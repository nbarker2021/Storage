# Patent Strategy (Non‑Legal Draft)

## Core Claims (method + system)
1) **Receipts‑native compute**: executing computations that **defer semantics** until a mirrored rest and **four‑view** commit pass, emitting a **4‑bit** receipt tied to rails, iso‑constraints, and overlays.
2) **Octet orchestration with monotone Δ‑lifts**: applying local repairs that provably lower debt without regression under iso‑constraints.
3) **Anchor‑clone geometry**: Construction‑A shell with logged automorphism IDs (M24/Monster) to mass‑produce isomorphic forms; ledger sufficient for 1:1 replay.
4) **Commit envelope & chain**: portable commit pack (rest_hash, fourbit, hue16, schema, receipts_hash, seed) notarized on a lightweight chain; data off‑chain in a content‑addressed cache.
5) **Backplane sidecars**: 64‑slot scheduler with budgets (beam, depth, ms), View‑Accrual Mode, Pareto‑greedy face selection, and collision‑triggered 8‑bit promotion.

## Dependent Claims
- Fill‑Vector Accounting; Cross‑View Residual Cache; Rail Rotation policy; EXO museum with reason codes.

## Trade Secrets
- Δ‑lift synthesis heuristics; octet design automation.

## Prior Art Notes
- CI/CD, ECC, reproducibility frameworks, formal methods—**partial limbs**. Emphasize CQE’s stitched order + late binding + 4‑bit portability + anchor‑clone registry.

## Filing Plan
- Provisional (12 mo) covering method/system/chain; follow with PCT. Freedom‑to‑Operate scan for ECC/ML pipeline overlaps.
