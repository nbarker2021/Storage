# Example Workflow
1) Author bundle in CQE‑L (rails, octet, mirror, Δ‑lifts, strict).
2) Run on CQE‑OS; get EXO or Working receipt.
3) If Working, bind semantics and publish via API; Chain notarizes.
4) Downstream consumes `(value, receipt)`; caches by commit hash.
