# Physics Sidecars

- S00 — OPTICS: PSF/MTF/phase retrieval
- S01 — EM_FIELD: E/B/ε/μ/σ rails
- S02 — THERMAL: radiator/vent cadence
- S03 — MECH_DYNAMICS
- S04 — CRYO_OPTICS
- S05 — THz_META
- S06 — PHOTONICS_COMB
- S07 — SPINTRONICS_Q
- S08 — ACOUSTICS
- S09 — RF_STEERING
- S10 — GRAVITY_WAVE
- S11 — PLASMA_SIM
- S12 — NEUTRON_OPTICS
- S13 — ION_TRAP_CTRL
- S14 — MAGNETIC_MATERIALS
- S15 — SUPERCONDUCTING_Q

**Template to 64**: replicate views across 8 bands × 8 regimes; auto-tag by hue16 and enforce collision monitors.
