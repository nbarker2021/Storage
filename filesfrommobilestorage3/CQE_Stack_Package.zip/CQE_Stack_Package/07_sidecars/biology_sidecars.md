# Biology Sidecars

- S00 — BIO_COHERENCE (radical pair / NV)
- S01 — ODMR_PROTEIN
- S02 — FRET_KINETICS
- S03 — OD_EC_GROWTH
- S04 — PCR_QPLOT
- S05 — SINGLE_CELL_FLUO
- S06 — EEG_RHYTHM
- S07 — OPTOGENETIC_PULSE
- S08 — FLOW_CYTOMETRY
- S09 — MICROFLUIDICS_TEMP
- S10 — CHEM_KINETICS
- S11 — DRUG_BINDING_ITC
- S12 — SPR_SENSOR
- S13 — AFM_FORCE
- S14 — CRISPR_EDIT_CHECK
- S15 — METABO_PROFILER

**Template to 64**: replicate views across 8 bands × 8 regimes; auto-tag by hue16 and enforce collision monitors.
