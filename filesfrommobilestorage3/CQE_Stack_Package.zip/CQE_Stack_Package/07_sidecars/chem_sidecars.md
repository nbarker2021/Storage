# Chemistry Sidecars

- S00 — NMR_SPECTRA
- S01 — FTIR
- S02 — RAMAN
- S03 — UV_VIS
- S04 — HPLC_RT
- S05 — GC_MS
- S06 — TITRATION_AUTOMATION
- S07 — CALORIMETRY
- S08 — ELECTROCHEM_CV
- S09 — PH_BUFFER
- S10 — CATALYST_TURNOVER
- S11 — REACTION_KINETICS
- S12 — SOLUBILITY_CURVE
- S13 — DISTILLATION
- S14 — CRYST_GROWTH
- S15 — ADSORPTION_ISO

**Template to 64**: replicate views across 8 bands × 8 regimes; auto-tag by hue16 and enforce collision monitors.
