# CQE Guidebook — Operator's Manual (Draft)

## Part I — Foundations
1. Why CQE (rest, octet, mirror, Δ‑lift, strict, receipts)
2. Geometry shells (Construction‑A, E8/Leech; Monster/M24 actions)
3. Tokens & albums (stand‑ins; Working vs Non‑Working)

## Part II — Running CQE
4. Rails & iso‑constraints
5. Designing octets; independence tests
6. Building the palindromic rest; mirror pairs
7. Δ‑lifts: writing, proving, and verifying non‑regression
8. Strict ratchets & maturity curves
9. Receipts: commit envelope & Merkle proofs

## Part III — Tooling
10. CQE‑L language
11. CQE‑OS runtime & sidecars
12. API/Chain & pricing
13. Human‑only kit

## Part IV — Patterns
14. ML pipelines (RAG/agents)
15. Lab calibration
16. Robotics/edge
17. Security/compliance

## Part V — Governance
18. EXO museums & rail rotation
19. Collision monitors & 8‑bit promotions
20. Audits, attestations, and disclosure
