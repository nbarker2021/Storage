# Human‑Only CQE Kit (Expanded)

Includes: Stand‑in cards, DNA‑10 sheets, Octet overlay, 4‑bit strip, Working/Non‑Working slips, Master ledger (pointers‑only), Parity loom guide (E8/Leech), and a wall checklist.

New additions:
- **FVA tracker** (fill‑vector) mini-card
- **Strict ratchet ledger** (bound history)
- **EXO museum index** (reason codes)
- **Rail rotation wheel** (periodic swap‑outs)
