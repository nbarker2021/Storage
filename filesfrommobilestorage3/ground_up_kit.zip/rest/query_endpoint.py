
from __future__ import annotations
from fastapi import APIRouter
from pydantic import BaseModel, Field
import numpy as np
from config.flags import ENABLE_DUAL_RETRIEVAL
from retrieval.scorer import ScorerConfig, rerank
router = APIRouter()
class QueryBody(BaseModel):
    center: list[float] = Field(..., min_items=8, max_items=8)
    candidates: list[list[float]]
    topk: int = 20
    alpha: float = 1.0
    beta: float = 0.0
@router.post("/query_budgeted")
def query_budgeted(body: QueryBody):
    q=np.array(body.center,dtype=float); docs=np.array(body.candidates,dtype=float)
    idx, scores = rerank(q, docs, ScorerConfig(alpha=body.alpha, beta=body.beta), topk=body.topk)
    return {"indices":[int(i) for i in idx], "scores":[float(s) for s in scores]}
