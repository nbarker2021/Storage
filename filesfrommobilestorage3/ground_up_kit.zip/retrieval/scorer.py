
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
@dataclass(slots=True)
class ScorerConfig:
    alpha: float = 1.0
    beta: float = 0.0
class PlaceholderGeodesic:
    def distance(self, a: np.ndarray, b: np.ndarray) -> float:
        na = a/(np.linalg.norm(a)+1e-12); nb=b/(np.linalg.norm(b)+1e-12)
        return 1.0 - float(np.dot(na, nb))
def blended_score(q, docs, cfg: ScorerConfig, g: PlaceholderGeodesic | None=None):
    qn = q/(np.linalg.norm(q)+1e-12); dn=docs/(np.linalg.norm(docs,axis=1,keepdims=True)+1e-12)
    cos = dn @ qn
    if cfg.beta==0.0: return cfg.alpha*cos
    if g is None: g=PlaceholderGeodesic()
    dists = np.array([g.distance(q, d) for d in docs], dtype=float)
    gscore = 1.0/(1.0+dists)
    return cfg.alpha*cos + cfg.beta*gscore
def rerank(q, docs, cfg: ScorerConfig, topk: int=50):
    s=blended_score(q, docs, cfg); idx=np.argsort(-s)[:topk]; return idx, s[idx]
