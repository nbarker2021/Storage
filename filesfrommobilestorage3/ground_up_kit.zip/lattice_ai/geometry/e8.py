
import numpy as np
from dataclasses import dataclass
from .e8_roots import E8

@dataclass
class E8Geometry:
    """
    Facade over a concrete E8 root system. Provides reflections and neighbor graph.
    """
    e8: E8 = None

    def __post_init__(self):
        if self.e8 is None:
            self.e8 = E8.build()
        self.simple_roots = self.e8.simple  # for compatibility

    def reflect(self, v: np.ndarray, k: int) -> np.ndarray:
        return self.e8.reflect(v, k)

    def batch_reflect(self, V: np.ndarray, k: int) -> np.ndarray:
        r = self.simple_roots[k]
        num = V @ r
        den = (r @ r)
        return V - 2.0 * (num[:, None] / den) * r[None, :]

    def geom_bias(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        return A @ B.T

    def neighbors(self, points: np.ndarray, k: int = 8):
        # Use inner-product=1 adjacency on the E8 root set, then fall back to kNN for arbitrary points
        R, nbrs = self.e8.neighbor_graph()
        if points.shape[0] == R.shape[0] and np.allclose(points, R):
            return nbrs
        # fallback: Euclidean kNN
        dists = np.sum((points[:, None, :] - points[None, :, :])**2, axis=-1)
        np.fill_diagonal(dists, np.inf)
        idxs = np.argsort(dists, axis=1)[:, :k]
        return [list(row) for row in idxs]
