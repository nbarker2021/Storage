
from __future__ import annotations
import pathlib, importlib, numpy as np
from typing import Any, Dict, Optional, Tuple
from .config import MODE, SNAP_COMPARE, SNAP_KIND
def _try_import(module: str):
    try: return importlib.import_module(module)
    except Exception: return None
def load_v14():
    return _try_import("lattice_ai.geometry.e8_roots"), _try_import("lattice_ai.geometry.e8")
class E8APIs:
    def __init__(self, roots_mod: Any, geo_mod: Any): self.roots_mod, self.geo_mod = roots_mod, geo_mod
    def generate_roots(self): return self.roots_mod.generate_e8_roots()
    def reflect(self, V, r): return self.geo_mod.E8Geometry().reflect(V, r)
def load_dual():
    r, g = load_v14()
    if not r or not g: raise ImportError("v14 geometry not available")
    return E8APIs(r,g), None, None
