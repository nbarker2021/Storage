
from __future__ import annotations
import os
MODE = os.getenv("E8_DUAL_MODE", "v14").lower()
SNAP_COMPARE = os.getenv("E8_SNAP_COMPARE","0")=="1"
SNAP_KIND = os.getenv("E8_SNAP_KIND","Run")
