# LFAI Executive Brief — v1.0 (UTC 2025-09-16T22:56:52Z)

**One-liner:** Replace similarity with **legality**. Facts are invariants of a declared frame; illegal states are not processed.

## What it delivers
- **Determinism:** unique normal form per input+frame (commit once).  
- **Explainability:** channel‑local reasons per verdict.  
- **Robustness:** ECC‑grade tolerance via Construction‑A.  
- **Governance:** contracts (GAE/CEC), evidence pins (NTER), auditable replay.  
- **Efficiency:** ledger many, materialize once.

## Acceptance Policy (Editorial Charter)
- REST (OPEN): Type‑II Con‑A legality + palindromy within θ + zero syndrome.  
- ACTION (PROVISIONAL‑CLOSE): reducible; Φ decreases.  
- REJECT: illegal, non‑reducible.  
- PROVISIONAL‑OPEN (NTER): structure OK; external pins pending.


**Pin & Evidence Legend**  
- ✅ satisfied, ⏳ pending, ✖ failed  
- Example pins: `atm_density_known`, `dv_budget_known`, `pressure_gpa>=2.0`, `temperature_c>=10`  
- Dual-witness required (e.g., structural parity + timing-13)



**Prime-Arm Legend**  
- 2/4/8 → parity & palindromy  
- 13 → timing/rate arm (default ON)  
- 24 → Golay/Leech legality  
- 3/5/7/11 → optional lanes activated by glyphs


## Results Snapshot
- **Navigation:** PROVISIONAL‑OPEN until `atm_density_known` & `dv_budget_known` (NTER).  
- **Ice Phase:** OPEN (pins satisfied).  
- **Codon Duplex:** OPEN (symbolic).


**Spec → API Map**  
1) GAE (Attestation) → `POST /frame` (compile frame)  
2) CEC (Execution) → `POST /verify` → `POST /reduce`* → `POST /commit`  
3) Storage/Retrieval → `POST /store` / `POST /retrieve` (invariant keys)  
4) Governance/Extension → `POST /extend` (priced, signed)  
*Reducer guarantees strict ↓Φ; confluence ensures unique normal form.


## Proof‑level Summary

### Formal Claims (sketch proofs)
**Theorem (Soundness).** If REST, then state lies in a Type‑II Con‑A shell with zero syndrome and zero palindrome‑defects.  
*Sketch:* legality test checks syndrome=0, evenness, canonical coset, and P₄=P₈=0.

**Theorem (Completeness for strict REST).** If a state is Type‑II legal with P₄=P₈=0, reducer returns REST at the canonical representative.  
*Sketch:* finite coset canonicalization; palindromy is preserved.

**Termination & Confluence.** Violation vector Φ(x)∈ℕ⁴ decreases strictly; local critical pairs resolve with parity‑first policy; Newman’s Lemma ⇒ unique normal form.


## Assurance
- Replay recipe (deterministic), Merkle‑bound logs, frame/nf hashes.  
- Falsifiers & Scoreboard to track safety and value.
