// cqeViewerSDK.js — v0 reference stubs

function normalize(obj){
  return new TextEncoder().encode(JSON.stringify(obj, Object.keys(obj).sort(), 0));
}

async function sha256(bytes){
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

async function merkleRoot(leaves){
  if (!leaves.length) return "merkle:empty";
  let layer = [];
  for (let L of leaves){
    const h = await sha256(L);
    layer.push(Uint8Array.from(h.match(/.{2}/g).map(x=>parseInt(x,16))));
  }
  while (layer.length>1){
    if (layer.length%2===1) layer.push(layer[layer.length-1]);
    const next=[];
    for (let i=0;i<layer.length;i+=2){
      const concat = new Uint8Array([...layer[i],...layer[i+1]]);
      const h = await crypto.subtle.digest("SHA-256", concat);
      next.push(new Uint8Array(h));
    }
    layer = next;
  }
  const rootHex = Array.from(layer[0]).map(b=>b.toString(16).padStart(2,'0')).join('');
  return "merkle:sha256:"+rootHex;
}

// Minimal API shape
export async function OCTET_plan(tokens){
  const buckets = {};
  for (const t of tokens){
    buckets[t.units] = buckets[t.units]||[];
    buckets[t.units].push(t);
  }
  const keys = Object.keys(buckets);
  const views = [];
  for (let i=0;i<8;i++){
    const k = keys[i] || "spare";
    const chans = buckets[k]? buckets[k].map(t=>t.id) : [];
    views.push({id:`H${i+1}`, name:`cluster:${k}`, channels:chans});
  }
  return {views, rest:"pal-gray"};
}

export function MIRROR_test(overlay, pose, tol){
  const k1 = overlay.views.reduce((a,v)=>a+Math.abs((v.channels||[]).length-1),0)/Math.max(1, overlay.views.length);
  const hash = Array.from(new TextEncoder().encode(pose)).reduce((s,b)=> (s+b)%1000, 0)/1000*0.01;
  const OPE = +(k1*0.03 + hash).toFixed(3);
  const FCE = +(k1*0.0285 + hash).toFixed(3);
  const passed = OPE<= (tol.OPE||0.05) && FCE<= (tol.FCE||0.05);
  return {passed, debt:{OPE, FCE}, delta:[{cell:[1,2], type:"bias", mag:+(k1*0.1).toFixed(3)}]};
}

export function STRICT_ratchet(thresholds, passed){
  const th = {...thresholds};
  if (passed){
    th.OPE = +(th.OPE*0.97).toFixed(3);
    th.FCE = +(th.FCE*0.97).toFixed(3);
  }
  return th;
}

export async function LEDGER_commit(context){
  const leaves = [];
  for (const key of ["overlay","mirror","thresholds","tokens"]){
    if (context[key]) leaves.push(normalize(context[key]));
  }
  const glyphs = normalize(context.glyphs||[]);
  leaves.push(glyphs);
  const root = await merkleRoot(leaves);
  const gh = await sha256(glyphs);
  return {
    fourbit: context.fourbit||"1011",
    metrics: context.metrics||{},
    automorphism: context.automorphism||{group:"M24", element:"σ_identity"},
    page_hash: root,
    glyph_hash: gh
  };
}
