# CQE Proof Pack v0.2 & Viewer SDK v0

Date: 2025-09-20

Contents
- Proof_Pack_v0_2.pdf — formal statements S1–S5, Construction-A acceptance, and receipt rules.
- SDK_Python/cqe_viewer_sdk.py — minimal reference stubs (plan, mirror, Δ, strict, ledger).
- SDK_JS/cqeViewerSDK.js — browser-friendly stubs with WebCrypto.
- Worksheets/WS-1..WS-5 — printable hand-proof worksheets (PDF or .txt fallback).

Quick Start (Python)
```
from SDK_Python.cqe_viewer_sdk import Token, run_once
tokens = [Token(id="tok-wfe", value=25.0, units="nm_rms", guards={"min":0,"max":100}, glyphs=["λ/20","🔬"])]
ctx, receipt = run_once(tokens, pose="pose0", thresholds={"OPE":0.05,"FCE":0.05})
print(receipt)
```

Notes
- The SDK stubs are illustrative; plug in your real OCTET planner and MIRROR forward/inverse.
- Merkle receipts hash overlay/deltas/thresholds/tokens/glyphs; sensitive leaves can be redacted via commitment while preserving the root.
- Worksheets are designed for pen-and-paper verification.
