# Adapter stub for OpenCatalyst
# Usage: python3 adapters/oc_adapter.py --path /data/oc --task IS2RE --sample 0
import argparse, json, pathlib
if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--path', required=True)
    ap.add_argument('--task', default='IS2RE')
    ap.add_argument('--sample', type=int, default=0)
    args = ap.parse_args()
    # TODO: load structure/targets, compute energy monotonicity, force alignment
    print(json.dumps({'status':'stub','task':args.task,'sample':args.sample}))
