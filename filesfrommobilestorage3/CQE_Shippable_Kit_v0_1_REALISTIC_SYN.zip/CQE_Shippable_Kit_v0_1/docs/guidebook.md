# CQE Guidebook (v0.1)
## Part I: Ritual
(1) Tokens → (2) DNA-10 → (3) Octet → (4) Mirror → (5) Δ-lift → (6) Strict → (7) Commit → (8) Ledger.
## Part II: Sidecars
Templates for math, ARC, WB, OC, EM, OPTICS, THERMAL, POLAR, SPINTRONICS, BIO, COSMOS...
## Part III: Receipts
Metrics per domain; reason codes; strict policies.
## Part IV: Geometry
Construction-A → E8/Leech shells; Monster/M24 actions.
## Part V: Operations
Promotion flow, collision rotation, EXO museum, reproducibility tips.
