# CQE Human-Only Kit (Printables)

## What you need
- Token cards (3×5): id, bucket, hue16, grad, salted_hash, provenance.
- DNA-10 sheet: timing, polarity, scale, pose, domain, conditioning, units, precision, cost, seed.
- Octet overlay sheet: 8 colored boxes + gray palindromic rest.
- Mirror strip: forward ↔ inverse check (tolerance).
- Δ-lift pad (red): local repair, must reduce debt, non-regression.
- Strict ratchet pad (gold): threshold → tighter only on pass.
- Receipts log (blue): mirror votes, view votes, debts, thresholds, fourbit.
- Ledger page: append-only commit pack; Merkle stamp.

## Ritual (1 page)
1) Stand-ins → fill token cards; **no semantics** yet.
2) DNA-10 → capture the state save.
3) Octet → pick 8 independent views you can actually test.
4) Mirror → forward∘inverse ≈ identity; if miss, go to Δ-lift.
5) Δ-lift → one local repair; debt ↓; no regression.
6) Strict → tighten thresholds if (and only if) pass.
7) Commit → shade the 4-bit strip if 4 rails pass; else EXO.
8) Ledger → copy the commit pack; stamp Merkle hash.

## Loom sanity (Construction-A)
- Hamming→E8: parity clips + half-shift glue.
- Extended Golay→Leech: octads as masks; Monster actions as braid permutations.
- Palindromic overlay must align under the tracing-paper mirror.
