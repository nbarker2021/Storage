#!/usr/bin/env python3
import argparse, json, subprocess, sys, hashlib, time
from pathlib import Path

def sha(x:bytes)->str: import hashlib; return hashlib.sha256(x).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", type=Path, required=True, help="JSON/YAML plan of rails")
    ap.add_argument("--out", type=Path, required=True, help="Output chained ledger JSON")
    args = ap.parse_args()
    # naive YAML/JSON load
    import json, re
    text = args.plan.read_text()
    try:
        plan = json.loads(text)
    except Exception:
        # minimal YAML -> JSON (very naive; accepts a tiny subset)
        lines = [l for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
        d = {}
        current = None
        arr = []
        for l in lines:
            if re.match(r"^-", l.strip()):
                arr.append(l.split(":",1)[-1].strip())
            elif ":" in l:
                k,v = l.split(":",1); d[k.strip()] = v.strip()
            else:
                pass
        plan = {"rails": arr or d.get("rails", [])}
    rails = plan.get("rails", [])
    wrapper_id = plan.get("wrapper_id","CQE_CHAIN")
    seed = int(plan.get("seed", 20250920))
    cwd = Path(__file__).resolve().parent
    receipts_dir = cwd.parent/"receipts_chain"
    receipts_dir.mkdir(exist_ok=True, parents=True)
    entries = []
    bits_concat = ""
    for r in rails:
        out = receipts_dir/f"{r}.json"
        cmd = [sys.executable, str(cwd/"cqe_cli.py"), "--rail", r, "--seed", str(seed), "--out", str(out)]
        p = subprocess.run(cmd, capture_output=True, text=True)
        if p.returncode!=0:
            entries.append({"rail": r, "error": p.stderr})
            continue
        entry = json.loads(out.read_text())
        bits = entry.get("commit_bits","")
        bits_concat += bits
        entries.append(entry)
    chain = {
        "wrapper_id": wrapper_id,
        "seed": seed,
        "entries": entries,
        "composite_bits": bits_concat,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    }
    chain["merkle_root"] = sha(json.dumps(chain, sort_keys=True).encode())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(chain, indent=2))
    print(json.dumps(chain, indent=2))

if __name__=="__main__":
    main()
