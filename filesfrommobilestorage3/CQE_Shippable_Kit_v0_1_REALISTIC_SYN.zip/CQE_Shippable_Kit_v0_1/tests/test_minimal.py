#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    assert p.returncode==0, p.stderr
    return p.stdout

def main():
    root = Path(__file__).resolve().parents[1]
    # parity test via WB
    wb = root/"receipts/wb_test.json"
    run([sys.executable, str(root/"tools/cqe_cli.py"), "--rail","WB_SYN","--out", str(wb)])
    # chain test
    chain = root/"receipts_chain/chain_test.json"
    run([sys.executable, str(root/"tools/cqe_chain.py"), "--plan", str(root/"plans/demo_plan.json"), "--out", str(chain)])
    print("OK")
if __name__=="__main__":
    main()
