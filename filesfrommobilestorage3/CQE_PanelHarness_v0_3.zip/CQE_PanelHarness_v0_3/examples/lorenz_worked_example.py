
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
from core.geom_embed import lorenz_step, embed_state_3d_to_8d, promote_8d_to_24d, quantize
from adapters.optional_adapters import load_any, call_first

def run(root, key_b64, steps=600, dt=0.01):
    led = MasterLedger(root, key_b64)
    found = load_any()
    def on_receipt(rec): led.append({"type":"sidecar_receipt", **rec})
    sl = attach_sidecar(root, on_receipt=on_receipt)
    x,y,z = 1.0,1.0,1.0
    totalE = 0.0; deltaE=[]; eq_counts={}
    for i in range(steps):
        x,y,z = lorenz_step(x,y,z, dt=dt); t = i*dt
        payload = {"example":"lorenz","i":i}
        def compute_once():
            v8 = embed_state_3d_to_8d(x,y,z,t)
            ok, v24 = call_first(found, "viewer24_embed", v8)
            if not ok:
                v24 = promote_8d_to_24d(v8)
            q = quantize(v24, bins=32)
            # optional mdhg gate
            ok2, adm = call_first(found, "mdhg_admit", {"source":"lorenz","i":i,"q":q})
            if ok2 and adm:
                led.append({"type":"lorenz_mdhg_admit","i":i,"admit":bool(adm.get("admit")), "distance":adm.get("distance"), "slot":adm.get("slot")})
            return {"state":[x,y,z],"v8":v8,"v24":v24,"q":q}
        res, cost, rid = sl.compute(payload, scope="lorenz", channel=6, compute_fn=compute_once, tags=["lorenz"])
        hit = (cost.get("hits",0)==1 and cost.get("cost",0.0)==0.0)
        E = cost.get("cost",0.0) if not hit else cost.get("cost",0.0)*0.1
        totalE += E; deltaE.append({"i":i,"E":totalE,"hit":hit})
        key = tuple(res["q"]); eq_counts[key] = eq_counts.get(key,0)+1
        if i % 100 == 0:
            led.append({"type":"lorenz_step","i":i,"rid":rid,"E":totalE})

    eq_len = len(eq_counts); top = sorted(eq_counts.items(), key=lambda kv: -kv[1])[:10]
    led.append({"type":"lorenz_report","classes":eq_len,"top":top})
    return {"example":"lorenz","steps":steps,"classes":eq_len,"top":top,"deltaE_tail": deltaE[-10:]}
