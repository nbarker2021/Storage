
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
from core.geom_embed import embed_hash_to_8d, promote_8d_to_24d, quantize
from adapters.optional_adapters import load_any, call_first

def run(root, key_b64, N=256):
    led = MasterLedger(root, key_b64)
    found = load_any()
    def on_receipt(rec): led.append({"type":"sidecar_receipt", **rec})
    sl = attach_sidecar(root, on_receipt=on_receipt)
    eq_counts = {}; deltaE = []; totalE = 0.0
    samples24 = []

    for n in range(N):
        payload = {"example":"rng","n":n}
        def compute_once():
            seed = str(n).encode()
            v8 = embed_hash_to_8d(seed)
            ok, v24 = call_first(found, "viewer24_embed", v8)
            if not ok:
                v24 = promote_8d_to_24d(v8)
            q = quantize(v24, bins=32)
            # optional moonshine crosshit
            ok2, moon = call_first(found, "moonshine_crosshit", v24)
            if ok2 and moon:
                led.append({"type":"rng_moonshine", "n":n, "moon":moon})
            # optional mdhg admission
            ok3, adm = call_first(found, "mdhg_admit", {"source":"rng","n":n,"q":q})
            if ok3 and adm:
                led.append({"type":"rng_mdhg_admit","n":n,"admit":bool(adm.get("admit")), "distance":adm.get("distance"), "slot":adm.get("slot")})
            return {"v8":v8,"v24":v24,"q":q}
        res, cost, rid = sl.compute(payload, scope="rng", channel=3, compute_fn=compute_once, tags=["rng","sha256"])
        hit = (cost.get("hits",0)==1 and cost.get("cost",0.0)==0.0)
        E = cost.get("cost",0.0) if not hit else cost.get("cost",0.0)*0.1
        totalE += E; deltaE.append({"i":n,"E":totalE,"hit":hit})
        key = tuple(res["q"]); eq_counts[key] = eq_counts.get(key,0)+1
        if n<128:
            samples24.append(tuple(float(x) for x in res["v24"]))

    # lattice proxy classification on sample
    from core.geom_embed import gram_proxy
    proxy = gram_proxy(samples24) if samples24 else {"mean":0,"var":0,"top":[]}
    led.append({"type":"rng_proxy", "proxy": proxy})

    # pick one text file for geotokenize demo
    import glob, os
    text_files = [p for p in glob.glob("/mnt/data/*") if os.path.isfile(p) and p.lower().endswith((".md",".txt"))]
    if text_files:
        try:
            with open(text_files[0],"r",encoding="utf-8",errors="ignore") as f:
                txt = f.read(1000)
            ok4, toks = call_first(found, "geotokenize", txt)
            if ok4 and toks:
                led.append({"type":"rng_geotokenize","file":os.path.basename(text_files[0]),"tokens":toks})
        except Exception as e:
            led.append({"type":"rng_geotokenize_err","err":str(e)})

    # summarize
    eq_len = len(eq_counts)
    top = sorted(eq_counts.items(), key=lambda kv: -kv[1])[:10]
    led.append({"type":"rng_report","classes":eq_len,"top":top})
    return {"example":"rng","N":N,"classes":eq_len,"top":top,"deltaE_tail": deltaE[-10:], "samples24": samples24[:32], "proxy": proxy}
