
def diagram_for_case(case="rng"):
    return {
        "case": case,
        "pipeline":[
            "ingest_auto → manifest receipts",
            "orchestrator.new_run_id",
            "SpeedLight.compute(key=payload) → rid",
            "geom_embed / viewer24_embed → quantize → equivalence_class",
            "mdhg_admit / moonshine_crosshit receipts (if adapters present)",
            "ΔE add(hit/miss) → cumulative",
            "ledger.append at milestones",
            "report JSON written to artifacts/"
        ]
    }
