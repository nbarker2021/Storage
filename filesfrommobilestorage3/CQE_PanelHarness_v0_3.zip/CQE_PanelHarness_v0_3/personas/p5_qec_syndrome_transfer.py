
from examples import qec_worked_example as QEC
def run(root, key_b64):
    rep = QEC.run(root, key_b64, trials=64, p_err=0.2)
    syn = rep["common_syndrome"]
    rep["transfer_hint"] = {"syndrome": syn, "reused_as":"diagnostic_tag:mod3"}
    return rep
