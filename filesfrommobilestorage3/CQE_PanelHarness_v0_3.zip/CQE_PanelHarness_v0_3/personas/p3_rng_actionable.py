
from examples import rng_worked_example as RNG
def run(root, key_b64): return RNG.run(root, key_b64, N=256)
