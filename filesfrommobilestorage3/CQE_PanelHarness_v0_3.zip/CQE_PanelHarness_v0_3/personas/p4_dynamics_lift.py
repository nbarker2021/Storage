
from examples import lorenz_worked_example as LOR
def run(root, key_b64): return LOR.run(root, key_b64, steps=600, dt=0.01)
