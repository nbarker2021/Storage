
def pick_onramp():
    return {
        "recommended_entry":"RNG/hash worked example",
        "why":[
            "fully concrete inputs/outputs",
            "clean path from bytes → geometry → classes → receipts",
            "easy to swap in your adapters (viewer24/mdhg/moonshine)"
        ]
    }
