
from core.geom_embed import gram_proxy
def classify_proxy(sample_q24):
    prototypes = {"Leech-like":{"mean":8.0,"var":1.0},"E8^3-like":{"mean":7.0,"var":1.5},"A24-like":{"mean":6.0,"var":2.0}}
    g = gram_proxy(sample_q24)
    def dist(p): return abs(g["mean"]-p["mean"]) + abs(g["var"]-p["var"])
    name = min(prototypes.items(), key=lambda kv: dist(kv[1]))[0]
    return {"proxy_gram": g, "nearest": name}
