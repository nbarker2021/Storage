
from examples import lambda_worked_example as LMB
def run(root, key_b64): return LMB.run(root, key_b64)
