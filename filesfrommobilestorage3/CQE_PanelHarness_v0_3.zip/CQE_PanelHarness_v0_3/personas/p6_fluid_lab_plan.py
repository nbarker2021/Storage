
def lab_plan_grid_turbulence():
    return {
        "scenario":"grid_turbulence",
        "measurements":[
            "U(x,y,t), V(x,y,t) via PIV",
            "pressure taps downstream of grid",
            "spectra E(k) over windowed segments"
        ],
        "embedding":"window fields → v8 counts → viewer24_embed (if provided) → q24 equivalence",
        "predictions":[
            "as Re↑, increased class concentration near few q24 bins (emergent order in lift)",
            "ΔE decreases with reuse of structures across windows"
        ]
    }
