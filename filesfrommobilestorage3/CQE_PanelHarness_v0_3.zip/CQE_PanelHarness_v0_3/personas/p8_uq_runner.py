
from examples import uq_perturb_runner as UQ
def run(root, key_b64): return UQ.run(root, key_b64, seeds=128, perturb=3)
