
from core.geom_embed import embed_hash_to_8d, promote_8d_to_24d, quantize
def synthetic_task(n=200):
    items = []
    for i in range(n):
        label = (sum(int(c) for c in str(i)) % 2)
        v8 = embed_hash_to_8d(str(i).encode())
        v24 = promote_8d_to_24d(v8)
        q = quantize(v24, bins=32)
        items.append({"i":i,"label":label,"q":q})
    def hamming(a,b): return sum(1 for x,y in zip(a,b) if x!=y)
    errors = 0; errors_q = 0
    for i in range(n):
        j = i-1 if i>0 else 1
        if (sum(int(c) for c in str(j)) % 2) != items[i]["label"]: errors += 1
        best = None; best_d = 1e9
        for k in range(n):
            if k==i: continue
            d = hamming(items[i]["q"], items[k]["q"])
            if d<best_d: best_d=d; best=k
        if items[best]["label"] != items[i]["label"]: errors_q += 1
    return {"n":n, "baseline_err":errors, "qspace_err":errors_q}
