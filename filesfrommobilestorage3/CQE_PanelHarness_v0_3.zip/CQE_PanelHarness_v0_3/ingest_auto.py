
import os, json, glob
from core.ledger import MasterLedger

def discover_user_papers(scan_root="/mnt/data"):
    files = []
    exts = (".md",".txt",".pdf",".docx",".tex")
    for p in glob.glob(os.path.join(scan_root, "*")):
        if os.path.isfile(p) and p.lower().endswith(exts):
            files.append(p)
    return files

def run(ledger: MasterLedger, scan_root="/mnt/data"):
    files = discover_user_papers(scan_root)
    rec = {"type":"auto_ingest_manifest","files":[os.path.basename(f) for f in files]}
    ledger.append(rec)
    for path in files:
        name = os.path.basename(path)
        try:
            if path.lower().endswith((".md",".txt")):
                with open(path,"r",encoding="utf-8",errors="ignore") as f:
                    snippet = f.read(2000)
            else:
                snippet = f"[binary:{os.path.splitext(name)[1]}]"
        except Exception as e:
            snippet = f"[error:{e}]"
        ledger.append({"type":"auto_ingest_item","name":name,"snippet":snippet})
    return {"count": len(files)}
