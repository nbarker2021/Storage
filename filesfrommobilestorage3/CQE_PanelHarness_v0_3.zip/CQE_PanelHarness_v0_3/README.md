
# CQE_PanelHarness_v0_3 — Adapters-wired, receipt-heavy, near-real run

**What’s new**
- Auto-unpacks your zipped toolkits from `/mnt/data` into `adapters/ext/` and **auto-loads** any `*.py` that looks like GeoTokenizer / Viewer24 / MDHG / Monster/Moonshine / Lattice / Transformer / Controller / Validator.
- RNG / Lorenz / λ examples **call adapters if present**:
  - `viewer24_embed(v8)` for the true 24D embedding
  - `mdhg_admit(payload)` to gate admission & log distance/slot
  - `moonshine_crosshit(v24)` to annotate matches
  - `geotokenize(text)` exercised on one discovered `.md/.txt`
- Every adapter call adds **receipts** in the master ledger.

## Run
```bash
cd CQE_PanelHarness_v0_3
python panel_orchestrator.py
# -> artifacts/panel_bundle.json
# -> artifacts/ledgers/master.jsonl
```

## Where to drop your tools
Put zips (e.g., `Viewer24_Controller_v2_CA.zip`, `GeoTokenizer_TieIn_v1.zip`, `MonsterMoonshineDB_v1.zip`, `LatticeBuilder_Validator_v1.zip`, `GeometryOnlyTransformer_Standalone_v2.zip`, `Morphonic-LambdaSuite_v1.zip`, `CoherenceSuite_v1.zip`, `AGRM_*.zip`) into `/mnt/data` **before** running. The harness will unpack what it can and try to import their `.py` modules.

### Optional adapter signatures
```python
def geotokenize(text: str) -> dict: ...
def viewer24_embed(v8: list[float]) -> list[float]:  # returns 24D
def mdhg_admit(payload: dict) -> dict:  # {"admit": bool, "distance": float, "slot": str}
def moonshine_crosshit(v24: list[float]) -> dict:  # arbitrary metadata about cross-hits
```

These are detected dynamically; missing ones fall back to defaults.

## Receipts
- **Sidecar**: Every compute call yields a `sidecar_receipt` entry with `rid/scope/channel/tags/hit/cost`.
- **Adapters**: Each successful adapter call writes a typed receipt (`rng_moonshine`, `*_mdhg_admit`, `rng_geotokenize`…).
- **Sections**: Worked-example entries `WE1..WE6_*` pin the exact flow for the panel’s ask.
- **Verify**: `ledger.verify()` results included in `panel_bundle.json`.

Replace the placeholder ΔE with your ΔΦ and wire any additional instruments; all events will be ledgered.
