
import importlib.util, os, sys, json
from .ext_unpacker import unpack_all

def _try_load(path, name_hint):
    try:
        spec = importlib.util.spec_from_file_location(name_hint, path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None

def load_any():
    mods = []
    # unpack relevant zips from /mnt/data to local ext/
    unpacked_dirs = unpack_all(dest=os.path.join(os.path.dirname(__file__), "ext"))
    # include unpacked dirs in sys.path
    for d in unpacked_dirs:
        if d not in sys.path:
            sys.path.append(d)
    # look for .py candidates in /mnt/data, cwd, and ext tree
    candidates = []
    roots = ["/mnt/data","."] + unpacked_dirs
    hints = ["adapter","geotoken","tokenizer","viewer24","mdhg","moonshine","monster","niemeier","leech","lattice","transformer"]
    for r in roots:
        if not os.path.isdir(r): continue
        for dirpath,_,files in os.walk(r):
            for fn in files:
                if fn.endswith(".py") and any(h in fn.lower() for h in hints):
                    candidates.append(os.path.join(dirpath, fn))
    loaded = []
    for p in candidates:
        m = _try_load(p, os.path.basename(p).replace(".py",""))
        if m: loaded.append(m)
    return loaded

def call_first(mods, fn, *args, **kw):
    for m in mods:
        if hasattr(m, fn):
            try:
                return True, getattr(m, fn)(*args, **kw)
            except Exception as e:
                return True, {"error": str(e)}
    return False, None
