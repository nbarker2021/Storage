
import os, zipfile, shutil

KEYS = ["viewer24","geotoken","tokenizer","moonshine","monster","niemeier","leech","lattice","mdhg","agrm","coherence","geometryonly","lambda","suite","controller","validator","transformer"]

def unpack_all(src="/mnt/data", dest="adapters/ext"):
    os.makedirs(dest, exist_ok=True)
    unpacked = []
    for fn in os.listdir(src):
        p = os.path.join(src, fn)
        if not os.path.isfile(p): continue
        if not fn.lower().endswith(".zip"): continue
        if not any(k in fn.lower() for k in KEYS): continue
        out = os.path.join(dest, os.path.splitext(fn)[0])
        try:
            if os.path.exists(out): shutil.rmtree(out)
            os.makedirs(out, exist_ok=True)
            with zipfile.ZipFile(p, "r") as z:
                z.extractall(out)
            unpacked.append(out)
        except Exception:
            continue
    return unpacked
