
import os, json, base64, time
from core.ledger import MasterLedger
import ingest_auto
from personas import p1_lattice_check as P1
from personas import p2_lambda_semantics as P2
from personas import p3_rng_actionable as P3
from personas import p4_dynamics_lift as P4
from personas import p5_qec_syndrome_transfer as P5
from personas import p6_fluid_lab_plan as P6
from personas import p7_ml_pipeline as P7
from personas import p8_uq_runner as P8
from personas import p9_tooling_diagram as P9
from personas import p10_onramp_example as P10

def worked_example_rng(root, key_b64):
    led = MasterLedger(root, key_b64)
    run_id = led.new_run_id("worked_rng")
    problem = {"input":"sha256(i) for i in [0..255]","goal":"analyze latent geometry + equivalence + ΔE (+ adapters)"}
    led.append({"type":"WE1_setup","run_id":run_id,"problem":problem})
    rep_rng = P3.run(root, key_b64)
    samples = rep_rng.get("samples24", [])[:8]
    led.append({"type":"WE2_embed","run_id":run_id,"samples24_head":samples})
    diag = P9.diagram_for_case("rng")
    led.append({"type":"WE3_tooling","run_id":run_id,"diagram":diag})
    led.append({"type":"WE4_energy","run_id":run_id,"hint":"inspect artifacts/ledgers/master.jsonl for ΔE cumulative and sidecar receipts"})
    p1 = P1.classify_proxy(samples)
    led.append({"type":"WE5_syndromes","run_id":run_id,"proxy":p1})
    outcome = {"equivalence": {"classes": rep_rng.get("classes"), "top": rep_rng.get("top")}, "note":"Adapters (viewer24/mdhg/moonshine/geotokenize) logged receipts if present."}
    led.append({"type":"WE6_outcome","run_id":run_id,"outcome":outcome})
    return {"run_id": run_id, "input_setup": problem, "embedding_samples24_head": samples, "tooling_diagram": diag, "energy_hint": "ΔE in ledger receipts", "syndrome_proxy": p1, "outcome": outcome}

def run_all(project_root=None, out_name="panel_bundle.json"):
    project_root = project_root or os.getcwd()
    key_b64 = base64.b64encode(os.urandom(32)).decode("ascii")
    art = os.path.join(project_root, "artifacts"); os.makedirs(art, exist_ok=True)
    led = MasterLedger(art, key_b64)
    led.append({"type":"panel_start","ts":time.time()})
    try:
        ingest_auto.run(led, scan_root="/mnt/data")
    except Exception as e:
        led.append({"type":"auto_ingest_error","err":str(e)})
    # persona runs
    rep_p3 = P3.run(art, key_b64)
    rep_p4 = P4.run(art, key_b64)
    rep_p2 = P2.run(art, key_b64)
    rep_p5 = P5.run(art, key_b64)
    rep_p8 = P8.run(art, key_b64)
    rep_p7 = P7.synthetic_task(n=200)
    diag = P9.diagram_for_case("rng")
    onr = P10.pick_onramp()
    # worked example
    we = worked_example_rng(art, key_b64)
    v = led.verify()
    bundle = {
        "worked_example_rng": we,
        "persona_reports": {
            "rng": rep_p3,
            "lorenz": rep_p4,
            "lambda": rep_p2,
            "qec": rep_p5,
            "uq": rep_p8,
            "ml_synth": rep_p7,
            "tooling_diagram": diag,
            "onramp": onr
        },
        "ledger_verify": v
    }
    out_path = os.path.join(art, out_name)
    with open(out_path,"w",encoding="utf-8") as f: json.dump(bundle, f, indent=2)
    return out_path

if __name__ == "__main__":
    p = run_all()
    print("wrote", p)
