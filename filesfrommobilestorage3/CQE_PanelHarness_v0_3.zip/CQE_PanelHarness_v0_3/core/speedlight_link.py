
import os, json, time, hashlib, importlib.util, threading

class SimpleSidecar:
    def __init__(self, on_receipt=None):
        self.cache = {}
        self.lock = threading.Lock()
        self.on_receipt = on_receipt

    def compute(self, key_obj, scope="panel", channel=3, compute_fn=None, tags=None):
        key = hashlib.sha256((scope+"|"+str(channel)+"|"+json.dumps(key_obj, sort_keys=True)).encode()).hexdigest()
        with self.lock:
            if key in self.cache:
                e = self.cache[key]
                rid = e["rid"]
                if self.on_receipt:
                    self.on_receipt({"rid":rid,"scope":scope,"channel":channel,"tags":tags or [],"hit":True,"cost":0.0})
                return e["result"], {"hits":1,"misses":0,"cost":0.0}, rid
        t0 = time.time()
        res = compute_fn() if compute_fn else None
        dt = time.time()-t0
        rid = "R:"+key[:16]
        with self.lock:
            self.cache[key] = {"result":res,"rid":rid,"E":dt}
        if self.on_receipt:
            self.on_receipt({"rid":rid,"scope":scope,"channel":channel,"tags":tags or [],"hit":False,"cost":dt})
        return res, {"hits":0,"misses":1,"cost":dt}, rid

def load_speedlight_plus(path, on_receipt=None):
    try:
        spec = importlib.util.spec_from_file_location("speedlight_sidecar_plus", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        cls = getattr(mod, "SpeedLightPlus", None)
        if cls is None:
            return None
        sl = cls(mem_bytes=256_000_000, disk_dir=None, ledger_path=None)
        orig = sl.compute
        def wrapped(key_obj, scope="panel", channel=3, compute_fn=None, tags=None):
            res, cost, rid = orig(key_obj, scope=scope, channel=channel, compute_fn=compute_fn)
            if on_receipt:
                on_receipt({"rid":rid,"scope":scope,"channel":channel,"tags":tags or [],"hit": cost.get("hits",0)==1 and cost.get("cost",0.0)==0.0, "cost": cost.get("cost",0.0)})
            return res, cost, rid
        sl.compute = wrapped
        return sl
    except Exception:
        return None

def attach_sidecar(project_root: str, on_receipt=None):
    plus = os.path.join(project_root, "speedlight_sidecar_plus.py")
    if os.path.exists(plus):
        sl = load_speedlight_plus(plus, on_receipt=on_receipt)
        if sl: return sl
    plus2 = "/mnt/data/speedlight_sidecar_plus.py"
    if os.path.exists(plus2):
        sl = load_speedlight_plus(plus2, on_receipt=on_receipt)
        if sl: return sl
    return SimpleSidecar(on_receipt=on_receipt)
