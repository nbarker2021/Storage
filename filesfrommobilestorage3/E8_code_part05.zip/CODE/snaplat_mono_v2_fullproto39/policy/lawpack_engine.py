import json, pathlib, yaml
from kernel.telemetry import emit

LAW_DIR = pathlib.Path("policy/lawpacks")

def _load_packs():
    packs = {}
    if not LAW_DIR.exists():
        return packs
    for p in LAW_DIR.glob("*.yaml"):
        try:
            packs[p.stem] = yaml.safe_load(p.read_text(encoding="utf-8"))
        except Exception:
            continue
    return packs

def _check_privacy(slice_desc):
    # deny PII without consent
    pii_keys = {'email','ssn','phone','dob','address'}
    found = [k for k in pii_keys if k in slice_desc]
    if found and not slice_desc.get('consent', False):
        return False, [f"privacy.pii_without_consent:{','.join(found)}"]
    return True, []

def _check_legal(slice_desc):
    # block export-restricted content
    if slice_desc.get('export_restricted', False):
        return False, ["legal.export_control.blocked"]
    return True, []

def _check_finance(slice_desc):
    # If finance fields present, enforce double entry balance
    deb = sum(slice_desc.get('debits', []) or [0])
    cre = sum(slice_desc.get('credits', []) or [0])
    if (slice_desc.get('debits') or slice_desc.get('credits')) and deb != cre:
        return False, [f"finance.unbalanced:{deb}-{cre}"]
    return True, []

def _check_physics(slice_desc):
    # Placeholder: always pass
    return True, []

CHECKS = {
    'privacy': _check_privacy,
    'legal': _check_legal,
    'finance': _check_finance,
    'physics': _check_physics,
}

def enforce_lawpacks(slice_desc: dict) -> (bool, list):
    packs = _load_packs()
    reasons = []
    ok = True
    for name in packs.keys():
        fn = CHECKS.get(name)
        if not fn:
            continue
        passed, rs = fn(slice_desc)
        if not passed:
            ok = False
            reasons.extend(rs)
    emit("lawpack.evaluate", "cto", {"ok": ok, "reasons": reasons})
    return ok, reasons


def _enabled(packs, name):
    cfg = packs.get(name, {}) or {}
    return bool(cfg.get('enabled', True))

def enforce_lawpacks(slice_desc: dict) -> (bool, list):
    packs = _load_packs()
    reasons = []
    ok = True
    # PRIVACY
    if _enabled(packs,'privacy'):
        pii_keys = set(packs.get('privacy',{}).get('require_consent_for', [])) or {'email','ssn','phone','dob','address'}
        found = [k for k in pii_keys if k in slice_desc]
        if found and not slice_desc.get('consent', False):
            ok = False; reasons.append(f"privacy.pii_without_consent:{','.join(found)}")
    # LEGAL
    if _enabled(packs,'legal'):
        if slice_desc.get('export_restricted', False):
            ok = False; reasons.append('legal.export_control.blocked')
    # FINANCE
    if _enabled(packs,'finance'):
        tol = float(packs.get('finance',{}).get('balance_tolerance', 0))
        deb = sum(slice_desc.get('debits', []) or [0])
        cre = sum(slice_desc.get('credits', []) or [0])
        if (slice_desc.get('debits') or slice_desc.get('credits')) and abs(deb - cre) > tol:
            ok = False; reasons.append(f"finance.unbalanced:{deb}-{cre} tol={tol}")
    # PHYSICS (placeholder)
    # Emit summary
    from kernel.telemetry import emit
    emit("lawpack.evaluate", "cto", {"ok": ok, "reasons": reasons})
    return ok, reasons


def _enforce_domain_packs(slice_desc, packs, reasons):
    ok = True
    # Healthcare PHI
    hc = packs.get('healthcare') or {}
    if hc.get('enabled', False):
        phi = set(hc.get('phi_fields', []))
        if any(k in slice_desc for k in phi) and not slice_desc.get('consent', False):
            ok = False; reasons.append('healthcare.phi_without_consent')
    # Education FERPA
    edu = packs.get('education') or {}
    if edu.get('enabled', False):
        fe = set(edu.get('ferpa_fields', []))
        if any(k in slice_desc for k in fe) and not slice_desc.get('consent', False):
            ok = False; reasons.append('education.ferpa_without_consent')
    return ok

# Patch main enforce to call domain packs
_old_enforce = enforce_lawpacks

def enforce_lawpacks(slice_desc: dict) -> (bool, list):
    packs = _load_packs()
    reasons = []
    ok, base_reasons = True, []
    # reuse prior checks by feeding packs to a local copy
    # reconstruct base checks quickly
    # PRIVACY
    if (packs.get('privacy',{}).get('enabled', True)):
        pii_keys = set(packs.get('privacy',{}).get('require_consent_for', [])) or {'email','ssn','phone','dob','address'}
        found = [k for k in pii_keys if k in slice_desc]
        if found and not slice_desc.get('consent', False):
            ok = False; reasons.append(f"privacy.pii_without_consent:{','.join(found)}")
    if (packs.get('legal',{}).get('enabled', True)) and slice_desc.get('export_restricted', False):
        ok = False; reasons.append('legal.export_control.blocked')
    if (packs.get('finance',{}).get('enabled', True)):
        tol = float(packs.get('finance',{}).get('balance_tolerance', 0))
        deb = sum(slice_desc.get('debits', []) or [0])
        cre = sum(slice_desc.get('credits', []) or [0])
        if (slice_desc.get('debits') or slice_desc.get('credits')) and abs(deb - cre) > tol:
            ok = False; reasons.append(f"finance.unbalanced:{deb}-{cre} tol={tol}")
    # Domain packs
    if not _enforce_domain_packs(slice_desc, packs, reasons):
        ok = False
    from kernel.telemetry import emit
    emit('lawpack.evaluate', 'cto', {'ok': ok, 'reasons': reasons})
    return ok, reasons
