#!/usr/bin/env python3
import os, time, json, shutil, pathlib, subprocess, sys
from pathlib import Path

ROOT = Path(".")

SCENES = [
    {"name":"S1_small",  "ticks":4, "batch":64,  "budget":{"e8_per_tick":64,  "policy":"stretch","max_carry_ticks":10}, "max_vecs":512},
    {"name":"S2_medium", "ticks":4, "batch":256, "budget":{"e8_per_tick":256, "policy":"stretch","max_carry_ticks":10}, "max_vecs":2000},
    {"name":"S3_large",  "ticks":4, "batch":512, "budget":{"e8_per_tick":512, "policy":"stretch","max_carry_ticks":10}, "max_vecs":6000},
]

def patch_budgets(b):
    p = ROOT/'triads/sap_snapops_archivist/snapops/budgets.py'
    txt = p.read_text(encoding='utf-8')
    import re
    txt = re.sub(r'"e8_per_tick":\s*\d+', f'"e8_per_tick": {b["e8_per_tick"]}', txt)
    txt = re.sub(r'"policy":\s*"(stretch|skip)"', f'"policy": "{b["policy"]}"', txt)
    txt = re.sub(r'"max_carry_ticks":\s*\d+', f'"max_carry_ticks": {b["max_carry_ticks"]}', txt)
    p.write_text(txt, encoding='utf-8')

def clear_outputs():
    for d in ['outputs/cas', 'outputs/trails', 'outputs/state/batches', 'outputs/state/snapshots']:
        dp = ROOT/d
        if dp.exists():
            shutil.rmtree(dp)

def cas_stats():
    root = ROOT/'outputs/cas'
    n=0; bytes=0
    if root.exists():
        for p in root.rglob('*.json'):
            n += 1
            bytes += p.stat().st_size
    return {"files": n, "bytes": bytes}

def run_scene(scene, zip_path):
    print("== Running", scene["name"])
    clear_outputs()
    # reseed backlog from zip with improved vectorizer; cap vecs
    # (Temp hack: seed script has a fixed cap; we'll run it then trim)
    subprocess.run([sys.executable, "tools/seed_backlog_from_zip.py", zip_path], check=True)
    # trim to max_vecs
    qpath = ROOT/'outputs/state/queues/e8_backlog.json'
    q = json.loads(qpath.read_text(encoding='utf-8'))
    if len(q["vectors"]) > scene["max_vecs"]:
        q["vectors"] = q["vectors"][:scene["max_vecs"]]
        qpath.write_text(json.dumps(q), encoding='utf-8')
    # budgets
    patch_budgets(scene["budget"])
    # run audit to a scenario-specific output root
    out_root = ROOT/f"outputs/reports/{scene['name']}"
    t0 = time.perf_counter()
    subprocess.run([sys.executable, "tools/tick_audit.py", "--ticks", str(scene["ticks"]), "--docs", "docs", "--batch", str(scene["batch"]), "--out-root", str(out_root)], check=True)
    dt = time.perf_counter() - t0
    cas = cas_stats()
    # copy trails viewer for convenience
    try:
        subprocess.run([sys.executable, "tools/trailview.py"], check=False)
    except Exception:
        pass
    # summarize
    summary = {
        "scene": scene["name"],
        "ticks": scene["ticks"],
        "batch": scene["batch"],
        "budget": scene["budget"],
        "max_vecs": scene["max_vecs"],
        "elapsed_sec": round(dt, 3),
        "cas_files": cas["files"],
        "cas_bytes": cas["bytes"],
    }
    (out_root/"summary.json").write_text(json.dumps(summary, indent=2), encoding='utf-8')
    return summary

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True)
    args = ap.parse_args()
    OUT = ROOT/'outputs/reports/scenarios'
    OUT.mkdir(parents=True, exist_ok=True)
    results=[]
    for sc in SCENES:
        res = run_scene(sc, args.zip)
        results.append(res)
    # write combined index
    idx = ["<html><head><meta charset='utf-8'><title>Scenario Results</title>",
           "<style>body{font-family:ui-sans-serif;margin:24px} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style>",
           "</head><body><h1>Scenario Results</h1>",
           "<table><tr><th>Scene</th><th>ticks</th><th>batch</th><th>e8_per_tick</th><th>elapsed(s)</th><th>CAS files</th><th>CAS MB</th><th>Open</th></tr>"]
    for res in results:
        name = res["scene"]
        scenepath = f"../{name}/index.html"
        idx.append(f"<tr><td>{name}</td><td>{res['ticks']}</td><td>{res['batch']}</td><td>{res['budget']['e8_per_tick']}</td><td>{res['elapsed_sec']}</td><td>{res['cas_files']}</td><td>{round(res['cas_bytes']/1_000_000,3)}</td><td><a href='../{name}/index.html'>dashboard</a></td></tr>")
    idx.append("</table></body></html>")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/"index.html").write_text("\n".join(idx), encoding='utf-8')
    print("WROTE", OUT/"index.html")

if __name__ == "__main__":
    main()
