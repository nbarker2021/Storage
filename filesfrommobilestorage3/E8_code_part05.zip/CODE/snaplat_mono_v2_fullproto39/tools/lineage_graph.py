#!/usr/bin/env python3
import sqlite3, json, pathlib, math, time
from kernel.authz import guard_rmi_read
from kernel.rmi_reads import lineage_edges

DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/lineage.html")

def fetch():
    if not guard_rmi_read(context={'script':'lineage_graph'}):
        return [], []
    rows = lineage_edges(); nodes=set(); edges=[]
    for r in rows:
        nodes.add(r['src_id']); nodes.add(r['dst_id']); edges.append((r['src_id'], r['dst_id'], r.get('weight',1)))
    return sorted(nodes), edges

def render(nodes, edges):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    N = max(1, len(nodes)); R = 200
    pos = {}
    for i,n in enumerate(nodes):
        ang = 2*math.pi*i/N
        pos[n] = (300 + R*math.cos(ang), 300 + R*math.sin(ang))
    svg = ["<html><head><meta charset='utf-8'><title>Lineage</title></head><body><nav style='padding:8px;background:#f0f0f0;border-bottom:1px solid #ddd'>
  <a href='topk.html'>Top‑K</a> |
  <a href='overlays.html'>Overlays</a> |
  <a href='lineage.html'>Lineage</a> |
  <a href='topk_history.html'>Top‑K History</a>
</nav>
"]
    svg.append(f"<h2>Lineage (generated {int(time.time())})</h2>")
    svg.append("<svg width='600' height='600' style='background:#fafafa;border:1px solid #ddd'>")
    # edges
    for s,d,w in edges:
        x1,y1 = pos.get(s,(0,0)); x2,y2 = pos.get(d,(0,0))
        svg.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='gray' stroke-width='{1+min(max(w,0.1),3)}' opacity='0.6' />")
    # nodes
    for n,(x,y) in pos.items():
        svg.append(f"<circle cx='{x}' cy='{y}' r='6' fill='#4682b4'/>")
        svg.append(f"<text x='{x+8}' y='{y+4}' font-size='10'>{n}</text>")
    svg.append("</svg></body></html>")
    OUT.write_text("\n".join(svg), encoding='utf-8')

if __name__ == "__main__":
    nodes, edges = fetch(); render(nodes, edges)
