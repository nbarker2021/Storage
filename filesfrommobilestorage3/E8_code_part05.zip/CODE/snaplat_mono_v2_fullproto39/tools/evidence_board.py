#!/usr/bin/env python3
import sqlite3, json, pathlib, time
from collections import defaultdict
from kernel.authz import guard_rmi_read

DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/evidence.html")

def fetch():
    if not guard_rmi_read(context={'script':'evidence_board'}):
        return []
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    rows = cur.execute("SELECT created_at, payload FROM trails WHERE kind='assembly.evaluate' ORDER BY created_at").fetchall()
    out = []
    for r in rows:
        try:
            p = json.loads(r['payload']) if isinstance(r['payload'], str) else r['payload']
        except Exception:
            p = {}
        out.append({"created_at": r["created_at"], **(p or {})})
    return out

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    # thresholds from safecube trail (latest)
    thr_edges, thr_oct = 3, 2
    # group by endpoint
    series = defaultdict(list)
    for r in rows:
        ep = r.get('endpoint_id','')
        e = r.get('evidence') or {}
        series[ep].append((r['created_at'], int(e.get('nodes',0)), int(e.get('edges',0)), int(bool(r.get('ready',False))), r.get('domain','')))
    # HTML
    html = ["<html><head><meta charset='utf-8'><title>Evidence Board</title><style>body{font-family:sans-serif} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style></head><body>"]
    html.append("<nav style='padding:8px;background:#f0f0f0;border-bottom:1px solid #ddd'>\n  <a href='topk.html'>Top-K</a> |\n  <a href='overlays.html'>Overlays</a> |\n  <a href='lineage.html'>Lineage</a> |\n  <a href='topk_history.html'>Top-K History</a> |\n  <a href='tt_asm.html'>TT/ASM</a> |\n  <a href='evidence.html'>Evidence</a>\n</nav>")
    html.append("<h2>Evidence Board</h2>")
    html.append("<table><tr><th>endpoint</th><th>domain</th><th>avg nodes</th><th>avg edges</th><th>ready%</th><th>edges sparkline</th></tr>")
    for ep, pts in series.items():
        if not ep: continue
        dom = pts[-1][4] if pts else ''
        avg_nodes = sum(p[1] for p in pts)/len(pts)
        avg_edges = sum(p[2] for p in pts)/len(pts)
        ready_pct = 100*sum(p[3] for p in pts)/len(pts)
        # sparkline SVG
        xs = list(range(len(pts)))
        ys = [p[2] for p in pts]
        w,h,pad = 120, 30, 2
        if ys:
            ymax = max(ys) or 1
            pts_svg = ' '.join(f"{pad + i*(w-2*pad)/max(1,len(xs)-1)},{h-pad - (v/ymax)*(h-2*pad)}" for i,v in enumerate(ys))
        else:
            pts_svg = ''
        spark = f"<svg width='{w}' height='{h}'><polyline fill='none' stroke='black' stroke-width='1' points='{pts_svg}'/></svg>"
        html.append(f"<tr><td>{ep}</td><td>{dom}</td><td>{avg_nodes:.1f}</td><td>{avg_edges:.1f}</td><td>{ready_pct:.0f}%</td><td>{spark}</td></tr>")
    html.append("</table></body></html>")
    OUT.write_text("\n".join(html), encoding='utf-8')

if __name__ == '__main__':
    render(fetch())
