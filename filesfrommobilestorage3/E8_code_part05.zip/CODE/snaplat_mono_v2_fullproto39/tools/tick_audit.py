#!/usr/bin/env python3
import pathlib, json, math, shutil, sys, os
sys.path.insert(0, os.getcwd())
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Dict, Any, List, Optional
import matplotlib.pyplot as plt

from triads.sap_snapops_archivist.snapops.runner_e8 import run_tick, RunConfig
from ecc.snap_e8 import SnapE8

ROOT = pathlib.Path(".")

@dataclass
class TickReport:
    t: int
    count: int
    deferred: int
    occ_top: List[tuple]
    distortion: Dict[str, float]
    kurtosis: Dict[str, float]
    scale: Optional[float]
    neighbor_hit: Optional[float]
    timing: Optional[Dict[str, float]]
    entropy: Optional[float]
    scale_eval: Optional[Dict[str, float]]

def _scan_cas_for_tick(t: int):
    cas_root = ROOT / "outputs" / "cas"
    cells=[]; dists=[]
    if not cas_root.exists():
        return [], []
    for p in cas_root.rglob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(obj, dict) and obj.get("tick") == t:
            cid = obj.get("cell_id")
            if cid: cells.append(cid)
            r = obj.get("residual")
            if isinstance(r, list):
                try:
                    d = math.sqrt(sum(float(x)*float(x) for x in r))
                    dists.append(d)
                except Exception:
                    pass
    return cells, dists

def _plot_hist(data, title, path):
    if not data:
        return
    plt.figure()
    plt.hist(data, bins=20)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(path)
    plt.close()

def _plot_bar(labels, values, title, path):
    if not values:
        return
    plt.figure()
    xs = list(range(len(values)))
    plt.bar(xs, values)
    # keep x labels minimal to avoid crowding
    plt.title(title)
    plt.tight_layout()
    plt.savefig(path)
    plt.close()

def _entropy(counts):
    s = float(sum(counts))
    if s <= 0: return 0.0
    H=0.0
    for c in counts:
        p = c/s
        if p>0:
            H -= p*math.log(p+1e-12)
    return H

def _neighbor_hit_ratio(t: int):
    bfile = ROOT/'outputs/state/batches'/f't={t:06d}.json'
    if not bfile.exists():
        return None
    obj = json.loads(bfile.read_text(encoding='utf-8'))
    vecs = obj.get('vectors', [])
    scale = obj.get('scale', 1.0)
    q = SnapE8(scale=scale)
    buckets = defaultdict(list)
    cids=[]
    for i,v in enumerate(vecs):
        cid,_ = q.encode(v)
        cids.append(cid)
        buckets[cid].append(i)
    import random
    idxs = list(range(len(vecs)))
    random.seed(0)
    idxs = idxs[: min(20, len(idxs))]
    hits=0; tot=0
    for i in idxs:
        cid = cids[i]
        nbrs = q.neighbors(cid, radius=1)
        cand = set(buckets.get(cid, []))
        for n in nbrs:
            cand |= set(buckets.get(n, []))
        cand.discard(i)
        tot += 1
        if cand:
            hits += 1
    return hits/float(tot) if tot>0 else None

def _micro_recall_ratio(t: int):
    # adjacent indices are pseudo-positives for sliding windows
    bfile = ROOT/'outputs/state/batches'/f't={t:06d}.json'
    if not bfile.exists():
        return None
    obj = json.loads(bfile.read_text(encoding='utf-8'))
    vecs = obj.get('vectors', [])
    scale = obj.get('scale', 1.0)
    q = SnapE8(scale=scale)
    cids = []
    for v in vecs:
        cid,_ = q.encode(v)
        cids.append(cid)
    hits=0; tot=0
    for i in range(len(vecs)-1):
        cid = cids[i]; nxt = cids[i+1]
        nbrs = q.neighbors(cid, radius=1)
        tot += 1
        if nxt == cid or nxt in nbrs:
            hits += 1
    return hits/float(tot) if tot>0 else None

def run_audit(ticks: int, docs: str, batch: int, out_root_override: str|None=None):
    out_root = pathlib.Path(out_root_override) if out_root_override else ROOT/'outputs'/'reports'/'ticks'
    out_root.mkdir(parents=True, exist_ok=True)
    cfg = RunConfig(docs_dir=docs, batch=batch)
    summary = []
    for i in range(ticks):
        res = run_tick(i, cfg)
        cells, dists = _scan_cas_for_tick(i)
        occ = Counter(cells)
        nh = _neighbor_hit_ratio(i)
        mr = _micro_recall_ratio(i)
        ent = _entropy([c for _,c in occ.most_common(999)])
        rep = TickReport(
            t=i,
            count=int(res.get("count", 0)),
            deferred=int(res.get("deferred", 0)),
            occ_top=occ.most_common(20),
            distortion={
                "n": len(dists),
                "mean": round(sum(dists)/len(dists), 6) if dists else 0.0,
                "max": round(max(dists), 6) if dists else 0.0
            },
            kurtosis=(res.get("kurtosis") or {"pre":0.0,"post":0.0}),
            scale=res.get("scale"),
            neighbor_hit=nh,
            timing=res.get("timing"),
            entropy=ent,
            scale_eval=res.get("scale_eval")
        )
        # write per-tick folder
        tdir = out_root/f"t={i:06d}"
        tdir.mkdir(parents=True, exist_ok=True)
        (tdir/"metrics.json").write_text(json.dumps(rep.__dict__, indent=2), encoding="utf-8")
        # plots
        _plot_hist(dists, f"Tick {i} Residual L2", tdir/"distortion_hist.png")
        if rep.occ_top:
            labels = [c for c,_ in rep.occ_top]
            counts = [c for _,c in rep.occ_top]
            _plot_bar(labels, counts, f"Tick {i} Top Cells", tdir/"top_cells.png")
        # html
        html = [
            "<html><head><meta charset='utf-8'><title>Tick Report</title>",
            "<style>body{font-family:ui-sans-serif;margin:24px} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style>",
            "</head><body>",
            f"<h1>Tick {i}</h1>",
            f"<pre>{json.dumps(rep.__dict__, indent=2)}</pre>",
        ]
        if (tdir/"distortion_hist.png").exists():
            html.append("<h3>Residual L2</h3><img src='distortion_hist.png' style='max-width:100%'>")
        if (tdir/"top_cells.png").exists():
            html.append("<h3>Top Cells</h3><img src='top_cells.png' style='max-width:100%'>")
        html.append("</body></html>")
        (tdir/"index.html").write_text("\n".join(html), encoding="utf-8")
        # snapshot
        snap = ROOT/'outputs'/'state'/'snapshots'/f"t={i:06d}"
        snap.mkdir(parents=True, exist_ok=True)
        clock = ROOT/'outputs'/'state'/'tick.json'
        if clock.exists():
            shutil.copy2(clock, snap/'tick.json')
        shutil.copy2(tdir/'metrics.json', snap/'metrics.json')
        summary.append(rep.__dict__)
    # master index
    idx = ["<html><head><meta charset='utf-8'><title>Tick Audit</title>",
           "<style>body{font-family:ui-sans-serif;margin:24px} a{color:#166}</style>",
           "</head><body>",
           f"<h1>Tick Audit ({ticks} ticks)</h1>",
           "<ul>"]
    for rep in summary:
        idx.append(f"<li><a href='t={rep['t']:06d}/index.html'>tick {rep['t']}</a> — count={rep['count']}  dist.mean={rep['distortion']['mean']}</li>")
    idx.append("</ul></body></html>")
    (out_root/"index.html").write_text("\n".join(idx), encoding="utf-8")
    print("WROTE", out_root/"index.html")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticks", type=int, default=3)
    ap.add_argument("--docs", default="docs")
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--out-root", default=None)
    args = ap.parse_args()
    run_audit(args.ticks, args.docs, args.batch, args.out_root)
