
#!/usr/bin/env python3
import re, json, time, pathlib, argparse
from kernel.telemetry import emit
from triads.sap_snapops_archivist.archivist.cas import put
from triads.sap_snapops_archivist.snapdna_v2 import encode_v2
from triads.agencies.queue import enqueue

ROLE_USER = "user"
ROLE_ASSISTANT = "assistant"

BLOCK_PATTERNS = [
    (re.compile(r"^\s*(you said|you:)\s*:?\s*$", re.IGNORECASE), ROLE_USER),
    (re.compile(r"^\s*(chat\s*gpt\s*said|chatgpt\s*said|assistant|ai:)\s*:?\s*$", re.IGNORECASE), ROLE_ASSISTANT),
]

FENCE = re.compile(r"^```(\w+)?\s*$")

def parse_blocks(txt: str):
    lines = txt.splitlines()
    blocks = []
    role = None
    buf = []
    def flush():
        nonlocal buf, role
        if role is not None and buf:
            blocks.append({"role": role, "text": "\n".join(buf).strip()})
            buf = []
    for line in lines:
        matched = False
        for pat, r in BLOCK_PATTERNS:
            if pat.match(line):
                flush(); role = r; matched = True; break
        if not matched:
            buf.append(line)
    flush()
    return blocks

def extract_code(text: str):
    # returns list of (lang, code), purely fence-based
    out = []
    lines = text.splitlines()
    in_code = False; lang = ""; buf = []
    for line in lines:
        m = FENCE.match(line)
        if m:
            if not in_code:
                in_code = True; lang = (m.group(1) or "").strip().lower(); buf = []
            else:
                out.append((lang or "text", "\n".join(buf)))
                in_code = False; lang = ""; buf = []
            continue
        if in_code:
            buf.append(line)
    # If file ended while still in code fence, flush
    if in_code and buf:
        out.append((lang or "text", "\n".join(buf)))
    return out

def ingest(path: str, domain: str = "governance", consent: bool = True, universe_id: str = "u1"):
    p = pathlib.Path(path)
    raw = p.read_text(encoding="utf-8", errors="ignore")
    blocks = parse_blocks(raw)
    emit("ingest.begin","ingest",{"path": str(p), "blocks": len(blocks)})
    count_turns = 0; count_codes = 0
    for i, b in enumerate(blocks):
        turn = {
            "kind": "conversation_turn",
            "role": b["role"],
            "text": b["text"],
            "turn_index": i,
            "source_path": str(p),
            "universe_id": universe_id,
            "domain": domain,
            "created_at": int(time.time()*1000)
        }
        dna = encode_v2(turn)
        cas = put(turn)
        emit("ingest.record","fixture",{"consent": bool(consent), "domain": domain, "cas": cas, "dna": dna.get("dna")})
        enqueue("conversation_turn", {"kind":"conversation_turn","endpoint_id":"ep-demo","universe_id":universe_id,"domain":domain, "cas": cas})
        count_turns += 1
        # code extraction
        for lang, code in extract_code(b["text"]):
            if not code.strip(): 
                continue
            code_snap = {
                "kind": "code_snippet",
                "language": lang,
                "text": code,
                "turn_index": i,
                "source_path": str(p),
                "universe_id": universe_id,
                "domain": domain,
                "created_at": int(time.time()*1000)
            }
            encode_v2(code_snap)
            ccas = put(code_snap)
            emit("ingest.record","fixture",{"consent": bool(consent), "domain": domain, "cas": ccas})
            enqueue("code_snippet", {"kind":"code_snippet","endpoint_id":"ep-demo","universe_id":universe_id,"domain":domain, "cas": ccas})
            count_codes += 1
    emit("ingest.end","ingest",{"path": str(p), "turns": count_turns, "codes": count_codes})
    return {"turns": count_turns, "codes": count_codes}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True, help="Path to log file to ingest")
    ap.add_argument("--domain", default="governance")
    ap.add_argument("--consent", type=int, default=1, help="1 = consent true, 0 = false")
    args = ap.parse_args()
    res = ingest(args.file, args.domain, bool(args.consent))
    print(json.dumps(res))

if __name__ == "__main__":
    main()
