
#!/usr/bin/env python3
import os, json, shutil, time, pathlib, subprocess, sys
from pathlib import Path

ROOT = Path(".")

POLICIES = [
    {"name":"stretch", "budget":{"e8_per_tick":256,"policy":"stretch","max_carry_ticks":10}},
    {"name":"skip",    "budget":{"e8_per_tick":256,"policy":"skip","max_carry_ticks":2}},
]

def patch_budgets(b):
    p = ROOT/'triads/sap_snapops_archivist/snapops/budgets.py'
    txt = p.read_text(encoding='utf-8')
    import re
    txt = re.sub(r'"e8_per_tick":\s*\d+', f'"e8_per_tick": {b["e8_per_tick"]}', txt)
    txt = re.sub(r'"policy":\s*"(stretch|skip)"', f'"policy": "{b["policy"]}"', txt)
    txt = re.sub(r'"max_carry_ticks":\s*\d+', f'"max_carry_ticks": {b["max_carry_ticks"]}', txt)
    p.write_text(txt, encoding='utf-8')

def clear_outputs():
    for d in ['outputs/cas','outputs/trails','outputs/state/batches','outputs/state/snapshots']:
        dp = ROOT/d
        if dp.exists():
            shutil.rmtree(dp)

def seed(zip_path):
    subprocess.run([sys.executable, "tools/seed_backlog_from_zip.py", zip_path], check=True)

def run_policy(pol, zip_path, ticks=6, batch=256):
    clear_outputs()
    seed(zip_path)
    patch_budgets(pol["budget"])
    out_root = ROOT/f"outputs/reports/policy_{pol['name']}"
    subprocess.run([sys.executable, "tools/tick_audit.py", "--ticks", str(ticks), "--docs", "docs", "--batch", str(batch), "--out-root", str(out_root)], check=True)
    # summarize from per-tick metrics
    mets=[]
    for p in sorted(out_root.glob("t=*/metrics.json")):
        mets.append(json.loads(p.read_text(encoding="utf-8")))
    def seq(field, sub=None):
        arr=[]
        for m in mets:
            v = m.get(field)
            if sub and isinstance(v, dict):
                v = v.get(sub)
            arr.append(v)
        return arr
    summary = {
        "policy": pol["name"],
        "counts": seq("count"),
        "deferred": seq("deferred"),
        "dist_mean": [m.get("distortion",{}).get("mean") for m in mets],
        "nhit": [m.get("neighbor_hit") for m in mets],
        "kurt_pre": [m.get("kurtosis",{}).get("pre") for m in mets],
        "kurt_post": [m.get("kurtosis",{}).get("post") for m in mets],
    }
    (out_root/"summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return out_root

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True)
    args = ap.parse_args()
    roots=[]
    for pol in POLICIES:
        roots.append(run_policy(pol, args.zip))
    # Build compare page
    out = ROOT/"outputs/reports/policy_ab"
    out.mkdir(parents=True, exist_ok=True)
    html = ["<html><head><meta charset='utf-8'><title>Policy A/B</title>",
            "<style>body{font-family:ui-sans-serif;margin:24px}</style>",
            "</head><body><h1>Policy A/B</h1>"]
    for r in roots:
        html.append(f"<h2>{r.name}</h2><p><a href='../{r.name}/index.html'>dashboard</a></p>")
    (out/"index.html").write_text("\n".join(html), encoding="utf-8")
    print("WROTE", out/"index.html")

if __name__ == "__main__":
    main()
