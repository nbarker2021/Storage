#!/usr/bin/env python3
import zipfile, pathlib, re, json, sys, os
sys.path.insert(0, os.getcwd())

def strip_html(t: str) -> str:
    t = re.sub(r"<script[\s\S]*?</script>", " ", t, flags=re.I)
    t = re.sub(r"<style[\s\S]*?</style>", " ", t, flags=re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    return re.sub(r"\s+", " ", t)

def read_text_from_zip(z: zipfile.ZipFile, name: str) -> str:
    data = z.read(name)
    # direct text try
    for enc in ("utf-8", "latin-1"):
        try:
            txt = data.decode(enc)
            if name.lower().endswith((".html",".htm",".xhtml")):
                txt = strip_html(txt)
            return txt
        except Exception:
            continue
    return ""

from triads.pipelines.vec8 import hashed_vec8

def toy_vec8_from_text(text: str):
    import re
    toks = re.findall(r"[a-z0-9]+", text.lower())
    # sliding windows of 32 tokens; vector dims = lengths of first 8 tokens in window
    vecs=[]
    W=48; S=8
    for i in range(0, max(0, len(toks)-W+1), S):
        window = toks[i:i+W]
        dims = [float(len(t)) for t in window[:8]]
        if len(dims) < 8:
            dims += [0.0]*(8-len(dims))
        vecs.append(dims)
        if len(vecs) >= 8000:   # cap for session
            break
    return vecs

def main():
    if len(sys.argv) < 2:
        print("usage: seed_backlog_from_zip.py <zipfile>")
        sys.exit(2)
    zip_path = sys.argv[1]
    out = pathlib.Path("outputs/state/queues/e8_backlog.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        best_name = None; best_len = 0; best_text = ""
        for name in z.namelist():
            if name.endswith("/"): continue
            if name.lower().endswith((".png",".jpg",".jpeg",".gif",".pdf",".mp3",".mp4",".mov",".zip",".gz",".tar",".rar",".7z",".exe",".dll",".so",".bin",".class",".jar",".ico",".woff",".ttf",".otf")):
                continue
            t = read_text_from_zip(z, name)
            L = len(t)
            if L > best_len:
                best_name, best_len, best_text = name, L, t
        if not best_name:
            print("no suitable text file found"); sys.exit(3)
        vecs = toy_vec8_from_text(best_text)
        q = {"vectors": vecs, "created_tick": 0, "meta": {"source_zip": zip_path, "file": best_name, "text_len": best_len, "vecs": len(vecs)}}
        out.write_text(json.dumps(q), encoding="utf-8")
        print("Seeded backlog from", best_name, "text_len", best_len, "vecs", len(vecs))

if __name__ == "__main__":
    main()
