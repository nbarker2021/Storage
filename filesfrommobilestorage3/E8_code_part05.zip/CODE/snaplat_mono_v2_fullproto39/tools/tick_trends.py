
#!/usr/bin/env python3
import json, pathlib, math
import matplotlib.pyplot as plt

ROOT = pathlib.Path("outputs/reports/ticks")

def load():
    rows=[]
    for p in sorted(ROOT.glob("t=*/metrics.json")):
        t = int(p.parent.name.split("=")[1])
        m = json.loads(p.read_text(encoding="utf-8"))
        rows.append({"t": t,
                     "count": m.get("count",0),
                     "deferred": m.get("deferred",0),
                     "dist_mean": m.get("distortion",{}).get("mean"),
                     "dist_max": m.get("distortion",{}).get("max"),
                     "k_pre": m.get("kurtosis",{}).get("pre"),
                     "k_post": m.get("kurtosis",{}).get("post"),
                     "occ_top": m.get("occ_top", [])})
    return rows

def entropy(counts):
    s = sum(counts)
    if s <= 0: return 0.0
    import math
    H = 0.0
    for c in counts:
        p = c/s
        if p>0:
            H -= p*math.log(p+1e-12)
    return H

def main():
    rows = load()
    if not rows:
        print("no tick metrics found"); return
    # plots dir
    out = ROOT / "trends"
    out.mkdir(parents=True, exist_ok=True)

    # Series
    ts = [r["t"] for r in rows]
    counts = [r["count"] for r in rows]
    deferred = [r["deferred"] for r in rows]
    dmean = [r["dist_mean"] for r in rows]
    dmax  = [r["dist_max"] for r in rows]
    kpre  = [r["k_pre"] for r in rows]
    kpost = [r["k_post"] for r in rows]
    ent   = [entropy([c for _,c in r["occ_top"]]) for r in rows]

    # Plot helpers (no styles/colors set)
    def line(xs, ys, title, fname, ylabel=None):
        plt.figure()
        plt.plot(xs, ys, marker="o")
        if ylabel: plt.ylabel(ylabel)
        plt.title(title)
        plt.xlabel("tick")
        plt.tight_layout()
        plt.savefig(out/fname)
        plt.close()

    line(ts, counts, "Processed per tick", "counts.png", "count")
    line(ts, deferred, "Deferred backlog per tick", "deferred.png", "deferred")
    line(ts, dmean, "Residual L2 mean per tick", "dist_mean.png", "mean L2")
    line(ts, dmax,  "Residual L2 max per tick", "dist_max.png", "max L2")
    line(ts, kpre,  "Kurtosis pre-whitening per tick", "kurtosis_pre.png", "excess kurtosis")
    line(ts, kpost, "Kurtosis post-whitening per tick", "kurtosis_post.png", "excess kurtosis")
    line(ts, ent,   "Occupancy entropy per tick", "entropy.png", "H (nats)")

    # Build an HTML
    html = ["<html><head><meta charset='utf-8'><title>Tick Trends</title>",
            "<style>body{font-family:ui-sans-serif;margin:24px} img{max-width:100%}</style>",
            "</head><body>",
            "<h1>Tick Trends</h1>"]
    for f in ["counts.png","deferred.png","dist_mean.png","dist_max.png","kurtosis_pre.png","kurtosis_post.png","entropy.png"]:
        html.append(f"<h2>{f.replace('.png','').replace('_',' ').title()}</h2><img src='{f}'>")
    html.append("</body></html>")
    (out/"index.html").write_text("\n".join(html), encoding="utf-8")
    print("WROTE", out/"index.html")

if __name__ == "__main__":
    main()
