import subprocess, json, pathlib
import policy.safecube as sc

def _seed():
    subprocess.check_call(['python','tools/seed_fixture_db.py'])

def test_phi_masking_required(monkeypatch):
    _seed()
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_phi_unmasked.json'])
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epH","evidence":{"edges":2},"domain":"healthcare"})
    assert not ok

def test_phi_masking_ok(monkeypatch):
    _seed()
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_phi_masked.json'])
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epH2","evidence":{"edges":2},"domain":"healthcare"})
    assert ok

def test_finance_pan_cvv_blocks(monkeypatch):
    _seed()
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_pan_cvv.json'])
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epF","evidence":{"edges":2},"domain":"finance"})
    assert not ok

def test_finance_token_ok(monkeypatch):
    _seed()
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_fin_ok.json'])
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epF2","evidence":{"edges":2},"domain":"finance"})
    assert ok

def test_education_pseudonymization(monkeypatch):
    _seed()
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_edu_bad.json'])
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epE","evidence":{"edges":2},"domain":"education"})
    assert not ok
    _seed()
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_edu_ok.json'])
    ok, details = sc.assess({"endpoint_id":"epE2","evidence":{"edges":2},"domain":"education"})
    assert ok
