
import json, hashlib, os
try:
    from cryptography.hazmat.primitives.asymmetric import ed25519 as _ed
    from cryptography.hazmat.primitives import serialization as _ser
    _CRYPTO = "cryptography"
except Exception:
    _CRYPTO = None

DEFAULT_PEM = "security/signer_demo.pem"

def _read_file(path):
    try:
        return open(path, "rb").read()
    except FileNotFoundError:
        return None

def load_keypair(pem_path=DEFAULT_PEM):
    env = os.getenv("SNAPLAT_CRYPTO","").strip().lower()
    prefer_ed = env in ("ed25519","ed","crypto")
    raw = _read_file(pem_path)
    if _CRYPTO and raw and prefer_ed:
        try:
            priv = _ser.load_pem_private_key(raw, password=None)
            if not isinstance(priv, _ed.Ed25519PrivateKey):
                seed = hashlib.blake2b(raw, digest_size=32).digest()
                priv = _ed.Ed25519PrivateKey.from_private_bytes(seed)
            pub = priv.public_key()
            kid = pub.public_bytes(encoding=_ser.Encoding.Raw, format=_ser.PublicFormat.Raw).hex()[:16]
            return {"mode": "ed25519-cryptography", "pub": pub, "priv": priv, "kid": kid}
        except Exception:
            pass
    secret = raw or b"DEMO_FALLBACK_SECRET"
    pub = hashlib.blake2b(secret, digest_size=16).hexdigest()
    return {"mode": "fallback-hmac", "pub": pub, "priv": secret, "kid": pub[:16]}

def _json_bytes(payload):
    return json.dumps(payload, sort_keys=True).encode("utf-8")

def sign(payload, keypair=None):
    keypair = keypair or load_keypair()
    msg = _json_bytes({k:v for k,v in payload.items() if k != "signature"})
    if keypair["mode"].startswith("ed25519"):
        return keypair["priv"].sign(msg).hex()
    return hashlib.blake2b((keypair["priv"] or b"") + msg, digest_size=32).hexdigest()

def verify(payload, sig, keypair=None):
    keypair = keypair or load_keypair()
    msg = _json_bytes({k:v for k,v in payload.items() if k != "signature"})
    if keypair["mode"].startswith("ed25519"):
        try:
            keypair["pub"].verify(bytes.fromhex(sig), msg); return True
        except Exception:
            return False
    return hashlib.blake2b((keypair["priv"] or b"") + msg, digest_size=32).hexdigest() == sig

def pub_fingerprint(keypair=None):
    from hashlib import blake2b
    kp = keypair or load_keypair()
    if kp["mode"].startswith("ed25519"):
        try:
            raw = kp["pub"].public_bytes(encoding=_ser.Encoding.Raw, format=_ser.PublicFormat.Raw)
        except Exception:
            raw = repr(kp["pub"]).encode("utf-8")
        return blake2b(raw, digest_size=8).hexdigest()
    return str(kp["pub"])

def mode():
    env = os.getenv("SNAPLAT_CRYPTO","").strip().lower()
    if env in ("ed25519","ed","crypto") and _CRYPTO: return "ed25519-cryptography"
    return "fallback-hmac"

def key_id():
    return load_keypair().get("kid","<none>")
