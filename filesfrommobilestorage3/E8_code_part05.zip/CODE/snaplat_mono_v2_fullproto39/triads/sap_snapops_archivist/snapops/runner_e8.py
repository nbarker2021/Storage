from dataclasses import dataclass
from typing import Dict, Any, List
from kernel.telemetry import emit
from kernel.tick import begin_tick
from triads.sap_snapops_archivist.snapops import budgets as B, env as E
from triads.pipelines.e8_source import vectors_from_docs
import json, pathlib, time
from typing import List

def _sanitize_vecs(vecs: List[List[float]]) -> List[List[float]]:
    out=[]
    for v in vecs:
        if not isinstance(v, list):
            continue
        if len(v) != 8:
            continue
        try:
            out.append([float(x) for x in v])
        except Exception:
            continue
    return out

import triads.agencies.e8_quant  # ensure registration
from triads.agencies.core import Job, get

QUEUE = pathlib.Path("outputs/state/queues/e8_backlog.json")

def _q_load():
    if not QUEUE.exists():
        return {"vectors": [], "created_tick": None, "meta": {}}
    try:
        return json.loads(QUEUE.read_text(encoding="utf-8"))
    except Exception:
        return {"vectors": [], "created_tick": None, "meta": {}}

def _q_save(obj):
    QUEUE.parent.mkdir(parents=True, exist_ok=True)
    QUEUE.write_text(json.dumps(obj), encoding="utf-8")

@dataclass
class RunConfig:
    docs_dir: str
    batch: int = 16
    use_backlog: bool = True

def run_tick(t: int, cfg: RunConfig) -> Dict[str, Any]:
    budget = B.for_tick(t)
    _env = E.build(t, seed=0)
    emit("tick.start", "runner_e8", {"t": t, "budget": budget})

    # Backlog: seed once if enabled and empty
    q = _q_load()
    if cfg.use_backlog and not q["vectors"]:
        seed = vectors_from_docs(cfg.docs_dir, limit=None)
        q = {"vectors": seed, "created_tick": t, "meta": {"docs_dir": cfg.docs_dir, "seed_count": len(seed)}}
        _q_save(q)

    allowed = int(budget.get("e8_per_tick", cfg.batch))
    have = len(q["vectors"])
    take = min(allowed, have) if have else 0
    vecs: List[List[float]] = _sanitize_vecs(q["vectors"][:take])
    q["vectors"] = q["vectors"][take:]
    _q_save(q)

    agency = get("e8_quant")
    res = agency.run(Job(kind="quantize", payload={"vectors": vecs, "tick": t, "scale_grid": [0.5,0.75,1.0,1.5,2.0,3.0]}, created_at=0))
    deferred = len(q["vectors"])
    # save batch for audit
    bd = pathlib.Path('outputs/state/batches'); bd.mkdir(parents=True, exist_ok=True)
    (bd/f't={t:06d}.json').write_text(json.dumps({"tick": t, "vectors": vecs, "scale": res.get("scale")}, indent=2), encoding='utf-8')

    # policy: skip if too old
    if deferred and budget.get("policy") == "skip":
        age = t - (q.get("created_tick") or t)
        if age > int(budget.get("max_carry_ticks", 10)):
            q["vectors"] = []
            _q_save(q)
            emit("tick.policy", "runner_e8", {"t": t, "action": "drop_backlog", "age": age})
            deferred = 0

    emit("tick.e8", "runner_e8", {"t": t, "tick": t, "count": res.get("count", 0), "deferred": deferred, "kurtosis": res.get("kurtosis"), "timing": res.get("timing")})
    return {"t": t, "status": "OK" if res.get("ok") else "FAIL", "count": res.get("count", 0), "deferred": deferred, "kurtosis": res.get("kurtosis"), "scale": res.get("scale"), "timing": res.get("timing"), "scale_eval": res.get("scale_eval")}
