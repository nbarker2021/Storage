from dataclasses import dataclass
from typing import List, Dict, Any
import time
from .core import Agency, Job, register
from kernel.telemetry import emit
from triads.sap_snapops_archivist.archivist.cas import put
from ecc.snap_e8 import SnapE8
from ecc import whiten
from triads.pipelines.scale_tune import choose_scale

@dataclass
class E8QuantizeAgency(Agency):
    name: str = "e8_quant"
    scale: float = 1.0

    def run(self, job: Job) -> dict:
        payload = job.payload or {}
        vecs: List[List[float]] = payload.get("vectors", [])
        if not vecs:
            return {"ok": False, "error": "no vectors", "count": 0}

        # ---- Scale selection ----
        scale = None
        eval_grid = None
        grid = payload.get("scale_grid")
        if isinstance(grid, (list, tuple)) and grid:
            eval_grid = {}
            for s in grid:
                qtmp = SnapE8(scale=float(s))
                total = 0.0
                for v in vecs[: min(64, len(vecs))]:
                    _, resid = qtmp.encode(v)
                    total += sum(r*r for r in resid)
                eval_grid[float(s)] = total / max(1, min(64, len(vecs)))
            # pick lowest loss
            scale = min(eval_grid, key=lambda k: eval_grid[k])
        else:
            scale = choose_scale(vecs, candidate_scales=(0.5, 1.0, 2.0), sample=min(64, len(vecs)))

        q = SnapE8(scale=scale, pre=whiten.pre_hadamard)

        # ---- Stats before/after whitening ----
        flat = [x for v in vecs for x in v]
        k_pre = whiten.kurtosis(flat) if flat else 0.0
        wvecs = [q.pre(v) if q.pre else v for v in vecs]
        flat_w = [x for v in wvecs for x in v]
        k_post = whiten.kurtosis(flat_w) if flat_w else 0.0

        # ---- Encode timing ----
        t0 = time.perf_counter()
        out = q.encode_batch(vecs)
        t1 = time.perf_counter()

        # ---- CAS write timing ----
        hashes = []
        t2a = time.perf_counter()
        for rec in out:
            try:
                h = put({ "cell_id": rec["cell_id"], "residual": rec["residual"], "tick": payload.get("tick") })
                hashes.append(h)
            except Exception as e:
                emit("e8.cas_error", "agency", {"err": str(e)})
        t2b = time.perf_counter()

        timing = {
            "encode_ms": round((t1 - t0) * 1000.0, 3),
            "cas_ms": round((t2b - t2a) * 1000.0, 3),
            "per_vec_ms": round(((t1 - t0) + (t2b - t2a)) * 1000.0 / max(1, len(out)), 4)
        }

        emit("e8.quantized", "agency", {
            "count": len(out),
            "tick": payload.get("tick"),
            "kurtosis": {"pre": k_pre, "post": k_post},
            "scale": scale,
            "timing": timing,
            "scale_eval": eval_grid
        })

        return {
            "ok": True,
            "count": len(out),
            "cas": hashes,
            "kurtosis": {"pre": k_pre, "post": k_post},
            "scale": scale,
            "timing": timing,
            "scale_eval": eval_grid
        }

# register on import
register(E8QuantizeAgency())
