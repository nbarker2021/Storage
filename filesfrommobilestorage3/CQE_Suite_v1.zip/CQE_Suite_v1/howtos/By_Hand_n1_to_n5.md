# By-Hand Falsifier: n=1 → n=5 with paper & grids

**You need**
- Graph paper, two markers (two colors), and a ruler.

**Grid**
- Draw a 4×4 grid. Mark top/bottom rows as “mirrors.”

**Rules (plain)**
- A “move” must keep mirror symmetry. If a choice breaks symmetry and another fixes it, pick the fix.
- A step “latches” a face when your marking touches that border legally. You need all 8 latches once per cycle to “advance.”
- Keep a simple ledger: step#, what you drew, which faces latched.

**n=4 (the rest)**
1. Place “1” along the center. Balance with its mirror.
2. Add “2” where it raises overlap *and* keeps the picture palindromic. If not, undo and try the symmetric slot.
3. Do the same for “3” and “4.”
4. You’ll land on a mirror-locked picture (your “rest”). If you repeat the process, nothing changes (idempotent).

**n=5 (why 8 classes are forced)**
1. On a fresh copy of your n=4 rest, try inserting “5” at each of the 16 cells (one per page).
2. Each time, first fix symmetry locally. If you can’t make it symmetric without breaking elsewhere, mark that page as “illegal.”
3. Group the legal pages by obvious rotations/reflections (they look the same under turning/flipping with colors).
4. You will have **eight** distinct looks left. One of them becomes palindromic after cleanup; the other seven stabilize as non‑palindromic but balanced patterns.

**What you’ve shown**
- n=4 collapses to a single palindromic rest (up to turning/flipping).
- To extend to n=5 legally, you need exactly 8 different insert “types.”
- That’s the octad—the reason we use 8 faces later.
