# Scratchpad HQ (no-code mental model)

- Think of a **ring of checkpoints** (8 faces). You can move your drawing anywhere, but you only “advance” after each checkpoint has been touched once.
- The **rest** is your clean, symmetric sketch that nothing can improve locally.
- A **delta** is any change you add; only keep it if it still lets you touch all 8 checkpoints in a full lap.
- If a change can’t fit this lap, don’t throw it away—start a **new loop** for it and keep going.
- Only stop when nothing changes after a full lap—then you write the ledger row.
