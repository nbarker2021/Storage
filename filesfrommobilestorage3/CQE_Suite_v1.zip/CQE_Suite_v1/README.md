# CQE Suite v1

**Build timestamp:** 2025-09-17T17:14:47.967842Z

This bundle packages the legality-first, geometry-based architecture we developed in this session into a shippable set:

- **papers/** spec & theory (Math spine, Torus engine, Dyadic rests, Overlay/Return, API, falsifiers, public research)
- **howtos/** notebook-and-graph style by-hand guides (no jargon)
- **examples/** small artifacts (sample ledger, acceptance tests CSV/JSONL)
- **api/** OpenAPI stub + payload examples
- **schemas/** JSON Schemas for ledger/anchors/loop proposals
- **legal/** license & provenance scaffolding
- **manifests/** manifest + changelog
- **data/** session embedding sample (helix10_embedding.csv if present)
- **scripts/** Makefile for Pandoc PDF build and a tiny toy generator (optional)

**Key policy defaults**
- Epsilon: `ε = 1e-6` (normalized face scale)
- Verdicts: `REST`, `ACTION`, `LOOP_NEEDED`, `OUT_OF_SCOPE`, `SECURITY_REJECT`
- Reject policy: No semantic hard-fails; semantic “no” → `LOOP_NEEDED` with a loop proposal. Integrity/auth → `SECURITY_REJECT`.
- Public research: Allowed via **LFAI Research License v1** (non-commercial), with C2PA/JWS provenance.

**One-line intuition**: *Declare dyadic rests (2/4/8/16/64), keep the Monster-managed Leech carrier fixed, treat everything else as labeled deltas. All-8 Gate enforces cadence. Identity is anchors + legality proofs—no recall, just context motion.*
