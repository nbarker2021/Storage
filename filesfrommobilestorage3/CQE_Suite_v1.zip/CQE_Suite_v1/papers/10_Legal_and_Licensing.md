# Legal & Licensing (scaffold)

- Include LICENSE.txt, NOTICE.txt, PERMISSION_NOTICE_TEMPLATE.md, LICENSING_ENFORCEMENT.md
- Patent strategy: umbrella + continuations covering Rest⊕Δ loop, All-8 Gate, Dyadic rests, Even-Lift discipline, Tuple→CRT selector, Anchors (no recall), Verdict model.
- Contributor terms: research-only patent grant, CLA for inbound rights.
