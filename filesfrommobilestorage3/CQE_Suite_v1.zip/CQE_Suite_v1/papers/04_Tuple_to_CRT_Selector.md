# Tuple→CRT Selector & Overlay Families

**Selector (tuple size n):**
1. Keep Leech carrier fixed.
2. Add q‑ary ConA layers per factor of n (include mod‑13 for screw nativity).
3. Glue by CRT to a single modulus.
4. If odd lift appears, apply even‑neighbor (Return) to Type‑II.
5. Intersect allowed set with 10‑D stage; pick pitch; preserve mirror pairing.

**Overlays (labeled deltas):**
- P (parity façade / Type‑I): overlay‑only; must Return before dynamics.
- M (modulus/CRT): q‑ary constraints; legal if even after Return.
- S (symmetry): 13A↔13B slice; commuting elements.
- H (Moonshine): choice/normalization of envelope.
- G (gating): chamber windows, witness policy.
- N (embedding): Niemeier/E₈ classifiers; read‑only until Return.
