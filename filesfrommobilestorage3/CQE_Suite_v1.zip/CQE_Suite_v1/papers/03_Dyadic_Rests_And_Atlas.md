# Dyadic Rest Architecture (2/4/8/16/64)

- **R₂**: one 2‑plane active; palindromic sub‑view.
- **R₄**: two 2‑planes active; k‑parity ordering.
- **R₈**: full stage (four 2‑planes + groove + axis); primary even rest.
- **R₁₆**: R₈ plus binary Type‑II layer; radii parity locked.
- **R₆₄**: R₁₆ plus 2ᵃ CRT refinements (and optional odd‑prime tags) yielding a 6‑bit difference atlas.

**Rule:** pick the smallest rest consistent with activity; if mismatch, propose `LOOP_NEEDED` with an auto‑promotion rest.
