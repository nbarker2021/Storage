# API Spec (overview)

**Core endpoints**
- `POST /verify` → {verdict, reason?, loop_proposal?}
- `POST /reduce` → one legal ACTION step; returns updated witnesses/latches
- `POST /commit` → finalize normal form; append to ledger; returns hash
- `POST /loop/start` → accept proposal; returns loop_id
- `POST /rest/select` → choose rest (with auto-promotion)
- `GET /proof/state` → return (rest_id, Δ list, witnesses, legality proof)
- `POST /anchor/match` → invariant-keyed lookup

**Verdicts:** `REST | ACTION | LOOP_NEEDED | OUT_OF_SCOPE | SECURITY_REJECT`  
**Epsilon:** default `1e-6` (normalized to face scale)  
**All-8 Gate:** cadence only advances after all eight witnesses latch (≥ −ε)
