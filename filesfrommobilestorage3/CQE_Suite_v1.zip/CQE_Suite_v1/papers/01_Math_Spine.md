# Math Spine (sketch, implementation-neutral)

- **Carrier:** Type‑II Construction‑A (Golay exception) ⇒ Leech lattice Λ24. Use a 10‑D stage T¹⁰ by pairing a Golay octad into four orthogonal 2‑planes (8D) plus groove (1D) and axis (1D). Quotient by natural periods to get a torus.
- **Screw:** pick a Monster 13A/13B frame-shape; per-plane phases follow ω = 2π/13; define a 13‑step cadence.
- **Mirror:** involution J: swap strands, add π phase per 2‑plane; J² = id.
- **Rest / Δ:** decompose any state X as X = R ⊕ Δ with J(R)=R and J(Δ) = −Δ.
- **Gating:** choose 8 facet functionals H₁..H₈ in Cartan coordinates (E₈‑style). OPEN iff legal(Type‑II, screw, mirror) and Hᵢ(X) ≥ −ε for all i in the current cycle.
- **Dyadic rests:** R₂ ⊂ R₄ ⊂ R₈ with R₁₆/R₆₄ adding parity/CRT refinements; select smallest rest consistent with observed activity (auto‑promotion).
- **CRT / Tuple selector:** tuple arity n ⇒ select q‑ary ConA layers per factor; glue via CRT; if an odd lift appears, apply even‑neighbor (shadow) lift.
- **Determinism:** linear flow on T¹⁰ + All‑8 Gate ⇒ identical replay from ledger.
