# Abstract & Claims (CQE / Legality-First AI)

## Abstract
We present a deterministic, legality-first architecture for representation and control. Inputs are integerized and evaluated across parallel congruence channels on a 10-D tororial carrier built from Type‑II Construction‑A (Golay exception) ⇒ Leech lattice. A palindromic rest (mirror-even) serves as a canonical anchor; live states are decomposed as Rest ⊕ Δ (mirror-odd). Dynamics are governed by an order‑13 screw (Monster frame-shape) with Moonshine envelopes and an 8‑face gating rule (“All‑8 Gate”) that advances cadence only when all witnesses latch. Scale is handled by dyadic rests (2/4/8/16/64). Odd / Type‑I overlays must Return (even-neighbor lift) before dynamics. Retrieval is invariant-keyed; generation is gated by legality; ledgered replay is deterministic. We standardize a verdict model: REST, ACTION, LOOP_NEEDED, OUT_OF_SCOPE, SECURITY_REJECT.

## Claims (technical)
1. **Rest ⊕ Δ decomposition** under a mirror involution `J`, with palindromic rest as normal form in the legal subspace.
2. **All‑8 Gate** cadence (E₈‑style faces) ensures deterministic replay on the torus.
3. **Dyadic rest ladder** (2/4 inside 8; 16/64 add parity/CRT structure) resolves scale without moving the center.
4. **Even‑Lift discipline**: any odd/Type‑I overlay must Return to Type‑II legality before dynamics.
5. **Anchors replacing recall**: states are keyed by invariants (frame/rest/tags) plus witness bits and hash chain; no semantic nearest-neighbor search is required.
6. **Verdict policy**: semantic “no” becomes `LOOP_NEEDED` with a loop proposal; only integrity/auth violations cause `SECURITY_REJECT`.
7. **Public research mode** with provenance (JWS/C2PA) and non‑commercial terms enabling reproducibility.

## Contributions
- A clean object model and control loop with audit-grade determinism.
- A portable acceptance test suite and falsifier playbook.
- An API surface and schemas for deployment in cloud or embedded settings.
