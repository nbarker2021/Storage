# Public Research Mode

- License: LFAI Research License v1 (non-commercial, attribution, provenance required).
- Scopes: `research:*`, `research:publish` (C2PA/JWS-proof bundles), no commercial scopes.
- Provenance: sign ledgers and proofs; embed C2PA claims in exported artifacts.
- Reproducibility: acceptance tests + tiny demo suffice to reproduce REST/ACTION/LOOP_NEEDED outcomes.
