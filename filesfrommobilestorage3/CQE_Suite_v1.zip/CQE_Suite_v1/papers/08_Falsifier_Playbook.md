# Falsifier Playbook (spec-level)

F1 Bad ConA seed → LOOP_NEEDED {Return:"even_lift_needed"} or SECURITY_REJECT if tamper.
F2 Latch disabled → Stall (no advance). Expected behavior: cadence does not advance.
F3 13A/13B mismatch → LOOP_NEEDED {screw_class:"13B"}.
F4 Odd overlay used → auto-Return or LOOP_NEEDED {Return:"even_neighbor"}.
F5 ε=0 → LOOP_NEEDED {epsilon: 1e-6}.
F6 CRT inconsistent → LOOP_NEEDED {resync:true} (auth OK) or SECURITY_REJECT (auth fail).
F7 Rest too small → LOOP_NEEDED {rest:"R8"}.
F8 Mirror not involutive → LOOP_NEEDED {fix:"mirror_phase_pi"}.
F9 Pulse without All-8 → LOOP_NEEDED {replay_from_last_all8:true}.
F10 Rehydration hash mismatch → SECURITY_REJECT.
