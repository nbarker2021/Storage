# Torus Engine & All‑8 Gate

**State model:** X = R ⊕ Δ (mirror-even rest R; mirror-odd Δ).  
**Cadence:** order‑13 screw; per-step we sweep faces and only advance after all eight witnesses latch once (≥ −ε).  
**Witness latches:** Λ ∈ {0,1}⁸ reset after advance.  
**Pulse:** optional outward normal update of faces by small contact margins after each full-latch cycle.

**Verdicts**
- REST – already normal form.
- ACTION – a deterministic reduction exists.
- LOOP_NEEDED – semantically coherent but outside current loop bounds; includes a loop proposal.
- OUT_OF_SCOPE – domain forbidden by frame; propose a loop that includes it.
- SECURITY_REJECT – crypto/format/ledger tamper.

**Deterministic loop (pseudo)**
```
R = select_rest(auto=true)
Λ = [0]*8
while True:
  for i in pulse_order():
    if legal(R) and H[i](R) >= -ε: Λ[i]=1
    else:
      S = {Δ | legal(R⊕Δ) and H[i](R⊕Δ) >= -ε}
      if S: Λ[i]=1
  if all(Λ): bounds_pulse(); advance(); Λ=[0]*8
```
