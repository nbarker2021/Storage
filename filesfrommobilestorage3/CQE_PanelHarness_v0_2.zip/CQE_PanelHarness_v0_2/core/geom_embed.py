
import math, hashlib

def bytes_to_float01(b):
    return int.from_bytes(b, "big") / (256**len(b)-1)

def sha256_bytes(x: bytes):
    return hashlib.sha256(x).digest()

def embed_hash_to_8d(seed: bytes):
    h = sha256_bytes(seed)
    vec = []
    for i in range(8):
        chunk = h[4*i:4*(i+1)]
        vec.append(bytes_to_float01(chunk))
    return vec

def promote_8d_to_24d(v8):
    v = list(v8)
    v24 = []
    for k in range(3):
        for i in range(8):
            v24.append((v[i] + (0.123*(k+1)) + (0.017*i)) % 1.0)
    return v24

def lorenz_step(x,y,z, s=10.0, r=28.0, b=8.0/3.0, dt=0.01):
    dx = s*(y-x)
    dy = x*(r-z)-y
    dz = x*y - b*z
    return x+dx*dt, y+dy*dt, z+dz*dt

def embed_state_3d_to_8d(x,y,z,t):
    v8 = [
        (x%50)/50, (y%50)/50, (z%50)/50,
        ((x**2+y**2+z**2)%1000)/1000,
        ((x*y)%100)/100, ((y*z)%100)/100,
        ((z*x)%100)/100, ((t%10)/10)
    ]
    return v8

def quantize(vec, bins=32):
    q = []
    for v in vec:
        k = int(max(0, min(bins-1, math.floor(v*bins))))
        q.append(k)
    return tuple(q)

def gram_proxy(samples):
    '''Compute a tiny proxy Gram "spectrum" by average inner products of 24D vectors.'''
    import itertools
    ips = []
    for a,b in itertools.islice(itertools.combinations(samples, 2), 0, 256):
        s = sum(x*y for x,y in zip(a,b))
        ips.append(s)
    if not ips:
        return {"mean":0.0,"var":0.0,"top":[]}
    m = sum(ips)/len(ips)
    v = sum((x-m)*(x-m) for x in ips)/len(ips)
    top = sorted(ips, reverse=True)[:5]
    return {"mean":m,"var":v,"top":top}
