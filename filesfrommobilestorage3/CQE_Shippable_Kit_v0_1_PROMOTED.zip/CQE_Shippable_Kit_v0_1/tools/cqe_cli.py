#!/usr/bin/env python3
import argparse, json, math, hashlib, time, sys
from pathlib import Path

def sha(x:bytes)->str: return hashlib.sha256(x).hexdigest()

def mirror_rmse_vs_mse(mse, rmse, tol=1e-12):
    return abs(rmse - math.sqrt(mse)) <= tol

def run_weatherbench_synthetic(seed=424242):
    import numpy as np
    rng = np.random.default_rng(seed)
    lats = np.linspace(-87.1875,87.1875,16); lons=np.linspace(0,360-360/32,32)
    obs = rng.normal(0,1,size=(len(lats),len(lons)))
    rho6, rho12 = 0.80, 0.60
    fc6 = rho6*obs + rng.normal(0, math.sqrt(1-rho6**2), size=obs.shape)
    fc12= rho12*obs + rng.normal(0, math.sqrt(1-rho12**2), size=obs.shape)
    def mse(a,b): return float(((a-b)**2).mean())
    def acc(a,b):
        aa=a.ravel()-a.mean(); bb=b.ravel()-b.mean()
        num=float((aa*bb).sum()); den=float((aa**2).sum()* (bb**2).sum())**0.5
        return float(num/den) if den>0 else float("nan")
    mse_g = mse(fc6, obs); rmse_g = mse_g**0.5
    acc6 = acc(fc6,obs); acc12 = acc(fc12,obs)
    rails = [
        mirror_rmse_vs_mse(mse_g, rmse_g),
        acc6>0.70,
        True,                 # regional split placeholder (omitted here)
        acc6>=acc12
    ]
    fourbit = "".join("1" if b else "0" for b in rails)
    receipts = {"mse6":mse_g,"rmse6":rmse_g,"acc6":acc6,"acc12":acc12}
    return fourbit, receipts

def run_opencatalyst_surrogate():
    # tiny LJ surrogate; PROVISIONAL by design
    import numpy as np
    eps, sig, cut = 0.010, 2.5, 6.0
    surface = np.array([[0.0,0.0,0.0],[2.5,0.0,0.0],[0.0,2.5,0.0],[2.5,2.5,0.0]], float)
    ads = np.array([[1.25,1.25,2.0]], float)
    X = np.vstack([surface, ads])
    def energy(x):
        e=0.0
        for i in range(len(x)):
            for j in range(i+1,len(x)):
                r=np.linalg.norm(x[i]-x[j]); 
                if r<1e-12 or r>cut: continue
                sr6=(sig/r)**6; e += 4*eps*(sr6*sr6 - sr6)
        return e
    def force(x):
        f=np.zeros_like(x)
        for i in range(len(x)):
            for j in range(len(x)):
                if i==j: continue
                rij=x[i]-x[j]; r=np.linalg.norm(rij)
                if r<1e-12 or r>cut: continue
                sr2=(sig/r)**2; sr6=sr2**3; sr12=sr6**2
                mag=24*eps/r*(2*sr12 - sr6); f[i]+=mag*(rij/r)
        return -f
    E0=energy(X); F0=force(X); step=0.02
    X1=X.copy(); X1[-1]+= step * F0[-1]/(np.linalg.norm(F0[-1])+1e-12)
    E1=energy(X1)
    rails=[(E0-E1)>=0, True, True, True]  # energy improve, units, stability, mirror (trivial here)
    fourbit="".join("1" if b else "0" for b in rails)
    receipts={"E0":E0,"E1":E1,"dE":E0-E1}
    return fourbit, receipts

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--rail", choices=["WB_SYN","OC_SUR"], required=True)
    ap.add_argument("--seed", type=int, default=424242)
    ap.add_argument("--out", type=Path, required=True)
    args=ap.parse_args()
    if args.rail=="WB_SYN": fourbit, receipts = run_weatherbench_synthetic(args.seed)
    else: fourbit, receipts = run_opencatalyst_surrogate()
    entry = {
        "wrapper_id":"CQE_DEMO",
        "rail_id": args.rail,
        "rest_hash": sha(json.dumps({"seed":args.seed}).encode()),
        "commit_bits": fourbit,
        "receipts": receipts,
        "schema_ver":"0.1.0",
        "seed": args.seed,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    }
    entry["merkle_root"] = sha(json.dumps(entry, sort_keys=True).encode())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(entry, indent=2))
    print(json.dumps(entry, indent=2))

if __name__=="__main__":
    main()
