
import json, os, time
class Wallet:
    def __init__(self, path=".ledger/wallet.json"):
        self.path = path; os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(path): json.dump({"balances":{}, "history":[]}, open(path,"w"))
    def _load(self):
        return json.load(open(self.path,"r"))
    def _save(self, data): json.dump(data, open(self.path,"w"))
    def credit(self, who, coin, amount, note="mint"):
        d = self._load(); b = d["balances"].get(who,{}); b[coin] = b.get(coin,0.0)+amount; d["balances"][who]=b
        d["history"].append({"ts":time.time(),"who":who,"coin":coin,"amount":amount,"note":note})
        self._save(d); return b[coin]
    def multi_credit(self, who, domain_map, note="mint"):
        for k,v in domain_map.items(): self.credit(who,k,v,note=note)
    def balance(self, who): return self._load()["balances"].get(who,{})
    def history(self, n=100): return self._load()["history"][-n:]
