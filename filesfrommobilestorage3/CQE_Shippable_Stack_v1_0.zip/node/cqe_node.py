
import os, time, json, base64
from urllib import request
ASSETS = "assets"; os.makedirs(ASSETS, exist_ok=True)

def _post(path, obj):
    data = json.dumps(obj).encode()
    req = request.Request(f"http://127.0.0.1:8766{path}", data=data, headers={"Content-Type":"application/json"})
    return json.loads(request.urlopen(req).read().decode())

def watch_once():
    files = os.listdir(ASSETS)
    for fn in files:
        # Extract features
        r = _post("/features/extract", {"filename": fn})
        feats = r.get("features", {})
        # Optionally auto-mint if server toggle is on
        _post("/mint/mint_now", {"features": feats})

if __name__ == "__main__":
    while True:
        try: watch_once()
        except Exception as e: pass
        time.sleep(3)
