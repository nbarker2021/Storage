
import os, json, re
def tokenize(txt:str):
    return re.findall(r"[A-Za-z0-9_\-]+", txt)
def simple_features(text:str):
    toks = tokenize(text)
    n = len(toks)
    uniq = len(set(toks)); alpha = sum(t.isalpha() for t in toks) / (n or 1)
    # Toy signals; replace with adapters later
    AEGIS = {"Auditability": 0.6, "Evidence": 0.55, "Governance":0.5, "Impact":0.6, "Safety":0.7}
    FIVEWH1 = {"Who":0.5,"What":0.6,"Where":0.4,"When":0.6,"Why":0.6,"How":0.55}
    GEO_GLOBAL = {"Novelty": min(0.25, uniq/(n+1.0)), "Bridges": min(5, uniq//200)}
    GEO_LOCAL = {}  # fill in UI or client-side
    return {"AEGIS":AEGIS, "FIVEWH1":FIVEWH1, "GEO_GLOBAL":GEO_GLOBAL, "GEO_LOCAL":GEO_LOCAL}
