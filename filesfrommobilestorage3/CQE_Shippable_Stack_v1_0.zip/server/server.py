
import os, json, time, base64
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from kernel.kernel import CQEKernel
from mint.commonsledger_mint import MintEngine, Wallet
from analyzer.features import simple_features

ASSETS = "assets"
os.makedirs(ASSETS, exist_ok=True)
os.makedirs(".ledger", exist_ok=True)

KERNEL = CQEKernel(".ledger/kernel.jsonl")
MINT = MintEngine(".ledger/mints.jsonl")
WALLET = Wallet(".ledger/wallet.json")
CFG = {"mint_enabled": False, "default_owner":"local.user"}

def ok(w, obj): w.send_response(200); w.send_header("Content-Type","application/json"); w.send_header("Access-Control-Allow-Origin","*"); w.end_headers(); w.wfile.write(json.dumps(obj).encode())
def err(w, code, msg): w.send_response(code); w.send_header("Content-Type","application/json"); w.send_header("Access-Control-Allow-Origin","*"); w.end_headers(); w.wfile.write(json.dumps({"ok":False,"error":msg}).encode())

class App(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200); self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","content-type"); self.send_header("Access-Control-Allow-Methods","POST,GET,OPTIONS"); self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path
        if p=="/assets/list":
            files = sorted(os.listdir(ASSETS))
            return ok(self, {"ok":True,"files":files})
        if p=="/wallet/balance":
            who = "local.user"
            return ok(self, {"ok":True,"balance": WALLET.balance(who)})
        if p=="/cfg":
            return ok(self, {"ok":True, "cfg": CFG})
        return err(self,404,"not found")

    def do_POST(self):
        p = urlparse(self.path).path
        ln = int(self.headers.get("Content-Length","0")); b = json.loads(self.rfile.read(ln) or b"{}")

        if p=="/kernel/report":
            from common.receipts import Ledger
            tail = Ledger(".ledger/kernel.jsonl").tail(100)
            return ok(self, {"ok":True,"tail":tail})

        if p=="/assets/upload":
            filename = b.get("filename","asset.txt"); content_b64 = b.get("content_b64","")
            try:
                raw = base64.b64decode(content_b64.encode())
                with open(os.path.join(ASSETS, filename), "wb") as f: f.write(raw)
                KERNEL.compute({"op":"upload","file":filename}, scope="io", channel=3, tags=["upload"], compute_fn=lambda: True)
                return ok(self, {"ok":True,"file":filename})
            except Exception as e:
                return err(self,400,str(e))

        if p=="/features/extract":
            filename = b.get("filename")
            path = os.path.join(ASSETS, filename)
            if not os.path.exists(path): return err(self,404,"no such file")
            try:
                data = open(path,"rb").read()
                try:
                    txt = data.decode("utf-8", errors="ignore")
                except:
                    txt = ""
                feats = simple_features(txt)
                return ok(self, {"ok":True,"features": feats})
            except Exception as e:
                return err(self,400,str(e))

        if p=="/mint/score":
            feats = b.get("features",{})
            out = MINT.score(feats)
            return ok(self, {"ok":True,"result": out})

        if p=="/mint/mint_now":
            if not CFG.get("mint_enabled"): return err(self,403,"minting disabled")
            feats = b.get("features",{})
            out = MINT.score(feats)
            who = CFG.get("default_owner","local.user")
            WALLET.credit(who, "MERIT", out["mint"]["MERIT"], note="mint")
            WALLET.multi_credit(who, out["mint"]["domains"], note="mint")
            # local_merit is endorsement-only (not a transferable coin)
            return ok(self, {"ok":True,"result": out, "credited_to": who})

        if p=="/toggle/minting":
            CFG["mint_enabled"] = bool(b.get("enabled", False))
            return ok(self, {"ok":True,"mint_enabled": CFG["mint_enabled"]})

        if p=="/wallet/transfer":
            who = b.get("to","local.user"); coin=b.get("coin","MERIT"); amt=float(b.get("amount",0.0))
            WALLET.credit(who, coin, amt, note="manual")
            return ok(self, {"ok":True,"balance": WALLET.balance(who)})

        return err(self,404,"not found")

def run(host="127.0.0.1", port=8766):
    httpd = HTTPServer((host,port), App)
    print(f"Server: http://{host}:{port}"); httpd.serve_forever()
