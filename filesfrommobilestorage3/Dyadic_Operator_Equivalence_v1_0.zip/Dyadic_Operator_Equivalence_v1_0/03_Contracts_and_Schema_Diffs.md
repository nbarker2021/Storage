# Contracts — GAE/CEC Diffs for Uplift

GAE (Attestation) additions:
- rest_scale: one of {2,4,8,16,64}
- dyadic_depth: integer d >= 1
- uplift_count: integer (monotone)
- two_adic_max: 2^J, the highest 2-power included
- pulse_tolerance: epsilon for face-touch checks

CEC (Execution) additions:
- return_to_even: true (required)
- pal_profile: {theta4,theta8}
- latches: uint8[8]
- pulse_order: enum or list
- bounds_eps: epsilon used for face-only pulses

Schema is backwards-compatible; older frames omit these fields and default to the existing R8 semantics.
