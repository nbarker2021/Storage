# API — Endpoints and Examples

POST /uplift
- Input: { frame_hash, state_hash, steps: k=1..N }
- Effect: applies U2^k with legality-preserving even-neighbor lifts
- Output: { frame_hash', state_hash', dyadic_depth', two_adic_max' }

POST /rest/select
- Input: { planes_active, parity_flags, frame_hash }
- Output: { rest_scale, dyadic_depth, anchor_id }

POST /gate/scan
- Input: { frame_hash, state_hash, face_id }
- Output: { latches[8], touched?:bool, ready_to_advance?:bool }

POST /advance
- Input: { frame_hash, state_hash, latches }
- Output: { advanced?:bool, latches_cleared?:bool }

GET /proof/state
- Output: { rest_id, deltas[], latches, legality_proof, nf_hash, merkle_root }

Example (JSON):
{
  "op": "uplift",
  "frame_hash": "F_abc...",
  "state_hash": "S_xyz...",
  "steps": 3
}
-> 
{
  "frame_hash": "F_def...",
  "state_hash": "S_uvm...",
  "dyadic_depth": 6,
  "two_adic_max": 64
}
