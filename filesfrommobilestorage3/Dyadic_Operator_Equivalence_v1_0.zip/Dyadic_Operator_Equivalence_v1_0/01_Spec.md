# Section X — Dyadic Operator Equivalence (2, 4, and 8^k are the same operation)

Claim. There is one uplift operator, U2. Applying it once yields "x2 detail" (2), twice yields "x4 detail" (4), and three times yields "x8 detail" (8 == U2^3). All higher powers of eight are repeated applications: 8^k == U2^(3k). Semantics are identical at each application; only resolution refines.

X.1 Objects
- Frame F = <tau, S=2^d, M, FACES>
- State x in Z^n with legality (Type-II Con-A evenness, zero syndrome, palindromy bounds)
- Decomposition: x = R (+) Delta, with mirror R* = R (even), Delta* = -Delta (odd)

X.2 Definition of U2 (single application)
1) Scale step: d <- d+1 (S doubles)
2) 2-adic refinement: ensure next modulus 2^(J+1) in M (odd primes preserved)
3) Histogram refinement: palindromy buckets refine by one bit
4) Even-neighbor lift: choose the even representative in x+2C to preserve legality

X.3 Invariants under U2
I1. Legality invariant: legal(x,F) => legal(U2(x), U2(F))
I2. Threshold semantics invariant: "1/8 representation" and "1/4 driving" remain fraction-of-current-scale
I3. Gating invariant: 8-face latches, mirror, timing-13, pulse/advance logic unchanged
I4. Reduction commutation up to NF: NF(U2(Reduce*(x))) == NF(Reduce*(U2(x)))
I5. Ledger/energy invariant: ledger-many, commit-once policy unchanged
I6. Anchor mapping: (frame, rest_scale, coset) -> (frame', rest_scale*2, coset') with same latch pattern

X.4 Relation to Dyadic Rests
R_2 = U2^1(R_1), R_4 = U2^2(R_1), R_8 = U2^3(R_1), R_64 = U2^6(R_1) = U8^2(R_1).
Policy: choose the smallest rest consistent with active planes + flags.

X.5 Micro-mapping
- 2->4: add mod 2^3, refine histograms, even-neighbor lift; witnesses identical
- 4->8: repeat; thresholds remain 1/8 and 1/4 at finer chart
- 8->64: apply U2 three times (or U8 once)

X.6 Acceptance
- "Same operation" means: identical gate semantics, ledger policy, witness logic, and reduction rules; only resolution changes.
