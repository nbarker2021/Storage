# Methods — Uplift Run-Loop

Inputs: frame F, state x (or R, Delta), current dyadic depth d, 2-adic tower up to 2^J.

Run-Loop (pure uplift, one step):
1) d <- d+1; S <- 2^d
2) M <- M U {2^(J+1)}
3) Recompute mod-2..2^(J+1) residues and palindromy histograms
4) Con-A even-neighbor lift: pick canonical element in x+2C that preserves zero-syndrome and evenness
5) Re-check witnesses at refined depth; latch state carries over

Reduce-vs-Uplift order:
- We allow Reduce* to proceed at either depth; confluence guarantees the same NF hash after mapping.
