# By-Hand Worksheet — Uplift and Latches

Inputs: dyadic depth d, 2-adic max 2^J, pal thresholds (theta4,theta8).

Step 1 (Select rest): choose smallest rest scale consistent with plane activity and flags.
Step 2 (Uplift once): d<-d+1; add next 2-power to M.
Step 3 (Even-neighbor): pick canonical rep in x+2C (preserve zero syndrome and evenness).
Step 4 (Palindromy): recompute P4,P8 at finer buckets; confirm zero-defects remain zeros.
Step 5 (Latches): run a face-only sweep; flip latch bit when face legally touched.
Step 6 (Advance): only when all 8 latch bits are 1; then clear latches and continue.

Check boxes:
[ ] Rest selected  [ ] Uplift applied  [ ] Even-neighbor chosen
[ ] P4,P8 validated  [ ] 8 latches set  [ ] Advanced cadence
