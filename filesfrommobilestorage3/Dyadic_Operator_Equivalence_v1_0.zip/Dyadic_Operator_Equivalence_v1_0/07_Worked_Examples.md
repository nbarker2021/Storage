# Worked Examples

Example A: 2 -> 4
Start: d=1 (S=2). Legal x with NF hash h0.
Apply U2 once: d=2 (S=4), add 2^3 to M, refine histograms, even-neighbor lift.
Run Reduce*: NF' hash h0' == canonical map of h0; latches identical.

Example B: 4 -> 8 (three-step equivalence)
Apply U2 twice more (total three applications): equivalent to U8 once. Threshold meanings unchanged; 8-face gating unchanged; anchor maps to rest_scale=8.

Example C: 8 -> 64 (U2^3)
Three U2 steps: extend tower, refine histograms, preserve legality, recompute residues.
Result: same verdicts; finer resolution; same anchor pattern at higher depth.
