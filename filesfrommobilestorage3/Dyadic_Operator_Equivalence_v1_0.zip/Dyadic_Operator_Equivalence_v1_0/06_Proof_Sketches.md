# Proof Sketches

Termination/Confluence with U2
- Violation vector Phi=(wt(s), P8, P4, rho) over N^4 is unaffected in ordering by a pure uplift; Reduce steps strictly decrease Phi at any fixed depth.
- Local confluence holds; Newman => unique NF. Mapping NF between depths is canonical via even-neighbor lifts, thus NF(U2(Reduce*(x))) == NF(Reduce*(U2(x))).

Legality Invariance
- U2 extends the 2-adic tower and re-checks Con-A legality with an even-neighbor lift. If (syndrome=0, even, pal bounds) held, they hold at the refined histogram as zeros map to zeros; if noisy bounds, thresholds are rescaled consistently.

Threshold Semantics
- Thresholds are fractions of the current scale; the policy uses relative occupancy. Therefore, 1/8 and 1/4 gates are scale-free and invariant under U2.
