# Falsifiers and Metrics (Uplift-Specific)

F7 Gating completeness: any cadence advance with fewer than 8 latches set -> FAIL
F8 Depth non-commutation: Reduce* before vs after U2 gives distinct NF hash -> FAIL
F9 Odd-lift leak: U2 produces an odd lift that enters dynamics -> FAIL
F10 Threshold drift: 1/4 driving or 1/8 representation semantics change after U2 -> FAIL

Metrics to report:
- confluence_hash (target 1.000)
- legality_rate
- time_to_REST at each depth
- energy/commit equivalence across depths
- latch_sweeps_per_advance
