# Dyadic Operator Equivalence (2, 4, 8^k) — v1.0
UTC: 2025-09-16T23:22:09Z

This pack gives the new section the same treatment as the rest of the LFAI docs:
- Spec-level definition of the uplift operator U2
- Methods and uplift run-loop
- Contract diffs (GAE/CEC) + machine-readable examples
- API endpoints and example payloads
- Falsifiers, metrics, and acceptance
- Proof sketches (termination, confluence, invariants)
- Worked examples
- By-hand worksheet for uplift and latches
