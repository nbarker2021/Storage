# CQE Shippable Kit v0.1

## Contents
- spec/: DSL + Ledger schema
- sidecars/: 16 pre-defined sidecar templates
- tools/: reference CLI (`cqe_cli.py`)
- samples/: example receipts (WB synthetic, OC surrogate)
- docs/: human-only kit (printables)
- api/: OpenAPI spec
- pitch/: pitch deck (markdown)
- patent/: provisional claims sketch (not legal advice)

## Quick Start
```
python3 tools/cqe_cli.py --rail WB_SYN --out receipts/wb.json
python3 tools/cqe_cli.py --rail OC_SUR --out receipts/oc.json
```
Review the `commit_bits` and `receipts` fields. `1111` → DIGEST; otherwise EXO with reason.

## Binding Meaning (Optional)
Attach glyph packs per domain only after a 4-bit pass; never bind raw secrets pre-commit.

## Next
- Swap WB synthetic for a real WeatherBench/ERA5 slice.
- Swap OC surrogate for an OpenCatalyst sample.
- Add rails via `sidecars/` and extend the CLI or service.
