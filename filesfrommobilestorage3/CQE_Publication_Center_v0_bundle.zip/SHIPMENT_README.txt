CQE Publication Center — Shipment v0
====================================
Contents:
- 8 foundational PDFs (charter, methods, governance, results ×3, falsifiers, ledger & replay).
- Code/Research two-division pilot:
  * harnesses.csv
  * research tokens (3 CSVs)
  * governance_manifest.csv + .json
  * pin_schema.csv
  * residues_*.csv (mods [2, 4, 8, 32, 13]) for numeric pins (scale=1000 integerization)

Operational notes:
- Mars Nav is PROVISIONAL-OPEN pending real pins (atm_density_kg_m3, dv_budget_m_s).
- Ice Phase and Codon Duplex are OPEN in the scratch-only demo.
- Residues files are a convenience for quick CRT checks; replace stand-ins with cited values to finalize.
