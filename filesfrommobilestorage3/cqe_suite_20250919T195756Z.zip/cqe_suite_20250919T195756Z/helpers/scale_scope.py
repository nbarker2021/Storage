{
  "normalize": "x'=(x-lo)/(hi-lo)",
  "conversions": {
    "C_to_K": "+273.15",
    "eV_to_J": "*1.602e-19",
    "GHz_to_Hz": "*1e9",
    "dB_to_linear": "10^(dB/20)"
  },
  "notes": "Use to scale receipts when units/scope change."
}