
import json, os, sys, glob, hashlib
import pandas as pd

TS="20250919T195756Z"

def load(p): 
    with open(p,'r') as f: return json.load(f)
def hsh(d): 
    return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()

def check(pack_def, ex):
    rc={"pass":True,"reasons":[]}
    r=ex.get("receipts",{}); s=pack_def.get("strict",{})
    def ge(k,t):
        v=r.get(k,None)
        if v is None or v<t: rc["pass"]=False; rc["reasons"].append(f"{k}<{t} (got {v})")
    def le(k,t):
        v=r.get(k,None)
        if v is None or v>t: rc["pass"]=False; rc["reasons"].append(f"{k}>{t} (got {v})")
    name=pack_def.get("description","").lower()
    if "non-reciprocal magnetism" in name:
        if "min_chirality" in s: ge("chirality_score", s["min_chirality"])
        if "min_nonrecip" in s: ge("nonreciprocity_index", s["min_nonrecip"])
        if "min_gap_GHz" in s: ge("floquet_gap_GHz", s["min_gap_GHz"])
        if "max_temp_rise_K" in s: le("max_temp_rise_K", s["max_temp_rise_K"])
    if "hippocampal" in name:
        if "min_MI" in s: ge("spike_content_MI", s["min_MI"])
        if "min_phase_R" in s: ge("phase_lock_R", s["min_phase_R"])
        if "max_replay_err_cm" in s: le("replay_err_cm", s["max_replay_err_cm"])
    if "atropisomer" in name or "macrocycle" in name:
        if "min_barrier_kcal" in s: ge("deltaG_dagger_axis_kcal", s["min_barrier_kcal"])
        if "min_ee" in s: ge("er", s["min_ee"])
        if "min_dr" in s: ge("dr", s["min_dr"])
        if "min_yield_pct" in s: ge("yield_pct", s["min_yield_pct"])
    if "hydrofunctionalization" in name:
        if "min_ee" in s: ge("ee", s["min_ee"])
        if "min_dr" in s: ge("dr_alpha", s["min_dr"]); ge("dr_gamma", s["min_dr"])
        if "min_site_selectivity_pct" in s: ge("site_selectivity_pct", s["min_site_selectivity_pct"])
        if "min_mass_balance_pct" in s: ge("mass_balance_pct", s["min_mass_balance_pct"])
    if "graphene-oxide" in name:
        if "deltaEg_window_eV" in s:
            val=abs(r.get("deltaEg_eV",1e9))
            if val>s["deltaEg_window_eV"]: rc["pass"]=False; rc["reasons"].append(f"|deltaEg_eV|>{s['deltaEg_window_eV']} (got {val})")
        if "min_abs_deltaPhi_eV" in s:
            val=abs(r.get("deltaPhi_eV",0.0))
            if val<s["min_abs_deltaPhi_eV"]: rc["pass"]=False; rc["reasons"].append(f"|deltaPhi_eV|<{s['min_abs_deltaPhi_eV']} (got {val})")
        if "min_ads_energy_mag_eV" in s:
            val=abs(r.get("ads_energy_eV",0.0))
            if val<s["min_ads_energy_mag_eV"]: rc["pass"]=False; rc["reasons"].append(f"|ads_energy_eV|<{s['min_ads_energy_mag_eV']} (got {val})")
    if "gauge fields in photonics" in name:
        if "min_gap_GHz" in s: ge("gap_GHz", s["min_gap_GHz"])
        if "max_linewidth_GHz" in s: le("linewidth_GHz", s["max_linewidth_GHz"])
        if "min_edge_Q" in s: ge("edge_mode_Q", s["min_edge_Q"])
    if "spatial gene expression" in name:
        if "min_celltype_acc" in s: ge("celltype_acc", s["min_celltype_acc"])
        if "min_per_cell_corr" in s: ge("per_cell_corr", s["min_per_cell_corr"])
        if "min_svg_rec_k" in s: ge("svg_recovery@k", s["min_svg_rec_k"])
        if "max_gpu_hours" in s: le("gpu_hours", s["max_gpu_hours"])
    if "topological superconductivity" in name:
        if "min_surface_band_res_meV" in s: ge("surface_band_res_meV", s["min_surface_band_res_meV"])
        if "min_zbp_robustness" in s: ge("zbp_robustness", s["min_zbp_robustness"])
        if "min_odd_parity_QPI" in s: ge("odd_parity_QPI_score", s["min_odd_parity_QPI"])
        if "min_bulk_gap_meV" in s: ge("bulk_gap_meV", s["min_bulk_gap_meV"])
    if "entanglement characterization" in name:
        if "min_fidelity" in s: ge("fidelity", s["min_fidelity"])
        if "min_N_qubits" in s: ge("N_qubits", s["min_N_qubits"])
        if "max_runtime_s" in s: le("runtime_s", s["max_runtime_s"])
    if "transfer methylation" in name:
        if "min_yield_pct" in s: ge("yield_pct", s["min_yield_pct"])
        if "min_chemoselect_pct" in s: ge("chemoselect_pct", s["min_chemoselect_pct"])
        if "min_quantum_yield" in s: ge("quantum_yield", s["min_quantum_yield"])
    if "photonic neural network" in name:
        if "min_TOPS" in s: ge("TOPS", s["min_TOPS"])
        if "max_pJ_per_MAC" in s: le("pJ_per_MAC", s["max_pJ_per_MAC"])
        if "min_acc_top1_pct" in s: ge("acc_top1_pct", s["min_acc_top1_pct"])
        if "max_latency_ms" in s: le("latency_ms", s["max_latency_ms"])
    return rc

def main(root):
    packs_dir=os.path.join(root,"packs")
    ex_g=os.path.join(root,"examples","golden")
    ex_b=os.path.join(root,"examples","baseline")
    report=os.path.join(root,"reports","summary.csv")
    packs={os.path.splitext(os.path.basename(p))[0]: load(p) for p in glob.glob(os.path.join(packs_dir,"*.yaml"))}
    rows=[]
    for cls,kind in [("golden",ex_g),("baseline",ex_b)]:
        for exf in glob.glob(os.path.join(kind,"*.yaml")):
            ex=load(exf); pack=ex.get("pack"); stem=os.path.splitext(os.path.basename(exf))[0]
            rc={"pass":False,"reasons":["unknown pack"]}
            if pack in packs: rc=check(packs[pack],ex)
            rows.append({"class":cls,"pack":pack,"id":ex.get("id",stem),"fourbit":ex.get("fourbit","----"),
                         "pass":rc["pass"],"reasons":"; ".join(rc["reasons"]), "receipts_hash": hsh(ex.get("receipts",{})), "timestamp_utc": TS})
    df=pd.DataFrame(rows); df.to_csv(report,index=False)
    agg=df.groupby(["pack","class"])["pass"].mean().reset_index().rename(columns={"pass":"pass_rate"})
    agg.to_csv(os.path.join(root,"reports","per_pack_pass_rates.csv"),index=False)
    df.to_csv(os.path.join(root,"reports","commit_ledger.csv"),index=False)
    print("WROTE", report)

if __name__=="__main__":
    main(sys.argv[1] if len(sys.argv)>1 else ".")
