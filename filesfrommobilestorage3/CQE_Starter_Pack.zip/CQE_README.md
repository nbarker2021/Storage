# CQE Starter Pack

This starter pack gives you three launch files:

- **CQE_Frontpage_Explainer.pdf** — one‑page overview of the method.
- **CQE_Helpsheet.pdf** — quick loop, color legend, and guardrails.
- **CQE_README.md** — this file with next steps and links.

## TL;DR
**Code → Lattice → Overlay → Mirror → Commit.** Run eight views, require palindromic rest, apply a local Δ‑lift, tighten strict thresholds, and record a 4‑bit receipt with hashes.

## First Run (paper or whiteboard)
1. Create stand‑in tokens with units/guards.  
2. Fill a DNA‑10 strip.  
3. Choose an octet of views.  
4. Do the mirror test (forward/back).  
5. If mismatch, apply one Δ‑lift and re‑test.  
6. Tighten strict thresholds after a pass.  
7. Log receipts (debts, votes) and a 4‑bit code.

## Sidecars
Start with 4–8: `MATH`, `OPTICS`, `THERMAL`, `POLAR`, `STORAGE`, `BIO`, `SPIN`, `FIN`. Scale to 64 as needed.

## Commits & Ledger
Store rows: `form_id, constructionA, automorphism_id, octet_map, dna10, thresholds, receipts, fourbit, page_hash`.

## License
CC‑BY 4.0. Generated 2025-09-20 18:39 UTC.
