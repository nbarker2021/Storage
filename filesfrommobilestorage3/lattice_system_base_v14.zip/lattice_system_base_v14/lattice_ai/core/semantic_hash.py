
import numpy as np
from dataclasses import dataclass

@dataclass
class SemanticHashTrainer:
    dim: int = 8
    bits: int = 64
    lr: float = 0.05
    steps: int = 500
    balance_weight: float = 1.0
    decor_weight: float = 0.5
    pair_weight: float = 1.0
    seed: int = 0

    def fit(self, X: np.ndarray, y_pairs: np.ndarray):
        """
        X: [N, dim] normalized vectors (SafeCube space)
        y_pairs: [M, 3] -> (i, j, label) with label in {+1 (similar), -1 (dissimilar)}
        Returns W (dim,bits), b (bits,)
        """
        rng = np.random.default_rng(self.seed)
        W = rng.standard_normal((self.dim, self.bits)) * 0.1
        b = np.zeros((self.bits,), dtype=float)

        def sigmoid(z): return 1.0 / (1.0 + np.exp(-z))
        def tanh(z): return np.tanh(z)

        for t in range(self.steps):
            Z = X @ W + b  # [N,bits]
            H = tanh(Z)    # continuous surrogate in [-1,1]
            # Bit balance loss: encourage mean ~ 0 -> 50/50
            mean_bits = H.mean(axis=0)              # [bits]
            L_balance = (mean_bits**2).mean()

            # Decorrelation loss: off-diagonal of H^T H
            C = (H.T @ H) / max(1, H.shape[0])
            off = C - np.diag(np.diag(C))
            L_decor = (off**2).mean()

            # Pairwise supervised: similar -> close codes; dissimilar -> far
            # Use cosine on H as proxy
            idx_i = y_pairs[:,0].astype(int)
            idx_j = y_pairs[:,1].astype(int)
            lbl = y_pairs[:,2]  # +/-1
            Hi = H[idx_i]; Hj = H[idx_j]
            cos = (Hi * Hj).sum(axis=1) / (np.linalg.norm(Hi,axis=1)*np.linalg.norm(Hj,axis=1) + 1e-6)
            L_pair = ((cos - lbl)**2).mean()

            L = self.balance_weight*L_balance + self.decor_weight*L_decor + self.pair_weight*L_pair

            # Gradients (simple and not fully exact; sufficient for demo)
            dH = np.zeros_like(H)
            # balance grad
            dH += (2.0 * mean_bits / H.shape[0])[None,:]
            # decor grad
            dC = 2.0*off / max(1, H.shape[0])
            dH += H @ dC
            # pair grad (approx via cosine derivative)
            denom_i = np.linalg.norm(Hi,axis=1).reshape(-1,1)+1e-6
            denom_j = np.linalg.norm(Hj,axis=1).reshape(-1,1)+1e-6
            dcos_i = (Hj/ (denom_i*denom_j)) - ((cos.reshape(-1,1)*Hi)/(denom_i**2))
            dcos_j = (Hi/ (denom_i*denom_j)) - ((cos.reshape(-1,1)*Hj)/(denom_j**2))
            # scatter back
            for k,(ii,jj) in enumerate(zip(idx_i, idx_j)):
                dH[ii] += 2*(cos[k]-lbl[k])*dcos_i[k]
                dH[jj] += 2*(cos[k]-lbl[k])*dcos_j[k]

            dZ = dH * (1 - np.tanh(Z)**2)  # derivative of tanh

            dW = X.T @ dZ / max(1, X.shape[0])
            db = dZ.mean(axis=0)

            W -= self.lr * dW
            b -= self.lr * db

        return W, b

    @staticmethod
    def bit_imbalance(X: np.ndarray, W: np.ndarray, b: np.ndarray) -> float:
        H = np.tanh(X @ W + b)
        return float(np.abs(H.mean(axis=0)).mean())
