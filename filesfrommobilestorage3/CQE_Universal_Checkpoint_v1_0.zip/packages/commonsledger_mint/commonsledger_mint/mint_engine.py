
import json, time, os
from typing import Dict, Any
from .coins import default_domain_weights, emergent_coins

class MintEngine:
    def __init__(self, ledger_path=".ledger/mints.jsonl"):
        self.ledger_path = ledger_path
        os.makedirs(os.path.dirname(ledger_path), exist_ok=True)
        if not os.path.exists(self.ledger_path): open(self.ledger_path,"w").close()

    def _write(self, rec: Dict[str,Any]):
        with open(self.ledger_path, "a", encoding="utf-8") as f: f.write(json.dumps(rec)+"\n")

    def score(self, features: Dict[str,Any]) -> Dict[str,Any]:
        if features.get('harm_instant_deny', False):
            out = {'mint': {'MERIT': 0.0, 'domains': {}, 'local_merit': 0.0},
                   'tier': 'deny','reasons': features.get('harm_reasons', []),
                   'receipts': {'decision': 'GateDeny'}}
            self._write({'ts':time.time(),'type':'deny','features':features,'out':out}); return out

        A = sum(features.get('AEGIS',{}).values()) / 5.0 if features.get('AEGIS') else 0.0
        C = sum(features.get('FIVEWH1',{}).values()) / 6.0 if features.get('FIVEWH1') else 0.0
        G = sum(features.get('GEO_GLOBAL',{}).values()) / 13.0 if features.get('GEO_GLOBAL') else 0.0

        wA, wC, wG = features.get('wA',0.45), features.get('wC',0.25), features.get('wG',0.30)
        B = wA*A + wC*C + wG*G

        tier = 'normal'
        triggers = features.get('tierdown_triggers', [])
        if triggers:
            tier = 'down'; B = min(B, features.get('tierdown_cap', 0.45))

        S = features.get('AEGIS',{}).get('Safety',0.0)
        if features.get('gov_sensitive') and S < 0.5:
            tier = 'down'; B = min(B, features.get('gov_cap', 0.35))

        if features.get('regulator_contrary', False):
            tier = 'down'; B *= features.get('reg_contrary_mult', 0.15)

        novelty = features.get('GEO_GLOBAL',{}).get('Novelty',0.0)
        saturation = min(0.3, features.get('citations_per_year',0)/10.0)
        K = features.get('epoch_factor', 100.0)

        MERIT_global = K * B * (1.0 + min(0.25, novelty) - saturation)
        if MERIT_global < 0: MERIT_global = 0.0

        field_mass = features.get('field_mass', {})
        emergent = emergent_coins(field_mass, threshold=features.get('emergent_threshold',0.40))
        dw = default_domain_weights(field_mass) if field_mass else {}
        bridges = features.get('GEO_GLOBAL',{}).get('Bridges',0)
        bridge_factor = 1.0 + 0.1 * min(5, bridges)
        domains = {k: MERIT_global * v * bridge_factor for k,v in dw.items()}

        L24 = (sum(features.get('GEO_LOCAL',{}).values()) / 24.0) if features.get('GEO_LOCAL') else 0.0
        K_local = features.get('epoch_factor_local', 400.0)
        local_merit = min(K_local * (L24 ** 1.1), features.get('local_merit_cap', 500.0))

        if features.get('education_only'):
            keep = set(features.get('edu_keep', ['SOLON','LOGOS']))
            domains = {k:(v if k in keep else 0.0) for k,v in domains.items()}
            MERIT_global = sum(domains.values())

        out = {'mint': {'MERIT': MERIT_global, 'domains': domains, 'local_merit': local_merit},
               'tier': tier,'reasons': triggers,
               'receipts': {'decision': 'Scored', 'A':A, 'C':C, 'G':G, 'L24':L24, 'emergent':emergent}}
        self._write({'ts':time.time(),'type':'mint','features':features,'out':out})
        return out
