
import json, time, os
from typing import List, Dict

class BountyBook:
    def __init__(self, path=".ledger/bounties.jsonl"):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(self.path): open(self.path,"w").close()

    def post(self, paper_id: str, title: str, fields: List[str], reward: Dict[str, float], ttl_days:int=90):
        rec = {"ts": time.time(), "paper_id": paper_id, "title": title, "fields": fields, "reward": reward, "ttl": ttl_days*86400, "status":"open"}
        with open(self.path, "a", encoding="utf-8") as f: f.write(json.dumps(rec)+"\n")
        return rec

    def list_open(self):
        out, now = [], time.time()
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip(): continue
                rec = json.loads(line)
                if rec.get("status")=="open" and (now - rec["ts"]) < rec["ttl"]:
                    out.append(rec)
        return out
