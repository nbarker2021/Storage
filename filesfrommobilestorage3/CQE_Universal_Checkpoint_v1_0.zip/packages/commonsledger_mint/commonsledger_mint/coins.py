
from typing import Dict

DEFAULT_COINS = ["MERIT","ASCLEPIUS","SOLON","THETA","EULER","LOGOS","GAIA","DAVINCI","VANGOGH","MYTHOS","HERMES","SATOSHI"]

def default_domain_weights(field_mass: Dict[str,float]) -> Dict[str,float]:
    s = sum(v for k,v in field_mass.items() if k != "MERIT")
    if s <= 0: return {}
    return {k: v/s for k,v in field_mass.items() if k != "MERIT"}

def emergent_coins(field_mass: Dict[str,float], threshold: float = 0.40):
    news = []
    for k,v in field_mass.items():
        if k not in DEFAULT_COINS and v >= threshold:
            news.append(k)
    return news
