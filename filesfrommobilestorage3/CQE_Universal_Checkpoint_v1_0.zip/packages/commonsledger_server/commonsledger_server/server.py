
import json, time, os, hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from commonsledger_mint import MintEngine
from . import licenses as _lic

KERNEL_LOG = []
LEDGER_PATH = ".ledger/kernel.jsonl"
os.makedirs(".ledger", exist_ok=True)
if not os.path.exists(LEDGER_PATH): open(LEDGER_PATH,"w").close()

MINT_ENGINE = MintEngine(ledger_path=".ledger/mints.jsonl")

def log_kernel(ev):
    KERNEL_LOG.append({"ts": time.time(), **ev})
    with open(LEDGER_PATH,"a",encoding="utf-8") as f: f.write(json.dumps(KERNEL_LOG[-1])+"\n")

class App(BaseHTTPRequestHandler):
    def _headers(self, code=200):
        self.send_response(code); self.send_header("Content-Type","application/json"); self.send_header("Access-Control-Allow-Origin","*"); self.end_headers()
    def do_OPTIONS(self):
        self.send_response(200); self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","content-type"); self.send_header("Access-Control-Allow-Methods","POST,GET,OPTIONS"); self.end_headers()
    def write(self, obj): self._headers(200); self.wfile.write(json.dumps(obj).encode())

    def do_POST(self):
        p = urlparse(self.path).path
        ln = int(self.headers.get("Content-Length","0"))
        b = json.loads(self.rfile.read(ln) or b"{}")
        if p=="/kernel/emit":
            log_kernel({"ev":"emit","payload":b}); return self.write({"ok":True})
        if p=="/kernel/report": return self.write({"ok":True,"tail": KERNEL_LOG[-50:]})

        if p=="/mint/score":
            out = MINT_ENGINE.score(b.get("features",{})); return self.write({"ok":True,"result": out})

        if p=="/licenses/verify":
            ok = _lic.verify_cap(b.get("token",{})); return self.write({"ok": bool(ok)})

        if p=="/licenses/issue":
            sub = b.get("sub","dev.local"); scopes=b.get("scopes",[]); resources=b.get("resources",[])
            nbf = int(time.time())-5; exp = int(time.time())+3600
            tok = _lic.issue_cap(sub,scopes,resources,nbf,exp,b.get("conditions",{})); return self.write({"ok":True,"token":tok})

        self._headers(404); self.wfile.write(b'{"ok":false,"err":"not found"}')

def run(host="127.0.0.1", port=8765):
    httpd = HTTPServer((host,port), App); print(f"Server running on http://{host}:{port}"); httpd.serve_forever()
