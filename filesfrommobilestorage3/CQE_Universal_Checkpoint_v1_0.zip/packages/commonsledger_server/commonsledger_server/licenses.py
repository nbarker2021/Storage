
import os, json, time, hmac, hashlib

SECRET_PATH = os.environ.get("CQE_LICENSE_SECRET", ".secrets/license_key.txt")
os.makedirs(os.path.dirname(SECRET_PATH), exist_ok=True)
if not os.path.exists(SECRET_PATH):
    with open(SECRET_PATH, "w") as f: f.write("cqe-dev-key")

def _secret(): return open(SECRET_PATH,"r").read().strip().encode()

def issue_cap(sub: str, scopes, resources, nbf:int, exp:int, conditions=None):
    tok = {"iss":"cqe.local","sub":sub,"scopes":scopes,"resources":resources,"conditions":conditions or {},
           "nbf":nbf,"exp":exp,"nonce": hashlib.sha256(f"{sub}-{time.time()}".encode()).hexdigest()[:16]}
    msg = json.dumps(tok, sort_keys=True).encode()
    sig = hmac.new(_secret(), msg, hashlib.sha256).hexdigest()
    tok["sig"] = sig
    return tok

def verify_cap(tok: dict):
    msg = json.dumps({k:v for k,v in tok.items() if k!="sig"}, sort_keys=True).encode()
    ok = hmac.compare_digest(hmac.new(_secret(), msg, hashlib.sha256).hexdigest(), tok.get("sig",""))
    now = int(time.time())
    return ok and (now >= tok.get("nbf",0)) and (now <= tok.get("exp",0))
