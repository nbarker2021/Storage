
CQE Universal Checkpoint v1.0 (stdlib-only)

What you get
- Kernel (receipts-first) + sidecar placeholder (drop in your SpeedLightPlus)
- Mint Engine with: Instant-Deny Harm Gate; Tier-Down + Local-24; Emergent Coins; Education-only override
- Licensing (HMAC dev caps; swap with Ed25519 when ready)
- HTTP server exposing /mint/score, /kernel/*, /licenses/*
- Lab UI (web/ca.html): Mint Composer, Local-24 hint, Licenses tools

Run it
1) In one terminal:  python -c "from commonsledger_server.server import run; run()"
2) Open web/ca.html in your browser (the UI calls http://127.0.0.1:8765)
3) Try Run Mint / Issue Dev Token / Verify

Receipts
- .ledger/mints.jsonl     (minting results)
- .ledger/kernel.jsonl    (kernel tail)
- .secrets/license_key.txt (local HMAC secret for demo caps)

Swap-ins
- Replace sidecar/speedlight_sidecar_plus.py with your real file (same name) to wire SpeedLightPlus.
- Plug your GeoTokenizer/MDHG/Moonshine adapters behind the scenes feeding the features vectors.
