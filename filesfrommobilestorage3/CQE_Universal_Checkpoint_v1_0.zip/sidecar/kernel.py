
import json, time, os, hashlib

class CQEKernel:
    def __init__(self, ledger_path=".ledger/kernel.jsonl"):
        self.ledger_path=ledger_path; os.makedirs(os.path.dirname(ledger_path), exist_ok=True)
        if not os.path.exists(self.ledger_path): open(self.ledger_path,"w").close()

    def compute(self, payload, scope="default", channel=3, tags=None, compute_fn=lambda: None):
        start = time.time()
        result = compute_fn()
        rid = hashlib.sha256(f"{start}-{scope}-{channel}-{json.dumps(payload,sort_keys=True)}".encode()).hexdigest()[:16]
        rec = {"ts": time.time(), "scope": scope, "channel": channel, "tags": tags or [], "rid": rid, "payload": payload, "result_meta": bool(result)}
        with open(self.ledger_path,"a",encoding="utf-8") as f: f.write(json.dumps(rec)+"\n")
        return result, {"cost": 1.0}, rid
