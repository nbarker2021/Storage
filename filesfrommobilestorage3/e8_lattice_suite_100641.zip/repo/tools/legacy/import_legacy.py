
from __future__ import annotations
import argparse, pathlib, shutil, zipfile, time, json, hashlib, sys
def unzip_to(src_zip: pathlib.Path, dst: pathlib.Path):
    with zipfile.ZipFile(src_zip, 'r') as zf: zf.extractall(dst)
def sha256_file(p: pathlib.Path) -> str:
    h = hashlib.sha256(); 
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(8192), b''): h.update(chunk)
    return h.hexdigest()
def manifest_for(root: pathlib.Path, slug: str, src_repr: str) -> dict:
    files = []
    for p in root.rglob('*'):
        if p.is_file():
            files.append({"path": p.relative_to(root).as_posix(), "sha256": sha256_file(p), "size": p.stat().st_size})
    return {"schema_version":"2.0","snap_id":f"snap::{int(time.time()*1000)}","created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "kind":"LegacyIntake","payload":{"slug":slug,"source":src_repr,"root":str(root)},"metrics":{"file_count":len(files)},"notes":{}}
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True); ap.add_argument("--slug", required=True); ap.add_argument("--dest", default="legacy")
    args = ap.parse_args()
    src = pathlib.Path(args.src).resolve(); ymd = time.strftime("%Y%m%d", time.gmtime())
    dest_root = pathlib.Path(args.dest)/ymd/args.slug; dest_root.parent.mkdir(parents=True, exist_ok=True)
    unzip_to(src, dest_root); src_repr = str(src)
    man = manifest_for(dest_root, args.slug, src_repr)
    art = pathlib.Path("artifacts"); art.mkdir(parents=True, exist_ok=True)
    out = art/f"legacy_intake_{args.slug}_{ymd}.json"; out.write_text(json.dumps(man, indent=2))
    print(f"Imported into {dest_root}\nWrote manifest {out}")
if __name__ == "__main__": main()
