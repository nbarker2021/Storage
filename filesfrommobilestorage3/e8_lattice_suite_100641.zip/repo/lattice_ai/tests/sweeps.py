
from __future__ import annotations
import numpy as np
from typing import Dict, Any, List, Tuple
from lattice_ai.pipeline.microflow import microflow_demo

def alpha_beta_sweep(seed=8, n_items=256, grid=None) -> Dict[str, Any]:
    if grid is None:
        grid = [(1.0, 0.0), (1.0, 0.1), (1.0, 0.25), (0.8, 0.4), (0.6, 0.6), (1.2, 0.2)]
    rows = []
    for a,b in grid:
        m = microflow_demo(seed=seed, n_items=n_items, alpha=float(a), beta=float(b))
        d = m.get("data", {})
        rows.append({"alpha": a, "beta": b, **d})
    return {"_artifact":"sweep_alpha_beta", "data":{"rows": rows}}
