
from __future__ import annotations
from typing import Dict, Any, Tuple, List
import numpy as np
from lattice_ai.encode.e8_lattice import E8LatticeEncoder, _geodesic_proxy
from lattice_ai.hash.two_tier import TwoTierHash, build_houses
from lattice_ai.tests.goldens_recall_latency import synth_corpus, _cosine
from lattice_ai.snap.snaphash import SnapHash, save_snaphash
from lattice_ai.snap.think_tank import publish, auto_tuners_boot

def _shell_metrics(X: np.ndarray, idx: List[int], q: np.ndarray) -> Dict[str, float]:
    if not idx: return {"coherence": 0.0, "redundancy": 1.0, "gdist_max": 1.0}
    C = X[idx]; sims = _cosine(q, C); coh = float(np.mean(sims))
    # redundancy: mean pairwise cosine among C (approx via random sample)
    if len(idx) > 1:
        m = min(len(idx), 16); pick = np.random.default_rng(7).choice(len(idx), size=m, replace=False)
        Cp = C[pick]
        N = Cp / (np.linalg.norm(Cp, axis=1, keepdims=True)+1e-12)
        G = N @ N.T
        red = float((np.sum(G)-m)/(m*(m-1)+1e-9))
    else:
        red = 0.0
    gmax = float(max(_geodesic_proxy(v) for v in C))
    return {"coherence": coh, "redundancy": red, "gdist_max": gmax}

def run(snaphash_id: str = "router→shells", bits: int = 24, mod: int = 257, alpha: float = 0.8, beta: float = 0.4, seed: int = 99) -> Dict[str, Any]:
    auto_tuners_boot()
    texts, X, labels = synth_corpus(seed=seed)
    # Index with Two-Tier corridor
    H = TwoTierHash.make(bits=bits, seed=seed)
    keys = H.house_keys(X); houses = build_houses(keys, mod=mod)
    # Query one per topic
    q_idx = [i for i,l in enumerate(labels) if labels.count(l) > 0][::60][:8]  # crude pick
    Q = X[q_idx]
    recalls = []; cand_list = []; gmax_list = []; coh_list = []
    for qi, q in enumerate(Q):
        b = int(H.house_keys(q.reshape(1,-1))[0] % mod)
        cand = houses.get(b, [])
        cand_list.append(int(len(cand)))
        if len(cand)==0: 
            recalls.append(0.0); gmax_list.append(1.0); coh_list.append(0.0); 
            continue
        sims = _cosine(q, X[cand])
        gq = 1.0/(1.0+_geodesic_proxy(q)+1e-9)
        gC = np.array([1.0/(1.0+_geodesic_proxy(c)+1e-9) for c in X[cand]], dtype=np.float32)
        blend = alpha*sims + beta*gC
        order = np.argsort(-blend)[:10]
        topk = [int(cand[i]) for i in order]
        truth = set(i for i,l in enumerate(labels) if l==labels[q_idx[qi]] and i!=q_idx[qi])
        hit = 1.0 if any(i in truth for i in topk) else 0.0
        recalls.append(hit)
        sm = _shell_metrics(X, topk, q); gmax_list.append(sm["gdist_max"]); coh_list.append(sm["coherence"])
    metrics = {
        "recall@1_nonzero": float(np.mean(recalls)),
        "avg_cand": float(np.mean(cand_list)),
        "gdist_max": float(np.max(gmax_list)),
        "coherence_mean": float(np.mean(coh_list)),
    }
    sh = SnapHash(
        snaphash_id=snaphash_id,
        src={"system":"router","corridor":f"bits={bits}|mod={mod}|alpha={alpha}|beta={beta}"},
        dst={"system":"shells","policy":"default"},
        replay={"seed": seed, "K": 10},
        expect={"recall@1_nonzero_min":0.3, "gdist_max":0.8},
        metrics={"actual": metrics},
        artifact_ref=None,
    )
    out = save_snaphash(sh)
    # Rebroadcast to think-tank
    publish("router.shells.metrics", {"snaphash_id": snaphash_id, **metrics})
    return out
