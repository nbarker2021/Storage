
from __future__ import annotations
import numpy as np, os
from dataclasses import dataclass
from lattice_ai.cmplx.backend_legacy import LegacyHashBackend
from lattice_ai.encode.e8_lattice import _geodesic_proxy
@dataclass
class MicroflowReport: cand_count:int; shell_size:int; score_mean:float; score_max:float
def _cosine(a: np.ndarray, B: np.ndarray) -> np.ndarray:
    a = a/(np.linalg.norm(a)+1e-12); B=B/(np.linalg.norm(B,axis=1,keepdims=True)+1e-12); return B@a
def microflow_demo(seed:int=8, n_items:int=256, alpha:float=1.0, beta:float=0.25) -> dict:
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n_items,8)).astype(np.float32); q = rng.standard_normal(8).astype(np.float32)
    mod = os.environ.get("LEGACY_HASH_MODULE","legacy_agrm_cmplx_agrm_module"); fn=os.environ.get("LEGACY_HASH_FUNC","fnv1a64")
    back = LegacyHashBackend(module=mod, func=fn)
    hbits = back.encode(X); buckets={}
    for i,h in enumerate(hbits): buckets.setdefault(int(h%17), []).append(i)
    qh = int(back.encode(q.reshape(1,-1))[0] % 17); cand = buckets.get(qh, [])
    if not cand: rep = MicroflowReport(0,0,0.0,0.0)
    else:
        C = X[cand]; sims = _cosine(q, C);
        gq = 1.0/(1.0+_geodesic_proxy(q)+1e-9)
        gC = np.array([1.0/(1.0+_geodesic_proxy(c)+1e-9) for c in C], dtype=np.float32)
        blend = alpha*sims + beta*gC
        order = np.argsort(-blend)[:min(16, C.shape[0])]
        scores = blend[order]; rep = MicroflowReport(len(cand), len(order), float(scores.mean()), float(scores.max()))
        # governance metrics
        gC_sel = gC[order]
        govern = {"cand_count": rep.cand_count, "score_mean": rep.score_mean, "gdist_mean": float(gC_sel.mean()), "gdist_max": float(gC_sel.max())}
    return {"_artifact":"microflow_demo","data":{"cand_count":rep.cand_count,"shell_size":rep.shell_size,"score_mean":rep.score_mean,"score_max":rep.score_max}, "govern": govern}
