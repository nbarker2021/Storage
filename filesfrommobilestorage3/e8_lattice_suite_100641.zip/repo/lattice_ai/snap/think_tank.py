
from __future__ import annotations
from typing import Dict, Any, Callable, List

_subs: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}

def publish(topic: str, message: Dict[str, Any]) -> None:
    for fn in _subs.get(topic, []):
        try: fn(message)
        except Exception: pass

def subscribe(topic: str, handler: Callable[[Dict[str, Any]], None]) -> None:
    _subs.setdefault(topic, []).append(handler)


# --- Auto-tuners ---
import json, pathlib, time

def _save_proposal(topic: str, proposal: dict):
    out_dir = pathlib.Path("/mnt/data/n7-stage/artifacts")
    ts = int(time.time()*1000)
    (out_dir / f"think_tank__{topic}__{ts}.json").write_text(json.dumps(proposal, indent=2))

def tuner_alpha_beta(msg: dict):
    # if recall low but avg_cand small, try more beta (geodesic) weight
    rec = msg.get("recall@1_nonzero", 0.0); cand = msg.get("avg_cand", 0.0)
    if rec < 0.3 and cand <= 3.5:
        proposal = {"action":"try_alpha_beta","suggested":{"alpha":0.7,"beta":0.5},"reason":"low recall with low cand"}
        _save_proposal("router.shells.tuner_ab", proposal)

def tuner_bits_mod(msg: dict):
    # if recall low and cand too low, increase bits or use larger modulus
    rec = msg.get("recall@1_nonzero", 0.0); cand = msg.get("avg_cand", 0.0)
    if rec < 0.3 and cand < 2.0:
        proposal = {"action":"try_bits_mod","suggested":{"bits":32,"mod":521},"reason":"raise fan-out slightly"}
        _save_proposal("router.shells.tuner_bm", proposal)

def auto_tuners_boot():
    subscribe("router.shells.metrics", tuner_alpha_beta)
    subscribe("router.shells.metrics", tuner_bits_mod)
