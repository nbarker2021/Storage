
from __future__ import annotations
import hashlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Any
import numpy as np


def _gen_e8_roots() -> np.ndarray:
    """Construct the canonical 240 E8 roots in R^8.

    Family 1 (112): vectors with two nonzero entries ±1 and the rest 0, any sign combo.

    Family 2 (128): vectors with all entries ±1/2 with an even number of minus signs.
    """

    roots = []

    # Family 1

    for i in range(8):

        for j in range(i+1, 8):

            for s1 in (1.0, -1.0):

                for s2 in (1.0, -1.0):

                    v = [0.0]*8

                    v[i] = s1; v[j] = s2

                    roots.append(np.array(v, dtype=np.float32))

    # Family 2

    from itertools import product

    for signs in product((1.0, -1.0), repeat=8):

        minus = sum(1 for s in signs if s < 0)

        if minus % 2 == 0:

            v = [0.5*s for s in signs]

            roots.append(np.array(v, dtype=np.float32))

    R = np.stack(roots, axis=0)

    # Normalize to unit length (though these are already at two distinct norms)

    R = R / (np.linalg.norm(R, axis=1, keepdims=True) + 1e-12)

    assert R.shape[0] == 240, f"Expected 240 roots, got {R.shape[0]}"

    return R.astype(np.float32)



    # Family 1: permutations of (±1, ±1, 0,0,0,0,0,0) with even number of minus signs
    base = [1.0, 1.0] + [0.0]*6
    from itertools import permutations, product
    seen = set()
    for perm in set(permutations(base, 8)):
        nz_idx = [i for i, val in enumerate(perm) if val != 0.0]  # exactly two indices
        for signs in product([1.0, -1.0], repeat=2):
            # even number of negatives among the two non-zeros
            if (sum(1 for s in signs if s < 0) % 2) != 0:
                continue
            vv = list(perm)
            vv[nz_idx[0]] *= signs[0]
            vv[nz_idx[1]] *= signs[1]
            t = tuple(vv)
            if t not in seen:
                seen.add(t)
                roots.append(np.array(vv, dtype=np.float32))
    # Family 2
    for bits in product([1.0, -1.0], repeat=8):
        # even number of +1 (equivalently even number of -1) -> even parity
        if (sum(1 for b in bits if b > 0) % 2) == 0:
            roots.append(np.array([0.5*b for b in bits], dtype=np.float32))
    R = np.stack(roots, axis=0)
    # normalize
    R = R / (np.linalg.norm(R, axis=1, keepdims=True) + 1e-12)
    # Deduplicate defensively (floating error)
    uniq = []
    seen = set()
    for r in R:
        key = tuple(np.round(r, 6))
        if key not in seen:
            seen.add(key); uniq.append(r)
    R = np.stack(uniq, axis=0).astype(np.float32)
    assert R.shape[0] == 240, f"Expected 240 roots, got {R.shape[0]}"
    return R

_E8_ROOTS = _gen_e8_roots()

@dataclass
class LatticeBank:
    """Pre-allocated lattice for a given shape; holds capacity slots and metadata."""
    name: str
    shape: str  # e.g., "E8", "D8", "A1^8", "Shell:k"
    dims: int = 8
    capacity: int = 1024
    # Storage
    V: np.ndarray = field(init=False)         # (capacity, dims) float32
    meta: List[Dict[str, Any]] = field(init=False)

    def __post_init__(self):
        self.V = np.zeros((self.capacity, self.dims), dtype=np.float32)
        self.meta = [dict() for _ in range(self.capacity)]
        self._next = 0

    def put(self, v: np.ndarray, info: Dict[str, Any]) -> int:
        i = self._next % self.capacity
        self.V[i] = v.astype(np.float32)
        self.meta[i] = info
        self._next += 1
        return i

@dataclass
class E8LatticeEncoder:
    """E8 lattice-aware encoder that maps inputs into R^8 vectors and assigns them
    into pre-allocated lattice banks labeled by shape.

    Shapes are tracked with explicit labels so downstream systems know the intended
    sub-structure and dimensionality semantics (e.g., Shell:k, D8 sublattice).

    Notes:
    - This implementation is deterministic and stateless w.r.t inputs.
    - Banks are pre-allocated to guarantee O(1) inserts and predictable memory locality.
    """
    banks: Dict[str, LatticeBank] = field(default_factory=dict)
    salt: str = "E8"

    def allocate_bank(self, name: str, shape: str, capacity: int = 4096, dims: int = 8) -> None:
        if name in self.banks:
            raise ValueError(f"Bank '{name}' already exists")
        if dims != 8:
            raise ValueError("This encoder is R^8-native; dims must be 8")
        self.banks[name] = LatticeBank(name=name, shape=shape, dims=dims, capacity=capacity)

    def list_banks(self) -> List[Tuple[str, str, int]]:
        return [(b.name, b.shape, b.capacity) for b in self.banks.values()]

    # --- Encoding primitives ---
    def _stable_hash(self, x: bytes, salt: str) -> int:
        return int.from_bytes(hashlib.blake2b(salt.encode('utf-8')+x, digest_size=16).digest(), 'little')

    def _pick_roots(self, h: int, k: int) -> np.ndarray:
        """Pick k root directions deterministically from E8 roots using hash h."""
        idx = list(_cached_root_idx(h, k))
        return _E8_ROOTS[np.array(idx, dtype=int)]  # (k, 8)

    def _mix(self, roots: np.ndarray, weights: np.ndarray) -> np.ndarray:
        v = (roots * weights.reshape(-1,1)).sum(axis=0)
        n = np.linalg.norm(v) + 1e-12
        return (v / n).astype(np.float32)

    def encode_text(self, text: str, bank: Optional[str] = None, k: int = 3, shell_k: int = 1) -> Dict[str, Any]:
        """Encode text to R^8, with optional insertion into a bank.

        Args:
            text: input string
            bank: optional bank name to store the vector
            k:    number of root directions to mix
            shell_k: which 'shell' label to attach (metadata only)

        Returns:
            dict: {vector, meta, (optional) bank_index}
        """
        b = text.encode('utf-8')
        h = self._stable_hash(b, self.salt)
        roots = self._pick_roots(h, k)
        # weights derived from another hash stream in [-1,1]
        w = []
        cur = h ^ 0x9E3779B97F4A7C15
        for i in range(k):
            cur = (cur * 1442695040888963407 + 11400714819323198485) & ((1<<64)-1)
            w.append(((cur & 0xFFFF) / 32767.5) - 1.0)
        v = self._mix(roots, np.array(w, dtype=np.float32))
        meta = {
            "shape": "E8",
            "dims": 8,
            "coxeter": _coxeter_coords(v).tolist(),
            "gdist": float(_geodesic_proxy(v)),
            "shell": f"Shell:{shell_k}",
            "k_roots": k,
            "roots_idx": None,  # omitted for now to keep meta light; can add if needed
            "salt": self.salt,
            "kind": "text",
        }
        rec = {"vector": v, "meta": meta}
        if bank is not None:
            if bank not in self.banks:
                raise KeyError(f"Unknown bank '{bank}'")
            i = self.banks[bank].put(v, meta | {"payload_preview": text[:64]})
            rec["bank_index"] = i
        return rec

    def encode_bytes(self, blob: bytes, bank: Optional[str] = None, k: int = 4, shell_k: int = 2) -> Dict[str, Any]:
        h = self._stable_hash(blob, self.salt)
        roots = self._pick_roots(h, k)
        # weights from blob chunks
        w = []
        cur = h ^ 0xD1B54A32D192ED03
        for i in range(k):
            cur = (cur * 3202034522624059733 + 6364136223846793005) & ((1<<64)-1)
            w.append(((cur & 0xFFFF) / 32767.5) - 1.0)
        v = self._mix(roots, np.array(w, dtype=np.float32))
        meta = {"shape": "E8", "dims": 8, "coxeter": _coxeter_coords(v).tolist(), "gdist": float(_geodesic_proxy(v)), "shell": f"Shell:{shell_k}", "k_roots": k, "salt": self.salt, "kind": "bytes"}
        rec = {"vector": v, "meta": meta}
        if bank is not None:
            if bank not in self.banks: raise KeyError(f"Unknown bank '{bank}'")
            i = self.banks[bank].put(v, meta | {"payload_len": len(blob)})
            rec["bank_index"] = i
        return rec

    # Batch helpers
    def encode_texts(self, texts: List[str], bank: Optional[str] = None, k: int = 3, shell_k: int = 1) -> Dict[str, Any]:
        out = [self.encode_text(t, bank=bank, k=k, shell_k=shell_k) for t in texts]
        V = np.stack([o["vector"] for o in out], axis=0)
        meta = [o["meta"] for o in out]
        idx = [o.get("bank_index") for o in out]
        return {"vectors": V, "meta": meta, "bank_indices": idx}

    # Introspection
    def bank_snapshot(self, name: str, limit: int = 10) -> Dict[str, Any]:
        b = self.banks[name]
        return {
            "shape": b.shape, "dims": b.dims, "capacity": b.capacity, "next": getattr(b, "_next", 0),
            "sample": [{"i": i, "meta": b.meta[i]} for i in range(min(limit, getattr(b, "_next", 0)))]
        }


# --- Geodesic / Coxeter proxies ---
def _simple_roots() -> np.ndarray:
    """A common simple-root system for E8 in R^8 (rows)."""
    # This is one canonical choice; we ensure rows are float32.
    S = np.array([
        [ 1,-1, 0, 0, 0, 0, 0, 0],
        [ 0, 1,-1, 0, 0, 0, 0, 0],
        [ 0, 0, 1,-1, 0, 0, 0, 0],
        [ 0, 0, 0, 1,-1, 0, 0, 0],
        [ 0, 0, 0, 0, 1,-1, 0, 0],
        [ 0, 0, 0, 0, 0, 1,-1, 0],
        [ 0, 0, 0, 0, 0, 0, 1,-1],
        [ -0.5,-0.5,-0.5,-0.5,-0.5,-0.5,-0.5,-0.5],  # half-sum vector as a proxy simple root
    ], dtype=np.float32)
    # Normalize rows
    S = S / (np.linalg.norm(S, axis=1, keepdims=True) + 1e-12)
    return S

_SIMPLES = _simple_roots()

from functools import lru_cache

@lru_cache(maxsize=8192)
def _cached_root_idx(h_key: int, k: int) -> tuple:
    """Cache the root index selection for a given hash and k."""
    cur = h_key
    N = _E8_ROOTS.shape[0]
    idx = []
    for _ in range(k):
        cur = (cur * 2862933555777941757 + 3037000493) & ((1<<64)-1)
        idx.append(int(cur % N))
    return tuple(idx)

def _coxeter_coords(v: np.ndarray) -> np.ndarray:
    """Least-squares coordinates of v in the simple-root basis (proxy)."""
    # Solve S^T * x ≈ v  -> x = (S S^T)^-1 S v
    S = _SIMPLES
    # normal equations
    SS = S @ S.T
    x = np.linalg.lstsq(SS, S @ v, rcond=1e-6)[0]
    return x.astype(np.float32)

def _geodesic_proxy(v: np.ndarray) -> float:
    """Proxy distance: inverse of max alignment with any E8 root."""
    sims = _E8_ROOTS @ (v / (np.linalg.norm(v)+1e-12))
    m = float(np.max(sims))
    # map sim in [0,1] to a distance-like ~ 1/(1+m)
    return 1.0 / (1.0 + m + 1e-9)
