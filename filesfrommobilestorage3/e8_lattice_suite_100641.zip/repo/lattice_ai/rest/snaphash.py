
from __future__ import annotations
from fastapi import APIRouter, Query
from lattice_ai.tests.edge_runner import run as run_edge
from lattice_ai.tests.edge_matrix import matrix as run_matrix

router = APIRouter(prefix="/snaphash", tags=["snaphash"])

@router.post("/run")
def run(snaphash_id: str = "router→shells", bits: int = 24, mod: int = 257, alpha: float = 0.8, beta: float = 0.4, seed: int = 99):
    return run_edge(snaphash_id, bits=bits, mod=mod, alpha=alpha, beta=beta, seed=seed)

@router.post("/matrix")
def matrix(snaphash_id: str = "router→shells"):
    return run_matrix(snaphash_id=snaphash_id)
