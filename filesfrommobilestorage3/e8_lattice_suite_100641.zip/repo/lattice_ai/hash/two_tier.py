
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Tuple, Dict, Any
from lattice_ai.cmplx.backend_legacy import LegacyHashBackend

@dataclass
class Tier1:
    proj: np.ndarray  # shape (B, 8)
    def signature(self, X: np.ndarray) -> np.ndarray:
        S = (X @ self.proj.T) >= 0.0
        # pack bits into integers (e.g., 16-bit if B<=16)
        out = np.zeros((X.shape[0],), dtype=np.uint32)
        B = self.proj.shape[0]
        for i in range(B):
            out |= (S[:, i].astype(np.uint32) << i)
        return out

@dataclass
class TwoTierHash:
    t1: Tier1
    t2: LegacyHashBackend

    @classmethod
    def make(cls, bits: int = 16, seed: int = 13, module: str = "legacy_agrm_cmplx_agrm_module", func: str = "fnv1a64") -> "TwoTierHash":
        rng = np.random.default_rng(seed)
        proj = rng.standard_normal((bits, 8)).astype(np.float32)
        # L2-normalize projections
        proj /= (np.linalg.norm(proj, axis=1, keepdims=True) + 1e-12)
        return cls(Tier1(proj), LegacyHashBackend(module=module, func=func))

    def house_keys(self, X: np.ndarray) -> np.ndarray:
        t1 = self.t1.signature(X)  # uint32
        t2 = self.t2.encode(X)     # uint64
        # Combine to a single 64-bit bucket key by mixing high/low
        keys = (t2 ^ (t1.astype(np.uint64) << 32)) & np.uint64((1<<64)-1)
        return keys

def build_houses(keys: np.ndarray, mod: int = 1021) -> Dict[int, np.ndarray]:
    buckets: Dict[int, list[int]] = {}
    for i, k in enumerate(keys):
        b = int(k % mod)
        buckets.setdefault(b, []).append(i)
    return {b: np.array(ix, dtype=int) for b, ix in buckets.items()}
