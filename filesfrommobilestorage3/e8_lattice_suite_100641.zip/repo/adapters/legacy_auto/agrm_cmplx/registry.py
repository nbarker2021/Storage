
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
import importlib.util, sys, pathlib, inspect
@dataclass
class LegacyModule: name: str; path: str; functions: List[str]; doc: str|None
def _load_module_from_path(path: str, modname: str):
    spec = importlib.util.spec_from_file_location(modname, path)
    if spec is None or spec.loader is None: raise ImportError(f"Cannot load {path}")
    mod = importlib.util.module_from_spec(spec); sys.modules[modname] = mod; spec.loader.exec_module(mod); return mod
def list_legacy(slug: str = "agrm-cmplx", root: str = "/mnt/data/e8_repo/legacy/20250810/agrm-cmplx") -> Dict[str, Any]:
    base = pathlib.Path(root); mods: List[LegacyModule] = []
    for p in base.rglob("*.py"):
        if p.name == "__init__.py": continue
        modname = f"legacy_{slug.replace('-','_')}_" + "_".join(p.relative_to(base).with_suffix('').parts)
        try:
            m = _load_module_from_path(str(p), modname)
            funcs = [n for n,o in inspect.getmembers(m, inspect.isfunction) if o.__module__ == m.__name__]
            mods.append(LegacyModule(name=modname, path=str(p), functions=funcs, doc=(m.__doc__ or None)))
        except Exception as e:
            mods.append(LegacyModule(name=modname, path=str(p), functions=[], doc=f"IMPORT_ERROR: {type(e).__name__}: {e}"))
    data = [dict(name=m.name, path=m.path, functions=m.functions, doc=m.doc) for m in mods]
    return {"_artifact":"legacy_registry","data":{"slug": slug, "root": root, "modules": data}}
