
from __future__ import annotations
import importlib, binascii
class Hash64:
    def __init__(self, module: str, func: str): self._fn = getattr(importlib.import_module(module), func)
    def _call(self, payload):
        try: return int(self._fn(payload))
        except TypeError:
            try: return int(self._fn(payload, 0))
            except Exception:
                if isinstance(payload, (bytes, bytearray)): hx = binascii.hexlify(payload).decode('ascii')
                else: hx = payload.encode('utf-8').hex()
                return int(self._fn(hx))
    def hash_bytes(self, b: bytes) -> int: return self._call(b)
    def hash_str(self, s: str) -> int: return self._call(s.encode('utf-8'))
def verify_vectors(module: str, func: str) -> dict:
    h = Hash64(module, func)
    vectors = {"": b"", "E8": b"E8", "hello": b"hello", "fox": b"The quick brown fox jumps over the lazy dog"}
    results = {}
    for k,b in vectors.items():
        try: results[k] = {"ok": True, "value": h.hash_bytes(b)}
        except Exception as e: results[k] = {"ok": False, "error": f"{type(e).__name__}: {e}"}
    return {"_artifact":"hash_verify","data":{"module": module, "func": func, "results": results}}
