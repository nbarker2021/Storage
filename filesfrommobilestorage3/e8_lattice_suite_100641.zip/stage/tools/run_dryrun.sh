
#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
export CODE_UNDER_TEST="${CODE_UNDER_TEST:-/mnt/data/e8_repo}"
export TEST_PLAN="${TEST_PLAN:-$ROOT_DIR/plans/n7_record_dry.yml}"
export DRYRUN_REPORT="${DRYRUN_REPORT:-$ROOT_DIR/dryrun_report.json}"
python - <<'PY'
from src.testlib_plus.orchestrator import Orchestrator
import os, json
rep = Orchestrator(os.environ['CODE_UNDER_TEST'], os.environ['TEST_PLAN'], os.environ['DRYRUN_REPORT']).run()
print(json.dumps({"records": len(rep.get("queue_records", []))}, indent=2))
PY
