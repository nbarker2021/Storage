
from __future__ import annotations
import time
class RunLog:
    def __init__(self): self.records=[]; self.saps=[]; self.meta={}; self.notes=[]
    def start_run(self, spec): self.meta={"started_at": time.time(), "plan": spec}
    def log_op(self, op, status, dur_ms, out, err): self.records.append({"name":op.name,"family":op.family,"module":op.module,"func":op.func,"priority":op.priority,"status":status,"duration_ms":dur_ms,"error":err})
    def log_sap(self, att, rule, family): self.saps.append({"family":family,"attestation":att,"ruling":rule})
    def add_notes(self, op_name, opt, weak): self.notes.append({"op":op_name,"optimization_points":opt,"weak_spots":weak})
    def finish_run(self): import time; ended=time.time(); return {"meta":{**self.meta,"ended_at":ended,"elapsed_s":ended-self.meta["started_at"]},"queue_records":self.records,"sap_events":self.saps,"notes":self.notes}
