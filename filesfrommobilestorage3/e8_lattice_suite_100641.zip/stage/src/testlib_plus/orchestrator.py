
from __future__ import annotations
import time, json, importlib, pathlib, os, sys, yaml, traceback
from typing import Any, Dict
from .queue_router import OpQueue, Op
from .runlog import RunLog
from .sap_stubs import sentinel_check, arbiter_rule

class Orchestrator:
    def __init__(self, code_root: str, plan_path: str, out_report: str):
        self.code_root=pathlib.Path(code_root).resolve()
        self.plan_path=pathlib.Path(plan_path).resolve()
        self.out_report=pathlib.Path(out_report).resolve()
        self.runlog=RunLog(); self.queue=OpQueue()

    def _patch_sys_path(self):
        if str(self.code_root) not in sys.path:
            sys.path.insert(0, str(self.code_root))

    def load_plan(self)->Dict[str,Any]:
        return yaml.safe_load(self.plan_path.read_text())

    def enqueue(self, spec: Dict[str,Any]):
        for step in spec.get("steps", []):
            op=Op(step["name"], step.get("family","generic"), step["module"], step["func"],
                  step.get("args",[]), step.get("kwargs",{}), int(step.get("priority",100)),
                  step.get("policy_id","policy:default"))
            op.kwargs.setdefault("_est_wall_ms", float(step.get("est_wall_ms",0))); self.queue.push(op)

    def _import_callable(self, module:str, func:str):
        m=importlib.import_module(module); return getattr(m, func)

    def _govern(self, family: str, metrics: Dict[str,Any], policy_id: str)->str:
        att=sentinel_check(policy_id, metrics); rule=arbiter_rule(att); self.runlog.log_sap(att, rule, family); return rule["decision"]

    def _save_artifact(self, op_name:str, artifact_name:str, obj:Any)->None:
        p=self.out_report.parent/"artifacts"; p.mkdir(parents=True, exist_ok=True)
        (p/f"{op_name}__{artifact_name}.json").write_text(json.dumps(obj, indent=2, default=str))

    def run(self)->Dict[str,Any]:
        self._patch_sys_path(); spec=self.load_plan(); self.enqueue(spec); self.runlog.start_run(spec)
        while not self.queue.empty():
            op=self.queue.pop(); t0=time.perf_counter(); status="ok"; err=None; out=None
            try:
                fn=self._import_callable(op.module, op.func)
                call_kwargs = {k:v for k,v in op.kwargs.items() if not k.startswith('_')}
                out=fn(*op.args, **call_kwargs)
                if isinstance(out, dict) and out.get("_artifact"): self._save_artifact(op.name, out["_artifact"], out.get("data"))
                if isinstance(out, dict): self.runlog.add_notes(op.name, out.get("_optimization_points",[]), out.get("_weak_spots",[]))
            except Exception as e:
                status="error"; err={"type":type(e).__name__,"msg":str(e),"trace":traceback.format_exc()}
            dur=(time.perf_counter()-t0)*1000.0
            metrics = {"op_dur_ms": dur}
            try:
                  metrics = out.get("govern", metrics) if isinstance(out, dict) else metrics
            except Exception:
                pass
            self._govern(op.family, metrics, op.policy_id); self.runlog.log_op(op, status, dur, out, err)
        rep=self.runlog.finish_run(); self.out_report.write_text(json.dumps(rep, indent=2)); return rep
