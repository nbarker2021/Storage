
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
from itertools import permutations
@dataclass
class Kernel: seed:int; alphabet: List[str]; notes: str = ""
def kernel_gen(seed:int=42, n:int=7, mode:str="dry")->Kernel:
    alpha=[chr(ord('A')+i) for i in range(3 if mode=='dry' else n)]; return Kernel(seed, alpha, f"mode={mode}")
def constructor(kernel:Kernel)->Dict[str,Any]:
    seq="".join(''.join(p) for p in permutations(kernel.alphabet, len(kernel.alphabet)))
    return {"_artifact":"superperm_candidate","data":{"sequence":seq,"alphabet":kernel.alphabet,"length":len(seq),"mode":kernel.notes.replace('mode=','')}}
def coverage_check(seq:str, alphabet:List[str], exactly_once:bool=True)->Dict[str,Any]:
    n=len(alphabet); from itertools import permutations
    counts={}; L=len(seq)
    for p in permutations(alphabet,n):
        s=''.join(p); c=0
        for i in range(0, L-n+1):
            if seq[i:i+n]==s: c+=1
        counts[s]=c
    ok = all(v==1 for v in counts.values()) if exactly_once else all(v>=1 for v in counts.values())
    return {"_artifact":"coverage_cert","data":{"alphabet":alphabet,"n":n,"counts":counts},"ok":ok}
