
from __future__ import annotations

GATES = {
    "dim": {"overlap_min": 0.60},
    "n7": {"length_min": 100},
    "micro": {"cand_min": 8, "score_mean_min": 0.1, "gdist_max": 0.8},
}

def sentinel_check(policy_id: str, metrics: dict) -> dict:
    reasons = []
    status = "pass"
    if policy_id.startswith("policy:dim"):
        if "overlap" in metrics and metrics["overlap"] < GATES["dim"]["overlap_min"]:
            reasons.append("overlap below min"); status = "fail"
    if policy_id.startswith("policy:n7"):
        if "length" in metrics and metrics["length"] < GATES["n7"]["length_min"]:
            reasons.append("length too short"); status = "fail"
    if policy_id.startswith("policy:micro"):
        if "gdist_max" in metrics and metrics["gdist_max"] > GATES["micro"]["gdist_max"]:
            reasons.append("gdist too large"); status="fail"
        if metrics.get("cand_count", 1) < GATES["micro"]["cand_min"]:
            reasons.append("no candidates in house"); status = "fail"
        if "score_mean" in metrics and metrics["score_mean"] < GATES["micro"]["score_mean_min"]:
            reasons.append("mean score below min"); status = "fail"
    return {"status": status, "policy_id": policy_id, "reasons": reasons, "metrics": metrics}

def arbiter_rule(att: dict) -> dict:
    return {"decision": "allow" if att["status"]=="pass" else "deny", "rationale": {"policy": att["policy_id"]}}
