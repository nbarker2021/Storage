
from dataclasses import dataclass
from typing import Dict, List, Callable
import numpy as np

@dataclass
class ShellQASuite:
    def run(self, c: np.ndarray, X: np.ndarray, score_fn: Callable[[str], float], item_ids: List[str]) -> Dict[str, float]:
        out: Dict[str,float] = {}
        if X.size == 0:
            return {"size":0.0,"coherence":0.0,"redundancy":0.0,"domain":0.0}
        size = X.shape[0]
        def norm(v): 
            n = np.linalg.norm(v, axis=-1, keepdims=True) + 1e-9
            return v / n
        cN = norm(c[None,:])[0]; XN = norm(X)
        coherence = float(np.mean(XN @ cN))
        if size > 1:
            S = XN @ XN.T
            redundancy = float((np.sum(S) - size) / (size*(size-1)))
        else:
            redundancy = 0.0
        domain = float(np.mean([score_fn(i) for i in item_ids])) if score_fn else 0.0
        return {"size":float(size),"coherence":coherence,"redundancy":redundancy,"domain":domain}

@dataclass
class ShellPromotionRules:
    min_size: int = 6
    min_coherence: float = 0.10
    max_redundancy: float = 0.99
    min_domain: float = 0.0
    max_flip_rate: float = 0.05  # policy monitor

    def decide(self, metrics: Dict[str, float]) -> bool:
        return (
            metrics.get("size",0) >= self.min_size and
            metrics.get("coherence",0.0) >= self.min_coherence and
            metrics.get("redundancy",1.0) <= self.max_redundancy and
            metrics.get("domain",0.0) >= self.min_domain
        )
