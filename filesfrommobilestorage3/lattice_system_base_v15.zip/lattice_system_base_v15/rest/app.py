
from fastapi import FastAPI, HTTPException
from starlette.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
import numpy as np
import json

from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.router import Router
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_qa import ShellQASuite, ShellPromotionRules
from lattice_ai.core.shell_policy import ShellPolicy
from lattice_ai.geometry.e8_roots import E8
from lattice_ai.persistence.sqlite_store import SQLiteStore
from lattice_ai.core.probes import Probes
import time
from lattice_ai.jobs.job_runner import JobRunner
from lattice_ai.core.metrics_runtime import GLOBAL_METRICS

app = FastAPI(title="Lattice AI Service", version="0.3")
app.mount('/ui', StaticFiles(directory='ui', html=True), name='ui')

# singletons (demo only)
e8 = E8.build()
cube = SafeCube(dim=8, seed=777)
sm = ShellManager()
router = Router(cube, shell_manager=sm)
store = SQLiteStore("/mnt/data/lattice_ai_v12.db")
jobs = JobRunner(cube, sm)

class GlyphIn(BaseModel):
    id: str
    tags: Optional[dict] = None

@app.post("/glyphs")
def add_glyph(g: GlyphIn):
    tags = (g.tags or {})
    tags.setdefault('ts', time.time())
    cube.add_glyph(g.id, **tags)
    cube.store_glyph(g.id)
    store.persist_glyphs(cube); store.persist_houses(cube)
    GLOBAL_METRICS.counter("glyphs_added").inc()
    return {"ok": True}

@app.post("/build_shells/{center_id}")
def build_shells(center_id: str, max_k: int = 3, nn: int = 10):
    R = e8.roots; ids = [f"root::{i}" for i in range(R.shape[0])]
    if center_id not in ids:
        raise HTTPException(404, "center_id not found among E8 roots for demo")
    sb = ShellBuilder(points=R, ids=ids)
    shells = sb.shells_for(center_id=center_id, max_k=max_k, nn=nn)
    sm.create(center_id, shells, hash_fn=lambda s: str(abs(hash(s))))
    suite = ShellQASuite(); rules = ShellPromotionRules(min_size=6, min_coherence=0.10)
    def probe_hook(center_id_str, members):
        now = time.time()
        # recency via glyph tags
        def get_ts(gid):
            g = cube.glyphs.get(gid)
            return float(g.tags.get('ts', 0)) if g else 0.0
        rec = Probes.recency(members, now, get_ts).value
        # novelty vs center
        c = R[int(center_id_str.split('::')[1])]
        import numpy as np
import json
        X = np.stack([R[int(m.split('::')[1])] for m in members], axis=0) if members else np.zeros((0,8))
        nov = Probes.novelty(c, X).value
        return {'recency': rec, 'novelty': nov}
    sm.set_probe_hook(probe_hook)
    sm.validate_and_promote(center_id, suite, rules, get_vector=lambda gid: R[int(gid.split("::")[1])], score_fn=lambda _:1.0)
    store.persist_shells_and_reports(sm)
    GLOBAL_METRICS.counter("shells_built").inc()
    return {"ok": True}

@app.get("/query")
def query(center_id: str, top_k: int = 10):
    cands = router.prefilter([center_id], k_candidates=64, use_promoted_for=center_id)
    top = router.exact_rank(center_id, cands, top_k=top_k) if cands else []
    GLOBAL_METRICS.hist("prefilter_candidates").observe(len(cands))
    return {"center_id": center_id, "candidates": cands, "topk": [x for x,_ in top]}

@app.post("/jobs/run_once")
def run_jobs_once():
    jobs.run_once()
    return {"statuses": jobs.snapshot()}

@app.get("/metrics")
def metrics():
    return GLOBAL_METRICS.snapshot()


@app.get("/reports/{center_id}")
def reports(center_id: str):
    cur = store.conn.cursor()
    rows = cur.execute("SELECT center_id, shell_k, decision, metrics, policy FROM promotion_reports WHERE center_id=?", (center_id,)).fetchall()
    out = []
    for cid, k, decision, metrics, policy in rows:
        out.append({"center_id": cid, "k": k, "decision": decision, "metrics": json.loads(metrics), "policy": json.loads(policy)})
    return {"reports": out}


@app.get("/policy/{domain}")
def get_policy(domain: str):
    blob = store.get_policy(domain)
    return blob or {}

@app.put("/policy/{domain}")
def put_policy(domain: str, body: dict):
    # Validate minimally and store
    store.upsert_policy(domain, body)
    return {"ok": True, "domain": domain, "policy": body}


@app.post("/claims")
def add_claim(subject: str, predicate: str, value: str, source: str):
    store.add_claim(subject, predicate, value, source)
    return {"ok": True}

@app.get("/houses")
def houses_snapshot():
    # Return counts + hot zones by current in-memory cube
    hz = [{"hotness": h.hotness, "items": h.items[:10]} for h in cube.hashes.hot_zones(hot_thresh=2.0)]
    return {"house_count": len(cube.hashes.houses), "hot_zones": hz}
