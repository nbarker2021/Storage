
import sqlite3, json
from .migrations import migrate
from typing import Dict, List
from ..core.safe_cube import SafeCube
from ..core.shell_lifecycle import ShellManager, ShellState, PromotionReport

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS glyphs (id TEXT PRIMARY KEY, tags TEXT);
CREATE TABLE IF NOT EXISTS houses (h1 BLOB NOT NULL, h2 BLOB NOT NULL, hotness REAL DEFAULT 0, PRIMARY KEY (h1,h2));
CREATE TABLE IF NOT EXISTS house_items (h1 BLOB NOT NULL, h2 BLOB NOT NULL, item_id TEXT NOT NULL, PRIMARY KEY (h1,h2,item_id));
CREATE TABLE IF NOT EXISTS neighbors (h1a BLOB NOT NULL, h2a BLOB NOT NULL, h1b BLOB NOT NULL, h2b BLOB NOT NULL, PRIMARY KEY (h1a,h2a,h1b,h2b));
CREATE TABLE IF NOT EXISTS shells (
  center_id TEXT NOT NULL, k INTEGER NOT NULL, payload_hash TEXT NOT NULL, state TEXT NOT NULL, ttl INTEGER NOT NULL,
  metrics TEXT NOT NULL, stats TEXT NOT NULL, members TEXT NOT NULL, provenance TEXT NOT NULL, access_policy TEXT NOT NULL,
  PRIMARY KEY (center_id,k,payload_hash,state)
);
CREATE TABLE IF NOT EXISTS promotion_reports (
  center_id TEXT, shell_k INTEGER, decision TEXT, metrics TEXT, policy TEXT
);
CREATE TABLE IF NOT EXISTS claims (
  subject TEXT, predicate TEXT, value TEXT, source TEXT
);
CREATE TABLE IF NOT EXISTS policies (
  domain TEXT PRIMARY KEY, blob TEXT
);
CREATE TABLE IF NOT EXISTS probe_cache (
  center_id TEXT, metrics TEXT, ts REAL
);
CREATE TABLE IF NOT EXISTS promotion_reports (
  center_id TEXT, shell_k INTEGER, decision TEXT, metrics TEXT, policy TEXT
);
"""

class SQLiteStore:
    def __init__(self, path: str):
        self.conn = sqlite3.connect(path)
        self.conn.executescript(SCHEMA); self.conn.commit(); migrate(self.conn)

    def persist_glyphs(self, cube: SafeCube):
        cur = self.conn.cursor()
        for gid, g in cube.glyphs.items():
            cur.execute("INSERT OR REPLACE INTO glyphs(id,tags) VALUES (?,?)",(gid, json.dumps(g.tags)))
        self.conn.commit()

    def persist_houses(self, cube: SafeCube):
        cur = self.conn.cursor()
        for key, h in cube.hashes.houses.items():
            h1,h2 = key
            cur.execute("INSERT OR REPLACE INTO houses(h1,h2,hotness) VALUES (?,?,?)", (sqlite3.Binary(h1), sqlite3.Binary(h2), float(h.hotness)))
            for item in h.items:
                cur.execute("INSERT OR REPLACE INTO house_items(h1,h2,item_id) VALUES (?,?,?)", (sqlite3.Binary(h1), sqlite3.Binary(h2), item))
            for nb in h.neighbors:
                nb1,nb2 = nb
                cur.execute("INSERT OR REPLACE INTO neighbors(h1a,h2a,h1b,h2b) VALUES (?,?,?,?)", (sqlite3.Binary(h1), sqlite3.Binary(h2), sqlite3.Binary(nb1), sqlite3.Binary(nb2)))
        self.conn.commit()

    def persist_shells_and_reports(self, sm: ShellManager):
        cur = self.conn.cursor()
        for cid, lst in sm.records.items():
            for st in lst:
                rec = st.record
                cur.execute(
                    "INSERT OR REPLACE INTO shells(center_id,k,payload_hash,state,ttl,metrics,stats,members,provenance,access_policy) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (rec.center_id, int(rec.shell_k), rec.payload_hash, st.state, int(rec.ttl),
                     json.dumps(st.metrics), json.dumps(rec.stats), json.dumps(rec.members), json.dumps(rec.provenance), rec.access_policy)
                )
        for r in sm.reports:
            cur.execute("INSERT INTO promotion_reports(center_id,shell_k,decision,metrics,policy) VALUES (?,?,?,?,?)",
                        (r.center_id, int(r.shell_k), r.decision, json.dumps(r.metrics), json.dumps(r.policy)))
        self.conn.commit()

    def load_shell_states(self, center_id: str) -> List[dict]:
        rows = self.conn.execute("SELECT k,payload_hash,state,ttl,metrics,stats,members FROM shells WHERE center_id=?", (center_id,)).fetchall()
        out = []
        for k,payload_hash,state,ttl,metrics,stats,members in rows:
            out.append({"k":k,"payload_hash":payload_hash,"state":state,"ttl":ttl,"metrics":json.loads(metrics),"stats":json.loads(stats),"members":json.loads(members)})
        return out


# --- Claims ---
def add_claim(self, subject: str, predicate: str, value: str, source: str):
    self.conn.execute("INSERT INTO claims(subject,predicate,value,source) VALUES (?,?,?,?)", (subject,predicate,value,source))
    self.conn.commit()

def list_claims_for_members(self, members):
    ph = ",".join("?"*len(members)) if members else "''"
    if not members:
        return []
    q = f"SELECT subject,predicate,value,source FROM claims WHERE source IN ({ph})"
    return [dict(subject=a,predicate=b,value=c,source=d) for (a,b,c,d) in self.conn.execute(q, members).fetchall()]

# --- Policies ---
def upsert_policy(self, domain: str, blob: dict):
    self.conn.execute("INSERT OR REPLACE INTO policies(domain,blob) VALUES (?,?)", (domain, json.dumps(blob)))
    self.conn.commit()

def get_policy(self, domain: str):
    row = self.conn.execute("SELECT blob FROM policies WHERE domain=?", (domain,)).fetchone()
    return json.loads(row[0]) if row else None
