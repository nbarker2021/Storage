"""Budget controller (v2)
Notation:
- k: candidate cap for prefilter; controls latency roughly O(k).
- p95_budget_ms: target latency; controller shrinks k when measured latency exceeds budget.
Algorithm:
1) Start at k0; measure (prefilter+rank) latency.
2) If over budget, k := max(k_min, 0.6*k); iterate up to max_iters.
3) Return final k and run exact ranking for top_k.
Limits: heuristic; future work—learned cost model conditioned on house occupancy.
"""


from dataclasses import dataclass
from typing import Optional, List, Tuple
import time, numpy as np
from .router import Router

@dataclass
class BudgetController:
    p95_budget_ms: float = 20.0
    min_k_candidates: int = 16
    max_k_candidates: int = 256
    start_k_candidates: int = 64
    max_iters: int = 3

    def _measure(self, router: Router, center_id: str, k: int, use_promoted: bool) -> Tuple[float, int, list]:
        t0 = time.time()
        cands = router.prefilter([center_id], k_candidates=k, use_promoted_for=center_id if use_promoted else None)
        t1 = time.time()
        _ = router.exact_rank(center_id, cands, top_k=min(20, len(cands))) if cands else []
        t2 = time.time()
        pre_ms = (t1 - t0) * 1000.0
        rank_ms = (t2 - t1) * 1000.0
        return pre_ms + rank_ms, len(cands), cands

    def query(self, router: Router, center_id: str, use_promoted: bool = True, top_k: int = 10):
        k = self.start_k_candidates
        last = None
        for _ in range(self.max_iters):
            lat, n, cands = self._measure(router, center_id, k, use_promoted)
            last = (lat, n, cands, k)
            if lat <= self.p95_budget_ms or k <= self.min_k_candidates:
                break
            # shrink aggressively if over budget
            k = max(self.min_k_candidates, int(k * 0.6))
        # one final exact rank with chosen K
        cands = last[2]
        top = router.exact_rank(center_id, cands, top_k=top_k) if cands else []
        return {"latency_ms": last[0], "k_candidates": last[3], "candidates": cands, "top": top}
