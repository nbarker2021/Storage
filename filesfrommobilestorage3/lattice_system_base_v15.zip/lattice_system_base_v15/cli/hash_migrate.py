
import argparse, json, numpy as np
from lattice_ai.core.hash_system import HashSystem

def synth_dataset(n_items=5000, dim=8, seed=13):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n_items, dim))
    X = X / (np.linalg.norm(X,axis=1,keepdims=True)+1e-9)
    return X

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", type=str, default="")  # optional: baseline (random)
    ap.add_argument("--new", type=str, required=True)
    ap.add_argument("--n_items", type=int, default=5000)
    args = ap.parse_args()

    X = synth_dataset(n_items=args.n_items)

    hs = HashSystem(dim=X.shape[1], tier2_bits=64, seed=1234)
    before = hs.hash_batch(X)
    # import new weights
    data = json.load(open(args.new,"r"))
    hs.import_tier2(data)
    after = hs.hash_batch(X)

    moved = sum(1 for a,b in zip(before, after) if a!=b)
    churn = moved / len(X)

    # occupancy (unique houses) for before/after
    uniq_before = len(set(before))
    uniq_after = len(set(after))

    report = {
        "items": len(X),
        "moved": moved,
        "churn": churn,
        "unique_houses_before": uniq_before,
        "unique_houses_after": uniq_after
    }
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
