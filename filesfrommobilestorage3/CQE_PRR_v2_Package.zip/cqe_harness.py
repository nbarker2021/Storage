
import numpy as np, math, json, hashlib
from typing import Dict, List, Tuple
import pandas as pd

def sha256_hex(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()

def segment_stationarity(x: np.ndarray, fs: float, win_sec=10.0, step_sec=5.0, tol_mean=2.0, tol_std=2.0):
    n = len(x)
    win = int(win_sec*fs); step = int(step_sec*fs)
    if win < 8: win = min(256, n//4)
    means, stds, idxs = [], [], []
    for start in range(0, n-win+1, step):
        seg = x[start:start+win]
        means.append(float(np.mean(seg)))
        stds.append(float(np.std(seg)))
        idxs.append((start, start+win))
    means = np.array(means); stds = np.array(stds)
    m_med, s_med = np.median(means), np.median(stds)
    m_z = np.abs(means - m_med)/(np.std(means)+1e-12)
    s_z = np.abs(stds - s_med)/(np.std(stds)+1e-12)
    cuts = [0]
    for i,(a,b) in enumerate(idxs[1:], start=1):
        if m_z[i] > tol_mean or s_z[i] > tol_std:
            cuts.append(a)
    cuts.append(n)
    segs=[]
    for i in range(len(cuts)-1):
        a,b = cuts[i], cuts[i+1]
        if segs and (a - segs[-1][1]) < step:
            segs[-1]=(segs[-1][0], b)
        else:
            segs.append((a,b))
    return segs, {"means":means.tolist(), "stds":stds.tolist(), "idxs":idxs}

def welch_psd(x: np.ndarray, fs: float, nperseg: int=1024, noverlap: int=512, window="hann"):
    n = len(x)
    if nperseg > n: nperseg = n//2 if n//2>=16 else n
    if noverlap >= nperseg: noverlap = nperseg//2
    step = nperseg - noverlap
    if step<=0: step=1
    win = np.hanning(nperseg) if window=="hann" else np.ones(nperseg)
    scale = (fs*np.sum(win**2))
    frames=[]
    for start in range(0, n-nperseg+1, step):
        seg = x[start:start+nperseg]*win
        X = np.fft.rfft(seg)
        Pxx = (np.abs(X)**2)/scale
        frames.append(Pxx)
    if not frames:
        f = np.fft.rfftfreq(n, d=1/fs)
        P = (np.abs(np.fft.rfft(x))**2)/(fs*n)
        return f, P
    S = np.mean(frames, axis=0)
    f = np.fft.rfftfreq(nperseg, d=1/fs)
    return f, S

def fdr_bh(pvals, alpha=0.05):
    pvals = np.asarray(pvals)
    m = len(pvals)
    order = np.argsort(pvals)
    ranked = pvals[order]
    thresh = alpha * (np.arange(1, m+1)/m)
    passed = ranked <= thresh
    k = np.max(np.where(passed)) if np.any(passed) else -1
    mask = np.zeros(m, dtype=bool)
    if k>=0:
        mask[order[:k+1]] = True
    return mask

def peak_pick_psd(f, P, min_prom=0.0, min_sep=3):
    peaks=[]
    for i in range(1, len(P)-1):
        if P[i] > P[i-1] and P[i] > P[i+1]:
            left = np.max(P[:i]) if i>0 else P[i]
            right = np.max(P[i+1:]) if i<len(P)-1 else P[i]
            prom = P[i] - 0.5*(left+right)
            if prom >= min_prom:
                peaks.append((i, f[i], P[i], prom))
    peaks_sorted = sorted(peaks, key=lambda t: t[2], reverse=True)
    taken=[]
    for p in peaks_sorted:
        if all(abs(p[0]-q[0])>min_sep for q in taken):
            taken.append(p)
    return taken

def phase_randomized_surrogate(x):
    X = np.fft.rfft(x)
    mag = np.abs(X)
    phase = np.angle(X)
    rand_phase = np.random.uniform(-np.pi, np.pi, size=len(phase))
    rand_phase[0] = 0.0
    if len(rand_phase)>1 and (len(x)%2==0):
        rand_phase[-1] = 0.0
    Y = mag * np.exp(1j*rand_phase)
    y = np.fft.irfft(Y, n=len(x))
    return y

def bicoherence_summary(x, fs, nseg=8):
    n = len(x)
    seglen = n//nseg
    if seglen < 64: seglen = min(n, 256)
    X = []
    for i in range(0, n-seglen+1, seglen):
        seg = x[i:i+seglen]*np.hanning(seglen)
        X.append(np.fft.rfft(seg))
    if not X: 
        return {"max_bico":0.0,"hotspots":[]}
    X = np.stack(X, axis=0)
    F = np.fft.rfftfreq(seglen, d=1/fs)
    max_b=0.0; hot=[]
    idx = np.linspace(1, len(F)-2, 32).astype(int)
    for i in idx:
        for j in idx:
            k = i+j
            if k >= len(F): continue
            num = np.mean(X[:,i]*X[:,j]*np.conj(X[:,k]))
            den = np.sqrt(np.mean(np.abs(X[:,i]*X[:,j])**2) * np.mean(np.abs(X[:,k])**2)) + 1e-12
            b = np.abs(num)/den
            if b>max_b:
                max_b=b
            if b>0.4:
                hot.append({"f1":float(F[i]),"f2":float(F[j]),"f3":float(F[k]),"b":float(b)})
    return {"max_bico":float(max_b),"hotspots":hot[:16]}

def rational_group(peaks_f, tol=0.01, max_harm=10):
    peaks_f = sorted(peaks_f)
    bases=[]
    assigned=[False]*len(peaks_f)
    for i,f in enumerate(peaks_f):
        if assigned[i]: continue
        base=f
        group=[i]
        for j,g in enumerate(peaks_f):
            if i==j or assigned[j]: continue
            ratio = g/base
            k = round(ratio)
            if k>=1 and k<=max_harm and abs(ratio - k) <= tol:
                assigned[j]=True
                group.append(j)
        assigned[i]=True
        bases.append({"f0":base, "members":[peaks_f[k] for k in group]})
    return bases

def integer_relations(omegas, max_coeff=6, tol=1e-3):
    m=len(omegas); rels=[]
    if m<=1: return rels
    w = np.array(omegas)/omegas[0]
    rng = range(-max_coeff, max_coeff+1)
    for a in rng:
        for b in rng:
            for c in ([0] if m<3 else rng):
                k = np.array([a,b]) if m==2 else np.array([a,b,c])
                if np.all(k==0): continue
                val = abs(np.dot(k, w[:len(k)]))
                if val < tol:
                    rels.append({"k":k.tolist(), "res":float(val)})
    def normk(k):
        import math
        g=0
        for t in k: g=math.gcd(g, int(abs(t)))
        if g>0: k=[int(t//g) for t in k]
        for t in k:
            if t!=0:
                if t<0: k=[-q for q in k]
                break
        return k
    seen=set(); rels_norm=[]
    for r in rels:
        kk=tuple(normk(r["k"]))
        if kk not in seen:
            seen.add(kk); rels_norm.append({"k":list(kk),"res":r["res"]})
    return rels_norm

def cartan_hit_ratio(f, P, bases, tol=0.01, max_mn=6):
    if len(bases)==0: return 0.0
    bfreqs=[b["f0"] for b in bases]
    hits = np.zeros_like(P, dtype=bool)
    for i,fi in enumerate(bfreqs):
        for j,fj in enumerate(bfreqs):
            for m in range(1, max_mn+1):
                for n in range(1, max_mn+1):
                    target = abs(m*fi - n*fj)
                    idx = np.argmin(np.abs(f - target))
                    if abs(f[idx]-target) <= tol*max(1.0,target):
                        hits[idx]=True
    power_total = float(np.sum(P))
    power_hits = float(np.sum(P[hits]))
    return float(power_hits/power_total) if power_total>0 else 0.0

def phase_lock_score(x, bases, fs):
    if len(bases)==0: return 0.0
    from numpy.fft import rfft, irfft, rfftfreq
    N=len(x)
    X = rfft(x*np.hanning(N))
    f = rfftfreq(N, d=1/fs)
    Rs=[]
    for b in bases:
        f0=b["f0"]
        bw=max(1.0, 0.05*f0)
        mask = (f > max(0.0,f0-bw)) & (f < f0+bw)
        Y = np.zeros_like(X); Y[mask]=X[mask]
        y = irfft(Y, n=N)
        Z = rfft(y)
        H = np.zeros_like(Z); H[1:] = -1j*np.sign(f[1:])
        zh = irfft(Z*H, n=N)
        angle = np.arctan2(zh, y)
        R = np.abs(np.mean(np.exp(1j*angle)))
        Rs.append(R)
    return float(np.mean(Rs))

def energy_balance(x, fs, seg_sec=5.0):
    N=len(x); seg=int(seg_sec*fs)
    if seg<32: seg=max(32, N//8)
    vs=[]
    for i in range(0, N-seg+1, seg):
        vs.append(np.var(x[i:i+seg]))
    if len(vs)<2: return 1.0
    v = np.array(vs)
    return float(1.0/(1.0 + np.std(v)/(np.mean(v)+1e-12)))

def delta_welch_linear(P_signal, P_model):
    S = np.log10(P_signal+1e-12)
    M = np.log10(P_model+1e-12)
    return float(np.sqrt(np.mean((S-M)**2)))

def build_linear_model_psd(f, bases):
    P = np.zeros_like(f)
    for b in bases:
        f0=b["f0"]
        for k in range(1, 8):
            mu = k*f0
            width = max(0.01*mu, 0.5)
            P += 1.0/(1.0 + ((f-mu)/width)**2)
    return P / (np.max(P)+1e-12)

def receipts_and_commit(x, fs, params=None):
    params = params or {}
    segs, stat_info = segment_stationarity(x, fs)
    seg = max(segs, key=lambda ab: ab[1]-ab[0])
    xs = x[seg[0]:seg[1]]

    f, P = welch_psd(xs, fs)
    peaks = peak_pick_psd(f, P, min_prom=0.0, min_sep=3)
    peaks_f=[p[1] for p in peaks]; peaks_p=[p[2] for p in peaks]
    peak_df=pd.DataFrame({"f":peaks_f,"P":peaks_p,"prom":[p[3] for p in peaks]})

    # surrogate pvals for top K
    K = min(10, len(peaks_f))
    pvals=[]
    if K>0:
        for idx in range(K):
            target = peaks_f[idx]
            vals=[]
            for s in range(20):
                ys = phase_randomized_surrogate(xs)
                fsurr, Ps = welch_psd(ys, fs)
                j = np.argmin(np.abs(fsurr-target))
                vals.append(Ps[j])
            pv = float((np.sum(np.array(vals)>=P[np.argmin(np.abs(f-target))]) + 1) / (len(vals)+1))
            pvals.append(pv)
        # FDR
        # We don't import fdr here to keep deps simple; accept raw pvals (add BH in notebook if needed)
        peak_df["pval"]=pvals
    else:
        peak_df["pval"]=[]

    bases = rational_group(peak_df["f"].tolist(), tol=0.01, max_harm=10) if len(peak_df)>0 else []
    omegas = [2*math.pi*b["f0"] for b in bases]
    pslq = integer_relations(omegas, max_coeff=6, tol=1e-3)
    cartan_ratio = cartan_hit_ratio(f, P, bases, tol=0.01, max_mn=6)
    bico = bicoherence_summary(xs, fs, nseg=8)
    plock = phase_lock_score(xs, bases, fs) if len(bases)>0 else 0.0
    eb = energy_balance(xs, fs, seg_sec=5.0)
    P_model = build_linear_model_psd(f, bases) if len(bases)>0 else np.ones_like(f)
    dwel = delta_welch_linear(P, P_model)

    anisotropy = float(np.std(P)/ (np.mean(P)+1e-12))
    r_eff = float(np.exp(-np.sum((P/np.sum(P)+1e-12)*np.log(P/np.sum(P)+1e-12))))
    ORI = 0.4*min(1.0, dwel/0.6) + 0.2*min(1.0, anisotropy/0.3) + 0.2*min(1.0, max(0.0, r_eff-8.0)/2.0) + 0.2*min(1.0, max(0.0, 0.35-plock)/0.35)

    b1 = int(plock > 0.35)
    b2 = int(dwel < 0.08)
    b3 = int(cartan_ratio > 0.35 and bico["max_bico"] < 0.45)
    b4 = int(eb > 0.6)
    commit_bits = f"{b1}{b2}{b3}{b4}"

    receipts = {
        "phase_lock": float(plock),
        "delta_welch": float(dwel),
        "harmonic_legality": float(cartan_ratio),
        "energy_balance": float(eb),
        "ori": float(ORI)
    }
    proofs = {
        "stationarity": {"segment": [int(seg[0]), int(seg[1])]},
        "peaks": peak_df.to_dict(orient="records"),
        "bases": bases,
        "pslq_like": pslq,
        "cartan_hits": {"ratio": float(cartan_ratio)},
        "bicoherence": bico,
        "surrogates": {"peak_pvals": [float(p) for p in (peak_df["pval"].fillna(1.0).tolist() if "pval" in peak_df else [])]},
        "dissipation": {"energy_balance": float(eb)}
    }
    env = {"fs": fs, "psd": {"method":"welch"}, "tolerances":{"rational":0.01,"pslq_tol":1e-3}}
    rest_hash = sha256_hex({"receipts":receipts, "proofs":proofs})
    prr = {
        "version":"cqe.prr.v2",
        "timestamp": None,
        "input_digest": None,
        "rails":["propagation_torus","interference","harmonics","dissipation"],
        "commit_bits": commit_bits,
        "receipts": receipts,
        "proofs": proofs,
        "sidecars": [],
        "env": env,
        "rest_hash": rest_hash,
        "notes": ""
    }
    return (f, P, P_model, receipts, proofs, prr)
