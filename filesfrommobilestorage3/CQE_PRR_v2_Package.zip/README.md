# CQE PRR v2 Harness (Lite)

Implements upgraded validators & PRR v2 (no internet deps):
- Welch PSD, peak picking, surrogate p-values.
- Rational grouping, small-integer relations (PSLQ-like brute force).
- Cartan-hit ratio, bicoherence (coarse), phase-lock, energy-balance.
- ORI, 4-bit commit, PRR with proofs.

Limitations: true KPSS/ADF, multitaper, persistent homology, and E8/Leech audits are not included here; replace stubs as needed.
