
import json, time, os, hashlib
class Ledger:
    def __init__(self, path=".ledger/receipts.jsonl"):
        self.path = path; os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(path): open(path,"w").close()
    def write(self, obj):
        obj = dict(obj); obj["ts"] = time.time()
        with open(self.path,"a",encoding="utf-8") as f: f.write(json.dumps(obj)+"\n")
        return obj
    def tail(self, n=50):
        try:
            with open(self.path,"r",encoding="utf-8") as f:
                lines = f.readlines()[-n:]
            return [json.loads(x) for x in lines if x.strip()]
        except: return []
def rid_for(payload)->str:
    h = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return h[:16]
