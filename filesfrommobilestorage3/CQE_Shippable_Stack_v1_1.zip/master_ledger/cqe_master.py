
import json, os, time, hashlib, hmac

def _canon(obj): return json.dumps(obj, sort_keys=True, separators=(',',':')).encode()

class MasterLedger:
    def __init__(self, path=".ledger/master.jsonl", secret_path=".secrets/master_key.txt"):
        self.path = path
        self.secret_path = secret_path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        os.makedirs(os.path.dirname(secret_path), exist_ok=True)
        if not os.path.exists(self.path): open(self.path,"w").close()
        if not os.path.exists(self.secret_path):
            with open(self.secret_path, "w") as f: f.write("cqe-master-dev-key")

    def _secret(self) -> bytes:
        return open(self.secret_path,"rb").read().strip()

    def _tail_last_hash(self):
        last = None
        with open(self.path,"r",encoding="utf-8") as f:
            for line in f:
                if not line.strip(): continue
                last = json.loads(line)
        return last["hash"] if last else "0"*64

    def append(self, etype: str, payload, pointers=None):
        import time, json, hashlib, hmac
        ts = time.time()
        prev = self._tail_last_hash()
        rec = {"ts": ts, "type": etype, "payload": payload, "pointers": (pointers or {}), "prev": prev}
        digest = hashlib.sha256(_canon(rec)).hexdigest()
        sig = hmac.new(self._secret(), digest.encode(), hashlib.sha256).hexdigest()
        out = {"hash": digest, "rec": rec, "sig": sig}
        with open(self.path,"a",encoding="utf-8") as f:
            f.write(json.dumps(out)+"\n")
        return out

    def verify(self):
        prev = "0"*64
        idx = 0
        with open(self.path,"r",encoding="utf-8") as f:
            for line in f:
                idx += 1
                if not line.strip(): continue
                obj = json.loads(line)
                rec = obj.get("rec",{})
                if rec.get("prev") != prev: return {"ok": False, "at": idx, "err":"prev mismatch"}
                import hashlib, json
                digest = hashlib.sha256(json.dumps(rec, sort_keys=True, separators=(',',':')).encode()).hexdigest()
                if digest != obj.get("hash",""): return {"ok": False, "at": idx, "err":"hash mismatch"}
                prev = obj.get("hash","")
        return {"ok": True, "entries": idx}
