
import os, json, importlib.util
from pathlib import Path

PLUGIN_PATHS = ["/mnt/data/CQE_Universal_Superbundle_v1_1/packages_all", "/mnt/data/CQE_Universal_Superbundle_v1_1/sources"]

def _iter_py_files(base: Path):
    for p in base.rglob("*.py"):
        if p.name.startswith("__"): continue
        yield p

def discover():
    found = []
    for s in PLUGIN_PATHS:
        base = Path(s)
        if not base.exists(): continue
        for p in _iter_py_files(base):
            try:
                spec = importlib.util.spec_from_file_location(p.stem, str(p))
                if not spec or not spec.loader: continue
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                caps = []
                for name in ["geotokenize","extract_features","analyze","mdhg_signal","novelty","moonshine","viewer24","coherence"]:
                    if hasattr(mod, name): caps.append(name)
                if hasattr(mod, "REGISTER"): caps.append("REGISTER")
                if caps:
                    found.append({"path": str(p), "caps": caps})
            except Exception:
                pass
    return found

def load_feature_pipeline():
    mods = []
    for s in PLUGIN_PATHS:
        base = Path(s)
        if not base.exists(): continue
        for p in _iter_py_files(base):
            try:
                spec = importlib.util.spec_from_file_location(p.stem, str(p))
                if not spec or not spec.loader: continue
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                if any(hasattr(mod, n) for n in ["geotokenize","extract_features","analyze","mdhg_signal","novelty","moonshine"]):
                    mods.append(mod)
            except Exception:
                pass

    def compose(text: str):
        feats = {"AEGIS":{},"FIVEWH1":{},"GEO_GLOBAL":{},"GEO_LOCAL":{},"field_mass":{}}
        for m in mods:
            try:
                if hasattr(m, "geotokenize"):
                    r = m.geotokenize(text); 
                    if isinstance(r, dict):
                        feats["GEO_GLOBAL"].update(r.get("GEO_GLOBAL",{}))
                        feats["GEO_LOCAL"].update(r.get("GEO_LOCAL",{}))
                if hasattr(m, "extract_features"):
                    r = m.extract_features(text); 
                    if isinstance(r, dict):
                        for k in ["AEGIS","FIVEWH1","GEO_GLOBAL","GEO_LOCAL","field_mass"]:
                            if k in r and isinstance(r[k], dict): feats[k].update(r[k])
                if hasattr(m, "analyze"):
                    r = m.analyze(text);
                    if isinstance(r, dict):
                        for k in ["AEGIS","FIVEWH1","GEO_GLOBAL","GEO_LOCAL","field_mass"]:
                            if k in r and isinstance(r[k], dict): feats[k].update(r[k])
                if hasattr(m, "mdhg_signal"):
                    r = m.mdhg_signal(text); 
                    if isinstance(r, dict):
                        feats["GEO_GLOBAL"].update(r.get("GEO_GLOBAL",{}))
                        feats["GEO_LOCAL"].update(r.get("GEO_LOCAL",{}))
                if hasattr(m, "novelty"):
                    r = m.novelty(text); 
                    if isinstance(r, dict): feats["GEO_GLOBAL"]["Novelty"] = max(feats["GEO_GLOBAL"].get("Novelty",0.0), r.get("Novelty",0.0))
                if hasattr(m, "moonshine"):
                    r = m.moonshine(text);
                    if isinstance(r, dict): feats["field_mass"].update(r.get("field_mass",{}))
            except Exception:
                pass
        return feats
    return compose
