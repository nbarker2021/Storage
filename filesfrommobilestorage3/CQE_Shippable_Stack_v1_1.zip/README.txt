
CQE Shippable Stack v1.0 (stdlib-only)

What you get
- kernel/: CQEKernel + SpeedLight sidecar placeholder (drop-in your real speedlight_sidecar_plus.py)
- mint/: MintEngine + Wallet (receipts in .ledger/)
- analyzer/: simple_features() stub (replace with your adapters: GeoTokenizer/MDHG/Moonshine)
- server/: production-lite HTTP server exposing upload, features, mint, wallet, config
- node/: cqe_node watcher (optionally auto-mints when server toggle is enabled)
- web/: index.html SPA (upload, features, mint, wallet, config, receipts)

Run (two terminals)
1) Server
   python -c "from server.server import run; run()"
   # runs at http://127.0.0.1:8766

2) Node watcher (optional auto-mint processor)
   python node/cqe_node.py

Open the UI
- Open web/index.html in your browser (it calls the server on 127.0.0.1:8766).

Turn on coin minting
- In the UI Config tab, click "Enable Minting".

Wire your real adapters
- Replace analyzer/features.py with calls that compute AEGIS, FIVEWH1, GEO_GLOBAL, GEO_LOCAL from your toolchain.
- Or fill features via the Features tab editor before minting.

Wallet
- Credits MERIT + domain coins for each mint; `local_merit` is endorsement-only (not a coin).

Receipts
- .ledger/kernel.jsonl
- .ledger/mints.jsonl
- .ledger/wallet.json

Shipping notes
- No external dependencies; all stdlib.
- Replace sidecar with your SpeedLightPlus for full beaming & CAS + receipts chaining.
- Add capability licensing (see the earlier checkpoint) when you need sensitive routes.


v1.1 Enhancements
- CQE Master Ledger (Merkle + HMAC) with /master/verify; all ops append records + pointers.
- Adapter system autoloads from Superbundle (packages_all/ and sources/): /adapters/list and /features/extract_auto.
- Website gains Adapters and Master Ledger tabs.
