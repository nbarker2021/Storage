CQE suite (fresh) 20250919T215635Z
Run: python harness/run_cqe.py .
