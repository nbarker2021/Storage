
import json, os, sys, glob, hashlib, math
import pandas as pd

TS="20250919T215635Z"

def load(p):
    with open(p,'r') as f: return json.load(f)
def hsh(d):
    return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()

def get_min(r, key):
    v = r.get(key, None)
    if isinstance(v, dict): return v.get("min", None)
    return v
def get_max(r, key):
    v = r.get(key, None)
    if isinstance(v, dict): return v.get("max", None)
    return v

def ge_interval(r, key, thr, rc, slack_acc):
    lo = get_min(r, key)
    if lo is None or lo < thr:
        rc["pass"]=False; rc["reasons"].append(f"{key}_min<{thr} (got {lo})")
    else:
        denom = abs(thr) if abs(thr) > 1e-9 else 1.0
        slack_acc.append((lo - thr) / denom)

def le_interval(r, key, thr, rc, slack_acc):
    hi = get_max(r, key)
    if hi is None or hi > thr:
        rc["pass"]=False; rc["reasons"].append(f"{key}_max>{thr} (got {hi})")
    else:
        denom = abs(thr) if abs(thr) > 1e-9 else 1.0
        slack_acc.append((thr - hi) / denom)

def check(pack_def, ex):
    rc = {"pass": True, "reasons": []}
    r = ex.get("receipts", {})
    s = pack_def.get("strict", {})
    slack_vals = []
    name = pack_def.get("description","").lower()

    # Recognize all packs by description fragments and apply gates
    if "non-reciprocal magnetism" in name:
        if "min_chirality" in s: ge_interval(r, "chirality_score", s["min_chirality"], rc, slack_vals)
        if "min_nonrecip" in s: ge_interval(r, "nonreciprocity_index", s["min_nonrecip"], rc, slack_vals)
        if "min_gap_GHz" in s: ge_interval(r, "floquet_gap_GHz", s["min_gap_GHz"], rc, slack_vals)
        if "max_temp_rise_K" in s: le_interval(r, "max_temp_rise_K", s["max_temp_rise_K"], rc, slack_vals)

    if "hippocampal" in name:
        if "min_MI" in s: ge_interval(r, "spike_content_MI", s["min_MI"], rc, slack_vals)
        if "min_phase_R" in s: ge_interval(r, "phase_lock_R", s["min_phase_R"], rc, slack_vals)
        if "max_replay_err_cm" in s: le_interval(r, "replay_err_cm", s["max_replay_err_cm"], rc, slack_vals)

    if "macrocycle" in name or "atropisomer" in name:
        if "min_barrier_kcal" in s: ge_interval(r, "deltaG_dagger_axis_kcal", s["min_barrier_kcal"], rc, slack_vals)
        if "min_ee" in s: ge_interval(r, "er", s["min_ee"], rc, slack_vals)
        if "min_dr" in s: ge_interval(r, "dr", s["min_dr"], rc, slack_vals)
        if "min_yield_pct" in s: ge_interval(r, "yield_pct", s["min_yield_pct"], rc, slack_vals)

    if "hydrofunctionalization" in name:
        if "min_ee" in s: ge_interval(r, "ee", s["min_ee"], rc, slack_vals)
        if "min_dr" in s: ge_interval(r, "dr_alpha", s["min_dr"], rc, slack_vals); ge_interval(r, "dr_gamma", s["min_dr"], rc, slack_vals)
        if "min_site_selectivity_pct" in s: ge_interval(r, "site_selectivity_pct", s["min_site_selectivity_pct"], rc, slack_vals)
        if "min_mass_balance_pct" in s: ge_interval(r, "mass_balance_pct", s["min_mass_balance_pct"], rc, slack_vals)

    if "graphene-oxide" in name:
        if "deltaEg_window_eV" in s:
            val = r.get("deltaEg_eV", None)
            mag = abs(get_min(r,"deltaEg_eV")) if isinstance(val, dict) else abs(val if val is not None else 1e9)
            if mag > s["deltaEg_window_eV"]:
                rc["pass"]=False; rc["reasons"].append(f"|deltaEg_eV|>{s['deltaEg_window_eV']} (got {mag})")
            else:
                thr = s["deltaEg_window_eV"]; denom = abs(thr) if abs(thr)>1e-9 else 1.0
                slack_vals.append((thr - mag)/denom)
        if "min_abs_deltaPhi_eV" in s:
            val = r.get("deltaPhi_eV", None)
            mag = abs(get_min(r,"deltaPhi_eV")) if isinstance(val, dict) else abs(val if val is not None else 0.0)
            if mag < s["min_abs_deltaPhi_eV"]:
                rc["pass"]=False; rc["reasons"].append(f"|deltaPhi_eV|<{s['min_abs_deltaPhi_eV']} (got {mag})")
            else:
                thr = s["min_abs_deltaPhi_eV"]; denom = abs(thr) if abs(thr)>1e-9 else 1.0
                slack_vals.append((mag - thr)/denom)
        if "min_ads_energy_mag_eV" in s:
            val = r.get("ads_energy_eV", None)
            mag = abs(get_min(r,"ads_energy_eV")) if isinstance(val, dict) else abs(val if val is not None else 0.0)
            if mag < s["min_ads_energy_mag_eV"]:
                rc["pass"]=False; rc["reasons"].append(f"|ads_energy_eV|<{s['min_ads_energy_mag_eV']} (got {mag})")
            else:
                thr = s["min_ads_energy_mag_eV"]; denom = abs(thr) if abs(thr)>1e-9 else 1.0
                slack_vals.append((mag - thr)/denom)

    if "gauge fields in photonics" in name:
        if "min_gap_GHz" in s: ge_interval(r, "gap_GHz", s["min_gap_GHz"], rc, slack_vals)
        if "max_linewidth_GHz" in s: le_interval(r, "linewidth_GHz", s["max_linewidth_GHz"], rc, slack_vals)
        if "min_edge_Q" in s: ge_interval(r, "edge_mode_Q", s["min_edge_Q"], rc, slack_vals)

    if "spatial gene expression" in name:
        if "min_celltype_acc" in s: ge_interval(r, "celltype_acc", s["min_celltype_acc"], rc, slack_vals)
        if "min_per_cell_corr" in s: ge_interval(r, "per_cell_corr", s["min_per_cell_corr"], rc, slack_vals)
        if "min_svg_rec_k" in s: ge_interval(r, "svg_recovery@k", s["min_svg_rec_k"], rc, slack_vals)
        if "max_gpu_hours" in s: le_interval(r, "gpu_hours", s["max_gpu_hours"], rc, slack_vals)

    if "topological superconductivity" in name:
        if "min_surface_band_res_meV" in s: ge_interval(r, "surface_band_res_meV", s["min_surface_band_res_meV"], rc, slack_vals)
        if "min_zbp_robustness" in s: ge_interval(r, "zbp_robustness", s["min_zbp_robustness"], rc, slack_vals)
        if "min_odd_parity_QPI" in s: ge_interval(r, "odd_parity_QPI_score", s["min_odd_parity_QPI"], rc, slack_vals)
        if "min_bulk_gap_meV" in s: ge_interval(r, "bulk_gap_meV", s["min_bulk_gap_meV"], rc, slack_vals)

    if "entanglement characterization" in name:
        if "min_fidelity" in s: ge_interval(r, "fidelity", s["min_fidelity"], rc, slack_vals)
        if "min_N_qubits" in s: ge_interval(r, "N_qubits", s["min_N_qubits"], rc, slack_vals)
        if "max_runtime_s" in s: le_interval(r, "runtime_s", s["max_runtime_s"], rc, slack_vals)

    if "transfer methylation" in name:
        if "min_yield_pct" in s: ge_interval(r, "yield_pct", s["min_yield_pct"], rc, slack_vals)
        if "min_chemoselect_pct" in s: ge_interval(r, "chemoselect_pct", s["min_chemoselect_pct"], rc, slack_vals)
        if "min_quantum_yield" in s: ge_interval(r, "quantum_yield", s["min_quantum_yield"], rc, slack_vals)

    if "photonic neural network" in name:
        if "min_TOPS" in s: ge_interval(r, "TOPS", s["min_TOPS"], rc, slack_vals)
        if "max_pJ_per_MAC" in s: le_interval(r, "pJ_per_MAC", s["max_pJ_per_MAC"], rc, slack_vals)
        if "min_acc_top1_pct" in s: ge_interval(r, "acc_top1_pct", s["min_acc_top1_pct"], rc, slack_vals)
        if "max_latency_ms" in s: le_interval(r, "latency_ms", s["max_latency_ms"], rc, slack_vals)

    if "quantum ising" in name and "2d" in name:
        if "min_level_spacing_r" in s: ge_interval(r, "level_spacing_r", s["min_level_spacing_r"], rc, slack_vals)
        if "min_otoc_growth" in s: ge_interval(r, "OTOC_growth_rate", s["min_otoc_growth"], rc, slack_vals)
        if "min_ent_slope" in s: ge_interval(r, "ent_entropy_slope", s["min_ent_slope"], rc, slack_vals)
        if "max_eth_kld" in s: le_interval(r, "ETH_KLD", s["max_eth_kld"], rc, slack_vals)
        if "min_quasi_charge_residual" in s: ge_interval(r, "min_quasi_charge_residual", s["min_quasi_charge_residual"], rc, slack_vals)

    slack_mean = float(sum(slack_vals)/len(slack_vals)) if slack_vals else 0.0
    tier = "HARD_SIM" if rc["pass"] else "SKETCH"
    return rc, slack_mean, tier

def main(root):
    packs_dir = os.path.join(root,"packs")
    ex_g_dir = os.path.join(root,"examples","golden")
    ex_b_dir = os.path.join(root,"examples","baseline")
    report_path = os.path.join(root,"reports","summary.csv")
    pack_defs = {os.path.splitext(os.path.basename(p))[0]: load(p) for p in glob.glob(os.path.join(packs_dir,"*.yaml"))}

    rows = []
    for cls, d in [("golden", ex_g_dir), ("baseline", ex_b_dir)]:
        for ex in glob.glob(os.path.join(d, "*.yaml")):
            exd = load(ex)
            pack_name = exd.get("pack")
            stem = os.path.splitext(os.path.basename(ex))[0]
            if pack_name not in pack_defs:
                rc = {"pass": False, "reasons": [f"unknown pack {pack_name}"]}
                slack_mean, tier = 0.0, "SKETCH"
            else:
                rc, slack_mean, tier = check(pack_defs[pack_name], exd)
            rows.append({
                "class": cls,
                "pack": pack_name,
                "id": exd.get("id", stem),
                "fourbit": exd.get("fourbit","----"),
                "pass": rc["pass"],
                "commit_tier": tier,
                "slack_mean": round(slack_mean, 4),
                "reasons": "; ".join(rc["reasons"]),
                "receipts_kind": exd.get("receipts_kind","scalar"),
                "sim_model_id": exd.get("sim",{}).get("model_id",""),
                "sim_model_hash": exd.get("sim",{}).get("model_hash",""),
                "receipts_hash": hsh(exd.get("receipts", {})),
                "timestamp_utc": TS
            })
    df = pd.DataFrame(rows)
    df.to_csv(report_path, index=False)
    agg = df.groupby(["pack","class"])["pass"].mean().reset_index().rename(columns={"pass":"pass_rate"})
    agg.to_csv(os.path.join(root,"reports","per_pack_pass_rates.csv"), index=False)
    df.to_csv(os.path.join(root,"reports","commit_ledger.csv"), index=False)
    print("WROTE", report_path)

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv)>1 else ".")
