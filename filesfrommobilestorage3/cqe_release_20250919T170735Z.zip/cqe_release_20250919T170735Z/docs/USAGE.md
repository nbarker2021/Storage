# How to run CQE on a baseline

1. Choose a baseline in `baselines/` and read its `meaning_pack` value.
2. Open the corresponding `packs/PACK_*.yaml` to see knobs, octet views, receipts, and strict thresholds.
3. On paper or in your tools, execute:
   - Stand-ins (tokens) with units/guards
   - Octet overlays (8 views)
   - Mirror (forward/back)
   - Δ-lift (local repair)
   - Strict ratchet (tighten tolerances)
4. Record receipts and write a 4-bit code to the baseline's `commit.fourbit_code`.
5. Update `status` to `WORKING` if the pass is clean; otherwise leave as `PROVISIONAL` and log why.