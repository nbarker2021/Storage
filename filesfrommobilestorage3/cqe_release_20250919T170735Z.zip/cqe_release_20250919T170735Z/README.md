# CQE Release (20250919T170735Z)

This repository is auto-assembled from your paper link files. It provides:

- `baselines/` — one **baseline YAML per paper URL**, with rail and PACK mapping (provisional).
- `packs/` — **six domain packs** (and a generic fallback) with knobs, octet views, receipts, and strict gates.
- `ledgers/baseline_index.csv` — structural validation results and mapping (no external fetch required).
- `schemas/` — JSON schema for baseline files.
- `docs/` — usage notes.

## What "validated" means here
This release performs **structural validation** only (URL presence, hashing, rail+PACK mapping). It does **not** parse or score papers.
Use the PACK templates to run CQE gates (octet → mirror → Δ-lift → strict) and then write **4-bit commits** back into each baseline YAML.

## Quick start
1. Pick a `baselines/paper_XXXX.yaml` with a non-GENERIC PACK.
2. Open the corresponding `packs/PACK_*.yaml` and create stand-in tokens for your experiment/model.
3. Run the octet views, perform mirror tests, apply Δ-lifts if needed, tighten strict.
4. Fill `commit.fourbit_code` and append receipts (hashes/metrics).
5. Mark `status: WORKING` or leave as `PROVISIONAL`.

## Provenance
- Built from: Links 2_250918_122552.txt, Paper links 1_250918_122445.txt
- UTC: 20250919T170735Z