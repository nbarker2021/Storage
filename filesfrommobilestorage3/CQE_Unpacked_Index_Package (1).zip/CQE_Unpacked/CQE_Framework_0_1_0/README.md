
# CQE Framework (seed)

This repository is the *full framework* skeleton that ingests **verified** CQE units and exposes them via a minimal SDK.

## Layout
- `registry/verified_index.(json|csv)`: canonical list of verified units with metrics
- `modules/<rails>/id_<id>/module.json`: spec for each unit
- `modules/<rails>/id_<id>/stub.py`: placeholder runner hook for that unit
- `sdk/cqe/`: tiny SDK with `Registry` and `Runner`
- `receipts/`: snapshots of wrapper receipts & ledger for audit
- `tests/`: smoke tests for registry/runner

## Quick start
```python
from pathlib import Path
from sdk.cqe import Registry, Runner

root = Path("cqe_framework")
reg = Registry(root)
print("Verified ids:", reg.ids())

first = reg.get(reg.ids()[0])
out = Runner(root).run_module(first.id, first.rails, data={"example": True})
print(out)
```

## Notes
- Module stubs are placeholders; in a full deployment they would invoke the compiled kernels/overlays for each id.
- Registry rows carry OPE/FCE metrics and mirror votes; receipts are snapshotted for traceability.
