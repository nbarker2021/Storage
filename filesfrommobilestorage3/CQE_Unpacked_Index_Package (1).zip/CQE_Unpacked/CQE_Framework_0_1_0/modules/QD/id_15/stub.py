# Auto-generated CQE module stub
from pathlib import Path
import json, pandas as pd

def run(data=None, overlays=True):
    """Run the verified module id=15 (rails=QD) in placeholder mode.
    - Loads registry metrics, prints a compact receipt.
    - In a real deployment, this would call the module's kernel.
    """
    root = Path(__file__).resolve().parents[3]  # up from modules/<rails>/id_x/
    reg  = root/'registry'/'verified_index.json'
    rows = json.loads(reg.read_text())
    row = next((x for x in rows if x['id']==15), None)
    if not row:
        return {"id": 15, "status": "error", "reason": "not in registry"}
    out = {"id": 15, "rails": "QD", "status":"verified", "metrics": row["metrics"]}
    if overlays:
        # surface OPE/FCE and mirrored votes from receipts (if present)
        rec_path = root/'receipts'/'wrapper_receipts_latest.csv'
        if rec_path.exists():
            df = pd.read_csv(rec_path)
            pick = df[df['id']==15].tail(1)
            if not pick.empty:
                out["receipts"] = pick.iloc[-1].to_dict()
    return out