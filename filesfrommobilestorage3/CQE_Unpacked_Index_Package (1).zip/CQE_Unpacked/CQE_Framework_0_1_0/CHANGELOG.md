
# Changelog

## 0.1.0 — 2025-09-19
- Initial framework skeleton
- Verified registry from plan/ledger/wrapper receipts
- Module stubs per verified id
- Mini SDK (Registry/Runner)
- Receipts snapshot and smoke tests
