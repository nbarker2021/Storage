
from pathlib import Path
from sdk.cqe import Registry

def test_registry_loads():
    root = Path(__file__).resolve().parents[1]
    reg = Registry(root)
    ids = reg.ids()
    assert isinstance(ids, list)
    assert all(isinstance(i, int) for i in ids)
