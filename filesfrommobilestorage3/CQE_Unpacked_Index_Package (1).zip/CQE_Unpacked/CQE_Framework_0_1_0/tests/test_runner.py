
from pathlib import Path
from sdk.cqe import Registry, Runner

def test_run_first_verified():
    root = Path(__file__).resolve().parents[1]
    reg = Registry(root)
    ids = reg.ids()
    if not ids: return
    e = reg.get(ids[0])
    rr = Runner(root).run_module(e.id, e.rails)
    assert rr.get("status") in ("verified","error")  # smoke test
