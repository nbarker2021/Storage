
import json
from pathlib import Path
from dataclasses import dataclass

@dataclass
class Entry:
    id: int
    rails: str
    status: str
    metrics: dict
    url: str
    domain: str
    seed: int

class Registry:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.path = self.root / "registry" / "verified_index.json"
        self._rows = json.loads(self.path.read_text()) if self.path.exists() else []

    def ids(self):
        return [r["id"] for r in self._rows]

    def get(self, id: int) -> Entry | None:
        r = next((x for x in self._rows if x["id"]==id), None)
        if not r: return None
        return Entry(id=r["id"], rails=r["rails"], status=r["status"], metrics=r["metrics"],
                     url=r.get("url",""), domain=r.get("domain",""), seed=int(r.get("seed",0)))

    def by_rails(self, rails: str):
        return [self.get(r["id"]) for r in self._rows if r["rails"]==rails]
