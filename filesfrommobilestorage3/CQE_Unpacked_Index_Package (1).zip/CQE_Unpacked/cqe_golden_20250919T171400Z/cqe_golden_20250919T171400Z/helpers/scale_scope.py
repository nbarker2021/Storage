def scale_up(value, factor): 
    return value * factor

def scale_down(value, factor): 
    return value / factor if factor != 0 else value

def normalize_range(x, lo, hi):
    if hi == lo: return 0.0
    return max(0.0, min(1.0, (x - lo) / (hi - lo)))

# Unit conversions
def c_to_k(c): return c + 273.15
def k_to_c(k): return k - 273.15

def ev_to_j(ev): return ev * 1.602176634e-19
def j_to_ev(j): return j / 1.602176634e-19

def ghz_to_hz(ghz): return ghz * 1e9
def hz_to_ghz(hz): return hz / 1e9

def db_to_linear(db):
    # magnitude ratio
    return 10.0 ** (db / 20.0)

def linear_to_db(r):
    import math
    return 20.0 * math.log10(max(r, 1e-12))