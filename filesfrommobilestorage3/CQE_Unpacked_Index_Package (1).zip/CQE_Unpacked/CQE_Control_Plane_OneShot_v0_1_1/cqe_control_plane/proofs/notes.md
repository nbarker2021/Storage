Proof notes placeholder
