# Worked Example — Toroidal Telescope (by hand)

Sidecars: OPTICS (S2), THERMAL (S7), POLAR (S11), MATH (S0), STORAGE (S9).

OPTICS: PSF FFT/iFFT parity; Δ‑lift astig; WFE 25→22 nm; fourbit 1011.
THERMAL: cadence parity; shorten vent 1 tick; ΔT_tick ≤ 0.8 K; fourbit 1101.
POLAR: L/R + LinX/LinY rotations; AR ≤ 1.5 dB; eff ≥ 0.85; fourbit 1010.
MATH: Rayleigh units + interval; fourbit 1001.
STORAGE: write/read parity; burst shaping; fourbit 1110.

Commit → Master (pointers only). Then write the plan.
