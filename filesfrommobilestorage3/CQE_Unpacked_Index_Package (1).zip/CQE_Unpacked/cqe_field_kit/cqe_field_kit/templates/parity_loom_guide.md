# Parity Loom (Construction‑A / Golay / E8–Leech by hand)

- Make a foam/peg board with 8 twines (E8) or 24 (Leech).
- **Construction A (binary):** lattice points are integer vectors whose residues mod 2 lie in a code C.
  Test membership with XOR on a syndrome pad; place clips for parity 1s.
- **E8:** use extended Hamming (8,4,4). Two root families: (±1,±1,0,…,0) and (±1/2,…,±1/2) with even minus count.
  Draw half‑shift marks; mirror overlay must align (pal rest).
- **Leech:** from extended Golay (24,12,8) plus glue. Enforce octads (weight‑8) using masks; rethread via simple permutations.

Mirror test: lay tracing paper over the braid; reflect and check alignment within tolerance.
All steps are **finite**: parity checks, half‑shifts, and clip moves. No black boxes.
