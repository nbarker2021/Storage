# Non‑Working Album Slip (EXO / partial)

bundle: _________________________    sidecar: ____________    page: ___

reason_codes:  □ no_iso_move  □ no_residue_improvement  □ budget_exhausted  □ trivial_rails  □ collision
path_hash: _____________________    reattach_of (if any): __________________

breadcrumbs (what nearly worked): ______________________________________
