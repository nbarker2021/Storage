# Master Ledger (pointer‑only; never blends local traces)

work_id/session: ________________________________   date: __________

| slot | sidecar | entry_hash/commit_hash | fourbit | receipts_rollup |
|------|---------|------------------------|---------|------------------|
|      |         |                        |         |                  |
|      |         |                        |         |                  |

Quadratic edges (sparse): _____________________________________________

**Rule:** master stores pointers and rollups only. Local ledgers remain sealed.
