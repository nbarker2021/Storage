# 4‑bit Commit Strip (choose one face only)

R1 □  R2 □  R3 □  R4 □     fourbit: _ _ _ _    (e.g., 1 0 1 1)

Face selection rule (PGFS): pick the four orthogonal views with
max Hamming distance, min cross‑covariance, highest stability votes.
Everything else stays as overlays for replay/diagnostics.
