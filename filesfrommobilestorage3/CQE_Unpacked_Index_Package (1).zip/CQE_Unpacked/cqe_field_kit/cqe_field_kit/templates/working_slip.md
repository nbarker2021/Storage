# Working Album Slip (portable proof)

bundle: _________________________    sidecar: ____________    page: ___

rest_hash: _______________________    schema_ver: _________
fourbit: ____   views_face: [____, ____, ____, ____]
receipts (hash or short list): _________________________________________
hue16: ______  grad: ______

Notes: _________________________________________________________________
