# One‑Sheet Run Checklist

1) Stand‑ins ready (units, guards, calibration) □
2) DNA‑10 saved □
3) Octet sketched; View‑Accrual Mode on □
4) Mirror forward↔inverse; Δ‑lifts until stable □
5) Strict ratchet after each pass □
6) Fills covered (FVA) & debt slope < τ □
7) Pick face (PGFS), shade 4‑bit □
8) Seal slips + pointer‑only Master □
9) Bind semantics; write plan □
