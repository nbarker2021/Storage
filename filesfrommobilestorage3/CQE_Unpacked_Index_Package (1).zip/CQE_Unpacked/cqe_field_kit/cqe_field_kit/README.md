# CQE Field Kit (Human-Run Edition)

This kit lets a human run CQE **by hand** with paper + colored pens, exactly as described:
**Code → Lattice → Overlay → Mirror → Commit**, with **stand-ins only** until a **4‑bit** commit.
It includes templates for Stand‑in cards, DNA‑10 state saves, Octet overlays, Commit strips,
Working/Non‑Working albums, a pointer‑only Master Ledger, and a Parity‑Loom guide (Construction‑A/Golay).

**Core doctrine (one page)**: Mirror first · One face commit · Sealed ledgers · Multi‑validation always on · Semantics last.
