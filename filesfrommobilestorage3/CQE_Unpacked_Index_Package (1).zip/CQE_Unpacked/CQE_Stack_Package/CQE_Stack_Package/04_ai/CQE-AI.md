# CQE‑AI — An AI that Natively Speaks CQE

## Agents
- **Planner**: turns prompts into bundles; chooses rails & iso‑constraints.
- **Rail Designer**: suggests orthogonal views; certifies independence.
- **Repairer (Δ‑lift Synthesis)**: proposes monotone rewrites with proofs.
- **Orchestrator**: runs sidecars with View‑Accrual Mode & Pareto face pick.
- **Evidence Manager**: merges commits, monitors collisions, rotates rails.
- **Citation/Meaning Binder**: binds semantics only after commit.

## Safety
- Pattern‑only exploration; semantics last.
- Cross‑bundle conflict corridors for high‑stakes digestion.
- Adversarial octets and rail rotation by policy.
