# CQE‑L — The Cartan Quadratic Equivalence Language

## Goals
- Model **rails, iso‑constraints, views, mirrors, Δ‑lifts, strict ratchets, receipts**.
- Compose **micro‑languages** that scale by **2/4/8/64** without semantic drift.
- Late‑bind semantics: stand‑ins first; bind after commit.

## Core Types
```
rail      ::= name {metric, threshold, guard}
view      ::= name {plan, cost, deps}
mirror    ::= {forward: op, inverse: op, epsilon}
delta     ::= {rewrite, pre, post, monotone_proof}
strict    ::= {tighten: rule, guard}
receipt   ::= {rest_hash, fourbit, hue16, schema_ver, receipts_hash, seed, provenance}
token     ::= {id, kind, unit, value?, guard, hue16, grad, salted_hash}
bundle    ::= {tokens, dna10, views[≤8], mirrors, deltas, stricts}
commit    ::= receipt when passes(bndl)
```
## Micro‑languages
- **CQE‑L/2** (atoms): tokens, guards, units.
- **CQE‑L/4** (faces): rails, iso‑constraints, 4‑bit commit.
- **CQE‑L/8** (octets): view orchestration, mirror pairs.
- **CQE‑L/64** (routing): backplane, provenance, automorphisms.

## Example (CQE‑L/4)
```
rails {
  R: metric="whiteness", thresh>=0.92
  E: metric="consistency", thresh>=0.95
  F: metric="fidelity",   thresh>=0.90
  W: metric="width",      thresh<=0.10
}
iso { target: "A600,A800 fixed", leak<=0.01 }
commit face{ R,E,F,W }
```
## Example (CQE‑L/8)
```
octet {
  v1: airy_psf(); v2: pupil_fft(); v3: zernike_sweep(); v4: phase_retrieval();
  v5: mtf_est();  v6: stray_supp(); v7: stop_sens();    v8: actuator_model();
}
mirror { forward=pupil_fft, inverse=ifft, epsilon=1e-3 }
delta  { rewrite=zernike_astig_fix, monotone_proof="WFE↓ & others !↑" }
strict { tighten WFE_nm to 22 }
```
## Compilation
- CQE‑L → **Commit IR (CIR)** (binary) → **Runner** (sidecars) → receipt.
- Deterministic: CIR is content‑addressed by Merkle over syntax trees.
