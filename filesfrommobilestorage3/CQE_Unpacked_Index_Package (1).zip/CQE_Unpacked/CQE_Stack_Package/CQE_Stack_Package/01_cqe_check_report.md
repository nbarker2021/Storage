# Session Binary Checks (CQE lite)

Rule: each item gets a **single binary gate** first. If PASS → accept. If FAIL → run full CQE (octet, mirror, Δ‑lift, strict), then re‑test.

| Item | Binary Gate | Result | Action |
|---|---|---|---|
| Opinions (OS‑level stance, 4/8/64 wrap) | Parity with prior invariants | PASS | Accepted |
| Field Kit (human‑run) | Mirror vs session traces (consistency) | PASS | Accepted |
| Forms Registry (Leech/M24) | Commit schema completeness | PASS | Accepted |
| Sidecar pattern (math/optics/thermal/polar) | 4‑view coverage | PASS | Accepted |
| API/Chain pricing | Economic fairness test (toy) | FAIL | Ran full CQE: added octet (burst, latency, region, cache, replay, fraud, audit, legal); Δ‑lift: cap+grace; strict: proof‑of‑replay required → PASS |
| 64/field sidecar coverage | Discriminability sufficiency | FAIL | Full CQE: octet of independence tests; Δ‑lift: tag lattice + collision monitor; strict: promote to 8‑bit on alias → PASS (provisional) |

**Receipts (abbrev)**: mirror votes, view votes, and Δ‑lift notes included inline in each spec below.
