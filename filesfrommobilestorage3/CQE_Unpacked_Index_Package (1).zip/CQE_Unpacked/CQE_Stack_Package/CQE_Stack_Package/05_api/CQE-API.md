# CQE Public API + Chain

## Commit Envelope (CQR-0001)
```json
{
  "rest_hash": "...",
  "fourbit": "1011",
  "hue16": "0xE3AF",
  "schema_ver": "v1",
  "receipts_hash": "...",
  "seed": 1337,
  "provenance": {"runner":"cqe-os/1.0","sidecars":["OPTICS","MATH"]},
  "signature": "ed25519:..."
}
```

## REST Endpoints (sketch)
- `POST /bundles` — create bundle (stand-ins only).
- `POST /run` — execute; returns EXO or Working commit.
- `GET /commits/{hash}` — fetch receipt + minimal proof.
- `POST /meaning/bind` — bind semantics to Working tokens.

## Pricing (wrapper‑based)
- **Per-call base** + **per‑wrapper size** (bytes of overlays+receipts) + **octet coverage bonus** (discount) + **replay credit** (cache hit rebate).

## Chain
- Public, lightweight **CommitChain**: Merkle‑linked commits; zk‑friendly summaries optional.
- Notarizes existence/time; data stays off‑chain in CC (content‑addressed).
