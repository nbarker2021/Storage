# Astronomy Sidecars

- S00 — COSMOS_LENSING
- S01 — PSF_DEBLUR
- S02 — PHOTOZ_PRIOR
- S03 — SUBHALO_PERTURB
- S04 — TIME_DELAY
- S05 — FLAT_FIELD
- S06 — DARK_CURRENT
- S07 — STRAY_LIGHT
- S08 — TRACKING_JITTER
- S09 — CAL_STAR_RAIL
- S10 — SPECTRO_LINE_FIT
- S11 — ATMOS_MODEL
- S12 — SIDEBAND_CHECK
- S13 — SUN_GLINT_GUARD
- S14 — STAR_CROWDING
- S15 — ROLL_CALIB

**Template to 64**: replicate views across 8 bands × 8 regimes; auto-tag by hue16 and enforce collision monitors.
