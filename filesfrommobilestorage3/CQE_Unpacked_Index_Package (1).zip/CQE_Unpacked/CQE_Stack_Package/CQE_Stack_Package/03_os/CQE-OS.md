# CQE‑OS — An Operating System for Evidence Machines

## Kernel Primitives
- `rest()` — build palindromic rest under iso‑constraints.
- `octet()` — orchestrate ≤8 views; share residual caches.
- `mirror()` — enforce forward∘inverse≈I; collect votes.
- `delta()` — apply monotone local repairs with non‑regression checks.
- `strict()` — ratchet bounds post‑pass.
- `commit()` — emit receipt (4‑bit) & ledger entries.

## Subsystems
- **Receipt Bus** (RB): append‑only topic; ingests only commits.
- **Commit Cache** (CC): content‑addressed store ⇒ global reuse.
- **Sidecar Scheduler** (SS): 64‑slot backplane; budgeted beam search.
- **Ledger FS (CQEFS):** bundles as dirs, slips as files; `/.octet/` overlays.
- **Security**: signed commits; cross‑bundle conflict corridors mandatory for high‑stakes.
- **IO**: semantics adapters bind **after** commit; stand‑ins only on ingress.

## Process Model
- Tasks are **bundles**. System calls manage runs; every executable returns `(value?, receipt|EXO)`.
