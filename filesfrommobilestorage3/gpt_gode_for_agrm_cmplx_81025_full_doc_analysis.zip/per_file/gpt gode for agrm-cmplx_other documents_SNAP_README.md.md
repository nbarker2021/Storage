# File: gpt gode for agrm-cmplx/other documents/SNAP_README.md

**Lines:** 43 | **Words:** 205

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Text


# SNAP Subsystem (State Save, Management, Adoption)

**SNAP** is a universal state system. It can capture any data (tokens, documents, kernel ops, etc.)
into a typed, versioned **SNAPRecord**, persist it, and later **adopt** it back into a live context.

## Key Concepts
- **SNAPRecord**: immutable JSON manifest (`id`, `type`, `meta`, `payload`, `links`, `version`).
- **SNAPType**: pluggable behavior per type: `normalize`, `validate`, `adopt`.
  - Included: `SNAPToken`, `SNAPDoc`, `SNAPKernel`.
- **Storage**: `MemoryStorage` and `FileStorage` (content-addressed by `sha256`).
- **Adoption**: turns saved payloads into runtime-usable forms.

## Quickstart
```python
from bestof_agrm.snap import SNAP, FileStorage, SNAPToken, SNAPDoc, SNAPKernel
from bestof_agrm.snap.types import register_snap_type

store = FileStorage("/tmp/snapstore")
snap = SNAP(store, {"SNAPToken": SNAPToken(), "SNAPDoc": SNAPDoc(), "SNAPKernel": SNAPKernel()})

# Save a token stream
tid = snap.save("SNAPToken", {"tokens": ["hello","world"], "vocab": {"hello":1,"world":2}})

# Save a document focus
did = snap.save("SNAPDoc", {"segments": ["Para 1."," Para 2."], "focus": [{"topic":"A","span":[0,6]}]})

# Save a kernel plan
kid = snap.save("SNAPKernel", {"ops": ["load A","map f","reduce"], "env": {"CUDA": "12.3"}})

# Adopt back
replay = snap.adopt(tid)     # -> dict usable to replay tokens
view   = snap.adopt(did)     # -> concatenated text + focus
plan   = snap.adopt(kid)     # -> ops/env restorable plan
```

## Extending
Implement a new type class with `normalize`, `validate`, `adopt`, then register:
```python
class SNAPMyType: ...
register_snap_type("SNAPMyType", SNAPMyType())
```
