# File: gpt gode for agrm-cmplx/starting docs/e8 system inintal attempt explaination.txt

**Lines:** 328 | **Words:** 1888

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 7
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 13
- golden: 6
- glyph: 8
- lattice: 14

---

## Full Text

Big picture: what this system is
We’re building a retrieval/routing and memory platform whose geometry is anchored in an 8-dimensional space inspired by the E8 root system. Data (“glyphs”) live in that space, are bucketed into “houses” by a two-tier hash (fast Tier-1 geometry + trainable Tier-2 semantics), and are compared/organized using shells (concentric neighbor sets) with governance (promotion policies, probes like recency/novelty/contradiction risk). Queries route through promoted shells under a latency budget controlled by a measured budget controller. Everything is persisted (SQLite), observable (metrics, reports, UI), and now multi-tenant.

Geometry & E8: how the 8-D world is set up
We work in ℝ⁸ (“safe cube”). Every glyph/document/user datum maps to a unit vector v ∈ ℝ⁸ via a deterministic embedding (for demos we use seeded pseudo-vectors; in production you’d plug a real encoder).

E8 shows up as a structuring scaffold: the 240 E8 root directions and their neighbor graph give us canonical directions and a “geodesic” notion (path length on the root graph). We use those to:

Build local shells around a center vector (neighbors at increasing “k” steps).

Define an auxiliary geodesic score (currently a lightweight proxy; see “What’s unfinished”).

Why E8 helps: dense, highly symmetric packing ⇒ good coverage around a point, low distortion when you quantize directions, and nice neighbor structure for shelling.

Houses: two-tier hashing (Tier-1 geometry, Tier-2 semantics)
Goal: fan-out fast to “likely” neighbors before doing more expensive scoring.

Tier-1 (geometric) hash: a simple, cheap locality-sensitive signature from the 8-D vector (e.g., signs of a small projection bank). This spreads vectors spatially with very low cost.

Tier-2 (semantic) hash: a trainable bit vector (e.g., 64-bit) whose weights you can learn to make buckets reflect semantic neighborhoods, not just geometry.

Trainer optimizes three families of terms:

Balance (each bit ~50/50 across the corpus) to avoid dead/constant bits.

Decorrelation (bits don’t collapse onto each other).

Pairwise supervision (pull similar pairs together, push dissimilar apart).

We export/import Tier-2 weights, evaluate bit imbalance, bucket occupancy, recall@K, and measure migration churn when changing weights (how many items move houses).

House key = (Tier-1, Tier-2). Lookup hits a small set of houses (“hot zones”), then we re-rank candidates.

Using it

bash
Copy
Edit
# Train semantic hash on synthetic pairs, save weights
python -m lattice_ai.tests.hash_train --steps 400 --out /mnt/data/weights.json

# Evaluate recall/latency/occupancy with or without weights
python -m lattice_ai.tests.hash_eval_suite
python -m lattice_ai.tests.hash_eval_suite --weights /mnt/data/weights.json

# Estimate churn before adopting new weights
python -m cli.hash_migrate --new /mnt/data/weights.json
Benefits

Very fast prefilter with good recall once Tier-2 is tuned.

Safe upgrades: churn metrics + consistent hashing minimize bucket thrash on reweights.

Shelling: concentric neighborhoods + promotion governance
Goal: maintain curated, auditable neighborhoods (shells) around important centers (topics, users, tasks).

Shell k = the k-th ring of neighbors around a center glyph, derived via E8-anchored neighbor building (k=1 closest ring, larger k broader context).

QA suite computes:

Size (avoid tiny brittle shells)

Coherence: mean cos(xᵢ, center). Higher ⇒ tighter topical focus.

Redundancy: mean cos(xᵢ, xⱼ). Lower ⇒ more diverse, less duplication.

Domain score: external signal if you supply one (optional).

Policies (per domain/tenant) set thresholds: min_size, min_coherence, max_redundancy, etc. The promotion step flips a shell from candidate → promoted when it meets policy.

Probes enrich metrics:

Recency: freshness from timestamps (auto-stamped when glyphs land).

Novelty: diversity vs. the center (1 − cosine on average).

Contradiction risk: detect multiple conflicting claims across members; if conflicts exist, we can quarantine.

Auto-expand: if promotion coverage is low or flip-rate is high, we expand to deeper shells (k+Δ) and re-evaluate.

Using it

nginx
Copy
Edit
# Build shells around a center and promote under default policy
curl -X POST "http://localhost:8000/build_shells/root::0" -H "X-API-Key: <key>" -H "X-Tenant: <tenant>"

# See promotion decisions (+ probe metrics)
curl "http://localhost:8000/reports/root::0" -H "X-Tenant: <tenant>"
Benefits

Auditable, explainable neighborhoods (reports say why a shell is promoted).

Dynamic breadth: shells expand when uncertainty/flip-rate indicates thin coverage.

Router & scoring (α/β blending) under a latency budget
Goal: return strong results while guaranteeing p95 latency.

Two-stage routing

Prefilter by houses (Tier-1+Tier-2 key) → a few dozen/hundred candidates.

Exact re-rank on the short list.

Score model (blended):
score = α · cosine + β · gscore, where gscore = 1 / (1 + geodesic distance) (currently proxied).

Defaults to cosine (α=1, β=0).

You can tune α/β per domain/tenant with an offline grid search on a validation set.

Budget Controller

v2: measure prefilter + exact cost and iteratively shrink candidates k until within budget.

v3: tiny learned linear cost model (latency ≈ a·k + b) updated online; picks k before querying; still shrinks if needed.

You set the p95 target (e.g., 20–25 ms).

Using it

nginx
Copy
Edit
# Budgeted query
curl "http://localhost:8000/query_budgeted?center_id=root::0"

# Tune α/β (offline) and set for a domain
python -m lattice_ai.tests.tune_scorer
curl -X POST "http://localhost:8000/scorer/docs?alpha=1.2&beta=0.2"
Benefits

Predictable p95 latency with minimal recall loss.

Per-domain tuning gets a free lift in recall@K at the same budget.

Per-datum lattices (local maps) & guarded KV memory
Goal: each datum can carry a small local transform and key-value memory—with safety rails.

Each item can have a per-datum lattice with:

Anchor pairs (global ↔ local) and a (currently identity) map; KPI for round-trip distortion so we can detect drift.

KV memory with capabilities (read/write tags). Writes go through add_memory_guarded(key, value, required_cap).

Templates to initialize new items consistently per domain.

Using it

nginx
Copy
Edit
python -m lattice_ai.tests.per_datum_kpi_demo
# prints round-trip distortion and demonstrates capability-guarded KV writes
Benefits

Future-proof slot for task- or user-specific adaptations with measurable distortion.

Built-in permission checks to avoid accidental leakage.

Governance & safety: contradiction sweeps, quarantine, audit trail
Claims: you can attach factual claims (subject, predicate, value, source) to glyphs.

Contradiction sweeps group claims by (subject, predicate) across promoted members; if multiple values exist, that shell is quarantined until resolved.

Promotion reports are persisted with metrics, policy used, and probe outputs so you can review decisions.

Using it

nginx
Copy
Edit
# Add conflicting claims for demo
curl -X POST "http://localhost:8000/claims?subject=S1&predicate=p&value=A&source=root::0"
curl -X POST "http://localhost:8000/claims?subject=S1&predicate=p&value=B&source=root::1"

# Enqueue a contradiction sweep
curl -X POST "http://localhost:8000/enqueue?name=contradiction_sweep&center_id=root::0"
curl "http://localhost:8000/tasks"
Benefits

Safety first: prevents contradictory evidence from silently contaminating promoted context.

Clear “why” for every decision; easy post-mortems.

Ops & multi-tenancy
Persistence: SQLite with migrations, indices, and tables for glyphs, houses, neighbors, house_items, shells, promotion_reports, claims, policies, schedules, tenants, probe cache.

Background jobs:

JobRunner + Scheduler for periodic tasks (contradictions, hot clusters, shell re-eval).

TaskQueue with retries + backoff + retention; enqueue work via REST and check status.

Metrics: counters, gauges, histograms exposed at /metrics (p50/p95 latency, candidate sizes, etc.). Simple UI at /ui.

Multi-tenancy: every table has tenant_id. REST writes/reads are tenant-scoped; per-tenant keys via /tenants. Single-tenant mode also supported via an env API key.

Using it

nginx
Copy
Edit
# Start service
uvicorn rest.app:app --host 0.0.0.0 --port 8000

# Create a tenant
curl -X POST "http://localhost:8000/tenants?tenant_id=acme&api_key=acme-secret"

# Operate as tenant
curl -X POST "http://localhost:8000/glyphs" -H "X-API-Key: acme-secret" -H "X-Tenant: acme" -d '{"id":"root::0"}'
curl "http://localhost:8000/metrics"        # counters are tenant-tagged inside
open http://localhost:8000/ui               # dashboard: Metrics, Houses, Reports, Policy & Scorer controls
Benefits

Safe by design (no cross-tenant leaks).

Operable without babysitting: jobs, metrics, schedules, and a smoke test.

Evaluation & guardrails (goldens)
Recall/latency eval on synthetic clustered data (head/tail + near-dupes).

Goldens enforce floors so regressions fail fast:

Baseline recall@10 and latency cap.

Promoted-only routing overlap proxy + latency cap.

Phase-2 golden: tuned α/β must beat cosine-only by ≥ a configured delta.

bash
Copy
Edit
bash lattice_ai/tests/run_all_goldens.sh
bash lattice_ai/tests/run_phase2_goldens.sh
Benefits

Continuous confidence. You can change policies, hashes, or scorer params without guessing whether quality fell off a cliff.

How to actually use the platform (a typical flow)
Bring data in

Convert each item to a vector (plug your encoder).

POST /glyphs (auto-timestamped).

Define policy & probes

PUT /policy/{domain} with thresholds and probes you care about.

Optional: set α/β via POST /scorer/{domain} (or tune offline first).

Build shells & promote

POST /build_shells/{center_id} (probes run; reports persisted).

GET /reports/{center_id} to inspect results (coherence, redundancy, recency/novelty, contradiction risk).

Query inside the budget

GET /query_budgeted?center_id=... (Budget Controller selects k).

Tune α/β if you need more recall at the same budget.

Govern & operate

Add claims when new facts arrive; enqueue contradiction sweeps.

Use schedules for periodic sweeps; watch /metrics.

Use the UI (/ui) to visualize houses, probe metrics, and adjust policies.

What’s finished vs. in progress
Solid and working

Two-tier hashing with a trainable Tier-2 + trainer, eval, churn metrics.

Shell lifecycle with policy thresholds, probes, auto-expand, promotion reports (SQLite), REST, and UI views.

Budget Controller with online cost model and iterative fallback.

Per-datum lattice scaffold with distortion KPI and KV capability policy.

Contradiction sweeps (rule: conflicting values per subject/predicate) + quarantine.

Persistence/migrations, background jobs/queue/scheduler, metrics, multi-tenant scoping, REST + minimal UI, Dockerfile, smoke/golden tests.

Deliberate placeholders / next improvements

Geodesic score is proxied; a richer E8 path metric (Coxeter length, cached path distances) will sharpen β’s contribution.

Router blending is still cosine-first in hot paths; we’ll fully wire α/β into every ranking stage with proper geodesic.

Per-datum map is identity; swap in a small learned linear map with regularized fitting per template/domain.

Scheduler uses simple intervals (“cron-ish” strings are stored, not fully parsed).

Auth is API-key based (tenant-scoped); a JWT/HMAC scheme and per-tenant rate limits are on deck.

UI is functional but minimal; we’ll add charts (occupancy histograms, recall-vs-budget curves) and a promotion “what-if” preview.

Why this approach is useful (concrete benefits)
Latency with quality: Houses + Budget Controller = predictable p95 without giving up recall—then α/β tuning buys extra recall for “free.”

Explainability & audit: You can see why something is in context—promotion reports, probes, and claim provenance.

Safety: Contradiction detection + quarantine prevents silent corruption of the “trusted” context.

Adaptability: Policies per domain/tenant, auto-expand on uncertainty, trainable Tier-2 hash, and per-datum templates mean it grows with your data.

Operability: Metrics, jobs, schedules, tests, and a tiny UI reduce day-2 pain.

Multi-tenant: One deployment, many tenants; strict row-level isolation with separate API keys.

If you want a one-command quickstart
bash
Copy
Edit
# Build and run
docker build -t lattice-ai .
docker run -p 8000:8000 -e LATTICE_API_KEY=secret lattice-ai

# Sanity check in another shell
bash lattice_ai/tests/smoke.sh

# Open the dashboard
http://localhost:8000/ui