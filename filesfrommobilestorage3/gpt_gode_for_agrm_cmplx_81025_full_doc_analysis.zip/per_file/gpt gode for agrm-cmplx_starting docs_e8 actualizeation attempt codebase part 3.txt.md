# File: gpt gode for agrm-cmplx/starting docs/e8 actualizeation attempt codebase part 3.txt

**Lines:** 368 | **Words:** 1559

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 1
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 4
- golden: 26
- glyph: 10
- lattice: 23

---

## Full Text

# Part 3 — Tests, Evaluation, and SPEC

## FILE: tests/synth_data.py
"""
Generates synthetic clustered, long-tail, and near-duplicate documents for realistic evaluation.
Clusters: sets of similar glyphs sharing vector regions.
Long-tail: rare, distant glyphs.
Near-dupes: glyphs differing in minor ways.
"""

def generate_synthetic_data():
    clusters = [[f"glyph_c{i}_{j}" for j in range(10)] for i in range(5)]
    long_tail = [f"glyph_lt{i}" for i in range(20)]
    near_dupes = [(f"glyph_nd{i}_a", f"glyph_nd{i}_b") for i in range(10)]
    return clusters, long_tail, near_dupes

## FILE: tests/golden_quality.py
"""
Golden test for retrieval quality under budget.
Requires recall@10 improvement of at least +2 points over baseline.
"""
from core import router

def run_golden():
    baseline = 0.75
    tuned = router.evaluate_recall_at_k(k=10)
    if tuned < baseline + 0.02:
        raise AssertionError(f"Recall@10 {tuned} did not meet target")
    print(f"Recall@10 OK: {tuned}")

## FILE: tests/golden_latency.py
"""
Golden test for p95 latency adherence.
"""
from core import router

def run_golden():
    p95 = router.evaluate_latency_p95()
    cap = 200  # ms
    if p95 > cap:
        raise AssertionError(f"Latency p95 {p95}ms exceeds cap {cap}ms")
    print(f"Latency p95 OK: {p95}ms")

## FILE: tests/run_all_goldens.sh
#!/bin/bash
python -m tests.golden_quality
python -m tests.golden_latency

## FILE: docs/SPEC.md
"""
# Lattice AI v20 SPEC

## Invariants
- Per-datum lattice arrays remain isolated but comparable.
- Safe cube holds all tenant-contextual data.
- Shell promotions follow policy thresholds and QA probes.
- Router obeys budget controller outputs.
- Contradictions trigger quarantine and require resolution.

## Release Gates
- All golden tests must pass.
- No unauthorized cross-tenant data access.
- p95 latency ≤ budget cap.
- Recall@10 meets or exceeds baseline improvement target.

## Open Items
- UI policy editor for live adjustments.
- Offline tuner integration for more similarity metrics.
- Expanded contradiction resolution workflows.
"""


######################################################################################
# FILE: lattice_ai/tests/__init__.py
######################################################################################
"""Test package initializer."""


######################################################################################
# FILE: lattice_ai/tests/synth_data.py
######################################################################################
"""Structured synthetic dataset generator with head/tail clusters and near-dupes.

Used by goldens and the α/β tuner to mimic real-world cluster/long-tail effects.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass
class SynthConfig:
    dim: int = 8
    n_head: int = 6
    n_tail: int = 10
    per_head: int = 120
    per_tail: int = 20
    duplicate_rate: float = 0.10
    seed: int = 42

def unit(v: np.ndarray) -> np.ndarray:
    return v / (np.linalg.norm(v) + 1e-9)

def make_dataset(cfg: SynthConfig):
    rng = np.random.default_rng(cfg.seed)
    centers = [unit(rng.standard_normal(cfg.dim)) for _ in range(cfg.n_head + cfg.n_tail)]
    X = []; labels = []
    for i in range(cfg.n_head):
        for _ in range(cfg.per_head):
            X.append(unit(centers[i] + 0.15*rng.standard_normal(cfg.dim)))
            labels.append(i)
    for i in range(cfg.n_tail):
        idx = cfg.n_head + i
        for _ in range(cfg.per_tail):
            X.append(unit(centers[idx] + 0.20*rng.standard_normal(cfg.dim)))
            labels.append(idx)
    X = np.stack(X, axis=0); labels = np.array(labels)
    n_dup = int(cfg.duplicate_rate * len(X))
    if n_dup > 0:
        dup_idx = rng.choice(len(X), size=n_dup, replace=False)
        X[dup_idx] = unit(X[dup_idx] + 0.02*rng.standard_normal((n_dup, cfg.dim)))
    return X, labels


######################################################################################
# FILE: lattice_ai/tests/eval_golden.py
######################################################################################
"""Golden: baseline recall@10 and latency cap on synthetic data.

This provides a coarse regression check on core retrieval quality and speed.
"""
from __future__ import annotations
import json, sys, time
import numpy as np
from .synth_data import SynthConfig, make_dataset

THRESH = {"recall_at_10_min": 0.45, "latency_ms_max": 50.0}

def brute_rank(i, X, labels, k):
    q = X[i]
    sims = X @ q
    order = np.argsort(-sims)
    same = [j for j in order if labels[j]==labels[i] and j!=i]
    return same[:k]

def main():
    X, labels = make_dataset(SynthConfig())
    t0 = time.time()
    R = 0.0; cnt=0
    for i in range(0, min(300,len(X)), 10):
        true = brute_rank(i, X, labels, 10)
        ranked = list(np.argsort(-(X @ X[i])))[:10]
        R += len(set(true) & set(ranked)) / 10.0
        cnt+=1
    recall = R/max(1,cnt)
    lat_ms = (time.time()-t0)*1000.0
    print({"recall@10": recall, "latency_ms": lat_ms})
    ok = (recall >= THRESH["recall_at_10_min"]) and (lat_ms <= THRESH["latency_ms_max"]) 
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()


######################################################################################
# FILE: lattice_ai/tests/routing_golden.py
######################################################################################
"""Golden: promoted-only routing overlap proxy + latency cap.

Build shells around a center, promote with defaults, then route and ensure
we overlap with the promoted set while staying under a latency target.
"""
from __future__ import annotations
import json, sys, time
import numpy as np
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shell_qa import ShellQASuite, ShellPromotionRules
from lattice_ai.core.router import Router
from lattice_ai.core.budget_controller import BudgetController

THRESH = {"overlap_min": 0.40, "latency_ms_max": 50.0}

def main():
    cube = SafeCube(dim=8, seed=101)
    ids = [f"d::{i}" for i in range(600)]
    P = np.stack([cube.glyph_vector(i) for i in ids], axis=0)
    center = ids[0]
    sb = ShellBuilder(points=P, ids=ids)
    shells = sb.shells_for(center, max_k=3, nn=12)
    sm = ShellManager(); sm.create(center, shells, hash_fn=lambda s: str(abs(hash((s.center_id, s.k, tuple(s.members))))) )
    suite = ShellQASuite(); rules = ShellPromotionRules(min_size=8, min_coherence=0.1)
    sm.validate_and_promote(center, suite, rules, get_vector=cube.glyph_vector, score_fn=lambda _:1.0)

    router = Router(cube, shell_manager=sm)
    bc = BudgetController(p95_budget_ms=25.0)

    t0 = time.time()
    res = bc.query(router, center_id=center, use_promoted=True, top_k=10)
    dt = (time.time()-t0)*1000.0

    promoted = set(sm.promoted_members(center))
    cand = set(res["candidates"]) if res.get("candidates") else set()
    overlap = len(promoted & cand) / max(1, min(10, len(promoted)))

    print({"overlap_proxy": overlap, "latency_ms": dt})
    ok = (overlap >= THRESH["overlap_min"]) and (dt <= THRESH["latency_ms_max"]) 
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()


######################################################################################
# FILE: lattice_ai/tests/quality_golden.py
######################################################################################
"""Golden: learned α/β must beat cosine-only baseline by >= delta.

We simulate tuning on the synthetic set and compare recall@10 to baseline.
"""
from __future__ import annotations
import sys, numpy as np
from .synth_data import SynthConfig, make_dataset
from lattice_ai.core.tuner import tune_alpha_beta

DELTA_MIN = 0.02

def recall_at_k(true_neighbors, ranked, k=10):
    return len(set(true_neighbors[:k]) & set(ranked[:k])) / max(1,k)

def brute_rank(i, X, labels, k):
    q = X[i]
    sims = X @ q
    order = np.argsort(-sims)
    same = [j for j in order if labels[j]==labels[i] and j!=i]
    return same[:k]

def blended_rank(i, X, labels, a, b, k):
    sims = X @ X[i]
    order = np.argsort(-sims)
    ranks = np.empty(len(X), dtype=int); ranks[order] = np.arange(len(X))
    g = 1.0 / (1.0 + ranks)
    scores = a*sims + b*g
    ranked = list(np.argsort(-scores))
    return ranked[:k]

def main():
    X, labels = make_dataset(SynthConfig())
    Rb = 0.0; cnt=0
    for i in range(0, min(300,len(X)), 10):
        true = brute_rank(i, X, labels, 10)
        ranked = list(np.argsort(-(X @ X[i])))[:10]
        Rb += recall_at_k(true, ranked, 10); cnt+=1
    base = Rb/max(1,cnt)

    tr = tune_alpha_beta(X, labels, 10)
    Rt = 0.0; cnt=0
    for i in range(0, min(300,len(X)), 10):
        true = brute_rank(i, X, labels, 10)
        ranked = blended_rank(i, X, labels, tr.alpha, tr.beta, 10)
        Rt += recall_at_k(true, ranked, 10); cnt+=1
    tuned = Rt/max(1,cnt)
    delta = tuned - base

    print({"base": base, "tuned": tuned, "delta": delta})
    sys.exit(0 if delta >= DELTA_MIN else 1)

if __name__ == "__main__":
    main()


######################################################################################
# FILE: lattice_ai/tests/tune_scorer.py
######################################################################################
"""CLI: run α/β tuner on synthetic data and write params to JSON."""
from __future__ import annotations
import json
from .synth_data import SynthConfig, make_dataset
from lattice_ai.core.tuner import tune_alpha_beta

def main():
    X, labels = make_dataset(SynthConfig())
    res = tune_alpha_beta(X, labels, k=10)
    blob = {"alpha": res.alpha, "beta": res.beta, "recall_at_10": res.recall_at_k}
    out = "scorer_params.json"
    json.dump(blob, open(out, "w"))
    print("Saved", out, "=>", blob)

if __name__ == "__main__":
    main()


######################################################################################
# FILE: lattice_ai/tests/run_all_goldens.sh
######################################################################################
#!/usr/bin/env bash
set -euo pipefail
python -m lattice_ai.tests.eval_golden
python -m lattice_ai.tests.routing_golden
echo "ALL GOLDENS OK"


######################################################################################
# FILE: lattice_ai/tests/run_phase2_goldens.sh
######################################################################################
#!/usr/bin/env bash
set -euo pipefail
python -m lattice_ai.tests.quality_golden
echo "PHASE2 GOLDEN OK"


######################################################################################
# FILE: docs/SPEC.md
######################################################################################
# Lattice System SPEC (v20)

## 1. Geometry & Space
- ℝ^8 ("Safe Cube") with deterministic glyph→vector mapping.
- Unit-normalization invariant; vectors stored in-memory (demo) and can be persisted.

## 2. Hashing & Houses
- Tier-1 sign-projection LSH, Tier-2 trainable 64-bit semantic hash.
- Houses keyed by (h1,h2) with hotness and items.

## 3. Shells & Governance
- Shells built as NN rings; QA metrics: size, coherence, redundancy, domain.
- Promotion via policy thresholds; probes: recency, novelty, contradiction risk.
- Quarantine on contradictions across promoted members.

## 4. Routing & Budget
- Prefilter via houses/promoted members; exact re-rank with blend hooks.
- Budget Controller v3: small online linear model picks k to meet p95.

## 5. Per-datum Lattices
- Identity map baseline, anchors bookkeeping, distortion KPI, KV with caps.

## 6. Persistence & Jobs
- SQLite for policies, claims, shells, reports, schedules, tenants.
- TaskQueue (retries/backoff) and JobService (contradiction sweeps).

## 7. Multi-tenant
- Row-level `tenant_id` on tables; key registry via `/tenants`.

## 8. Tests & Goldens
- Synthetic data; goldens for baseline recall/latency, routing overlap, and α/β gain.

## 9. Open Items
- True E8 geodesic integration; router-wide α/β; richer scheduler; JWT; UI charts.


######################################################################################
# FILE: Dockerfile
######################################################################################
FROM python:3.11-slim
WORKDIR /app
COPY . /app
RUN pip install fastapi uvicorn numpy pydantic
EXPOSE 8000
CMD ["uvicorn", "rest.app:app", "--host", "0.0.0.0", "--port", "8000"]


######################################################################################
# FILE: launch.sh
######################################################################################
#!/usr/bin/env bash
set -euo pipefail
uvicorn rest.app:app --host 0.0.0.0 --port 8000
