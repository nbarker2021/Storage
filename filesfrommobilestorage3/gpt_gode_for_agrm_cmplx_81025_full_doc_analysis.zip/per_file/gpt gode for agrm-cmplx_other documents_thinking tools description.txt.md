# File: gpt gode for agrm-cmplx/other documents/thinking tools description.txt

**Lines:** 1 | **Words:** 412

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Text

Think Tank - internal review for every single task, housing experts in fields specific to job being performed, selected based on best fit for task Assembly Line - breaks all tasks down to atomic level, then works on all steps concurrently, and sharing data across tasks for context into best methods on the fly, feeds info into thinktank, thinktank suggests improvements, this repeats until "perfect" design, can be used for ANY design task MORSR(Middle Out, Ripple, Subripple) - Very powerful tool to observe any system for dependancy and mapping, if used from very begining of Assembly Line design, a perfect full map is achieved during design process. targets specific systems, sends a pulse that tracks all dependancies, the another from that point, and so on until full system map is made. can be applied to text for context finding Wave Pool - Tailored "waves" of context about each and every specific topic, housed in a "wave pool" with indiviual "lanes" for a wave to house, frozen in read only until called, applied to specific task containing the refrenced system, and then updated and placed back in the pool to freeze. Waves are applied omnidirectionally on the task, so the end steps are informed by the start steps, and every step inbetween Snapshots, Movies, Songs, - The single most powerful tool in AI existance. Snapshots are state data, like a picture of each and every system, at every point of development and update, thanks to Asesembly Line design Movies are a series of snapshots that reflect the whole process Songs are complex combinations of movies and snaps that show the entire chain from suggestion of idea, till final implementation Whirlpool - a concept where very difficult ideas get ALL contextual knowledge "swirlled around it like a whirlpool" DTT (Deploy to Test): An iterative development methodology involving rapid prototyping, testing, and refinement of different algorithmic variations. Modular design, chunking, plug and play, error to genesis - Modular and chunked, from the atomic level up, data is always used. we can map relations and dependancies, with "perfect" chunks of data allways being used. we do this by mapping and testing in dtt, and understanding what programs inherntly work together and which dont. all this is saved in snaps movies and songs, building bout a "best and worst of" library, for every single task. this allows for on the fly plug and play, 0 calculation troubleshooting and update/reversion, and the ability to track errors from error start to end basically instantly.