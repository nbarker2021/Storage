# CQE Demo Dataset — SCHEMA

Each row is a candidate state (torus or equivalent primitive) ready for CQE processing.

| Field | Type | Description |
|------|------|-------------|
| state_id | string | Row identifier (S000..S127) |
| label_glyphs | string | Fixed meaning-hash label (glyph/pictograph string) |
| form_tag | enum | Geometric primitive ('torus_d10_doublehelix', 'hypercube_slice', 'leech_patch', 'e8_octad', 'monster_patch', ...) |
| parity_lane | {0,1} | Palindromic mirror lane selector |
| scale | int | Discrete scale (1..64) |
| pose | enum | {'rest','tilt','braid','weave'} |
| domain_hint | enum | Domain-sidecar hint (EM_FIELD, BIO_COHERENCE, COSMOS, SPINTRONICS, THERMAL, OPTICS, POLAR, MATH) |
| sidecars_active | csv | Comma-separated sidecars toggled ON at ingest |
| octet_passes | bitstring(8) | Pass/fail across the octet viewers (1=pass) |
| mirror_hash | hex12 | Palindromic mirror receipt hash (truncated) |
| fourbit_commit | bitstring(4) | Compact commit code (derived from octet) |
| residues | csv | Minor issues captured (or 'none') |
| status | enum | {'provisional','working','non-working'} |
| notes | string | Short operator note |

## Intended use
- Treat `label_glyphs` as the meaning-hash that must remain stable within a session.
- Promote/demote rows by updating `status` and `fourbit_commit` after running your CQE loop.
- Join with workbook templates (below) to create new states from scratch.
