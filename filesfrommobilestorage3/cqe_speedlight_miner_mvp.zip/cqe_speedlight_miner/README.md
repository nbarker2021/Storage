# CQE–Speedlight Solo Miner (MVP)

Receipts‑first, geometry‑native solo miner scaffold:
- Deterministic tri‑rail scheduler (nonce, extra‑nonce→merkle class, version/time) with dihedral palindromes
- Long‑poll GBT (with polling fallback), submitblock
- Midstate planner (reference) + reuse ratio telemetry
- O8→E8/24D atlas (simple embed) + Q‑meter (tip entropy, reorg estimate, obs lag, receipt density)
- E8 tiler (residue‑class partitioner) for multi‑agent non‑overlap
- JSONL receipts + hourly Merkle anchors
- Pure stdlib (no third‑party deps)

> This is a reference MVP for testing and extension. It does **not** change PoW or Bitcoin consensus. It reduces waste and adds auditability.

## Quickstart

```bash
python -m cqe_speedlight_miner.cli --help
# Example (regtest, localhost bitcoind RPC):
python -m cqe_speedlight_miner.cli mine --rpc-url http://127.0.0.1:18443 --rpc-user user --rpc-pass pass --address bcrt1q...
```

## Layout
- `node_adapter.py` JSON‑RPC GBT/submit wrappers (+ long‑poll)
- `header_space.py` legal rails + state mutations
- `golden_strider.py` palindromic stride sequences
- `midstate_planner.py` header construction + reuse telemetry
- `e8_tiler.py` non‑overlap agent partitioning
- `atlas_o8.py` orbital extractor + simple E8/24D mapping + curvature
- `qmeter.py` uncertainty index from headers
- `receipts.py` WHAT+GOV writer + rolling merkle anchor
- `runner.py` mining loop
- `cli.py` argparse CLI
- `tests/` minimal smoke tests
- `scripts/` regtest helpers

## Config hints
- Export `BITCOIN_RPC_URL`, `BITCOIN_RPC_USER`, `BITCOIN_RPC_PASS` or pass as flags.
- Set `--finality 6` for Q‑meter finality depth.
- Use `--agents 4 --agent-id 0..3` to split work across local processes (E8 tiler ensures non‑overlap).

## License
MIT
