from cqe_speedlight_miner.golden_strider import StriderCfg, tri_rail_batches

def test_palindrome_batches():
    cfg = StriderCfg(Kx=4, Km=3, Kv=2)
    ops = list(tri_rail_batches(cfg))
    assert any(o[0]=="nonce" for o in ops)
    assert any(o[0]=="xtra_merkle" for o in ops)
    assert any(o[0]=="version_nonce" for o in ops)
    assert any(o[0]=="time" for o in ops)
