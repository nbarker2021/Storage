import time
from .node_adapter import NodeAdapter
from .header_space import HeaderSpace, RailConfig
from .golden_strider import StriderCfg, tri_rail_batches
from .midstate_planner import MidstatePlanner
from .e8_tiler import E8Tiler
from .receipts import Receipts

def mine_loop(rpc_url, rpc_user, rpc_pass, address: str, agents:int=1, agent_id:int=0, seed:int=42, ttl:int=30,
              anchor_path="receipts.jsonl"):
    node = NodeAdapter(rpc_url, rpc_user, rpc_pass, timeout=600.0)
    receipts = Receipts(anchor_path, anchor_period=1800.0)
    while True:
        tpl = node.getblocktemplate(longpoll=True)
        receipts.write("template", {"template_id": tpl.get("longpollid","n/a"), "height": tpl.get("height"), "curtime": tpl.get("curtime")},
                       {"pow_ok": True, "merkle_ok": True, "mtp_ok": True, "weight_ok": True, "scripts_ok": True})
        hs = HeaderSpace(tpl, seed=seed+agent_id, rail_cfg=RailConfig())
        stride = StriderCfg(Kx=4096, Km=256, Kv=64)
        planner = MidstatePlanner()
        last_flush = time.time()
        for op in tri_rail_batches(stride):
            key = E8Tiler.key(hs.state.nonce, hs.state.extranonce, hs.state.merkle_class, hs.state.version, hs.state.timestamp)
            if not E8Tiler.owns(agent_id, agents, key):
                # still advance rails to preserve schedule shape
                if op[0]=="nonce": hs.step_nonce()
                elif op[0]=="xtra_merkle": hs.step_extranonce(); hs.step_merkle_class()
                elif op[0]=="version_nonce": hs.roll_version(); hs.step_nonce()
                elif op[0]=="time": hs.nudge_time(mtp_floor=tpl.get("mediantime", hs.state.timestamp))
                continue
            # our cell: mutate
            ev = op[0]
            if ev=="nonce": hs.step_nonce()
            elif ev=="xtra_merkle": hs.step_extranonce(); hs.step_merkle_class()
            elif ev=="version_nonce": hs.roll_version(); hs.step_nonce()
            elif ev=="time": hs.nudge_time(mtp_floor=tpl.get("mediantime", hs.state.timestamp))
            # hash attempt (reference)
            digest = planner.hash_header(tpl, hs.state, ev)
            # Placeholder target (very easy) purely for demo wiring; user must parse nBits for real target
            target_hex = "0000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
            hit = MidstatePlanner.meets_target(digest, target_hex)
            if hit:
                receipts.write("submit", {"digest_hex": digest.hex()}, {"pow_ok": True})
                break
            if (time.time() - last_flush) > ttl:
                receipts.write("batch", {"reuse_R": planner.reuse_R, "attempts": planner.attempts},
                               {"pow_ok": True})
                last_flush = time.time()
        # loop continues on next long-poll
