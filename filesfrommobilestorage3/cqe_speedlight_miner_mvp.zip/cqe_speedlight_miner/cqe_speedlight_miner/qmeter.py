import math, collections
from typing import List

def shannon_entropy(weights: List[float]) -> float:
    s = sum(weights)+1e-12
    p = [w/s for w in weights if w>0]
    return -sum(pi*math.log(pi) for pi in p)

class QMeter:
    def __init__(self, finality_k:int=6, weights=None):
        self.finality_k = finality_k
        self.weights = weights or (0.25,0.25,0.25,0.25)
        self.receipt_hits = 0
        self.receipt_total = 0
        self.obs_lags = []
        self.fork_hist = collections.deque(maxlen=1024)

    def record_receipt(self, anchored: bool):
        self.receipt_total += 1
        if anchored: self.receipt_hits += 1

    def record_observation_lag(self, seconds: float):
        self.obs_lags.append(seconds)

    def record_fork(self, forked: bool):
        self.fork_hist.append(1 if forked else 0)

    def tip_entropy(self, tip_supports: List[float]) -> float:
        if len(tip_supports)<=1: return 0.0
        return shannon_entropy(tip_supports)/math.log(len(tip_supports))

    def reorg_risk(self) -> float:
        lam = (sum(self.fork_hist)/max(1,len(self.fork_hist))) or 1e-6
        alpha = max(1e-6, lam*5.0)
        return 1.0 - math.exp(-alpha * self.finality_k)

    def obs_lag(self) -> float:
        if not self.obs_lags: return 0.0
        median = sorted(self.obs_lags)[len(self.obs_lags)//2]
        return min(median / 1200.0, 1.0)

    def receipt_density(self) -> float:
        if self.receipt_total == 0: return 1.0
        return self.receipt_hits / max(1,self.receipt_total)

    def Q(self, tip_supports: List[float]):
        w1,w2,w3,w4 = self.weights
        q_tip = self.tip_entropy(tip_supports)
        q_reorg = self.reorg_risk()
        q_obs = self.obs_lag()
        rho = self.receipt_density()
        total = w1*q_tip + w2*q_reorg + w3*q_obs + w4*(1.0 - rho)
        return {"tip":q_tip, "reorg":q_reorg, "obs":q_obs, "Rbar":(1.0-rho), "total": total}
