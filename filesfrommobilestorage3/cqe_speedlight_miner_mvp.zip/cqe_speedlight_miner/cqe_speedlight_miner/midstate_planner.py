import hashlib, struct
from typing import Dict

class MidstatePlanner:
    def __init__(self): 
        self.rebuilds = 0
        self.attempts = 0

    @property
    def reuse_R(self):
        return (self.attempts / self.rebuilds) if self.rebuilds else 1.0

    def build_header(self, tpl: Dict, rails) -> bytes:
        version = rails.version & 0xFFFFFFFF
        time_ = rails.timestamp & 0xFFFFFFFF
        nBits = tpl.get("bits_hex") or tpl.get("bits") or "1d00ffff"
        nBits_int = int(nBits, 16) if isinstance(nBits, str) else int(nBits)
        nonce = rails.nonce & 0xFFFFFFFF
        merkle_low = (rails.extranonce ^ (rails.merkle_class * 0x9E3779B1)) & 0xFFFFFFFF
        prevhash = int(tpl.get("previousblockhash", "0"*64)[:8] or "0", 16)
        header = struct.pack("<LLLLLL", version, prevhash, merkle_low, time_, nBits_int, nonce)
        return header

    def double_sha256(self, header: bytes) -> bytes:
        h = hashlib.sha256(header).digest()
        return hashlib.sha256(h).digest()

    def hash_header(self, tpl: Dict, rails, event: str):
        if event in ("xtra_merkle","version_nonce","time"):
            self.rebuilds += 1
        self.attempts += 1
        hdr = self.build_header(tpl, rails)
        digest = self.double_sha256(hdr)
        return digest

    @staticmethod
    def meets_target(digest: bytes, target_hex: str) -> bool:
        h_int = int.from_bytes(digest, "big")
        T = int(target_hex, 16)
        return h_int <= T
