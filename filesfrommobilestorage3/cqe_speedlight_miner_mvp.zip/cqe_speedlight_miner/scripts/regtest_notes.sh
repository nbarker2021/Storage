#!/usr/bin/env bash
set -euo pipefail
# Minimal notes for running regtest and the miner (assumes bitcoind in PATH)
# Start bitcoind with regtest:
#   bitcoind -regtest -fallbackfee=0.0001 -server -rpcuser=user -rpcpassword=pass -txindex=1 -printtoconsole
# Create a wallet and address:
#   bitcoin-cli -regtest -rpcuser=user -rpcpassword=pass createwallet miner || true
#   ADDR=$(bitcoin-cli -regtest -rpcuser=user -rpcpassword=pass getnewaddress)
# Run miner (loop 0):
#   python -m cqe_speedlight_miner.cli mine --rpc-url http://127.0.0.1:18443 --rpc-user user --rpc-pass pass --address $ADDR --agents 2 --agent-id 0
# Run miner (loop 1):
#   python -m cqe_speedlight_miner.cli mine --rpc-url http://127.0.0.1:18443 --rpc-user user --rpc-pass pass --address $ADDR --agents 2 --agent-id 1
echo "See comments for regtest instructions."
