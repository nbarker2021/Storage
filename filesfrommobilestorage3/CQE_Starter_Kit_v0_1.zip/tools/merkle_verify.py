#!/usr/bin/env python3
import os, sys, hashlib, json
sha256=lambda b: hashlib.sha256(b).hexdigest()
def leaf(path, ch): return sha256((path.replace(os.sep,"/")+":"+ch).encode())
def build(root):
  leaves=[]
  for b,_,fs in os.walk(root):
    for f in fs:
      p=os.path.join(b,f); ch=sha256(open(p,'rb').read())
      rel=os.path.relpath(p,root); leaves.append(leaf(rel,ch))
  if not leaves: return None,[]
  leaves=sorted(leaves); layers=[leaves]; cur=leaves
  while len(cur)>1:
    nxt=[sha256((cur[i]+(cur[i+1] if i+1<len(cur) else cur[i])).encode()) for i in range(0,len(cur),2)]
    layers.append(nxt); cur=nxt
  return cur[0],layers
if __name__=='__main__':
  root=sys.argv[1]; m,l=build(root); print(json.dumps({"merkle_root":m,"layer_sizes":[len(x) for x in l]},indent=2))
