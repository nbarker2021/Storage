# CQE DSL (slice) — v0.1
```
job "J/${yyyy-MM-dd'T'HHmmssZ}" {
  anchor       = "LEECH_PATCH_A1"
  automorphism = M24("σ_173842")
  S            = 2
  tokens   = load("tokens.json")
  octet    = load("octet_plan.json")
  strict   = load("strict_gate.json")
  policy   = load("policy.json")
  run {
    for H in octet.faces {
      VIEW(H) { pre { unit_guards(tokens) } exec { viewer(H).apply(tokens) }
                mir { assert mirror_agrees(H) within tolerance(H) }
                delta{ apply best_delta_if_needed(H) } keep { record metrics(H) } }
    }
  }
  commit { require octet.pass_count >= 4
           emit receipt(commit4(bits_from_faces()), evidence_root()) }
}
```