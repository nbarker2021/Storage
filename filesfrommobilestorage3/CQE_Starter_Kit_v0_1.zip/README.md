# CQE Starter Kit v0.1

Evidence root: `9c845ff0210825de744447ac2b21b077143d184306127510e78e7296d63bec86`  
Commit-4 (demo): `1011`

See `runbook_replay.md` for verification steps.
