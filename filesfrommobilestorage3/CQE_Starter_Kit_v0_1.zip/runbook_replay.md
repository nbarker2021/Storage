# Replay Runbook
1) Verify zip hash.
2) Compute Merkle over `evidence/{root}` with `tools/merkle_verify.py`.
3) Re-run viewers offline; check metrics match to precision.
4) Check `commit4` equals bits_from_faces(H1..H8).
