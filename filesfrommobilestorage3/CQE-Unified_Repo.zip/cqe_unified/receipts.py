from .utils import sha256_hex, merkle_root

def is_palindrome(p):
    return p==list(reversed(p))

def mirror_holds(a,b):
    return a==b

def locality(prev_seq, seq, max_adj_swaps=1, allow_one_cut=True):
    if prev_seq==seq: return True
    if allow_one_cut:
        for k in range(1,len(seq)):
            if prev_seq==seq[k:]+seq[:k]: return True
    pos={v:i for i,v in enumerate(prev_seq)}
    inv=0
    for i,v in enumerate(seq):
        inv+=abs(i-pos.get(v,i))
        if inv>max_adj_swaps: return False
    return True

def strict_metric(prev_m, m):
    return m<=prev_m

def commit_merkle(parts):
    leaves=[sha256_hex(p) for p in parts]
    return merkle_root(leaves)
