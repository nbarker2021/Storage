def paint_gradients(n):
    return [0.0] if n<=1 else [i/(n-1) for i in range(n)]
