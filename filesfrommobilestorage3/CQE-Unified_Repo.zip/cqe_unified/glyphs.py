from dataclasses import dataclass, field
from typing import Any, List, Dict, Optional

@dataclass
class Glyph:
    gid: str
    observed: Any
    declared_label: Optional[str]=None
    inferred_label: Optional[str]=None
    bound_label: Optional[str]=None
    overrides: List[Dict[str,Any]] = field(default_factory=list)
    def bind(self,label,why):
        prior=self.bound_label or self.declared_label or self.inferred_label
        self.bound_label=label
        if prior and prior!=label:
            self.overrides.append({"from":prior,"to":label,"why":why})

@dataclass
class GlyphSet:
    glyphs: List[Glyph]=field(default_factory=list)
    @classmethod
    def from_rows(cls, rows):
        gs=cls()
        for r in rows:
            g=Glyph(str(r.get('gid')), r.get('observed'), r.get('declared_label'), r.get('inferred_label'))
            preferred=r.get('observed_label') or g.declared_label or g.inferred_label
            if preferred: g.bind(preferred, 'initial')
            gs.glyphs.append(g)
        return gs
    def overrides_exist(self):
        return any(g.overrides for g in self.glyphs)
