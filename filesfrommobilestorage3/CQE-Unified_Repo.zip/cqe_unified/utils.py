import hashlib

def sha256_hex(b):
    return hashlib.sha256(b).hexdigest()

def merkle_root(leaves):
    import binascii
    if not leaves: return sha256_hex(b"")
    layer=[bytes.fromhex(h) for h in leaves]
    while len(layer)>1:
        nxt=[]
        for i in range(0,len(layer),2):
            a=layer[i]; b=layer[i+1] if i+1<len(layer) else a
            nxt.append(hashlib.sha256(a+b).digest())
        layer=nxt
    return layer[0].hex()
