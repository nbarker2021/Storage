from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

@dataclass
class Carrier:
    sequence: List[int]
    face: List[int]
    suit: List[int]
    parity_lane: List[int]
    meta: Dict[str,Any]=field(default_factory=dict)
    def visible_pattern(self):
        return list(zip(self.sequence,self.face,self.suit))
    def mirrored(self):
        rev_seq=list(reversed(self.sequence))
        rev_face=[1-b for b in reversed(self.face)]
        rev_suit=[ (s^1) for s in reversed(self.suit)]
        return Carrier(rev_seq,rev_face,rev_suit,list(reversed(self.parity_lane)),meta={"mirrored":True})
