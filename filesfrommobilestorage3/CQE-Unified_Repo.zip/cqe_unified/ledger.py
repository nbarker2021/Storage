import os,json,time,hashlib
class Ledger:
    def __init__(self,path):
        self.path=path; os.makedirs(path,exist_ok=True)
    def append(self,commit):
        with open(os.path.join(self.path, f"{commit['id']}.json"),'w') as f:
            json.dump(commit,f,indent=2)
