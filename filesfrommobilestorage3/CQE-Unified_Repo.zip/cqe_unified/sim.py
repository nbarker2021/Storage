from dataclasses import dataclass
from .carriers import Carrier
from .utils import sha256_hex
from typing import List
import random

@dataclass
class SimConfig:
    beam:int=4
    seed:int=1337

def simulate_overlays(carrier, cfg:SimConfig):
    r=random.Random(cfg.seed)
    n=len(carrier.sequence)
    ovs=[]
    for _ in range(cfg.beam):
        touches=sorted(set(r.randrange(0,n) for __ in range(max(1,n//8))))
        deltas={i: r.choice([-1,0,1]) for i in touches}
        ovs.append((touches,deltas))
    return ovs

def choose_palindromic_rest(carrier, overlays):
    best=carrier; best_score=10**9
    for touches,deltas in overlays:
        seq=carrier.sequence[:]; face=carrier.face[:]; suit=carrier.suit[:]
        for i,d in deltas.items():
            if 0<=i<len(face): face[i]=(face[i]+(d&1))%2
        pat=list(zip(seq,face,suit)); rev=list(reversed(pat))
        mism=sum(1 for a,b in zip(pat,rev) if a!=b)
        if mism<best_score:
            from .carriers import Carrier
            best=Carrier(seq,face,suit,carrier.parity_lane[:],meta={"rest_score":mism})
            best_score=mism
    return best
