from __future__ import annotations
import os, json, glob, hashlib, time
from cqe_unified.carriers import Carrier
from cqe_unified.sim import SimConfig, simulate_overlays, choose_palindromic_rest
from cqe_unified.receipts import is_palindrome, mirror_holds, locality, strict_metric, commit_merkle
from cqe_unified.ledger import Ledger

HERE=os.path.dirname(__file__)
OUT=os.path.join(HERE,'out'); os.makedirs(OUT,exist_ok=True)

def run_len(bits):
    runs=[]; curr=1
    for i in range(1,len(bits)):
        if bits[i]==bits[i-1]: curr+=1
        else: runs.append(curr); curr=1
    runs.append(curr); return runs

def make_carrier(n):
    seq=list(range(n)); face=[0]*n; suit=[i%4 for i in range(n)]; parity=[i%2 for i in range(n)]
    return Carrier(seq,face,suit,parity,meta={'n':n})

def run_why(cfg):
    n=int(cfg.get('n',16)); prev_metric=int(cfg.get('prev_metric',n)); prev_seq=list(range(n))
    c=make_carrier(n)
    ovs=simulate_overlays(c, SimConfig())
    rest=choose_palindromic_rest(c, ovs)
    P=is_palindrome(rest.visible_pattern())
    M=mirror_holds(rest.visible_pattern(), rest.mirrored().visible_pattern())
    delta_ok=locality(prev_seq, rest.sequence, 1, True)
    metric=max(run_len(rest.face)); S=strict_metric(prev_metric, metric)
    L=bool(cfg.get('force_label_override', False))
    receipts={'P':P,'M':M,'Δ':delta_ok,'S':S,'L':L,'metrics':{'run_length':metric}}
    parts=[json.dumps(rest.meta).encode(), json.dumps(receipts).encode(), json.dumps(cfg).encode()]
    merkle=commit_merkle(parts)
    cid=hashlib.sha1(merkle.encode()).hexdigest()[:16]
    Ledger(os.path.join(OUT,'ledger')).append({'ts':time.time(),'id':cid,'merkle':merkle,'receipts':receipts,'meta':{'cfg':cfg}})
    rep={'id':cfg.get('id'),'title':cfg.get('title'),'n':n,'receipts':receipts,'commit_id':cid,'merkle':merkle}
    with open(os.path.join(OUT, f"{cfg.get('id','why')}.json"),'w') as f: json.dump(rep,f,indent=2)
    return rep

def main():
    files=sorted(glob.glob(os.path.join(HERE,'10why','*.json')))
    if not files: print('No WHY files.'); return
    results=[run_why(json.load(open(fp))) for fp in files]
    ok=sum(1 for r in results if sum(1 for k in ('P','M','Δ','S') if r['receipts'].get(k))>=2)
    with open(os.path.join(OUT,'summary.json'),'w') as f: json.dump({'total':len(results),'committed':ok}, f, indent=2)
    print('Harness finished: total', len(results), 'committed >=2 receipts', ok)

if __name__=='__main__': main()
