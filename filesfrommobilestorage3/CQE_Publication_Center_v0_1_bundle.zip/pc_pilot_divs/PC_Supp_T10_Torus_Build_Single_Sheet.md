# T¹⁰ Double-Helix Build — Single Sheet (Supplement)

**Carrier & Code**  
- Type‑II Construction‑A (Golay exception) ⇒ **Leech** (Λ₂₄): even, unimodular, no roots.  
- Choose a **Golay octad** and pair into **four orthogonal 2‑planes** (8D) + **groove** (1D) + **axis** (1D) ⇒ stage **T¹⁰**.

**Monster & Moonshine**  
- Lock a **13A/13B** screw; assign per‑plane phases by a legal frame‑shape (mod 13).  
- Envelope by McKay–Thompson **T_g(q)** (Moonshine) for radius/groove modulation.

**Mirror Parity (unison)**  
- Build left/right strands together: right = time‑reverse + phase‑shift of left.

---

## Parametric form (sketch)
Let θ be a running angle; φ_k per‑plane Monster phases; envelopes R(θ), G(θ).
- Left:  x_L(θ) = ( R·cos(θ+φ₁), R·sin(θ+φ₁), … ; G(θ), θ_axis ).
- Right: x_R(θ) = ( R·cos(−θ+φ₁+Δ), … ; G(θ), −θ_axis ).
Screw identity: one 13‑step takes x_L → x_R up to gauge.

---

## Rest & Differences
- **Rest** (palindromic template): the mirror‑even component at the gauge.  
- **Differences**: the mirror‑odd sector (legal moves around Rest).

---

## Deterministic Torus + Tokens
- Quotient by periods (four 2π plane periods + 13‑step pitch) ⇒ **T¹⁰**.  
- Linear flow θ̇ = ω with fixed gauge ⇒ **replay‑deterministic**.  
- Tokens are fixed anchors/cells; **move context**, don’t search tokens.

---

## 8‑Face Gating (Weyl/E₈‑style)
Pick 8 facet functionals in Cartan coordinates.  
**OPEN** iff: Type‑II legal ∧ Monster/Moonshine legal ∧ mirror‑legal ∧ all 8 facet inequalities hold (with tiny ≥ tolerance).  
Advance cadence only after all 8 faces latch once.

---

## Outside Neighbors
Project to an E₈ frame to enumerate facet‑adjacent chambers. Crossing a wall is **context change**, not a new center.

---

## Overlays (delta‑labeled, guaranteed return)
- P: Type‑I façade + even‑neighbor return.  
- M: Modulus/CRT layers (q‑ary lifts).  
- S: Symmetry (13A/13B slice).  
- H: Moonshine (T_g choices).  
- G: Gating windows/policies.  
- N: Embedding classifiers (Niemeier views).

---

## Tuple‑Driven Con‑A (selector by arity a)
Given tuple arity a: factor a = ∏ p_i^{k_i}; add Con‑A layers per factor; glue by CRT; if an odd lift appears, take the **shadow lift** back to even; intersect with the chamber and keep mirror pairing intact.

---

## 8‑Cell Atlas of Legal Differences
Mirror + k‑parity + frame closure reduce 16 raw 4‑bit patterns to **8 legal 4‑tuples** around Rest (one is palindromic). Local “best ordering” = nearest legal vertex. Plot with any faithful 3‑D slice.

---

## Unified Spec (RANF)
U = ( T¹⁰, R, J, Σ, H, Π, Legal, Return ), scanned at Rest per face; overlays carry legality; Return never leaves Type‑II for dynamics.

---

## Verification (always ship)
- Screw: 13‑step maps left↔right (gauge fixed).  
- Parity: mirror involution square = id; palindromic Rest invariant.  
- ConA: membership & evenness checks (code‑parity syndrome = 0).  
- Witnesses: all 8 face latches fire per cadence.  
- Determinism: same inputs ⇒ same scan order ⇒ same pulses.

**Breadcrumb**: concrete coordinates were emitted separately in `helix10_embedding.csv` with a 13‑phase slice and Moonshine envelope.
