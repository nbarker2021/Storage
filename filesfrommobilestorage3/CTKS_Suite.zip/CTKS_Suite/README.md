# Claims & Tickets Kernel Suite (CTKS)

A field‑agnostic suite that orders **any** claim/ticket into a deterministic, auditable path:
**intake → classify → route → plan (pal‑64) → act → status**, with tiny 4‑bit receipts.

Use it *without watching it*: CTKS arranges tokens in the **best resting order** so you can just act.
Rails are for proofing, not for micromanagement.

## Quickstart (token-only simulation)
1. Put cases into `data/cases.csv` (use the sample provided).
2. Read `docs/PLAYBOOK.md` and follow “SIM run (no external calls)”.  
3. Use `prompts/` templates to emit human-facing responses for each step.

Artifacts are plain text/JSON/YAML; you can drop them into any stack.
