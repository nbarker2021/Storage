# CTKS Playbook (SIM-first)

**Flow**: Intake → Octet → Classify → Route → Plan (pal‑64) → Act → Status → REST.

- **Receipts**: Each transition emits a 4‑bit receipt; you can ignore them unless you want an audit trail.
- **Promotion**: Any PROVISIONAL step flips to WORKING with one witness (if you ask for proof).
- **No Monitoring**: You don't "watch" CTKS. You speak objectives; CTKS pre-orders the tokens; you act.

## SIM run (no external pulls)
1. Choose a case row from `data/cases.csv`.
2. Wrap into an **Octet** (`schemas/octet.json`).
3. Classify via `rules/routing.yaml` → domain lane.
4. Compile a pal‑64 plan using `kernel/pal64.csv` template; attach 4‑bit receipt.
5. Emit **Status** and **Next Action** with `prompts/status.txt` & `prompts/next_action.txt`.
