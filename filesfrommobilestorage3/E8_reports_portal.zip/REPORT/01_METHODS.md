# Methods

## Intake and Vectorization
- Source: longest decodable text from the provided ZIP.
- Vectorizer: **hashed character n-grams (3–5)** into **8 bins**, log1p, L2-normalized.

## Whitening
- Pre-transform: **Hadamard H8** (normalized) applied before E8 quantization.
- Monitors: **excess kurtosis** pre- and post-whitening (0 ≈ Gaussian).

## E8 Quantization
- Lattice: **E8** with scale `s` chosen **per batch**:
  - Default tuner tries {0.5, 1.0, 2.0} on a small sample to minimize mean residual energy.
  - Optional **scale grid** (e.g., [0.5, 0.75, 1.0, 1.5, 2.0, 3.0]) records candidate losses.

## Tick-Orchestrated Execution
- Global tick loop; each tick performs:
  - Intake from **persistent backlog queue** (seeded once).
  - **Budget** enforcement (e8_per_tick; policy = stretch/skip).
  - E8 encode + **CAS** writes, telemetry, per-tick audit and **snapshots**.

## Metrics per Tick
- **Distortion**: residual L2 mean/max across CAS entries labeled with this tick.
- **Occupancy**: top cells and **entropy** over counts.
- **Locality sanity**: neighbor-hit ratio (radius 1) for sampled batch vectors.
- **Micro-recall proxy**: adjacent windows should map to same/neighbor cells.
- **Timing**: encode_ms, cas_ms, and ms_per_vec.

## Scenarios
- **S1_small**: 4 ticks, e8_per_tick=64, max_vecs≈512
- **S2_medium**: 4 ticks, e8_per_tick=256, max_vecs≈2000
- **S3_large**: 4 ticks, e8_per_tick=512, max_vecs≈6000

Each scenario writes its own dashboard under `RESULTS/dashboards/<scene>/`.
