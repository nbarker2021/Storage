# Next Steps

1) **Scale grid elbow**: expand to a denser grid per batch; record residual vs scale curves and select via elbow to avoid over/under-scaling.

2) **Occupancy alarms**: entropy-based thresholds to detect collapse (too few cells) or over-spread (too many singletons), with automatic scale/whitening adjustments.

3) **Semantic proxy**: augment micro-recall with lightweight cross-window similarity scores (e.g., character n-gram Jaccard) to improve quality signal without ML embeddings.

4) **Resource breakdown**: split ms/vec into intake, pre, encode, CAS; chart vs e8_per_tick to quantify the exact win sources.

5) **Dataset variability**: repeat S1–S3 on different document genres to test stability of the auto-scale and the locality metrics.
