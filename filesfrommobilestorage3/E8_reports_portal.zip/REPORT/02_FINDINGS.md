# Findings & Interpretation

- **Throughput scales efficiently**: ms/vec dropped as per-tick allowances rose (S1≈1.019 → S2≈0.749 → S3≈0.613 ms/vec). This validates the design hypothesis that fixed per-tick overheads amortize at larger batch sizes.

- **Whitening improves packability**: kurtosis dropped markedly pre→post Hadamard across sizes (closer to Gaussian), which supports more balanced occupancy without inflating distortion.

- **Auto-scale stable at ~2.0**: quick tuner consistently chose ~2.0, minimizing residual energy on a small sample and producing stable per-tick distortion.

- **Locality improves with size**: neighbor-hit and micro-recall proxies improved as allowances increased, implying better colocation of similar windows within and near the same E8 cells at larger batches.

- **Governance operates correctly**: backlog carried (stretch) and pruned (skip) as configured, with clear evidence in per-tick reports, snapshots, and telemetry.

**Limits**
- Geometry-level metrics (distortion, occupancy, neighbor-hit) don’t constitute semantic retrieval QA. Introduce labeled queries or a stronger proxy to measure recall/precision on downstream tasks.
