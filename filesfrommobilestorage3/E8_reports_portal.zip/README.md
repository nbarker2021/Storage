# E8 Tick-Orchestrated Quantization — Research Handout (v1)

This package contains:
- **CODE/**: the full codebase as tested (including hardening patches).
- **RESULTS/**: dashboards, per-tick reports, snapshots, and CAS artifacts from the runs in this session.
- **REPORT/**: research-level documentation and aggregate metrics.

## Quick links (open locally)
- Scenarios dashboard: `RESULTS/dashboards/scenarios/index.html`
- Policy A/B dashboard: `RESULTS/dashboards/policy_ab/index.html`
- Per-tick dashboards (latest run): see `RESULTS/dashboards/ticks/index.html` if present.
- Trails viewer (if present): `RESULTS/dashboards/trails/index.html`

## Reproduce key experiments
From `CODE/snaplat_mono_v2_fullproto39`:
```bash
# seed backlog from your ZIP or a new file
python tools/seed_backlog_from_zip.py /path/to/your.zip

# run small/medium/large scenarios on the same doc
python tools/scenario_runner.py --zip /path/to/your.zip

# run policy A/B on the same doc
python tools/policy_ab.py --zip /path/to/your.zip

# generate trends (if tick reports exist)
python tools/tick_trends.py
```
