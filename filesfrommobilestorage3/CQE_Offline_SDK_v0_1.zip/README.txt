
# CQE Offline SDK v0.1

**Everything runs with the Python standard library. No external builds.**  
Includes:
- `cqe_sidecar_mini`: stdlib-only mini-CQE sidecar (CAS, receipts, ΔΦ, sandbox, adapters)
- `commonsledger_server`: API server that uses the sidecar
- `web/`: static UI (Dashboard + Lab)
- `tools/wheelmaker.py`: pure-Python wheel builder for offline packaging

## Option A — Run directly
```
# from this folder
python -c "from commonsledger_server.server import run; run()"
# then open web/index.html and web/ca.html
```

## Option B — Build offline wheels (no internet)
```
python build_wheels.py
# Wheels will appear under dist/
# Install locally (example):
#   pip install --no-index --find-links=dist cqe_sidecar_mini commonsledger_server
python -c "from commonsledger_server.server import run; run()"
```

## Sidecar adapters
The sidecar exposes `cqe.adapters` with three pure-Python adapters you can replace with your real ones:
- `geotokenize(text)` → shape-ish features
- `mdhg_signal(vec, k=8)` → toy multi-D Hamiltonian features
- `moonshine_crosshit(vec, mod=13)` → modular cross-hit score

You can extend/replace them by editing `packages/cqe_sidecar_mini/cqe_sidecar_mini/adapters.py` and rebuilding wheels.

## Toolchains & Sandbox
Tool snippets run inside a safe sandbox (no imports/I/O). They receive a `cqe` helper namespace:
```python
def main(text):
    toks = cqe.tokenize(text)
    v = cqe.vectorize(toks)
    sig = cqe.adapters.moonshine_crosshit(v)
    return {"tokens": len(toks), "sig": sig}
```
