
# build_wheels.py — offline wheel builder
from tools.wheelmaker import build_all
import pathlib
base = str(pathlib.Path(__file__).resolve().parents[0])
print(build_all(base))
