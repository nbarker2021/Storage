
"""
Minimal pure-Python wheel builder for pure-Python packages (no C ext).

Usage:
  python tools/build_wheels.py
Creates dist/*.whl for each package under packages/ with a PKGINFO.json.
"""
import os, json, zipfile, hashlib, base64, time, pathlib

def build_wheel(pkg_root, dist_dir):
    meta_path = os.path.join(pkg_root, "PKGINFO.json")
    meta = json.load(open(meta_path,"r",encoding="utf-8"))
    name = meta["name"]; version = meta["version"]
    pkg_dir = os.path.join(pkg_root, name.replace("-","_"))
    dist_info = f"{name}-{version}.dist-info"
    wheel_name = f"{name}-{version}-py3-none-any.whl"
    os.makedirs(dist_dir, exist_ok=True)
    wheel_path = os.path.join(dist_dir, wheel_name)

    # Prepare METADATA/WHEEL/RECORD
    METADATA = f"Metadata-Version: 2.1\nName: {name}\nVersion: {version}\nSummary: {meta.get('summary','')}\n"
    WHEEL = "Wheel-Version: 1.0\nGenerator: wheelmaker\nRoot-Is-Purelib: true\nTag: py3-none-any\n"

    records = []

    def zwrite(zf, arcname, data_bytes):
        zf.writestr(arcname, data_bytes)
        digest = hashlib.sha256(data_bytes).digest()
        rec = f"{arcname},sha256={base64.urlsafe_b64encode(digest).decode().rstrip('=')},{len(data_bytes)}"
        records.append(rec)

    with zipfile.ZipFile(wheel_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        # add package files
        for root, _, files in os.walk(pkg_dir):
            for f in files:
                fp = os.path.join(root, f)
                rel = os.path.relpath(fp, pkg_root)
                arc = rel.replace("\\\\","/")
                with open(fp, "rb") as fh: data = fh.read()
                zwrite(z, arc, data)

        # dist-info
        zwrite(z, f"{dist_info}/METADATA", METADATA.encode("utf-8"))
        zwrite(z, f"{dist_info}/WHEEL", WHEEL.encode("utf-8"))
        # RECORD placeholder
        z.writestr(f"{dist_info}/RECORD", "")

    # reopen to write RECORD with correct content
    with zipfile.ZipFile(wheel_path, "a", compression=zipfile.ZIP_DEFLATED) as z:
        record_content = "\n".join(records + [f"{dist_info}/RECORD,,"]).encode("utf-8")
        z.writestr(f"{dist_info}/RECORD", record_content)

    return wheel_path

def build_all(base_root):
    dist = os.path.join(base_root, "dist"); os.makedirs(dist, exist_ok=True)
    pkgs = [p for p in os.listdir(os.path.join(base_root, "packages"))]
    built = []
    for p in pkgs:
        pkg_root = os.path.join(base_root, "packages", p)
        try:
            wheel = build_wheel(pkg_root, dist)
            built.append(wheel)
        except Exception as e:
            print("Failed building", p, e)
    return built

if __name__ == "__main__":
    base = str(pathlib.Path(__file__).resolve().parents[1])
    built = build_all(base)
    print("Built wheels:", built)
