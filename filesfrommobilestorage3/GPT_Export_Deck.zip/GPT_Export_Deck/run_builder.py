import argparse, os, zipfile, json
from pathlib import Path
from lib.parser import load_export
from lib.deck import build_decks

def main(args):
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    conversations = load_export(args.zip)
    conv_df, msg_df = build_decks(conversations, str(out))
    # Write a short run README
    (out/"README_run.md").write_text(f"""
# RAG Deck Build — Summary
Conversations: {len(conv_df)}
Messages: {len(msg_df)}
Outputs:
- sessions/conv_cards.(csv|jsonl)
- messages/msg_cards.(csv|jsonl)
- index/ordered_index.csv
""")
    # Zip bundle
    import zipfile
    with zipfile.ZipFile(out.parent/"RAG_All.zip","w",zipfile.ZIP_DEFLATED) as z:
        for p in out.rglob("*"):
            if p.is_file():
                z.write(p, arcname=p.relative_to(out))
    print("Done. Bundle at:", str(out.parent/"RAG_All.zip"))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True, help="Path to ChatGPT export zip (contains conversations.json)")
    ap.add_argument("--out", required=True, help="Output directory for the decks")
    main(ap.parse_args())
