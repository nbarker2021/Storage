import json, zipfile, io
from typing import Dict, Any, List

def find_conversations_json(z: zipfile.ZipFile):
    # Standard ChatGPT export layout usually has 'conversations.json' at root
    for name in z.namelist():
        base = name.split("/")[-1].lower()
        if base == "conversations.json":
            return name
    return None

def load_export(zip_path: str):
    z = zipfile.ZipFile(zip_path, "r")
    conv_name = find_conversations_json(z)
    if conv_name is None:
        # Fallback: look for any JSON that contains "mapping" fields
        candidates = [n for n in z.namelist() if n.lower().endswith(".json")]
        for n in candidates:
            try:
                data = json.loads(z.read(n).decode("utf-8", errors="ignore"))
                if isinstance(data, list) and data and isinstance(data[0], dict) and "mapping" in data[0]:
                    conv_name = n; break
            except Exception:
                continue
    if conv_name is None:
        raise FileNotFoundError("Could not find conversations.json in the ZIP")
    data = json.loads(z.read(conv_name).decode("utf-8", errors="ignore"))
    return data
