import hashlib, re
from datetime import datetime, timezone

STOP = set("""a an and are as at be by for from has have in is it its of on or that the to was were will with this these those you your i we they them our""".split())

def nibble(s: str) -> str:
    return format(int(hashlib.sha256(s.encode()).hexdigest()[0],16), "04b")

def top_words(text: str, k=7):
    text = (text or "").lower()
    words = re.findall(r"[a-z][a-z0-9\-]{2,}", text)
    words = [w for w in words if w not in STOP and not w.isdigit()]
    freq = {}
    for w in words: freq[w] = freq.get(w,0)+1
    return [w for w,_ in sorted(freq.items(), key=lambda x:(-x[1], x[0]))[:k]]

def norm_time(ts):
    # Accept epoch or ISO; return ISO UTC
    if ts is None: return ""
    try:
        # epoch seconds
        if isinstance(ts, (int, float)):
            return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
        # string
        from dateutil import parser
        return parser.parse(str(ts)).astimezone(timezone.utc).isoformat()
    except Exception:
        return str(ts)
