import pandas as pd, json, math
from .utils import nibble, top_words, norm_time

def iter_messages(conv):
    # ChatGPT export uses a mapping graph; reconstruct linear order by parent links
    mapping = conv.get("mapping", {})
    # find roots (parent None) then walk children in timestamp order if available
    # build flat list
    nodes = []
    for mid, node in mapping.items():
        msg = node.get("message") or {}
        author = (msg.get("author") or {}).get("role","")
        content = msg.get("content") or {}
        parts = content.get("parts") or []
        text = "\n".join(p for p in parts if isinstance(p,str))
        create_time = msg.get("create_time") or conv.get("create_time")
        nodes.append({
            "message_id": mid,
            "author": author,
            "text": text,
            "create_time": create_time,
            "parent": node.get("parent"),
            "children": node.get("children") or []
        })
    # heuristics: sort by create_time then fall back to author order
    nodes.sort(key=lambda r: (r["create_time"] if r["create_time"] is not None else 0, r["author"]))
    # linearize into (index, node)
    for i, n in enumerate(nodes):
        n["index"] = i
    return nodes

def build_decks(conversations, outdir: str):
    import os
    os.makedirs(outdir, exist_ok=True)
    conv_rows = []
    msg_rows = []
    for ci, conv in enumerate(conversations):
        cid = str(conv.get("id") or conv.get("conversation_id") or f"conv_{ci:06d}")
        title = conv.get("title") or "(untitled)"
        create_time = norm_time(conv.get("create_time"))
        nodes = iter_messages(conv)
        authors = sorted(set(n["author"] for n in nodes if n["author"]))
        n_msgs = len(nodes)
        conv_rows.append({
            "conv_id": cid,
            "title": title,
            "created": create_time,
            "n_messages": n_msgs,
            "authors": ",".join(authors),
            "tags": ",".join(top_words(title, k=7)),
            "receipt": nibble(f"{cid}|{title}|{n_msgs}")
        })
        for j, n in enumerate(nodes):
            txt = (n["text"] or "").strip()
            preview = (txt.splitlines() or [""])[0][:200]
            msg_rows.append({
                "conv_id": cid,
                "msg_idx": j,
                "message_id": n["message_id"],
                "author": n["author"],
                "created": norm_time(n["create_time"]),
                "preview": preview,
                "tags": ",".join(top_words(txt, k=7)),
                "prev_msg_idx": j-1 if j>0 else -1,
                "next_msg_idx": j+1 if j+1<n_msgs else -1,
                "receipt": nibble(f"{cid}|{j}|{n['author']}|{preview[:32]}")
            })
    # deterministic sort
    conv_df = pd.DataFrame(conv_rows).sort_values(by=["created","conv_id"], kind="mergesort").reset_index(drop=True)
    msg_df  = pd.DataFrame(msg_rows).sort_values(by=["conv_id","msg_idx"], kind="mergesort").reset_index(drop=True)
    # assign pal-64 steps cycling for global order
    conv_df["pal64_step"] = [(i%64)+1 for i in range(len(conv_df))]
    msg_df["pal64_step"]  = [(i%64)+1 for i in range(len(msg_df))]
    # write
    import os
    conv_dir = os.path.join(outdir, "sessions"); os.makedirs(conv_dir, exist_ok=True)
    msg_dir  = os.path.join(outdir, "messages"); os.makedirs(msg_dir, exist_ok=True)
    conv_df.to_csv(os.path.join(conv_dir,"conv_cards.csv"), index=False)
    msg_df.to_csv(os.path.join(msg_dir,"msg_cards.csv"), index=False)
    with open(os.path.join(conv_dir,"conv_cards.jsonl"),"w") as f:
        for _, r in conv_df.iterrows(): f.write(json.dumps(r.to_dict(), ensure_ascii=False)+"\n")
    with open(os.path.join(msg_dir,"msg_cards.jsonl"),"w") as f:
        for _, r in msg_df.iterrows(): f.write(json.dumps(r.to_dict(), ensure_ascii=False)+"\n")
    # ordered index
    import numpy as np, pandas as pd
    idx = msg_df[["conv_id","msg_idx","author","created","pal64_step","receipt"]].copy()
    idx.to_csv(os.path.join(outdir,"index","ordered_index.csv"), index=False)
    return conv_df, msg_df
