# GPT Export → Multi‑Scale RAG Deck Builder

**What it does:** Given your ChatGPT export ZIP, this builds **deterministic RAG decks** at two scales:
- **Conversations (sessions)** — one card per conversation
- **Messages (turns)** — one card per message (user/assistant/system), linked to its conversation and neighbors

**Deterministic, CQE‑native:** No monitoring, no embeddings required. Stable ordering keys, pal‑64 assignment, and 4‑bit receipts.

## Quick run (once you've uploaded your export)
```bash
python run_builder.py --zip /mnt/data/gpt_export.zip --out /mnt/data/derived/gpt_export_deck
```

Artifacts:
- `sessions/conv_cards.jsonl` and `.csv`
- `messages/msg_cards.jsonl` and `.csv`
- `index/ordered_index.csv` (stable global order)
- `README_run.md` (summary & counts)
- `RAG_All.zip` (bundle)

If your ZIP is named differently, change the `--zip` path.
