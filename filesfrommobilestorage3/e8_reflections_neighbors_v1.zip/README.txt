
E8 toolkit artifacts
====================
- roots: 240 vectors in /mnt/data/e8_tools/e8_roots.npy
- neighbor graph: edges + degree stats

Sanity checks:
- reflection closure (sampled): checks=1200, ok=1200, bad=0
- neighbor degrees: {'min': 56, 'max': 56, 'mean': 56.0, 'median': 56.0}

Orbit demo:
- start index 0, orbit size (200 random simple-root reflections): 32
