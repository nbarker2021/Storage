# gpt_gode_for_agrm_cmplx_81025 — Code Deep Pass


---
## gpt gode for agrm-cmplx/other documents/AGRM_refactored (1).py
- Ext: .py | Lines: 531 | Words: 2475

---
## gpt gode for agrm-cmplx/other documents/AGRM_refactored (2).py
- Ext: .py | Lines: 597 | Words: 2784

---
## gpt gode for agrm-cmplx/other documents/AGRM_refactored (3).py
- Ext: .py | Lines: 778 | Words: 3884

---
## gpt gode for agrm-cmplx/other documents/AGRM_refactored (4).py
- Ext: .py | Lines: 868 | Words: 4400

---
## gpt gode for agrm-cmplx/other documents/AGRM_refactored.py
- Ext: .py | Lines: 418 | Words: 1838

---
## gpt gode for agrm-cmplx/other documents/test_hash.py
- Ext: .py | Lines: 13 | Words: 49

---
## gpt gode for agrm-cmplx/other documents/test_runtime.py
- Ext: .py | Lines: 14 | Words: 50

---
## gpt gode for agrm-cmplx/other documents/test_scoring.py
- Ext: .py | Lines: 14 | Words: 80

---
## gpt gode for agrm-cmplx/other documents/test_think_systems.py
- Ext: .py | Lines: 14 | Words: 54

---
## gpt gode for agrm-cmplx/thermodynamics work/rE2L_harness.py
- Ext: .py | Lines: 374 | Words: 2217

---
## gpt gode for agrm-cmplx/thermodynamics work/thermodynamics_testing_framework_reworked.py
- Ext: .py | Lines: 123 | Words: 566