# File: gpt gode for agrm-cmplx/other documents/test_think_systems.py

**Lines:** 14 | **Words:** 54

## Keyword Hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

## Python Analysis
- __main__ present: False
- Module docstring: 
- Imports: os
- From-imports: bestof_agrm.config, bestof_agrm.controller
- Classes: (none)
- Functions: test_governance_loop


---

## Full Source

```text

import os
from bestof_agrm.config import Config
from bestof_agrm.controller import RuntimeController

def test_governance_loop():
    os.environ["AGRM_SEED"] = "12345"
    cfg = Config(seed=12345, field="superpermutation", n_symbols=9, max_iters=100)
    ctl = RuntimeController.from_config(cfg)
    plan = ctl.govern({"goal": "optimize"})
    assert "chosen_variant" in plan
    res = ctl.execute(plan)
    assert "delta" in res and isinstance(res["delta"], float)

```