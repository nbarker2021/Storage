# File: gpt gode for agrm-cmplx/other documents/test_runtime.py

**Lines:** 14 | **Words:** 50

## Keyword Hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

## Python Analysis
- __main__ present: False
- Module docstring: 
- Imports: os
- From-imports: bestof_agrm.config, bestof_agrm.controller
- Classes: (none)
- Functions: test_runtime_smoke


---

## Full Source

```text

import os
from bestof_agrm.config import Config
from bestof_agrm.controller import RuntimeController

def test_runtime_smoke():
    os.environ["AGRM_SEED"] = "12345"
    cfg = Config(seed=12345, field="superpermutation", n_symbols=4, max_iters=100)
    ctl = RuntimeController.from_config(cfg)
    selected = ctl.run_once(candidate_count=16, top_k=5)
    assert len(selected) == 5
    snap = ctl.results_snapshot()
    assert len(snap) >= 5

```