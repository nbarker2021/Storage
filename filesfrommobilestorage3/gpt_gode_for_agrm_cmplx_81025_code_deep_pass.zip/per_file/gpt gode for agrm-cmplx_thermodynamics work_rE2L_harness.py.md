# File: gpt gode for agrm-cmplx/thermodynamics work/rE2L_harness.py

**Lines:** 374 | **Words:** 2217

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

## Python Analysis
- __main__ present: True
- Module docstring: rE2L_harness: Refined Extended Second Law testing harness (callable, class-based)

This module implements a self-contained, falsifiable workflow to simulate, fit, and
analyze entropy production using a refined-Extended-2nd-Law decomposition:

    dS/dt = k_B ∫ [ D (∇p)^2/p  +  p ∇·v  +  ∇κ_I · ∇(-ln p) ] dx  +  k_B Φ R_sp(t)

where
- p(x,t) is a probability density on a 1D periodic domain, ∫ p dx = 1,
- D is diffusivity, v is drift velocity, κ_I is information-flow conductivity,
- R_sp(t) is a measurable rate-like complexity proxy.

This module provides:
- A semi-implicit simulator for p(x,t) 
- Imports: matplotlib.pyplot, numpy, os
- From-imports: dataclasses, typing
- Classes: RE2LConfig, RE2LTester
- Functions: periodic_gradient, periodic_laplacian, entropy_from_p_dx, permutation_entropy, __init__, build_lambda_field, semi_implicit_step, init_density, compute_predictors, run_case, fit_linear, bootstrap_ci, save_case_artifacts, run_ablation_suite, run_param_sweep, ci


---

## Full Source

```text

"""
rE2L_harness: Refined Extended Second Law testing harness (callable, class-based)

This module implements a self-contained, falsifiable workflow to simulate, fit, and
analyze entropy production using a refined-Extended-2nd-Law decomposition:

    dS/dt = k_B ∫ [ D (∇p)^2/p  +  p ∇·v  +  ∇κ_I · ∇(-ln p) ] dx  +  k_B Φ R_sp(t)

where
- p(x,t) is a probability density on a 1D periodic domain, ∫ p dx = 1,
- D is diffusivity, v is drift velocity, κ_I is information-flow conductivity,
- R_sp(t) is a measurable rate-like complexity proxy.

This module provides:
- A semi-implicit simulator for p(x,t) with diffusion, explicit info-Laplacian coupling, and drift.
- Predictors X0, X1, X2, and X2_perm (permutation entropy rate) to explain dS/dt.
- Linear-model fits, ablation tests, and bootstrap confidence intervals.
- Parameter sweeps and artifact generation (plots + JSON/CSV).

USAGE (minimal):
---------------
from rE2L_harness import RE2LConfig, RE2LTester

cfg = RE2LConfig(out_dir="./artifacts", seed=7)
tester = RE2LTester(cfg)
case = tester.run_case(name="baseline", v=0.0, lambda0=0.3, beta=0.8)
tester.save_case_artifacts(case)

# Ablations on a pair of cases:
results = tester.run_ablation_suite([
    {"name":"baseline", "v":0.0, "lambda0":0.3, "beta":0.8},
    {"name":"biased", "v":0.5, "lambda0":0.3, "beta":0.8},
])

# Parameter sweep:
sweep = tester.run_param_sweep(
    v_list=[0.0, 0.5],
    lambda0_list=[0.1, 0.3, 0.6],
    beta_list=[0.0, 0.5, 0.9]
)
tester.save_sweep(sweep)

NOTES:
- No external data sources; all results are reproducible with the cfg seed.
- Plots use matplotlib only; no seaborn, no style overrides.
"""

from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Tuple, Optional
import numpy as np
import matplotlib.pyplot as plt
import os, json, csv

# -----------------------------
# Config and core utilities
# -----------------------------

@dataclass
class RE2LConfig:
    out_dir: str = "./artifacts"
    seed: int = 7
    # Domain and numerics
    L: float = 1.0
    N: int = 512
    D: float = 0.01
    alpha: float = 0.01          # coupling for info-Laplacian term
    T: float = 1.0
    kB: float = 1.0              # nats
    cfl: float = 0.25            # time step heuristic (dt ~ cfl * dx^2 / D)
    # Lambda field defaults
    lambda_profile: str = "sinusoidal"  # "sinusoidal" or "constant"
    lambda0: float = 0.3
    beta: float = 0.8
    # Drift
    v: float = 0.0               # constant drift; incompressible in 1D
    # Bootstrap for CIs
    bootstrap_B: int = 60
    bootstrap_seed: int = 123

def periodic_gradient(arr: np.ndarray, dx: float) -> np.ndarray:
    return (np.roll(arr, -1) - np.roll(arr, 1)) / (2*dx)

def periodic_laplacian(arr: np.ndarray, dx: float) -> np.ndarray:
    return (np.roll(arr, -1) - 2*arr + np.roll(arr, 1)) / (dx*dx)

def entropy_from_p_dx(p: np.ndarray, dx: float, kB: float = 1.0, eps: float = 1e-12) -> float:
    p_safe = np.clip(p, eps, None)
    return -kB * np.sum(p_safe * np.log(p_safe)) * dx

def permutation_entropy(signal: np.ndarray, m: int = 3, eps: float = 1e-15) -> float:
    """Permutation entropy over a spatial signal (normalized to [0,1])."""
    x = np.array(signal, dtype=float)
    n = len(x)
    if n < m:
        return 0.0
    patterns = {}
    for i in range(n - m + 1):
        window = x[i:i+m]
        order = tuple(np.argsort(window))
        patterns[order] = patterns.get(order, 0) + 1
    counts = np.array(list(patterns.values()), dtype=float)
    probs = counts / np.sum(counts)
    H = -np.sum(probs * np.log(probs + eps))
    H_norm = H / np.log(np.math.factorial(m))
    return float(H_norm)

# -----------------------------
# Simulator and predictors
# -----------------------------

class RE2LTester:
    def __init__(self, cfg: RE2LConfig):
        self.cfg = cfg
        os.makedirs(cfg.out_dir, exist_ok=True)
        # Prepare grid
        self.x = np.linspace(0, cfg.L, cfg.N, endpoint=False)
        self.dx = self.x[1] - self.x[0]
        self.dt = cfg.cfl * self.dx * self.dx / (cfg.D + 1e-12)
        self.steps = int(np.floor(cfg.T / self.dt))
        self.rng = np.random.default_rng(cfg.seed)

    def build_lambda_field(self, lambda0: float, beta: float, profile: Optional[str] = None) -> np.ndarray:
        if profile is None:
            profile = self.cfg.lambda_profile
        if profile == "constant":
            return lambda0 * np.ones_like(self.x)
        return lambda0 * (1.0 + beta * np.sin(2*np.pi*self.x / self.cfg.L))

    def semi_implicit_step(self, p: np.ndarray, Lambda_x: np.ndarray, v: float):
        """One time step: semi-implicit diffusion + explicit info-Laplacian + explicit advection (constant drift)."""
        eps = 1e-14
        p_safe = np.clip(p, eps, None)
        I = -p_safe * np.log(p_safe)
        lap_I = periodic_laplacian(I, self.dx)
        # Advection (constant v), incompressible in 1D: -v ∂p/∂x
        adv_term = -v * periodic_gradient(p, self.dx)
        rhs = p + self.dt * (self.cfg.alpha * lap_I + adv_term)

        # Implicit diffusion in Fourier space: (I - dt D ∇²) p^{n+1} = rhs
        N = p.size
        k = 2*np.pi*np.fft.fftfreq(N, d=self.dx)
        lap_eigs = -(k**2)
        rhs_hat = np.fft.fft(rhs)
        denom = (1 - self.dt * self.cfg.D * lap_eigs)
        p_next = np.real(np.fft.ifft(rhs_hat / denom))

        p_next = np.maximum(p_next, eps)
        p_next /= np.sum(p_next) * self.dx
        dpdt = (p_next - p) / self.dt
        return p_next, I, lap_I, dpdt

    def init_density(self) -> np.ndarray:
        # Structured + noise initial condition
        x = self.x
        p0 = np.exp(2*np.sin(2*np.pi*x) + 0.5*np.sin(6*np.pi*x) + 0.2*self.rng.standard_normal(size=self.cfg.N))
        p0 = np.maximum(p0, 1e-12)
        p0 /= np.sum(p0) * self.dx
        return p0

    def compute_predictors(self, p: np.ndarray, I: np.ndarray, dpdt: np.ndarray, Lambda_x: np.ndarray, v: float) -> Dict[str, float]:
        # X0 = ∫ [D (∇p)^2/p + p ∇·v] dx; here ∇·v = 0 for constant v
        grad_p = periodic_gradient(p, self.dx)
        X0 = np.sum(self.cfg.D * (grad_p**2) / np.clip(p, 1e-14, None)) * self.dx
        # X1 = ∫ Λ ∇²I dx = -∫ (∂Λ/∂x)(∂I/∂x) dx  (periodic BC)
        dLambda_dx = periodic_gradient(Lambda_x, self.dx)
        dI_dx = periodic_gradient(I, self.dx)
        X1 = -np.sum(dLambda_dx * dI_dx) * self.dx
        # X2 = ∫ |∂p/∂t| dx (rate-like complexity proxy)
        X2 = np.sum(np.abs(dpdt)) * self.dx
        return {"X0": float(X0), "X1": float(X1), "X2": float(X2)}

    def run_case(self, name: str, v: Optional[float] = None, lambda0: Optional[float] = None, beta: Optional[float] = None,
                 lambda_profile: Optional[str] = None, m_perm: int = 3) -> Dict[str, Any]:
        """Run a single simulation case and return time series and design matrices."""
        v = self.cfg.v if v is None else v
        lambda0 = self.cfg.lambda0 if lambda0 is None else lambda0
        beta = self.cfg.beta if beta is None else beta
        Lambda_x = self.build_lambda_field(lambda0, beta, profile=lambda_profile)

        p = self.init_density()
        # Containers
        S_list, t_list, y_list = [], [], []
        X0_list, X1_list, X2_list, X2p_list = [], [], [], []

        # First step to prime
        perm_prev = permutation_entropy(p, m=m_perm)
        p, I, lap_I, dpdt = self.semi_implicit_step(p, Lambda_x, v)
        S_prev = entropy_from_p_dx(p, self.dx, kB=self.cfg.kB); t_prev = self.dt
        preds = self.compute_predictors(p, I, dpdt, Lambda_x, v)
        X0, X1, X2 = preds["X0"], preds["X1"], preds["X2"]
        perm_now = permutation_entropy(p, m=m_perm)
        X2p = abs((perm_now - perm_prev) / self.dt)
        # record
        S_list.append(S_prev); t_list.append(t_prev)
        y_list.append(np.nan)  # dS/dt placeholder for first index
        X0_list += [X0]; X1_list += [X1]; X2_list += [X2]; X2p_list += [X2p]
        perm_prev = perm_now

        for n in range(1, self.steps):
            p, I, lap_I, dpdt = self.semi_implicit_step(p, Lambda_x, v)
            S_now = entropy_from_p_dx(p, self.dx, kB=self.cfg.kB); t_now = (n+1)*self.dt
            preds = self.compute_predictors(p, I, dpdt, Lambda_x, v)
            X0, X1, X2 = preds["X0"], preds["X1"], preds["X2"]
            perm_now = permutation_entropy(p, m=m_perm)
            X2p = abs((perm_now - perm_prev) / self.dt)
            perm_prev = perm_now

            dSdt_obs = (S_now - S_prev) / (t_now - t_prev)

            S_list.append(S_now); t_list.append(t_now); y_list.append(dSdt_obs)
            X0_list += [X0]; X1_list += [X1]; X2_list += [X2]; X2p_list += [X2p]
            S_prev = S_now; t_prev = t_now

        # Assemble arrays and design matrices
        S = np.array(S_list); t = np.array(t_list); y = np.array(y_list)
        X0 = np.array(X0_list); X1 = np.array(X1_list); X2 = np.array(X2_list); X2p = np.array(X2p_list)
        valid = np.isfinite(y)
        y = y[valid]; t_valid = t[valid]; X0 = X0[valid]; X1 = X1[valid]; X2 = X2[valid]; X2p = X2p[valid]

        X_B01 = np.column_stack([np.ones_like(y), X0, X1])
        X_FullA = np.column_stack([np.ones_like(y), X0, X1, X2])
        X_FullB = np.column_stack([np.ones_like(y), X0, X1, X2p])

        return {
            "name": name,
            "params": {"v": v, "lambda0": lambda0, "beta": beta, "lambda_profile": lambda_profile or self.cfg.lambda_profile},
            "t": t, "S": S, "t_valid": t_valid, "y": y,
            "X0": X0, "X1": X1, "X2": X2, "X2p": X2p,
            "X_B01": X_B01, "X_FullA": X_FullA, "X_FullB": X_FullB
        }

    @staticmethod
    def fit_linear(X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        yhat = X @ coef
        resid = y - yhat
        ss_res = float(np.sum(resid**2))
        ss_tot = float(np.sum((y - np.mean(y))**2)) + 1e-12
        r2 = 1.0 - ss_res/ss_tot
        rmse = float(np.sqrt(ss_res/len(y)))
        return {"coef": coef, "yhat": yhat, "resid": resid, "R2": float(r2), "RMSE": rmse}

    def bootstrap_ci(self, X: np.ndarray, y: np.ndarray, B: Optional[int] = None, seed: Optional[int] = None) -> Dict[str, Any]:
        B = self.cfg.bootstrap_B if B is None else B
        seed = self.cfg.bootstrap_seed if seed is None else seed
        rng = np.random.default_rng(seed)
        n, k = X.shape
        coefs = np.zeros((B, k)); r2s = np.zeros(B); rmses = np.zeros(B)
        for b in range(B):
            idx = rng.integers(0, n, size=n)
            res = self.fit_linear(X[idx], y[idx])
            coefs[b, :] = res["coef"]; r2s[b] = res["R2"]; rmses[b] = res["RMSE"]
        def ci(arr: np.ndarray) -> Tuple[float, float]:
            return float(np.percentile(arr, 2.5)), float(np.percentile(arr, 97.5))
        return {"coef_ci": [ci(coefs[:, j]) for j in range(k)], "R2_ci": ci(r2s), "RMSE_ci": ci(rmses)}

    def save_case_artifacts(self, case: Dict[str, Any]) -> Dict[str, Any]:
        name = case["name"]
        out_dir = os.path.join(self.cfg.out_dir, name)
        os.makedirs(out_dir, exist_ok=True)

        B01 = self.fit_linear(case["X_B01"], case["y"])
        FullA = self.fit_linear(case["X_FullA"], case["y"])
        FullB = self.fit_linear(case["X_FullB"], case["y"])

        B01_ci = self.bootstrap_ci(case["X_B01"], case["y"])
        FullA_ci = self.bootstrap_ci(case["X_FullA"], case["y"])
        FullB_ci = self.bootstrap_ci(case["X_FullB"], case["y"])

        results = {
            "name": name,
            "params": case["params"],
            "B01": {"coef": B01["coef"].tolist(), "R2": B01["R2"], "RMSE": B01["RMSE"],
                    "coef_ci": B01_ci["coef_ci"], "R2_ci": B01_ci["R2_ci"], "RMSE_ci": B01_ci["RMSE_ci"]},
            "FullA": {"coef": FullA["coef"].tolist(), "R2": FullA["R2"], "RMSE": FullA["RMSE"],
                      "coef_ci": FullA_ci["coef_ci"], "R2_ci": FullA_ci["R2_ci"], "RMSE_ci": FullA_ci["RMSE_ci"]},
            "FullB": {"coef": FullB["coef"].tolist(), "R2": FullB["R2"], "RMSE": FullB["RMSE"],
                      "coef_ci": FullB_ci["coef_ci"], "R2_ci": FullB_ci["R2_ci"], "RMSE_ci": FullB_ci["RMSE_ci"]},
            "deltaA": {"R2": FullA["R2"] - B01["R2"], "RMSE": B01["RMSE"] - FullA["RMSE"]},
            "deltaB": {"R2": FullB["R2"] - B01["R2"], "RMSE": B01["RMSE"] - FullB["RMSE"]},
        }

        with open(os.path.join(out_dir, "results.json"), "w") as f:
            json.dump(results, f, indent=2)

        t = case["t_valid"]; y = case["y"]
        yhatA = case["X_FullA"] @ np.array(results["FullA"]["coef"])
        yhatB = case["X_FullB"] @ np.array(results["FullB"]["coef"])

        plt.figure()
        plt.plot(case["t"], case["S"])
        plt.xlabel("time"); plt.ylabel("S(t) [nats]")
        plt.title(f"Entropy over time — {name}")
        plt.tight_layout(); plt.savefig(os.path.join(out_dir, "plot_entropy_over_time.png"), dpi=150); plt.close()

        plt.figure()
        plt.plot(t, y, label="Observed dS/dt")
        plt.plot(t, yhatA, label="Fitted (FullA: X0+X1+X2)")
        plt.plot(t, yhatB, label="Fitted (FullB: X0+X1+X2_perm)")
        plt.xlabel("time"); plt.ylabel("dS/dt [nats/time]")
        plt.title(f"Observed vs Full Models — {name}")
        plt.legend()
        plt.tight_layout(); plt.savefig(os.path.join(out_dir, "plot_obs_vs_full.png"), dpi=150); plt.close()

        plt.figure()
        labelsA = ["Intercept", "a0 (X0)", "a1 (X1=∫Λ∇²I)", "a2 (X2=R_sp)"]
        idx = np.arange(len(labelsA))
        plt.bar(idx, results["FullA"]["coef"])
        plt.xticks(idx, labelsA, rotation=20); plt.ylabel("Coefficient")
        plt.title(f"FullA Coefficients — {name}")
        plt.tight_layout(); plt.savefig(os.path.join(out_dir, "plot_coefficients_fullA.png"), dpi=150); plt.close()

        plt.figure()
        labelsB = ["Intercept", "a0 (X0)", "a1 (X1=∫Λ∇²I)", "a2_perm (X2_perm)"]
        idx = np.arange(len(labelsB))
        plt.bar(idx, results["FullB"]["coef"])
        plt.xticks(idx, labelsB, rotation=20); plt.ylabel("Coefficient")
        plt.title(f"FullB Coefficients — {name}")
        plt.tight_layout(); plt.savefig(os.path.join(out_dir, "plot_coefficients_fullB.png"), dpi=150); plt.close()

        return results

    def run_ablation_suite(self, cases: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        results_all = []
        for c in cases:
            case = self.run_case(**c)
            res = self.save_case_artifacts(case)
            results_all.append(res)
        table_path = os.path.join(self.cfg.out_dir, "summary_table.csv")
        with open(table_path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["name", "R2_B01", "R2_FullA", "R2_FullB", "deltaR2_A", "deltaR2_B", "RMSE_B01", "RMSE_FullA", "RMSE_FullB"])
            for r in results_all:
                w.writerow([
                    r["name"], r["B01"]["R2"], r["FullA"]["R2"], r["FullB"]["R2"],
                    r["deltaA"]["R2"], r["deltaB"]["R2"],
                    r["B01"]["RMSE"], r["FullA"]["RMSE"], r["FullB"]["RMSE"]
                ])
        return results_all

    def run_param_sweep(self, v_list: List[float], lambda0_list: List[float], beta_list: List[float]) -> List[Dict[str, Any]]:
        summary = []
        for v in v_list:
            for lam0 in lambda0_list:
                for beta in beta_list:
                    name = f"v{v}_l{lam0}_b{beta}"
                    case = self.run_case(name=name, v=v, lambda0=lam0, beta=beta, lambda_profile="sinusoidal")
                    res = self.save_case_artifacts(case)
                    summary.append(res)
        table_path = os.path.join(self.cfg.out_dir, "sweep_summary.csv")
        with open(table_path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["name","v","lambda0","beta","R2_B01","R2_FullA","R2_FullB","deltaR2_A","deltaR2_B","RMSE_B01","RMSE_FullA","RMSE_FullB"])
            for r in summary:
                p = r["params"]
                w.writerow([
                    r["name"], p["v"], p["lambda0"], p["beta"],
                    r["B01"]["R2"], r["FullA"]["R2"], r["FullB"]["R2"],
                    r["deltaA"]["R2"], r["deltaB"]["R2"],
                    r["B01"]["RMSE"], r["FullA"]["RMSE"], r["FullB"]["RMSE"]
                ])
        return summary

if __name__ == "__main__":
    cfg = RE2LConfig(out_dir="./rE2L_artifacts_demo", N=256, T=0.5)
    tester = RE2LTester(cfg)
    results = tester.run_ablation_suite([
        {"name":"baseline", "v":0.0, "lambda0":0.3, "beta":0.8},
        {"name":"biased",   "v":0.5, "lambda0":0.3, "beta":0.8},
    ])
    _ = tester.run_param_sweep(v_list=[0.0,0.5], lambda0_list=[0.1,0.3], beta_list=[0.0,0.8])
    print("Artifacts written to:", cfg.out_dir)

```