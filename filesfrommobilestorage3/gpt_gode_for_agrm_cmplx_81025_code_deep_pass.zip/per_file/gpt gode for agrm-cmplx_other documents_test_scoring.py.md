# File: gpt gode for agrm-cmplx/other documents/test_scoring.py

**Lines:** 14 | **Words:** 80

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

## Python Analysis
- __main__ present: False
- Module docstring: 
- Imports: (none)
- From-imports: bestof_agrm.scoring
- Classes: (none)
- Functions: test_prodigal_selection


---

## Full Source

```text

from bestof_agrm.scoring import prodigal_selection

def test_prodigal_selection():
    items = [
        {"novelty": 0.2, "consistency": 0.9, "path_cost": 0.1, "coverage": 0.6, "stability": 0.7},
        {"novelty": 0.95, "consistency": 0.2, "path_cost": 0.8, "coverage": 0.2, "stability": 0.3},
        {"novelty": 0.6, "consistency": 0.6, "path_cost": 0.4, "coverage": 0.6, "stability": 0.6},
    ]
    w = {"novelty": 1, "consistency": 1, "path_cost": 1, "coverage": 1, "stability": 1}
    sel = prodigal_selection(items, w, k=2)
    assert len(sel) == 2
    assert isinstance(sel[0][0], float)

```