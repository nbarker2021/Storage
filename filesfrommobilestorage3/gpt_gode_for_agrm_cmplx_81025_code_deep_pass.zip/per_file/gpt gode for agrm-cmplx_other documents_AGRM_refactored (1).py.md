# File: gpt gode for agrm-cmplx/other documents/AGRM_refactored (1).py

**Lines:** 531 | **Words:** 2475

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 19
- MDHG: 7
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 12
- golden: 1
- glyph: 0
- lattice: 0

## Python Analysis
- __main__ present: True
- Module docstring: 
- Imports: math
- From-imports: __future__, collections, dataclasses, typing
- Classes: AGRMConfig, Trace, Shortcuts, _Meta, _Entry, _Room, _Floor, _Building, MDHGHashTable, SweepState, AGRMController, AGRMAudit
- Functions: fnv1a64, stable_hash64, _collect_hit_hist, __init__, add, dump, __init__, learn, next_hop, __init__, __init__, __init__, __init__, __init__, __init__, _pick_building, _pick_floor, _pick_room, put, get, remove, _touch, _promote, _demote, _move, idle_sweep, _maybe_resize, _resize, items, stats, __init__, trace_dump, snapshot, __init__, _score_vector, _tune_from_sweeps, run_sweeps, run_demo, summarize


---

## Full Source

```text

# ===========================================================
# === AGRM System (Refactored "Best-of" Single-File Build) ===
# ===========================================================
# Goals:
# - Preserve public API names (MDHGHashTable, AGRMController, AGRMAudit)
# - Centralize configuration in AGRMConfig
# - Bounded, consistent tracing and snapshot output
# - Hierarchical MDHG (Building→Floor→Room) with φ-resizing, velocity tiers
# - Shortcuts (co-visit routing) and promotion/demotion cadence
# - Clean typing, __slots__, EAFP hashing, and safe defaults
# - Self-test: run "python AGRM_refactored.py" to sanity-check

from __future__ import annotations
import math, time, json, random
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Optional, Iterable
from collections import defaultdict

# -----------------------------
# Configuration & Utilities
# -----------------------------

@dataclass(frozen=True)
class AGRMConfig:
    phi_scale: float = 1.618
    target_load: float = 0.70
    floors_per_building: int = 3
    rooms_per_floor: int = 64
    promote_hits: int = 8
    demote_after_idle: int = 10
    decay_rate: float = 0.85
    enable_shortcuts: bool = True
    trace_limit: int = 20000
    resize_policy: str = "phi"  # "phi" | "double" | "none"

def fnv1a64(data: bytes) -> int:
    h = 0xcbf29ce484222325
    for b in data:
        h ^= b
        h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
    return h

def stable_hash64(key: Any) -> int:
    try:
        b = key if isinstance(key, (bytes, bytearray)) else str(key).encode("utf-8", "ignore")
    except Exception:
        b = repr(key).encode("utf-8", "ignore")
    return fnv1a64(b)

class Trace:
    __slots__ = ("_buf","_limit")
    def __init__(self, limit: int):
        self._buf: List[Tuple[str, Dict[str, Any]]] = []
        self._limit = int(limit)

    def add(self, event: str, **kv):
        if len(self._buf) < self._limit:
            self._buf.append((event, kv))

    def dump(self) -> List[Tuple[str, Dict[str, Any]]]:
        return list(self._buf)

class Shortcuts:
    __slots__ = ("co","hits","misses")
    def __init__(self):
        self.co: Dict[Tuple[int,int], int] = defaultdict(int)
        self.hits = 0
        self.misses = 0

    def learn(self, r1: int, r2: int):
        self.co[(r1, r2)] += 1

    def next_hop(self, r1: int) -> Optional[int]:
        cands = [(cnt, dst) for (src, dst), cnt in self.co.items() if src == r1]
        if not cands:
            self.misses += 1
            return None
        cands.sort(reverse=True)
        self.hits += 1
        return cands[0][1]

# -----------------------------
# Hierarchical MDHG Hash Table
# -----------------------------

class _Meta:
    __slots__ = ("hits","floor","room","building","last_touch")
    def __init__(self, floor=0, room=0, building=0):
        self.hits = 0
        self.floor = floor
        self.room = room
        self.building = building
        self.last_touch = 0

class _Entry:
    __slots__ = ("key","value","meta")
    def __init__(self, key, value, meta: _Meta):
        self.key = key
        self.value = value
        self.meta = meta

class _Room:
    __slots__ = ("entries",)
    def __init__(self):
        self.entries: List[_Entry] = []

class _Floor:
    __slots__ = ("rooms","hamiltonian")
    def __init__(self, rooms: int):
        self.rooms: List[_Room] = [_Room() for _ in range(rooms)]
        # Simple snake Hamiltonian order
        self.hamiltonian: List[int] = list(range(rooms))

class _Building:
    __slots__ = ("floors",)
    def __init__(self, floors: int, rooms: int):
        self.floors: List[_Floor] = [_Floor(rooms) for _ in range(floors)]

class MDHGHashTable:
    """
    Multi-Dimensional Hamiltonian Golden-ratio Hash Table (hierarchical).
    Building -> Floor (velocity tier) -> Room (bucket)
    - φ-resizing (or other policies)
    - Promotion/demotion based on hits and idle decay
    - Shortcuts (co-visit) learning
    - Bounded tracing and snapshot-friendly stats
    Public API: put/get/remove/items/stats
    """

    def __init__(self, config: Optional[AGRMConfig] = None, *, buildings:int=1):
        self.cfg = config or AGRMConfig()
        self._buildings: List[_Building] = [_Building(self.cfg.floors_per_building, self.cfg.rooms_per_floor) for _ in range(buildings)]
        self._floors = self.cfg.floors_per_building
        self._rooms_per_floor = self.cfg.rooms_per_floor

        self._loc: Dict[Any, Tuple[int,int,int,int]] = {}  # key -> (b,f,r,idx)
        self._trace = Trace(self.cfg.trace_limit)
        self._shortcuts = Shortcuts() if self.cfg.enable_shortcuts else None

        # stats
        self.size = 0
        self.inserts = 0
        self.lookups = 0
        self.moves = 0
        self.promotions = 0
        self.demotions = 0
        self.resizes = 0
        self.tick = 0

    # ---- addressing helpers ----
    def _pick_building(self, h: int) -> int:
        return h % len(self._buildings)

    def _pick_floor(self, h: int, prefer: int = 0) -> int:
        return prefer % self._floors

    def _pick_room(self, h: int) -> int:
        rooms = self._rooms_per_floor
        # Power-of-two fast path
        return (h >> 32) & (rooms - 1) if (rooms & (rooms-1)) == 0 else h % rooms

    # ---- ops ----
    def put(self, key: Any, value: Any) -> None:
        self.tick += 1
        hh = stable_hash64(key)
        b = self._pick_building(hh)
        f = self._pick_floor(hh, 0)
        r = self._pick_room(hh)

        loc = self._loc.get(key)
        if loc is not None:
            ob, of, oroom, idx = loc
            room = self._buildings[ob].floors[of].rooms[oroom]
            if 0 <= idx < len(room.entries) and room.entries[idx].key == key:
                room.entries[idx].value = value
                self.inserts += 1
                return
            # stale index: repair via scan
            for j, e in enumerate(room.entries):
                if e.key == key:
                    e.value = value
                    self._loc[key] = (ob, of, oroom, j)
                    self.inserts += 1
                    return
        # new insert
        room = self._buildings[b].floors[f].rooms[r]
        ent = _Entry(key, value, _Meta(floor=f, room=r, building=b))
        room.entries.append(ent)
        self._loc[key] = (b, f, r, len(room.entries)-1)
        self.size += 1
        self.inserts += 1
        self._trace.add("put", key=str(key), b=b, f=f, r=r, size=self.size)
        self._maybe_resize()

    def get(self, key: Any, default=None) -> Any:
        self.tick += 1
        self.lookups += 1
        loc = self._loc.get(key)
        if not loc:
            self._trace.add("miss", key=str(key))
            return default
        b, f, r, idx = loc
        room = self._buildings[b].floors[f].rooms[r]
        if not (0 <= idx < len(room.entries)):
            self._trace.add("stale_index", key=str(key))
            return default
        ent = room.entries[idx]
        if ent.key != key:
            # repair
            for j, e in enumerate(room.entries):
                if e.key == key:
                    self._loc[key] = (b, f, r, j)
                    ent = e
                    break
            else:
                return default

        # touch & promote
        self._touch(ent)
        if self._shortcuts is not None:
            # learn co-visit with previous room (naive: use same room as src)
            self._shortcuts.learn(r, r)

        return ent.value

    def remove(self, key: Any) -> bool:
        loc = self._loc.pop(key, None)
        if not loc:
            return False
        b, f, r, idx = loc
        room = self._buildings[b].floors[f].rooms[r]
        if 0 <= idx < len(room.entries) and room.entries[idx].key == key:
            room.entries.pop(idx)
            # fix indices
            for j in range(idx, len(room.entries)):
                self._loc[room.entries[j].key] = (b, f, r, j)
            self.size -= 1
            self._trace.add("remove", key=str(key), b=b, f=f, r=r, size=self.size)
            return True
        # fallback scan
        for j, e in enumerate(room.entries):
            if e.key == key:
                room.entries.pop(j)
                for k in range(j, len(room.entries)):
                    self._loc[room.entries[k].key] = (b, f, r, k)
                self.size -= 1
                self._trace.add("remove_scan", key=str(key), b=b, f=f, r=r, size=self.size)
                return True
        return False

    # ---- internal mechanics ----
    def _touch(self, ent: _Entry):
        m = ent.meta
        m.hits = int(m.hits * self.cfg.decay_rate) + 1
        m.last_touch = self.tick
        # promotion policy
        if m.hits >= self.cfg.promote_hits and m.floor + 1 < self._floors:
            self._promote(ent)

    def _promote(self, ent: _Entry):
        # move entry to higher velocity floor, rehash room placement
        self.promotions += 1
        self._move(ent, new_floor=ent.meta.floor + 1)

    def _demote(self, ent: _Entry):
        if ent.meta.floor > 0:
            self.demotions += 1
            self._move(ent, new_floor=ent.meta.floor - 1)

    def _move(self, ent: _Entry, new_floor: int):
        # remove from old room
        key = ent.key
        b, f, r, idx = self._loc.get(key, (None, None, None, None))
        if b is None:  # shouldn't happen
            return
        room = self._buildings[b].floors[f].rooms[r]
        # find accurate index in case of staleness
        if not (0 <= idx < len(room.entries)) or room.entries[idx] is not ent:
            for j, e in enumerate(room.entries):
                if e is ent:
                    idx = j
                    break
        room.entries.pop(idx)
        for j in range(idx, len(room.entries)):
            self._loc[room.entries[j].key] = (b, f, r, j)

        # place in new floor
        h = stable_hash64(key)
        nr = self._pick_room(h)
        tgt = self._buildings[b].floors[new_floor].rooms[nr]
        ent.meta.floor = new_floor
        ent.meta.room = nr
        tgt.entries.append(ent)
        self._loc[key] = (b, new_floor, nr, len(tgt.entries)-1)
        self.moves += 1
        self._trace.add("move", key=str(key), from_f=f, to_f=new_floor, r=nr)

    def idle_sweep(self):
        # demote entries idle past threshold
        threshold = self.cfg.demote_after_idle
        for b in self._buildings:
            for f in range(self._floors-1, 0, -1):
                for r in range(self._rooms_per_floor):
                    room = b.floors[f].rooms[r]
                    for ent in list(room.entries):
                        if self.tick - ent.meta.last_touch >= threshold:
                            self._demote(ent)

    def _maybe_resize(self):
        rooms = len(self._buildings) * self._floors * self._rooms_per_floor
        load = self.size / max(1, rooms)
        if load <= self.cfg.target_load or self.cfg.resize_policy == "none":
            return
        if self.cfg.resize_policy == "phi":
            new_buildings = max(1, int(math.ceil(len(self._buildings) * self.cfg.phi_scale)))
        else:  # "double"
            new_buildings = max(1, len(self._buildings) * 2)
        self._resize(buildings=new_buildings)

    def _resize(self, buildings: int = None):
        nb = buildings or len(self._buildings)
        old_items = list(self.items())
        self._buildings = [_Building(self._floors, self._rooms_per_floor) for _ in range(nb)]
        self._loc.clear()
        self.size = 0
        self.resizes += 1
        for k, v in old_items:
            self.put(k, v)
        self._trace.add("resize", buildings=nb)

    # ---- iteration & stats ----
    def items(self) -> Iterable[Tuple[Any, Any]]:
        for b, bd in enumerate(self._buildings):
            for f, fl in enumerate(bd.floors):
                for r, rm in enumerate(fl.rooms):
                    for e in rm.entries:
                        yield (e.key, e.value)

    def stats(self) -> Dict[str, Any]:
        rooms = len(self._buildings) * self._floors * self._rooms_per_floor
        out = {
            "buildings": len(self._buildings),
            "floors": self._floors,
            "rooms_per_floor": self._rooms_per_floor,
            "total_rooms": rooms,
            "size": self.size,
            "load": self.size / rooms if rooms else 0.0,
            "inserts": self.inserts,
            "lookups": self.lookups,
            "moves": self.moves,
            "promotions": self.promotions,
            "demotions": self.demotions,
            "resizes": self.resizes,
            "shortcuts": {"hits": getattr(self._shortcuts, "hits", 0), "misses": getattr(self._shortcuts, "misses", 0)},
        }
        return out

class SweepState:
    """Holds per-sweep metrics used to adapt thresholds for the next sweep."""
    __slots__ = ("sweep_id","size","load","promotions","demotions","moves","lookups","shortcut_hits",
                 "shortcut_misses","mean_hits","median_hits","p90_hits")
    def __init__(self, sweep_id:int, stats:Dict[str,Any], hit_hist:list):
        self.sweep_id = sweep_id
        self.size = stats.get("size",0)
        self.load = stats.get("load",0.0)
        self.promotions = stats.get("promotions",0)
        self.demotions = stats.get("demotions",0)
        self.moves = stats.get("moves",0)
        self.lookups = stats.get("lookups",0)
        sc = stats.get("shortcuts",{})
        self.shortcut_hits = sc.get("hits",0)
        self.shortcut_misses = sc.get("misses",0)
        # summarize hit histogram for tuning
        if hit_hist:
            h = sorted(hit_hist)
            n = len(h)
            self.mean_hits = sum(h)/n
            self.median_hits = h[n//2]
            self.p90_hits = h[int(0.9*n)-1]
        else:
            self.mean_hits = self.median_hits = self.p90_hits = 0

def _collect_hit_hist(table: MDHGHashTable) -> list:
    hist = []
    for _, v in table.items():
        # access meta via location map if available
        # we can't directly access meta from here; approximate using trace counts per key
        # fallback: use promotions as proxy — leave as empty for speed
        pass
    return hist

    def trace_dump(self) -> List[Tuple[str, Dict[str, Any]]]:
        return self._trace.dump()

    # convenience for snapshotting
    def snapshot(self, path: str):
        obj = {"stats": self.stats(), "trace": self.trace_dump()[:10000]}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)

# -----------------------------
# Controller & Audit
# -----------------------------

class AGRMController:
    """Minimal controller with phases and snapshotting hooks.
    Implements a sweep→adapt loop: each sweep updates thresholds/policies
    for the next sweep based on measured metrics.
    """
    def __init__(self, config: Optional[AGRMConfig] = None, snap_dir: Optional[str] = None):
        self.cfg = config or AGRMConfig()
        self.snap_dir = snap_dir or f"snaps_{int(time.time())}"
        self.table = MDHGHashTable(self.cfg)

    def _score_vector(self, s:dict) -> float:
        # Vectored distance scoring: lower is better.
        # Combine normalized load, move rate, promotion/demotion imbalance, and time proxy (lookups/size).
        size = max(1, s.get("size",1))
        load = s.get("load",0.0)
        move_rate = s.get("moves",0)/size
        pro = s.get("promotions",0)/size
        demo = s.get("demotions",0)/size
        imb = abs(pro - demo)
        time_proxy = s.get("lookups",1)/size
        sh = s.get("shortcuts",{}).get("hits",0)
        sl = s.get("shortcuts",{}).get("misses",1)
        shortcut_eff = sh/max(1,sh+sl)
        # weights can be adapted later
        return 0.5*load + 0.3*move_rate + 0.4*imb + 0.3*time_proxy - 0.2*shortcut_eff

    def _tune_from_sweeps(self, prev_stats:dict, prev_cfg:AGRMConfig) -> AGRMConfig:
        # Adjust thresholds based on empirical stats.
        pro = prev_stats.get("promotions",0)
        demo = prev_stats.get("demotions",0)
        size = max(1, prev_stats.get("size",1))
        pro_rate = pro/size; demo_rate = demo/size
        # If too many promotions vs demotions, make promotion harder; else easier.
        new_promote = max(2, int(prev_cfg.promote_hits * (1.1 if pro_rate>0.05 else 0.9)))
        # If load high, nudge φ up; if low, down.
        load = prev_stats.get("load",0.0)
        new_phi = min(2.0, max(1.3, prev_cfg.phi_scale * (1.05 if load>prev_cfg.target_load else 0.97)))
        # Idle demotion window: if demotions minimal, widen window to avoid churn; else tighten.
        new_idle = max(5, int(prev_cfg.demote_after_idle * (1.1 if demo_rate>0.02 else 0.9)))
        return AGRMConfig(
            phi_scale=new_phi,
            target_load=prev_cfg.target_load,
            floors_per_building=prev_cfg.floors_per_building,
            rooms_per_floor=prev_cfg.rooms_per_floor,
            promote_hits=new_promote,
            demote_after_idle=new_idle,
            decay_rate=prev_cfg.decay_rate,
            enable_shortcuts=prev_cfg.enable_shortcuts,
            trace_limit=prev_cfg.trace_limit,
            resize_policy=prev_cfg.resize_policy
        )

    def run_sweeps(self, sweeps:int=3, n:int=10000, seed:int=0):
        random.seed(seed)
        best = None; best_score = float("inf"); history = []
        cfg = self.cfg
        for s in range(sweeps):
            # fresh table per sweep using current config
            self.table = MDHGHashTable(cfg)
            # phase 1: inserts
            for i in range(n):
                self.table.put(f"k{i}", i)
            # phase 2: skewed gets with occasional restarts
            stuck = 0
            for i in range(n*2):
                key = f"k{int((random.random()**0.7)*(n-1))}"
                v = self.table.get(key)
                if v is None:
                    stuck += 1
                if stuck> max(100, n//50):
                    # simple restart: idle sweep + random demotion to shake state
                    self.table.idle_sweep(); stuck = 0
            # finalize
            stats = self.table.stats()
            score = self._score_vector(stats)
            history.append({"sweep": s, "stats": stats, "score": score})
            if score < best_score:
                best, best_score = stats, score
            # adapt thresholds for next sweep
            cfg = self._tune_from_sweeps(stats, cfg)
        # snapshot best-of
        Path(self.snap_dir).mkdir(parents=True, exist_ok=True)
        with open(f"{self.snap_dir}/sweep_history.json", "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)
        return {"best": best, "history": history}

    def run_demo(self, n:int=10000, seed:int=0):
        random.seed(seed)
        # Insert
        for i in range(n):
            self.table.put(f"k{i}", i)
        # Access with skew
        for i in range(n*2):
            key = f"k{int((random.random()**0.7)*(n-1))}"
            _ = self.table.get(key)
        # Idle sweep + snapshot
        self.table.idle_sweep()
        self.table.snapshot(f"{self.snap_dir}/agrm_snapshot.json")
        return self.table.stats()

class AGRMAudit:
    """Audit summary: promotion/demotion rates, shortcut rate, load and move stats."""
    @staticmethod
    def summarize(stats: Dict[str, Any]) -> Dict[str, Any]:
        total = max(1, stats.get("size", 1))
        return {
            "promotion_rate": stats.get("promotions", 0) / total,
            "demotion_rate": stats.get("demotions", 0) / total,
            "move_rate": stats.get("moves", 0) / total,
            "load": stats.get("load", 0.0),
            "shortcut_hit_rate": (stats.get("shortcuts", {}).get("hits", 0) / max(1, stats.get("lookups", 1))),
        }

# -----------------------------
# Self-test
# -----------------------------

if __name__ == "__main__":
    cfg = AGRMConfig()
    ctrl = AGRMController(cfg)
    s = ctrl.run_demo(n=5000, seed=1)
    print("Stats:", s)
    print("Audit:", AGRMAudit.summarize(s))
    assert s["size"] <= 5000  # after sweeps it might be equal or slightly less if you remove in demo
    print("OK")

```