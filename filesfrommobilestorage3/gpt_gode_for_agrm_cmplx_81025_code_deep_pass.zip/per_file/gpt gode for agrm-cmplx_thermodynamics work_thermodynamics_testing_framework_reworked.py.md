# File: gpt gode for agrm-cmplx/thermodynamics work/thermodynamics_testing_framework_reworked.py

**Lines:** 123 | **Words:** 566

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

## Python Analysis
- __main__ present: True
- Module docstring: Reworked Thermodynamics Testing Framework (Minimal, Falsifiable)

Key changes:
- Deterministic seeding
- Configurable output directory
- No hard-coded "pass" flags; real quantitative metrics
- Adds a toy non-equilibrium diffusion test comparing observed dS/dt to an E2L Lambda-term prediction
- Imports: json, numpy
- From-imports: dataclasses, typing
- Classes: RunConfig, Tester
- Functions: periodic_laplacian, periodic_gradient, entropy_from_p_dx, __init__, test_non_eq_diffusion_e2l_lambda, save_summary


---

## Full Source

```text

"""
Reworked Thermodynamics Testing Framework (Minimal, Falsifiable)

Key changes:
- Deterministic seeding
- Configurable output directory
- No hard-coded "pass" flags; real quantitative metrics
- Adds a toy non-equilibrium diffusion test comparing observed dS/dt to an E2L Lambda-term prediction
"""

import json, os, math
from dataclasses import dataclass, asdict
from typing import Dict, Any
import numpy as np

def periodic_laplacian(arr, dx):
    return (np.roll(arr, -1) - 2*arr + np.roll(arr, 1)) / (dx*dx)

def periodic_gradient(arr, dx):
    return (np.roll(arr, -1) - np.roll(arr, 1)) / (2*dx)

def entropy_from_p_dx(p, dx, kB=1.0, eps=1e-12):
    p_safe = np.clip(p, eps, None)
    return -kB * np.sum(p_safe * np.log(p_safe)) * dx

@dataclass
class RunConfig:
    out_dir: str = "./artifacts"
    seed: int = 123
    L: float = 1.0
    N: int = 512
    D: float = 0.01
    alpha: float = 0.0           # coupling for ∂²I term (0 -> classical diffusion)
    lambda0: float = 0.3         # amplitude for Λ(x)
    beta: float = 0.8            # modulation for Λ(x) = lambda0 * (1 + beta*sin(...))
    T: float = 1.0               # total time
    kB: float = 1.0              # nats
    cfl: float = 0.15            # time step factor for explicit Euler

class Tester:
    def __init__(self, cfg: RunConfig):
        self.cfg = cfg
        os.makedirs(cfg.out_dir, exist_ok=True)
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.summary: Dict[str, Any] = {"session_id": self.session_id, "tests": {}}

    def test_non_eq_diffusion_e2l_lambda(self) -> Dict[str, Any]:
        """Toy test: compare observed dS/dt to E2L Lambda-term prediction."""
        cfg = self.cfg
        rng = np.random.default_rng(cfg.seed)
        x = np.linspace(0, cfg.L, cfg.N, endpoint=False)
        dx = x[1] - x[0]
        dt = cfg.cfl * dx*dx / (cfg.D + 1e-12)
        steps = int(cfg.T / dt)

        # Lambda(x)
        Lambda_x = cfg.lambda0 * (1.0 + cfg.beta * np.sin(2*np.pi*x/cfg.L))

        # initial p
        p0 = np.exp(2*np.sin(2*np.pi*x) + 0.5*np.sin(6*np.pi*x) + 0.2*rng.standard_normal(size=cfg.N))
        p0 = np.maximum(p0, 1e-12)
        p0 /= np.sum(p0) * dx
        p = p0.copy()

        S_list, t_list = [], []
        dSdt_pred_lambda = []
        eps = 1e-12

        for n in range(steps):
            p_safe = np.clip(p, eps, None)
            I = -p_safe * np.log(p_safe)
            lap_p = periodic_laplacian(p, dx)
            lap_I = periodic_laplacian(I, dx)
            dpdt = cfg.D * lap_p + cfg.alpha * lap_I
            p = p + dt * dpdt
            p = np.maximum(p, eps)
            p /= np.sum(p) * dx
            S_list.append(entropy_from_p_dx(p, dx, kB=cfg.kB))
            t_list.append((n+1)*dt)
            dLambda_dx = periodic_gradient(Lambda_x, dx)
            dI_dx = periodic_gradient(I, dx)
            integrand = -dLambda_dx * dI_dx
            dSdt_pred_lambda.append(np.sum(integrand) * dx)

        S = np.array(S_list)
        t = np.array(t_list)
        dSdt_obs = np.gradient(S, t)
        dSdt_pred = np.array(dSdt_pred_lambda)

        corr = float(np.corrcoef(dSdt_obs, dSdt_pred)[0,1])
        num = float(np.dot(dSdt_pred, dSdt_obs))
        den = float(np.dot(dSdt_pred, dSdt_pred) + 1e-12)
        gamma = num / den
        rmse = float(np.sqrt(np.mean((dSdt_obs - gamma * dSdt_pred)**2)))

        out = {
            "corr_obs_predLambda": corr,
            "gamma_hat": gamma,
            "rmse": rmse,
            "dt": float(dt),
            "params": asdict(cfg)
        }

        with open(os.path.join(cfg.out_dir, f"non_eq_diffusion_{self.session_id}.json"), "w") as f:
            json.dump(out, f, indent=2)

        self.summary["tests"]["non_eq_diffusion_e2l_lambda"] = out
        return out

    def save_summary(self):
        path = os.path.join(self.cfg.out_dir, f"summary_{self.session_id}.json")
        with open(path, "w") as f:
            json.dump(self.summary, f, indent=2)
        return path

if __name__ == "__main__":
    cfg = RunConfig(out_dir="./artifacts", alpha=0.005)
    tester = Tester(cfg)
    res = tester.test_non_eq_diffusion_e2l_lambda()
    print(json.dumps(res, indent=2))
    print("Summary saved to:", tester.save_summary())

```