
#!/usr/bin/env bash
set -euo pipefail
curl -s -X POST "http://localhost:8000/glyphs" -H "Content-Type: application/json" -H "X-API-Key: ${LATTICE_API_KEY:-}" -d '{"id":"root::0"}' >/dev/null
curl -s -X POST "http://localhost:8000/build_shells/root::0" -H "X-API-Key: ${LATTICE_API_KEY:-}" >/dev/null
curl -s "http://localhost:8000/query_budgeted?center_id=root::0" >/dev/null
curl -s "http://localhost:8000/metrics" >/dev/null
echo "OK"
