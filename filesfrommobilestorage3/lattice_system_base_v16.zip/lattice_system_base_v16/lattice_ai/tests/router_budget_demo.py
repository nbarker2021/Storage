
import numpy as np, time
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shell_qa import ShellQASuite, ShellPromotionRules
from lattice_ai.core.router import Router
from lattice_ai.core.budget_controller import BudgetController

def main():
    cube = SafeCube(dim=8, seed=33)
    ids = [f"d::{i}" for i in range(500)]
    for gid in ids:
        cube.add_glyph(gid); cube.store_glyph(gid)
    P = np.stack([cube.glyph_vector(i) for i in ids], axis=0)
    sb = ShellBuilder(points=P, ids=ids)
    center = ids[0]
    shells = sb.shells_for(center, max_k=3, nn=12)
    sm = ShellManager(); sm.create(center, shells, hash_fn=lambda s: str(abs(hash(s))))
    suite = ShellQASuite(); rules = ShellPromotionRules(min_size=8, min_coherence=0.1)
    sm.validate_and_promote(center, suite, rules, get_vector=lambda gid: cube.glyph_vector(gid), score_fn=lambda _:1.0)

    router = Router(cube, shell_manager=sm)
    bc = BudgetController(p95_budget_ms=10.0, base_k_candidates=64)  # very small budget for demo
    res = bc.query(router, center_id=center, use_promoted=True, top_k=10)
    print("Budget result:", {"latency_ms": round(res["latency_ms"],3), "k_candidates": res["k_candidates"], "candidates": len(res["candidates"]), "top3": res["top"][:3]})

if __name__ == "__main__":
    main()
