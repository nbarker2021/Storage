
"""
Shell policy definitions.

Notation / rationale:
- min_size: |S_k| >= min_size to avoid brittle small shells.
- min_coherence: mean cos(X, c) >= τ_coh to ensure topical focus around center c.
- max_redundancy: mean pairwise cos(X) <= τ_red to prevent collapse into near-duplicates.
- min_domain: external domain score threshold (user/app-provided).
- max_flip_rate: upper bound on proportion of shells whose state flips in one evaluation round.
- probes: list[str] selecting optional probe families (e.g., "recency", "novelty", "contradiction_risk").
"""
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class ShellPolicy:
    name: str = "default"
    min_size: int = 6
    min_coherence: float = 0.10
    max_redundancy: float = 0.99
    min_domain: float = 0.0
    max_flip_rate: float = 0.05
    probes: List[str] = None

    @classmethod
    def from_dict(cls, d: Dict):
        return cls(
            name=d.get("name","default"),
            min_size=d.get("min_size",6),
            min_coherence=d.get("min_coherence",0.10),
            max_redundancy=d.get("max_redundancy",0.99),
            min_domain=d.get("min_domain",0.0),
            max_flip_rate=d.get("max_flip_rate",0.05),
            probes=d.get("probes", None),
        )
