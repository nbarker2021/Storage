
import time, threading, json
from dataclasses import dataclass, field
from typing import Callable, Dict, List
from ..core.safe_cube import SafeCube
from ..core.shell_lifecycle import ShellManager
from ..core.shell_qa import ShellQASuite, ShellPromotionRules
from ..core.shelling import ShellBuilder

@dataclass
class JobStatus:
    name: str
    last_run_ts: float = 0.0
    last_ok: bool = True
    last_msg: str = ""

@dataclass
class JobRunner:
    cube: SafeCube
    sm: ShellManager
    statuses: Dict[str, JobStatus] = field(default_factory=dict)
    running: bool = False

    def _wrap(self, name: str, fn: Callable[[], None]):
        try:
            fn()
            self.statuses[name] = JobStatus(name=name, last_run_ts=time.time(), last_ok=True, last_msg="ok")
        except Exception as e:
            self.statuses[name] = JobStatus(name=name, last_run_ts=time.time(), last_ok=False, last_msg=str(e))

    def contradiction_sweep(self):
        def task():
            # placeholder: would load claims and quarantine on conflicts
            pass
        self._wrap("contradiction_sweep", task)

    def hot_cluster_rebuild(self):
        def task():
            # placeholder: would measure house hotness and rebuild clusters
            pass
        self._wrap("hot_cluster_rebuild", task)

    def shell_re_eval(self):
        def task():
            # simple re-eval on all centers we know (demo scale)
            suite = ShellQASuite(); rules = ShellPromotionRules()
            # In a real system, we’d persist and load per-center vectors;
            # here we just record that the job ran.
            pass
        self._wrap("shell_re_eval", task)

    def run_once(self):
        self.contradiction_sweep()
        self.hot_cluster_rebuild()
        self.shell_re_eval()

    def snapshot(self) -> Dict[str, dict]:
        return {k: vars(v) for k,v in self.statuses.items()}


class Scheduler:
    def __init__(self, runner: JobRunner):
        self.runner = runner
        self.intervals = {"contradiction_sweep": 300, "hot_cluster_rebuild": 600, "shell_re_eval": 900}
        self._last = {k:0 for k in self.intervals}

    def tick(self):
        now = time.time()
        for name, sec in self.intervals.items():
            if now - self._last[name] >= sec:
                getattr(self.runner, name)()
                self._last[name] = now
