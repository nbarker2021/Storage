# CQE Zero-Repeat Cheat Sheet

- **Carrier:** `T^10` = 4×(2‑plane) + groove + axis  
- **State:** `X = R ⊕ Δ`, `R ∈ {R2, R4, R8, R16, R64}`  
- **Mirror:** pose‑as‑gauge (free check)  
- **Residues:** mods `{2,4,8,13}` (+ extras as needed), stitched by CRT  
- **Legality:** Con‑A evenness; code parity OK  
- **Witnesses:** 8 faces; cadence advances only when all latch  
- **Reduction:** minimize `ν = (syndrome, P4, P8)` until REST  
- **Cost (Alena):** `D = Σ w_i (P_i + λ|K_i|)`, `λ ≈ 0.66`  
- **Ledger:** append‑only; residues‑only replay; step hash chain  
- **I/O arms:** g2,g4,g5,g6 for chamber/provenance/safety/time  
- **Space policy:** declare inside/outside/extension; back faces closed; shell up to 4096 with compress‑and‑restart  
- **Falsify:** break octad, break replay, break evenness, allow dual‑red commit.
