# Paper G — Applications & Evidence

## Abstract
Worked examples that live entirely inside the CQE runtime (toy but faithful): composite video from 8 streams; 3‑body “mission control”; codon duplex & peptide bond; water‑ice anomaly; time‑crystal‑like gating; vector‑search hygiene.

### G.1 Composite video (Δ‑space mixing)
Mix differences in 10‑D under a shared rest; enforce latches; decode to pixels; deterministic replay.

### G.2 3‑body planner (rails)
Treat rails as CRT corridors; latches prevent oscillation; replay shows stable sling windows.

### G.3 Codon duplex (biology)
Two adjacent codons → two RNA mini‑helices (P/A sites) + peptide bond; model as parity + gate; ledger proves order.

### G.4 Ice anomaly (materials)
Gate‑driven packing explains density inversion under specific pressure/temperature shells; relax ⇒ return to usual rest.

### G.5 Time‑crystal analog (strobing)
Stroboscopic (mod‑13) cadence stabilizes otherwise forbidden order; witnesses make the phase visible without drift.
