# Paper D — Scratch‑Pad HQ: The Operating Model

## Abstract
Blueprint of the building: Control Tower, eight stations, floors (L1–L8), latches, runbook, and journals.

## D.1 Floors & Stations
- L1 Exchange (parity market), L2 CRT switchboard, L3 Construction‑A lift, L4 Helix cartography, L5 Alena (sliders), L6 Ledger, L7 Spectral/Haptic lab, L8 Validation court.  
- Stations: Lens/Codec, CRT, Con‑A, Helix, Tuple Bundler, Alena, Spectral/Haptic, Ledger.

## D.2 Runbook
Seed freeze → parity→CRT→Con‑A→Helix→Alena → Verify → Ledger → Replay audit. Reds are “needs lift,” not errors.

## D.3 Journals & Ledgers
- `ledger.ndjson` (hash‑chained), `witness.csv` (DFT/WHT/haptic), HP/SP journals (hyperperm/superperm notes).  
- Repro kit: fixed seeds, routes/policies, expected hashes.
