# Appendix IV — Dyadic Rests & 8‑Cell Atlas

16 naive sign patterns reduce to 8 legal vertices under mirror+k‑parity+frame closure. One vertex is the palindromic rest; seven are clean orthogonal deltas. Plot in 3‑D via a fixed slice or PCA of the 10‑D embedding.
