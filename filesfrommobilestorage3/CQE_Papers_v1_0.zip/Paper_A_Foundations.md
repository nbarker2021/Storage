# Paper A — Foundations: Canon, Carrier & Rests

**Series:** CQE: A Legality-First, Geometry-Native Operating Model for Deterministic Reasoning  
**Version:** v1.0  
**Date:** 2025-09-17T15:37:36.022748Z

## Abstract
We present a framework (CQE) in which legality—not similarity—governs both retrieval and generation. Inputs are integerized and evaluated on a 10‑D toroidal carrier with dyadic rests (2/4/8/16/64) and mirror parity. Work proceeds through parallel residue channels (CRT) and Type‑II Construction‑A legality checks. Progress is gated by 8 facet witnesses; commits are deterministic and replayable from residues alone. A confluent reduction selects a unique normal form (REST). We formalize the scratch‑pad HQ, provide an API, falsifiers, and application studies (biological duplex, 3‑body planning, composite video, time‑crystal‑like gating, vector‑search hygiene). The aim is an explainable, auditable runtime that keeps the math tight and the ops simple.

## A.1 Canonical Definitions
**Def.A.1 (Integerized state).** Any sample `x` is mapped to integers; floats are surrogates only.  
**Def.A.2 (Frame from glyphs).** Numeric glyphs compile the runtime frame `F = ⟨τ, S, M, 𝔽⟩`: thresholds `τ`; dyadic scale `S` (promote in powers of 4); moduli `M` (e.g., {2,4,8,13}); face priorities `𝔽`.  
**Def.A.3 (Carrier).** `T^10 = (S^1)^4_(2‑planes) × S^1_(groove) × S^1_(axis)`.  
**Def.A.4 (Dyadic rests).** `R2,R4,R8,R16,R64` are mirror‑gauged palindromic anchors; **motion** is mirror‑odd `Δ`. State decomposes `X = R ⊕ Δ`.  
**Def.A.5 (Mirror & Pose‑as‑gauge).** Mirror swaps strands; pose changes don’t affect residues or ledger truth.  
**Def.A.6 (Residues & CRT).** Work in parallel congruence classes mod `M`, stitch by CRT to one gate code.  
**Def.A.7 (Type‑II legality).** Construction‑A evenness + code parity ⇒ admissible lift.  
**Def.A.8 (Witness suite).** 8 facet functionals (“faces”). **OPEN** only when all faces latch within cadence.  
**Def.A.9 (Ledger).** Append‑only rows with delta‑xor, residues, K‑corrections, witness bits, step hash; replayable from residues.

## A.2 Space‑defining Rules (Define All Space)
- Declare **inside** (current shell), **outside** (facet‑adjacent chambers), **extension** (next dyadic), **expansion budget**, and **back‑face policy** (closed).  
- **Shell policy:** allow shells 2,4,8,16,24,32 then +8 up to 4096; upon saturation, **compress** to a higher‑order token set and restart; keep prior proofs as closed ledgers; **pose** validates heritage.  
- External data only via I/O arms; back faces closed; front‑face pose shift is a free safety/consistency check.

## A.3 Why Dyadic
Rests at 2/4/8 capture minimal parity structure; 16/64 add doubly‑even/CRT refinement without moving the center.
