# Appendix I — Hand Proof Kit (n=1→5, no jargon)

## Materials
- Two sheets of graph paper (4×4 grids), two colors of pens/highlighters.

## Steps
1. Draw two mirrored lanes (top/bottom).  
2. Place symbols {1,2,3,4}. Use local overlap and “least‑defect” to build a palindromic weave for n=4.  
3. Re‑run the same rule: confirm nothing changes (idempotence).  
4. Take a fresh grid. Try each of the 16 placements for “5”. For each, attempt minimal local repairs.  
5. Record whether you can end in one step of repairs; group outcomes by rotation/flip with color parity.  
6. You’ll have 8 inequivalent classes. Exactly one re‑palindromizes; 7 stabilize as non‑palindromic.
