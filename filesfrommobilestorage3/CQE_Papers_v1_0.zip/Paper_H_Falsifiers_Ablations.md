# Paper H — Falsifiers, Limits, Ablations

## Abstract
Everything that would break the story, and how to test it.

- Show non‑confluence (same seed+frame → different hash).  
- Show legal commit with non‑even lift.  
- Dual‑red commits (DFT & WHT both red) allowed.  
- Cross‑frame leakage.  
- Ablations: remove rate‑arm 13, disable latches, remove parity; measure failures.
