# Appendix V — Schematics (ASCII)

```
T^10 carrier (schematic)
  [2‑plane 1]—[2‑plane 2]—[2‑plane 3]—[2‑plane 4]  + groove + axis

Face‑only scan (latches)
  faces: f1 f2 f3 f4 f5 f6 f7 f8
  step advances only if all latched = 1

Ledger chain
  step_hash -> step_hash -> step_hash   (append‑only; residues replay)
```
