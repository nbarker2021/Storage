# Speaker Deck — CQE in 12 Slides (Markdown outline)

1. Problem: similarity-led systems are non‑deterministic & fragile  
2. Premise: legality‑first + integer lattices + CRT  
3. Carrier: 10‑D torus; dyadic rests  
4. Mirror & pose‑as‑gauge  
5. Gate wall (g₁..g₆) and 8‑face witnesses  
6. Alena & confluent reduction  
7. Ledger & residues‑only replay  
8. Scratch‑Pad HQ (floors, stations)  
9. API & ops (idempotent endpoints)  
10. Applications (duplex, 3‑body, composite video, ice anomaly, time‑crystal)  
11. Falsifiers & ablations  
12. Roadmap & benchmarks
