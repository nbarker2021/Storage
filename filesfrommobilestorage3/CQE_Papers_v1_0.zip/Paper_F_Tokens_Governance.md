# Paper F — Tokens, Glyphs, Stand‑ins & Governance

## Abstract
How to use stand‑in tokens (domain‑agnostic glyphs) safely; numeric glyphs compile frames; journals track meaning; contracts and provenance.

## F.1 Stand‑ins
Treat “$” or “DNA” as a sealed container until a gate requires expansion. Expand only when a legal decision needs exact semantics; otherwise operate on legal structure (residues, witnesses).

## F.2 Governance
No PII; IRL data only through g₄..g₆ (provenance/safety/time). Pose‑as‑gauge: free consistency check; back faces closed by default.
