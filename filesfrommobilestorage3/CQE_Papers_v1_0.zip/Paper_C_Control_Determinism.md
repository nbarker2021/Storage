# Paper C — Control & Determinism (Corridors, Latches, Replay)

## Abstract
Formalizes the gate wall (g₁..g₆) and face‑only scan; proves the confluent reduction ⇒ unique normal form; provides the replay kit.

## C.1 Gate Wall (I/O twin)
g₁ XOR parity (mod 2), g₂ chamber (mod 3), g₃ cost (mod 5), g₄ provenance (mod 7), g₅ safety (mod 11), g₆ timing (mod 13).  
**OPEN** iff CRT(g₁..g₆) ∈ Allow_I/O and dual witnesses are green.

## C.2 Alena & Reduction
**Cost:** `D = Σ w_i (P_i + λ |K_i|)`, with `λ ∈ [0.64,0.67]`.  
**Violation vector:** `ν = (syndrome, P4, P8)`.  
**Alg.C.1 (NORMAL_FORM):** while VERIFY=ACTION, pick the minimal legal move that strictly lowers `ν`; end in REST; idempotent.

## C.3 Replay Determinism
Same seed+frame ⇒ same cadence order and snap hash. Pose is gauge; residues suffice to replay.
