# Paper B — Algebraic Spine & the n=4→5 Hinge

## Abstract
States the hand‑checkable hinge: n=4 collapses to one palindromic rest on a 4×4 parity grid; inserting “5” forces **eight** inequivalent insertion classes (the octad). Provides falsifiers and a paper‑and‑pencil worksheet.

## B.1 Claims & Lemmas (hand‑verifiable)
- **Lemma B.1 (n=4 uniqueness).** Canonicalization under Alena yields one palindromic rest (up to pose).  
- **Lemma B.2 (n=5 octad).** Exactly 8 inequivalent legal insertions (4 fixed‑axis, 4 off‑axis under parity).  
- **Lemma B.3 (1 palindromic + 7 invariant).** One re‑palindromizes; seven stabilize non‑palindromically.  
- **Theorem B.4 (Octad ⇒ global spine).** The octad forces 8‑face gating; standard Con‑A lifts align naturally (E8 projection; Leech legality as I/O slice at 24; two‑slice hub at 32).

## B.2 Falsifiers
F1 \< 8 or \> 8 n=5 classes.  
F2 n=4 cannot palindromize.  
F3 palindromic class fails idempotence.  
F4 rotation leaves octad orbit.

## B.3 Worksheet (kitchen‑table)
1) Draw a 4×4 grid with two mirrored parity lanes.  
2) Build the **n=4 palindrome** with local overlap & “least‑defect” rule; rerun canonicalization (idempotence check).  
3) Try all 16 placements of “5”; repair locally; quotient by dihedral×parity ⇒ **eight classes**.  
4) Mark which class re‑palindromizes; the other 7 stabilize non‑palindromically.
