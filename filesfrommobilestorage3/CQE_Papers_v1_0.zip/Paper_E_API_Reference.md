# Paper E — API & Reference Implementation

## Abstract
Public endpoints and schemas; idempotent, key‑scoped; example payloads.

## E.1 Endpoints
POST `/frame.compile` → F from glyphs  
POST `/verify` → verdict + (synd, P4, P8, typeII)  
POST `/reduce` → one legal ACTION step + reason  
POST `/commit` → collapse to normal form (hash)  
POST `/anchor.match` → invariant‑keyed lookup  
POST `/extend` → propose minimal frame extension (+ cost)

## E.2 Schemas
RunFrame, StepFrame, FeatureFrame, CheckFrame, ArtifactFrame.

## E.3 Pseudocode
Face‑only scan with witness latches; bounds pulse only after all eight fire; advance cadence.
