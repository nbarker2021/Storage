# Appendix II — Witness Math

`P4 = |h4[1] - h4[3]|`  
`P8 = |h8[1] - h8[7]| + |h8[2] - h8[6]| + |h8[3] - h8[5]|`  
Syndrome and K‑corrections follow the chosen code parity and even‑lift rules (Construction‑A discipline).
