# Appendix III — Alena Tuning & Dead‑band

`λ` sweet band ≈ 0.66; entry/exit hysteresis ±0.01. Priorities: palindromic fix → minimal defects → minimal motion. One targeted spectral flip per window if DFT red & WHT green (whitelist).
