# File: final72625/final72625/grid_utils.py

**Extension:** .py

**Lines:** 72 | **Words:** 322

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: itertools

- From-imports: (none)

- Classes (1): Grid

- Functions (6): __init__, get_section_id, get_section_id_from_coordinates, get_section_coordinates, get_neighbors, get_all_section_ids


---


## Full Source


```text

import itertools

class Grid:
    def __init__(self, dimensions):
        self.dimensions = dimensions
        self.num_dimensions = len(dimensions)
        self.section_sizes = dimensions  # Assuming each dimension has the same size for now.  Could be generalized later.
        self.total_sections = 1
        for dim_size in dimensions:
            self.total_sections *= dim_size

    def get_section_id(self, permutation):
        coordinates = []
        for i in range(self.num_dimensions):
            coordinates.append(permutation[i] - 1) #Adjusted to 0-indexing
        return self.get_section_id_from_coordinates(tuple(coordinates))

    def get_section_id_from_coordinates(self, coordinates):
        section_id = 0
        multiplier = 1
        for i in range(self.num_dimensions):
            section_id += coordinates[i] * multiplier
            multiplier *= self.section_sizes[i]
        return section_id

    def get_section_coordinates(self, section_id):
        coordinates = []
        for i in range(self.num_dimensions):
            coordinates.append(section_id % self.section_sizes[i])
            section_id //= self.section_sizes[i]
        return tuple(coordinates)

    def get_neighbors(self, section_id):
        coordinates = self.get_section_coordinates(section_id)
        neighbors = []
        for delta in itertools.product([-1, 0, 1], repeat=self.num_dimensions):
            if all(d == 0 for d in delta):  # Skip the current section itself
                continue
            neighbor_coords = tuple(coordinates[i] + delta[i] for i in range(self.num_dimensions))

            # Check if neighbor coords are within the grid
            if all(0 <= c < self.section_sizes[i] for i, c in enumerate(neighbor_coords)):
                neighbors.append(self.get_section_id_from_coordinates(neighbor_coords))
        return neighbors

    def get_all_section_ids(self):
        return range(self.total_sections)


# Example usage (for testing):
if __name__ == "__main__":
    grid = Grid((9, 9))  # 2D 9x9 grid
    print("Total Sections:", grid.total_sections)
    perm = (1, 2, 3, 4, 5, 6, 7, 8, 9)
    section_id = grid.get_section_id(perm)
    print(f"Section ID for {perm}:", section_id)
    coords = grid.get_section_coordinates(section_id)
    print(f"Coordinates for {section_id}:", coords)
    neighbors = grid.get_neighbors(section_id)
    print(f"Neighbors of {section_id}:", neighbors)
    print("All Section IDs:", list(grid.get_all_section_ids()))

    grid_3d = Grid((3, 3, 3))
    print("Total Sections (3D):", grid_3d.total_sections)
    perm_3d = (1,2,3,4,5,6,7,8,9)
    section_id_3d = grid_3d.get_section_id(perm_3d)
    print(f"Section ID for {perm_3d}:", section_id_3d)
    coords_3d = grid_3d.get_section_coordinates(section_id_3d)
    print(f"Coordinates for {section_id_3d}:", coords_3d)
    neighbors_3d = grid_3d.get_neighbors(section_id_3d)
    print(f"Neighbors of {section_id_3d}:", neighbors_3d)
    print("All Section IDs (3D):", list(grid_3d.get_all_section_ids()))

```