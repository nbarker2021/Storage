# final72625 — Code Deep Pass (Full-Content)

_This master file summarizes each source with metrics and Python symbols. Full source texts are in per_file/._


---
## final72625/final72625/analysis_scripts_final.py
- Ext: **.py** | Lines: **657** | Words: **3014**
### Keyword hits
- SFBB: 0
- superperm: 67
- superpermutation: 59
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 8
- debruijn: 2
- beam: 0
- orchestrator: 0
- hash: 43
- golden: 4
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 22
- Imports: heapq, itertools, math, networkx, random
- From-imports: collections

---
## final72625/final72625/generation_code_n7_dynamic_final.py
- Ext: **.py** | Lines: **690** | Words: **3223**
### Keyword hits
- SFBB: 0
- superperm: 76
- superpermutation: 76
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 1
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 85
- golden: 14
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 2
- Functions: 21
- Imports: analysis_scripts, heapq, itertools, math, networkx, random, time
- From-imports: collections, layout_memory

---
## final72625/final72625/grid_utils.py
- Ext: **.py** | Lines: **72** | Words: **322**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 1
- Functions: 6
- Imports: itertools
- From-imports: (none)

---
## final72625/final72625/layout_memor_finaly.py
- Ext: **.py** | Lines: **116** | Words: **697**
### Keyword hits
- SFBB: 0
- superperm: 5
- superpermutation: 5
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: math, pickle
- From-imports: (none)