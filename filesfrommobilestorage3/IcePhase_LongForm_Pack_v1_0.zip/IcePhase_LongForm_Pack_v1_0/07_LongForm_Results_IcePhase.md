# Case Study - Ice Phase (Long Form)
Status: OPEN - structure and evidence satisfied.
Frame: tau=1/4, S=64, M={2,4,8,13,24,32}, faces={dense_solid, octad, E8_witnesses}.
Pins: pressure_gpa>=2.0 satisfied, temperature_c>=10 satisfied.
Witnesses: parity=GREEN, timing=GREEN.
Palindromy: P4=0, P8=0; Syndrome: 0; Type-II: True.
Decision: OPEN; export nf_hash, merkle root, residues-only replay.
