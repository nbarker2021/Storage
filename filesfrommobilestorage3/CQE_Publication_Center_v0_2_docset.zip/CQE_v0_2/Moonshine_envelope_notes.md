# Moonshine Envelope Notes

Pick a McKay–Thompson series T_g(q) (Monster conjugacy class g) and fix normalization.
In demos, set R(θ)≡1, G(θ)≡0. For production, document:
- g class (e.g., 13A),
- q-expansion truncation order,
- normalization,
- sensitivity analysis (how small changes affect latches).