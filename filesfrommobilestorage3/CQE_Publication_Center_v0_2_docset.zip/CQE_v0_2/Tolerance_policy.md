# Face-Latch Tolerance Policy (ε)

Gate inequality: ⟨α_i, π₈(x)⟩ ≥ b_i − ε

- Default ε = 1e−9 in normalized coordinates (unit facet normals).
- Rationale: prevents measure-zero failures at exact boundary due to floating error.
- Policy knobs:
  - `epsilon_min`: 1e−12
  - `epsilon_default`: 1e−9
  - `epsilon_max`: 1e−6
- Ledger: record ε used per latch event.