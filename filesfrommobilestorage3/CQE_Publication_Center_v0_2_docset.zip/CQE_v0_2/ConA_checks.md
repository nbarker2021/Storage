# Con‑A Legality & Syndrome Checks

**Goal**: Verify legality in Type‑II Construction‑A by checking membership in the extended binary Golay code and evenness.

## Definitions
- Extended binary Golay code G ⊂ F₂²⁴ with parameters [24,12,8].
- Parity‑check matrix H_G (12×24) over F₂; syndrome s = H_G · vᵗ (mod 2).
- Construction‑A lift: Λ = (1/√2) · { x ∈ ℤ²⁴ : x mod 2 ∈ G }.

## Checks (operational)
1. Reduce candidate x ∈ ℤ²⁴ mod 2 → v ∈ F₂²⁴.
2. Compute s = H_G · vᵗ (mod 2).  
   - If s ≠ 0 → **illegal** (reject or reduce).  
   - If s = 0 → candidate is Con‑A legal in the Golay channel.
3. Evenness: ensure ‖x‖² ≡ 0 (mod 2). (Type‑II condition.)
4. For multi‑channel CRT lifts, perform steps 1–3 per channel and glue results.

> Note: Ship an explicit H_G (canonical form) for production. In this docset we describe the algorithm and expect H_G to be provided by the code harness (to avoid transcription errors).