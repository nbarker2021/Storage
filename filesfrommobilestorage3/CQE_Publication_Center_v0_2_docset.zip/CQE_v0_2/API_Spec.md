# Publication Center API (CQE / v0.2)

- `POST /frame` → compile numbers → frame F.
- `POST /verify` → { verdict ∈ {REST,ACTION,REJECT}, syndrome, P4, P8, typeII }.
- `POST /reduce` → one legal ACTION step (reason attached).
- `POST /commit` → collapse reversible log to normal form; return hash.
- `POST /store` / `POST /retrieve` → invariant-keyed I/O.
- `POST /extend` → propose minimal frame extension with explicit cost.

Artifacts returned:
- Residues (mods {2,4,8,32,13}),
- Witness flags (DFT/WHT/haptic if active),
- Gate LED states (g₁..g₆),
- λ and dead-band region,
- Step and run hashes.

Security: tenant isolation, pin schema enforcement, unit/range validation, provenance required.