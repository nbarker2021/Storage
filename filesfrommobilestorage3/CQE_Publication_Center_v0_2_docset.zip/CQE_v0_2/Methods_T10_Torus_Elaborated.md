# Methods — T¹⁰ Double-Helix (Elaborated)

This expands the Single Sheet into an operational, parameterized method.

## 1. Carrier & Codes
- **Carrier**: Leech lattice Λ₂₄ via Type‑II Construction A from the **extended binary Golay (24,12,8)** code.
- **Evenness**: Type‑II (even, unimodular), no roots.
- **Con‑A legality**: Membership check uses a parity‑check matrix H_Golay (see `ConA_checks.md`).

## 2. 10‑D Stage (T¹⁰)
- Choose a **Golay octad**; pair coordinates into four orthogonal 2‑planes (8D), plus **groove** (1D) and **axis** (1D).
- Coordinate order: (P1x,P1y,P2x,P2y,P3x,P3y,P4x,P4y,Groove,Axis).

## 3. Monster 13‑Screw & Moonshine Envelope
- **Monster class**: 13A or 13B. Select a frame shape; assign plane phases φ_k = 2π * s_k / 13 (k=1..4), with s_k ∈ {0..12}.
- **Envelopes**: R(θ), G(θ) chosen from a normalized McKay–Thompson series T_g(q) (see `Moonshine_envelope_notes.md`). In demos we set R≡1, G≡0 for a pure geometry check.

## 4. Mirror Parity & Palindromic Rest
- Mirror involution M: swap strands (L↔R), flip axis sign, and add Δ phase to keep palindromy.
- **Rest**: the mirror‑even component at gauge; **Differences**: mirror‑odd sector.

## 5. Parametric Equations
Let θ be the running angle; Δ = 2π/13.

Left strand:
x_L(θ) = ( R·cos(θ+φ₁), R·sin(θ+φ₁), … ; G(θ),  θ )

Right strand (mirror):
x_R(θ) = ( R·cos(−θ+φ₁+Δ), R·sin(−θ+φ₁+Δ), … ; G(θ), −θ )

**Screw identity**: advancing θ by 13Δ maps L→R up to gauge.

## 6. 8‑Face Gating
- Define 8 Cartan linear forms (see `Cartan_facets.csv`). Gate is **OPEN** iff:
  - Con‑A legal (Type‑II, syndrome 0),
  - Mirror‑legal,
  - For all facets i: ⟨α_i, π_8(x)⟩ ≥ b_i − ε,
  - with ε per `Tolerance_policy.md`.
- Cadence: advance only after all 8 facets have latched once.

## 7. Outside Neighbors via E₈ Projection
- Project π_8(x) to an E₈ frame; adjacent chambers correspond to simple root walls crossed.

## 8. Overlays (Delta‑Labeled, Return‑Guaranteed)
- P (Type‑I façade), M (CRT layers), S (13A/13B symmetry), H (Moonshine choices), G (gating windows), N (Niemeier classifiers). All overlays must **Return** to Type‑II before dynamics.

## 9. Tuple‑Driven Con‑A (Selector by Arity a)
- Factor a = ∏ p_i^{k_i}; add Con‑A layers per factor; glue via CRT; if an odd lift appears, apply the **shadow lift** back to even.

## 10. Verification Artifacts
- `Screw13_demo.csv` + `Screw13_report.md`: numeric evidence that 13 steps implement the screw.
- `T10_Torus_Build_Verification_Checklist.csv`: pass/fail gate.
- `ConA_checks.md`: parity‑check method for Golay; syndrome = 0 = legal.
- `Cartan_facets.csv`: explicit α_i and thresholds.
- `T10_params.csv`: typed pins with units/ranges/provenance.