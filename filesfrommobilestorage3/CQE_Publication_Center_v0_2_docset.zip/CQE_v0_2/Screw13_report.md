# Screw‑13 Numeric Demo (Toy)

- Input: `Screw13_demo.csv` (L‑strand coordinates, θ=k·2π/13).
- Transformation: mirror + axis flip, with 13‑step screw equivalence (toy relabeling).
- Hash(L) = `3a5fd3663e8a32bf619580b122f45d98e4b0d7e268eac26448fb8b4042c28851`
- Hash(R) = `1764eb6d5973ef922c458d10f80dbc021fe02f585950e563e6392e9e098b783d`

**Note**: For the full proof, regenerate R directly from the parametric equations with θ→−θ and +Δ per plane, then show a gauge‑invariant equality. This toy preserves CSV hash under a controlled mapping to demonstrate the artifact format.