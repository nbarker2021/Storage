#!/usr/bin/env python3
import json, pathlib
from cqe.registry import load_registry, four_bit_commit

def main():
    root = pathlib.Path(__file__).resolve().parents[1]
    carts, benches, rh = load_registry(str(root))
    id2cart = {c.id: c for c in carts}
    print(f"== Run Benches (registry {rh[:12]}...) ==")
    for b in benches:
        drivers = b.obj["drivers"]
        tokens = []
        for cid in drivers:
            tokens.extend(id2cart[cid].obj["tokens"][:4])  # slice for demo
        commit = four_bit_commit(tokens)
        print(f"{b.id}  drivers={drivers}  commit=0b{commit:04b}")
    print("Done.")

if __name__ == "__main__":
    main()
