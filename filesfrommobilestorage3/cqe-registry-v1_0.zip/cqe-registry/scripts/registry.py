#!/usr/bin/env python3
import pathlib
from cqe.registry import load_registry

def main():
    root = pathlib.Path(__file__).resolve().parents[1]
    carts, benches, rh = load_registry(str(root))
    print("== CQE Registry Manifest ==")
    print(f"Root: {root}")
    print(f"Cartridges: {len(carts)}")
    for c in carts:
        print(f"  - {c.id}  hash={c.hash[:12]}...")
    print(f"Benches: {len(benches)}")
    for b in benches:
        print(f"  - {b.id}  hash={b.hash[:12]}...")
    print(f"\nRegistry Merkle Root: {rh}")

if __name__ == "__main__":
    main()
