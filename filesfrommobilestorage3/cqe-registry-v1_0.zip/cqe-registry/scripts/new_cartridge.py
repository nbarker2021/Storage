#!/usr/bin/env python3
import json, sys, pathlib, secrets

TEMPLATE = {
  "id": "CXX",
  "title": "New Cartridge",
  "version": "1.0.0",
  "intent": "prototype",
  "schema": "cqe.cartridge.schema.v1",
  "tokens": [],
  "receipts": {"rho":0.0,"whiteness":1.0,"leakage":0.0,"ece":0.01},
  "microtests": [{"seed":0,"expect":"ok"}]
}

def main():
    if len(sys.argv)<2:
        print("usage: new_cartridge.py C19"); sys.exit(1)
    cid = sys.argv[1]
    c = dict(TEMPLATE)
    c["id"]=cid
    c["title"]=f"Cartridge {cid}"
    for i in range(8):
        name = f"tok{i}"
        bucket = "ALPHA" if i%2==0 else "NOVA"
        hex16 = f"{(i*7+3)%65536:04x}"
        grad = round((i+1)/9,3)
        h = secrets.token_hex(16)
        c["tokens"].append({"name":name,"bucket":bucket,"hex16":hex16,"grad":grad,"hash":h})
    out = pathlib.Path(__file__).resolve().parents[1] / "cartridges" / f"{cid}.json"
    out.write_text(json.dumps(c, indent=2))
    print(f"Wrote {out}")

if __name__ == "__main__":
    main()
