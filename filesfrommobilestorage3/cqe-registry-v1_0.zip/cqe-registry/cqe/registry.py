import json, pathlib
from .utils import stable_dumps, sha256_of_json
from .hashing import merkle_root_hex
from .validator import validate_cartridge, validate_bench

class Cartridge:
    def __init__(self, obj):
        validate_cartridge(obj)
        self.obj = obj
        self.id = obj["id"]
        self.hash = sha256_of_json(obj)

class Bench:
    def __init__(self, obj):
        validate_bench(obj)
        self.obj = obj
        self.id = obj["id"]
        self.hash = sha256_of_json(obj)

def load_registry(root: str):
    rootp = pathlib.Path(root)
    cart_dir = rootp / "cartridges"
    bench_dir = rootp / "benches"
    cartridges = []
    benches = []
    for f in sorted(cart_dir.glob("C*.json")):
        cartridges.append(Cartridge(json.loads(f.read_text())))
    for f in sorted(bench_dir.glob("B*.json")):
        benches.append(Bench(json.loads(f.read_text())))
    leaves = [c.hash for c in cartridges] + [b.hash for b in benches]
    root_hash = merkle_root_hex(leaves)
    return cartridges, benches, root_hash

def four_bit_commit(tokens):
    # Deterministic illustrative 4-bit commit
    if not tokens:
        return 0
    # bit0: majority bucket initial A-M vs N-Z
    left = sum(t["bucket"][0].upper() <= "M" for t in tokens)
    bit0 = 0 if left >= len(tokens)/2 else 1
    # bit1: hex16 median parity
    vals = sorted(int(t["hex16"],16) for t in tokens)
    med = vals[len(vals)//2]
    bit1 = med & 1
    # bit2: gradient median above 0.5
    gvals = sorted(float(t["grad"]) for t in tokens)
    gmed = gvals[len(gvals)//2]
    bit2 = 1 if gmed > 0.5 else 0
    # bit3: any palindrome name
    def pal(s): 
        s = s.lower()
        return s == s[::-1]
    bit3 = 1 if any(pal(t["name"]) for t in tokens) else 0
    return (bit3<<3) | (bit2<<2) | (bit1<<1) | bit0

def merkle_root(root: str) -> str:
    _, _, h = load_registry(root)
    return h
