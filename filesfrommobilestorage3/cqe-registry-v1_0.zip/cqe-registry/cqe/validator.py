# Lightweight schema validator (no external deps).

def _type(o):
    if isinstance(o, bool): return "boolean"
    if isinstance(o, int): return "integer"
    if isinstance(o, float): return "number"
    if isinstance(o, str): return "string"
    if isinstance(o, list): return "array"
    if isinstance(o, dict): return "object"
    return "unknown"

def validate_cartridge(obj):
    required = ["id","title","version","intent","schema","tokens","receipts","microtests"]
    for k in required:
        if k not in obj: raise ValueError(f"cartridge missing key: {k}")
    if _type(obj["tokens"]) != "array": raise ValueError("tokens must be array")
    if _type(obj["receipts"]) != "object": raise ValueError("receipts must be object")
    if _type(obj["microtests"]) != "array": raise ValueError("microtests must be array")
    for t in obj["tokens"]:
        for k in ["name","bucket","hex16","grad","hash"]:
            if k not in t: raise ValueError(f"token missing {k}")
    for k in ["rho","whiteness","leakage","ece"]:
        if k not in obj["receipts"]: raise ValueError(f"receipts missing {k}")
    return True

def validate_bench(obj):
    required = ["id","title","drivers","paths","expectations"]
    for k in required:
        if k not in obj: raise ValueError(f"bench missing key: {k}")
    return True
