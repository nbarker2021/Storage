from .utils import sha256_hex

def merkle_root_hex(leaves):
    """Compute a simple Merkle root over an iterable of hex digests (strings).
    Deterministic: sorts leaves lexicographically first.
    """
    if not leaves:
        return sha256_hex(b"")
    level = sorted(leaves)
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            left = level[i].encode("ascii")
            right = level[i+1].encode("ascii") if i+1 < len(level) else left
            nxt.append(sha256_hex(left + right))
        level = nxt
    return level[0]
