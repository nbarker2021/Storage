import json, hashlib

def stable_dumps(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",",":"))

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha256_of_json(obj) -> str:
    return sha256_hex(stable_dumps(obj).encode("utf-8"))
