from .registry import load_registry, merkle_root, four_bit_commit
