import pathlib
from cqe.registry import load_registry, four_bit_commit

def test_manifest_and_hash():
    root = pathlib.Path(__file__).resolve().parents[1]
    carts, benches, rh = load_registry(str(root))
    assert len(carts) >= 12
    assert len(benches) == 4
    assert isinstance(rh, str) and len(rh)==64

def test_four_bit_commit_stability():
    tokens = [
        {"name":"aba","bucket":"ALPHA","hex16":"0002","grad":0.6,"hash":"h"},
        {"name":"tok","bucket":"NOVA","hex16":"0003","grad":0.4,"hash":"h"},
    ]
    c1 = four_bit_commit(tokens)
    c2 = four_bit_commit(list(reversed(tokens)))
    assert c1 == c2
