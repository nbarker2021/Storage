# CQE Registry & Harness (v1)

A clean, reproducible **Cartan–Quadratic-Equivalence (CQE)** repository that ships:

- **cartridges/**: domain-agnostic *stand‑in* reasoning modules (C01–C18)
- **benches/**: four composite suites (BA–BD) for invariance, collision, and replay
- **cqe/**: zero-dependency Python library to load, validate, hash, and commit
- **schemas/**: human-readable JSON schemas (documentation-first)
- **tests/**: unittest-style tests (no third-party deps required)
- **scripts/**: small CLI tools (registry hash, run benches, new cartridge template)
- **docs/**: short conceptual notes

This repo is **semantics-free**: cartridges contain synthetic tokens/receipts; useful for CQE method development without domain data.

## Quickstart

```bash
# (optional) create venv
python -m venv .venv && . .venv/bin/activate

# run manifest + registry hash
python scripts/registry.py

# run benches (BA–BD) and compute 4-bit commits
python scripts/run_benches.py

# run tests
python -m unittest
```

## Concepts (one-paragraph)

- **Cartridge**: JSON with `tokens` (stand‑ins), `receipts` (quality metrics), and minimal `microtests`.  
- **Overlay**: sparse combination of paths across 4 drivers; we only store summaries.  
- **Palindromic rest & 4-bit commit**: canonicalization yields a 4-bit view vector; its Merkle root anchors a ledger entry.  
- **Determinism**: given same inputs + schema version, hashes and commits are identical.

See **docs/concepts.md** for details.
