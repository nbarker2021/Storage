# CQE Concepts (Short)

- **Stand-in tokens**: placeholders carrying bucket + color + gradient + salted hash; meaning binds only after commit.
- **Receipts**: minimal metrics for pruning/acceptance (rho, whiteness, leakage, ECE).
- **Overlays**: sparse summaries of simulated paths; intersections suggest palindromic rest candidates.
- **4-bit commit**: minimal deterministic view-vector; stored with a Merkle root proof.
- **Registry**: versioned set of cartridges + benches with a stable hash for replay and audit.
