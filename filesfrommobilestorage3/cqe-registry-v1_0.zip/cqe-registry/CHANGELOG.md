# Changelog

## 1.0.0 (initial)
- Cartridges C01–C18
- Benches BA–BD
- Deterministic registry hash + 4-bit commit
- Zero-dep validator; CLI tools; tests
