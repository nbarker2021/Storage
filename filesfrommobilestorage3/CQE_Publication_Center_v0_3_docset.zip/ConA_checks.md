# Construction‑A Legality Checks (v0.3)

**Goal:** Compute syndrome `s = H · c^T (mod 2)` for a 24‑bit candidate `c`, where `H` is a 12×24 parity‑check matrix
for the *extended binary Golay code* G24. Legal Type‑II channel requires `s = 0` and even weight class per ConA.

## What we ship now
- A **pluggable harness** (`harness/cona_golay.py`) that loads `H_golay.csv` and computes syndromes and cosets.
- A **placeholder template** `H_golay_TEMPLATE.csv` with instructions to drop the canonical matrix you use in your lab.
- A **self‑test** using extended Hamming [8,4,4] to demonstrate the path end‑to‑end without claiming a specific G24 basis.

> Why no hard‑coded H here? We avoid shipping a possibly mis‑transcribed matrix. Use your canonical H (12×24, rank 12)
from your codebook; the harness will compute all syndromes reproducibly.

## API
- `syndrome(c: np.ndarray[24]) -> np.ndarray[12]`
- `is_codeword(c) -> bool`
- `nearest_codeword(c) -> c'` (optional; syndrome/leader table pluggable)
