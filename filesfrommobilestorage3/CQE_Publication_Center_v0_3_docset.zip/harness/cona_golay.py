import numpy as np
import csv

def load_H(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row: continue
            rows.append([int(x) for x in row])
    H = np.array(rows, dtype=int) % 2
    assert H.shape[1] == 24, "H must have 24 columns"
    return H

def syndrome(H, c):
    v = (H @ (np.array(c) % 2)) % 2
    return v

def is_codeword(H, c):
    return np.all(syndrome(H,c) == 0)
