#!/usr/bin/env python3
import json, sys, argparse, hashlib, math, csv
import numpy as np

def parity_hist_mod(bits, mod):
    counts = [0]*mod
    for i,b in enumerate(bits):
        counts[i % mod] += b
    return counts

def P4_P8(bits):
    h4 = parity_hist_mod(bits, 4)
    h8 = parity_hist_mod(bits, 8)
    P4 = abs(h4[1]-h4[3])
    P8 = sum(abs(h8[k]-h8[8-k]) for k in range(1,4))
    return P4, P8

def violation_vector(bits):
    s_bit = sum(bits) % 2
    synd = [s_bit]*12
    P4, P8 = P4_P8(bits)
    return synd, P4, P8

def reduce_step(bits):
    s0,p40,p80 = violation_vector(bits)
    v0 = (sum(s0), p40, p80)
    best = None
    for i in range(len(bits)):
        y = bits.copy()
        y[i] ^= 1
        s1,p41,p81 = violation_vector(y)
        v1 = (sum(s1), p41, p81)
        if v1 < v0:
            if best is None or v1 < best[0]:
                best = (v1, y, i)
    if best is None: return bits, None
    return best[1], best[2]

def normal_form(bits, max_steps=256):
    steps = 0
    xs = bits.copy()
    while steps < max_steps:
        xs_new, idx = reduce_step(xs)
        if idx is None: break
        xs = xs_new
        steps += 1
    return xs, steps

def cmd_frame(args):
    F = {"mods":[2,4,8,32], "epsilon":1e-9}
    print(json.dumps(F))

def cmd_verify(args):
    bits = [int(x) for x in args.bits]
    synd,P4,P8 = violation_vector(bits)
    verdict = "REST" if (sum(synd)==0 and P4==0 and P8==0) else ("ACTION" if True else "REJECT")
    out = {"verdict":verdict, "syndrome_sum":sum(synd), "P4":P4, "P8":P8}
    print(json.dumps(out))

def cmd_reduce(args):
    bits = [int(x) for x in args.bits]
    nxt, idx = reduce_step(bits)
    out = {"next_bits":nxt, "flip_index":idx}
    print(json.dumps(out))

def cmd_commit(args):
    bits = [int(x) for x in args.bits]
    nf, steps = normal_form(bits)
    h = hashlib.sha256(bytes(nf)).hexdigest()
    out = {"normal_form":nf, "steps":steps, "hash":h}
    print(json.dumps(out))

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers()

    ap_frame = sub.add_parser("frame"); ap_frame.set_defaults(func=cmd_frame)

    ap_verify = sub.add_parser("verify"); ap_verify.add_argument("bits", nargs="+"); ap_verify.set_defaults(func=cmd_verify)

    ap_reduce = sub.add_parser("reduce"); ap_reduce.add_argument("bits", nargs="+"); ap_reduce.set_defaults(func=cmd_reduce)

    ap_commit = sub.add_parser("commit"); ap_commit.add_argument("bits", nargs="+"); ap_commit.set_defaults(func=cmd_commit)

    args = ap.parse_args()
    if hasattr(args, "func"): args.func(args)
    else: ap.print_help()

if __name__ == "__main__":
    main()
