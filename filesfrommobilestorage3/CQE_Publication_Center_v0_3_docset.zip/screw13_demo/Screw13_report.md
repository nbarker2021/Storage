# Screw‑13 Identity Report

Rows: 39
Max mirror error (constructed): 0.000e+00
CSV SHA256: ce1168f5582c84b6684ea8502a88c8f232702a3307814d1846bb3b613015075c
