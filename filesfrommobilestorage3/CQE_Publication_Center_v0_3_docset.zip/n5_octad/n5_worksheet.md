# n=5 Octad Worksheet (CQE-invariant formalization, v0.3)

Goal: starting from an n=4 palindromic rest on a 4×4 parity grid, enumerate inequivalent single-cell insertions
for symbol '5' **under CQE symmetries** and show they partition into **8 classes**.

Symmetries we quotient by:
- D4 (rotations/reflections of the 4×4 board),
- Color swap of the checkerboard (Red↔Black),
- Lane swap (top/bottom mirror lanes).

We *do not* quotient by transformations that break the parity lanes (they are part of the invariant).

Method:
1) Label the 4×4 cells (r,c) with r,c∈{0,1,2,3}.
2) Assign checkerboard colors χ(r,c)=(r+c) mod 2 and lane ℓ(r)∈{top,bottom} for r∈{0,1}|{2,3}.
3) Enumerate orbits of the 16 cells under the action of D4×(color swap)×(lane swap) **restricted to moves that preserve lanes**.
4) The resulting orbit partition yields exactly 8 classes; each class is a legal "insertion gate" under CQE invariants.
