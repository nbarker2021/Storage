# Moonshine envelope notes

Parameterization placeholders only in v0.3; choose 13A/13B normalization in your lab and record here.