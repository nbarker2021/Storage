import json, hashlib, random
from collections import defaultdict

# F1: n=5 classes == 8 (load produced CSV at runtime in real use)
def F1_n5_classes(n5_orbits_json):
    num = n5_orbits_json["num_classes"]
    return num == 8, {"observed": num, "expected": 8}

# F2: n=4 palindrome canonicalization (placeholder: we assert idempotence of a toy canonicalizer)
def canonicalize_toy(s):
    # toy: reverse if it reduces lexicographic order else keep; repeat until stable
    while True:
        rev = s[::-1]
        if rev < s:
            s = rev
        else:
            break
    return s

def F2_n4_pal_idempotence():
    samples = ["12344321","21433412","34122143","43211234"]
    ok = True
    for s in samples:
        c1 = canonicalize_toy(s)
        c2 = canonicalize_toy(c1)
        ok &= (c1 == c2)
    return ok, {"samples": samples}

# F3: palindromic class replays idempotently (placeholder hash equality)
def F3_pal_replay_hash():
    x = bytes("PALINDROME", "utf-8")
    h1 = hashlib.sha256(x).hexdigest()
    h2 = hashlib.sha256(x).hexdigest()
    return h1 == h2, {"hash": h1}

# F4: rotation invariance stays within orbit (placeholder: synthetic transform)
def F4_rotation_invariance():
    orbit = {(0,0),(0,3),(3,0),(3,3)}  # corners
    def rot90(rc): r,c = rc; return (c,3-r)
    ok = True; chain=[]
    rc=(0,0)
    for _ in range(4):
        chain.append(rc)
        ok &= (rc in orbit)
        rc = rot90(rc)
    return ok, {"chain": chain}

def run_all(n5_json):
    results = []
    ok1, info1 = F1_n5_classes(n5_json)
    results.append(("F1", ok1, info1))
    ok2, info2 = F2_n4_pal_idempotence()
    results.append(("F2", ok2, info2))
    ok3, info3 = F3_pal_replay_hash()
    results.append(("F3", ok3, info3))
    ok4, info4 = F4_rotation_invariance()
    results.append(("F4", ok4, info4))
    all_ok = all(ok for _,ok,_ in results)
    return all_ok, results
