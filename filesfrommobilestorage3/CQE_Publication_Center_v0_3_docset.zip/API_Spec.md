# Publication Center API (minimal)

POST /frame         → compile numeric glyphs → frame F
POST /verify        → {verdict ∈ {REST,ACTION,REJECT}, syndrome, P4, P8, typeII}
POST /reduce        → one legal ACTION step + reason
POST /commit        → collapse log to normal form; return hash
POST /store|/retrieve → invariant-keyed storage
POST /extend        → propose minimal frame extension with cost
