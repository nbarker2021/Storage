# Tolerance policy

We use ε = 1e-9 for facet inequalities; all ε are logged verbatim in ledger.