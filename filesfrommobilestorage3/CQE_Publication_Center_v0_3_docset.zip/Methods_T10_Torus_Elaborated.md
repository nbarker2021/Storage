# Methods — T¹⁰ Toroidal Control Manifold (Elaborated, v0.3)

**Carrier:** Type‑II Constructions (Leech slice via Golay exception).  
**Stage:** 10‑D (4 orthogonal 2‑planes + groove + axis).  
**Gauge:** Mirror‑parity in unison; Monster order‑13 screw.  
**Gating:** 8 facet witnesses (E8‑style), OPEN iff all latch with epsilon policy.  
**Ledger:** Append‑only; residues‑only replay; pose treated as gauge.

## 1. Coordinates & Parameters
Let the 4 two‑planes be indexed j∈{0,1,2,3}. We define per‑plane phases φ_j and amplitudes A_j, B_j.
Let Δ = 2π/13 (screw cadence), t ∈ Z be the discrete step.

Envelopes (Moonshine‑style placeholder; any smooth bounded envelope allowed):
- r_j(t) = A_j * (1 + ε_rj * cos(Δ t + φ_j))
- g(t) = A_g * (1 + ε_g * sin(Δ t + φ_g))  # groove
- z(t) = A_z * (1 + ε_z * cos(Δ t + φ_z))  # axis

Left strand (L) on plane j:  
x_{2j}(t)   = r_j(t) * cos(Δ t + φ_j)  
x_{2j+1}(t) = r_j(t) * sin(Δ t + φ_j)

Right strand (R) = mirror of L with a fixed phase shift ϑ and sign flip on odd axes:  
x^R_{2j}(t)   =  x^L_{2j}(t+τ)  
x^R_{2j+1}(t) = -x^L_{2j+1}(t+τ)

Groove/axis pair: (g(t), z(t))

**Screw identity:** one 13‑step advance equals a 2π rotation on each plane (modulo the phase offsets).

## 2. Mirror/Parity Operator Π
Π acts by (i) swapping strands, (ii) rotating phase by τ steps, (iii) flipping sign on odd axes.  
We verify ΠL(t) = R(t) to numerical tolerance (see `Screw13_report.md`).

## 3. 8‑Face Gating (Facet CSV)
We use 8 linear functionals f_k(x) = w_k·x − θ_k in Cartan/E8‑style coordinates with thresholds θ_k.  
OPEN/CLOSE is decided by f_k(x) ≥ −ε for all k with ε>0 logged in `Tolerance_policy.md`.

## 4. Reduction & Normal Form
Violation vector v = (syndrome, P4, P8).  
A legal ACTION step must strictly decrease v (lexicographic). Confluence (order‑independence) is tested in the fuzzer.

## 5. Return/Overlay
Any excursion into Type‑I overlays must even‑neighbor lift back to Type‑II before dynamics continue.
