from cqe_speedlight_miner.golden_strider import StriderCfg, tri_rail_batches
def test_batches():
    ops=list(tri_rail_batches(StriderCfg(4,3,2)))
    assert any(o[0]=="nonce" for o in ops)
    assert any(o[0]=="xtra_merkle" for o in ops)
    assert any(o[0]=="version_nonce" for o in ops)
    assert any(o[0]=="time" for o in ops)
