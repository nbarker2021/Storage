CQE-only miner scaffold
