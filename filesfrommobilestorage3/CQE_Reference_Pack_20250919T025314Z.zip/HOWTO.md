
# CQE Reference Pack — 20250919T025314Z
Files: verified_index.json|csv, wrapper_receipts_latest.csv, ledger_snapshot.csv (if present)

Gates: Normal = (OPE_debt ≤ 0.04, FCE_debt ≤ 0.04, FCE_Dvotes ≥ 40, mirror ≥ 6 both ways)  
       Strict = (OPE_debt ≤ 0.032, FCE_debt ≤ 0.032, FCE_Dvotes ≥ 48, mirror ≥ 7 both ways)

Run falsifiers (inside full repo): `python scripts/run_falsifiers.py`
