
# GAPS (Missingness Universe) — v0.30.15 — 2025-08-14

This standalone module computes a preflight "what is missing" assessment for a task:

- Estimates n-level readiness from W5H coverage and heterogeneity
- Lists required expertise tags
- Recommends subsystems (AGRM/TPG, MDHG, InverseExplore, BridgeChaser, RAG)
- Identifies missing W5H dimensions and emits half-bridge hints
- Generates a few inverse/false hypotheticals by flipping WHY/HOW weights

## Usage

```python
from gaps_module_v0_30_15 import build_gaps

metas = [
  {"family":"science","type":"doc/paper","w5h":{"what":0.8,"why":0.6,"how":0.3}},
  {"family":"governance","type":"policy","w5h":{"what":0.5,"why":0.9,"how":0.2,"where":0.4}},
]
assessment = build_gaps(metas)
print(assessment["n_est"], assessment["missing_dims"], assessment["systems"])
```
