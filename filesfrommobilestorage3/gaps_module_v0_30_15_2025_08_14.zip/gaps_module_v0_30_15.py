
from typing import Dict, Any, List
import statistics as stats
import time

EXP_MAP = {
    "finance": ["quant", "risk", "ledger"],
    "science": ["data_science", "stats"],
    "governance": ["policy", "compliance"],
    "generic": ["generalist"]
}

def w5h_vector(meta: Dict[str,Any]) -> List[float]:
    w = meta.get("w5h") or {}
    keys = ["who","what","where","when","why","how"]
    return [float(w.get(k,0.0)) for k in keys]

def w5h_coverage(metas: List[Dict[str,Any]]) -> float:
    if not metas: return 0.0
    cov = []
    for m in metas:
        v = w5h_vector(m)
        present = sum(1 for x in v if x>0.0)
        cov.append(present/6.0)
    return sum(cov)/len(cov)

def estimate_n_level(metas: List[Dict[str,Any]]) -> int:
    cov = w5h_coverage(metas)
    fams = { (m.get("family") or "generic") for m in metas }
    types = { (m.get("type") or "node") for m in metas }
    het = (len(fams) + len(types))/10.0
    score = cov*3.0 + het*2.0
    if score < 1.0: return 1
    if score < 2.0: return 2
    if score < 3.5: return 3
    if score < 4.5: return 4
    return 5

def required_expertise(metas: List[Dict[str,Any]]) -> List[str]:
    fams = { (m.get("family") or "generic") for m in metas }
    out = set()
    for f in fams:
        out.update(EXP_MAP.get(f, ["generalist"]))
    return sorted(out)

def recommend_systems(n_level: int, metas: List[Dict[str,Any]]) -> List[str]:
    rec = ["AGRM/TPG","W5H"]
    if n_level >= 3: rec.append("MDHG")
    if n_level >= 4: rec.extend(["InverseExplore","BridgeChaser"])
    doc_weight = sum(1 for m in metas if (m.get("type") or "").startswith("doc"))
    if doc_weight >= 1: rec.append("RAG-Parser")
    return rec

def build_gaps(metas: List[Dict[str,Any]]) -> Dict[str,Any]:
    n_est = estimate_n_level(metas)
    exps  = required_expertise(metas)
    recs  = recommend_systems(n_est, metas)
    dims = ["who","what","where","when","why","how"]
    dim_avgs = { d: stats.mean([(m.get("w5h") or {}).get(d,0.0) for m in metas] or [0.0]) for d in dims }
    missing_dims = [d for d,v in dim_avgs.items() if v < 0.4]
    half_bridges = [{"need": d, "hint": f"Add evidence for '{d}'"} for d in missing_dims]
    # make a couple of inverse hypotheticals
    hypotheticals = []
    for m in metas[:3]:
        w = (m.get("w5h") or {}).copy()
        if not w: continue
        w["why"] = 1.0 - w.get("why",0.0)
        w["how"] = 1.0 - w.get("how",0.0)
        hyp = dict(m); hyp["w5h"] = w; hyp["inverse"] = True
        hypotheticals.append(hyp)
    return {
        "n_est": n_est,
        "expertise": exps,
        "systems": recs,
        "dim_avgs": dim_avgs,
        "missing_dims": missing_dims,
        "half_bridges": half_bridges,
        "hypotheticals": hypotheticals,
        "ts": int(time.time())
    }
