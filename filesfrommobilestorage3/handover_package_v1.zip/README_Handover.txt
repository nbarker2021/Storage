Handover Package — Receipts-First E8-Native Computing
Generated: 2025-10-18 23:12:27 UTC

Contents
========
1) Schemas (JSON/YAML) — /schemas
2) Lambda Rules Spec (PDF) — /lambda
3) Method Papers (PDF) — /papers (15 docs)

Use
===
- Validate actions via /schemas/receipt_schema.json.
- Force every task to begin with its resolution string (schema provided).
- Select controller mode via manifest schema (E8x4 Parity, KQPL-192D, Wrapper-384D).
- Enforce the 14 portal invariants; treat refusal as lawful.

Integration
===========
- Renderers (WorldForge/ScenE8) ingest timeline tokens and receipts.
- Agents store anchors as signed hashes; compare forward/mirror at closure.
- ECC repairs occur at 64-bit tile before escalation.

Falsification
=============
- Track closure@64D (6+4 composite), Δφ dispersion (Leech vs alternates), ECC locality, refusal fidelity.
