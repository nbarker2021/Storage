
1. [Querying a Weaviate database](query_weaviate.md) - create an example collection in Weaviate and use Elysia with its core functionality to retrieve data.
2. [Basic Linear Regression](data_analysis.md) - creating a custom Elysia tool to perform a basic least squares regression on items retrieved from the `query` tool.

More examples coming soon!