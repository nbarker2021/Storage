
# Lattice System Base v9 — Semantic Hash + Shell Governance

This drop focuses on two priorities:
1) **Trainable Tier-2 semantic hash** (balanced bits, supervised pairs, exportable weights)
2) **Shell governance polish** (promotion reports, policy thresholds, persistence)

## Quick run

```bash
python -m lattice_ai.tests.hash_eval      # trains small semantic hash, prints bit imbalance
python -m lattice_ai.tests.policy_demo    # builds shells, promotes, persists to SQLite
```

## What to look at

- `core/semantic_hash.py`: tiny trainer with losses (balance, decorrelation, pairwise).
- `core/hash_system.py`: supports injecting Tier-2 weights via `set_tier2_weights(W,b)`.
- `core/shell_lifecycle.py`: emits `PromotionReport`s; saves/loads JSON; SQLite persistence via `persistence/sqlite_store.py`.
- `core/shell_policy.py`: policy dataclass for thresholds (hook for domain-specific configs).

## Next

- Hook the trainer into `HashSystem` for live rehash/migration tests.
- Add domain probe registry (multiple QA suites) and uncertainty-triggered shell expansion.
- Router budget controller (p95 latency target) with adaptive blend.


## v10 — WP‑A: Semantic Hash end‑to‑end
This version wires a **trainable Tier‑2** into a simple CLI trainer, an eval harness (recall@K, latency, occupancy), and a migration churn report.

### Train weights
```bash
python -m lattice_ai.tests.hash_train --steps 400 --out /mnt/data/weights.json
```

### Evaluate (baseline vs. trained)
```bash
# Baseline (random Tier‑2)
python -m lattice_ai.tests.hash_eval_suite

# With trained weights
python -m lattice_ai.tests.hash_eval_suite --weights /mnt/data/weights.json
```

### Migration churn
```bash
python -m lattice_ai.tests.migration_test --weights /mnt/data/weights.json
```


## v11 — WP‑B & WP‑C
- **Policy registry + auto‑expand:** `core/policy_registry.py`, `ShellManager.auto_expand_and_promote`, `core/rules_factory.py`.
  Demo: `python -m lattice_ai.tests.policy_auto_expand_demo`
- **Budget controller:** `core/budget_controller.py` chooses K/params to meet a latency budget (heuristic first pass).
  Demo: `python -m lattice_ai.tests.router_budget_demo`
