
import json, numpy as np
from lattice_ai.core.hash_system import HashSystem

def synth_dataset(n_items=2000, dim=8, seed=17):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n_items, dim))
    X = X / (np.linalg.norm(X,axis=1,keepdims=True)+1e-9)
    return X

def main(weights_json):
    X = synth_dataset()
    hs = HashSystem(dim=X.shape[1], tier2_bits=64, seed=1234)
    before = hs.hash_batch(X)
    # apply trained weights
    data = json.load(open(weights_json,"r"))
    hs.import_tier2(data)
    after = hs.hash_batch(X)
    # churn metrics
    changed = sum(1 for a,b in zip(before, after) if a!=b)
    churn = changed / len(X)
    print("Items moved houses:", changed, "of", len(X), "({:.2%})".format(churn))

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True)
    args = ap.parse_args()
    main(args.weights)
