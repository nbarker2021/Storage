
from dataclasses import dataclass
from typing import Dict

@dataclass
class ShellPolicy:
    name: str = "default"
    min_size: int = 6
    min_coherence: float = 0.10
    max_redundancy: float = 0.99
    min_domain: float = 0.0
    max_flip_rate: float = 0.05

    @classmethod
    def from_dict(cls, d: Dict):
        return cls(
            name=d.get("name","default"),
            min_size=d.get("min_size",6),
            min_coherence=d.get("min_coherence",0.10),
            max_redundancy=d.get("max_redundancy",0.99),
            min_domain=d.get("min_domain",0.0),
            max_flip_rate=d.get("max_flip_rate",0.05),
        )
