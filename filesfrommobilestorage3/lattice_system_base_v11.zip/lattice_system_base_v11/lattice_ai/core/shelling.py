
from dataclasses import dataclass
from typing import Dict, List, Callable
import numpy as np
from .types import ShellRecord

@dataclass
class ShellBuilder:
    points: np.ndarray
    ids: List[str]

    def shells_for(self, center_id: str, max_k: int = 4, nn: int = 16) -> Dict[int, List[str]]:
        i = self.ids.index(center_id)
        c = self.points[i]
        d = np.sum((self.points - c)**2, axis=1)
        order = np.argsort(d)
        shells: Dict[int, List[str]] = {}
        for k in range(1, max_k+1):
            lo = (k-1)*nn + 1
            hi = min(k*nn + 1, len(order))
            shells[k] = [self.ids[j] for j in order[lo:hi]]
        return shells

    def make_records(self, center_id: str, shells: Dict[int, List[str]], payload_hash_fn) -> List[ShellRecord]:
        recs = []
        for k, items in shells.items():
            h = payload_hash_fn(center_id + "|" + ",".join(items))
            recs.append(ShellRecord(
                glyph_id="g::" + center_id,
                center_id=center_id,
                shell_k=k,
                payload_hash=h,
                stats={"size": float(len(items))},
                provenance={"built_by": "ShellBuilder"},
                members=items,
                ttl=10080,
                access_policy="default",
            ))
        return recs
