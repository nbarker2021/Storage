
from dataclasses import dataclass
from typing import Optional, List, Tuple
import time, numpy as np
from .router import Router
from .safe_cube import SafeCube

@dataclass
class BudgetController:
    p95_budget_ms: float = 20.0
    base_k_candidates: int = 64
    min_k_candidates: int = 16
    max_k_candidates: int = 128
    alpha_range: Tuple[float,float] = (0.6, 0.9)  # for LocalRouter blend if used

    def choose_params(self, latency_estimate_ms: float) -> Tuple[int, float]:
        """Heuristic: shrink K if we're over budget; expand if well below. Adjust alpha slightly."""
        if latency_estimate_ms > 1.2 * self.p95_budget_ms:
            k = max(self.min_k_candidates, int(self.base_k_candidates * 0.5))
            alpha = self.alpha_range[1]  # lean more on cosine (cheaper)
        elif latency_estimate_ms < 0.6 * self.p95_budget_ms:
            k = min(self.max_k_candidates, int(self.base_k_candidates * 1.25))
            alpha = self.alpha_range[0]  # allow more structure
        else:
            k = self.base_k_candidates
            alpha = sum(self.alpha_range)/2.0
        return k, alpha

    def query(self, router: Router, center_id: str, use_promoted: bool = True, top_k: int = 10):
        # quick latency proxy: measure prefilter path with current K, then adapt
        t0 = time.time()
        cands = router.prefilter([center_id], k_candidates=self.base_k_candidates, use_promoted_for=center_id if use_promoted else None)
        dt = (time.time()-t0)*1000.0
        k_new, _ = self.choose_params(dt)
        if k_new != self.base_k_candidates:
            cands = router.prefilter([center_id], k_candidates=k_new, use_promoted_for=center_id if use_promoted else None)
        top = router.exact_rank(center_id, cands, top_k=top_k) if cands else []
        return {"latency_ms": dt, "k_candidates": k_new, "candidates": cands, "top": top}
