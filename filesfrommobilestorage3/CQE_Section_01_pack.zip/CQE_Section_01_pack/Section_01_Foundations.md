# Section 01 — Foundations: Tokens, Buckets, Colors & Overlays

> **Cast**:  
> **Instructor (I)** — patient, precise, slightly playful.  
> **Learner (L)** — curious, hands-on, challenges assumptions.

---

## Scene 1 — Why stand‑ins first?

**L:** Why do we *delay* assigning meanings and instead use stand‑in tokens?  
**I:** Because early on we want stability, not certainty. Stand‑ins let us *coarsely pose* the problem
in eight directions without over‑committing. CQE pays a heavier offline bill (overlays) so your online
decision collapses cleanly into **four bits**.

**Board note:** *Stand‑ins → bucketize → color (hex16) + gradient → 8× speculative overlays → palindromic rest → 4‑bit commit.*

---

## Scene 2 — The four primitives & eight faces

**I:** We’ll work with four driving buckets (you may rename them later):
1. **Sense** — inputs, observations
2. **Logic** — constraints, rules
3. **Memory** — priors, exemplars
4. **Action** — plans, candidates

Each has a mirrored partner, giving eight faces (octet). For today’s toy, we stay in **4 driving lanes**,
and let mirroring happen automatically during *rest finding*.

**L:** And color?  
**I:** A 16‑hex palette (0..F) — we encode “proximity to core” as a gradient 0..1. That’s not about hue
semantics; it’s a scalar the engine can use for palindromic checks.

---

## Scene 3 — What’s an overlay?

**I:** An overlay is a sparse summary of “how much each bucket contributes under a pose”. We don’t enumerate
every path; we keep *receipts* (few metrics) under budget.

We’ll compute three receipts today:
- **whiteness** — uniformity of support (1 − variance of gradient)  
- **rho_couple** — simple coupling score across buckets (here: normalized covariance proxy)  
- **novelty** — how non‑redundant the token set is (1 − duplicate rate by stem/hash)

**L:** And the palindromic rest?  
**I:** Sort contribution by bucket and check a mirror criterion. If it’s not palindromic, we reflect and
average (“mirror settle”).

---

## Scene 4 — The 4‑bit commit

**I:** We expose four views (think: **Execute, Reflect, Synthesize, Verify**). For each, we threshold a
blend of receipts. On this toy engine, it’s deterministic and reproducible. That 4‑bit vector is your
portable invariant for replay and comparison.

**L:** So the meaning arrives *after* the commit?  
**I:** Exactly. Resolve real tokens only after the 4 bits lock.

---

## Scene 5 — Lab briefing

We will:
1. Load `sample_tokens1.csv` (12 tokens across 4 buckets).  
2. Build an overlay (whiteness, rho, novelty).  
3. Find a palindromic rest (or mirror‑settle).  
4. Emit `commit.json` with a 4‑bit vector and receipts.

Run:
```bash
cd labs/lab1_foundations
python cqe_lab1.py --tokens sample_tokens1.csv --out commit_out
```

Inspect the three outputs and compare to the interpretation table at the end of this file.

---

## Scene 6 — Walkthrough (after you run the lab)

**L:** My `overlay.json` shows balanced bucket scores; `whiteness≈0.88`.  
**I:** Good — uniform gradients usually portend a palindromic rest. What about `rho_couple`?  
**L:** ~0.61.  
**I:** That’s adequate to open 3 of 4 commit bits on the default thresholds.

**L:** The `commit.json` has bits `E=1, R=1, S=1, V=0`.  
**I:** Interpreted minimally: *execute*, *reflect*, *synthesize* are greenlit; *verify* awaits more mass.
On a real corridor, you’d either fetch evidence or down‑rank risky actions.

---

## Appendix — Interpretation cheat‑sheet (toy engine)

| Receipt       | Range  | Meaning in toy engine                            |
|---------------|--------|--------------------------------------------------|
| whiteness     | 0..1   | Higher = more uniform support across tokens      |
| rho_couple    | 0..1   | Higher = buckets co‑vary (coupled)               |
| novelty       | 0..1   | Higher = less duplication / more diversity       |

**4‑bit mapping**
- **E** (Execute): avg(receipts) > 0.55  
- **R** (Reflect): whiteness > 0.6 and rho > 0.4  
- **S** (Synthesize): novelty > 0.5  
- **V** (Verify): min(receipts) > 0.6

> *Note:* These are didactic thresholds, not domain‑optimal numbers.

---

## Credits
This section carries forward the CQE Section 00 prologue: stand‑ins, octet framing, palindromic rest,
and a 4‑bit invariant. Replace heuristics later with your domain‑specific corridors.
