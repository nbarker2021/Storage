# Section 01 — Foundations: Tokens, Buckets, Colors & Overlays

This pack contains the lesson (scene-based), lab, templates, and a small reference implementation to
compute a *toy* palindromic rest and a 4‑bit commit for CQE.

## Structure
- `Section_01_Foundations.md` — instructor × learner scene, theory, and examples.
- `labs/lab1_foundations/` — inputs, the `cqe_lab1.py` script, and sample outputs.
- `templates/` — color palette, overlay schema, and token schema.
- `README.md` — this file.

## Quickstart
```bash
# (Python 3.9+ recommended)
cd labs/lab1_foundations
python cqe_lab1.py --tokens sample_tokens1.csv --out commit_out
# Outputs:
#   commit_out/overlay.json
#   commit_out/commit.json
#   commit_out/receipts.json
```
See the lesson file for the scene-based walkthrough and interpretation.
