#!/usr/bin/env python3
import argparse, csv, json, os, math
from collections import defaultdict, Counter

def load_tokens(path):
    rows = []
    with open(path, newline="") as f:
        for i, r in enumerate(csv.DictReader(f)):
            r["gradient_score"] = float(r["gradient_score"])
            rows.append(r)
    return rows

def compute_receipts(tokens):
    # group by bucket
    buckets = ["Sense","Logic","Memory","Action"]
    by_b = {b: [] for b in buckets}
    for r in tokens:
        if r["bucket"] in by_b:
            by_b[r["bucket"]].append(r)
    # basic contrib = average gradient per bucket (normalized later)
    contrib_raw = {b: (sum(t["gradient_score"] for t in by_b[b]) / max(1, len(by_b[b]))) for b in buckets}
    # normalize to 0..1
    mx = max(contrib_raw.values()) or 1.0
    contrib = {b: (contrib_raw[b] / mx) for b in buckets}
    # whiteness = 1 - variance of all gradients
    all_g = [t["gradient_score"] for t in tokens] or [0.0]
    mean_g = sum(all_g)/len(all_g)
    var_g = sum((g-mean_g)**2 for g in all_g)/len(all_g)
    whiteness = max(0.0, min(1.0, 1.0 - var_g))  # toy proxy

    # novelty = 1 - duplicate rate by (text lower)
    texts = [t["text"].strip().lower() for t in tokens]
    dup_rate = 1.0 - len(set(texts))/max(1,len(texts))
    novelty = max(0.0, min(1.0, 1.0 - dup_rate))

    # rho_couple: toy proxy using covariance between bucket contribs and uniform target
    vals = [contrib[b] for b in buckets]
    mean_v = sum(vals)/len(vals)
    cov = sum((v-mean_v)*(0.5-0.5) for v in vals)  # 0; keep simple
    # instead, use 1 - stddev as coupling proxy
    std = math.sqrt(sum((v-mean_v)**2 for v in vals)/len(vals))
    rho = max(0.0, min(1.0, 1.0 - std))  # higher when buckets are balanced

    receipts = {
        "whiteness": round(whiteness, 4),
        "rho_couple": round(rho, 4),
        "novelty": round(novelty, 4)
    }
    overlay = [{"bucket": b, "contrib": round(contrib[b],4),
                "whiteness": receipts["whiteness"],
                "rho_couple": receipts["rho_couple"],
                "novelty": receipts["novelty"]} for b in buckets]
    return overlay, receipts

def palindromic_rest(overlay):
    # check palindrome in contrib sequence (S,L,M,A vs reversed)
    seq = [o["contrib"] for o in overlay]
    rev = list(reversed(seq))
    eps = 0.05
    pal = all(abs(a-b) <= eps for a,b in zip(seq, rev))
    if pal:
        status = "palindromic"
        pal_seq = seq
    else:
        # mirror-settle: average with reverse
        pal_seq = [(a+b)/2.0 for a,b in zip(seq, rev)]
        status = "mirror_settled"
    # build rest object
    rest = {
        "status": status,
        "contrib_pal": [round(x,4) for x in pal_seq]
    }
    return rest

def commit_bits(receipts):
    # toy thresholds
    E = 1 if (sum(receipts.values())/3.0) > 0.55 else 0
    R = 1 if (receipts["whiteness"] > 0.6 and receipts["rho_couple"] > 0.4) else 0
    S = 1 if receipts["novelty"] > 0.5 else 0
    V = 1 if min(receipts.values()) > 0.6 else 0
    return {"E":E,"R":R,"S":S,"V":V}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    tokens = load_tokens(args.tokens)
    overlay, receipts = compute_receipts(tokens)
    rest = palindromic_rest(overlay)
    commit = {
        "bits": commit_bits(receipts),
        "receipts": receipts,
        "rest": rest
    }
    with open(os.path.join(args.out,"overlay.json"),"w") as f:
        json.dump(overlay, f, indent=2)
    with open(os.path.join(args.out,"receipts.json"),"w") as f:
        json.dump(receipts, f, indent=2)
    with open(os.path.join(args.out,"commit.json"),"w") as f:
        json.dump(commit, f, indent=2)
    print("Wrote:", args.out)

if __name__ == "__main__":
    main()
