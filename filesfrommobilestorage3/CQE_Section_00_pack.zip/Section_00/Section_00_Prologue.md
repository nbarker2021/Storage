# Section 00 — Prologue & Ground Rules (Scene-Based Lesson)

**Cast**
- **Instructor (I)** — your guide to CQE.
- **Learner (L)** — a curious engineer/researcher new to CQE.

---

## Scene 1 — Why CQE?

**L:** I’ve used transformers and classical pipelines. What makes CQE different?  
**I:** CQE is a *reasoning harness* with three invariants: **palindromic rest**, **4‑bit commit**, and **octet parity**.  
**L:** Palindromic… in what sense?  
**I:** We stage speculative structure first, then *only commit* when a four‑view audit locks. After commit, tokens resolve to real meanings; before commit they’re *stand‑ins* governed by neutral geometry (buckets, colors, parity).

**L:** So exploration and commitment are separated?  
**I:** Precisely. Exploration = overlays; Commitment = 4 bits + receipts; Execution = applied tokens. The benefit is deterministic replay, provenance, and easy rollback.

---

## Scene 2 — Minimum objects

**I:** CQE uses a compact set of objects:

1. **Stand‑in token** — a neutral placeholder with `bucket`, `color_hex16`, `gradient_score`, and `parity`.  
2. **DNA‑10** — the canonical *state card* (10 fields) for any bundle: identity, pose, parity, receipts, etc.  
3. **Overlay** — sparse path summaries over bucket×path.  
4. **Commit (4‑bit)** — which of four canonical views pass; stored with a Merkle root and receipts.  
5. **Ledger entry** — hash‑addressed record tying schema version → overlays → commit → provenance.

**L:** And the octet?  
**I:** At `n=5`, eight inequivalent insertion gates are forced. We honor that with **octet parity**—you can run with 2 or 4 rails, but the structure tends to close at 8.

---

## Scene 3 — Palindromic Rest & Receipts

**I:** We seek a *palindromic rest*—the symmetric snapshot whose overlays intersect best. Then we compute receipts:
- **whiteness** (coverage balance),
- **rho** (rotation invariance score),
- **ECE** (expected calibration error of the overlay predictions),
- **leakage** (data path isolation),
- **budget** (compute used).

**L:** If receipts fail?  
**I:** Mark provisional, rotate rails (or add a discriminative rail), and re‑stage.

---

## Scene 4 — 4‑bit Commit

**I:** After receipts pass, we seal a **4‑bit vector**: `[v1,v2,v3,v4] ∈ {0,1}^4`. Each bit corresponds to a canonical view. Publish a Merkle root over rest + overlay fingerprints + receipts. Only *then* do we resolve stand‑ins to real meanings and act.

**L:** That enables deterministic replay?  
**I:** Yes—re-running with the same input reproduces the same commit and downstream behavior.

---

## Scene 5 — Lab 0

**Task:** You’ll take a tiny token set, map them to stand‑ins, fill a DNA‑10, sketch overlays (textual), and produce a **dummy 4‑bit commit** with placeholder receipts.

**Files:**
- `labs/lab0_prologue/sample_tokens.csv`
- `labs/lab0_prologue/dna10_example.json`
- `labs/lab0_prologue/receipts/receipt0.json`

**Steps:**
1. Open `templates/tokens_schema.csv` — see the stand‑in fields.  
2. Inspect `sample_tokens.csv` — note buckets and hex colors.  
3. Open `templates/dna10_template.json` — duplicate to a working copy; fill from `sample_tokens.csv`.  
4. Draft overlays (bullet list inside `dna10_example.json` → `overlays.paths`). Keep them *sparse*.  
5. Compute a dummy commit: set `commit.bits` to something like `[1,1,0,1]` and fill `receipts` with plausible placeholder numbers.  
6. Validate invariants (palindromic rest present? receipts within thresholds?). If not, re‑stage.  
7. Save as a new *receipt* (copy `receipts/receipt0.json` and edit fields).

**Rubric:**  
- Neutrality preserved pre‑commit,  
- Palindromic rest described,  
- Receipts consistent and honest,  
- 4‑bit commit present,  
- Clear overlay sketch.

---

## Scene 6 — Ground rules

1. **Separation of phases**: Explore → Commit → Execute.  
2. **Idempotence**: Re‑canonicalization does not change rest.  
3. **Rotation invariance**: Rotating labels/pose shouldn’t change the ledger class.  
4. **Privacy**: Store hashes and summaries, not raw secrets.  
5. **Budget honesty**: Track compute and early‑stop heavily pruned branches.

**L:** Understood. Ready for Section 01.  
**I:** Great. Finish Lab 0; we’ll use your DNA‑10 as seed for the next section.
