# CQE Course — Section 00: Prologue & Ground Rules

Welcome! This is the self-contained pack for **Section 00** of the 16‑part CQE course.
It includes:
- `Section_00_Prologue.md` (scene-based lesson: Instructor × Learner)
- Templates in `templates/` (DNA‑10, token schema, commit template)
- Lab 0 assets in `labs/lab0_prologue/` (sample tokens, a filled DNA‑10 example, a receipt)

> Tip: Open the Prologue first, then follow the Lab 0 instructions inside.
