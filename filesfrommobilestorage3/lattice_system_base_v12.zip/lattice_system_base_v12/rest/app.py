
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import numpy as np

from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.router import Router
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_qa import ShellQASuite, ShellPromotionRules
from lattice_ai.geometry.e8_roots import E8
from lattice_ai.persistence.sqlite_store import SQLiteStore
from lattice_ai.jobs.job_runner import JobRunner
from lattice_ai.core.metrics_runtime import GLOBAL_METRICS

app = FastAPI(title="Lattice AI Service", version="0.2")

# singletons (demo only)
e8 = E8.build()
cube = SafeCube(dim=8, seed=777)
sm = ShellManager()
router = Router(cube, shell_manager=sm)
store = SQLiteStore("/mnt/data/lattice_ai_v12.db")
jobs = JobRunner(cube, sm)

class GlyphIn(BaseModel):
    id: str
    tags: Optional[dict] = None

@app.post("/glyphs")
def add_glyph(g: GlyphIn):
    cube.add_glyph(g.id, **(g.tags or {}))
    cube.store_glyph(g.id)
    store.persist_glyphs(cube); store.persist_houses(cube)
    GLOBAL_METRICS.counter("glyphs_added").inc()
    return {"ok": True}

@app.post("/build_shells/{center_id}")
def build_shells(center_id: str, max_k: int = 3, nn: int = 10):
    R = e8.roots; ids = [f"root::{i}" for i in range(R.shape[0])]
    if center_id not in ids:
        raise HTTPException(404, "center_id not found among E8 roots for demo")
    sb = ShellBuilder(points=R, ids=ids)
    shells = sb.shells_for(center_id=center_id, max_k=max_k, nn=nn)
    sm.create(center_id, shells, hash_fn=lambda s: str(abs(hash(s))))
    suite = ShellQASuite(); rules = ShellPromotionRules(min_size=6, min_coherence=0.10)
    sm.validate_and_promote(center_id, suite, rules, get_vector=lambda gid: R[int(gid.split("::")[1])], score_fn=lambda _:1.0)
    store.persist_shells_and_reports(sm)
    GLOBAL_METRICS.counter("shells_built").inc()
    return {"ok": True}

@app.get("/query")
def query(center_id: str, top_k: int = 10):
    cands = router.prefilter([center_id], k_candidates=64, use_promoted_for=center_id)
    top = router.exact_rank(center_id, cands, top_k=top_k) if cands else []
    GLOBAL_METRICS.hist("prefilter_candidates").observe(len(cands))
    return {"center_id": center_id, "candidates": cands, "topk": [x for x,_ in top]}

@app.post("/jobs/run_once")
def run_jobs_once():
    jobs.run_once()
    return {"statuses": jobs.snapshot()}

@app.get("/metrics")
def metrics():
    return GLOBAL_METRICS.snapshot()
