# Billing Model (v0.1)
- Unit: wrapper_id × commit_bits length × receipts bytes.
- Example: 4-bit commit with 1 KB receipts → 1 credit; 64-bit with 20 KB → 8 credits.
- Free: EXO with reason codes (encourages honesty). DIGEST billed on commit.
- Replay: discounted; same merkle_root → near-zero cost.
