#!/usr/bin/env python3
import json, sys, re, argparse
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--schema", type=Path, required=True)
    ap.add_argument("--doc", type=Path, required=True)
    args = ap.parse_args()
    import jsonschema
    schema = json.loads(args.schema.read_text())
    doc = json.loads(args.doc.read_text())
    jsonschema.validate(instance=doc, schema=schema)
    print("OK")
if __name__=="__main__":
    main()
