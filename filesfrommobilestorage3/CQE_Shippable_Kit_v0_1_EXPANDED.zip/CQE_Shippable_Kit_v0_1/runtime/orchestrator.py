#!/usr/bin/env python3
import json, subprocess, sys, time, hashlib, os
from pathlib import Path

def sha(x:bytes)->str: import hashlib; return hashlib.sha256(x).hexdigest()

class CollisionMonitor:
    def __init__(self, min_hamming=2):
        self.codes = []  # (rail_id, bits)
        self.min_hamming = min_hamming
    def hamming(self, a,b):
        n = min(len(a), len(b))
        return sum(1 for i in range(n) if a[i]!=b[i])
    def add(self, rail_id, bits):
        collisions = []
        for (rid, code) in self.codes:
            if self.hamming(bits, code) < self.min_hamming:
                collisions.append({"with": rid, "code": code})
        self.codes.append((rail_id, bits))
        return collisions

def run_rail(cli, rail, seed, outdir):
    out = outdir/f"{rail}.json"
    cmd = [sys.executable, str(cli), "--rail", rail, "--seed", str(seed), "--out", str(out)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode!=0:
        return {"rail": rail, "error": p.stderr}
    return json.loads(out.read_text())

def main():
    root = Path(__file__).resolve().parent
    cli = root/"cqe_cli.py"
    plan = {"rails":["WB_SYN","OC_SUR","ARC_SYN"], "wrapper_id":"CQE_ORCH", "seed":20250920}
    receipts_dir = root.parent/"receipts_orchestrator"
    receipts_dir.mkdir(parents=True, exist_ok=True)
    cm = CollisionMonitor(min_hamming=2)
    entries = []
    rotation_events = []
    for r in plan["rails"]:
        e = run_rail(cli, r, plan["seed"], receipts_dir)
        bits = e.get("commit_bits","0000")
        col = cm.add(r, bits)
        if col:
            rotation_events.append({"rail": r, "bits": bits, "collisions": col, "action": "PROMOTE_OR_ROTATE"})
            # suggest promote to 8-bit (placeholder)
            e["suggested_action"] = "promote_to_8bit"
        entries.append(e)
    bundle = {"wrapper_id":plan["wrapper_id"], "seed":plan["seed"], "entries":entries, "rotation_events":rotation_events,
              "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    bundle["merkle_root"] = sha(json.dumps(bundle, sort_keys=True).encode())
    out = receipts_dir/"orchestrator_bundle.json"
    out.write_text(json.dumps(bundle, indent=2))
    print(json.dumps(bundle, indent=2))

if __name__=="__main__":
    main()
