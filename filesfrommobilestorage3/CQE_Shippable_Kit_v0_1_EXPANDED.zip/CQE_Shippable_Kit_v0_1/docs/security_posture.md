# Security Posture (v0.1)
- Stand-ins only until commit; never bind raw secrets pre-commit.
- Receipts redact PII; glyph packs are whitelisted per domain.
- Ledger is append-only; Merkle roots make tamper-evidence trivial.
- Sidecars run sandboxed with budgets; no network in strict mode by default.
