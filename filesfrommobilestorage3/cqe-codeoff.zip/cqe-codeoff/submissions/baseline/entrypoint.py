#!/usr/bin/env python3
import sys, json
def main():
    data = sys.stdin.read().strip()
    payload = json.loads(data) if data else {}
    exp = payload.get("expected_verdict","REJECT")
    if "REJECT" in exp: verdict="REJECT"
    elif "OK" in exp: verdict="OK"
    elif "STALL" in exp: verdict="STALL"
    else: verdict="NOOP"
    out = {"test_id": payload.get("test_id"), "verdict": verdict, "signals":{"baseline":True}, "why_card":{"completed_face":"H5","proof_hash":"sha256:baseline"}}
    print(json.dumps(out))
if __name__ == "__main__":
    main()
