#!/usr/bin/env python3
import os, sys, json, subprocess, csv, pathlib, random, time
import click
from datetime import datetime

ROOT = pathlib.Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"; RESULTS.mkdir(exist_ok=True)

SEVERITY_WEIGHTS = {"P0":5,"P1":3,"P2":2,"P3":1}
TRACKS = {
  "core": ["tests/falsifiers_round1.csv","tests/falsifiers_round2.csv","tests/acceptance_tests_extra.csv"],
  "reverse": ["tests/reverse_tests.csv"],
  "rd_it": ["tests/rd_it_tests.csv"],
  "symmetry": []
}

def load_rows(files):
    rows = []
    for f in files:
        p = ROOT / f
        if not p.exists(): 
            continue
        with p.open() as fh:
            reader = csv.DictReader(fh)
            rows.extend(list(reader))
    return rows

def verdict_ok(expected, got):
    if "/" in expected:
        return got in [x.strip() for x in expected.split("/")]
    return expected == got

@click.group()
def cli(): ...

@cli.command()
@click.argument("submission_dir", type=click.Path(exists=True, file_okay=False))
@click.option("--tracks", default="core,reverse,rd_it", show_default=True)
def evaluate(submission_dir, tracks):
    sub = pathlib.Path(submission_dir)
    entry = sub / "entrypoint.py"
    team = "unknown"
    manifest = sub / "manifest.json"
    if manifest.exists():
        team = json.loads(manifest.read_text()).get("team","unknown")

    files = []
    for t in tracks.split(","):
        files += TRACKS.get(t, [])
    tests = load_rows(files)
    random.shuffle(tests)

    log_path = RESULTS / f"judge_log_{team}_{int(time.time())}.ndjson"
    lb_path = RESULTS / "leaderboard.csv"
    if not lb_path.exists():
        lb_path.write_text("team,score,total,pass_rate,ts\n")
    score = 0; total = 0; passed = 0
    for r in tests:
        tid = r.get("test_id")
        expected = r.get("expected_verdict","REJECT")
        sev = r.get("severity","P2")
        payload = {
            "test_id": tid, "category": r.get("category","core"),
            "scenario": r.get("scenario",""),
            "input_payload_json": r.get("input_payload_json","{}"),
            "expected_verdict": expected,
            "expected_signals_json": r.get("expected_signals_json","{}")
        }
        proc = subprocess.Popen([sys.executable, str(entry), "test"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = proc.communicate(json.dumps(payload)+"\n", timeout=20)
        got = "ERROR"
        try:
            resp = json.loads(out.strip() or "{}")
            got = resp.get("verdict","ERROR")
        except Exception:
            pass
        w = SEVERITY_WEIGHTS.get(sev,1)
        total += w
        ok = verdict_ok(expected, got)
        if ok:
            score += w; passed += 1
        with open(log_path,"a") as lf:
            lf.write(json.dumps({"ts":datetime.utcnow().isoformat()+"Z","team":team,"test":tid,"expected":expected,"got":got,"sev":sev,"ok":ok})+"\n")
    with open(lb_path,"a") as f:
        f.write(f"{team},{score},{total},{passed}/{len(tests)},{int(time.time())}\n")
    print(f"Team {team}: {score}/{total}  Passed {passed}/{len(tests)}  Log: {log_path}  Leaderboard: {lb_path}")

if __name__ == "__main__":
    cli()
