Severity weights P0=5,P1=3,P2=2,P3=1; tie-breaks by reverse then determinism.
