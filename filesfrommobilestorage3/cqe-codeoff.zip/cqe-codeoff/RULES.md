Determinism, idempotency, no network from entrypoint.
