# CQE Code‑Off Competition Kit
Tracks: Core Determinism, Reverse‑Ops, R&D/IT, Symmetry & Lifts.
Usage: `python tools/judge.py evaluate submissions/baseline --tracks core,reverse,rd_it`
