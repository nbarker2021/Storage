"""
S5 query plan builder and receipt normalizer (web.run integration happens outside).
"""
from typing import List, Dict, Any
from .receipts import merkle_leaf_hex

def plan_for_token(token: str, edge_type: str) -> List[Dict[str, Any]]:
    return [
        {"role":"precision","q":f"\"{token}\" {edge_type}","recency_days":365,"domains":[]},
        {"role":"recall","q":f"{token} {edge_type} evidence","recency_days":None,"domains":[]},
        {"role":"paraphrase_alt","q":f"\"{token} alternative\" OR \"{token} parity\"","recency_days":1095,"domains":[]},
        {"role":"counterfactual","q":f"\"{token}\" -{edge_type} contradiction","recency_days":None,"domains":[]},
    ]

def normalize_receipt(src: Dict[str,Any], snippet: Dict[str,Any], anchors: Dict[str,Any], status: str, notes:str="") -> Dict[str,Any]:
    r = {"source": src, "snippet": snippet, "anchors": anchors, "mapping":{"status":status,"notes":notes}}
    r["hashes"] = {"merkle_leaf_hex": merkle_leaf_hex(snippet)}
    return r
