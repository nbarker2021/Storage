"""
CI gates for S3..S5.
"""
from typing import Dict, Any, List

def g_cardinality(stage1: Dict[str,Any]) -> bool:
    return len(stage1.get("main",[]))==64 and len(stage1.get("parity",[]))==64

def g_parity(stage1: Dict[str,Any]) -> bool:
    for b in stage1.get("main",[]):
        mid = stage1["parity"][63-b["bucket_id"]]["bucket_id"] if stage1.get("parity") else None
        if mid is None or mid != 63 - b["bucket_id"]:
            return False
    return True

def g_24_lock(core24: List[int], fringe8: List[int]) -> bool:
    return len(core24)==24 and len(fringe8)==8 and len(set(core24))==24

def g_diagonals(ids: List[int]) -> bool:
    return all(0 <= i < 64 for i in ids)

def g_octet(bucket: Dict[str,Any]) -> bool:
    return len(bucket.get("octets",[]))==8
