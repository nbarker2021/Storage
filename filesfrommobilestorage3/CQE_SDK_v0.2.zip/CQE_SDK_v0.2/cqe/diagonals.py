"""
Diagonal traversal utilities, including pose-aware diagonals modulated by a Coxeter/CARTAN angle.
"""
from typing import Tuple
import math

def step(r: int, c: int) -> Tuple[int, int]:
    """Uniform diagonal step (S3): (r,c)->(r+1 mod 32, c+1 mod 4)."""
    return ( (r+1)%32, (c+1)%4 )

def pose_step(r: int, c: int, angle_rad: float, k_bias: float = 0.0) -> Tuple[int, int]:
    """
    Pose-aware diagonal step. angle_rad modulates row advance; columns still wrap by +1.
    dr = 1 + round( |sin(angle_rad)| + k_bias ) in {{1,2}}
    """
    dr = 1 + round(abs(math.sin(angle_rad)) + k_bias)
    nr = (r + dr) % 32
    nc = (c + 1) % 4
    return nr, nc
