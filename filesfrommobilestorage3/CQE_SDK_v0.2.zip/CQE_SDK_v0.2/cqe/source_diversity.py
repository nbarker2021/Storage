"""
Source diversity constraints for S5.
Enforces diversity across publishers/domains/media types and presence of contradictions.
"""
from typing import List, Dict, Any
from urllib.parse import urlparse

def domain(url: str) -> str:
    try:
        return urlparse(url).netloc.split(":")[0].lower()
    except Exception:
        return ""

def evaluate(receipts: List[Dict[str, Any]], min_publishers=3, min_domains=3, require_pdf=False, require_disagreement=True):
    pubs = set()
    doms = set()
    has_pdf = False
    statuses = set()
    for r in receipts:
        src = r.get("source", {})
        pubs.add(src.get("publisher","").strip().lower())
        doms.add(domain(src.get("url","")))
        if r.get("snippet",{}).get("pdf_page") is not None:
            has_pdf = True
        statuses.add(r.get("mapping",{}).get("status"))
    ok = True
    reasons = []
    if len([p for p in pubs if p]) < min_publishers:
        ok = False; reasons.append(f"need >={min_publishers} publishers; got {len(pubs)}")
    if len([d for d in doms if d]) < min_domains:
        ok = False; reasons.append(f"need >={min_domains} domains; got {len(doms)}")
    if require_pdf and not has_pdf:
        ok = False; reasons.append("need at least one PDF receipt")
    if require_disagreement and "refutes" not in statuses:
        ok = False; reasons.append("need at least one refuting receipt")
    return {"ok": ok, "reasons": reasons, "publishers": sorted(pubs), "domains": sorted(doms), "statuses": sorted(statuses)}
