"""
Bucket scaffolding for S1..S3.
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

def mirror_id(i: int) -> int:
    return 63 - i

@dataclass
class Octet:
    elements: List[Any] = field(default_factory=list)  # len up to 8

@dataclass
class Bucket:
    bucket_id: int
    label: str = ""
    octets: List[Octet] = field(default_factory=lambda: [Octet() for _ in range(8)])
    rag: Dict[str, Any] = field(default_factory=dict)
    debruijn: Dict[str, Any] = field(default_factory=lambda: {"k":5})
    merkle: Dict[str, Any] = field(default_factory=lambda: {"root": None})
    links: Dict[str, Any] = field(default_factory=dict)
    status: str = "stage1"
    parity: str = "main"

    def set_mirror(self):
        self.links["mirror_bucket_id"] = mirror_id(self.bucket_id)

@dataclass
class Stage2Coord:
    split_row: int  # 1..4
    split_col: int  # 1..32

@dataclass
class Stage2Entry:
    origin_bucket_id: int
    coord: Stage2Coord
    placement: Dict[str, Any] = field(default_factory=dict)

def even_odd_split(seq: List[int]):
    even = [seq[i] for i in range(len(seq)) if i%2==0]
    odd  = [seq[i] for i in range(len(seq)) if i%2==1]
    return even, odd

def core24_fringe8(seq: List[int]):
    core24 = seq[:24]
    fringe8 = seq[24:32]
    return core24, fringe8
