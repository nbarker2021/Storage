"""
Extended binary Golay (24,12,8) — interface + demo syndrome check.
NOTE: Provide a valid 12x24 parity-check matrix H for production.
"""
from typing import List

def matmul_mod2(H: List[List[int]], v: List[int]) -> List[int]:
    return [sum((h & 1) * (x & 1) for h, x in zip(row, v)) % 2 for row in H]

def is_codeword(H: List[List[int]], v: List[int]) -> bool:
    if len(v) != 24:
        raise ValueError("v must be length-24 bit vector")
    s = matmul_mod2(H, v)
    return all(bit == 0 for bit in s)

# Example placeholder H (NOT canonical). Replace with a standard H before use.
DEMO_H = [[1 if (i==j or (i+1)%12==j) else 0 for j in range(24)] for i in range(12)]
