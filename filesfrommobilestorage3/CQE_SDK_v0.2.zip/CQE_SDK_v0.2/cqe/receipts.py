"""
Receipts utilities: Merkle leaf hashing (blake2b-256), canonical JSON.
"""
import json, hashlib

def canonical_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def merkle_leaf_hex(obj) -> str:
    cj = canonical_json(obj).encode("utf-8")
    return hashlib.blake2b(cj, digest_size=32).hexdigest()
