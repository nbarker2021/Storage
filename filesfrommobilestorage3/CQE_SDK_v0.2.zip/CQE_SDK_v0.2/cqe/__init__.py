"""
CQE SDK v0.2 — Shapes-first, receipts-first orchestration for meaning.
Created: 2025-10-11T07:35:23Z
"""
__version__ = "0.2.0"
