"""
Pragmatics lane: speech-act tagging, implicature/stance heuristics, and schema.
This is adapter-friendly: swap out detectors for model-native tools.
"""
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import re

SPEECH_ACTS = ["assertive","directive","commissive","expressive","declarative"]

HEDGE_PATTERNS = [
    r"\bmaybe\b", r"\bperhaps\b", r"\bmight\b", r"\bseems\b", r"\bpossible\b"
]
POLITENESS = [r"\bplease\b", r"\bcould you\b", r"\bwould you\b"]
SARCASM = [r"yeah right", r"sure[,!.?]", r"as if", r"/s\b"]

def detect_speech_act(text: str) -> str:
    t = text.strip().lower()
    if re.search(r"\?$", t) or re.search(r"\bcan you\b|\bcould you\b|\bplease\b", t):
        return "directive"
    if re.search(r"\bi promise\b|\bi will\b", t):
        return "commissive"
    if re.search(r"!$", t) or re.search(r"\bi feel\b|\bi'm\b", t):
        return "expressive"
    return "assertive"

def detect_flags(text: str) -> Dict[str, bool]:
    t = text.lower()
    return {
        "hedge": any(re.search(p, t) for p in HEDGE_PATTERNS),
        "politeness": any(re.search(p, t) for p in POLITENESS),
        "sarcasm": any(re.search(p, t) for p in SARCASM)
    }

def annotate(text: str) -> Dict[str, Any]:
    sa = detect_speech_act(text)
    flags = detect_flags(text)
    return {"speech_act": sa, **flags}
