# CQE API Reference (Python)

```python
from cqe.receipts import merkle_leaf_hex
from cqe.diagonals import step, pose_step
from cqe.pragmatics import annotate
from cqe.source_diversity import evaluate
from cqe.golay import is_codeword, DEMO_H
```

- `pose_step(r,c,angle_rad,k_bias=0.0)` → next (r,c)
- `annotate(text)` → {'speech_act':..., 'hedge':bool, 'politeness':bool, 'sarcasm':bool}
- `evaluate(receipts, min_publishers=3, min_domains=3, require_pdf=False, require_disagreement=True)` → policy result
- `is_codeword(H, v)` → True/False (H is 12×24, v is 24-bit int list)
- `merkle_leaf_hex(obj)` → blake2b-256 hex
