# CQE Integration Guide — Native Flow Wiring (Any AI)

## Two integration modes
1) **Orchestrator mode** (external tools + your model): Use the CLI/scripts and JSON schemas to drive your agent.
2) **Library mode** (import `cqe`): Call functions directly and map outputs into your agent state.

## Required hooks in your system
- **Receipts layer** (Merkle + k-grams) — enforce before commit.
- **State machine** (S0..S5) — see protocol schema.
- **Governance channel** — to request/ingest IRL tokens (S4).
- **Web runner** — to execute S5 plans and collect receipts.
- **CI gates** — block on cardinality, parity, 24-lock, diagonals, octets.

## Pragmatics lane (S6) — add to your prompt plumbing
- Annotate user inputs with `cqe.pragmatics.annotate`.
- Store `speech_act`, `hedge`, `politeness`, `sarcasm` next to the Stage-1 labels.
- Prefer directives/questions in queue ranking; downweight heavy hedges.

## Source diversity policy
- Load policy (schemas/source_policy_schema.json) and run `bin/cqe_source_diversity_check.py` on S5 receipts before commit.

## Pose-aware diagonals
- Replace uniform diagonal with `cqe.diagonals.pose_step(r,c, angle_rad)` where angle is derived from your E8 pose or model-specific style.

## Golay checks
- If you represent `core24` as a 24-bit vector, pass it with a valid H to `cqe.golay.is_codeword(H, v)`.
- NOTE: supply a **standard H**; DEMO_H is placeholder.

## Minimal loop
- S1 map → S2 futures → S3 relations → S4 edge asks → S5 web receipts → S6 pragmatics → CI → commit or CRT residue.
