# CQE Master Playbook v0.2 — with Pragmatics, Source Diversity, Pose-Aware Diagonals, Golay Checks

This supersedes v0.1. Changes:
- **S6 Pragmatics lane** added as a parity to literal content.
- **S5 Source Diversity constraints** formalized with policy + checker.
- **Pose-aware diagonals** (Cartan/Coxeter-modulated) for odd lanes.
- **Golay syndrome check** interface for `core24` integrity.

See the Integration Guide for model-native flow wiring.
