# Sameness Matrix

| Property                     | Ice VII | Navigation |
|-----------------------------|:-------:|:----------:|
| Type-II ConA legality       |   YES   |    YES     |
| Palindromy P4,P8 within theta|  YES   |    YES     |
| Syndrome = 0                |   YES   |    YES     |
| 8-face gating (full latch)  |   YES   |  PENDING*  |
| Dyadic rest policy          |  SAME   |    SAME    |
| Threshold semantics (1/8,1/4)| SAME   |    SAME    |
| Ledger: commit once         |  SAME   |    SAME    |
| Replay via residues         |  SAME   |    SAME    |
| Anchors (frame,rest,coset)  |  SAME   |    SAME    |

*Pending = structural latchable; requires atm_density_known and dv_budget_known (pins) before cadence can advance.
