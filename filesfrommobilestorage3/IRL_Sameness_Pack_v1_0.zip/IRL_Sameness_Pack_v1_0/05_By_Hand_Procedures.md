# By-Hand Procedures (IRL)

Common skeleton (both cases)
1) Select smallest dyadic rest consistent with active 2-planes and flags.
2) Compute syndrome with the E8 H-matrix -> require zero.
3) Tally mod-4 and mod-8 histograms -> compute P4 and P8; require 0 under strict profile.
4) Apply primitive reductions that strictly decrease Phi=(wt(s),P8,P4,rho) until REST.
5) Run a face-only sweep; flip latch bit when face legally touched.
6) Advance cadence only when all 8 latch bits are 1; otherwise remain PROVISIONAL.

Case A (Ice VII)
- Confirm pins: pressure_gpa>=2.0 and temperature_c>=10.
- Expect OPEN; anchor (rest=8) with bounds_sig=11111111.

Case B (Navigation)
- Structural checks same as Ice; pins pending block advance.
- Remain PROVISIONAL-OPEN (NTER) until atm_density_known and dv_budget_known satisfied.
