# IRL Case B — Planetary Navigation (Entry/Descent/Landing)

Frame
- tau = 1/4 (driving), S promotes to 64 for route capacity
- Moduli M = {2,4,8,13,5,7,11}
- Faces = {navigation, octad, two_slice}

Pins (evidence)
- atm_density_known  [pending]
- dv_budget_known    [pending]

Witness results
- Structural legality: GREEN (Type-II, palindromy, syndrome)
- Gate: PROVISIONAL-OPEN (NTER); cadence does not advance until both pins satisfied

Dyadic rest
- R4 when two active 2-planes; promote to R8/64 based on flags and capacity
- Anchor reserved but not committed until pins flip to satisfied
