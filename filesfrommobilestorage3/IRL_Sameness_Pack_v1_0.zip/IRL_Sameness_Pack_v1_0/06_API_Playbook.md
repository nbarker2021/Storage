# API Playbook (IRL)

Ice VII
1) POST /frame {glyphs: [25,13,24,32]} -> frame_hash F_ice
2) POST /verify {frame:F_ice, x} -> REST (OPEN), witnesses GREEN
3) POST /commit {frame:F_ice} -> nf_hash, merkle_root
4) POST /store {frame:F_ice, nf} -> anchor_id (rest=8)

Navigation
1) POST /frame {glyphs: [25,13,5,7,11,32]} -> frame_hash F_nav
2) POST /verify {frame:F_nav, x} -> PROVISIONAL-OPEN (NTER), witnesses GREEN
3) POST /gate/scan ... -> latches as faces touched
4) POST /advance ... -> stays false until pins flip
5) POST /commit after pins satisfied -> anchor_id (rest per policy)
