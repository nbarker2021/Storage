# Sameness Charter (IRL)

Goal
Establish cross-domain sameness: different IRL tasks instantiate the same legality-first and dyadic-rest mechanics.

Core invariants (must match across cases)
- Type-II ConA legality: evenness + zero syndrome + unimodular/canonical coset
- Palindromy profile: P4<=theta4 and P8<=theta8 (strict by default)
- 8-face gating: latches trip on a full sweep; cadence advances only when all eight are set
- Dyadic rest selection: smallest rest consistent with 2-plane activity and flags
- Threshold semantics: 1/8 representation and 1/4 driving are fraction-of-current-scale (scale-free)
- Ledger policy: ledger many, commit once (NF-only materialization)
- Replay: residues (not poses) define identity and deterministic rehydration
- Anchors: (frame, rest_scale, coset) + bounds_sig encode identity; no text recall
