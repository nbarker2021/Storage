# IRL Sameness Pack v1.0
UTC: 2025-09-16T23:28:28Z

What this pack contains
- Canonical IRL cases (Ice Phase VII; Planetary Navigation) written in the legality-first/DRA formalism
- A "sameness" charter defining invariants and equivalences across domains
- A compact sameness matrix (which properties match across cases)
- By-hand procedures for both cases (witness latches, CRT checks, dyadic rest selection)
- API playbooks and machine-readable GAE/CEC examples
- IRL falsifiers and reporting format
