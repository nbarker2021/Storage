# IRL Case A — Ice Phase VII

Frame
- tau = 1/4 (driving), S starts at 8 (promotes to 64 if corridor fills)
- Moduli M = {2,4,8,13,24,32}
- Faces = {dense_solid, octad, E8_witnesses}

Pins (evidence)
- pressure_gpa >= 2.0  [satisfied]
- temperature_c >= 10  [satisfied]

Witness results
- Parity: GREEN
- Timing (13-arm): GREEN
- Palindromy: P4=0, P8=0
- Syndrome: 0 (Type-II passes)
- Gate: OPEN

Dyadic rest
- R8 default; R16 tightening on demand; R64 for CRT atlas views
- Anchor: (frame, rest=8, coset=canonical), bounds_sig=11111111

By hand
- Use the E8 H-matrix for syndrome=0; mod-4/8 tallies show P4=P8=0 after a few primitive moves if needed
- Latch the octad; all eight faces touched; cadence advances
