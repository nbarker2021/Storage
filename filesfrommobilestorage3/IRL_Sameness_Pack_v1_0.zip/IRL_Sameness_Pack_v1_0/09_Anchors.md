# Anchors (Identity Without Recall)

Format: (frame, rest_scale, coset) + bounds_sig (8 latch bits).

Ice VII (example)
- rest_scale=8, coset=canonical, bounds_sig=11111111 -> anchor_id=A_ice_demo

Navigation (example)
- rest_scale=4 or 8 per policy, reserved anchor until pins satisfied -> anchor_id=A_nav_demo (provisional)
