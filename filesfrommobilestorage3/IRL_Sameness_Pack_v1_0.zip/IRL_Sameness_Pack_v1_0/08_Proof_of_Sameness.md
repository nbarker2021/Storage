# Proof of Sameness (Sketch)

Both cases instantiate the same operator stack:
- Integerized state -> CRT residues -> Con-A evenness -> palindromy -> 8-face gating -> dyadic rest policy.
Legality invariants and thresholds are scale-free; Reduction commutes with U2 uplift up to canonical NF; ledger and anchor semantics are identical. Differences are captured as overlay deltas (pins/evidence), not as changes to legality.
