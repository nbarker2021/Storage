# IRL Falsifiers and Reporting

F1 Confluence: two legal step orders -> different NF hash (should not happen)
F2 Mirage-Type-II: REST but fails evenness/unimodularity
F3 Pal failure: REST with P4>0 or P8>0 under strict profile
F4 Invariance breach: truth changes under allowed morphisms of frame
F7 Gating completeness: cadence advances without all 8 latches set
F10 Threshold drift: 1/4 or 1/8 semantics change with depth

Report per case: legality-rate, confluence-hash, P4,P8, syndrome, time-to-REST, energy/commit, latch_sweeps_per_advance, pin status.
