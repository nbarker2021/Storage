
# CQE_PanelHarness_v0_1 (stdlib-only)

Produce the **one worked example** (actually several) the panel asked for.

## Run
```bash
cd CQE_PanelHarness_v0_1
python panel_harness.py
# -> artifacts/panel_report.json
```
It will also auto-record a manifest of your uploaded papers in `/mnt/data`.
