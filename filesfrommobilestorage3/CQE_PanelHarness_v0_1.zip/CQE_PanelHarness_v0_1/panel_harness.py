
import os, json, base64, time
from core.ledger import MasterLedger
from examples import rng_worked_example as RNG
from examples import lorenz_worked_example as LOR
from examples import lambda_worked_example as LMB
from examples import qec_worked_example as QEC
from examples import uq_perturb_runner as UQ
import ingest_auto
def run_all(project_root=None, out_name="panel_report.json"):
    project_root = project_root or os.getcwd()
    key_b64 = base64.b64encode(os.urandom(32)).decode("ascii")
    os.makedirs(os.path.join(project_root, "artifacts"), exist_ok=True)
    led = MasterLedger(os.path.join(project_root, "artifacts"), key_b64)
    led.append({"type":"panel_start","ts":time.time()})
    try: ingest_auto.run(led, scan_root="/mnt/data")
    except Exception as e: led.append({"type":"auto_ingest_error","err":str(e)})
    rep_rng = RNG.run(os.path.join(project_root, "artifacts"), key_b64, N=256)
    rep_lor = LOR.run(os.path.join(project_root, "artifacts"), key_b64, steps=600, dt=0.01)
    rep_lmb = LMB.run(os.path.join(project_root, "artifacts"), key_b64)
    rep_qec = QEC.run(os.path.join(project_root, "artifacts"), key_b64, trials=64, p_err=0.2)
    rep_uq = UQ.run(os.path.join(project_root, "artifacts"), key_b64, seeds=128, perturb=3)
    v = led.verify()
    report = {"panel_report":{"rng":rep_rng,"lorenz":rep_lor,"lambda":rep_lmb,"qec":rep_qec,"uq":rep_uq}, "ledger_verify":v}
    out_path = os.path.join(project_root, "artifacts", out_name)
    with open(out_path,"w",encoding="utf-8") as f: json.dump(report, f, indent=2)
    return out_path
if __name__ == "__main__":
    p = run_all(); print("wrote", p)
