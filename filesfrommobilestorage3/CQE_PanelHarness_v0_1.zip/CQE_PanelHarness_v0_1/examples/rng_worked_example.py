
import json
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
from core.geom_embed import embed_hash_to_8d, promote_8d_to_24d, quantize
from core.equivalence import EquivalenceIndex
from core.deltaE import DeltaETrace
def run(root, key_b64, N=256):
    led = MasterLedger(root, key_b64); sl = attach_sidecar(root)
    equiv = EquivalenceIndex(); tr = DeltaETrace()
    def compute_once(n):
        seed = str(n).encode(); v8 = embed_hash_to_8d(seed); v24 = promote_8d_to_24d(v8); q = quantize(v24, bins=32)
        return {"v8":v8,"v24":v24,"q":q}
    for n in range(N):
        payload = {"example":"rng","n":n}
        res, cost, rid = sl.compute(payload, scope="rng", channel=3, compute_fn=lambda: compute_once(n))
        hit = (cost["hits"]==1 and cost["cost"]==0.0)
        tr.add(cost["cost"], hit); equiv.add(rid, tuple(res["q"]))
        if n % 32 == 0:
            led.append({"type":"rng_step","n":n,"rid":rid,"hit":hit,"E":tr.total})
    report = {"example":"rng","N":N,"equivalence":equiv.summary(),"deltaE_tail": tr.to_series()[-10:]}
    led.append({"type":"rng_report","summary":report["equivalence"]}); return report
