
import random
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
from core.geom_embed import embed_hash_to_8d, promote_8d_to_24d, quantize
def run(root, key_b64, seeds=128, perturb=3):
    led = MasterLedger(root, key_b64); sl = attach_sidecar(root)
    def class_of(n):
        v8 = embed_hash_to_8d(str(n).encode()); v24 = promote_8d_to_24d(v8)
        return quantize(v24, bins=32)
    base = [class_of(i) for i in range(seeds)]
    kept = 0
    for i in range(seeds):
        n = i + random.randint(-perturb, perturb); c2 = class_of(n)
        if c2 == base[i]: kept += 1
    frac = kept / seeds; led.append({"type":"uq_result","seeds":seeds,"perturb":perturb,"kept_frac":frac})
    return {"example":"uq","kept_fraction":frac}
