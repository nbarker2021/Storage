
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
from core.geom_embed import quantize
class Term: pass
class Var(Term):
    def __init__(self, name): self.name=name
class Lam(Term):
    def __init__(self, x, body): self.x=x; self.body=body
class App(Term):
    def __init__(self, f, a): self.f=f; self.a=a
class Pair(Term):
    def __init__(self, a,b): self.a=a; self.b=b
class Fst(Term):
    def __init__(self, p): self.p=p
class Snd(Term):
    def __init__(self, p): self.p=p
def free_vars(t):
    if isinstance(t, Var): return {t.name}
    if isinstance(t, Lam): return free_vars(t.body)-{t.x}
    if isinstance(t, App): return free_vars(t.f)|free_vars(t.a)
    if isinstance(t, Pair): return free_vars(t.a)|free_vars(t.b)
    if isinstance(t, Fst): return free_vars(t.p)
    if isinstance(t, Snd): return free_vars(t.p)
    return set()
def subst(t, x, v):
    if isinstance(t, Var): return v if t.name==x else t
    if isinstance(t, Lam):
        if t.x==x: return t
        return Lam(t.x, subst(t.body,x,v))
    if isinstance(t, App): return App(subst(t.f,x,v), subst(t.a,x,v))
    if isinstance(t, Pair): return Pair(subst(t.a,x,v), subst(t.b,x,v))
    if isinstance(t, Fst): return Fst(subst(t.p,x,v))
    if isinstance(t, Snd): return Snd(subst(t.p,x,v))
    return t
def step(t):
    if isinstance(t, App) and isinstance(t.f, Lam): return subst(t.f.body, t.f.x, t.a), True, "beta"
    if isinstance(t, Fst) and isinstance(t.p, Pair): return t.p.a, True, "fst"
    if isinstance(t, Snd) and isinstance(t.p, Pair): return t.p.b, True, "snd"
    if isinstance(t, App):
        f2, did, rule = step(t.f)
        if did: return App(f2, t.a), True, rule
        a2, did, rule = step(t.a)
        if did: return App(t.f, a2), True, rule
    if isinstance(t, Fst):
        p2, did, rule = step(t.p); 
        if did: return Fst(p2), True, rule
    if isinstance(t, Snd):
        p2, did, rule = step(t.p); 
        if did: return Snd(p2), True, rule
    if isinstance(t, Pair):
        a2, da, _ = step(t.a); 
        if da: return Pair(a2, t.b), True, "pair-a"
        b2, db, _ = step(t.b); 
        if db: return Pair(t.a, b2), True, "pair-b"
    return t, False, None
def term_size(t):
    if isinstance(t, Var): return 1
    if isinstance(t, Lam): return 1+term_size(t.body)
    if isinstance(t, App): return 1+term_size(t.f)+term_size(t.a)
    if isinstance(t, Pair): return 1+term_size(t.a)+term_size(t.b)
    if isinstance(t, Fst) or isinstance(t, Snd): return 1+term_size(t.p)
    return 1
def denotation_vec8(t):
    counts = {"Var":0,"Lam":0,"App":0,"Pair":0,"Fst":0,"Snd":0,"Fv":0,"Size":0}
    def walk(x):
        if isinstance(x, Var): counts["Var"]+=1
        elif isinstance(x, Lam): counts["Lam"]+=1; walk(x.body)
        elif isinstance(x, App): counts["App"]+=1; walk(x.f); walk(x.a)
        elif isinstance(x, Pair): counts["Pair"]+=1; walk(x.a); walk(x.b)
        elif isinstance(x, Fst): counts["Fst"]+=1; walk(x.p)
        elif isinstance(x, Snd): counts["Snd"]+=1; walk(x.p)
    walk(t)
    counts["Fv"] = len(free_vars(t)); counts["Size"] = term_size(t)
    mx = max(1, max(counts.values()))
    v8 = [counts[k]/mx for k in ["Var","Lam","App","Pair","Fst","Snd","Fv","Size"]]
    return v8
def run(root, key_b64):
    from core.ledger import MasterLedger
    from core.speedlight_link import attach_sidecar
    led = MasterLedger(root, key_b64); sl = attach_sidecar(root)
    a, b = Var("a"), Var("b")
    term = App(Lam("p", Fst(Var("p"))), Pair(a,b))
    E_total = 0.0; steps = []; cur = term
    while True:
        payload = {"example":"lambda","term_size":term_size(cur)}
        def compute_once():
            v8 = denotation_vec8(cur)
            v24 = [min(0.999, (v8[i%8] + 0.07*(i//8))) for i in range(24)]
            q = quantize(v24, bins=32)
            return {"v8":v8,"v24":v24,"q":q}
        res, cost, rid = sl.compute(payload, scope="lambda", channel=9, compute_fn=compute_once)
        hit = (cost["hits"]==1 and cost["cost"]==0.0); E = cost["cost"] if not hit else cost["cost"]*0.1; E_total += E
        led.append({"type":"lambda_obs","rid":rid,"hit":hit,"E":E_total,"q":res["q"]})
        nxt, did, rule = step(cur); steps.append({"rule":rule,"E_total":E_total})
        if not did: break
        cur = nxt
    report = {"example":"lambda","steps":steps,"final_size":term_size(cur)}
    led.append({"type":"lambda_report","final_size":report["final_size"]}); return report
