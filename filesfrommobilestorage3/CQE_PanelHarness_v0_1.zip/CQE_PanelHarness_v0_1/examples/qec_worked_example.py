
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
def run(root, key_b64, trials=64, p_err=0.2):
    led = MasterLedger(root, key_b64); sl = attach_sidecar(root)
    def flip(p): import random; return 1 if random.random()<p else 0
    reuse = {}; E_total = 0.0
    for t in range(trials):
        a=b=c=0; a^=flip(p_err); b^=flip(p_err); c^=flip(p_err)
        s1 = a^b; s2 = b^c; syn = (s1,s2)
        payload = {"example":"qec","syn":syn}
        def compute_once():
            v8 = [0.0]*8; idx = syn[0]*2 + syn[1]; v8[idx] = 1.0
            v24 = [min(0.999, (v8[i%8] + 0.05*(i//8))) for i in range(24)]
            return {"syn":syn,"v8":v8,"v24":v24}
        res, cost, rid = sl.compute(payload, scope="qec", channel=3, compute_fn=compute_once)
        hit = (cost["hits"]==1 and cost["cost"]==0.0); E = cost["cost"] if not hit else cost["cost"]*0.1; E_total += E
        reuse[syn] = reuse.get(syn,0)+1; led.append({"type":"qec_trial","t":t,"syn":syn,"rid":rid,"E":E_total})
    common_syn = max(reuse.items(), key=lambda kv: kv[1])[0]
    led.append({"type":"qec_common_syndrome","syn":common_syn,"count":reuse[common_syn]})
    return {"example":"qec","trials":trials,"common_syndrome":common_syn,"reuse_counts":reuse}
