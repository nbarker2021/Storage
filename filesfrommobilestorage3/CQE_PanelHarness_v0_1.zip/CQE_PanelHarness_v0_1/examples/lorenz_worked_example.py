
from core.ledger import MasterLedger
from core.speedlight_link import attach_sidecar
from core.geom_embed import lorenz_step, embed_state_3d_to_8d, promote_8d_to_24d, quantize
from core.equivalence import EquivalenceIndex
from core.deltaE import DeltaETrace
def run(root, key_b64, steps=600, dt=0.01):
    led = MasterLedger(root, key_b64); sl = attach_sidecar(root)
    equiv = EquivalenceIndex(); tr = DeltaETrace()
    x,y,z = 1.0,1.0,1.0
    for i in range(steps):
        x,y,z = lorenz_step(x,y,z, dt=dt); t = i*dt
        payload = {"example":"lorenz","i":i}
        def compute_once():
            v8 = embed_state_3d_to_8d(x,y,z,t); v24 = promote_8d_to_24d(v8); q = quantize(v24, bins=32)
            return {"state":[x,y,z],"v8":v8,"v24":v24,"q":q}
        res, cost, rid = sl.compute(payload, scope="lorenz", channel=6, compute_fn=compute_once)
        hit = (cost["hits"]==1 and cost["cost"]==0.0); tr.add(cost["cost"], hit); equiv.add(rid, tuple(res["q"]))
        if i % 50 == 0: led.append({"type":"lorenz_step","i":i,"rid":rid,"hit":hit,"E":tr.total})
    report = {"example":"lorenz","steps":steps,"equivalence":equiv.summary(),"deltaE_tail": tr.to_series()[-10:]}
    led.append({"type":"lorenz_report","summary":report["equivalence"]}); return report
