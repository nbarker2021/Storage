
import os, json, time, hashlib, importlib.util, threading
class SimpleSidecar:
    def __init__(self): self.cache = {}; self.lock = threading.Lock()
    def compute(self, key_obj, scope="panel", channel=3, compute_fn=None):
        key = hashlib.sha256((scope+"|"+str(channel)+"|"+json.dumps(key_obj, sort_keys=True)).encode()).hexdigest()
        with self.lock:
            if key in self.cache:
                e = self.cache[key]
                return e["result"], {"hits":1,"misses":0,"cost":0.0}, e["rid"]
        t0 = time.time(); res = compute_fn() if compute_fn else None; dt = time.time()-t0
        rid = "R:"+key[:16]
        with self.lock: self.cache[key] = {"result":res,"rid":rid,"E":dt}
        return res, {"hits":0,"misses":1,"cost":dt}, rid
def load_speedlight_plus(path):
    try:
        spec = importlib.util.spec_from_file_location("speedlight_sidecar_plus", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        cls = getattr(mod, "SpeedLightPlus", None)
        if cls is None: return None
        return cls(mem_bytes=128_000_000, disk_dir=None, ledger_path=None)
    except Exception:
        return None
def attach_sidecar(project_root: str):
    plus = os.path.join(project_root, "speedlight_sidecar_plus.py")
    if os.path.exists(plus):
        sl = load_speedlight_plus(plus)
        if sl: return sl
    return SimpleSidecar()
