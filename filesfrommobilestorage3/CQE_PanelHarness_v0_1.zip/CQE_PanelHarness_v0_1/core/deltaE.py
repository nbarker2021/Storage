
class DeltaETrace:
    def __init__(self): self.steps = []; self.total = 0.0
    def add(self, cost: float, hit: bool):
        E = cost if not hit else cost*0.1
        self.total += E
        self.steps.append({"cost":cost, "hit":hit, "E":E, "cumulative": self.total})
    def to_series(self): return self.steps
