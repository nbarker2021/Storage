
from collections import defaultdict
class EquivalenceIndex:
    def __init__(self):
        self.counts = defaultdict(int); self.map = {}
    def add(self, rid, key):
        self.counts[key] += 1; self.map[rid] = key
    def summary(self):
        k = list(self.counts.items()); k.sort(key=lambda x: -x[1])
        return {"classes": len(self.counts), "top": k[:10]}
