# CQE Promotion Report (Uploaded Kits)

## CQE_Control_Plane_OneShot_v0_1_1
- files: 18 | text: 17
- signals: control
- fourbit: **0000** → **EXO**
- reasons: missing rails/octet markers, missing receipts metrics, missing fourbit mentions, missing ledger/Merkle/commit terms

## CQE_Framework_0_1_0
- files: 31 | text: 29
- signals: rails, receipts, fourbit, ledger, control, glyphs
- fourbit: **1111** → **DIGEST**

## CQE_Modular_Atomic_Pilot_v0_3
- files: 20 | text: 17
- signals: receipts, fourbit, ledger, control, glyphs
- fourbit: **0111** → **EXO**
- reasons: missing rails/octet markers

## CQE_Reference_Pack_20250919T025314Z
- files: 4 | text: 4
- signals: rails, receipts, fourbit, control
- fourbit: **1110** → **EXO**
- reasons: missing ledger/Merkle/commit terms

## CQE_Stack_Package
- files: 20 | text: 20
- signals: rails, receipts, fourbit, ledger, control, glyphs
- fourbit: **1111** → **DIGEST**

## cqe_field_kit
- files: 12 | text: 12
- signals: rails, receipts, fourbit, ledger, control, glyphs
- fourbit: **1111** → **DIGEST**

## cqe_forms_registry
- files: 5 | text: 5
- signals: rails, receipts, fourbit, control, glyphs
- fourbit: **1110** → **EXO**
- reasons: missing ledger/Merkle/commit terms

## cqe_golden_20250919T171400Z
- files: 23 | text: 22
- signals: rails, receipts, fourbit, control
- fourbit: **1110** → **EXO**
- reasons: missing ledger/Merkle/commit terms

## cqe_release_20250919T170735Z
- files: 43 | text: 42
- signals: rails, receipts, fourbit, ledger, control, glyphs
- fourbit: **1111** → **DIGEST**
