#!/usr/bin/env python3
import json, argparse, hashlib
from pathlib import Path

def sha(x:bytes)->str: return hashlib.sha256(x).hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", type=Path, required=True)
    args=ap.parse_args()
    entry = json.loads(args.inp.read_text())
    print("merkle_root:", sha(json.dumps(entry, sort_keys=True).encode()))
if __name__=="__main__":
    main()
