# Δ-Lift Plan — cqe_golden_20250919T171400Z
Current fourbit: **1110** → **EXO**
Reasons: missing ledger/Merkle/commit terms

## Minimal actions to promote to DIGEST (1111)
- [ ] **Rails**: Add a `rails.yaml` (or section) explicitly naming four painted rails and their thresholds.
- [ ] **Receipts**: Add a `receipts.schema.json` for this bundle + at least one `sample_receipts.json` run.
- [ ] **Fourbit**: Add an explicit `commit_bits` emission step (CLI/script snippet or human ritual page).
- [ ] **Ledger**: Append-only `ledger/` entry with before/after bits + reason codes.
- [ ] **EXO museum**: If promotion fails again, write a one-line EXO record with reason codes.

## Suggested rail template
rails:
  - name: rail_A
    metric: <define>
    threshold: <number>
  - name: rail_B
    metric: <define>
    threshold: <number>
  - name: rail_C
    metric: <define>
    threshold: <number>
  - name: rail_D
    metric: <define>
    threshold: <number>

## Receipt template (drop in `receipts/sample_receipts.json`)
{
  "bundle": "cqe_golden_20250919T171400Z",
  "commit_bits": "0000",
  "receipts": {
    "rail_A": {"metric": 0.0, "pass": false},
    "rail_B": {"metric": 0.0, "pass": false},
    "rail_C": {"metric": 0.0, "pass": false},
    "rail_D": {"metric": 0.0, "pass": false}
  },
  "exo_reason_codes": ["insufficient_views"]
}

## Ledger stub (append to `ledger/log.jsonl`)
{
  "timestamp": "<UTC>",
  "bundle": "cqe_golden_20250919T171400Z",
  "before_bits": "1110",
  "after_bits": "<post-run-bits>",
  "action": "PROMOTE_ATTEMPT",
  "reason": "<what changed>"
}
