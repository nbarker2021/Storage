# How-To: Real Datasets (WB/OC) — attach without drift
## WeatherBench/ERA5
- Fetch ERA5 reanalysis or WB2-specified variable slices (z500, t850, etc.).
- Preprocess to native grid; split regions (Tropics/Extra-tropics) and leads (6h/12h/24h).
- Run rails: MSE/RMSE, ACC, regional split, lead monotone; parity check RMSE≈√MSE.
## OpenCatalyst
- Pull one OC20 IS2RE example (structure + target energy; forces if available).
- Run rails: Energy monotonicity under safe step, force alignment, unit guards; mirror via reversible step.
- Expect EXO until true targets are used; surrogate is for plumbing only.
## Receipts
- Save per-rail JSON, then chain via `tools/cqe_chain.py` for composite commits.
