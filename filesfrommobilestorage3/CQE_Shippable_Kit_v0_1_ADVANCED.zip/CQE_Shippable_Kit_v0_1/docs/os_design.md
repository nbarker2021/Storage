# CQE OS Design (v0.1)
- Kernel: REST→VIEWS→MIRROR→Δ→STRICT→COMMIT
- Backplane: 64 sidecar slots (S0..S63), each a rail with budgets.
- Albums: Working (DIGEST), Non-working (EXO breadcrumbs).
- Ledger: append-only, per commit pack, Merkle rooted.
- Rotation: on fourbit collision, rotate view or promote bits (4→8).
- Governance: thresholds ratchet; Δ-lifts monotone; EXO is success.
