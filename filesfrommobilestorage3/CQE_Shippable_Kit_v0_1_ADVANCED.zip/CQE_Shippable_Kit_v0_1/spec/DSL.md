# CQE DSL v0.1 (stub)
Primitives: token, rail, view, receipt, commit, ledger.
