# Adapter stub for WeatherBench/ERA5
# Usage: python3 adapters/wb_adapter.py --path /data/era5 --var z500 --lead 24h --region tropics
import argparse, json, pathlib
if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--path', required=True)
    ap.add_argument('--var', default='z500')
    ap.add_argument('--lead', default='24h')
    ap.add_argument('--region', default='global')
    args = ap.parse_args()
    # TODO: load data files, compute MSE/RMSE/ACC, split by region/lead, parity RMSE≈sqrt(MSE)
    print(json.dumps({'status':'stub','var':args.var,'lead':args.lead,'region':args.region}))
