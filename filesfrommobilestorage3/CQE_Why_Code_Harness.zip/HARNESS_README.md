# CQE WHY Harness

This lightweight runner simulates the CQE loop (octet → mirror → Δ → strict → 4-bit receipts) across the 10 WHY exemplars.

## Files
- `cqe_why_harness.py` — CLI to run simulated passes, producing JSON receipts
- (Your WHY PDFs live in `../WHY_Papers`)

## Usage
```bash
python cqe_why_harness.py --dry-run
python cqe_why_harness.py --run WHY_01 WHY_03 WHY_10 --seed 2025
```

## Output
A JSON blob with one `Receipt` per requested doc:
```json
{
  "receipts": [
    {
      "sidecar": "WHY_01",
      "fourbit": "1110",
      "mirror_votes": "24/24",
      "view_votes": "56/64",
      "ope_debt": 0.015,
      "fce_debt": 0.018,
      "residues": {"hotzones": 1, "notes": "demo"},
      "page_hash": "d41d8cd98f00b204",
      "seed": 1338
    }
  ],
  "count": 1,
  "ts": 1690000000.0
}
```

## Notes
- This is a stub harness for demonstration. Swap the mock functions (`mirror_test`, `octet_views`, etc.) with your real evaluators.
- Keep 4‑bit minimal; promote to 8‑bit only when collisions are empirically detected.
