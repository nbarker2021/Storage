#!/usr/bin/env python3
# cqe_why_harness.py
# Minimal runner to exercise 10 WHY exemplars with the CQE loop.
# No external deps beyond Python stdlib.
#
# Usage:
#   python cqe_why_harness.py --dry-run
#   python cqe_why_harness.py --run WHY_01 WHY_03 WHY_10

import argparse, hashlib, json, random, time
from dataclasses import dataclass, asdict
from typing import List, Dict, Any

# ---------- Core data structures ----------

@dataclass
class Token:
    id: str
    quantity: str
    unit: str
    value: float
    guards: Dict[str, Any]

@dataclass
class DNA10:
    timing: str
    polarity: str
    scale: str
    pose: str
    domain: str
    conditioning: str
    units: str
    precision: str
    cost: str
    seed: int

@dataclass
class Receipt:
    sidecar: str
    fourbit: str
    mirror_votes: str
    view_votes: str
    ope_debt: float
    fce_debt: float
    residues: Dict[str, Any]
    page_hash: str
    seed: int

# ---------- Mock sidecar runners ----------

def mirror_test(payload: Dict[str, Any]) -> bool:
    # Simulate a mirror forward ∘ inverse agreement within tolerance
    rnd = random.Random(payload["seed"])
    residual = rnd.uniform(0.0, 0.02)  # pretend tolerance is 0.03
    return residual <= 0.03

def octet_views(payload: Dict[str, Any]) -> int:
    # Return number of views passed (<=8); simulate diversity
    rnd = random.Random(payload["seed"] + 17)
    return rnd.randint(5, 8)

def delta_lift(payload: Dict[str, Any]) -> Dict[str, Any]:
    # Simulate a local repair that reduces debt
    rnd = random.Random(payload["seed"] + 29)
    return {"changed": bool(rnd.getrandbits(1)), "note": "local tweak applied"}

def strict_ratchet(payload: Dict[str, Any]) -> Dict[str, Any]:
    # Tighten a bound if pass; keep a simple counter for demo
    return {"tightened": True}

def page_hash(doc_id: str, seed: int) -> str:
    h = hashlib.sha256(f"{doc_id}:{seed}".encode()).hexdigest()
    return h[:16]

def fourbit_code(mirror_ok: bool, views_passed: int) -> str:
    # Minimal mapping: 8+ states → 4-bit bucket; deterministic but simple
    base = (8 if mirror_ok else 0) + max(0, min(7, views_passed))
    return format(base % 16, "04b")

# ---------- WHY exemplars ----------

WHY_IDS = [f"WHY_{i:02d}" for i in range(1, 11)]

def run_one(doc_id: str, seed: int) -> Receipt:
    payload = {"doc_id": doc_id, "seed": seed}
    m_ok = mirror_test(payload)
    v_pass = octet_views(payload)
    _ = delta_lift(payload)
    _ = strict_ratchet(payload)
    code = fourbit_code(m_ok, v_pass)
    mv = f"{24 if m_ok else 18}/24"
    vv = f"{v_pass*8}/64"
    ope = max(0.0, 0.05 - 0.005 * v_pass)
    fce = max(0.0, 0.05 - 0.004 * v_pass)
    residues = {"hotzones": max(0, 8 - v_pass), "notes": "demo"}
    return Receipt(
        sidecar=doc_id,
        fourbit=code,
        mirror_votes=mv,
        view_votes=vv,
        ope_debt=round(ope, 3),
        fce_debt=round(fce, 3),
        residues=residues,
        page_hash=page_hash(doc_id, seed),
        seed=seed,
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", nargs="*", default=WHY_IDS, help="Which WHY_* to run")
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    random.seed(args.seed)

    rows = []
    for doc in args.run:
        rcpt = run_one(doc, seed=args.seed + int(doc.split("_")[1]))
        rows.append(asdict(rcpt))

    out = {"receipts": rows, "count": len(rows), "ts": time.time()}
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
