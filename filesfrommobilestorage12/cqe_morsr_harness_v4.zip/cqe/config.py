
TOL = {
  "eps_phi": 1e-6,
  "eps_w": 1e-8,
  "eps_Q": 1e-9,
  "eps_PHI": 1e-6,
  "eps_spec": 1e-7
}

# Operator acceptance weights
PHI_WEIGHTS = {
  "a": 1.0,    # Q
  "b": 1.0,    # lane syndrome
  "c": 0.1,    # global syndrome
  "d": 0.02,   # sparsity penalty
}

# Kissing penalty target fraction and weight
KISSING = {"tau": 1.0, "nu": 0.1, "tol": 0.02}

# Lane permutations whitelist (IDs -> permutations of 0..7)
LANE_PERMS = {
    0: [0,1,2,3,4,5,6,7],
    1: [1,2,3,4,5,6,7,0],
    2: [0,2,1,3,4,5,6,7],
    3: [0,1,3,2,4,5,6,7],
    4: [7,6,5,4,3,2,1,0],
    5: [0,3,1,2,4,7,5,6],
    6: [2,1,0,3,6,5,4,7],
    7: [0,1,2,4,3,5,6,7]
}
