
import json, re
from typing import List
from .overlay import EO
from .canonicalize import canonicalize
from .operators import op_Rtheta, op_Midpoint, op_ParityMirror, op_WeylReflect

TOKEN_SPEC = {
  "S": ("single", None),
  "M": ("midpoint", None),
  "P": ("parity", None),
  "R": ("rtheta", "k"),   # R3 means step=3
  "W": ("weyl", "j")      # W0 means simple_idx=0
}

def parse_ops(script: str):
    # tokens like "R3 M W0 P"
    toks = re.findall(r"[A-Za-z][0-9]*", script)
    ops = []
    for t in toks:
        op = t[0].upper()
        arg = t[1:]
        if op not in TOKEN_SPEC: continue
        kind, param = TOKEN_SPEC[op]
        if kind=="rtheta":
            k = int(arg) if arg else 1
            ops.append(("Rtheta", {"step": k}))
        elif kind=="weyl":
            j = int(arg) if arg else 0
            ops.append(("Weyl", {"simple_idx": j}))
        elif kind=="midpoint":
            ops.append(("Midpoint", {}))
        elif kind=="parity":
            ops.append(("Parity", {}))
        elif kind=="single":
            ops.append(("Single", {}))
    return ops

def run_ops(eo: EO, script: str, monotone: bool = True):
    ops = parse_ops(script)
    trace = []
    for name, params in ops:
        phi_before = eo.compute_PHI()
        if name=="Rtheta":
            op_Rtheta(eo, **params)
        elif name=="Weyl":
            op_WeylReflect(eo, **params)
        elif name=="Midpoint":
            op_Midpoint(eo)
        elif name=="Parity":
            op_ParityMirror(eo)
        elif name=="Single":
            pass
        eo.update_invariants()
        phi_after = eo.compute_PHI()
        if monotone and phi_after > phi_before:
            # rollback by ignoring effect; in a full engine we'd copy/restore
            # here we just record a rejection
            trace.append({"op":name, "accepted": False, "phi_before":phi_before, "phi_after":phi_after})
        else:
            trace.append({"op":name, "accepted": True, "phi_before":phi_before, "phi_after":phi_after})
    return trace
