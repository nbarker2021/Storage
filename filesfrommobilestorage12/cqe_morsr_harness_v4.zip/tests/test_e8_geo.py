
from cqe.geo.e8_geo import R, ADJ, DEGS, reflect_root_index, SIMPLE

def test_degrees_regular_56():
    assert len(R)==240
    assert min(DEGS)==56 and max(DEGS)==56

def test_reflection_maps_into_roots():
    # reflect a handful of indices by a simple root; must remain in [0,239]
    for i in [0, 5, 17, 123, 239]:
        j = reflect_root_index(i, 0)
        assert 0 <= j < 240
