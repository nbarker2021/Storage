
import zipfile, shutil, json, os, re, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/"src"
SNAPDIR = ROOT/"substrate"/"snaprag"
SRC.mkdir(parents=True, exist_ok=True); SNAPDIR.mkdir(parents=True, exist_ok=True)

def sha256p(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""): h.update(chunk)
    return h.hexdigest()

def extract_all_from_mnt_data():
    data = Path("/mnt/data")
    zips = list(data.glob("*.zip"))
    for z in zips:
        with zipfile.ZipFile(z) as zf:
            target = SRC / z.stem
            target.mkdir(parents=True, exist_ok=True)
            zf.extractall(target)
    for p in data.iterdir():
        if p.suffix in {".py",".md",".json",".pdf"}:
            shutil.copy2(p, SRC / p.name)

def build_snap_cards():
    cards = []
    for p in SRC.rglob("*"):
        if p.is_file():
            kind = "code" if p.suffix==".py" else "doc" if p.suffix in {".md",".pdf"} else "data"
            cards.append({"name": p.name, "path": str(p.relative_to(SRC)), "kind": kind, "size": p.stat().st_size, "sha256": sha256p(p), "families": ["SNAPCorpus","SNAP"+kind.capitalize()]})
    (SNAPDIR/"snap_cards.jsonl").write_text("\n".join(json.dumps(c) for c in cards))

def build_rag_index():
    entries = []
    for p in SRC.rglob("*"):
        if p.is_file():
            toks = re.split(r"[^A-Za-z0-9]+", p.stem)
            entries.append({"name": p.name, "path": str(p.relative_to(SRC)), "tokens": [t for t in toks if t]})
    (SNAPDIR/"rag_index.json").write_text(json.dumps({"entries": entries}, indent=2))

if __name__ == "__main__":
    extract_all_from_mnt_data()
    from tools.registry.build_registry import discover_tools
    reg = discover_tools()
    REG_JSON = ROOT / "tools/registry/registry.json"
    REG_JSON.write_text(json.dumps(reg, indent=2))
    build_snap_cards()
    build_rag_index()
    print(f"Ingest complete. Found {len(reg)} tool candidates. SNAP/RAG built under {SNAPDIR}.")
