
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, Tuple

class Tool(Protocol):
    name: str
    def call(self, **kwargs) -> Dict[str, Any]: ...

class GUI(Protocol):
    def click(self, xy: Tuple[int,int]): ...
    def type(self, text: str): ...

class MagicProbe(Protocol):
    def measure(self, state: Dict[str,Any]) -> Dict[str, float]: ...

class IdentityProjector(Protocol):
    def lock(self, before: Dict[str,Any], after: Dict[str,Any], eps: float) -> bool: ...

class DeltaPhiMeter(Protocol):
    def sectors(self, before: Dict[str,Any], after: Dict[str,Any]) -> Dict[str, float]: ...

@dataclass
class ToolRegistry:
    tools: Dict[str, Tool]
    def has(self, name: str) -> bool: return name in self.tools
    def call(self, name: str, **kwargs): return self.tools[name].call(**kwargs)

@dataclass
class Receipt:
    op: str
    args: Dict[str, Any]
    delta_phi: Dict[str, float]
    idf_equal: bool
    magic: Dict[str, float]
    outcome: str
    anchors: Dict[str, str]

@dataclass
class AletheiaSidecar:
    tools: ToolRegistry
    gui: Optional[GUI]
    projector: IdentityProjector
    meter: DeltaPhiMeter
    magic: MagicProbe
    eps: float = 1e-5

    def scene8(self, goal: str, context: Dict[str,Any]) -> Dict[str,Any]:
        return {"goal": goal, "ctx": context, "state": {}}

    def choose_action(self, scene: Dict[str,Any]) -> Tuple[str, Dict[str,Any], str]:
        if self.tools.has("demo.echo"):
            return ("tool", {"msg": f"[goal={scene['goal']}]"}, "demo.echo")
        return ("tool", {"a":1, "b":2}, "math.add")

    def act_once(self, scene: Dict[str,Any]) -> Receipt:
        before = dict(scene)
        mode, args, op = self.choose_action(scene)
        if mode == "tool":
            out = self.tools.call(op, **args)
            scene["state"].update(out or {})
        after = dict(scene)
        idf_ok = self.projector.lock(before, after, self.eps)
        phi = self.meter.sectors(before, after)
        magic = self.magic.measure(after)
        outcome = "commit" if (idf_ok and phi["total"] <= 0.0) else "repair" if phi["total"] <= 0.0 else "refuse"
        return Receipt(op=op, args=args, delta_phi=phi, idf_equal=idf_ok, magic=magic, outcome=outcome, anchors={"fwd":"...", "mir":"..."} )

    def run_turn(self, goal: str, context: Dict[str,Any]) -> List[Receipt]:
        scene = self.scene8(goal, context)
        receipts: List[Receipt] = []
        for _ in range(context.get("max_steps", 4)):
            r = self.act_once(scene)
            receipts.append(r)
            if r.outcome == "refuse": break
        return receipts
