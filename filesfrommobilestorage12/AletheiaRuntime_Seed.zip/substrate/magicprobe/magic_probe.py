
from typing import Dict, Any
class SimpleMagic:
    def measure(self, state: Dict[str,Any]) -> Dict[str,float]:
        sz = len(state.get("state",{}))
        im = float(min(1.0, sz/10.0))
        status = 0 if im < 0.33 else 1 if im < 0.66 else 2
        return {"I_M": im, "status": status}
