
from typing import Dict, Any
class SimpleProjector:
    def __init__(self, tol: float=1e-5): self.tol = tol
    def lock(self, before: Dict[str,Any], after: Dict[str,Any], eps: float) -> bool:
        return before.get("goal","") == after.get("goal","")
