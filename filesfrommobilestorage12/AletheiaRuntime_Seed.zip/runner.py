
import json, argparse
from pathlib import Path
from substrate.aletheia_sidecar import AletheiaSidecar, ToolRegistry
from substrate.governance.idf_projector import SimpleProjector
from substrate.governance.delta_phi import SimpleNSL
from substrate.magicprobe.magic_probe import SimpleMagic
from tools.registry.runtime_registry import RuntimeToolRegistry

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--goal", default="Smoke test")
    ap.add_argument("--steps", type=int, default=4)
    args = ap.parse_args()
    rt = RuntimeToolRegistry()
    sc = AletheiaSidecar(
        tools=ToolRegistry(rt.tools),
        gui=None,
        projector=SimpleProjector(),
        meter=SimpleNSL(),
        magic=SimpleMagic(),
        eps=1e-5
    )
    receipts = sc.run_turn(goal=args.goal, context={"max_steps": args.steps})
    outdir = Path("substrate/receipts"); outdir.mkdir(parents=True, exist_ok=True)
    with (outdir/"receipts.jsonl").open("w") as f:
        for r in receipts: f.write(json.dumps(r.__dict__) + "\n")
    print(f"Wrote {len(receipts)} receipts to {outdir/'receipts.jsonl'}")

if __name__ == "__main__":
    main()
