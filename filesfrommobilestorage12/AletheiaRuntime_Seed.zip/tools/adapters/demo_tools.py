
from typing import Dict, Any
class EchoTool:
    name = "demo.echo"
    def call(self, **kwargs) -> Dict[str,Any]:
        return {"echo": kwargs}
class AddTool:
    name = "math.add"
    def call(self, **kwargs) -> Dict[str,Any]:
        a = float(kwargs.get("a",0)); b = float(kwargs.get("b",0))
        return {"sum": a+b}
