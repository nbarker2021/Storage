
import json, argparse
from .overlay import EO
from .canonicalize import canonicalize
from .morsr import pulse

def cmd_mint_seed(args):
    eo = EO()
    # simple A2 seed: activate three indices (0,1,2 for harness)
    eo.present[0]=eo.present[1]=eo.present[2]=True
    eo.w[0]=eo.w[1]=eo.w[2]=0.7
    eo.phi[0]=0.0; eo.phi[1]=1.5708; eo.phi[2]=3.1416
    eo.update_invariants()
    j = canonicalize(eo.to_json())
    eo.canon = j["canon"]
    with open(args.out, "w") as f:
        json.dump(j, f, indent=2)
    print("Minted seed overlay ->", args.out)

def cmd_morsr(args):
    with open(args.seed, "r") as f:
        seed_json = json.load(f)
    # build EO from json (minimal)
    nodes = seed_json["nodes"]
    present_b64 = nodes["present"]
    bits = list(reversed([int(b) for byte in list(__import__('base64').b64decode(present_b64)) for b in [(byte>>7)&1, (byte>>6)&1, (byte>>5)&1, (byte>>4)&1, (byte>>3)&1, (byte>>2)&1, (byte>>1)&1, byte&1]]))[:248]
    eo = EO()
    eo.present = [bool(b) for b in bits]
    eo.w = [float(x or 0.0) for x in nodes["w"]]
    eo.phi = [x if x is None else float(x) for x in nodes["phi"]]
    eo.pose = seed_json.get("pose", eo.pose)
    eo.update_invariants()
    result = pulse(eo, max_rings=2)
    with open(args.region_out, "w") as f:
        json.dump(result["region"], f, indent=2)
    with open(args.handshakes_out, "w") as f:
        for h in result["handshakes"]:
            f.write(json.dumps(h)+"\n")
    print("MORSR complete. Region ->", args.region_out, "Handshakes ->", args.handshakes_out)

def main():
    ap = argparse.ArgumentParser(prog="cqe")
    sub = ap.add_subparsers(dest="cmd", required=True)
    m1 = sub.add_parser("mint-seed")
    m1.add_argument("--out", default="seed_overlay.json")
    m1.set_defaults(func=cmd_mint_seed)
    m2 = sub.add_parser("morsr")
    m2.add_argument("--seed", required=True)
    m2.add_argument("--region-out", default="region.json")
    m2.add_argument("--handshakes-out", default="handshakes.jsonl")
    m2.set_defaults(func=cmd_morsr)
    args = ap.parse_args()
    args.func(args)

if __name__=="__main__":
    main()
