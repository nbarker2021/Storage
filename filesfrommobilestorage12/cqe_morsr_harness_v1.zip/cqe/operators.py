
import math
from typing import Dict, Any
from .overlay import EO

def op_Rtheta(eo: EO, step: int = 1) -> EO:
    # Advance coxeter_k and rotate any defined phases by small rational step
    k = (eo.pose.get("coxeter_k",0) + step) % 30
    eo.pose["coxeter_k"]=k
    for i,phi in enumerate(eo.phi):
        if phi is not None:
            eo.phi[i] = phi + (math.pi/2) * (step/15.0)
    return eo

def op_Midpoint(eo: EO) -> EO:
    # Toy midpoint: flip a few low-weight inactive nodes on to reduce parity syndromes
    from .overlay import lane_bits_from_overlay, syndrome_lane
    lane = lane_bits_from_overlay(eo.present)
    synd = syndrome_lane(lane)
    # turn on up to 3 nodes in lanes that cause syndrome bits to drop (toy heuristic)
    flips = 0
    for lane_idx, s in enumerate(synd):
        if s!=0 and flips<3:
            # find first inactive node with this lane index
            for i,b in enumerate(eo.present):
                if not b and i%8==lane_idx:
                    eo.present[i]=True; eo.w[i]=0.5; eo.phi[i]=0.0
                    flips += 1; break
    return eo

def op_ParityMirror(eo: EO) -> EO:
    # No-op for harness except toggling a mirror flag in pose
    eo.pose["diag_auto_id"] = 1 - int(eo.pose.get("diag_auto_id",0))
    return eo

def op_SingleInsert(eo: EO, idx: int, weight: float = 0.7, phi: float = 0.0) -> EO:
    if 0<=idx<248 and not eo.present[idx]:
        eo.present[idx]=True; eo.w[idx]=weight; eo.phi[idx]=phi
    return eo
