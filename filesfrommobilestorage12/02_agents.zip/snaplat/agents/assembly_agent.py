from typing import List, Dict, Any
from ..core.assembly import stitch, replay_ok

def stitch_best(points: List[List[float]], weights: List[float], sources: List[str]) -> Dict[str, Any]:
    out = stitch(points, weights, sources)
    out["replay_ok"] = replay_ok(out["dna"], points, weights)
    return out
