from typing import Dict, Any, List
from ..core.dtt import boundary_walk, evidence_yield

def run_boundary_tests(pairs: List[Dict[str, Any]], steps=8) -> Dict[str, Any]:
    cases = []; hits = []
    for p in pairs:
        x0 = p["a"]; x1 = p["b"]
        path = boundary_walk(x0, x1, steps=steps)
        cases.extend(path)
        # Dummy hit: edge if sign changes on first coord
        sign = [1 if v[0]>=0 else -1 for v in path]
        hits.append(1 if min(sign) < 0 and max(sign) > 0 else 0)
    return {"yield": evidence_yield(list(range(len(cases))), hits)}
