1) Ingest → 2) Train → 3) Eval → 4) Serve → 5) Ops
