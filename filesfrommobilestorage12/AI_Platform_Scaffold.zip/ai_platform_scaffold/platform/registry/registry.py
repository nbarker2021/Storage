print('registry stub')
