print('training stub')
