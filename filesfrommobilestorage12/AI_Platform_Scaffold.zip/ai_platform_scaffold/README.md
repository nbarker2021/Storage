# AI Platform Scaffold

SIM-first work order baked in. See docs/SIM_LANE_PLAN.md.
