
# CQE Extension Pack (v1)
Adds three production-meaningful modules to the CQE harness:
- **GlyphRegistry**: observed label > assumed label with provenance and chainable receipts.
- **CollisionMonitor**: 4-bit commit collision stats + simple silhouette-like separability.
- **CorridorPruner**: budgeted beam-search pruner using posterior × novelty × residual-gain.

## Quickstart
```bash
python -m harness.run_extension
python -m pytest -q
```
Artifacts are written to `harness/out_ext/`.
