
from dataclasses import dataclass, field
from typing import Dict, Optional, List, Tuple
import hashlib, json, time

@dataclass
class GlyphEvent:
    token_id: str
    assumed: Optional[str]
    observed: Optional[str]
    reason: str
    t: float

@dataclass
class GlyphRegistry:
    """Observed label always trumps assumed label — with provenance.
    - assumed_map: initial dictionary token_id -> label
    - observed_map: runtime overrides token_id -> label
    - history: append-only event log
    - policy: 'observed_over_assumed' (default); can be extended later
    """
    assumed_map: Dict[str,str] = field(default_factory=dict)
    observed_map: Dict[str,str] = field(default_factory=dict)
    history: List[GlyphEvent] = field(default_factory=list)
    policy: str = "observed_over_assumed"

    def assume(self, token_id: str, label: str, reason: str = "init"):
        old = self.assumed_map.get(token_id)
        self.assumed_map[token_id] = label
        self.history.append(GlyphEvent(token_id, old, label, f"assume:{reason}", time.time()))

    def observe(self, token_id: str, label: str, reason: str = "observation"):
        old = self.observed_map.get(token_id)
        self.observed_map[token_id] = label
        self.history.append(GlyphEvent(token_id, old, label, f"observe:{reason}", time.time()))

    def label_of(self, token_id: str) -> Optional[str]:
        if self.policy == "observed_over_assumed":
            return self.observed_map.get(token_id, self.assumed_map.get(token_id))
        return self.assumed_map.get(token_id)

    def snapshot(self) -> Dict[str,str]:
        keys = set(self.assumed_map) | set(self.observed_map)
        return {k: self.label_of(k) for k in sorted(keys)}

    def receipts(self) -> Dict[str,str]:
        """Return a compact, stable receipt: SHA256 of the canonical mapping json."""
        payload = json.dumps(self.snapshot(), sort_keys=True, ensure_ascii=False)
        return {
            "count": str(len(self.snapshot())),
            "hash": hashlib.sha256(payload.encode("utf-8")).hexdigest()
        }

    def overrides(self) -> List[Tuple[str,str,str]]:
        out = []
        for k,v in self.observed_map.items():
            base = self.assumed_map.get(k)
            if base != v:
                out.append((k, base, v))
        return out
