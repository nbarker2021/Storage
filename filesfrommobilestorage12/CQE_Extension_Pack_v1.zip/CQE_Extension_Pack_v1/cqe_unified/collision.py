
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Iterable
import hashlib, math, statistics, random

def _det_hash(s: str) -> int:
    return int(hashlib.sha256(s.encode("utf-8")).hexdigest(), 16)

@dataclass
class Commit4:
    """4-bit commit derived from a label string.
    This is a simple, deterministic stand-in:
      - compute sha256(label)
      - take lower 4 bits as the commit code (0..15)
      - we also return a 4-char string of bits (e.g., '1011')
    """
    @staticmethod
    def code(label: str) -> int:
        return _det_hash(label) & 0xF

    @staticmethod
    def bits(label: str) -> str:
        return format(Commit4.code(label), "04b")

@dataclass
class CollisionStats:
    total: int
    unique_codes: int
    collisions: int
    collision_rate: float
    histogram: Dict[int,int]

@dataclass
class CollisionMonitor:
    """Monitor 4-bit commit collisions across a set of labels.
    Provides a histogram and a basic collision rate.
    """
    labels: List[str]

    def histogram(self) -> Dict[int,int]:
        hist: Dict[int,int] = {}
        for lb in self.labels:
            c = Commit4.code(lb)
            hist[c] = hist.get(c, 0) + 1
        return hist

    def stats(self) -> CollisionStats:
        hist = self.histogram()
        total = len(self.labels)
        unique_codes = sum(1 for k,v in hist.items() if v > 0)
        collisions = total - unique_codes
        rate = collisions / max(1,total)
        return CollisionStats(total, unique_codes, collisions, rate, hist)

    @staticmethod
    def hamming(a: str, b: str) -> int:
        return sum(ch1 != ch2 for ch1, ch2 in zip(a,b))

    def silhouette_like(self) -> float:
        """A crude 'silhouette' proxy using Hamming distance between 4-bit strings.
        We treat each code bucket as a cluster; for each item we compute
        a = avg intra-cluster distance (0 because identical code gives bits identical)
        b = min avg distance to any other cluster (over 16 codes)
        silhouette ~ (b - a)/max(b,a) -> here simplifies to 1 if there exists another code.
        If only one code exists, return 0.
        """
        hist = self.histogram()
        if len(hist) <= 1:
            return 0.0
        # avg distance between different codes in 4-bit space
        codes = list(hist.keys())
        # average pairwise hamming between cluster representatives
        total_pairs = 0
        dist_sum = 0
        for i in range(len(codes)):
            for j in range(i+1,len(codes)):
                ca = format(codes[i], "04b")
                cb = format(codes[j], "04b")
                d = self.hamming(ca, cb)
                dist_sum += d
                total_pairs += 1
        if total_pairs == 0:
            return 0.0
        return dist_sum/total_pairs/4.0  # normalize by 4 (bit-length)
