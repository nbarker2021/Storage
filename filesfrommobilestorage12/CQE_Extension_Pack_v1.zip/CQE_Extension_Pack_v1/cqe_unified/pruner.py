
from dataclasses import dataclass, field
from typing import List, Callable, Optional
import math, random

@dataclass
class Candidate:
    id: str
    posterior: float         # probability mass or score in [0,1]
    novelty: float           # novelty score in [0,1]
    residual_gain: float     # expected improvement of residual (0..1)

    def merit(self, alpha=1.0, beta=1.0, gamma=1.0) -> float:
        # Weighted geometric-mean inspired merit (avoid biasing high single term)
        return (self.posterior**alpha) * (self.novelty**beta) * (self.residual_gain**gamma)

@dataclass
class CorridorPruner:
    beam: int = 8
    alpha: float = 1.0
    beta: float = 1.0
    gamma: float = 1.0
    budget: int = 64

    def select(self, candidates: List[Candidate]) -> List[Candidate]:
        ranked = sorted(candidates, key=lambda c: c.merit(self.alpha, self.beta, self.gamma), reverse=True)
        return ranked[:self.beam]

    def run(self, seed_candidates: List[Candidate], expand: Callable[[Candidate], List[Candidate]]) -> List[Candidate]:
        # Simple beam search with fixed expansion depth determined by budget // beam
        beam = self.select(seed_candidates)
        steps = max(1, self.budget // max(1,self.beam) - 1)
        for _ in range(steps):
            pool: List[Candidate] = []
            for c in beam:
                pool.extend(expand(c))
            beam = self.select(pool + beam)  # keep incumbents
        return beam
