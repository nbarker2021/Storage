
import json
from pathlib import Path
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
from harness.run_extension import run_registry_and_collisions, run_pruner

def test_observed_overrides_reduce_collision():
    rep = run_registry_and_collisions()
    # We expect more unique codes after observed overrides (or equal in worst case)
    assert rep["collision_after_observed"]["unique_codes"] >= rep["collision_baseline"]["unique_codes"]

def test_pruner_outputs_beam_results():
    rep = run_pruner()
    assert len(rep["winners"]) == rep["beam"]
    # values are within [0,1]
    for w in rep["winners"]:
        for k in ("posterior","novelty","residual_gain"):
            assert 0.0 <= w[k] <= 1.0
