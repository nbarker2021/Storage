
# Worksheet: Glyph Registry (Observed > Assumed)

**Goal**: Practice how observed labels override assumed ones and why this reduces 4-bit commit collisions.

1. Load `harness/run_extension.py` and run `run_registry_and_collisions()`.
2. Inspect `harness/out_ext/glyph_collision_report.json`.
3. Note:
   - `overrides_count` indicates how many tokens adopted observed labels.
   - Collision rate should go down or unique codes go up.
4. Record the receipt hash alongside the snapshot count.
