
import json, random, hashlib, os, sys
from pathlib import Path
from typing import List

# ensure package root on path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from cqe_unified.glyphs import GlyphRegistry
from cqe_unified.collision import CollisionMonitor, Commit4
from cqe_unified.pruner import CorridorPruner, Candidate

random.seed(1234)

OUT = Path(__file__).resolve().parent / "out_ext"
OUT.mkdir(exist_ok=True, parents=True)

def make_tokens(n=200):
    tokens = [f"t{i:03d}" for i in range(n)]
    classes = ["ALPHA","BETA","GAMMA","DELTA"]
    assumed = {t: f"{random.choice(classes)}_{(i%16)}" for i,t in enumerate(tokens)}
    return tokens, assumed

def inject_observations(reg: GlyphRegistry, tokens: List[str], p=0.25):
    for t in tokens:
        if random.random() < p:
            salt = random.randint(0, 10_000)
            new_label = f"OBS_{salt}_{t}"
            reg.observe(t, new_label, reason="measurement")

def run_registry_and_collisions():
    tokens, assumed = make_tokens(256)
    reg = GlyphRegistry()
    for t, lbl in assumed.items():
        reg.assume(t, lbl)

    labels0 = [reg.label_of(t) for t in tokens]
    cm0 = CollisionMonitor(labels0)
    stats0 = cm0.stats()

    inject_observations(reg, tokens, p=0.35)

    labels1 = [reg.label_of(t) for t in tokens]
    cm1 = CollisionMonitor(labels1)
    stats1 = cm1.stats()

    report = {
        "registry_receipts": reg.receipts(),
        "overrides_count": len(reg.overrides()),
        "collision_baseline": {
            "total": stats0.total,
            "unique_codes": stats0.unique_codes,
            "collisions": stats0.collisions,
            "collision_rate": stats0.collision_rate,
            "silhouette_like": cm0.silhouette_like()
        },
        "collision_after_observed": {
            "total": stats1.total,
            "unique_codes": stats1.unique_codes,
            "collisions": stats1.collisions,
            "collision_rate": stats1.collision_rate,
            "silhouette_like": cm1.silhouette_like()
        }
    }
    (OUT / "glyph_collision_report.json").write_text(json.dumps(report, indent=2))
    return report

def expand_candidate(c: Candidate) -> List[Candidate]:
    def clamp(x): return max(0.0, min(1.0, x))
    out = []
    for i in range(3):
        post = clamp(c.posterior + random.uniform(-0.05, 0.05))
        nov  = clamp(c.novelty + random.uniform(-0.1, 0.1))
        res  = clamp(c.residual_gain + random.uniform(-0.07, 0.07))
        out.append(Candidate(id=f"{c.id}.{i}", posterior=post, novelty=nov, residual_gain=res))
    return out

def run_pruner():
    seeds = [Candidate(id=f"S{i}", posterior=random.random(), novelty=random.random(), residual_gain=random.random()) for i in range(32)]
    pruner = CorridorPruner(beam=8, alpha=1.0, beta=1.0, gamma=1.0, budget=64)
    winners = pruner.run(seeds, expand_candidate)
    payload = {
        "beam": pruner.beam,
        "budget": pruner.budget,
        "winners": [
            {"id": w.id, "posterior": round(w.posterior,3), "novelty": round(w.novelty,3), "residual_gain": round(w.residual_gain,3), "merit": round(w.merit(), 5)}
            for w in winners
        ]
    }
    (OUT / "pruner_report.json").write_text(json.dumps(payload, indent=2))
    return payload

def main():
    rep1 = run_registry_and_collisions()
    rep2 = run_pruner()
    import hashlib, json
    digest = hashlib.sha256(json.dumps({"glyph":rep1, "pruner":rep2}, sort_keys=True).encode()).hexdigest()
    (OUT / "combined_receipt.txt").write_text(digest)
    print("OK: wrote reports to", OUT)

if __name__ == "__main__":
    main()
