
from cqe.overlay import EO
from cqe.operators import op_WeylReflect

def test_weyl_reflect_runs_and_preserves_cardinality():
    eo = EO()
    # activate a few roots in 0..239
    for i in [0, 10, 50]:
        eo.present[i]=True; eo.w[i]=0.5; eo.phi[i]=0.0
    before = sum(1 for b in eo.present if b)
    op_WeylReflect(eo, simple_idx=0)
    after = sum(1 for b in eo.present if b)
    assert before == after
