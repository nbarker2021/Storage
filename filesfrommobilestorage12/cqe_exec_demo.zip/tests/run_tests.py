
import sys, os, math, json, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / "src"))
from cqe_finance import BSParams, call_price, put_price, parity_residual

def run():
    t0 = time.time()
    p = BSParams(S=100.0, K=100.0, r=0.05, sigma=0.2, T=1.0)
    c = call_price(p); put = put_price(p); resid = parity_residual(p)
    assert abs(c - 10.4506) < 1e-3, f"call price off: {c}"
    assert abs(put - 5.5735) < 1e-3, f"put price off: {put}"
    assert abs(resid) < 1e-12, f"parity residual too large: {resid}"
    p2 = BSParams(S=50, K=50, r=0.01, sigma=1e-14, T=1e-14)
    c2 = call_price(p2); put2 = put_price(p2)
    assert math.isfinite(c2) and math.isfinite(put2), "non-finite price with tiny sigma/T"
    assert abs(parity_residual(p2)) < 1e-10, "parity failed in tiny regime"
    t1 = time.time()
    return {"status":"pass","elapsed_s": round(t1-t0,6),"cases":2}
if __name__ == "__main__":
    print(json.dumps(run()))
