# CQE Execution Demo (Finance Parity)
This bundle demonstrates a full CQE-style run **that writes code, runs tests, ships files, and emits receipts** in a single pass.

## Contents
- `src/cqe_finance.py`: Black–Scholes formulas for call/put, and a **mirror check** via put–call parity.
- `src/cqe_manifest.py`: Build a manifest with SHA256 hashes, test receipts, and a 4-bit commit.
- `src/cqe_demo.py`: Example runner that reads CSV inputs and writes outputs.
- `data/sample_params.csv`: Demo inputs.
- `tests/run_tests.py`: Self-contained tests (no pytest) exercising mirror parity and numerical stability.
- `manifest.json`: Populated when you run `python src/cqe_manifest.py`

## How CQE maps here
- **Octet views**: spec adherence, length/shape of I/O, numeric stability, mirror parity, reproducibility (manifest), safety (no PII), packaging, licensing hints.
- **Mirror**: put–call parity `C - P ≈ S - K e^(-rT)`
- **Δ-lift**: numeric guardrails (clip sigma≥1e-9, T≥1e-9), graceful handling of edge cases
- **Strict**: parity residual ≤ 1e-10 on reference set; reproducible hashes; fail hard otherwise
- **Receipts**: `manifest.json` includes test results, timings, SHA256, and **4-bit commit**

## Quick start
```bash
# Rebuild manifest and run tests
python src/cqe_manifest.py

# Run demo with provided inputs
python src/cqe_demo.py data/sample_params.csv data/bs_output.csv
```
