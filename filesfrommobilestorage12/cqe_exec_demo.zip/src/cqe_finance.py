
from __future__ import annotations
import math
from dataclasses import dataclass
SQRT2 = math.sqrt(2.0)
def _phi(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / SQRT2))
def _Nprime(x: float) -> float:
    return math.exp(-0.5*x*x) / math.sqrt(2.0*math.pi)
def _clip_pos(x: float, eps: float=1e-12) -> float:
    return max(x, eps)
@dataclass
class BSParams:
    S: float; K: float; r: float; sigma: float; T: float
def d1_d2(p: BSParams):
    sigma = _clip_pos(p.sigma, 1e-12)
    T = _clip_pos(p.T, 1e-12)
    vsqrt = sigma * math.sqrt(T)
    m = math.log(_clip_pos(p.S,1e-18)/_clip_pos(p.K,1e-18)) + (p.r + 0.5*sigma*sigma)*T
    d1 = m / vsqrt
    d2 = d1 - vsqrt
    return d1, d2
def call_price(p: BSParams) -> float:
    d1, d2 = d1_d2(p)
    return p.S * _phi(d1) - p.K * math.exp(-p.r * p.T) * _phi(d2)
def put_price(p: BSParams) -> float:
    d1, d2 = d1_d2(p)
    return p.K * math.exp(-p.r * p.T) * _phi(-d2) - p.S * _phi(-d1)
def parity_residual(p: BSParams) -> float:
    c = call_price(p); rp = put_price(p)
    rhs = p.S - p.K * math.exp(-p.r * p.T)
    return (c - rp) - rhs
def greeks(p: BSParams) -> dict:
    d1, d2 = d1_d2(p); n_d1 = _Nprime(d1)
    vsqrt = _clip_pos(p.sigma,1e-12) * math.sqrt(_clip_pos(p.T,1e-12))
    call_delta = 0.5 * (1.0 + math.erf(d1 / math.sqrt(2.0)))
    gamma = n_d1 / (_clip_pos(p.S,1e-18) * vsqrt)
    vega = _clip_pos(p.S,1e-18) * n_d1 * math.sqrt(_clip_pos(p.T,1e-12))
    theta = (-(p.S * n_d1 * _clip_pos(p.sigma,1e-12)) / (2*math.sqrt(_clip_pos(p.T,1e-12))) 
             - p.r * p.K * math.exp(-p.r*p.T) * 0.5 * (1.0 + math.erf(d2 / math.sqrt(2.0))))
    rho = p.K * p.T * math.exp(-p.r*p.T) * 0.5 * (1.0 + math.erf(d2 / math.sqrt(2.0)))
    return {"delta": call_delta, "gamma": gamma, "vega": vega, "theta": theta, "rho": rho}
