
import sys, csv
from cqe_finance import BSParams, call_price, put_price, parity_residual, greeks
def main(inp, outp):
    rows = []
    with open(inp, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            p = BSParams(S=float(row["S"]), K=float(row["K"]), r=float(row["r"]), sigma=float(row["sigma"]), T=float(row["T"]))
            call = call_price(p)
            put = put_price(p)
            resid = parity_residual(p)
            gs = greeks(p)
            out_row = dict(row)
            out_row["call"] = f"{call:.10f}"
            out_row["put"]  = f"{put:.10f}"
            out_row["parity_residual"] = f"{resid:.3e}"
            for k,v in gs.items():
                out_row[k] = f"{v:.6e}"
            rows.append(out_row)
    fieldnames = list(rows[0].keys())
    with open(outp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    print(f"Wrote {outp} ({len(rows)} rows)")
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python src/cqe_demo.py data/sample_params.csv data/bs_output.csv")
        raise SystemExit(2)
    main(sys.argv[1], sys.argv[2])
