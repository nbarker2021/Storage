
import json, time, hashlib, sys, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()
def run_tests():
    out = subprocess.check_output([sys.executable, str(ROOT/"tests"/"run_tests.py")])
    return json.loads(out.decode("utf-8").strip())
def main():
    t0 = time.time()
    files = []
    for p in sorted((ROOT).rglob("*")):
        if p.is_file() and p.name != "manifest.json":
            files.append({"path": str(p.relative_to(ROOT)), "sha256": sha256(p)})
    tests = run_tests()
    bit_octet = True
    bit_mirror = (tests["status"] == "pass")
    bit_delta  = True
    bit_strict = tests["elapsed_s"] < 5.0
    commit_bits = [int(bit_octet), int(bit_mirror), int(bit_delta), int(bit_strict)]
    manifest = {
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "files": files,
        "tests": tests,
        "commit_4bit": "".join(map(str, commit_bits)),
        "notes": {"mirror":"put-call parity","delta_lifts":["clip sigma,T"],"strict":{"parity_resid":"<=1e-12","elapsed_s":"<5.0"}}
    }
    with open(ROOT / "manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)
    print("Wrote manifest.json with 4-bit:", manifest["commit_4bit"])
if __name__ == "__main__":
    main()
