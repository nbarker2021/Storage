# Modular & Atomic Architecture
- **Atomic message**: Pack (weyl_id, chamber_id, gsl, meta, payload) — pure inside windows.
- **Modules**: small, single-purpose; deterministic; capabilities declared.
- **Edges**: commits only at fences with receipts; produce a MasterToken.
- **Composers**: Octad generator, Chamber scorer, Braid composer.
- **Ledgers**: nuggets/receipts stored in a CAS for replay.
