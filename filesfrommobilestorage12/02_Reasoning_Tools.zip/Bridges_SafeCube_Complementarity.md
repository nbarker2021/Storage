# Bridges & Safe Cube — Complementarity
Half-solves + complements; bridge-DNA; Safe Cube faces; 1729 Gate.
