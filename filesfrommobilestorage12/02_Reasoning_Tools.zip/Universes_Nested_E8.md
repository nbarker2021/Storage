# Universes & Nested E8 — Design & Ops
Scoped contexts with anchors & transforms; Underverse 8×8; portals via bridges.
