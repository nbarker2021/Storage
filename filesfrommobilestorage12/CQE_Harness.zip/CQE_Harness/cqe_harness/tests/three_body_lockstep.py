import numpy as np
from cqe_harness.adapters.three_body import simulate

def run():
    traj_a = simulate(steps=400, switch=None)
    traj_b = simulate(steps=400, switch=200)
    # measure total momentum before/after switch near t=200
    def momentum(traj, idx):
        pos, vel = traj[idx]
        m = np.array([1.0,1.0,1.0])[:,None]
        return (m*vel).sum(axis=0)
    p_pre = momentum(traj_b, 199)
    p_post = momentum(traj_b, 201)
    conserved = np.allclose(p_pre, p_post, atol=1e-6)
    return {"momentum_conserved_switch": bool(conserved)}
