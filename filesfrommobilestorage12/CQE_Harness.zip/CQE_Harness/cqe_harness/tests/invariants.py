import numpy as np
from cqe_harness.core.ledger import Ledger
from cqe_harness.core.grid import parity_grid, contradictions, canonicalize, rotate_grid
from cqe_harness.core.alena import alena_decide

def run():
    led = Ledger("CQE-HARNESS")
    g = parity_grid(4)
    led.append("Bind", {"grid": g.tolist()})
    led.append("Collision", {"contradictions": contradictions(g)})
    mode, g2 = alena_decide(g)
    led.append("Expansion", {"mode": mode})
    g3 = canonicalize(g2)
    led.append("Act", {"canonical_hash": hash(tuple(g3.flatten()))})

    # Rotation invariance
    ok = True
    for k in range(4):
        r = rotate_grid(g,k)
        _, r2 = alena_decide(r)
        r3 = canonicalize(r2)
        ok &= np.array_equal(g3, r3)
    return {"rotation_invariance": bool(ok), "ledger": led.export()}
