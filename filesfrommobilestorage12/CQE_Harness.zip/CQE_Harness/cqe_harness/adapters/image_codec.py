import numpy as np
from typing import Tuple

def encode_image(img: np.ndarray)->Tuple[np.ndarray, dict]:
    """
    Toy CQE-like transform: canonical rotation + run-length of parity grid overlay.
    """
    assert img.ndim==2
    # canonical rotation: choose rotation minimizing sum along anti-diagonal
    candidates = [np.rot90(img, k) for k in range(4)]
    k_best = int(np.argmin([np.fliplr(c).diagonal().sum() for c in candidates]))
    g = candidates[k_best]
    # parity overlay
    parity = (np.indices(g.shape).sum(axis=0) % 2)
    stream = (g ^ parity).astype(np.uint8).flatten()
    # run-length
    runs = []
    last = stream[0]; cnt=1
    for v in stream[1:]:
        if v==last: cnt+=1
        else:
            runs.append((int(last), int(cnt))); last=v; cnt=1
    runs.append((int(last), int(cnt)))
    meta = {"rot": k_best, "shape": g.shape}
    return np.array(runs, dtype=int), meta

def decode_image(runs: np.ndarray, meta: dict)->np.ndarray:
    n = sum(int(c) for _,c in runs)
    stream = np.zeros(n, dtype=np.uint8)
    i=0
    for bit,c in runs:
        stream[i:i+c]=bit; i+=c
    g = stream.reshape(meta["shape"])
    parity = (np.indices(g.shape).sum(axis=0) % 2)
    img = (g ^ parity).astype(np.uint8)
    img = np.rot90(img, k=(4-meta["rot"])%4)
    return img
