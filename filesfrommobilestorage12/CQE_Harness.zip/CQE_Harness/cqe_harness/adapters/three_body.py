import numpy as np
from typing import Tuple

OCT = np.array([[1,0,0],[0,1,0],[0,0,1],[-1,0,0],[0,-1,0],[0,0,-1],[1,1,0],[-1,1,0]], dtype=float)

def nearest_face(v: np.ndarray)->np.ndarray:
    norms = np.linalg.norm(OCT - v/ (np.linalg.norm(v)+1e-9), axis=1)
    return OCT[np.argmin(norms)]

def step_three_body(pos, vel, m, dt=1e-2, G=1.0):
    n=3
    acc = np.zeros_like(pos)
    for i in range(n):
        for j in range(n):
            if i==j: continue
            r = pos[j]-pos[i]
            d = np.linalg.norm(r)+1e-9
            f_dir = nearest_face(r)
            acc[i] += G*m[j]*f_dir/(d*d)
    vel = vel + acc*dt
    pos = pos + vel*dt
    return pos, vel

def simulate(steps=1000, switch=None):
    m = np.array([1.0,1.0,1.0])
    pos = np.array([[-1.5,0,0],[1.5,0,0],[0,1.8,0]], dtype=float)
    vel = np.array([[0,0.2,0],[0,-0.2,0],[-0.2,0,0]], dtype=float)
    traj = []
    for t in range(steps):
        if switch is not None and t==switch:
            # rotate faces implicitly by swapping axes
            pos = pos[:,[1,0,2]]
            vel = vel[:,[1,0,2]]
        pos, vel = step_three_body(pos, vel, m)
        traj.append((pos.copy(), vel.copy()))
    return traj
