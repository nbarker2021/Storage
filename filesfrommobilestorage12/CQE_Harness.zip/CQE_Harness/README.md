# CQE Harness (Reality + Simulation)

A minimal, deterministic harness to test Cartan Quadratic Equivalence (CQE) invariants across toy grids, a 3-body adapter with octad faces, and a CQE-style image roundtrip transform.

## Install
Python 3.9+
```bash
pip install numpy
```

## Run
```bash
python -m cqe_harness.cli --json
```

## What it checks
- **Invariants:** rotation invariance, canonicalization idempotence, deterministic ledger replay.
- **Three-body lockstep:** momentum conservation across an octad-face rotation event.
- **Image roundtrip:** parity-overlay RLE roundtrip equals original (lossless toy).

## Extend
- Add adapters under `cqe_harness/adapters/` to map other domains (proteins, linguistics, braids).
- Add tests under `cqe_harness/tests/` following the `run()` signature.
- Use `docs/HowTo_Build_Failure_Tests.md` to craft adversarial cases.

## Disclaimer
This is a didactic, compact harness. Replace toy physics and codec modules with domain-accurate implementations for research use.
