See schema.json and registry.json; rebuild via Construction‑A + automorphism perm24, then run mirror/octet.
