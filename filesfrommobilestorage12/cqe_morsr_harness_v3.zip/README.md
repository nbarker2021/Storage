
# CQE/MORSR Harness (Minimal, Deterministic, Parity-Safe)

This package gives you a **runnable** implementation of:
- CQE structures (overlays), parity checks (ExtHamming(8,4) lanes; ExtGolay(24,12) global),
- A deterministic **canonicalization** pass (gauge + rounding + hash),
- Alena operators (`Rtheta`, `Midpoint`, `ParityMirror`) with **Φ** non-increase,
- A **MORSR** pulse that produces a **region ledger** and **handshake packets**.

> This is a **harness**: Weyl actions are stubbed; parity and Lyapunov rules are real; the artifacts and tests are deterministic.

## Install & test

```bash
python -m pip install numpy
python -m pytest -q
```

## CLI

Mint a seed overlay, then run MORSR:

```bash
python -m cqe.cli mint-seed --out seed_overlay.json
python -m cqe.cli morsr --seed seed_overlay.json --region-out region.json --handshakes-out handshakes.jsonl
```

Outputs:
- `region.json` — saturated region (2 rings in this demo)
- `handshakes.jsonl` — signed handshake packets with Φ before/after
```

