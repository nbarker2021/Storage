
import json, math, base64, time
from typing import Dict, Any, List
from .overlay import EO
from .canonicalize import canonicalize
from .operators import op_Rtheta, op_Midpoint, op_ParityMirror, op_WeylReflect
from .config import TOL

def make_handshake(from_eo: EO, to_eo: EO, op_name: str, phi_before: float, phi_after: float) -> Dict[str, Any]:
    return {
        "version":"morsr_handshake_v1",
        "overlay_id": to_eo.canon.get("hash_id",""),
        "frame":"e8_canonical_v1",
        "code_proof": {
          "lane_code":"ExtHamming84",
          "global_code":"ExtGolay24",
          "lane_syndromes": to_eo.invariants.get("code_proof",{}).get("lane_syndromes",[]),
          "global_syndrome": to_eo.invariants.get("code_proof",{}).get("global_syndrome",[]),
          "coset_leaders": {},
          "valid": True
        },
        "invariants": to_eo.invariants,
        "pose": to_eo.pose,
        "ops_trace":[{"op":op_name, "params":{}, "phi_before":phi_before, "phi_after":phi_after}],
        "context_contracts": {},
        "signature":"sigstore:DEMO"
    }

def pulse(seed: EO, max_rings: int = 2) -> Dict[str, Any]:
    # Build golden-ish example: ring 0 = seed; ring 1 attempts Rtheta on lane 1 and Midpoint on lane 5
    # Evaluate PHI monotonicity and accept if decreased.
    region = {
        "region_id":"morsr_region_auto",
        "config_id":"cqe_default_v1",
        "seed_overlay_id":"",
        "rings":[],
        "boundaries":[],
        "status":""
    }
    # Ring 0
    seed.update_invariants()
    js = canonicalize(seed.to_json())
    seed.canon = js["canon"]
    region["seed_overlay_id"] = seed.canon["hash_id"]
    region["rings"].append({"ring_idx":0, "lanes":[{"lane_id":i,"overlay_ids":[seed.canon["hash_id"]]} for i in range(1,9)]})
    # Ring 1 candidates
    accepted = []
    # Lane 1: Rtheta
    cand1 = EO(present=seed.present[:], w=seed.w[:], phi=seed.phi[:], pose=seed.pose.copy())
    phi_before = cand1.compute_PHI()
    op_Rtheta(cand1, step=1)
    cand1.update_invariants()
    js1 = canonicalize(cand1.to_json()); cand1.canon = js1["canon"]
    phi_after = cand1.compute_PHI()
    if phi_after <= phi_before - TOL["eps_PHI"] or abs(phi_after - phi_before) <= TOL["eps_PHI"]:
        accepted.append({"lane_id":1, "overlay_id": cand1.canon["hash_id"], "handshake": make_handshake(seed, cand1, "Rtheta", phi_before, phi_after)})
    # Lane 5: Midpoint

    # Lane 3: WeylReflect (simple root 0 by default)
    cand3 = EO(present=seed.present[:], w=seed.w[:], phi=seed.phi[:], pose=seed.pose.copy())
    phi_before3 = cand3.compute_PHI()
    op_WeylReflect(cand3, simple_idx=0)
    cand3.update_invariants()
    js3 = canonicalize(cand3.to_json()); cand3.canon = js3["canon"]
    phi_after3 = cand3.compute_PHI()
    if phi_after3 <= phi_before3 - TOL["eps_PHI"] or abs(phi_after3 - phi_before3) <= TOL["eps_PHI"]:
        accepted.append({"lane_id":3, "overlay_id": cand3.canon["hash_id"], "handshake": make_handshake(seed, cand3, "WeylReflect(s0)", phi_before3, phi_after3)})
    cand2 = EO(present=seed.present[:], w=seed.w[:], phi=seed.phi[:], pose=seed.pose.copy())
    phi_before2 = cand2.compute_PHI()
    op_Midpoint(cand2)
    cand2.update_invariants()
    js2 = canonicalize(cand2.to_json()); cand2.canon = js2["canon"]
    phi_after2 = cand2.compute_PHI()
    if phi_after2 <= phi_before2 - TOL["eps_PHI"]:
        accepted.append({"lane_id":5, "overlay_id": cand2.canon["hash_id"], "handshake": make_handshake(seed, cand2, "Midpoint", phi_before2, phi_after2)})
    # Assemble ring 1
    lanes = []
    for a in accepted:
        lanes.append({"lane_id": a["lane_id"], "overlay_ids":[a["overlay_id"]]})
    region["rings"].append({"ring_idx":1, "lanes":lanes})
    # Boundaries for the rest
    for i in [2,3,4,6,7,8]:
        region["boundaries"].append({"lane_id":i,"ring_idx_exhausted":1,"reason":"no_handshake"})
    region["status"]="saturated"
    # Emit handshakes list
    handshakes = []
    # identity
    handshakes.append(make_handshake(seed, seed, "Identity", seed.compute_PHI(), seed.compute_PHI()))
    handshakes.extend([a["handshake"] for a in accepted])
    return {"region": region, "handshakes": handshakes}
