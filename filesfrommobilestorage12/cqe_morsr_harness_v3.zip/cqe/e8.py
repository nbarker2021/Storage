
import itertools, json
from typing import List, Tuple

def e8_roots_sorted():
    roots = []
    # Type I: e_i ± e_j
    for i in range(8):
        for j in range(i+1,8):
            for s1 in (+1,-1):
                for s2 in (+1,-1):
                    v = [0]*8; v[i]=s1; v[j]=s2
                    roots.append(tuple(v))
    # Type II: 1/2(±1,...,±1) with even number of +1
    for signs in itertools.product((-1,1), repeat=8):
        if sum(1 for s in signs if s==1) % 2 == 0:
            roots.append(tuple(0.5*s for s in signs))
    roots.sort()
    return roots  # 240

def e8_nodes_248():
    roots = e8_roots_sorted()
    cartan = [tuple(1 if i==k else 0 for i in range(8)) for k in range(8)]
    nodes = roots + cartan
    vec_to_idx = {tuple(v): i for i,v in enumerate(nodes)}
    return nodes, vec_to_idx

def subroot_indices():
    nodes, vidx = e8_nodes_248()
    def idx_of(vec): return vidx[tuple(vec)]
    r12 = [1,-1,0,0,0,0,0,0]
    r23 = [0,1,-1,0,0,0,0,0]
    r31 = [-1,0,1,0,0,0,0,0]
    r34 = [0,0,1,-1,0,0,0,0]
    r56 = [0,0,0,0,1,-1,0,0]
    r67 = [0,0,0,0,0,1,-1,0]
    r75 = [0,0,0,0,-1,0,1,0]
    r3p4 = [0,0,1,1,0,0,0,0]
    A2 = [idx_of(r12), idx_of(r23), idx_of(r31)]
    A2xA2 = A2 + [idx_of(r56), idx_of(r67), idx_of(r75)]
    A3 = [idx_of(r12), idx_of(r23), idx_of(r34)]
    D4 = [idx_of(r12), idx_of(r23), idx_of(r34), idx_of(r3p4)]
    return {"A2":A2, "A2xA2":A2xA2, "A3":A3, "D4":D4, "H4":[]}
