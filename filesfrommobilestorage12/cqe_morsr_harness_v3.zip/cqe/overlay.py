
import base64, json, math
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import numpy as np
from .config import TOL, PHI_WEIGHTS, KISSING
from .codes import ext_hamming_84, ext_golay_24, gf2_matmul
from .e8 import e8_nodes_248

G8, H8 = ext_hamming_84()
G24, H24 = ext_golay_24()

NODES_248, VEC_TO_IDX = e8_nodes_248()

def b64_present(present_bool: List[bool]) -> str:
    out = bytearray()
    byte=0; count=0
    for i in range(248):
        bit = 1 if present_bool[i] else 0
        byte = (byte<<1) | bit
        count += 1
        if count==8:
            out.append(byte); byte=0; count=0
    return base64.b64encode(bytes(out)).decode()

def sparsity_penalty(present_bool: List[bool]) -> float:
    active = sum(1 for b in present_bool if b)
    return (248 - active) / 248.0

def lane_bits_from_overlay(present_bool: List[bool]) -> np.ndarray:
    # Partition 248 nodes into 8 lanes of size 31 for a toy lane parity
    lane = np.zeros(8, dtype=int)
    for i,b in enumerate(present_bool):
        if not b: continue
        lane[i % 8] ^= 1
    return lane  # 8-bit

def golay_bits_from_overlay(present_bool: List[bool]) -> np.ndarray:
    # Summarize into 24 bits by 24-slice parity
    g = np.zeros(24, dtype=int)
    for i,b in enumerate(present_bool):
        if not b: continue
        g[i % 24] ^= 1
    return g

def syndrome_lane(lane_bits: np.ndarray) -> np.ndarray:
    return gf2_matmul(lane_bits.reshape(1,8), H8.T).reshape(-1)

def syndrome_golay(bits24: np.ndarray) -> np.ndarray:
    return gf2_matmul(bits24.reshape(1,24), H24.T).reshape(-1)

def kissing_deviation(present_bool: List[bool]) -> float:
    # Target fraction tau; use density-scaled target with cap
    density = sum(present_bool)/248.0
    tau = min(1.0, density*1.2)
    # Observed "kissing" proxy: count neighbors modulo a small threshold (toy metric)
    # For harness, we approximate as active count normalized (since full neighbors needs geometry)
    Kobs = sum(present_bool)
    Kstar = 240.0
    return abs((Kobs/Kstar) - tau)

@dataclass
class EO:
    present: List[bool] = field(default_factory=lambda: [False]*248)
    w: List[float] = field(default_factory=lambda: [0.0]*248)
    phi: List[float] = field(default_factory=lambda: [None]*248)
    pose: Dict[str, Any] = field(default_factory=lambda: {"coxeter_k":0,"diag_auto_id":0,"lane_perm_id":0,"torus_params":{"q_max":8}})
    invariants: Dict[str, Any] = field(default_factory=dict)
    canon: Dict[str, Any] = field(default_factory=dict)
    provenance: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> Dict[str, Any]:
        return {
            "version":"eo_v1",
            "frame":"e8_canonical_v1",
            "nodes": {"present": b64_present(self.present), "w": self.w, "phi": self.phi},
            "invariants": self.invariants,
            "pose": self.pose,
            "canon": self.canon,
            "provenance": self.provenance,
            "signature":"sigstore:DEMO"
        }

    def compute_parity(self) -> Dict[str, Any]:
        lane_bits = lane_bits_from_overlay(self.present)
        golay_bits = golay_bits_from_overlay(self.present)
        s_lane = syndrome_lane(lane_bits)
        s_g = syndrome_golay(golay_bits)
        return {"lane_bits": lane_bits.tolist(), "golay_bits": golay_bits.tolist(),
                "lane_syndrome": s_lane.tolist(), "golay_syndrome": s_g.tolist()}

    def compute_Q(self) -> float:
        # Toy quadratic: sum w^2 for active, penalize phase jitter if present
        q = 0.0
        for i, b in enumerate(self.present):
            if not b: continue
            q += (self.w[i] if self.w[i] is not None else 0.0)**2
        # small phase jitter
        phis = [self.phi[i] for i,b in enumerate(self.present) if b and self.phi[i] is not None]
        if len(phis)>=2:
            diffs = [abs(phis[i+1]-phis[i]) for i in range(len(phis)-1)]
            q += 0.01*sum(diffs)
        return q

    def compute_PHI(self) -> float:
        from .config import PHI_WEIGHTS as W, KISSING
        parity = self.compute_parity()
        lane_norm = sum(1 for x in parity["lane_syndrome"] if x!=0)
        golay_norm = sum(1 for x in parity["golay_syndrome"] if x!=0)
        Q = self.compute_Q()
        spars = ((248 - sum(1 for b in self.present if b)) / 248.0)
        dev = kissing_deviation(self.present)
        PHI = W["a"]*Q + W["b"]*lane_norm + W["c"]*golay_norm + W["d"]*spars + KISSING["nu"]*dev
        return float(PHI)

    def update_invariants(self):
        active = [i for i,b in enumerate(self.present) if b]
        self.invariants.setdefault("orbit_counts", [len(active)])
        # cartan_sig toy: split 8 buckets by index mod 8 and sum weights
        buckets = [0.0]*8
        for i in active:
            buckets[i%8] += self.w[i]
        self.invariants["cartan_sig"] = buckets
        self.invariants.setdefault("coxeter_hist", [0]*30)
        self.invariants.setdefault("closure_sig", {"triad": True, "dyad": True, "pal": True, "phi_min": self.compute_PHI()})
        self.invariants.setdefault("torus_link", {"k":1,"wind":[[1,3]]})
        self.invariants.setdefault("spectrum", [1.0,0.5,0.2])
        self.invariants.setdefault("subsystem_tags", ["A2"])
        parity = self.compute_parity()
        self.invariants["code_proof"] = {
            "lane_code":"ExtHamming84",
            "global_code":"ExtGolay24",
            "lane_syndromes": parity["lane_syndrome"],
            "global_syndrome": parity["golay_syndrome"],
            "coset_leaders": {}
        }

