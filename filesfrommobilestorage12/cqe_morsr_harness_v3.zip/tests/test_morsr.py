
import json
from cqe.overlay import EO
from cqe.canonicalize import canonicalize
from cqe.morsr import pulse

def test_morsr_runs_and_monotone():
    eo = EO()
    for i in [0,1,2]:
        eo.present[i]=True; eo.w[i]=0.7; eo.phi[i]=0.0
    eo.update_invariants()
    start = eo.compute_PHI()
    out = pulse(eo, max_rings=2)
    assert "region" in out and "handshakes" in out
    # ensure at least identity present and PHI non-increase on accepted moves
    ok = False
    for h in out["handshakes"]:
        if h["ops_trace"][0]["op"]!="Identity":
            assert h["ops_trace"][0]["phi_after"] <= h["ops_trace"][0]["phi_before"] + 1e-6
            ok = True
    assert ok
