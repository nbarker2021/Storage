
import json, os, tempfile
from cqe.adapters.superperm_adapter import overlay_from_superperm
from cqe.adapters.audio_adapter import overlay_from_audio
from cqe.morsr import pulse

def test_superperm_adapter_runs():
    seq = "123451234512345"  # toy, n=5 detection
    eo, n, k = overlay_from_superperm(seq)
    assert n==5 and k>0
    out = pulse(eo)
    assert "region" in out

def test_audio_adapter_runs():
    eo, nf = overlay_from_audio("hello world", ber=0.01)
    assert nf >= 1
    out = pulse(eo)
    assert "region" in out
