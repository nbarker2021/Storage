
import os, json, time, hashlib, re
from http.server import BaseHTTPRequestHandler, HTTPServer
from sidecar.cqe_sidecar_mini import CQESidecarMini

BASE = os.path.dirname(os.path.dirname(__file__))
DATA = os.path.join(BASE, "data")
CONFIG = os.path.join(BASE, "config")
WEB = os.path.join(BASE, "web")
os.makedirs(DATA, exist_ok=True)

LEDGER_PATH = os.path.join(DATA, "ledger.jsonl")
INVENTORY_PATH = os.path.join(DATA, "inventory.json")
REQUESTS_PATH = os.path.join(DATA, "requests.json")
PAYOUT_PATH = os.path.join(DATA, "payout_wallet.json")
ANCHOR_PATH = os.path.join(DATA, "ledger_anchor.json")
TOOLS_PATH = os.path.join(DATA, "tools.json")
TOOLCHAINS_PATH = os.path.join(DATA, "toolchains.json")
TOOLTOKENS_PATH = os.path.join(DATA, "tooltokens.json")
BALANCES_PATH = os.path.join(DATA, "balances.json")
UPLOADS_DIR = os.path.join(DATA, "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

def load_json_file(p, default):
    try:
        with open(p, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: return default

def save_json_file(p, obj):
    with open(p, "w", encoding="utf-8") as f: json.dump(obj, f, indent=2)

POLICY = load_json_file(os.path.join(CONFIG, "policy.json"), {"policy_version":"mint-v1.0"})
SIDECAR = CQESidecarMini(disk_dir=os.path.join(DATA,'.cas'), ledger_path=os.path.join(DATA,'.sidecar_ledger.jsonl'), policy=POLICY)

def _hash_line(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def _merkle_root(lines):
    if not lines: return None
    level = [ _hash_line((l if isinstance(l, str) else json.dumps(l)).encode("utf-8")) for l in lines ]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            left = level[i]; right = level[i+1] if i+1 < len(level) else left
            nxt.append(hashlib.sha256(left+right).digest())
        level = nxt
    return level[0].hex()

def _load_balances():
    return load_json_file(BALANCES_PATH, {})

def _save_balances(b):
    save_json_file(BALANCES_PATH, b)

def credit(actor_id, coin, amount):
    bal = _load_balances()
    acct = bal.setdefault(actor_id, {})
    acct[coin] = float(acct.get(coin, 0.0)) + float(amount)
    _save_balances(bal)
    return acct

def debit(actor_id, coin, amount):
    bal = _load_balances()
    acct = bal.setdefault(actor_id, {})
    if float(acct.get(coin, 0.0)) < float(amount):
        raise ValueError("insufficient funds")
    acct[coin] = float(acct.get(coin, 0.0)) - float(amount)
    _save_balances(bal)
    return acct

def append_ledger(entry):
    with open(LEDGER_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry)+"\n")

def get_adapter_status():
    # stubbed: flip to true when actual modules present
    return {"geotokenizer": False, "novelty": False, "mdhg": False, "moonshine": False}

class Handler(BaseHTTPRequestHandler):
    def _read(self):
        ln = int(self.headers.get("Content-Length","0"))
        if ln <= 0: return {}
        raw = self.rfile.read(ln).decode("utf-8")
        try: return json.loads(raw)
        except Exception: return {}

    def _write(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","*")
        self.send_header("Access-Control-Allow-Methods","POST, OPTIONS")
        self.end_headers()

    def do_POST(self):
        body = self._read()
        path = self.path

        if path == "/health":
            return self._write({"ok": True, "ts": time.time()})

        if path == "/sidecar/run_tool":
    code = body.get("code",""); func = body.get("func","main"); args = body.get("args",{})
    try:
        out = SIDECAR.run_tool(code, func, args)
        return self._write({"ok": True, **out})
    except Exception as e:
        return self._write({"ok": False, "error": str(e)})
if path == "/sidecar/run_pipeline":
    stages = body.get("stages", [])
    try:
        out = SIDECAR.run_pipeline(stages)
        return self._write({"ok": True, **out})
    except Exception as e:
        return self._write({"ok": False, "error": str(e)})
if path == "/sidecar/report":
    return self._write({"ok": True, "report": SIDECAR.report()})
if path == "/adapters/status":
            return self._write({"ok": True, "adapters": get_adapter_status()})

        if path == "/upload":
            # body: {name, content(base64)? or text?} simple text variant for MVP
            name = body.get("name","note.txt")
            text = body.get("text","")
            fp = os.path.join(UPLOADS_DIR, name)
            with open(fp, "w", encoding="utf-8") as f: f.write(text)
            append_ledger({"type":"upload","name":name,"ts":time.time()})
            inv = load_json_file(INVENTORY_PATH, {"papers":[],"drafts":[]})
            inv["papers"].append({"name": name, "path": fp})
            save_json_file(INVENTORY_PATH, inv)
            return self._write({"ok": True, "name": name})

        if path == "/tiles/init":
            inv = load_json_file(INVENTORY_PATH, {"papers":[],"drafts":[]})
            return self._write({"ok": True, "inventory": inv})

        if path == "/combine":
            # combine two papers into a draft
            p1, p2 = body.get("p1"), body.get("p2")
            inv = load_json_file(INVENTORY_PATH, {"papers":[],"drafts":[]})
            draft_id = f"DF_{int(time.time()*1000)}"
            inv["drafts"].append({"draft_id": draft_id, "sources":[p1,p2], "lab":{"passes":0,"fails":0}, "evidence":{"endorsements":0,"lineage":0,"deployments":0,"quality":0,"delta_phi":0,"novelty":0,"safety":{"non_coercive": True,"non_weaponizable": True,"harm_reduction_pass": True}}})
            save_json_file(INVENTORY_PATH, inv)
            append_ledger({"type":"combine","draft_id":draft_id,"sources":[p1,p2],"ts":time.time()})
            return self._write({"ok": True, "draft_id": draft_id})

        if path == "/lab/record":
            draft_id = body.get("draft_id")
            passed = bool(body.get("passed", False))
            inv = load_json_file(INVENTORY_PATH, {"papers":[],"drafts":[]})
            for d in inv["drafts"]:
                if d["draft_id"] == draft_id:
                    if passed: d["lab"]["passes"] += 1
                    else: d["lab"]["fails"] += 1
                    save_json_file(INVENTORY_PATH, inv)
                    append_ledger({"type":"lab_mark","draft_id":draft_id,"passed":passed,"ts":time.time()})
                    return self._write({"ok": True, "lab": d["lab"]})
            return self._write({"ok": False, "error": "draft not found"})

        if path == "/metrics/mint_preview":
            draft_id = body.get("draft_id")
            inv = load_json_file(INVENTORY_PATH, {"papers":[],"drafts":[]})
            d = next((x for x in inv.get("drafts",[]) if x["draft_id"]==draft_id), None)
            if not d: return self._write({"ok": False, "error":"draft not found"})
            # very simple factor exposition
            sft = d["evidence"].get("safety", {})
            aegis_explanation = []
            if not sft.get("non_coercive", False): aegis_explanation.append("fails: non_coercive")
            if not sft.get("non_weaponizable", False): aegis_explanation.append("fails: non_weaponizable")
            if not sft.get("harm_reduction_pass", False): aegis_explanation.append("fails: harm_reduction_pass")
            out = {
                "ok": True,
                "policy_version": POLICY.get("policy_version","mint-v1.0"),
                "aegis_explanation": aegis_explanation,
                "factors": d["evidence"],
                "lab": d["lab"],
                "domains": {"MERIT": 1.0, "THETA":0.3, "DAVINCI":0.2}
            }
            return self._write(out)

        if path == "/ledger/tail":
            lines = []
            if os.path.exists(LEDGER_PATH):
                with open(LEDGER_PATH, "r", encoding="utf-8") as f:
                    lines = f.read().splitlines()[-60:]
            return self._write({"ok": True, "lines": lines})

        if path == "/ledger/anchor":
            if not os.path.exists(LEDGER_PATH): return self._write({"ok": False, "error": "no ledger"})
            with open(LEDGER_PATH, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
            root = _merkle_root(lines)
            anchor = {"ts": time.time(), "root": root, "count": len(lines), "signature": None}
            save_json_file(ANCHOR_PATH, anchor); return self._write({"ok": True, **anchor})

        if path == "/ledger/get_root":
            anchor = load_json_file(ANCHOR_PATH, {})
            return self._write({"ok": bool(anchor), **anchor})

        if path == "/ledger/verify_root":
            anchor = load_json_file(ANCHOR_PATH, {})
            if not anchor: return self._write({"ok": False, "error": "no anchor"})
            if not os.path.exists(LEDGER_PATH): return self._write({"ok": False, "error": "no ledger"})
            with open(LEDGER_PATH, "r", encoding="utf-8") as f: lines = f.read().splitlines()
            current = _merkle_root(lines)
            return self._write({"ok": current == anchor.get("root"), "stored":anchor.get("root"), "computed": current, "count": len(lines)})

        if path == "/lab/reproduce_script":
            sid = body.get("session_id","demo")
            manifest = {"session_id": sid, "generated_at": time.time(), "adapters": get_adapter_status(), "policy_version": POLICY.get("policy_version","mint-v1.0")}
            script = f"""#!/usr/bin/env bash
set -euo pipefail
echo 'Reproducing lab session {sid}'
cat <<'JSON'
{json.dumps(manifest, indent=2)}
JSON
"""
            return self._write({"ok": True, "manifest": manifest, "script": script})

        # Pricing, balances, convert
        if path == "/pricing/quote":
            kind = body.get("kind","lab_run")
            composed = bool(body.get("composed", False))
            p = POLICY.get("pricing", {})
            base_fiat = p.get("lab_run_base_fiat", 2.5) if kind=="lab_run" else p.get("tool_register_fiat", 5.0)
            base_merit = p.get("lab_run_base_merit", 0.05) if kind=="lab_run" else p.get("tool_register_merit", 0.10)
            if composed and kind=="lab_run":
                mult = p.get("suite_run_multiplier", 1.2)
                base_fiat *= mult; base_merit *= mult
            return self._write({"ok": True, "fiat": round(base_fiat, 4), "MERIT": round(base_merit, 4)})

        if path == "/credits/balances":
            actor = body.get("actor_id")
            bal = _load_balances()
            if actor: bal = {actor: bal.get(actor, {})}
            return self._write({"ok": True, "balances": bal})

        if path == "/credits/convert":
            actor = body.get("actor_id","anon")
            src = body.get("src")
            dstc = body.get("dst")
            amt = float(body.get("amount", 0))
            conv = POLICY.get("conversion", {})
            if src=='MERIT' and dstc in conv.get("MERIT_to_domain", {}):
                rate = float(conv["MERIT_to_domain"][dstc])
                try:
                    debit(actor, 'MERIT', amt)
                except Exception:
                    return self._write({"ok": False, "error": "insufficient MERIT"})
                credit(actor, dstc, amt * rate)
                append_ledger({"type":"convert","actor":actor,"src":"MERIT","dst":dstc,"amount":amt,"rate":rate,"ts":time.time()})
                return self._write({"ok": True, "rate": rate})
            if src!='MERIT' and dstc=='MERIT':
                if not conv.get("domain_to_MERIT_allowed", False):
                    return self._write({"ok": False, "error": "Upward conversion disabled by policy"})
            return self._write({"ok": False, "error": "Unsupported conversion"})

        # Tools & Toolchains
        if path == "/tools/register":
            actor = body.get("actor_id","anon")
            name = body.get("name"); code = body.get("code","")
            price = POLICY.get("pricing",{}).get("tool_register_merit", 0.10)
            try:
                debit(actor, 'MERIT', price)
            except Exception:
                return self._write({"ok": False, "error":"Insufficient MERIT", "price": price})
            tools = load_json_file(TOOLS_PATH, [])
            tid = f"TL_{int(time.time()*1000)}"
            tools.append({"tool_id": tid, "name": name, "owner": actor, "code": code, "created_at": time.time()})
            save_json_file(TOOLS_PATH, tools)
            append_ledger({"type":"tool_register","actor":actor,"tool_id":tid,"ts":time.time()})
            return self._write({"ok": True, "tool_id": tid, "debited_merit": price})

        if path == "/tools/list":
            tools = load_json_file(TOOLS_PATH, [])
            return self._write({"ok": True, "tools": tools})

        if path == "/tools/toolchains/create":
            actor = body.get("actor_id","anon")
            name = body.get("name","suite")
            steps = body.get("steps",[])
            tcs = load_json_file(TOOLCHAINS_PATH, [])
            tcid = f"TC_{int(time.time()*1000)}"
            tcs.append({"toolchain_id": tcid, "name": name, "owner": actor, "steps": steps, "created_at": time.time()})
            save_json_file(TOOLCHAINS_PATH, tcs)
            append_ledger({"type":"toolchain_create","actor":actor,"toolchain_id":tcid,"ts":time.time()})
            return self._write({"ok": True, "toolchain_id": tcid})

        if path == "/tools/toolchains/run":
            actor = body.get("actor_id","anon")
            tcid = body.get("toolchain_id")
            data = body.get("input","")
            tcs = load_json_file(TOOLCHAINS_PATH, [])
            tools = load_json_file(TOOLS_PATH, [])
            tc = next((t for t in tcs if t["toolchain_id"]==tcid), None)
            if not tc: return self._write({"ok": False, "error":"toolchain not found"})
            price = POLICY.get("pricing",{}).get("lab_run_base_merit",0.05) * POLICY.get("pricing",{}).get("suite_run_multiplier",1.2)
            try:
                debit(actor, 'MERIT', price)
            except Exception:
                return self._write({"ok": False, "error": "Insufficient MERIT for suite run", "price": price})
            out = data
            steps = []
            stages = []
            for st in tc.get("steps", []):
                tid = st.get("tool_id")
                tool = next((t for t in tools if t["tool_id"]==tid), None)
                if not tool:
                    steps.append({"tool_id": tid, "error": "missing"}); continue
                stages.append({"code": tool.get("code",""), "func": st.get("func","main"), "args": st.get("args",{})})
            # run pipeline in sidecar mini
            pipe = SIDECAR.run_pipeline(stages)
            rid = pipe.get("rid") or f"LABSUITE_{int(time.time()*1000)}"
            out = pipe.get("output")
            append_ledger({"type":"lab_suite","actor":actor,"toolchain_id":tcid,"rid":rid,"steps":steps,"ts":time.time()})
            return self._write({"ok": True, "rid": rid, "result": out, "steps": steps, "debited_merit": price})

        # Tool Tokens
        if path == "/tooltoken/request":
            actor = body.get("actor_id","anon")
            name = body.get("name"); desc = body.get("description","")
            est_cost = float(body.get("est_cost_merit", 1.0))
            toks = load_json_file(TOOLTOKENS_PATH, [])
            ttid = f"TT_{int(time.time()*1000)}"
            toks.append({"tooltoken_id": ttid, "requester": actor, "name": name, "description": desc, "status":"requested", "est_cost_merit": est_cost, "created_at": time.time(), "split":{"system":0.5,"requester":0.5}})
            save_json_file(TOOLTOKENS_PATH, toks)
            append_ledger({"type":"tooltoken_request","tooltoken_id":ttid,"actor":actor,"ts":time.time()})
            return self._write({"ok": True, "tooltoken_id": ttid})

        if path == "/tooltoken/approve":
            ttid = body.get("tooltoken_id")
            toks = load_json_file(TOOLTOKENS_PATH, [])
            x = next((t for t in toks if t["tooltoken_id"]==ttid), None)
            if not x: return self._write({"ok": False, "error":"not found"})
            x["status"] = "approved"
            save_json_file(TOOLTOKENS_PATH, toks)
            append_ledger({"type":"tooltoken_approve","tooltoken_id":ttid,"ts":time.time()})
            return self._write({"ok": True})

        if path == "/tooltoken/settle_usage":
            ttid = body.get("tooltoken_id"); income = float(body.get("merit_income",0.0))
            toks = load_json_file(TOOLTOKENS_PATH, [])
            x = next((t for t in toks if t["tooltoken_id"]==ttid), None)
            if not x: return self._write({"ok": False, "error":"not found"})
            split = x.get("split", {"system":0.5,"requester":0.5})
            sys_amt = income * float(split.get("system",0.5))
            req_amt = income * float(split.get("requester",0.5))
            credit("__system__", "MERIT", sys_amt)
            credit(x["requester"], "MERIT", req_amt)
            append_ledger({"type":"tooltoken_usage","tooltoken_id":ttid,"merit_income":income,"ts":time.time()})
            return self._write({"ok": True, "system_merit": sys_amt, "requester_merit": req_amt})

        return self._write({"ok": False, "error": "unknown path"}, 404)

def run(host="0.0.0.0", port=8787):
    httpd = HTTPServer((host, port), Handler)
    print(f"CommonsLedger v0.3.5 server on http://{host}:{port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
