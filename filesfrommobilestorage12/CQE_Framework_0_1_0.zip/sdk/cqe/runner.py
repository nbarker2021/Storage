
from pathlib import Path
import importlib.util, json

class Runner:
    def __init__(self, root: Path):
        self.root = Path(root)

    def run_module(self, mod_id: int, rails: str, data=None, overlays=True) -> dict:
        mod_dir = self.root / "modules" / rails / f"id_{mod_id}"
        stub = mod_dir / "stub.py"
        if not stub.exists():
            return {"id": mod_id, "status": "error", "reason": "module stub missing"}
        spec = importlib.util.spec_from_file_location(f"cqe.mod.{mod_id}", stub)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.run(data=data, overlays=overlays)
