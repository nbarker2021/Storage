import os, json, time
from typing import List, Dict, Any

class OrgNode:
    def __init__(self, base_dir: str):
        self.base = base_dir
        os.makedirs(self.base, exist_ok=True)
        self.index_path = os.path.join(self.base, "lineage_index.jsonl")

    def ingest_record(self, source_id: str, kind: str, score: float, meta: Dict[str,Any]):
        rec = {"source_id":source_id, "kind":kind, "score":float(score), "meta":meta, "ts":time.time()}
        with open(self.index_path,"a") as f:
            f.write(json.dumps(rec)+"\n")

    def match_lineage(self, contribution_summary: str) -> List[Dict[str,Any]]:
        res = []
        if not os.path.exists(self.index_path): return res
        with open(self.index_path) as f:
            for line in f:
                rec = json.loads(line)
                terms = (rec.get("meta",{}).get("keywords","") or "").lower().split()
                if any(t in contribution_summary.lower() for t in terms):
                    res.append({"source_id":rec["source_id"],"score":min(1.0, rec["score"]), "kind":rec["kind"]})
        return res
