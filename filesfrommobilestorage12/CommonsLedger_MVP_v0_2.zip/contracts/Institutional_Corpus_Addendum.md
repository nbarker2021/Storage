# Institutional Corpus Addendum — CommonsLedger MVP

Authorizes indexing & lineage‑matching; allows functional templates with royalty routing to authors/rights holders. Paywalled raw text remains gated; templates expose minimal functional elements. Attribution and withdrawal (prospective) honored.
