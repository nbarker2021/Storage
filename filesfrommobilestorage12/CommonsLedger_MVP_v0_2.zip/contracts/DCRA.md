# Data Contribution Royalty Agreement (DCRA) — CommonsLedger MVP

**You** contribute documented acts/know‑how (“Contribution”). **We** verify, mint Contribution Proofs, and route value and royalties.

1) **License**. Non‑exclusive license to index, lineage‑match, and create functional templates for survival/education/operational use. You keep IP.
2) **Sensitivity**. We publish minimal functional facts. Sensitive content remains local unless you authorize (e.g., MYTHOS).
3) **Verification/Mint**. Governance windows + lineage checks. If pass, Proof minted into Contribution Classes (MERIT, CARETAKER, AEGIS, INFRA, GAIA, VANGOGH, MYTHOS, DAVINCI, THETA, ORBIT).
4) **Royalties**. Paid services using your patterns route royalties to you per posted schedule.
5) **Commons Share**. 50% of platform net goes to Shared Relief Pool; locked and redeemable per rules.
6) **Withdrawal**. You may withdraw future licensing for new uses; existing Proofs remain immutable.
7) **Warranties**. You: truthful & no breach of third‑party secrets. We: accurate receipts & payouts per formulas.
8) **Disputes**. ORBIT mediation first; then ordinary remedies.
