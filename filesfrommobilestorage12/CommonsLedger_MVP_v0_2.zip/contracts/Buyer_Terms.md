# Buyer Terms for Specifics Requests — CommonsLedger MVP

1) Post request with budget/SLA/tests. 2) Bidders respond; escrow funds. 3) Work must pass governance windows. 4) On acceptance: release creator royalties, node fees, and 50% platform net to Shared Relief Pool. 5) Use license for your ops; redistribution triggers additional royalties. 6) ORBIT mediation for disputes.
