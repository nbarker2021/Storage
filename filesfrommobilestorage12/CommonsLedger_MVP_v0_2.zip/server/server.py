\
import os, json, time, hashlib, random
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
from typing import Dict, Any, List

ROOT = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.abspath(os.path.join(ROOT, ".."))
DATA = os.path.join(BASE, "data")

# Optional yaml config
policy = {"payout_split":{"payout_wallet_fraction":0.5},
          "domains":{"MERIT":1.0,"CARETaker".upper():1.0,"AEGIS":1.2,"INFRA":1.1,"GAIA":1.2,"VANGOGH":0.8,"MYTHOS":1.0,"DAVINCI":1.1,"THETA":1.3,"ORBIT":1.2}}

# Sidecar adapter
import sys
sys.path.append(os.path.join(BASE,"sidecar_adapters"))
from speedlight_router import Ledger, MintEngine

ledger = Ledger(DATA)
engine = MintEngine(policy, ledger)

# Utilities
def read_json(req: BaseHTTPRequestHandler) -> Dict[str,Any]:
    length = int(req.headers.get("Content-Length","0") or "0")
    body = req.rfile.read(length) if length else b"{}"
    try:
        return json.loads(body.decode("utf-8"))
    except Exception:
        return {}

def respond(res: BaseHTTPRequestHandler, code: int, obj: Dict[str,Any]):
    b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    res.send_response(code)
    res.send_header("Content-Type","application/json; charset=utf-8")
    res.send_header("Content-Length", str(len(b)))
    res.end_headers()
    res.wfile.write(b)

def short_id(prefix: str, payload: Dict[str,Any]) -> str:
    h = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()[:10]
    return f"{prefix}{h}"

# Inventory helpers
def inv_path(actor_id: str) -> str:
    return os.path.join(DATA, "inventory", f"{actor_id}.json")

def ensure_inventory(actor_id: str) -> Dict[str,Any]:
    p = inv_path(actor_id)
    if os.path.exists(p):
        return json.load(open(p))
    inv = {"actor_id":actor_id,
           "journals":3, "subjournals":9,
           "decks":{"invariant":24,"hypothesis":12},
           "credits":{"MERIT":0,"CARETAKER":0,"AEGIS":0,"INFRA":0,"GAIA":0,"VANGOGH":0,"MYTHOS":0,"DAVINCI":0,"THETA":0,"ORBIT":0}}
    json.dump(inv, open(p,"w"))
    return inv

def save_inventory(inv: Dict[str,Any]):
    json.dump(inv, open(inv_path(inv["actor_id"]), "w"))

# Simple text tokenizer
def tokenize(txt: str) -> List[str]:
    out = []
    buf = []
    for ch in txt.lower():
        if ch.isalnum():
            buf.append(ch)
        else:
            if buf:
                out.append("".join(buf)); buf=[]
    if buf: out.append("".join(buf))
    return [t for t in out if len(t) >= 3]

def overlap_score(tokens_a: List[str], tokens_b: List[str]) -> float:
    A, B = set(tokens_a), set(tokens_b)
    if not A or not B: return 0.0
    inter = len(A & B)
    return inter / float(min(len(A), len(B)))

# CA lab
def seed_grid_from_text(w: int, h: int, text: str):
    grid = [[0]*w for _ in range(h)]
    bits = hashlib.sha256(text.encode("utf-8")).digest()
    idx = 0
    for y in range(h):
        for x in range(w):
            b = bits[idx % len(bits)]
            grid[y][x] = 1 if (b & (1 << (x % 8))) else 0
            idx += 1
    return grid

def step_life(grid):
    h, w = len(grid), len(grid[0])
    nxt = [[0]*w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            s = 0
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    if dy==0 and dx==0: continue
                    yy, xx = (y+dy)%h, (x+dx)%w
                    s += grid[yy][xx]
            alive = grid[y][x]==1
            if alive and (s==2 or s==3): nxt[y][x]=1
            elif not alive and s==3: nxt[y][x]=1
            else: nxt[y][x]=0
    return nxt

LABS = {}

class App(BaseHTTPRequestHandler):
    def do_POST(self):
        p = urlparse(self.path).path

        if p == "/submit":
            obj = read_json(self)
            if not obj.get("actor_id") or not obj.get("domain_claims"):
                return respond(self, 400, {"error":"missing actor_id or domain_claims"})
            rid_raw = short_id("C", obj)
            ledger.append({"type":"contribution","rid":rid_raw,"obj":obj,"ts":time.time()})
            rid, minted = engine.mint(obj)
            # reflect minted into inventory credits
            inv = ensure_inventory(obj["actor_id"])
            for k,v in minted.items():
                inv["credits"][k] = round(inv["credits"].get(k,0)+float(v),6)
            save_inventory(inv)
            return respond(self, 200, {"receipt_id":rid, "minted":minted})

        elif p == "/settle":
            obj = read_json(self)
            if "revenue_fiat" not in obj or "patterns" not in obj:
                return respond(self, 400, {"error":"missing revenue_fiat or patterns"})
            engine.settle_paid_service(obj)
            return respond(self, 200, {"status":"ok"})

        elif p == "/payout_wallet":
            data = json.load(open(os.path.join(DATA,"payout_wallet.json")))
            return respond(self, 200, data)

        elif p == "/inventory/get":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            inv = ensure_inventory(actor)
            return respond(self, 200, inv)

        elif p == "/upload":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            fn = obj.get("filename","untitled.txt")
            content = obj.get("content","")
            pid = short_id("P", {"a":actor,"fn":fn,"c":content[:200]})
            rec = {"paper_id":pid,"actor_id":actor,"filename":fn,"content":content,"tokens":tokenize(content),"ts":time.time()}
            path = os.path.join(DATA,"uploads", f"{pid}.json")
            json.dump(rec, open(path,"w"))
            ledger.append({"type":"upload","paper_id":pid,"actor":actor,"ts":time.time()})
            return respond(self, 200, {"paper_id":pid,"token_count":len(rec["tokens"])})

        elif p == "/tiles/init":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            papers = []
            for name in os.listdir(os.path.join(DATA,"uploads")):
                rec = json.load(open(os.path.join(DATA,"uploads",name)))
                if rec.get("actor_id")==actor:
                    papers.append({"paper_id":rec["paper_id"],"title":rec["filename"],"snippet":rec["content"][:160]})
            drafts = []
            for name in os.listdir(os.path.join(DATA,"drafts")):
                dr = json.load(open(os.path.join(DATA,"drafts",name)))
                if dr.get("actor_id")==actor:
                    drafts.append({"draft_id":dr["draft_id"],"title":dr["title"],"summary":dr["summary"]})
            inv = ensure_inventory(actor)
            return respond(self, 200, {"papers":papers, "drafts":drafts, "inventory":inv})

        elif p == "/tiles/combine":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            inputs = obj.get("inputs",[])
            inv = ensure_inventory(actor)
            if inv["journals"] <= 0:
                return respond(self, 400, {"error":"no journals available"})
            # Load paper tokens
            recs = []
            for pid in inputs:
                path = os.path.join(DATA,"uploads", f"{pid}.json")
                if os.path.exists(path):
                    recs.append(json.load(open(path)))
            if len(recs) < 2:
                return respond(self, 400, {"error":"need at least two papers"})
            # Suggest links
            common = set(recs[0]["tokens"])
            for r in recs[1:]:
                common &= set(r["tokens"])
            common_terms = sorted(list(common))[:24]
            # Title & summary
            title = "Synthesis: " + (" ".join(common_terms[:6]) or "New Draft")
            summary = "Auto-suggested links across: " + ", ".join([r["filename"] for r in recs])
            # Draft record
            draft = {"draft_id": short_id("D", {"a":actor,"ins":inputs,"t":title}),
                     "actor_id":actor,
                     "title":title,
                     "summary":summary,
                     "inputs":inputs,
                     "suggested_terms":common_terms,
                     "created":time.time()}
            json.dump(draft, open(os.path.join(DATA,"drafts", f"{draft['draft_id']}.json"), "w"))
            # Spend inventory
            inv["journals"] -= 1
            inv["subjournals"] = max(0, inv["subjournals"]-1)
            save_inventory(inv)
            ledger.append({"type":"combine","actor":actor,"inputs":inputs,"draft_id":draft["draft_id"],"ts":time.time()})
            return respond(self, 200, {"draft":draft, "inventory":inv})

        elif p == "/lab/run":
            obj = read_json(self)
            did = obj.get("draft_id")
            size = int(obj.get("size", 24))
            path = os.path.join(DATA,"drafts", f"{did}.json")
            if not os.path.exists(path):
                return respond(self, 404, {"error":"draft not found"})
            dr = json.load(open(path))
            text = dr["title"] + " " + " ".join(dr.get("suggested_terms",[])) + " " + dr.get("summary","")
            grid = seed_grid_from_text(size, size, text)
            sid = short_id("LAB", {"d":did, "t":time.time()})
            LABS[sid] = {"grid":grid,"draft_id":did,"tick":0}
            ledger.append({"type":"lab_start","draft_id":did,"session_id":sid,"ts":time.time()})
            return respond(self, 200, {"session_id":sid, "grid":grid, "tick":0})

        elif p == "/lab/step":
            obj = read_json(self)
            sid = obj.get("session_id")
            sess = LABS.get(sid)
            if not sess:
                return respond(self, 404, {"error":"session not found"})
            sess["grid"] = step_life(sess["grid"])
            sess["tick"] += 1
            return respond(self, 200, {"session_id":sid, "grid":sess["grid"], "tick":sess["tick"]})

        else:
            return respond(self, 404, {"error":"unknown endpoint"})

def run():
    host, port = "127.0.0.1", 8787
    print(f"CommonsLedger MVP v0.2 running at http://{host}:{port}")
    HTTPServer((host, port), App).serve_forever()

if __name__ == "__main__":
    run()
