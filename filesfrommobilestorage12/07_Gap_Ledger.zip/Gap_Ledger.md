# Gap Ledger — Best-Practice Anchors & Next Actions
P0: IDs/semver/attestations; LawPacks; Safe Cube minima; repro builds; SBOM+sign; threat model; data-class map; CI policy gate.
