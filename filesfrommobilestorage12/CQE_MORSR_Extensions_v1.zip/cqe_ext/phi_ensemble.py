
from __future__ import annotations
from typing import Dict, Any, List
import statistics

def _active_indices(overlay: Dict[str,Any]) -> List[int]:
    present = overlay["nodes"]["present"]
    return [i for i,b in enumerate(present) if (b is True) or (b==1)]

def geom_component(overlay: Dict[str,Any]) -> float:
    present = overlay["nodes"]["present"]
    phi = overlay["nodes"]["phi"]
    phases = [phi[i] for i in range(min(240,len(phi))) if present[i] and (phi[i] is not None)]
    if len(phases) < 2:
        return 0.0
    return statistics.pvariance(phases)

def parity_component(overlay: Dict[str,Any]) -> float:
    present = overlay["nodes"]["present"]
    lane = sum(1 for b in present if b) % 2
    globalp = sum(1 for b in present[:240] if b) % 2
    return float(lane + globalp)

def sparsity_component(overlay: Dict[str,Any]) -> float:
    w = overlay["nodes"]["w"]
    present = overlay["nodes"]["present"]
    return 0.001 * sum(abs(w[i]) for i in range(len(w)) if present[i])

def compute_components(overlay: Dict[str,Any]) -> Dict[str,float]:
    return {"geom": geom_component(overlay), "parity": parity_component(overlay), "sparsity": sparsity_component(overlay)}

def total_phi(components: Dict[str,float], weights: Dict[str,float]) -> float:
    return (weights.get("geom",1.0)*components["geom"] +
            weights.get("parity",1.0)*components["parity"] +
            weights.get("sparsity",0.02)*components["sparsity"])
