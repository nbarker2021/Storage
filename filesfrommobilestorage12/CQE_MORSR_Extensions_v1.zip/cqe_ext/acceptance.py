
from __future__ import annotations
from typing import Dict, Any, List
from dataclasses import dataclass, field

@dataclass
class EscrowState:
    cap: float
    remaining: float
    horizon: int
    window: List[float] = field(default_factory=list)

    def reset_stage(self):
        self.remaining = self.cap
        self.window.clear()

    def register(self, delta: float) -> None:
        self.window.append(delta)
        if len(self.window) > self.horizon:
            self.window.pop(0)

class AcceptGuard:
    def __init__(self, policy_ext: Dict[str,Any]):
        acc = policy_ext["acceptance"]
        self.eps = acc["eps_phi"]
        self.plateau_cap = acc.get("plateau_cap", 0)
        self.midpoint_parity_strict = acc.get("midpoint_requires_parity_drop", True)
        q = acc["quorum"]
        self.quorum_enabled = q.get("enabled", False)
        self.quorum_metrics = q.get("metrics", ["geom","parity","sparsity"])
        self.quorum_rule = q.get("rule","all")
        self.quorum_m = q.get("m", 2)
        e = acc["escrow"]
        self.escrow_enabled = e.get("enabled", False)
        self.escrow = EscrowState(cap=e.get("cap",0.0), remaining=e.get("cap",0.0), horizon=e.get("horizon",3))

    def _quorum_accept(self, before: Dict[str,float], after: Dict[str,float], eps: float) -> bool:
        if not self.quorum_enabled:
            return True
        votes = 0
        for k in self.quorum_metrics:
            if after[k] <= before[k] - eps:
                votes += 1
        if self.quorum_rule == "all":
            return votes == len(self.quorum_metrics)
        else:
            return votes >= self.quorum_m

    def decide(self, op_name: str, before_total: float, after_total: float,
               before_components: Dict[str,float], after_components: Dict[str,float],
               parity_before: Dict[str,float]=None, parity_after: Dict[str,float]=None) -> (bool, str):
        delta = after_total - before_total
        if after_total <= before_total - self.eps and self._quorum_accept(before_components, after_components, self.eps):
            self.escrow.register(delta)
            return True, "strict_decrease"
        if abs(delta) <= self.eps and self.plateau_cap > 0:
            self.plateau_cap -= 1
            self.escrow.register(delta)
            return True, "plateau"
        if op_name == "Midpoint" and self.midpoint_parity_strict and parity_before and parity_after:
            if (parity_after.get("lane_norm",1e9) < parity_before.get("lane_norm",1e9)) or                (parity_after.get("global_norm",1e9) < parity_before.get("global_norm",1e9)):
                if after_total <= before_total + self.eps:
                    self.escrow.register(delta)
                    return True, "parity_strict"
        if self.escrow_enabled and delta > 0 and (self.escrow.remaining - delta) >= 0:
            self.escrow.remaining -= delta
            self.escrow.register(delta)
            return True, "escrow_uphill"
        return False, "delta_increase"
