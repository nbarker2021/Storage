
from __future__ import annotations
from typing import Dict, Any

def fingerprint_radial(base: float, factor: int, stage: int) -> str:
    R = min(1.0, base * (factor ** stage))
    return f"radial:R={R:.6f}"

def fingerprint_graph(base: int, factor: int, stage: int) -> str:
    hops = int(round(base * (factor ** stage)))
    return f"graph:hops={hops}"

def pick_winner(statsA: Dict[str,Any], statsB: Dict[str,Any], selection_metric: str="strict_gain") -> str:
    a = statsA.get(selection_metric, 0.0)
    b = statsB.get(selection_metric, 0.0)
    if a > b: return "A"
    if b > a: return "B"
    if statsA.get("accepts",0) >= statsB.get("accepts",0):
        return "A"
    return "B"
