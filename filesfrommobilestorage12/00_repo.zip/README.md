# SnapLat (Code Stack) — 20250816_090408

Pure-Python reference implementation of the SnapLat concepts from our session:
E8 substrate (simplified), MDHG hashing, AGRM phi-scheduler, Shelling metrics, DTT boundary tests,
Assembly stitching with DNA, Universes, Bridges, Safe Cube, SAP mock, WavePool telemetry,
Archivist/Trails, and minimal Agents.

## Quickstart
```bash
python -m snaplat.cli.run_demo
```

## Notes
- This is a light, dependency-free stack intended for local demos and unit tests.
- Replace the simplified E8 Z^8 lattice with a true E8 basis for production.
