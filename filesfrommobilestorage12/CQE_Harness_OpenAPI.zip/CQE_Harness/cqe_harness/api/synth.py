
from typing import Any, Dict, List, Tuple
import json
from collections import Counter

def _tokenize_text(s: str)->List[str]:
    import re
    toks = re.findall(r"[A-Za-z0-9_]+", s.lower())
    return [t for t in toks if len(t)>2]

def synthesize(a: Any, b: Any)->Dict[str, Any]:
    """
    Heuristic "CQE-ish" synthesis:
    - If both tables: match on shared field names and value overlaps
    - If text: compute shared salient tokens
    - If objects: compare key sets
    Output: mapping hypotheses + a ranked "meaning guess" summary.
    """
    out: Dict[str, Any] = {"hypotheses": [], "meaning_guess": ""}
    # tables
    if isinstance(a, list) and (not a or isinstance(a[0], dict)) and isinstance(b, list) and (not b or isinstance(b[0], dict)):
        keys_a = set().union(*(row.keys() for row in a[:200])) if a else set()
        keys_b = set().union(*(row.keys() for row in b[:200])) if b else set()
        shared = sorted(list(keys_a & keys_b))
        out["hypotheses"].append({"type":"table_join_keys","keys":shared})
        # value overlap on shared keys
        overlaps = {}
        for k in shared[:10]:
            va = Counter([str(row.get(k)) for row in a[:1000]])
            vb = Counter([str(row.get(k)) for row in b[:1000]])
            common = sum((va & vb).values())
            overlaps[k] = common
        out["hypotheses"].append({"type":"value_overlap","counts":overlaps})
        out["meaning_guess"] = "Tables likely relate via keys: " + ", ".join(shared[:5])
        return out
    # objects
    if isinstance(a, dict) and isinstance(b, dict):
        ka, kb = set(a.keys()), set(b.keys())
        shared = sorted(list(ka & kb))
        out["hypotheses"].append({"type":"object_intersection","keys":shared})
        out["meaning_guess"] = "Objects share keys: " + ", ".join(shared[:8])
        return out
    # text
    sa = json.dumps(a) if not isinstance(a, (str, bytes)) else (a.decode() if isinstance(a, bytes) else a)
    sb = json.dumps(b) if not isinstance(b, (str, bytes)) else (b.decode() if isinstance(b, bytes) else b)
    ta, tb = Counter(_tokenize_text(sa)), Counter(_tokenize_text(sb))
    common = (ta & tb)
    top = [k for k,_ in common.most_common(15)]
    out["hypotheses"].append({"type":"token_overlap","tokens":top})
    out["meaning_guess"] = "Texts share salient tokens: " + ", ".join(top[:10])
    return out
