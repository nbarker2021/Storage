
import json, csv, io, re
from typing import Tuple, Any, Dict, List, Optional
from urllib.parse import urlparse
import base64

try:
    import requests
except Exception:
    requests = None

def fetch_resource(url: str) -> bytes:
    """
    Fetch a resource. Supports http(s), data: URLs, and file-like overrides via 'payload=' in body.
    If requests is unavailable or network is blocked, raise a clear error.
    """
    if url.startswith("data:"):
        # data URL; naive decode
        head, b64 = url.split(",", 1)
        if ";base64" in head:
            return base64.b64decode(b64)
        return b64.encode()
    parsed = urlparse(url)
    if parsed.scheme in ("http", "https"):
        if requests is None:
            raise RuntimeError("requests not available in this runtime. Run in your env to enable URL fetch.")
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        return r.content
    if parsed.scheme == "file":
        with open(parsed.path, "rb") as f:
            return f.read()
    # treat as raw payload already
    return url.encode()

def sniff_format(b: bytes) -> str:
    s = b.decode(errors="ignore").strip()
    if not s:
        return "empty"
    if s[:1] in ("{","["):
        try:
            json.loads(s)
            return "json"
        except Exception:
            pass
    if "\n" in s and ("," in s.splitlines()[0] or "\t" in s.splitlines()[0]):
        # csv/tsv heuristic
        head = s.splitlines()[0]
        if "\t" in head:
            return "tsv"
        return "csv"
    if re.search(r"<\s*([Hh][Tt][Mm][Ll]|[Xx][Mm][Ll])", s[:200]):
        return "html_xml"
    if re.match(r"^{.*}\s*$", s, flags=re.S):
        return "jsonish"
    return "text"

def parse_payload(b: bytes, fmt: str) -> Any:
    s = b.decode(errors="ignore")
    if fmt in ("json","jsonish"):
        try:
            return json.loads(s)
        except Exception:
            return {"raw": s}
    if fmt in ("csv","tsv"):
        delim = "," if fmt=="csv" else "\t"
        reader = csv.DictReader(io.StringIO(s), delimiter=delim)
        rows = list(reader)
        return rows
    if fmt=="html_xml":
        # very light strip to text lines
        text = re.sub(r"<[^>]+>", " ", s)
        text = re.sub(r"\s+", " ", text)
        return {"text": text[:200000]}
    return {"text": s[:200000]}

def infer_schema(obj: Any) -> Dict[str, Any]:
    """
    Infer a simple, transparent schema for the payload.
    """
    if isinstance(obj, list):
        # array of objects or scalars
        if obj and isinstance(obj[0], dict):
            fields = {}
            for row in obj[:200]:
                for k,v in row.items():
                    t = type(v).__name__
                    fields[k] = fields.get(k, set())
                    fields[k].add(t)
            fields = {k: sorted(list(v)) for k,v in fields.items()}
            return {"type":"table","fields":fields,"sample_rows":min(len(obj),5)}
        return {"type":"array","length":len(obj)}
    if isinstance(obj, dict):
        return {"type":"object","keys":sorted(list(obj.keys()))[:50]}
    return {"type":"text","length":len(str(obj))}

def ledger_schema(name: str, schema: Dict[str, Any]) -> Dict[str, Any]:
    """
    Wrap a schema into an input or output ledger description.
    """
    return {"ledger": name, "kind": schema.get("type"), "schema": schema}
