
from fastapi import FastAPI, Body
from pydantic import BaseModel
from typing import Optional, Any, Dict
from .utils import fetch_resource, sniff_format, parse_payload, infer_schema, ledger_schema
from .synth import synthesize

app = FastAPI(title="CQE Open Ingest API", version="0.1.0")

class IngestRequest(BaseModel):
    url: Optional[str] = None
    payload: Optional[str] = None
    name: str = "input"

class SynthesizeRequest(BaseModel):
    a_url: Optional[str] = None
    b_url: Optional[str] = None
    a_payload: Optional[str] = None
    b_payload: Optional[str] = None
    a_name: str = "A"
    b_name: str = "B"

@app.post("/ingest")
def ingest(req: IngestRequest)->Dict[str, Any]:
    if not (req.url or req.payload):
        return {"error":"Provide url or payload"}
    data = fetch_resource(req.url) if req.url else req.payload.encode()
    fmt = sniff_format(data)
    obj = parse_payload(data, fmt)
    schema = infer_schema(obj)
    return {"format": fmt, "schema": schema, "ledger": ledger_schema(req.name, schema)}

@app.post("/synthesize")
def synth(req: SynthesizeRequest)->Dict[str, Any]:
    if not ((req.a_url or req.a_payload) and (req.b_url or req.b_payload)):
        return {"error":"Provide both A and B (url or payload)"}
    a_bytes = fetch_resource(req.a_url) if req.a_url else req.a_payload.encode()
    b_bytes = fetch_resource(req.b_url) if req.b_url else req.b_payload.encode()
    fa = sniff_format(a_bytes); fb = sniff_format(b_bytes)
    a_obj = parse_payload(a_bytes, fa)
    b_obj = parse_payload(b_bytes, fb)
    sa = infer_schema(a_obj); sb = infer_schema(b_obj)
    syn = synthesize(a_obj, b_obj)
    return {
        "A": {"format": fa, "schema": sa, "ledger": ledger_schema(req.a_name, sa)},
        "B": {"format": fb, "schema": sb, "ledger": ledger_schema(req.b_name, sb)},
        "synthesis": syn
    }
