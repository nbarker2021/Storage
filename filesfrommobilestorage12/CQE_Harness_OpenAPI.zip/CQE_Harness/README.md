# CQE Harness (Reality + Simulation)

A minimal, deterministic harness to test Cartan Quadratic Equivalence (CQE) invariants across toy grids, a 3-body adapter with octad faces, and a CQE-style image roundtrip transform.

## Install
Python 3.9+
```bash
pip install numpy
```

## Run
```bash
python -m cqe_harness.cli --json
```

## What it checks
- **Invariants:** rotation invariance, canonicalization idempotence, deterministic ledger replay.
- **Three-body lockstep:** momentum conservation across an octad-face rotation event.
- **Image roundtrip:** parity-overlay RLE roundtrip equals original (lossless toy).

## Extend
- Add adapters under `cqe_harness/adapters/` to map other domains (proteins, linguistics, braids).
- Add tests under `cqe_harness/tests/` following the `run()` signature.
- Use `docs/HowTo_Build_Failure_Tests.md` to craft adversarial cases.

## Disclaimer
This is a didactic, compact harness. Replace toy physics and codec modules with domain-accurate implementations for research use.


## Falsifier Suite (wired in CLI)
Runs the following additional tests:
- Cosmology: `cosmo_cmb` (CMB-like toy spectrum, flatness, baryon sign, dark residue)
- Quantum: `quantum_bell` (CHSH-like S, decoherence series)
- Thermodynamics: `thermo_entropy` (S_CQE, ΔE)
- Information theory: `info_bounds` (compression lower bound, Kolmogorov hint)
- Linguistics: `linguistics_parse` (ambiguity reduction, proto-merge token)
- Biology: `biology_folding` (stability score, DNA-like pitch)
- Computation: `computation_superperm` (embedding exists, gate count)
- Mathematics: `math_godel_lattice` (Gödel-safe closure, E8/Leech admissibility)


## Open Ingest API
A lightweight FastAPI app that:
- Ingests any open-source URL or raw payload
- Infers an **input ledger schema**
- Produces an **output ledger schema**
- Synthesizes A↔B approximate relations (keys, tokens, overlaps)

Run:
```bash
pip install fastapi uvicorn requests
uvicorn cqe_harness.api.app:app --reload --port 8000
```

Endpoints:
- `POST /ingest` with `{ "url": "...", "name": "X" }` or `{ "payload": "...", "name": "X" }`
- `POST /synthesize` with `{ "a_url": "...", "b_url": "..." }` or payload fields
