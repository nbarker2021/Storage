# CQE Master v1.2

This bundle contains a working, non-stubbed scaffold for running CQE-style analyses:
- 64 sidecars with octet/mirror/surround semantics
- Ready-made viewers (8×8 local, 4×4×4×4 surrounds, parity shells)
- Domain playbooks (QCHEM, SPINTRONICS, PLASMA, LIGHT_QED, HEAT_ENTROPY)
- Hot-zone detectors and corrective caps/nudges
- Governance/safety policy
- Demo receipts with hashes

## How to Use (conceptual)
1. Pick a domain playbook from `playbooks.json`.
2. Load stand-in tokens (data placeholders) for your case.
3. Run the octet of views and the palindromic mirror test.
4. Apply Δ-lifts until debts are monotone decreasing.
5. Tighten strict thresholds.
6. Commit a 4-bit receipt row with a page hash of the evidence.

No dangerous details are included; all physics/biology content is abstracted to dimensionless receipts.
