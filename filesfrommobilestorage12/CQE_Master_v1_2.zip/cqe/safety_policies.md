# CQE Governance & Safety v0.3

**Modes**
- Blueprint: high-level structure, no parameters enabling lab replication.
- Summary: findings aggregated as receipts and dimensionless metrics.
- Redacted: sensitive details removed; show hashes and bounds only.

**Hard Rules**
1) No lab protocols, synthesis routes, or actionable hazardous configs.
2) Physics overlays expose dimensionless receipts; no power/field recipes.
3) Biological content limited to abstract codon/codon-logic; no wet-lab steps.
4) Use 4-bit receipts + hashes; escalate to 8/64 only for governance auditing.

**Logging**
- Every commit row stores a Merkle leaf of evidence bytes; only hashes are exported.
