from typing import List, Tuple
from .schemas import FuturesGrid, Settings, Orders
import collections

def settings_from_futures(fut: FuturesGrid) -> Settings:
    S0 = [[None]*4 for _ in range(32)]
    for r in range(32):
        S0[r][0] = fut.Q1_main_to_parity_A[r]
        S0[r][1] = fut.Q2_main_to_parity_B[r]
        S0[r][2] = fut.Q3_parity_to_main_A[r]
        S0[r][3] = fut.Q4_parity_to_main_B[r]

    cols = list(zip(*S0))
    cols_alt = []
    for c, col in enumerate(cols):
        dq = collections.deque(col)
        dq.rotate(c)
        cols_alt.append([63 - x for x in list(dq)])
    S1 = [list(row) for row in zip(*cols_alt)]
    return Settings(S0_IRL=S0, S1_Alt=S1)

def four_orders(settings: Settings) -> Orders:
    def rr(cols):
        out = []
        for i in range(32):
            for c in range(4):
                out.append(cols[i][c])
        return out
    def to_perm(seq):
        seen=set(); out=[]
        for x in seq:
            if x not in seen:
                out.append(x); seen.add(x)
        i=0
        while len(out)<64:
            if i not in seen:
                out.append(i); seen.add(i)
            i+=1
        return out[:64]

    G1 = to_perm(rr(settings.S0_IRL))
    G2 = to_perm(rr(settings.S1_Alt))
    S0M = [[63 - x for x in row] for row in settings.S0_IRL]
    S1M = [[63 - x for x in row] for row in settings.S1_Alt]
    G3 = to_perm(rr(S0M))
    G4 = to_perm(rr(S1M))
    return Orders(G1_S0_IRL=G1, G2_S1_Alt=G2, G3_S0_IRL_Mirror=G3, G4_S1_Alt_Mirror=G4)
