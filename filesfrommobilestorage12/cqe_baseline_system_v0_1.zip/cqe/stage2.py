from typing import List, Dict
from .schemas import Stage1Layout, FuturesGrid, Stage2Seed, Bucket
from .kgrams.debruijn import kgram_stream, earliest_meeting_time

def _meeting_times(labels_src: List[str], labels_dst: List[str], k=5, steps=512) -> List[float]:
    times = []
    for a,b in zip(labels_src, labels_dst):
        M = kgram_stream(a, k=k, steps=steps)
        P = kgram_stream(b, k=k, steps=steps)
        times.append(earliest_meeting_time(M,P))
    return times

def futures_and_questions(s1: Stage1Layout) -> FuturesGrid:
    m2p = _meeting_times([b.label for b in s1.main], [b.label for b in s1.parity])
    p2m = _meeting_times([b.label for b in s1.parity], [b.label for b in s1.main])
    ids = list(range(64))
    order_m2p = [i for i,_ in sorted(enumerate(m2p), key=lambda t:t[1])]
    order_p2m = [i for i,_ in sorted(enumerate(p2m), key=lambda t:t[1])]
    A_m2p = order_m2p[0::2][:32]
    B_m2p = order_m2p[1::2][:32]
    A_p2m = order_p2m[0::2][:32]
    B_p2m = order_p2m[1::2][:32]

    return FuturesGrid(
        Q1_main_to_parity_A=A_m2p,
        Q2_main_to_parity_B=B_m2p,
        Q3_parity_to_main_A=A_p2m,
        Q4_parity_to_main_B=B_p2m,
        meeting_times={"m2p":m2p, "p2m":p2m}
    )

def stage2_seed_from_futures(s1: Stage1Layout, fut: FuturesGrid) -> Stage2Seed:
    def mk(seed_from: List[Bucket], orig: List[int]) -> List[Bucket]:
        out = []
        for i in range(64):
            b0 = seed_from[i]
            b = Bucket(bucket_id=i, label=b0.label, is_parity=b0.is_parity, mirror_id=b0.mirror_id)
            out.append(b)
        return out
    main64 = mk(s1.main, fut.Q1_main_to_parity_A)
    parity64 = mk(s1.parity, fut.Q3_parity_to_main_A)
    return Stage2Seed(main64=main64, parity64=parity64)
