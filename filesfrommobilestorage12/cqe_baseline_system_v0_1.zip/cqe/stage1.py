from typing import List, Dict, Any
from .schemas import Bucket, Stage1Layout
from .playbook import MIRROR
from .utils import label_source
from .receipts.merkle import merkle_leaf

def explode_to_64(request_text: str) -> List[str]:
    import re
    toks = [t for t in re.split(r'[^A-Za-z0-9]+', request_text) if t]
    if not toks:
        toks = ["seed"]
    uniq = []
    seen = set()
    for t in toks:
        k = t.lower()
        if k not in seen:
            uniq.append(t)
            seen.add(k)
        if len(uniq) >= 64:
            break
    while len(uniq) < 64:
        uniq.append(f"filler_{len(uniq)}")
    return uniq[:64]

def make_buckets(labels: List[str], parity_labels: List[str]) -> Stage1Layout:
    main = []
    parity = []
    for i, L in enumerate(labels):
        b = Bucket(bucket_id=i, label=L, is_parity=False, mirror_id=MIRROR(i))
        b.receipts["label"] = {"text": L, **label_source("derived")}
        b.receipts["leaf"] = merkle_leaf({"bucket_id": i, "label": L})
        main.append(b)
    for i, L in enumerate(parity_labels):
        b = Bucket(bucket_id=i, label=L, is_parity=True, mirror_id=MIRROR(i))
        b.receipts["label"] = {"text": L, **label_source("derived")}
        b.receipts["leaf"] = merkle_leaf({"bucket_id": i, "label": L, "parity": True})
        parity.append(b)
    return Stage1Layout(main=main, parity=parity)

def stage1_from_request(req: str) -> Stage1Layout:
    L = explode_to_64(req)
    P = [f"{x}_alt" for x in L]
    return make_buckets(L, P)
