from typing import List, Any, Tuple
from .hashers import blake2b256_hex

def merkle_leaf(obj: Any) -> str:
    return blake2b256_hex(obj)

def merkle_tree_hash(leaves_hex: List[str]) -> Tuple[str, List[Tuple[str,str]]]:
    """Return root hash and list of (left,right) pairs as proof nodes."""
    if not leaves_hex:
        return blake2b256_hex("EMPTY"), []
    layer = leaves_hex[:]
    proofs = []
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            if i+1 < len(layer):
                pair = (layer[i], layer[i+1])
            else:
                pair = (layer[i], layer[i])
            combined = blake2b256_hex({"L":pair[0], "R":pair[1]})
            proofs.append(pair)
            nxt.append(combined)
        layer = nxt
    return layer[0], proofs
