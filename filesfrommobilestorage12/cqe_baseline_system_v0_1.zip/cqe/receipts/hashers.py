import json, hashlib
from typing import Any, Dict

def json_c14n(obj: Any) -> str:
    # Simple canonicalizer: sort keys, no spaces, ensure tuples become lists deterministically
    def normalize(o):
        if isinstance(o, dict):
            return {k: normalize(o[k]) for k in sorted(o.keys())}
        if isinstance(o, (list, tuple)):
            return [normalize(x) for x in o]
        return o
    norm = normalize(obj)
    return json.dumps(norm, separators=(',', ':'), ensure_ascii=False)

def blake2b256_hex(obj: Any) -> str:
    c = json_c14n(obj).encode('utf-8')
    return hashlib.blake2b(c, digest_size=32).hexdigest()
