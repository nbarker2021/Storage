from typing import Any, Dict
from .receipts.hashers import blake2b256_hex

def label_source(tag: str) -> Dict[str, Any]:
    return {"label_source": tag}

def reason(code: str, detail: Dict[str,Any]) -> Dict[str,Any]:
    return {"code": code, "detail": detail, "hash": blake2b256_hex(detail)}
