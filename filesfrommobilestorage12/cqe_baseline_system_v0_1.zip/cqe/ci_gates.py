from typing import Dict, Any, List, Tuple
from .math.e8 import is_in_e8, snap_with_receipt
from .math.golay24 import is_codeword
from .math.leech import is_leech_member, lift_to_leech

def G_cardinality(main_count:int, parity_count:int, octet_shape:Tuple[int,int]) -> Tuple[bool, Dict[str,Any]]:
    ok = (main_count==64 and parity_count==64 and octet_shape==(8,8))
    return ok, {"expected":{"main":64,"parity":64,"octets":"8x8"}, "got":{"main":main_count,"parity":parity_count,"octets":f"{octet_shape[0]}x{octet_shape[1]}"}}

def G_parity(bucket_id:int, mirror_id:int) -> Tuple[bool, Dict[str,Any]]:
    ok = (mirror_id == 63 - bucket_id)
    return ok, {"bucket_id":bucket_id, "mirror_id":mirror_id}

def G_receipts_present(bucket_receipts:Dict[str,Any]) -> Tuple[bool, Dict[str,Any]]:
    keys = ("label","leaf")
    ok = all(k in bucket_receipts for k in keys)
    return ok, {"required":keys, "has":list(bucket_receipts.keys())}

def G_24_lock(core24_bits:List[int]) -> Tuple[bool, Dict[str,Any]]:
    ok = is_codeword(core24_bits)
    return ok, {"core24_is_golay":ok}

def G_24_lock_leech(core24_ints:List[int]) -> Tuple[bool, Dict[str,Any]]:
    ok = is_leech_member(core24_ints)
    return ok, {"leech_member":ok}

def G_diagonals(rows:int, cols:int) -> Tuple[bool, Dict[str,Any]]:
    ok = (rows==32 and cols==4)
    return ok, {"rows":rows, "cols":cols}

def G_octet(octet8:List[float]) -> Tuple[bool, Dict[str,Any]]:
    ok = is_in_e8(octet8)
    if not ok:
        snapped, rec = snap_with_receipt(octet8)
        return False, {"in_e8":False, "snap_receipt":rec}
    return True, {"in_e8":True}

def leech_lift_receipt(vec24:List[float]):
    x, rec = lift_to_leech(vec24)
    return x, rec
