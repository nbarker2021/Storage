from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field

@dataclass
class Bucket:
    bucket_id: int                 # 0..63
    label: str
    is_parity: bool
    mirror_id: int                 # 63 - bucket_id
    octets: List[List[Any]] = field(default_factory=lambda: [[None]*8 for _ in range(8)])
    receipts: Dict[str, Any] = field(default_factory=dict)   # merkle paths, kgram ids, etc.

@dataclass
class Stage1Layout:
    main: List[Bucket]
    parity: List[Bucket]

@dataclass
class FuturesGrid:
    # four 32-id queues; each id is 0..63 from the origin set indicated by direction
    Q1_main_to_parity_A: List[int]
    Q2_main_to_parity_B: List[int]
    Q3_parity_to_main_A: List[int]
    Q4_parity_to_main_B: List[int]
    meeting_times: Dict[str, List[float]]  # per bucket meeting t or inf (strings for direction keys)

@dataclass
class Stage2Seed:
    main64: List[Bucket]
    parity64: List[Bucket]

@dataclass
class Settings:
    S0_IRL: List[List[int]]  # 32x4 grid of bucket ids
    S1_Alt: List[List[int]]  # rotated/ mirrored as per playbook

@dataclass
class Orders:
    G1_S0_IRL: List[int]
    G2_S1_Alt: List[int]
    G3_S0_IRL_Mirror: List[int]
    G4_S1_Alt_Mirror: List[int]
