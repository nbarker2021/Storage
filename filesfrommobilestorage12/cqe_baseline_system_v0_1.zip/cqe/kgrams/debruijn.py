from typing import List
import hashlib, re, collections

def kgram_stream(label: str, k:int=5, steps:int=512) -> List[str]:
    s = re.sub(r'[^a-z0-9]+','',label.lower())
    if len(s) < k:
        pad = hashlib.blake2b(s.encode(), digest_size=16).hexdigest()
        s = (s + pad)[:k]
    seq = []
    i = 0
    buf = s
    for _ in range(steps):
        seq.append(buf[i:i+k])
        i = (i+1) % (len(buf)-k+1)
        if i == 0:
            h = int(hashlib.blake2b(buf.encode(), digest_size=2).hexdigest(),16)
            rot = 1 + (h % max(1, len(buf)-1))
            buf = buf[rot:] + buf[:rot]
    return seq

def earliest_meeting_time(a: List[str], b: List[str]) -> float:
    L = min(len(a), len(b))
    for t in range(L):
        if a[t] == b[t]:
            return float(t)
    return float('inf')
