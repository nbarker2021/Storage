# Constants per master playbook
MIRROR = lambda i: 63 - i
LANE = lambda p: p % 8
DIAG = lambda r,c: ((r+1) % 32, (c+1) % 4)

CORE24 = lambda xs: xs[:24]
FRINGE8 = lambda xs: xs[24:32]
