import argparse, json, os
from cqe.stage1 import stage1_from_request
from cqe.stage2 import futures_and_questions
from cqe.stage3 import settings_from_futures, four_orders
from cqe.ci_gates import G_cardinality, G_diagonals
from cqe.utils import reason

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--request", required=True)
    ap.add_argument("--outdir", default="runs/step3")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    s1 = stage1_from_request(args.request)
    fut = futures_and_questions(s1)
    sets = settings_from_futures(fut)
    orders = four_orders(sets)

    g_card_ok, g_card_info = G_cardinality(len(s1.main), len(s1.parity), (8,8))
    g_diag_ok, g_diag_info = G_diagonals(32,4)
    gate_report = {
        "G_cardinality": {"ok": g_card_ok, "reason": reason("G_cardinality", g_card_info)},
        "G_diagonals": {"ok": g_diag_ok, "reason": reason("G_diagonals", g_diag_info)}
    }

    with open(os.path.join(args.outdir,"settings.json"),"w") as f:
        json.dump({"S0_IRL":sets.S0_IRL, "S1_Alt":sets.S1_Alt}, f, indent=2)
    with open(os.path.join(args.outdir,"orders.json"),"w") as f:
        json.dump(orders.__dict__, f, indent=2)
    with open(os.path.join(args.outdir,"gates.json"),"w") as f:
        json.dump(gate_report, f, indent=2)

    print("Step3 complete:", args.outdir)

if __name__ == "__main__":
    main()
