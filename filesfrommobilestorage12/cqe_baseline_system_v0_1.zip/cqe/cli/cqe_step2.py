import argparse, json, os
from cqe.stage1 import stage1_from_request
from cqe.stage2 import futures_and_questions, stage2_seed_from_futures

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--request", required=True)
    ap.add_argument("--outdir", default="runs/step2")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    s1 = stage1_from_request(args.request)
    fut = futures_and_questions(s1)
    s2 = stage2_seed_from_futures(s1, fut)

    with open(os.path.join(args.outdir,"stage1.json"),"w") as f:
        json.dump({"main":[b.__dict__ for b in s1.main],
                   "parity":[b.__dict__ for b in s1.parity]}, f, indent=2)
    with open(os.path.join(args.outdir,"futures.json"),"w") as f:
        json.dump(fut.__dict__, f, indent=2)
    with open(os.path.join(args.outdir,"stage2_seed.json"),"w") as f:
        json.dump({"main":[b.__dict__ for b in s2.main64],
                   "parity":[b.__dict__ for b in s2.parity64]}, f, indent=2)

    print("Step2 complete:", args.outdir)

if __name__ == "__main__":
    main()
