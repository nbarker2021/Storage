import argparse, json, os
from cqe.stage1 import stage1_from_request
from cqe.stage2 import futures_and_questions

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--request", required=True)
    ap.add_argument("--outdir", default="runs/plan")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    s1 = stage1_from_request(args.request)
    fut = futures_and_questions(s1)

    with open(os.path.join(args.outdir,"stage1.json"),"w") as f:
        json.dump({"main":[b.__dict__ for b in s1.main],
                   "parity":[b.__dict__ for b in s1.parity]}, f, indent=2)

    with open(os.path.join(args.outdir,"futures.json"),"w") as f:
        json.dump(fut.__dict__, f, indent=2)
    print("Plan ready:", args.outdir)

if __name__ == "__main__":
    main()
