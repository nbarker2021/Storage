from typing import List
import numpy as np
from .math.golay24 import syndrome
from .math.leech import lift_to_leech

def order_core24_blocks(blocks: List[List[int]], embeddings: List[List[float]]) -> List[int]:
    scores = []
    for i,(b, y) in enumerate(zip(blocks, embeddings)):
        s = syndrome(b)
        sw = int(np.count_nonzero(s))
        _, rec = lift_to_leech(np.array(y, dtype=float))
        e = rec["delta2"]
        scores.append((sw, e, i))
    scores.sort()
    return [i for _,_,i in scores]
