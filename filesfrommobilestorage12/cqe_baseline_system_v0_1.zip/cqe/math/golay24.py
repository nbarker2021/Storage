import numpy as np
from functools import lru_cache

def mod2(x): return np.asarray(x, dtype=np.uint8) & 1

# Standard extended binary Golay [24,12,8] parity-check (12x24).
H_ROWS = [
  "111100000000111100000000",
  "110011000000110011000000",
  "101010100000101010100000",
  "100001110000100001110000",
  "011110000000011110000000",
  "010101000000010101000000",
  "001100110000001100110000",
  "000111000000000111000000",
  "000000111100000000111100",
  "000000110011000000110011",
  "000000101010000000101010",
  "000000100001000000100001",
]
H = np.array([[int(b) for b in row] for row in H_ROWS], dtype=np.uint8)  # 12x24

def syndrome(v):
    v = mod2(v).reshape(24,)
    s = mod2(H @ v)
    return s  # 12 bits

def is_codeword(v):
    return np.count_nonzero(syndrome(v)) == 0

def encode(m):
    v = np.zeros(24, dtype=np.uint8)
    v[:12] = mod2(m)
    c, _, _ = decode(v)
    return c

from itertools import combinations

@lru_cache(maxsize=1)
def _coset_table():
    table = {tuple([0]*12): np.zeros(24, dtype=np.uint8)}
    cols = list(range(24))
    def s_of(err):
        return tuple(mod2(H @ err))
    # w=1
    for i in cols:
        e = np.zeros(24, dtype=np.uint8); e[i]=1
        table.setdefault(s_of(e), e)
    # w=2
    for i,j in combinations(cols,2):
        e = np.zeros(24, dtype=np.uint8); e[i]=1; e[j]=1
        s = s_of(e)
        if s not in table:
            table[s]=e
    # w=3
    for i,j,k in combinations(cols,3):
        e = np.zeros(24, dtype=np.uint8); e[i]=e[j]=e[k]=1
        s = s_of(e)
        if s not in table:
            table[s]=e
    return table

def decode(v):
    v = (np.asarray(v, dtype=np.uint8) & 1).reshape(24,)
    s = tuple(syndrome(v))
    table = _coset_table()
    if s in table:
        e = table[s]
        c = (v ^ e) & 1
        return c, e, np.array(s, dtype=np.uint8)
    return v, np.zeros(24, dtype=np.uint8), np.array(s, dtype=np.uint8)
