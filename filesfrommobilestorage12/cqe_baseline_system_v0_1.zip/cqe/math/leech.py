import numpy as np
from .golay24 import syndrome, decode, is_codeword

def construction_A_lift(y24: np.ndarray):
    y = np.asarray(y24, dtype=float).reshape(24,)
    r = np.round(y).astype(int)
    v2 = (r & 1).astype(np.uint8)
    c2, e, s = decode(v2)
    mismatch = np.where(c2 != v2)[0]
    x = r.copy()
    for i in mismatch:
        up = abs((x[i]+1) - y[i]); dn = abs((x[i]-1) - y[i])
        x[i] = x[i]+1 if up <= dn else x[i]-1
    if (np.sum(x) % 2) != 0:
        i = int(np.argmin(np.abs(x - y)))
        x[i] += 1 if (y[i] - x[i]) > 0 else -1
    receipt = {
        "input": y.tolist(),
        "rounded": r.tolist(),
        "golay_syndrome": s.astype(int).tolist(),
        "golay_codeword": c2.astype(int).tolist(),
        "parity_fix_indices": mismatch.tolist(),
        "output": x.tolist(),
        "delta2": float(np.sum((x - y)**2))
    }
    return x, receipt

def is_leech_member(x24: np.ndarray) -> bool:
    x = np.asarray(x24, dtype=int).reshape(24,)
    if (np.sum(x) % 2) != 0:
        return False
    return is_codeword((x & 1).astype(np.uint8))

def lift_to_leech(y24: np.ndarray):
    return construction_A_lift(y24)
