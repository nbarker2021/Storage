import numpy as np
from typing import Tuple, Dict

def _parity_even(z: np.ndarray) -> bool:
    return (np.sum(z) % 2) == 0

def nearest_e8(y: np.ndarray) -> np.ndarray:
    """
    Snap R^8 vector y to nearest E8 lattice point using two-coset nearest-plane:
    Coset A: z ∈ Z^8 with even coordinate sum.
    Coset B: z ∈ (Z+0.5)^8 with odd (z-0.5) sum.
    """
    y = np.asarray(y, dtype=float).reshape(8,)
    # Coset A
    zA = np.round(y)
    if not _parity_even(zA):
        i = np.argmin(np.abs(y - zA))
        zA[i] += 1 if (y[i] - zA[i]) > 0 else -1
    dA = np.sum((y - zA) ** 2)
    # Coset B
    yB = y - 0.5
    zB = np.round(yB) + 0.5
    if _parity_even(zB - 0.5):
        i = np.argmin(np.abs(yB - np.round(yB)))
        zB[i] += 1 if (yB[i] - np.round(yB)[i]) > 0 else -1
    dB = np.sum((y - zB) ** 2)
    return zA if dA <= dB else zB

def is_in_e8(x: np.ndarray) -> bool:
    x = np.asarray(x, dtype=float).reshape(8,)
    frac = np.mod(x, 1.0)
    if np.allclose(frac, 0.0):
        return _parity_even(np.round(x))
    if np.allclose(frac, 0.5):
        return not _parity_even(np.round(x - 0.5))
    return False

def snap_with_receipt(y: np.ndarray) -> Tuple[np.ndarray, Dict]:
    x = nearest_e8(y)
    coset = "Z_even" if np.allclose(np.mod(x,1.0), 0.0) else "Z+1/2_odd"
    return x, {
        "input": y.tolist(),
        "output": x.tolist(),
        "coset": coset,
        "delta2": float(np.sum((x - y)**2))
    }
