from typing import Dict, Any
from .safecube import faces_green, gate_1729

def sentinel_attest(obj: Dict[str, Any]) -> bool:
    return obj is not None

def arbiter_decide(case: Dict[str, Any]) -> Dict[str, Any]:
    ok_faces = faces_green(case.get("safe_cube", {}))
    ok_1729 = case.get("high_assurance", False) == False or gate_1729(case.get("evidence_nodes", 0))
    allow = ok_faces and ok_1729
    return {"decision": "allow" if allow else "deny", "reason": "faces/1729" if not allow else ""}

def porter_lane(posture: str) -> str:
    p = (posture or "").lower()
    if p == "public": return "public"
    if p == "partner": return "partner"
    return "internal"
