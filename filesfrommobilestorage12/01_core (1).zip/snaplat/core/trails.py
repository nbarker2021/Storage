import time, json, pathlib
from typing import Dict, Any

class Trails:
    def __init__(self, path: str):
        self.path = pathlib.Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists(): self.path.write_text("", encoding="utf-8")

    def emit(self, event: Dict[str, Any]) -> None:
        event = dict(event); event.setdefault("ts", time.time())
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, sort_keys=True) + "\n")
