from typing import List, Dict, Any
from .e8 import barymix, norm2
from .ids import decision_hash

def stitch(points: List[List[float]], weights: List[float], sources: List[str], closure: Dict[str, float]=None) -> Dict[str, Any]:
    pos = barymix(points, weights)
    dna = {
        "sources": sources,
        "e8": {"mix": {"weights": weights, "method": "barymix"}},
        "closure_metrics": closure or {},
    }
    dna["id"] = "dna:" + decision_hash(dna)[:16]
    return {"position": pos, "dna": dna}

def replay_ok(dna: Dict[str, Any], points: List[List[float]], weights: List[float]) -> bool:
    return dna.get("e8", {}).get("mix", {}).get("weights") == weights
