
"""
unibeam_dualrail_harness_v2.py
Numeric‑tolerant identity check, fail‑closed policy, and parameterized NSL.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import json, math, hashlib
from typing import List, Dict, Any, Tuple
import numpy as np

def _sha(arr: np.ndarray) -> str:
    return hashlib.sha256(np.asarray(arr, dtype=np.float32).tobytes()).hexdigest()

@dataclass
class IdentityFamily:
    idx: np.ndarray
    anchor_slice: np.ndarray
    anchor_hash: str
    tol: float = 1e-5
    @classmethod
    def from_vector(cls, indices: np.ndarray, vec: np.ndarray, tol: float=1e-5) -> "IdentityFamily":
        idx = np.array(sorted(set(indices.tolist())), dtype=int)
        sl = vec[idx].copy()
        return cls(idx=idx, anchor_slice=sl, anchor_hash=_sha(sl), tol=tol)
    def enforce(self, v: np.ndarray) -> np.ndarray:
        out = v.copy(); out[self.idx] = self.anchor_slice
        return out / (np.linalg.norm(out)+1e-9)
    def equal(self, v: np.ndarray) -> bool:
        return np.linalg.norm(v[self.idx]-self.anchor_slice) < self.tol

@dataclass
class NSLBudget:
    temperature: float = 300.0
    kB: float = 1.380649e-23
    # number of bits erased (proxy) in this step when ECC applied
    bits_erased: int = 0
    def sectors(self, err_before: float, err_after: float, used_ecc: bool=False) -> Tuple[float,float,float,float]:
        dN = 0.0  # symmetry penalty can be made task‑dependent
        dI = -(max(0.0, err_before - err_after))  # DPI slack proxy
        dL = -(self.kB*self.temperature*math.log(2))* (self.bits_erased if used_ecc else 0)
        return dN, dI, dL, dN + dI + dL

class Unibeam:
    def __init__(self, dim: int=128, fam_width: int=32, noise: float=0.02, tri_tau: float=0.92, err_thresh: float=0.05, tol: float=1e-5, seed: int=17):
        self.dim = dim
        self.rng = np.random.default_rng(seed)
        self.Psi = self._rand_unit()
        fam_idx = np.arange(fam_width)
        self.idf = IdentityFamily.from_vector(fam_idx, self.Psi, tol=tol)
        self.Psi = self.idf.enforce(self.Psi)
        self.M_axis = self._rand_unit(); self.T_axis = self._rand_unit()
        self.noise = noise; self.tri_tau = tri_tau; self.err_thresh = err_thresh
        self.nsl = NSLBudget()
        self.receipts: List[Dict[str,Any]] = []
        self.halted = False
    def _rand_unit(self) -> np.ndarray:
        v = self.rng.normal(0,1,size=self.dim).astype(np.float32)
        return v/(np.linalg.norm(v)+1e-9)
    def _reflect(self, v: np.ndarray, axis: np.ndarray) -> np.ndarray:
        a = axis/(np.linalg.norm(axis)+1e-9)
        return (v - 2.0*(v.dot(a))*a).astype(np.float32)
    def _rotate_90(self, v: np.ndarray, axis: np.ndarray) -> np.ndarray:
        a = axis/(np.linalg.norm(axis)+1e-9)
        va = (v.dot(a))*a; vo = v - va
        if np.linalg.norm(vo) < 1e-12: vo = self._rand_unit() - va
        vo = vo/(np.linalg.norm(vo)+1e-9)
        v90 = va + vo
        return v90/(np.linalg.norm(v90)+1e-9)
    def tri_probe(self) -> Dict[str,Any]:
        cues = [self._rand_unit() for _ in range(3)]
        angles = [float(np.arccos(np.clip(self.Psi.dot(c), -1, 1))) for c in cues]
        spread = float(np.std(angles))
        rank = float(np.exp(-spread))
        ids = [hashlib.sha1(c.tobytes()).hexdigest()[:8] for c in cues]
        return {"witness_ids": ids, "pose_residual": float(np.median(angles)), "rank": rank}
    def quad_sweep(self) -> Tuple[int, np.ndarray, float]:
        def curv(e): return float(np.linalg.norm(self.Psi - e))
        e0 = self.Psi
        e90 = self._rotate_90(self.Psi, self.T_axis)
        e180 = self._reflect(self.Psi, self.M_axis)
        e270 = self._rotate_90(e90, self.T_axis)
        candidates = [(0,e0,curv(e0)), (90,e90,curv(e90)), (180,e180,curv(e180)), (270,e270,curv(e270))]
        angle, eff, phi = min(candidates, key=lambda z:z[2])
        gain = float(curv(self.Psi) - phi)
        return angle, eff, gain
    def ecc_gauge(self, target: np.ndarray) -> np.ndarray:
        comp_idx = np.setdiff1d(np.arange(self.dim), self.idf.idx)
        comp = 0.8*self.Psi[comp_idx] + 0.2*target[comp_idx]
        out = target.copy(); out[comp_idx] = comp
        return out/(np.linalg.norm(out)+1e-9)
    def step(self, k: int, rail: str) -> Dict[str,Any]:
        if self.halted:
            return {"step": k, "rail": rail, "outcome": "halted"}
        assert rail in ("forward","adjoint")
        evidence = self.Psi + (self.noise if rail=="forward" else self.noise)*self._rand_unit()
        evidence = evidence/(np.linalg.norm(evidence)+1e-9)
        tri = self.tri_probe()
        use_quad = tri["rank"] < self.tri_tau
        chosen = None; gain = 0.0
        cand = evidence
        if use_quad:
            chosen, cand, gain = self.quad_sweep()
        err0 = float(np.linalg.norm(self.Psi - cand))
        cand = self.idf.enforce(cand); id_equal = self.idf.equal(cand)
        used_ecc = False
        if err0 > self.err_thresh and id_equal:
            cand2 = self.ecc_gauge(cand)
            err1 = float(np.linalg.norm(self.Psi - cand2))
            if err1 < err0*(1.0-0.2):
                used_ecc = True; cand = cand2; err0 = err1
        dN,dI,dL,dphi = self.nsl.sectors(err_before=1.0, err_after=1.0-err0, used_ecc=used_ecc)
        outcome = "commit" if (dphi <= 0 and id_equal) else "refuse"
        if outcome == "commit":
            self.Psi = cand
        else:
            # Fail-closed: stop further steps on first identity/budget violation
            self.halted = True
        rec = {
            "step": k, "rail": rail, "tri": tri,
            "quad": {"used": use_quad, "chosen": chosen, "delta_phi_gain": gain},
            "idf": {"equal": id_equal, "tol": self.idf.tol},
            "errs": {"err_proxy": err0},
            "sectors": {"dNoether": dN, "dShannon": dI, "dLandauer": dL},
            "delta_phi": dphi, "outcome": outcome
        }
        self.receipts.append(rec); return rec
    def closure_certificate(self) -> Dict[str,Any]:
        sum_forward = sum(r.get("delta_phi",0.0) for r in self.receipts if r.get("rail")=="forward")
        sum_adjoint = sum(r.get("delta_phi",0.0) for r in self.receipts if r.get("rail")=="adjoint")
        id_equal = all(r.get("idf",{}).get("equal",False) for r in self.receipts if r.get("outcome")!="halted")
        return {"idf_equal": id_equal, "sum_delta_phi_forward": sum_forward, "sum_delta_phi_adjoint": sum_adjoint, "reality": (id_equal and (sum_forward + sum_adjoint) <= 0.0)}
if __name__ == "__main__":
    ub = Unibeam(dim=128, fam_width=32, noise=0.02, tri_tau=0.92, err_thresh=0.05, tol=1e-5, seed=42)
    for k in range(1, 401):
        ub.step(k, rail="forward")
        ub.step(k, rail="adjoint")
        if ub.halted: break
    cert = ub.closure_certificate()
    with open("unibeam_v2_receipts.jsonl","w") as f:
        for r in ub.receipts: f.write(json.dumps(r)+"\n")
    with open("unibeam_v2_closure.json","w") as f:
        json.dump(cert, f, indent=2)
    print(json.dumps(cert, indent=2))
