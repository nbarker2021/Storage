# CQE Master v1.1
What’s new:
- 64-rail sidecar catalog
- Viewers with light/sound/heat overlays + Cartan snaps
- Extra playbooks (QuantumChemistry, Spintronics, Plasma, Light, Heat)
- Hotzone caps/nudges incl. n=4→5 hinge
- Governance v0.3

Quickstart:
1) Load `viewers.json` and `sidecars_catalog.json`.
2) Pick a playbook and run octet→mirror→Δ-lift→strict.
3) Stamp `receipts_demo.csv` using `receipt_abi.json` and attach evidence hashes.
4) If detectors fire, apply `hotzones.json` caps/nudges and replay.
