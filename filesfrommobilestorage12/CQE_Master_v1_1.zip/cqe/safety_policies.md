# CQE Governance & Safety (v0.3)

Modes:
- **Blueprint**: high-level patterns & receipts only (default).
- **Summary**: aggregates + safe metrics; no field-weaponizable details.
- **Redacted**: explicit removals marked `[REDACTED]`.

Auto-Quarantine: any run with 4-bit receipt `0001` (strict-only) is sandboxed.
Forbidden outputs: fabrication-ready sequences, pathogen workflows, weaponizable step-lists.
Allowed: abstract structures, hashes, receipts, toy data, citations).
