# CommonsLedger MVP v0.1 (No external deps)

Evidence-grade social benefits ledger: submit a contribution → governance checks → mint domain credits → route royalties → fill a shared relief pool (50% platform net).

## Structure
- contracts/: DCRA, NPA, Corpus Addendum, Buyer Terms
- schemas/: JSON Schemas for Contribution Proof, Lineage Edge, Royalty Statement, Specifics Request
- sidecar_adapters/speedlight_router.py: mint + ledger + royalty routing (uses SpeedLightPlus if present)
- server/server.py: minimal HTTP server (POST /submit, /settle, /payout_wallet)
- web/index.html: static UI
- examples/overdose_example.json
- governance/: governance windows stubs
- node/org_node.py: corpus ingest + naive lineage matching
- config/policy.yaml: domain scales + 50% split
- tests/test_mint.py

## Run
python server/server.py
# open web/index.html and submit
# or:
curl -s -X POST http://127.0.0.1:8787/submit -H "Content-Type: application/json" --data @examples/overdose_example.json

# simulate a paid service settlement (routes 50% to payout wallet, remainder to creators):
curl -s -X POST http://127.0.0.1:8787/settle -H "Content-Type: application/json" --data '{"service_id":"S1","revenue_fiat":1000,"patterns":[{"pattern_id":"P1","creator_id":"street-medic-001","weight":1.0,"domain_breakdown":{"MERIT":0.7,"AEGIS":0.3}}]}'
