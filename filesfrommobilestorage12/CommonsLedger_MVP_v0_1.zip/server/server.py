\
import os, json, time, hashlib
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.abspath(os.path.join(ROOT, ".."))
DATA = os.path.join(BASE, "data")

import sys, yaml
sys.path.append(os.path.join(BASE,"sidecar_adapters"))
from speedlight_router import Ledger, MintEngine

with open(os.path.join(BASE,"config","policy.yaml"),"r") as f:
    policy = yaml.safe_load(f)

ledger = Ledger(DATA)
engine = MintEngine(policy, ledger)

def read_json(req: BaseHTTPRequestHandler):
    length = int(req.headers.get("Content-Length","0") or "0")
    body = req.rfile.read(length) if length else b"{}"
    try:
        return json.loads(body.decode("utf-8"))
    except Exception:
        return {}

def respond(res: BaseHTTPRequestHandler, code, payload):
    b = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    res.send_response(code)
    res.send_header("Content-Type","application/json; charset=utf-8")
    res.send_header("Content-Length", str(len(b)))
    res.end_headers()
    res.wfile.write(b)

class App(BaseHTTPRequestHandler):
    def do_POST(self):
        p = urlparse(self.path).path
        if p == "/submit":
            obj = read_json(self)
            if not obj.get("actor_id") or not obj.get("domain_claims"):
                return respond(self, 400, {"error":"missing actor_id or domain_claims"})
            rid_raw = hashlib.sha256(json.dumps(obj, sort_keys=True).encode("utf-8")).hexdigest()[:16]
            ledger.append({"type":"contribution","rid":rid_raw,"obj":obj,"ts":time.time()})
            rid, minted = engine.mint(obj)
            return respond(self, 200, {"receipt_id":rid, "minted":minted})
        elif p == "/settle":
            obj = read_json(self)
            if "revenue_fiat" not in obj or "patterns" not in obj:
                return respond(self, 400, {"error":"missing revenue_fiat or patterns"})
            engine.settle_paid_service(obj)
            return respond(self, 200, {"status":"ok"})
        elif p == "/payout_wallet":
            data = json.load(open(os.path.join(DATA,"payout_wallet.json")))
            return respond(self, 200, data)
        else:
            return respond(self, 404, {"error":"unknown endpoint"})

def run():
    host, port = "127.0.0.1", 8787
    print(f"CommonsLedger MVP running at http://{host}:{port}")
    HTTPServer((host, port), App).serve_forever()

if __name__ == "__main__":
    run()
