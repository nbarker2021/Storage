import os, json, time, hashlib, threading, math
from typing import Dict, Any, Tuple

try:
    from speedlight_sidecar_plus import SpeedLightPlus
except Exception:
    SpeedLightPlus = None

_LOCK = threading.Lock()

class Ledger:
    def __init__(self, base_dir: str):
        self.base = base_dir
        os.makedirs(self.base, exist_ok=True)
        self.ledger_path = os.path.join(self.base, "ledger.jsonl")
        self.payout_wallet = os.path.join(self.base, "payout_wallet.json")
        if not os.path.exists(self.payout_wallet):
            with open(self.payout_wallet,"w") as f:
                json.dump({"balance_fiat":0.0}, f)
    def append(self, entry: Dict[str,Any]):
        with _LOCK, open(self.ledger_path,"a") as f:
            f.write(json.dumps(entry, ensure_ascii=False)+"\n")
    def add_payout(self, amount: float):
        with _LOCK:
            data = json.load(open(self.payout_wallet))
            data["balance_fiat"] = round(data.get("balance_fiat",0.0)+float(amount), 2)
            json.dump(data, open(self.payout_wallet,"w"))

class MintEngine:
    def __init__(self, policy: Dict[str,Any], ledger: Ledger):
        self.policy = policy
        self.ledger = ledger
        if SpeedLightPlus:
            self.sl = SpeedLightPlus(mem_bytes=64_000_000, disk_dir=os.path.join(ledger.base,".cache"), ledger_path=os.path.join(ledger.base,".sl_ledger.jsonl"))
        else:
            self.sl = None

    def _hash(self, obj: Dict[str,Any]) -> str:
        b = json.dumps(obj, sort_keys=True).encode("utf-8")
        return hashlib.sha256(b).hexdigest()[:16]

    def _endorsement_strength(self, endorsements):
        if not endorsements: return 0.0
        s = sum(float(e.get("confidence",0)) for e in endorsements)
        return min(1.0, math.log1p(s)/math.log1p(5.0))

    def _lineage_weight(self, lineage_refs):
        if not lineage_refs: return 0.0
        avg = sum(float(r.get("score",0)) for r in lineage_refs)/len(lineage_refs)
        kinds = len(set(r.get("kind") for r in lineage_refs))
        return min(1.0, avg * (1.0 + 0.05*(kinds-1)))

    def _realized_deploy(self, deployments: int):
        return min(1.0, math.sqrt(max(0, deployments))/10.0)

    def _safety(self, safety: Dict[str,bool]):
        ok = safety and safety.get("non_coercive") and safety.get("non_weaponizable") and safety.get("harm_reduction_pass")
        return 1.0 if ok else 0.0

    def mint(self, contribution: Dict[str,Any]) -> Tuple[str, Dict[str,float]]:
        E = self._endorsement_strength(contribution.get("evidence",{}).get("endorsements",[]))
        L = self._lineage_weight(contribution.get("evidence",{}).get("lineage_refs",[]))
        R = self._realized_deploy(int(contribution.get("evidence",{}).get("deployments",0)))
        S = self._safety(contribution.get("evidence",{}).get("safety",{}))

        rid = self._hash({"ts": time.time(), "actor": contribution.get("actor_id",""), "summary": contribution.get("summary","")})
        alphas = self.policy.get("domains",{})
        minted = {}
        for d in contribution.get("domain_claims",[]):
            a = float(alphas.get(d, 1.0))
            minted[d] = round(a * E * L * R * S, 6)

        entry = {"type":"mint","rid":rid,"actor":contribution.get("actor_id"),"domains":minted,"E":E,"L":L,"R":R,"S":S,"ts":time.time()}
        self.ledger.append(entry)
        return rid, minted

    def settle_paid_service(self, service: Dict[str,Any]):
        rev = float(service.get("revenue_fiat",0.0))
        patterns = service.get("patterns",[])
        payout_fraction = float(self.policy.get("payout_split",{}).get("payout_wallet_fraction", 0.5))
        creators_share = rev * (1.0 - payout_fraction)
        self.ledger.add_payout(rev * payout_fraction)
        total_weight = sum(max(0.0,float(p.get("weight",0))) for p in patterns) or 1.0
        for p in patterns:
            share = creators_share * (max(0.0,float(p.get("weight",0)))/ total_weight)
            entry = {"type":"royalty","service_id":service.get("service_id"),
                     "pattern_id":p.get("pattern_id"),"creator_id":p.get("creator_id"),
                     "fiat_amount": round(share,2),"ts":time.time(),
                     "domain_breakdown": p.get("domain_breakdown",{})}
            self.ledger.append(entry)
        self.ledger.append({"type":"payout_wallet_credit","amount": round(rev*payout_fraction,2),"ts":time.time()})
