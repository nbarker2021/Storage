
# CQE Extension Pack v2 (Upgraded)

**What you get**
- Observed-label primacy (`GlyphRegistry`) with receipts
- Commit width switcher + dual-lane receipts (`CommitN`, `DualLaneCommit`)
- Collision health report (`CollisionMonitor`)
- Corridor beam pruner (`CorridorPruner`)
- Deck calculus adapter to/from canonical deck state (`DeckCodec`, `DeckMove`)
- Semantic sidecars (domain-agnostic): EEG, Light, Heat histograms

**Quickstart**
```bash
python -m harness.run_extension
python -m tests.test_extension
```
Artifacts land in `harness/out_ext/`.
