
# Worksheet: Observed > Assumed (Glyph Registry)

- Declare assumed labels for 10 tokens.
- Flip 3 to observed labels.
- Record `snapshot()` digest and `receipts()`.
- Verify that `overrides()` returns exactly 3 entries.
