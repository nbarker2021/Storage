
from __future__ import annotations
from dataclasses import dataclass
from typing import List

@dataclass
class Candidate:
    id: str
    posterior: float
    novelty: float
    residual_gain: float

    def merit(self) -> float:
        # Geometric-mean style merit, stable with small eps
        eps = 1e-9
        return (self.posterior + eps) * (self.novelty + eps) * (self.residual_gain + eps) ** (1/3)

class CorridorPruner:
    @staticmethod
    def prune(cands: List[Candidate], k: int = 8) -> List[Candidate]:
        return sorted(cands, key=lambda c: c.merit(), reverse=True)[:k]
