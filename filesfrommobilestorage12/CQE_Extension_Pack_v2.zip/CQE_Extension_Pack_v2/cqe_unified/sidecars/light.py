
from __future__ import annotations
from typing import Iterable, Dict
import hashlib

BINS = ["radio","microwave","infrared","visible","ultraviolet","xray","gamma"]

def spectrum_bin(label: str) -> str:
    h = hashlib.blake2s(label.encode()).digest()
    return BINS[h[0] % len(BINS)]

def histogram(labels: Iterable[str]) -> Dict[str, int]:
    hist: Dict[str, int] = {b:0 for b in BINS}
    for L in labels:
        hist[spectrum_bin(L)] += 1
    return hist
