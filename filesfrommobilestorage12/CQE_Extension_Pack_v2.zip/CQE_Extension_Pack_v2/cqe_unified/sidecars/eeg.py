
from __future__ import annotations
from typing import Iterable, Dict
import hashlib

BANDS = ["delta","theta","alpha","beta","gamma"]

def band(label: str) -> str:
    h = hashlib.sha256(label.encode()).digest()
    return BANDS[h[0] % len(BANDS)]

def histogram(labels: Iterable[str]) -> Dict[str, int]:
    hist: Dict[str, int] = {b:0 for b in BANDS}
    for L in labels:
        hist[band(L)] += 1
    return hist
