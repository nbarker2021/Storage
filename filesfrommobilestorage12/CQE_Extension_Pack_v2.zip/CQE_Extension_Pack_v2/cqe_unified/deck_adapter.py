
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

RANKS = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
SUITS = ["C","S","D","H"]  # Clubs, Spades, Diamonds, Hearts (fixed order)

def card_id(idx: int) -> str:
    r = RANKS[idx % 13]
    s = SUITS[idx // 13]
    return f"{r}{s}"

def all_cards() -> List[str]:
    return [card_id(i) for i in range(52)]

@dataclass
class Deck:
    order: List[str]          # top->bottom list of card ids
    face_up: Dict[str, bool]  # card id -> face flag
    piles: Dict[str, List[str]]  # optional partition

class DeckMove:
    @staticmethod
    def cut(deck: Deck, k: int) -> Deck:
        k = max(0, min(k, len(deck.order)))
        new_order = deck.order[k:] + deck.order[:k]
        return Deck(new_order, deck.face_up.copy(), {k: v[:] for k, v in deck.piles.items()})

    @staticmethod
    def reverse(deck: Deck) -> Deck:
        return Deck(list(reversed(deck.order)), deck.face_up.copy(), {k: v[:] for k, v in deck.piles.items()})

    @staticmethod
    def flip(deck: Deck, ids: List[str]) -> Deck:
        fu = deck.face_up.copy()
        for cid in ids:
            fu[cid] = not fu.get(cid, False)
        return Deck(deck.order[:], fu, {k: v[:] for k, v in deck.piles.items()})

    @staticmethod
    def riffle(deckA: Deck, deckB: Deck) -> Deck:
        out = []
        a, b = deckA.order[:], deckB.order[:]
        while a or b:
            if a: out.append(a.pop(0))
            if b: out.append(b.pop(0))
        # merge face flags (B overrides A if duplicate card ids, though decks should be disjoint in practice)
        fu = deckA.face_up.copy()
        fu.update(deckB.face_up)
        piles = {"A": deckA.order[:], "B": deckB.order[:]}
        return Deck(out, fu, piles)

class DeckCodec:
    @staticmethod
    def encode_sequence(bits: List[int]) -> Deck:
        """
        Encode a short bit sequence using the top |bits| cards.
        face_up=1 shows a set bit; face_down=0 otherwise.
        """
        cards = all_cards()
        seq_cards = cards[:len(bits)]
        face = {cid: (bits[i] == 1) for i, cid in enumerate(seq_cards)}
        # others default false
        for cid in cards[len(bits):]:
            face[cid] = False
        return Deck(seq_cards + cards[len(bits):], face, {"payload": seq_cards})

    @staticmethod
    def read_sequence(deck: Deck, n: int) -> List[int]:
        seq = deck.order[:n]
        return [1 if deck.face_up.get(cid, False) else 0 for cid in seq]
