
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Optional, Tuple
import hashlib, json, time

@dataclass
class Event:
    t: float
    kind: str
    token: str
    value: Any

class GlyphRegistry:
    """
    Observed label always overrides assumed.
    Keeps an append-only event log and produces snapshot receipts.
    """
    def __init__(self, project: str = "default"):
        self.project = project
        self.assumed: Dict[str, str] = {}
        self.observed: Dict[str, str] = {}
        self.log: List[Event] = []

    def assume(self, token: str, label: str) -> None:
        self.assumed[token] = label
        self.log.append(Event(time.time(), "assume", token, label))

    def observe(self, token: str, label: str) -> None:
        self.observed[token] = label
        self.log.append(Event(time.time(), "observe", token, label))

    def label_of(self, token: str) -> Optional[str]:
        return self.observed.get(token, self.assumed.get(token))

    def overrides(self) -> Dict[str, Tuple[str, str]]:
        out = {}
        for k, v in self.observed.items():
            if k in self.assumed and self.assumed[k] != v:
                out[k] = (self.assumed[k], v)
        return out

    def receipts(self) -> Dict[str, Any]:
        return {
            "project": self.project,
            "counts": {
                "assumed": len(self.assumed),
                "observed": len(self.observed),
                "overrides": len(self.overrides())
            },
            "digest": self.snapshot()
        }

    def snapshot(self) -> str:
        state = {
            "project": self.project,
            "assumed": dict(sorted(self.assumed.items())),
            "observed": dict(sorted(self.observed.items())),
            "log": [(e.t, e.kind, e.token, e.value) for e in self.log],
        }
        blob = json.dumps(state, sort_keys=True, separators=(",",":")).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()
