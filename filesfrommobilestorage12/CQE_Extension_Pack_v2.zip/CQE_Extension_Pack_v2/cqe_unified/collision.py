
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Tuple, Iterable
import hashlib, math, statistics

def _h(label: str, seed: str) -> int:
    m = hashlib.blake2b(digest_size=16, person=seed.encode("utf-8"))
    m.update(label.encode("utf-8"))
    return int.from_bytes(m.digest(), "big")

@dataclass
class CommitN:
    nbits: int = 4
    seed: str = "PAL"

    def code(self, label: str) -> str:
        val = _h(label, f"COMMITN::{self.seed}")
        mask = (1 << self.nbits) - 1
        return format(val & mask, f"0{self.nbits}b")

@dataclass
class DualLaneCommit:
    """Two independent lanes (e.g., Pal and Mir) → concatenated code string."""
    lane_a: CommitN
    lane_b: CommitN

    def code(self, label: str) -> str:
        return self.lane_a.code(label) + self.lane_b.code(label)

@dataclass
class CollisionReport:
    total: int
    unique: int
    collision_rate: float
    hist: Dict[str, int]
    sep_score: float

class CollisionMonitor:
    """Quick health and collision metrics in receipt space."""
    @staticmethod
    def report(labels: Iterable[str], coder) -> CollisionReport:
        codes: List[str] = [coder.code(x) for x in labels]
        hist: Dict[str, int] = {}
        for c in codes:
            hist[c] = hist.get(c, 0) + 1
        total = len(codes)
        unique = len(hist)
        collision_rate = 0.0 if total == 0 else (total - unique) / total
        # crude separability: inverse of average bucket size variance
        sizes = list(hist.values())
        if len(sizes) > 1:
            var = statistics.pvariance(sizes)
            sep = 1.0 / (1.0 + var)
        else:
            sep = 1.0
        return CollisionReport(total, unique, collision_rate, hist, sep)
