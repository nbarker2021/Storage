
import unittest
from cqe_unified import GlyphRegistry, CommitN, DualLaneCommit, CollisionMonitor, Candidate, CorridorPruner, DeckCodec

class TestCQEExt(unittest.TestCase):
    def test_observed_overrides(self):
        gr = GlyphRegistry("tproj")
        gr.assume("T1", "A")
        gr.observe("T1", "B")
        self.assertEqual(gr.label_of("T1"), "B")
        self.assertEqual(len(gr.overrides()), 1)

    def test_collision_width(self):
        gr = GlyphRegistry("tproj")
        for i in range(64):
            gr.assume(f"T{i}", f"L{i}")
        labels = [gr.label_of(f"T{i}") for i in range(64)]
        rep4 = CollisionMonitor.report(labels, CommitN(4, seed="PAL"))
        dual = DualLaneCommit(CommitN(4, seed="PAL"), CommitN(4, seed="MIR"))
        rep8 = CollisionMonitor.report(labels, dual)
        self.assertLessEqual(rep8.collision_rate, rep4.collision_rate + 1e-9)

    def test_pruner(self):
        cands = [Candidate(id=str(i), posterior=0.5, novelty=0.5, residual_gain=(i+1)/10.0) for i in range(10)]
        winners = CorridorPruner.prune(cands, k=3)
        self.assertEqual(len(winners), 3)
        self.assertGreaterEqual(winners[0].merit(), winners[-1].merit())

    def test_deck_roundtrip_len(self):
        bits = [1,0,1,1,0]
        deck = DeckCodec.encode_sequence(bits)
        readback = DeckCodec.read_sequence(deck, len(bits))
        self.assertEqual(bits, readback)

if __name__ == "__main__":
    unittest.main()
