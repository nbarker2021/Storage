
"""
End-to-end demo runner for CQE Extension Pack v2.
"""
import json, random
from pathlib import Path
from cqe_unified import GlyphRegistry, CommitN, DualLaneCommit, CollisionMonitor, Candidate, CorridorPruner, DeckCodec, DeckMove
from cqe_unified.sidecars import eeg as eeg_sc
from cqe_unified.sidecars import light as light_sc
from cqe_unified.sidecars import heat as heat_sc

OUT = Path(__file__).parent / "out_ext"
OUT.mkdir(parents=True, exist_ok=True)

def seed_registry(n=256):
    gr = GlyphRegistry(project="extpack_v2_demo")
    for i in range(n):
        tok = f"T{i:04d}"
        gr.assume(tok, f"LABEL_{i%64:02d}")  # coarse assumed mapping
    # apply some observed overrides
    for i in range(0, n, 5):
        tok = f"T{i:04d}"
        gr.observe(tok, f"OBS_{i%97:02d}")
    return gr

def run_collision(gr: GlyphRegistry):
    labels = [gr.label_of(f"T{i:04d}") for i in range(256)]
    labels = [x for x in labels if x is not None]
    rep_4 = CollisionMonitor.report(labels, CommitN(4, seed="PAL"))
    dual = DualLaneCommit(CommitN(4, seed="PAL"), CommitN(4, seed="MIR"))
    rep_8 = CollisionMonitor.report(labels, dual)
    return {
        "commit4": rep_4.__dict__,
        "commit8_dual": rep_8.__dict__,
    }

def run_pruner(k=8):
    rng = random.Random(42)
    cands = []
    for i in range(64):
        cands.append(Candidate(
            id=f"C{i:03d}",
            posterior=rng.random(),
            novelty=rng.random(),
            residual_gain=rng.random()
        ))
    winners = CorridorPruner.prune(cands, k=k)
    return {"winners": [vars(w) | {"merit": w.merit()} for w in winners]}

def run_deck_codec():
    bits = [1,0,1,1,0,0,1,0]
    deck = DeckCodec.encode_sequence(bits)
    deck_cut = DeckMove.cut(deck, 3)
    deck_rev = DeckMove.reverse(deck_cut)
    readback = DeckCodec.read_sequence(deck_rev, n=len(bits))
    return {
        "input_bits": bits,
        "readback_after_moves": readback,
        "ok_roundtrip_len": len(readback)==len(bits)
    }

def run_sidecars(gr: GlyphRegistry):
    labels = [gr.label_of(f"T{i:04d}") for i in range(64)]
    labels = [x for x in labels if x is not None]
    return {
        "eeg_hist": eeg_sc.histogram(labels),
        "light_hist": light_sc.histogram(labels),
        "heat_hist": heat_sc.histogram(labels)
    }

def main():
    gr = seed_registry(256)
    # Reports
    out = {}
    out["glyph_receipts"] = gr.receipts()
    out["collision"] = run_collision(gr)
    out["pruner"] = run_pruner()
    out["deck"] = run_deck_codec()
    out["sidecars"] = run_sidecars(gr)

    (OUT / "full_report.json").write_text(json.dumps(out, indent=2))
    (OUT / "snapshot.txt").write_text(gr.snapshot())
    print("Wrote:", OUT / "full_report.json")
    return out

if __name__ == "__main__":
    main()
