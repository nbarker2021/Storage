import argparse, json, random
from pathlib import Path
import pandas as pd
random.seed(1337)

def serialize_octet(row):
    # Canonical CQE string form
    parts = []
    parts.append("[OCTET]")
    for k in ["V1","V2","V3","V4","V5","V6","V7","V8"]:
        parts.append(f"[{k}] " + str(row.get(k, "")))
    parts.append("[STATUS] " + str(row.get("status","PROVISIONAL")).upper().replace("-",""))
    parts.append("[RECEIPT] " + str(row.get("receipt_four_bit","0000")))
    parts.append("[EOO]")
    return " ".join(parts)

def main(args):
    src = Path(args.src)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(src)
    df = df.fillna("")
    lines = [serialize_octet(r) for _, r in df.iterrows()]
    idx = list(range(len(lines))); random.shuffle(idx)
    split = int(0.9 * len(idx)) if len(idx) > 10 else max(1, int(0.8*len(idx)))
    train = [lines[i] for i in idx[:split]]
    val   = [lines[i] for i in idx[split:]] or train[:1]

    (out/"lm_train.txt").write_text("\n".join(train) + "\n")
    (out/"lm_val.txt").write_text("\n".join(val) + "\n")

    def label_id(s):
        s = str(s).upper()
        if "WORKING" in s: return 2
        if "PROVISIONAL" in s: return 1
        return 0

    rows = [{"text": serialize_octet(r), "label": label_id(r.get("status",""))} for _, r in df.iterrows()]
    train_rows = [rows[i] for i in idx[:split]]
    val_rows   = [rows[i] for i in idx[split:]] or rows[:1]
    with open(out/"cls_train.jsonl","w") as f:
        for r in train_rows: f.write(json.dumps(r)+"\n")
    with open(out/"cls_val.jsonl","w") as f:
        for r in val_rows: f.write(json.dumps(r)+"\n")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", type=str, required=True, help="Path to cqe_mined_octets.csv")
    ap.add_argument("--out", type=str, required=True, help="Output dir for prepared dataset")
    main(ap.parse_args())
