# Governance, Rules & Glossary

Rules: govern-or-don’t-go (SAP+SafeCube), anchors gate force-deploy, reproducibility (DNA replay, Trails), bridge-the-gap (def↔surp), CI gates.
Glossary: SNAP, Shelling, Triad/Inverse/TAC, 8/8, Underverse, C[8], Glyph, DNA, E8, Anchors, MDHG, AGRM, ThinkTank, DTT, Assembly, MORSR, SAP, Safe Cube, Universe, Bridge, 1729 Gate.
