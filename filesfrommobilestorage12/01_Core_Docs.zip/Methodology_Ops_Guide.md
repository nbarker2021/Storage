# SnapLat — Methodology, Ops Guide, Best Practices & Quick Tips

Runbook: Intake→Snapify→E8→Shelling(n=1→5)→C[8]→DTT→Assembly(DNA)→SAP→Archivist→MORSR.
Principles: E8-first, SNAP atoms, TAC, n=5 Top-K=8, evidence>opinion, Safe Cube, anchors, endpoint tags, tick discipline.
