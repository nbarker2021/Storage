# CQE Cloud API (pilot)

**What this is:** a runnable API that wraps the CQE orchestrator in one‑shot mode.
Endpoints:
- `POST /v1/commit` → one sealed answer + receipts (+ minted MasterToken on disk)
- `POST /v1/overlay` → variant map + one‑lap plan (no side effects)

## Run locally
```bash
cd /mnt/data/CQE_Cloud_API
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

## Docker
```bash
docker build -t cqe-cloud:pilot .
docker run -p 8000:8000 cqe-cloud:pilot
```

## Example
```bash
curl -s http://localhost:8000/v1/commit \
  -H 'content-type: application/json' \
  -d '{"prompt":"Earth observation fusion: VIS/IR + wind; anti‑alias diurnal/orbital with 3% anchors.","stitch":"earth"}' | jq .
```

Nuggets are written under `./nuggets/`.
