
def plan(prompt: str):
    # Toy variant map + one-lap φ plan (no side effects)
    variants = [
        {"slice":"H0","note":"direct"},
        {"slice":"H3","note":"contrast"},
        {"slice":"H5","note":"enumerated"}
    ]
    axes = ["scope","data source","constraint"]
    one_lap = {"window": 13, "arms": [0,3,5,1,4,6,2,7]}
    return {"variants": variants, "search_axes": axes, "one_lap_plan": one_lap}
