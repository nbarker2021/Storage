
"""
Windowed orchestrator with φ+gradient scheduling and edge fences.
This simulates 1 macrocycle: inside windows we use light gates; at edges we run receipts+compliance+mint.
"""
import math, json, random
from typing import List
from cqe_sdk import Pack, Normalizer, WeylSlicer, GradientPainter, BraidComposer, ReceiptsEngine, ComplianceGate, NuggetMint, EarthFusionStitch, SARStitch, InterferometerStitch

PHI = (1 + 5**0.5)/2
DEFAULT_ALPHA = PHI - 1

def phi_order(alpha: float=DEFAULT_ALPHA, arms: int=8, ticks: int=34):
    """Generate φ-based arm visitation order for a horizon of ticks."""
    seq = []
    x = 0.0
    for _ in range(ticks):
        x = (x + alpha) % 1.0
        seq.append(int(x * arms) % arms)
    return seq

def run_pilot(prompt: str, outdir: str, window: int=21, stitch_name: str|None=None) -> dict:
    # Initial pack at digit-0 observation, slice/chamber locked for determinism
    p = Pack(
        weyl_id=0, chamber_id=217,
        gsl={"base":24,"octave_k":2,"riser":7},
        meta={"window_id":"W0","tick":0,"phi_alpha":DEFAULT_ALPHA,"caps":["FS.WRITE"]},
        payload={"prompt":prompt, "comparator":{"order_key":["ts","id"],"metrics":["exact"],"tolerances":{"exact":1.0}}}
    ).seal()

    modules_fastlane = [Normalizer()]
    if stitch_name == "earth": modules_fastlane.append(EarthFusionStitch())
    elif stitch_name == "sar": modules_fastlane.append(SARStitch())
    elif stitch_name == "interferometer": modules_fastlane.append(InterferometerStitch())
    modules_fastlane += [WeylSlicer(), GradientPainter()]
    modules_edge = [BraidComposer({"chambers":4096}), ReceiptsEngine(), ComplianceGate(), NuggetMint(outdir)]

    # φ+gradient schedule inside one window
    order = phi_order(ticks=window)
    visits = {k:0 for k in range(8)}
    for t, arm in enumerate(order, start=1):
        # fairness: don't let any arm exceed φ by >2 visits in window
        if visits[arm] - min(visits.values()) > 2:
            # pick next best arm
            arm = min(visits, key=lambda k: visits[k])
        visits[arm]+=1
        p.weyl_id = arm
        p.meta["tick"] = t
        # fast lane
        for m in modules_fastlane:
            p = m.process(p)

    # Edge fence
    for m in modules_edge:
        p = m.process(p)

    return {
        "answer": p.meta["answer"],
        "token_path": p.meta["minted_token_path"],
        "receipts": p.meta.get("receipts",{}),
        "braid": p.meta.get("braid",{}),
        "schedule_visits": visits
    }
