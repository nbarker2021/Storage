from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import importlib, sys, os

# local imports
from cqe.overlay import plan as overlay_plan

# make orchestrator importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "cqe"))
spec = importlib.util.spec_from_file_location("engine", os.path.join(os.path.dirname(__file__), "cqe/orchestrator/engine.py"))
engine = importlib.util.module_from_spec(spec); spec.loader.exec_module(engine)  # type: ignore

app = FastAPI(title="CQE Cloud API", version="0.1.0")

class Comparator(BaseModel):
    order_key: Optional[List[str]] = None
    metrics: Optional[List[str]] = None
    tolerances: Optional[Dict[str, Any]] = None

class CommitBody(BaseModel):
    prompt: str
    comparator: Optional[Comparator] = None
    caps: Optional[List[str]] = None
    stitch: Optional[str] = None  # 'earth' | 'sar' | 'interferometer' | None

@app.post("/v1/commit")
def commit(body: CommitBody):
    prompt = body.prompt
    stitch = body.stitch if body.stitch in {"earth","sar","interferometer"} else None
    outdir = os.path.join(os.path.dirname(__file__), "nuggets")
    os.makedirs(outdir, exist_ok=True)
    res = engine.run_pilot(prompt, outdir, window=21, stitch_name=stitch)
    return {
        "answer": res["answer"],
        "receipts": res["receipts"],
        "braid": res["braid"],
        "nugget_path": res["token_path"]
    }

class OverlayBody(BaseModel):
    prompt: str

@app.post("/v1/overlay")
def overlay(body: OverlayBody):
    return overlay_plan(body.prompt)
