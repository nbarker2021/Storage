"""
CQE Modular SDK (Python) — Atomic Module base classes & helpers.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List
import hashlib, json, os

def sha256hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

@dataclass
class Pack:
    weyl_id: int
    chamber_id: int
    gsl: Dict[str, int]
    meta: Dict[str, Any]
    payload: Dict[str, Any]
    fastlane: bool = True
    pack_id: str = field(default_factory=lambda: sha256hex(os.urandom(16)))
    hash: str = ""

    def seal(self) -> "Pack":
        body = json.dumps({
            "weyl_id": self.weyl_id,
            "chamber_id": self.chamber_id,
            "gsl": self.gsl,
            "meta": self.meta,
            "payload": self.payload,
            "fastlane": self.fastlane,
        }, sort_keys=True).encode()
        self.hash = sha256hex(body)
        return self

class Module:
    KIND = "custom"
    NAME = "base"
    DETERMINISTIC = True
    FENCE_RULES: List[str] = []

    def __init__(self, config: Dict[str, Any] | None = None) -> None:
        self.config = config or {}

    def accept(self, pack: Pack) -> bool:
        """Return True if this module should process the pack."""
        return True

    def process(self, pack: Pack) -> Pack:
        """Pure function inside window; side-effects must be deferred to fences."""
        raise NotImplementedError

# Example modules
class Normalizer(Module):
    KIND="normalizer"
    NAME="normalizer"
    def process(self, pack: Pack) -> Pack:
        p = pack.payload
        # normalize prompt text, extract comparator (toy)
        comp = p.get("comparator", {"order_key":["t","id"], "metrics":["exact"], "tolerances":{"exact":1.0}})
        pack.meta["comparator"] = comp
        return pack.seal()

class WeylSlicer(Module):
    KIND="slicer"
    NAME="weyl_slicer"
    def process(self, pack: Pack) -> Pack:
        # here we just echo weyl_id; real system would generate eight reflections
        pack.meta["slice"] = f"H{pack.weyl_id}"
        return pack.seal()

class BraidComposer(Module):
    KIND="composer"
    NAME="braid"
    FENCE_RULES=["all8_closure","dual","compose"]
    def process(self, pack: Pack) -> Pack:
        # toy "braid score"
        pack.meta["braid_score"] = 1.0
        return pack.seal()
