"""
Minimal orchestrator stub: loads config and runs a linear pipeline of modules.
This is a toy to demonstrate atomic/micro-modular flow; real engine implements φ+gradient, windows, and fences.
"""
from typing import List
from cqe_sdk import Pack, Normalizer, WeylSlicer, BraidComposer

def run_once(prompt: str) -> Pack:
    # Build initial pack
    p = Pack(
        weyl_id=0, chamber_id=0,
        gsl={"base":24,"octave_k":2,"riser":7},
        meta={"window_id":"W0","tick":0,"phi_alpha":0.618,"grad":{"gain":0.0,"norm":0.0},"caps":[]},
        payload={"prompt":prompt}
    ).seal()
    pipeline: List = [Normalizer(), WeylSlicer(), BraidComposer()]
    for m in pipeline:
        if m.accept(p): p = m.process(p)
    return p
