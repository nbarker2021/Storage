# Patching Engine — Legal Ops & Invariants (version v0_1_2025_08_13)
**Date:** 2025-08-13

## Legal operations
1. **Single-node insertion (SNI)**  
   Insert node *k* between path edges (i,j).  
   - Score components: Δtour length, coverage gain (new sector/shell), tension relief (sector continuity), compute budget.
   - Invariants: simple cycle preserved; no node duplication; indices update coherently.

2. **Two-node chain insertion (TNI)**  
   Insert ordered pair (k,l) between (i,j) where (k,l) has high VWS edge frequency or MDHG hot edge.  
   - Invariants: as above; chain adjacency preserved.

3. **Short-chain splice (SCS)**  
   Replace edge (i,j) with k→…→l where k…l forms a short path through unvisited nodes (length ≤ L_max).  
   - Invariants: path remains Hamiltonian; visited set updates; avoids crossings if planar constraint active.

4. **Edge swap (ESW)**  
   Swap (i,a) and (j,b) to (i,j) and (a,b) when it reduces length or tension (2‑opt primitive).  
   - Invariants: cycle preserved; no fragmentation.

## Scoring (v1)
`score = w_len * (Δlength_gain) + w_cov * (coverage_gain) + w_ten * (tension_gain) - w_cost * (compute_cost)`  
- Δlength_gain = old_edge_len - new_insert_len (positive is good)  
- coverage_gain = 1 if insertion brings a new sector/shell, else 0  
- tension_gain ≈ sector continuity improvement (adjacent sector ids after insertion vs before)  
- compute_cost ∝ chain length and candidate fan-out

## Reversibility
- Every operation returns a **PatchLedger** with enough info to revert: indices, nodes inserted, edges removed/added, RNG seed.

## Safety
- All patches pass through SAP gates: governance check → quarantine on failure; ledger is snapshotted before commit.
