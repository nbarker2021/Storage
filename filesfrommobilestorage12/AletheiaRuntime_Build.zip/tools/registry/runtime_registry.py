
import json
from pathlib import Path
from typing import Dict, Any
from tools.adapters.demo_tools import EchoTool, AddTool

class RuntimeToolRegistry:
    def __init__(self):
        self.tools = {"demo.echo": EchoTool(), "math.add": AddTool()}
        REG = Path(__file__).resolve().parent/"registry.json"
        self.discovered = {}
        if REG.exists():
            try: self.discovered = json.loads(REG.read_text())
            except Exception: self.discovered = {}
    def has(self, name: str) -> bool:
        return (name in self.tools) or (name in self.discovered)
    def call(self, name: str, **kwargs) -> Dict[str, Any]:
        if name in self.tools: return self.tools[name].call(**kwargs)
        meta = self.discovered[name]
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("dynmod", meta["path"]); mod = module_from_spec(spec); spec.loader.exec_module(mod)  # type: ignore
        fn = getattr(mod, meta["callable"])
        return fn(**kwargs)
