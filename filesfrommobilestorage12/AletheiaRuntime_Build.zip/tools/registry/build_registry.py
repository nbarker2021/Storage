
import importlib.util, inspect, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
REG_JSON = ROOT / "tools/registry/registry.json"
def discover_tools():
    registry = {}
    for py in SRC.rglob("*.py"):
        name = "src_" + py.relative_to(SRC).as_posix().replace("/", "_").replace(".py","")
        spec = importlib.util.spec_from_file_location(name, str(py))
        try:
            mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)  # type: ignore
        except Exception:
            continue
        import inspect
        for n, obj in inspect.getmembers(mod, inspect.isfunction):
            if n.startswith("tool_"):
                key = f"{mod.__name__}.{n}"
                registry[key] = {"type":"python_func","path": str(py), "callable": n}
        if hasattr(mod, "TOOL_SPEC") and isinstance(mod.TOOL_SPEC, dict):
            for key, meta in mod.TOOL_SPEC.items():
                registry[key] = {"type":"tool_spec","path": str(py), "spec": meta}
    return registry
if __name__ == "__main__":
    reg = discover_tools()
    REG_JSON.parent.mkdir(parents=True, exist_ok=True)
    REG_JSON.write_text(json.dumps(reg, indent=2))
    print(f"Wrote registry with {len(reg)} entries to {REG_JSON}")
