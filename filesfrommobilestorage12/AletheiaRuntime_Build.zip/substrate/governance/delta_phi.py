
from typing import Dict, Any
import math
class SimpleNSL:
    def __init__(self, temperature: float=300.0, kB: float=1.380649e-23):
        self.temperature = temperature; self.kB=kB
    def sectors(self, before: Dict[str,Any], after: Dict[str,Any]) -> Dict[str,float]:
        b = len(before.get("state",{})); a = len(after.get("state",{}))
        dI = -(max(0.0, a - b))
        dN = 0.0
        dL = - (self.kB*self.temperature*math.log(2)) * 0.0
        total = dN + dI + dL
        return {"noether": dN, "shannon": dI, "landauer": dL, "total": total}
