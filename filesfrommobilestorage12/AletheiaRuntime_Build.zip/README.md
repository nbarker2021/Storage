
# AletheiaRuntime — Morphonic Substrate (Unified Repo)

This is a production-oriented skeleton that turns your corpus into a single callable system:
- Sidecar control AI (dual-rail ΔΦ gating).
- Scene8 world-building, MagicProbe monitoring, and Receipts logging.
- Tool Registry that discovers and wraps code from /src (ingested from zips).
- SNAP & RAG cards generated during ingest.

## Quickstart
```bash
python3 ingest/ingest_and_unify.py
python3 runner.py --goal "Smoke test the tool registry" --steps 4
```
