
import os, sys, json, hashlib, argparse
import numpy as np

BASE = os.path.dirname(os.path.dirname(__file__))
REPORTS = os.path.join(BASE, "reports")
os.makedirs(REPORTS, exist_ok=True)

def parse_cql(path):
    cfg = {}
    with open(path,"r") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"): 
                continue
            if ":" in s:
                k,v = s.split(":",1)
                cfg[k.strip()] = v.strip()
    # Tokenize sets
    for key in ["VIEWS"]:
        if key in cfg:
            cfg[key] = [t.strip() for t in cfg[key].split(",")]
    return cfg

def sha256_of(obj):
    h = hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()
    return h

# ---------- Domain kernels (synthetic) ----------

def optics_runner(cfg):
    np.random.seed(int(cfg.get("SEED","0")))
    N = 64
    # synthetic pupil with an astig-like phase term
    y,x = np.indices((N,N))
    x = (x - N/2)/(N/2)
    y = (y - N/2)/(N/2)
    r2 = x*x + y*y
    pupil = (r2 <= 1.0).astype(float)
    amp = 1.0
    astig_amp = 0.12  # matches CQL default
    phase = astig_amp * (x*x - y*y)  # Zernike-like
    field = pupil * np.exp(1j*phase)

    # forward: FFT->PSF->IFFT
    F = np.fft.fftshift(np.fft.fft2(field))
    PSF = np.abs(F)**2
    # crude inverse (normalize, root, ifft) for demo
    F_rec = np.sqrt(PSF+1e-12) * np.exp(1j*np.angle(F))
    field_rec = np.fft.ifft2(np.fft.ifftshift(F_rec))
    mirror_err = np.mean(np.abs(field - field_rec))

    # Δ-lift: remove astig phase to 0.00
    phase_lift = 0.0*(x*x - y*y)
    field_lift = pupil * np.exp(1j*phase_lift)
    F_lift = np.fft.fftshift(np.fft.fft2(field_lift))
    PSF_lift = np.abs(F_lift)**2
    F_rec_lift = np.sqrt(PSF_lift+1e-12) * np.exp(1j*np.angle(F_lift))
    field_rec_lift = np.fft.ifft2(np.fft.ifftshift(F_rec_lift))
    mirror_err_lift = np.mean(np.abs(field_lift - field_rec_lift))

    # crude WFE proxy and Strehl proxy
    # (WFE ~ std of phase where pupil==1; Strehl ~ PSF peak / ideal peak)
    wfe = float(np.std(phase[pupil==1]))
    strehl = float(PSF.max()/PSF_lift.max())  # worse than lifted

    # Strict bounds
    strict_normal_ok = (wfe <= 0.025) and (strehl >= 0.90)  # scaled numbers
    strict_tight_ok  = (wfe <= 0.022) and (strehl >= 0.92)

    octet_ok = len(cfg.get("VIEWS",[])) >= 8
    mirror_ok = mirror_err <= float(cfg.get("TOLERANCE","1e-6"))
    lift_ok = (mirror_err_lift < mirror_err)

    commit_bits = [
        "1" if octet_ok else "0",
        "1" if mirror_ok else "0",
        "1" if lift_ok else "0",
        "1" if strict_tight_ok else ("1" if strict_normal_ok else "0"),
    ]
    commit = "".join(commit_bits)

    return {
        "form": cfg.get("FORM",""),
        "domain": "optics",
        "octet_views": len(cfg.get("VIEWS",[])),
        "mirror_error": mirror_err,
        "lift_improvement": float(mirror_err - mirror_err_lift),
        "wfe_proxy": wfe,
        "strehl_proxy": strehl,
        "strict_pass": bool(strict_normal_ok or strict_tight_ok),
        "commit_4bit": commit,
    }

def materials_runner(cfg):
    np.random.seed(int(cfg.get("SEED","0")))
    # synthetic spectra arrays
    n = 256
    e = np.linspace(0,6,n)
    # IPA: base spectrum + noise
    ipa = np.exp(-((e-3.0)**2)/0.8) + 0.02*np.sin(5*e) + 0.02*np.random.randn(n)
    # RPA: broadened + kernel diff
    rpa = np.exp(-((e-3.0)**2)/1.0) + 0.02*np.sin(5*e+0.3)

    # Mirror = TL vs DL equivalence → here, we compare distributions
    mae_forward = float(np.mean(np.abs(rpa - ipa)))
    mae_inverse = float(np.mean(np.abs(ipa - rpa)))
    mae = max(mae_forward, mae_inverse)

    # Δ-lift: kernel tune width 0.30->0.24 (simulate sharper RPA)
    rpa_lift = np.exp(-((e-3.0)**2)/0.9) + 0.02*np.sin(5*e+0.25)
    mae_lift = float(np.mean(np.abs(rpa_lift - ipa)))
    sc = 1.0 - mae  # simple spectral coherence proxy
    sc_lift = 1.0 - mae_lift

    tol_str = cfg.get("TOLERANCE","MAE<=0.020")
    tol = float(tol_str.split("<=")[-1])

    strict_normal_ok = (mae <= 0.030) and (sc >= 0.94)
    strict_tight_ok  = (mae <= 0.025) and (sc >= 0.96)

    octet_ok = len(cfg.get("VIEWS",[])) >= 8
    mirror_ok = (mae <= tol)
    lift_ok = (mae_lift < mae)

    commit_bits = [
        "1" if octet_ok else "0",
        "1" if mirror_ok else "0",
        "1" if lift_ok else "0",
        "1" if strict_tight_ok else ("1" if strict_normal_ok else "0"),
    ]
    commit = "".join(commit_bits)

    return {
        "form": cfg.get("FORM",""),
        "domain": "materials",
        "octet_views": len(cfg.get("VIEWS",[])),
        "mae": mae,
        "mae_lift": mae_lift,
        "sc_proxy": sc,
        "sc_lift_proxy": sc_lift,
        "strict_pass": bool(strict_normal_ok or strict_tight_ok),
        "commit_4bit": commit,
    }

def spintronics_runner(cfg):
    np.random.seed(int(cfg.get("SEED","0")))
    # polarization curves (synthetic); mirror L↔R should agree within tolerance
    vbias = np.linspace(2.6,3.4,101)
    pol_L = 0.8 - 0.05*np.cos(8*(vbias-3.0)) + 0.02*np.random.randn(vbias.size)
    pol_R = 0.8 - 0.05*np.cos(8*(3.0-vbias)) + 0.02*np.random.randn(vbias.size)

    pol_err = float(np.mean(np.abs(pol_L - pol_R)))
    # Δ-lift: bias trim 3.10->3.00 => re-center curve to reduce error
    pol_R_lift = 0.8 - 0.05*np.cos(8*((3.0)-(vbias-0.10)))  # small re-center
    pol_err_lift = float(np.mean(np.abs(pol_L - pol_R_lift)))

    pol_tol = 0.05
    strict_normal_ok = (np.mean(pol_L)>=0.75) and (np.mean(pol_R)>=0.75)
    strict_tight_ok  = (np.mean(pol_L)>=0.80) and (np.mean(pol_R)>=0.80)

    octet_ok = len(cfg.get("VIEWS",[])) >= 8
    mirror_ok = (pol_err <= pol_tol)
    lift_ok = (pol_err_lift < pol_err)

    commit_bits = [
        "1" if octet_ok else "0",
        "1" if mirror_ok else "0",
        "1" if lift_ok else "0",
        "1" if strict_tight_ok else ("1" if strict_normal_ok else "0"),
    ]
    commit = "".join(commit_bits)

    return {
        "form": cfg.get("FORM",""),
        "domain": "spintronics",
        "octet_views": len(cfg.get("VIEWS",[])),
        "pol_error": pol_err,
        "pol_error_lift": pol_err_lift,
        "pol_mean_L": float(np.mean(pol_L)),
        "pol_mean_R": float(np.mean(pol_R)),
        "strict_pass": bool(strict_normal_ok or strict_tight_ok),
        "commit_4bit": commit,
    }

def run_one(path):
    cfg = parse_cql(path)
    name = os.path.splitext(os.path.basename(path))[0]
    form = cfg.get("FORM","")

    if "OPTICS" in form or "TOROIDAL" in form:
        out = optics_runner(cfg)
    elif "MATERIALS" in form:
        out = materials_runner(cfg)
    elif "SPINTRONICS" in form:
        out = spintronics_runner(cfg)
    else:
        raise SystemExit(f"Unrecognized FORM: {form}")

    out["form"] = form
    # page hash
    out["page_hash"] = hashlib.sha256(json.dumps(out, sort_keys=True).encode()).hexdigest()
    # write report
    rpt_path = os.path.join(REPORTS, f"{name}.json")
    with open(rpt_path,"w") as f:
        json.dump(out, f, indent=2)
    print(f"[OK] {name} -> {rpt_path}  commit={out['commit_4bit']}")
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cql", nargs="?", help="Path to a .cql file")
    ap.add_argument("--all", action="store_true", help="Run all bundled examples")
    args = ap.parse_args()

    if args.all:
        examples = ["optics_fft_ifft.cql","materials_ladder_ipa_rpa.cql","spintronics_chiral_filter.cql"]
        for ex in examples:
            run_one(os.path.join(BASE,"examples",ex))
    elif args.cql:
        run_one(args.cql)
    else:
        print("Usage: python3 harness_ext.py <file.cql>  or  --all")

if __name__ == "__main__":
    main()
