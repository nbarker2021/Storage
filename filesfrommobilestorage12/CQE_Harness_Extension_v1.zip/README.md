# CQE Harness Extension v1

This bundle adds runnable **CQL examples** and a **minimal harness** that executes:
- Octet view checks
- Mirror (forward ∘ inverse ≈ identity) checks
- Δ-lift (local repair) effectiveness checks
- Strict ratchet checks
- 4-bit commit computation

The examples are synthetic but **numerical** and reproducible. Use them as templates for real data.

## Contents
- `examples/optics_fft_ifft.cql` — 8-view optics octet with FFT↔IFFT mirror and a simple Δ-lift that removes an astigmatism-like phase term.
- `examples/materials_ladder_ipa_rpa.cql` — materials “Jacob’s ladder” style with IPA↔RPA mirror and a kernel-broadening Δ-lift.
- `examples/spintronics_chiral_filter.cql` — chirality sidecar with L↔R mirror and a Δ-lift bias tweak.
- `harness/harness_ext.py` — run the harness on one or all CQL files and produce JSON receipts.
- `reports/` — output JSON reports with 4-bit commit codes.

## Quick start
```bash
python3 harness/harness_ext.py examples/optics_fft_ifft.cql
python3 harness/harness_ext.py examples/materials_ladder_ipa_rpa.cql
python3 harness/harness_ext.py examples/spintronics_chiral_filter.cql

# Or run all examples
python3 harness/harness_ext.py --all
```

Each run emits a `reports/<name>.json` like:
```json
{
  "form": "TOROIDAL_OPTICS_A",
  "octet_views": 8,
  "mirror_error": 2.3e-7,
  "lift_improvement": 0.41,
  "strict_pass": true,
  "commit_4bit": "1111",
  "page_hash": "<sha256-of-report>"
}
```

### 4-bit commit (demo mapping)
- b1 = OCTET coverage (≥ 8)
- b2 = MIRROR within tolerance
- b3 = Δ-LIFT decreases error (improves metric)
- b4 = STRICT ratchet satisfied (strict thresholds)

> Adjust the mapping to your governance doc if needed.

## Notes
- This harness uses **small 64×64 grids** for FFT demos to stay lightweight.
- All data is generated deterministically (set numpy RNG seed).
- Replace synthetic generators with your domain loaders to go IRL.

