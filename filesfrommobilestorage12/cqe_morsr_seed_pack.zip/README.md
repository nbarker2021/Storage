
# CQE + MORSR Seed Pack (Spec + Schemas + Examples)

This bundle contains:
- `eo_v1.schema.json` — E8 Overlay schema
- `morsr_handshake_v1.schema.json` — Handshake packet schema
- `cqe_config_default_v1.json` — Default config
- `example_alena_eo.json`, `example_superperm_n6_eo.json`, `example_voice_family_eo.json` — Example overlays (DEMO placeholders)
- `openapi.yaml` — Minimal API contracts

All overlays are canonicalized, content-addressed, and intended to be signed at mint time. These examples include placeholder signatures and IDs.
