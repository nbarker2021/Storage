import json, os, sys, glob

def load_yaml_like(path):
    # accept JSON-like YAML produced by our dumper
    import json
    with open(path, 'r') as f:
        return json.load(f)

def check_pack(pack_def, example):
    rc = {"pass": True, "reasons": []}
    strict = pack_def.get("strict", {})
    r = example.get("receipts", {})
    # PACK-specific checks
    name = pack_def.get("description","").lower()
    # Generic interpretations
    def ge(key, thr):
        val = r.get(key, None)
        if val is None or val < thr:
            rc["pass"] = False; rc["reasons"].append(f"{key}<{thr} (got {val})")
    def le(key, thr):
        val = r.get(key, None)
        if val is None or val > thr:
            rc["pass"] = False; rc["reasons"].append(f"{key}>{thr} (got {val})")
    # EM_NH
    if "non-reciprocal magnetism" in name:
        if "min_chirality" in strict: ge("chirality_score", strict["min_chirality"])
        if "min_nonrecip" in strict: ge("nonreciprocity_index", strict["min_nonrecip"])
        if "min_gap_GHz" in strict: ge("floquet_gap_GHz", strict["min_gap_GHz"])
        if "max_temp_rise_K" in strict: le("max_temp_rise_K", strict["max_temp_rise_K"])
    # NEURO
    if "hippocampal" in name:
        if "min_MI" in strict: ge("spike_content_MI", strict["min_MI"])
        if "min_phase_R" in strict: ge("phase_lock_R", strict["min_phase_R"])
        if "max_replay_err_cm" in strict: le("replay_err_cm", strict["max_replay_err_cm"])
    # CHEM_ATRO
    if "atropisomer" in name or "macrocycle" in name:
        if "min_barrier_kcal" in strict: ge("deltaG_dagger_axis_kcal", strict["min_barrier_kcal"])
        if "min_ee" in strict: ge("er", strict["min_ee"])
        if "min_dr" in strict: ge("dr", strict["min_dr"])
        if "min_yield_pct" in strict: ge("yield_pct", strict["min_yield_pct"])
    # CHEM_RELAY
    if "hydrofunctionalization" in name:
        if "min_ee" in strict: ge("ee", strict["min_ee"])
        if "min_dr" in strict: ge("dr_alpha", strict["min_dr"])
        if "min_dr" in strict: ge("dr_gamma", strict["min_dr"])
        if "min_site_selectivity_pct" in strict: ge("site_selectivity_pct", strict["min_site_selectivity_pct"])
        if "min_mass_balance_pct" in strict: ge("mass_balance_pct", strict["min_mass_balance_pct"])
    # MAT_GRO
    if "graphene-oxide" in name:
        # window check: abs(deltaEg) <= window
        if "deltaEg_window_eV" in strict:
            val = abs(r.get("deltaEg_eV", 1e9))
            if val > strict["deltaEg_window_eV"]:
                rc["pass"] = False; rc["reasons"].append(f"|deltaEg_eV|>{strict['deltaEg_window_eV']} (got {val})")
        if "min_abs_deltaPhi_eV" in strict:
            val = abs(r.get("deltaPhi_eV", 0.0))
            if val < strict["min_abs_deltaPhi_eV"]:
                rc["pass"] = False; rc["reasons"].append(f"|deltaPhi_eV|<{strict['min_abs_deltaPhi_eV']} (got {val})")
        if "min_ads_energy_mag_eV" in strict:
            val = abs(r.get("ads_energy_eV", 0.0))
            if val < strict["min_ads_energy_mag_eV"]:
                rc["pass"] = False; rc["reasons"].append(f"|ads_energy_eV|<{strict['min_ads_energy_mag_eV']} (got {val})")
    # PHOT_GAUGE
    if "gauge fields in photonics" in name:
        if "min_gap_GHz" in strict: ge("gap_GHz", strict["min_gap_GHz"])
        if "max_linewidth_GHz" in strict: le("linewidth_GHz", strict["max_linewidth_GHz"])
        if "min_edge_Q" in strict: ge("edge_mode_Q", strict["min_edge_Q"])
    return rc

def main(repo_root):
    packs_dir = os.path.join(repo_root, "packs")
    ex_g_dir = os.path.join(repo_root, "examples", "golden")
    ex_b_dir = os.path.join(repo_root, "examples", "baseline")
    report_path = os.path.join(repo_root, "reports", "summary.csv")

    # load packs
    packs = {}
    for p in glob.glob(os.path.join(packs_dir, "*.yaml")):
        packs[os.path.splitext(os.path.basename(p))[0]] = load_yaml_like(p)
    rows = []
    for cls, kind in [("golden", ex_g_dir), ("baseline", ex_b_dir)]:
        for ex in glob.glob(os.path.join(kind, "*.yaml")):
            pack = os.path.splitext(os.path.basename(ex))[0]
            exd = load_yaml_like(ex)
            rc = check_pack(packs[pack], exd)
            rows.append({
                "class": cls,
                "pack": pack,
                "fourbit": exd.get("fourbit","----"),
                "pass": rc["pass"],
                "reasons": "; ".join(rc["reasons"])
            })
    import pandas as pd
    df = pd.DataFrame(rows)
    df.to_csv(report_path, index=False)
    print("WROTE", report_path)

if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv)>1 else "."
    main(root)