# CommonsLedger v0.3.5 (Lab Toolchains + Pricing + Tool Tokens)

## Run
```
python -m server.server
```
Open web:
- `web/index.html`
- `web/ca.html`

## Notes
- Balances start empty. Credit yourself with MERIT via ledger genesis or admin (not included here).
- Tool registration and suite run debit MERIT per policy.
- MERIT converts **down** into domain credits; reverse conversion blocked by policy.
- Tool Tokens: request -> approve (manual via /tooltoken/approve) -> settle_usage events split MERIT to system and requester.
