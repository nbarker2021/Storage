# CQE Formal Spec — v1.0
Timestamp: 2025-09-20T21:59:35.291677Z

This bundle formalizes the CQE system end‑to‑end: axioms, data types, grammar, ledger schemas,
protocols, by‑hand kits, API skeleton, conformance tests, governance, and a tiny Python
harness to sanity‑check artifacts.

## Contents
- `CQE_Core_Spec_v1.md` — axioms, invariants, operators, state model.
- `CQL_Grammar_v0_1.md` — the CQE micro‑language (CQL) and its 2↔4↔8↔64 scaling.
- `Ledger_Schema_v1.json` — canonical JSON schema for ledger rows.
- `OpenAPI_CQE_OS_v0_1.yaml` — API skeleton for a CQE‑OS.
- `Sidecar_Catalog_v1.md` — 64 sidecars, structure, and registration rules.
- `ByHand_CardKit_v1.md` — card‑based implementation, balsa builds, team workflow.
- `Governance_Safety_v1.md` — receipts, redaction, reproducibility, and safety rails.
- `Roadmap_v1.md` — what remains to be proved, engineered, or validated.
- `Conformance_Tests_v1/` — golden tests (n=4 rest, n=5 octad census, etc.).
- `harness/harness_simple.py` — minimal checker to run on the tests & your own inputs.

## Quick start
1) Read `CQE_Core_Spec_v1.md` (20–30 min skim).
2) Glance `CQL_Grammar_v0_1.md`; try the examples.
3) Run the harness:
```bash
python3 harness/harness_simple.py Conformance_Tests_v1
```
4) For by‑hand: print `ByHand_CardKit_v1.md` and `Sidecar_Catalog_v1.md`.
5) For integration: adapt `OpenAPI_CQE_OS_v0_1.yaml` to your stack.

## Versioning
This bundle is self‑hashed. The SHA‑256 of each file is recorded in the harness banner.
