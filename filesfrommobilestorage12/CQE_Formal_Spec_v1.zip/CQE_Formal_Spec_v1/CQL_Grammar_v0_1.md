# CQL — CQE Query/Control Language v0.1

CQL drives the CQE machine in a small, composable syntax. It scales by factorable
dialects: 2‑view (CQL/2), 4‑view (CQL/4), 8‑view (CQL/8), and 64‑view (CQL/64).

## 1. Lexical
- Ident: `[A-Za-z_][A-Za-z0-9_]*`
- Number: decimal or fraction
- String: `"..."`
- Hash: hex `{64}`
- Bit4: `[01]{4}`

## 2. Core statements
```
form      := FORM ident USING code "(" params ")" GLUE glue ;
viewplan  := VIEWS "{" H1 ":" vexpr "," ... "," H8 ":" vexpr "}" ;
mirror    := MIRROR "(" fwd "," inv "," tau ")" ;
lift      := LIFT name "=" rule ;
strict    := STRICT normal "->" strict ;
meaning   := MEANING PACK ident WITH { key ":" value, ... } ;
run       := RUN OCTET ;            # evaluate views
gate      := GATE MIRROR ;          # apply mirror test
repair    := APPLY LIFT name ;      # local Δ
tighten   := RATCHET ;              # strict ratchet
commit    := COMMIT bit4 HASH hash ;
```

## 3. Example (CQL/8)
```
FORM LEECH_A USING CODE "Golay(24,12,8)" GLUE "half-shift" ;
VIEWS { H1: octad(1), H2: octad(2), H3: band("IR"), H4: band("UV"),
        H5: pose(0),  H6: pose(90), H7: pol("LHCP"), H8: pol("RHCP") } ;
MIRROR ( fft, ifft, 2e-3 );
LIFT   fix1 = local_identity("kernel-broadening-link");
STRICT {OPE:0.04,FCE:0.04} -> {OPE:0.03,FCE:0.03};
MEANING PACK EM_v3 WITH { units:"SI", domain:"optics" };
RUN OCTET ; GATE MIRROR ; APPLY LIFT fix1 ; RATCHET ;
COMMIT 1011 HASH "a0b3...f9" ;
```

## 4. Scaling
- CQL/2: minimal (A/B + mirror).  
- CQL/4: quadrants for fast gating.  
- CQL/8: full CQE octet.  
- CQL/64: hierarchical 8×8 tiling (frames, notational sugar): `FRAME[i,j].Hk`.

