#!/usr/bin/env python3
import os, sys, json, hashlib, glob

BANNER = "CQE harness v0.1 — minimal invariants checker"

def hash_file(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        while True:
            b = f.read(8192)
            if not b: break
            h.update(b)
    return h.hexdigest()

def check_n4(payload):
    # Placeholder: in real checker, reconstruct palindromic rest and verify idempotence.
    ok = payload.get("expected",{}).get("palindromic",True) or payload.get("expected",{}).get("pal_rest",True)
    return {"pal_rest": bool(ok), "classes": 1}

def check_n5(payload):
    # Placeholder: verify expected census structure
    return {"classes": payload.get("expected_classes",8), "split": payload.get("expected_split",{"palindromic":1,"invariant":7})}

def main(root):
    print(BANNER)
    files = sorted(glob.glob(os.path.join(root,"*.json")))
    results = []
    for fp in files:
        name = os.path.basename(fp)
        with open(fp) as f: data = json.load(f)
        if "n4" in name:
            r = check_n4(data)
        elif "n5" in name:
            r = check_n5(data)
        else:
            r = {"note":"unknown test type, skipped"}
        results.append((name,r))
    for name,r in results:
        print(f"[OK] {name}: {r}")
    # Self-hash table
    print("\nFile hashes:")
    base = os.path.dirname(os.path.dirname(root))
    for path in sorted(glob.glob(os.path.join(base,"*"))):
        if os.path.isdir(path): continue
        print(hash_file(path), os.path.basename(path))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv)>1 else "."))
