# By‑Hand CardKit v1

## Decks
- **Decks**: multiple standard decks; suits bound to sidecars, ranks bound to roles.
- **Ranks**: A=primitive, 2..8 = k‑ary synthesis, 9=full idea, 10=parity twin,
  J/Q/K = observers (alternate viewers), 3 extra faces = witness cards,
  Jokers (2 colors) = Cartan/subharmonic cross‑chamber links.
- **4‑bit receipt strip**: four checkboxes per run.

## Moves
1) Layout a 4×4 rest grid; produce n=4 palindrome with your As..4s.  
2) Attempt n=5: enumerate placements; group into 8 inequivalent classes.
3) Build octet overlays with 2..8s; place 9/10 as committed/full/parity.
4) Use faces to swap viewers; Jokers to bridge chambers (record the link).

## Team room
- 8 stations mirror the sidecars; a center ledger wall records commits.
- Balsa/tape frames let you realize hypercubes and toroidal wraps physically.
- Measurement stations (scales, optics bench, RF kit) feed tokens/receipts.

## Ledger
- Use the supplied worksheet set: octet, mirror, Δ‑lift, strict, 4‑bit, page hash.
