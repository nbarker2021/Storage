# Sidecar Catalog v1 — 64 rails

Each sidecar S_k is a **mini‑lab** with: tokens, DNA‑10, admissible views, mirror, Δ‑lifts,
and strict thresholds. All share the same CQE gates; only tokens differ.

## Index (8×8 tiles)
S0 MATH • S1 OPTICS • S2 THERMAL • S3 POLAR • S4 EM_FIELD • S5 SPINTRONICS • S6 BIO_COHERENCE • S7 DNA/RNA
S8 MATERIALS • S9 CHEMISTRY • S10 MECH • S11 CONTROL • S12 FIN_RISK • S13 ROBOT_KIN • S14 COSMOS • S15 GRAPH
S16 PLASMA • S17 THz • S18 CRYO • S19 RAD_TRANSFER • S20 SPECTRO • S21 IMAGING • S22 NEURO • S23 COGNITION
S24 GEO/CLIMATE • S25 OCEAN • S26 AERO • S27 IONICS • S28 QUANTUM_HW • S29 QEC • S30 LOGIC • S31 ML
S32 SECURITY • S33 HCI • S34 NETWORK • S35 STORAGE • S36 LEDGER • S37 LEGAL • S38 ETHICS • S39 GOV
S40 ENERGY • S41 POWER • S42 PHOTONICS • S43 FIBER • S44 RF • S45 ANTENNA • S46 TERRESTRIAL • S47 SPACE
S48 MED_IMAGING • S49 GENOMICS • S50 PROTEOMICS • S51 METABO • S52 MICROBIO • S53 PHARMA • S54 AGRI • S55 FOOD
S56 EDUCATION • S57 UX • S58 ANALYTICS • S59 SIM • S60 VIZ • S61 DATA • S62 TEST • S63 OPS

## Template (per sidecar)
- Tokens: stand‑ins with units/guards.
- DNA‑10: [timing, polarity, scale, pose, domain, conditioning, units, precision, cost, seed].
- Views: 8 views H1..H8 (bands, poses, polarizations…).
- Mirror: (T, T^{-1}, τ) appropriate to the domain.
- Δ‑lifts: small rules approved for local repair.
- Strict: normal→strict tightening bounds.
- Receipts: 4‑bit mapping per sidecar (documented here).
