# Roadmap v1

1) Formal proof pack: complete n=5 octad enumeration under stated invariants (paper‑grade).  
2) Category lift: functor from CQL programs to lattice actions; prove commutation with automorphisms.  
3) Confluence: Δ‑lift rewrite system is terminating and locally confluent under guard set.  
4) Reference implementations: CQE‑OS (Rust/Go), CardKit mobile app, lab‑bench templates.  
5) Benchmarking: publish conformance vectors; third‑party reproducibility challenge.  
6) Education: open courseware (Basics → Applied → Safety).  
