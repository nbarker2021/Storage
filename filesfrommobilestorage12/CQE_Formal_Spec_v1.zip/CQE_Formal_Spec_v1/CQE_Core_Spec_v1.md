# CQE Core Spec — v1.0

## 0. One‑line
**Code → Lattice → Overlay → Mirror → Commit.**  
Discrete constraints become geometry; eight symmetry‑related views cover the local
neighborhood; a forward/inverse **Mirror** test must rejoin a palindromic **Rest**; only
then may a 4‑bit **Commit** be recorded. Meaning is swappable tokens; form is fixed.

## 1. Objects
- **Form F**: a Construction‑A shell with parameters (prime p, code C, glue g).  
  Examples: E8 from (p=2, C=Ext.Hamming(8,4), half‑shift); Leech from (p=2, C=Ext.Golay(24,12,8), glue).
- **View plan V**: an ordered octet `{H1..H8}` plus gray **Rest** box.
- **Mirror M**: a paired transform `(T, T^{-1})` with tolerance τ; passes if `||T^{-1}(T(x))-x|| ≤ τ` for all checked x.
- **Δ‑lift**: a local rewrite rule R that reduces debt (defects) and preserves determinism.
- **Strict ratchet**: thresholds {normal, strict} with monotone tightening after pass.
- **Receipts**: 4‑bit code b∈{0,1}^4, votes, OPE/FCE debts, page hash h.
- **Meaning pack P**: swappable tokens (units, domains, costs, seeds) that do not alter F or V.

## 2. Invariants
I1. **Coverage**: at least 8 materially independent views; no commit with <4 passing views.  
I2. **Palindromic Rest**: Mirror must round‑trip within τ; failures trigger Δ‑lift, not commit.  
I3. **Monotonicity**: Strict thresholds only tighten post‑pass.  
I4. **Idempotence**: Re‑canonicalization does not change a committed state.  
I5. **Rotation/Mirror invariance**: Dihedral actions on V permute labels, not legality.  
I6. **Reproducibility**: (F, automorphism a, V, P, thresholds, receipts) suffice to replay 1:1.

## 3. Operators
- `overlay(F,V,x)` → 8 traces around x.  
- `mirror(M,x,τ)` → pass/fail + residual r.  
- `lift(R,x)` → x' with debt↓ and determinism preserved.  
- `ratchet(Θ, pass)` → Θ' with tightened bounds if pass else unchanged.  
- `commit(b, h)` → record once; no mutation.

## 4. n‑hinges (by hand)
- n=4: unique palindromic rest on a 4×4 parity grid.  
- n=5: exactly 8 inequivalent minimal insertions (one palindromic + 7 invariant).  
- Consequence: octad is forced; higher scaffolds (E8, Leech) become the natural shells.

## 5. Automorphisms
- `a ∈ Aut(F)`: M24/Monster actions for Leech; Weyl for E8.  
- Cloning = applying `a` to produce isomorphic geometry; ledger records `a`.

## 6. Receipts & 4‑bit
- 4 bits encode the minimal deterministic receipt for a pass (domain‑defined mapping).  
- Longer receipts (8/64 bits) optional; 4‑bit always present.

## 7. Semantics discipline
- **Meaning ≠ Form**: P may change anytime pre‑commit; commit freezes b, not P.  
- Bad data never rests: failing views stay provisional or are annihilated with breadcrumbs.

