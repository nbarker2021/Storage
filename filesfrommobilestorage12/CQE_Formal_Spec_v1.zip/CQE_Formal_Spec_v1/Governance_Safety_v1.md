# Governance & Safety v1

- **No black boxes**: every commit backed by receipts and a hash of evidence.
- **Bad data never rests**: failures stay provisional; non‑working album retains breadcrumbs.
- **Redaction**: content‑aware masks permitted; hashes stay stable.
- **Safety gates**: medical/dual‑use domains never emit operational recipes; produce abstract tokens and pass/fail only.
- **Equity**: by‑hand kits enable low‑resource replication; OS APIs mirror the same gates.
