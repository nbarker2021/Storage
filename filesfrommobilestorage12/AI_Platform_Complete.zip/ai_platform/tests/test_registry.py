from platform.registry.registry import register_dataset, latest_dataset, register_model, latest_model
from pathlib import Path
import json

def test_registry(tmp_path, monkeypatch):
    from platform.registry import registry as reg
    monkeypatch.setattr(reg, "REGISTRY_PATH", tmp_path/"registry.json")
    ds = register_dataset("toy","0.1.0","/data.parquet","/schema.yaml",{"rows":10})
    assert ds["name"]=="toy"
    assert latest_dataset("toy")["version"]=="0.1.0"
    m = register_model("mlp","/ckpt.pt",{"acc":0.9})
    assert latest_model("mlp")["ckpt"]=="/ckpt.pt"
