import torch, torch.nn as nn

class MLP(nn.Module):
    def __init__(self, in_dim=2, hidden=[128,64], out_dim=2):
        super().__init__()
        layers=[]; prev=in_dim
        for h in hidden:
            layers += [nn.Linear(prev,h), nn.ReLU()]; prev=h
        layers += [nn.Linear(prev,out_dim)]
        self.net = nn.Sequential(*layers)
    def forward(self, x): return self.net(x)
