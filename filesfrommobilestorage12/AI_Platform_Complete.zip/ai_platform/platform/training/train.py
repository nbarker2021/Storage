import argparse, json, yaml, random, numpy as np, torch
from pathlib import Path
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
from torch import nn
from platform.training.models.mlp import MLP
from platform.registry.registry import register_model
from platform.receipts import write_receipt

def load_split(parquet_path: Path, split: str):
    base = parquet_path.parent
    fp = base / f"{split}.parquet"
    if not fp.exists(): fp = parquet_path
    df = pd.read_parquet(fp)
    X = torch.tensor(df[["feature_1","feature_2"]].values, dtype=torch.float32)
    y = torch.tensor(df["label"].values, dtype=torch.long)
    return X, y

def main(args):
    cfg = yaml.safe_load(Path(args.cfg).read_text())
    random.seed(cfg["seed"]); np.random.seed(cfg["seed"]); torch.manual_seed(cfg["seed"])
    Xtr, ytr = load_split(Path(args.data), "train")
    Xva, yva = load_split(Path(args.data), "val")

    train_ds = TensorDataset(Xtr,ytr); val_ds = TensorDataset(Xva,yva)
    train_loader = DataLoader(train_ds, batch_size=cfg["batch_size"], shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=cfg["batch_size"])

    model = MLP(in_dim=2, hidden=cfg["model"]["hidden_sizes"], out_dim=2)
    opt = torch.optim.Adam(model.parameters(), lr=cfg["optimizer"]["lr"])
    loss_fn = nn.CrossEntropyLoss()

    best_val = 1e9; patience = cfg.get("early_stopping",{}).get("patience",3); hits=0
    hist=[]

    for epoch in range(cfg["epochs"]):
        model.train(); tr_loss=0.0
        for xb, yb in train_loader:
            opt.zero_grad(); loss = loss_fn(model(xb), yb); loss.backward(); opt.step(); tr_loss += loss.item()
        model.eval(); va_loss=0.0; correct=0; total=0
        with torch.no_grad():
            for xb, yb in val_loader:
                preds = model(xb); va_loss += loss_fn(preds, yb).item()
                correct += (preds.argmax(1)==yb).sum().item(); total += len(yb)
        acc = correct/max(total,1); hist.append({"epoch":epoch+1,"val_loss":va_loss,"val_acc":acc})
        print(f"epoch={epoch+1} val_loss={va_loss:.4f} acc={acc:.3f}")
        if va_loss < best_val - cfg.get("early_stopping",{}).get("min_delta",0.0):
            best_val = va_loss; hits=0
        else:
            hits += 1
            if hits >= patience: 
                print("early stopping"); break

    outdir = Path(args.out); ckpt = outdir/"checkpoints"; outdir.mkdir(parents=True, exist_ok=True); ckpt.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), ckpt/"last.pt")
    (outdir/"train_history.json").write_text(json.dumps(hist, indent=2))
    mentry = register_model("mlp_small", str(ckpt/"last.pt"), {"val_best": best_val, "epochs": len(hist)})
    r = write_receipt("train", {"model": mentry, "history_path": str(outdir/'train_history.json')}, outdir/"receipts")
    print("TRAIN OK:", mentry); print("receipt:", r)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True); ap.add_argument("--cfg", required=True); ap.add_argument("--out", required=True)
    main(ap.parse_args())
