import argparse, json, torch, pandas as pd
from pathlib import Path
from sklearn.metrics import accuracy_score, f1_score
from platform.training.models.mlp import MLP
from platform.receipts import write_receipt

def main(args):
    df = pd.read_parquet(Path(args.data).parent/'test.parquet') if (Path(args.data).parent/'test.parquet').exists() else pd.read_parquet(args.data)
    X = torch.tensor(df[["feature_1","feature_2"]].values, dtype=torch.float32)
    y = torch.tensor(df["label"].values, dtype=torch.long)
    model = MLP(in_dim=2, hidden=[128,64], out_dim=2)
    state = torch.load(args.ckpt, map_location="cpu"); model.load_state_dict(state); model.eval()
    with torch.no_grad():
        preds = model(X).argmax(1).cpu().numpy()
    y_true = y.cpu().numpy()
    acc = float(accuracy_score(y_true, preds)); f1 = float(f1_score(y_true, preds))
    outdir = Path(args.out); outdir.mkdir(parents=True, exist_ok=True)
    (outdir/"metrics.json").write_text(json.dumps({"accuracy":acc,"f1":f1}, indent=2))
    r = write_receipt("eval", {"metrics_path": str(outdir/'metrics.json')}, Path("runs/latest/receipts"))
    print("EVAL OK: accuracy=", acc, "f1=", f1); print("receipt:", r)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True); ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
    main(ap.parse_args())
