from fastapi import FastAPI
from pydantic import BaseModel
import torch
from pathlib import Path
from platform.training.models.mlp import MLP

app = FastAPI(title="AI Platform Inference", version="0.1.0")

class Item(BaseModel):
    feature_1: float
    feature_2: float

model = MLP(in_dim=2, hidden=[128,64], out_dim=2)

@app.on_event("startup")
def load_model():
    ckpt = Path("runs/latest/checkpoints/last.pt")
    if ckpt.exists():
        state = torch.load(ckpt, map_location="cpu")
        model.load_state_dict(state); model.eval()

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/predict")
def predict(item: Item):
    with torch.no_grad():
        x = torch.tensor([[item.feature_1, item.feature_2]], dtype=torch.float32)
        y = int(model(x).argmax(1).item())
    return {"label": y}
