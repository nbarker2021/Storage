from __future__ import annotations
import hashlib, json, time
from pathlib import Path
from typing import Any, Dict

def _nibble(s: str) -> str:
    return format(int(hashlib.sha256(s.encode()).hexdigest()[0], 16), "04b")

def write_receipt(kind: str, payload: Dict[str, Any], outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    payload = dict(payload)
    payload["kind"] = kind
    payload["ts"] = ts
    payload["four_bit"] = _nibble(json.dumps(payload, sort_keys=True))
    path = outdir / f"{kind}_{ts}.json"
    path.write_text(json.dumps(payload, indent=2))
    return {"path": str(path), "four_bit": payload["four_bit"]}
