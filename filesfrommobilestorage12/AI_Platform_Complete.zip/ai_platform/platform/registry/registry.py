from __future__ import annotations
import json, time
from pathlib import Path
from typing import Dict, Any, Optional

REGISTRY_PATH = Path("runs/registry.json")

def _load() -> Dict[str, Any]:
    if REGISTRY_PATH.exists():
        return json.loads(REGISTRY_PATH.read_text())
    return {"datasets": [], "models": []}

def _save(reg: Dict[str, Any]) -> None:
    REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_PATH.write_text(json.dumps(reg, indent=2))

def register_dataset(name: str, version: str, path: str, schema_path: str, meta: Dict[str, Any] | None = None):
    reg = _load()
    entry = {"name": name, "version": version, "path": path, "schema": schema_path, "meta": meta or {}, "ts": int(time.time())}
    reg["datasets"].append(entry); _save(reg); return entry

def latest_dataset(name: str) -> Optional[Dict[str, Any]]:
    reg = _load(); ds = [d for d in reg["datasets"] if d["name"] == name]
    return sorted(ds, key=lambda d: (d["version"], d["ts"]), reverse=True)[0] if ds else None

def register_model(tag: str, ckpt_path: str, meta: Dict[str, Any] | None = None):
    reg = _load()
    entry = {"tag": tag, "ckpt": ckpt_path, "meta": meta or {}, "ts": int(time.time())}
    reg["models"].append(entry); _save(reg); return entry

def latest_model(tag: str) -> Optional[Dict[str, Any]]:
    reg = _load(); ms = [m for m in reg["models"] if m["tag"] == tag]
    return sorted(ms, key=lambda m: m["ts"], reverse=True)[0] if ms else None
