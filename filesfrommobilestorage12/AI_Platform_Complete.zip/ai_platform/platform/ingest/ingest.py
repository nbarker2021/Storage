import argparse, json, yaml, math
from pathlib import Path
import pandas as pd
from rich import print
from platform.registry.registry import register_dataset
from platform.receipts import write_receipt

def validate(df: pd.DataFrame, schema: dict) -> None:
    feat_names = [f["name"] for f in schema["features"]]
    lbl = schema["label"]["name"]
    cols = feat_names + [lbl]
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if "constraints" in schema and "label_values" in schema["constraints"]:
        allowed = set(schema["constraints"]["label_values"])
        bad = set(df[lbl].unique()) - allowed
        if bad: raise ValueError(f"Unexpected label values: {bad}")

def split(df: pd.DataFrame, splits: dict):
    n = len(df)
    idx = df.sample(frac=1.0, random_state=1337).reset_index(drop=True)
    n_train = int(n * splits.get("train", 0.8))
    n_val   = int(n * splits.get("val", 0.1))
    train = idx.iloc[:n_train]; val = idx.iloc[n_train:n_train+n_val]; test = idx.iloc[n_train+n_val:]
    return train, val, test

def main(args):
    src = Path(args.src); dst = Path(args.dst); dst.mkdir(parents=True, exist_ok=True)
    schema = yaml.safe_load(Path(args.schema).read_text())
    rows = []
    for p in src.glob("*.csv"):
        df = pd.read_csv(p)
        rows.append(df)
    if not rows:
        print("[yellow]No CSV files in", src, "— add CSVs and rerun.[/yellow]"); return
    df = pd.concat(rows, axis=0, ignore_index=True)
    validate(df, schema)
    train, val, test = split(df, schema.get("splits", {}))
    train.to_parquet(dst/"train.parquet", index=False)
    val.to_parquet(dst/"val.parquet", index=False)
    test.to_parquet(dst/"test.parquet", index=False)
    allp = dst/"dataset.parquet"; df.to_parquet(allp, index=False)
    stats = df.describe(include="all").to_dict(); (dst/"stats.json").write_text(json.dumps(stats, indent=2))
    entry = register_dataset(schema["name"], schema["version"], str(allp), args.schema, meta={"rows": len(df)})
    r = write_receipt("ingest", {"dataset": entry, "stats_path": str(dst/'stats.json')}, Path("runs/latest/receipts"))
    print("[green]INGEST OK[/green]:", entry)
    print("receipt:", r)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True); ap.add_argument("--dst", required=True); ap.add_argument("--schema", required=True)
    main(ap.parse_args())
