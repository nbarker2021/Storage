# AI Platform (SIM-first lane, locked)

This repo is a clean, deterministic scaffold for a full-stack ML platform:
**ingest → train → eval → serve → ops**. It is intentionally small, explicit, and portable.

**Operate SIM-first** (plan/compose steps) and only "spend" effort on the chosen lane.
This scaffold bakes that work order in and writes tiny **receipts** for each step.

## Quickstart
```bash
make setup           # (optional) create venv and install deps
make ingest          # read CSVs under data/raw, validate, and register dataset
make train           # train a small MLP and save checkpoints under runs/latest
make eval            # evaluate the latest checkpoint
make serve           # run FastAPI server with /predict and /health
```
