from typing import List, Dict, Any
import math

def triad_adequacy(triad: List[str], inverse: List[str], tests: List[str]) -> float:
    # Placeholder: score based on uniqueness + inverse disjointness + tests length
    if not triad or not inverse: return 0.0
    uniq = len(set(triad)) + len(set(inverse))
    disjoint = len(set(triad).intersection(set(inverse))) == 0
    base = min(1.0, uniq/6.0) * (1.0 if disjoint else 0.5)
    return min(1.0, base + 0.02*len(tests))

def underverse_coverage(matrix_8x8: List[List[int]]) -> float:
    resolved = sum(1 for row in matrix_8x8 for v in row if v in (0,1))
    return resolved / 64.0

def diversity_ok(vecs: List[List[float]], min_angle_deg: float, angle_fn) -> bool:
    for i in range(len(vecs)):
        for j in range(i+1, len(vecs)):
            if angle_fn(vecs[i], vecs[j]) < min_angle_deg:
                return False
    return True
