from typing import List, Dict, Any, Tuple
from .e8 import sub, mul, norm

def boundary_walk(x0: List[float], x1: List[float], steps: int = 16) -> List[List[float]]:
    d = sub(x1, x0)
    return [[x0[i] + (k/steps)*d[i] for i in range(len(x0))] for k in range(steps+1)]

def evidence_yield(cases: List[int], hits: List[int]) -> float:
    if not cases: return 0.0
    return sum(1 for h in hits if h) / len(cases)
