import math
from typing import List, Dict

PHI = (1 + 5**0.5)/2

class PhiScheduler:
    def __init__(self, n: int):
        self.n = n; self.i = 0
        self.step = int(n/PHI)

    def next(self) -> int:
        self.i = (self.i + self.step) % self.n
        return self.i

def bounded_message_passing(A: Dict[int, List[int]], seeds: List[int], T=2, alpha=0.85) -> Dict[int, float]:
    x = {i:0.0 for i in A}
    for s in seeds: x[s] = 1.0
    b = x.copy()
    for _ in range(T):
        nx = {i:0.0 for i in A}
        for i, nbrs in A.items():
            s = sum(x[j] for j in nbrs)/max(1, len(nbrs))
            nx[i] = alpha*s + (1-alpha)*b.get(i,0.0)
        x = nx
    return x

def plan_radius(evidence_sigma: float, divergence_sigma: float, r0=1, k1=1.0, k2=1.0) -> int:
    r = r0 + k1*evidence_sigma - k2*divergence_sigma
    return max(1, int(round(r)))

def plan_elevators(edge_score: float, stability: float, k0=1, c1=2.0, c2=1.0) -> int:
    kappa = k0 + c1*edge_score - c2*stability
    return max(0, int(round(kappa)))
