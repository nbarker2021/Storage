import json, re
from typing import Any

_JSON5_COMMENTS = re.compile(r"//.*?$|/\*.*?\*/", re.MULTILINE|re.DOTALL)
_TRAILING_COMMAS = re.compile(r",\s*([}\]])")

def loads(s: str) -> Any:
    s = _JSON5_COMMENTS.sub("", s)
    s = _TRAILING_COMMAS.sub(r" \1", s)
    return json.loads(s)

def dumps(obj: Any, **kw) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, **kw)
