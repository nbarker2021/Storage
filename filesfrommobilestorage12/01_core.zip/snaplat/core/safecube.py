from typing import Dict, Any

def green_faces(snapshot: Dict[str, Any]) -> bool:
    faces = snapshot.get("faces", {})
    for k in ("legal","technical","operational","ethical"):
        if faces.get(k,{}).get("status") != "green":
            return False
    return True
