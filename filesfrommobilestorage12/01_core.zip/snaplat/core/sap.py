from typing import Dict, Any
from .safecube import green_faces

def sentinel_attest(obj: Dict[str, Any]) -> bool:
    return obj is not None

def arbiter_decide(case: Dict[str, Any]) -> Dict[str, Any]:
    allow = green_faces(case.get("safe_cube", {}))
    return {"decision": "allow" if allow else "deny", "reason": "faces" if not allow else ""}

def porter_lane(posture: str) -> str:
    return "public" if posture.lower() == "public" else "internal"
