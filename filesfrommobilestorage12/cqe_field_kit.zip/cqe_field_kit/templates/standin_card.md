# Stand‑in Token Card (3×5 index card)

- id: __________________________  (e.g., tok-psf-lambda)
- kind:  □ measure  □ var  □ const  □ op  □ unit  □ domain
- rail/sidecar: _________________  (e.g., OPTICS, THERMAL, MATH)
- quantity/symbol: _______________
- unit: __________________________
- value / prior: _________________   ± __________
- guards (range, temp, etc.): ____________________________________________
- calibration_ref / provenance: __________________________________________
- hue16: __________  grad: _______  salted_hash: _________________________
- receipts_ptr (after run): ______________________________________________

**Rule:** this card carries behavior + units only. **No human meaning** binds until a 4‑bit commit exists.
