# Octet Overlay Sheet (+ Palindromic Rest)

Gray center = palindromic rest (forward∘inverse ≈ identity within thresholds).
Color the eight views around it. Use ✔/✖ in each box; annotate Δ‑lifts (red), strict ratchet (gold), receipts (blue).

[ v1 ]  [ v2 ]  [ v3 ]  [ v4 ]

[ v5 ]  [pal]  [ v6 ]  [ v7 ]

[   ]  [ v8 ]  [   ]  [   ]

Legend:
- Δ‑lift (red): local repair that lowers debt without moving targets.
- Strict (gold): tighten a bound **after** a pass.
- Receipts (blue): note OPE/FCE, whiteness, |ρ|, leakage, guards.

**Stop rule:** Freeze views when debt slope < τ and required fills (FVA) are covered.
