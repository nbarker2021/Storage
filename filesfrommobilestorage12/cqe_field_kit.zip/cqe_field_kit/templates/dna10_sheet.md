# DNA‑10 State Save (attach to a bundle)

Item/Torus id: __________________________   Date: __________  Page: ____

[ ] timing: ______________________________ (e.g., 13×N s)
[ ] polarity: ____________________________ (on/off; L/R; sign conventions)
[ ] scale: _______________________________ (e.g., 1.5 m aperture)
[ ] pose: ________________________________ (off‑axis, orientation notes)
[ ] domain: ______________________________ (bands, materials, regimes)
[ ] conditioning: ________________________ (well‑posed? ill‑conditioned?)
[ ] units: _______________________________
[ ] precision: ___________________________ (e.g., 1e‑3, 50 digits)
[ ] cost: ________________________________ (ops/time/budget notes)
[ ] seed: ________________________________ (random/test seed)

**Mirror ready?** □ yes  □ no
