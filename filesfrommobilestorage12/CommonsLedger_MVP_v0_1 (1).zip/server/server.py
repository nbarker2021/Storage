\
import os, json, time, hashlib, random
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import sys, yaml

ROOT = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.abspath(os.path.join(ROOT, ".."))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)

sys.path.append(os.path.join(BASE,"sidecar_adapters"))
from speedlight_router import Ledger, MintEngine

with open(os.path.join(BASE,"config","policy.yaml"),"r") as f:
    policy = yaml.safe_load(f)

ledger = Ledger(DATA)
engine = MintEngine(policy, ledger)

def read_json(req: BaseHTTPRequestHandler):
    length = int(req.headers.get("Content-Length","0") or "0")
    body = req.rfile.read(length) if length else b"{}"
    try:
        return json.loads(body.decode("utf-8"))
    except Exception:
        return {}

def respond(res: BaseHTTPRequestHandler, code, payload):
    b = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    res.send_response(code)
    # CORS for local file:// usage
    res.send_header("Access-Control-Allow-Origin", "*")
    res.send_header("Access-Control-Allow-Headers", "Content-Type")
    res.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
    res.send_header("Content-Type","application/json; charset=utf-8")
    res.send_header("Content-Length", str(len(b)))
    res.end_headers()
    res.wfile.write(b)

def ok(res: BaseHTTPRequestHandler, payload):
    respond(res, 200, payload)

def bad(res: BaseHTTPRequestHandler, code=400, msg="bad request"):
    respond(res, code, {"error": msg})

def normalize_tokens(text: str):
    import re
    toks = re.findall(r"[A-Za-z0-9]+", text.lower())
    return [t for t in toks if len(t) > 2]

def jaccard(a, b):
    A, B = set(a), set(b)
    if not A and not B: return 0.0
    return len(A & B) / max(1, len(A | B))

def guess_domains(tokens):
    # naive keyword mapping
    table = {
        "care": "CARETAKER", "grief": "CARETAKER", "shelter": "MERIT", "overdose": "AEGIS",
        "cooling": "INFRA", "bridge": "INFRA", "water": "GAIA",
        "ritual": "MYTHOS", "treaty": "ORBIT", "conflict": "ORBIT",
        "theorem": "THETA", "proof": "THETA", "design": "DAVINCI", "build": "DAVINCI",
        "art": "VANGOGH", "music": "VANGOGH",
    }
    hits = set()
    for t in tokens:
        if t in table: hits.add(table[t])
    if not hits: hits.add("MERIT")
    return sorted(hits)

def profile_path(actor_id):
    return os.path.join(DATA, f"profile_{actor_id}.json")

def load_profile(actor_id):
    p = profile_path(actor_id)
    if os.path.exists(p):
        return json.load(open(p))
    prof = {"actor_id": actor_id, "journals": 3, "sub_journals": 10, "drafts": {}}
    json.dump(prof, open(p, "w"))
    return prof

def save_profile(prof):
    json.dump(prof, open(profile_path(prof["actor_id"]), "w"))

def make_draft_id(actor, title):
    raw = f"{actor}|{title}|{time.time()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:12]

def load_lab(actor):
    p = os.path.join(DATA, f"lab_{actor}.json")
    if os.path.exists(p): return json.load(open(p))
    return None

def save_lab(actor, lab):
    json.dump(lab, open(os.path.join(DATA, f"lab_{actor}.json"), "w"))

class App(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        # CORS preflight
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.end_headers()

    def do_POST(self):
        p = urlparse(self.path).path
        if p == "/submit":
            obj = read_json(self)
            if not obj.get("actor_id") or not obj.get("domain_claims"):
                return bad(self, 400, "missing actor_id or domain_claims")
            rid_raw = hashlib.sha256(json.dumps(obj, sort_keys=True).encode("utf-8")).hexdigest()[:16]
            ledger.append({"type":"contribution","rid":rid_raw,"obj":obj,"ts":time.time()})
            rid, minted = engine.mint(obj)
            return ok(self, {"receipt_id":rid, "minted":minted})

        elif p == "/settle":
            obj = read_json(self)
            if "revenue_fiat" not in obj or "patterns" not in obj:
                return bad(self, 400, "missing revenue_fiat or patterns")
            engine.settle_paid_service(obj)
            return ok(self, {"status":"ok"})

        elif p == "/payout_wallet":
            data = json.load(open(os.path.join(DATA,"payout_wallet.json")))
            return ok(self, data)

        # --- New endpoints below ---
        elif p == "/profile":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            prof = load_profile(actor)
            # optional updates
            for k in ("journals","sub_journals"):
                if k in obj: prof[k] = int(obj[k])
            save_profile(prof)
            return ok(self, prof)

        elif p == "/link_suggest":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            papers = obj.get("papers", [])
            if len(papers) < 2:
                return bad(self, 400, "need at least 2 papers")
            # compute pairwise overlaps
            tokens = [normalize_tokens(p.get("title","") + " " + p.get("text","")) for p in papers]
            pairs = []
            for i in range(len(papers)):
                for j in range(i+1, len(papers)):
                    score = jaccard(tokens[i], tokens[j])
                    doms = list(sorted(set(guess_domains(tokens[i]) + guess_domains(tokens[j]))))[:3]
                    pairs.append({
                        "a": papers[i].get("id") or f"P{i}",
                        "b": papers[j].get("id") or f"P{j}",
                        "score": round(score, 3),
                        "suggested_domains": doms
                    })
            pairs.sort(key=lambda x: x["score"], reverse=True)
            return ok(self, {"links": pairs[:10]})

        elif p == "/draft":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            prof = load_profile(actor)
            if prof["sub_journals"] <= 0:
                return bad(self, 402, "no sub_journals available")
            title = obj.get("title","Untitled Draft")
            summary = obj.get("summary","")
            domains = obj.get("domains",["MERIT"])
            draft_id = make_draft_id(actor, title)
            prof["sub_journals"] -= 1
            prof["drafts"][draft_id] = {"title": title, "summary": summary, "domains": domains, "ts": time.time()}
            save_profile(prof)
            return ok(self, {"draft_id": draft_id, "remaining_sub_journals": prof["sub_journals"]})

        elif p == "/mint_from_draft":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            draft_id = obj.get("draft_id")
            prof = load_profile(actor)
            if prof["journals"] <= 0:
                return bad(self, 402, "no journals available")
            draft = prof["drafts"].get(draft_id)
            if not draft:
                return bad(self, 404, "draft not found")
            contribution = {
                "actor_id": actor,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "summary": draft["title"],
                "details": draft["summary"],
                "domain_claims": draft["domains"],
                "evidence": {
                    "endorsements": [],
                    "lineage_refs": [],
                    "deployments": 0,
                    "safety": {"non_coercive": True, "non_weaponizable": True, "harm_reduction_pass": True}
                }
            }
            rid_raw = hashlib.sha256(json.dumps(contribution, sort_keys=True).encode("utf-8")).hexdigest()[:16]
            ledger.append({"type":"contribution","rid":rid_raw,"obj":contribution,"ts":time.time()})
            rid, minted = engine.mint(contribution)
            prof["journals"] -= 1
            del prof["drafts"][draft_id]
            save_profile(prof)
            return ok(self, {"receipt_id": rid, "minted": minted, "remaining_journals": prof["journals"]})

        elif p == "/lab/start":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            size = int(obj.get("size", 32))
            mode = obj.get("mode","idle")
            random.seed(actor)
            grid = [[random.randint(0,1) for _ in range(size)] for _ in range(size)]
            lab = {"actor": actor, "size": size, "mode": mode, "grid": grid, "ts": time.time()}
            save_lab(actor, lab)
            return ok(self, {"status":"started", "size": size, "mode": mode})

        elif p == "/lab/step":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            lab = load_lab(actor)
            if not lab:
                return bad(self, 404, "no lab")
            # simple CA: Conway-esque
            g = lab["grid"]
            n = lab["size"]
            def neighbors(i,j):
                s=0
                for di in (-1,0,1):
                    for dj in (-1,0,1):
                        if di==0 and dj==0: continue
                        ii=(i+di)%n; jj=(j+dj)%n
                        s+=g[ii][jj]
                return s
            newg=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(n):
                    s = neighbors(i,j)
                    if g[i][j]==1:
                        newg[i][j] = 1 if s in (2,3) else 0
                    else:
                        newg[i][j] = 1 if s==3 else 0
            lab["grid"]=newg; lab["ts"]=time.time()
            save_lab(actor, lab)
            return ok(self, {"grid": newg})

        else:
            return bad(self, 404, "unknown endpoint")

def run():
    host, port = "127.0.0.1", 8787
    print(f"CommonsLedger MVP (Tiles+Lab) at http://{host}:{port}")
    HTTPServer((host, port), App).serve_forever()

if __name__ == "__main__":
    run()
