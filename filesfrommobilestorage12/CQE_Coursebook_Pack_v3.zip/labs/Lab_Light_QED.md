# Lab — Light & QED
Run harness on `examples/prompt_light_qed.json` and inspect receipts.
