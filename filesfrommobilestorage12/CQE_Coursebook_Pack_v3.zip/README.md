# CQE Coursebook Pack (v3)

Merged v2 coursebook format with extended runtime harness, labs, and governance.
