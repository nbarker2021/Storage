def rainbow(n): return [(1,0,0)]*n
