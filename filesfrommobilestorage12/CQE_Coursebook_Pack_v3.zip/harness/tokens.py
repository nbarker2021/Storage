from dataclasses import dataclass
@dataclass
class Token:
    name:str; unit:str; bounds:tuple; provenance_hash:str
