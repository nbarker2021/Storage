import numpy as np

def mirror_forward(sig): return {'fft':np.fft.rfft(sig)}

def mirror_inverse(fft): return {'sig_rec':np.fft.irfft(fft)}

def residual(x,y): import numpy as np; d=np.linalg.norm(x-y); n=max(1e-9,np.linalg.norm(x)); return float(d/n)
