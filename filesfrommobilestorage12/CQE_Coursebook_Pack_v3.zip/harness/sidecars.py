def run_sidecar(name,payload): return {'name':name,'vote':1 if payload else 0}
