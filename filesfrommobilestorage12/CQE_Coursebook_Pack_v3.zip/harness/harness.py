import json, os, numpy as np
from .tokens import Token
from .dna10 import DNA10
from .overlays import build_octet_views
from .mirror import mirror_forward, mirror_inverse, residual
from .delta import delta_lift
from .ratchet import Ratchet
from .receipts import Receipts
from .commit import commit4

def _toy_signal(n=1024, seed=0):
    rng = np.random.default_rng(seed)
    t = np.linspace(0,1,n)
    sig = np.sin(2*np.pi*7*t) + 0.5*np.sin(2*np.pi*13*t) + 0.05*rng.normal(size=n)
    return sig

def main(cfg_path):
    with open(cfg_path,'r',encoding='utf-8') as f: cfg=json.load(f)
    os.makedirs('outputs', exist_ok=True)
    tokens=[Token(**t) for t in cfg['tokens']]
    dna=DNA10(**cfg['dna10'])
    sig=_toy_signal(seed=cfg.get('seed',0))
    views=build_octet_views(sig)
    view_votes=len(views)
    fwd=mirror_forward(sig)['fft']; inv=mirror_inverse(fwd)['sig_rec']; r0=residual(sig,inv)
    sig2=delta_lift(sig); f2=mirror_forward(sig2)['fft']; inv2=mirror_inverse(f2)['sig_rec']; r1=residual(sig2,inv2)
    rat=Ratchet(cfg['tolerance']); tol1=rat.tighten()
    mirror_vote=int(r1<=tol1)
    rec=Receipts(mirror_vote, view_votes, r1, {'cfg':'ok'})
    commit=commit4(mirror_vote=mirror_vote, view_votes=view_votes, residual=r1, salt=cfg.get('salt',''))
    out={'commit4':commit,'receipts':json.loads(rec.dump())}
    with open(os.path.join('outputs', os.path.basename(cfg_path).replace('.json','_receipts.json')),'w') as f: json.dump(out,f,indent=2)
    print(commit, r1, tol1)

if __name__ == '__main__':
    import sys; main(sys.argv[1] if len(sys.argv)>1 else 'examples/prompt_light_qed.json')
