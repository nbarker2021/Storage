from dataclasses import dataclass
@dataclass
class DNA10:
    timing:str; polarity:str; scale:str; pose:str; domain:str
    conditioning:str; units:str; precision:str; cost:str; seed:str
