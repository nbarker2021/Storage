import json
class Receipts:
    def __init__(self,mirror_vote,view_votes,residual,hashes):
        self.mirror_vote=mirror_vote; self.view_votes=view_votes; self.residual=residual; self.hashes=hashes
    def dump(self):
        return json.dumps({'mirror_vote':self.mirror_vote,'view_votes':self.view_votes,'residual':self.residual,'hashes':self.hashes},indent=2)
