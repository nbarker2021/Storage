class Ratchet:
    def __init__(self,tol): self.tol=tol
    def tighten(self,factor=0.9): self.tol*=factor; return self.tol
