import numpy as np

def build_octet_views(signal):
    f=np.fft.rfft(signal); return {'time':signal,'freq':abs(f),'phase':np.angle(f)}
