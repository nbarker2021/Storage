from hashlib import blake2b

def hstr(*chunks):
    h=blake2b(digest_size=16)
    for c in chunks: h.update(str(c).encode());
    return h.hexdigest()
