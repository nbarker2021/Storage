import numpy as np

def delta_lift(x):
    mu=x.mean(); s=x.std()+1e-9; lo,hi=mu-3*s,mu+3*s; return np.clip(x,lo,hi)
