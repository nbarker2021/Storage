from .utils import hstr

def commit4(**kw):
    x=hstr(kw.get('mirror_vote'),kw.get('view_votes'),kw.get('residual'),kw.get('salt',''))
    return bin(int(x[0],16))[2:].zfill(4)
