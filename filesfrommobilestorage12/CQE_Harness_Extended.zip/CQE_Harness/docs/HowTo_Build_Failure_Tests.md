# How to Build Literal Failure Tests in CQE

This guide shows how *you* can construct adversarial cases that try to break CQE, using CQE itself.

## 1) Define Workspace and Bounds
- Choose a 4×4 parity grid as the base (n=4).
- Declare octad faces and the parity lanes.
- Start a hash-chained ledger (Bind → Collision → Expansion → Act).

## 2) Construct Adversarials
- **Rotation Stress:** random rotations before each phase; expect canonical closure to be invariant.
- **Parity Flip:** flip a checkerboard bit; expect contradictions to rise then snap on canonicalization.
- **Degenerate Seeds:** all-zeros or all-ones inputs; expect idempotent rest after canonicalization.
- **Sequence Chaos:** random 10,000-step sequences of Bind/Collision/Expansion/Act; replay must match hash-chain.

## 3) Reality vs Simulation
- **Reality Adapter:** map a physical system (3-body, pendulum array, braid crossings) to octad faces; verify conservation across face rotations.
- **Simulation Adapter:** use synthetic data with known ground truth; verify image/video roundtrip exactness.

## 4) Pass/Fail
- A test *passes* if invariants hold: determinism at rest, rotation invariance, parity lockstep, replayability.
- A test *fails* if any invariant breaks reproducibly with identical seeds.

## 5) Extend to 1–64–1
- Repeat 4×4 windows across the ledger; treat each closure as a rest token.
- Build to n=64 by stacking canonical closures; contradictions must monotonically decrease under φ-paced expansion.
