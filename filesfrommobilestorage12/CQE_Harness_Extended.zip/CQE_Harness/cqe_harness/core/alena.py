import numpy as np
from typing import Tuple

def alena_decide(g: np.ndarray)->Tuple[str, np.ndarray]:
    """
    Deterministic decision: prefer palindromic rows else invariant-min heuristic.
    """
    pal = all((row==row[::-1]).all() for row in g)
    if pal:
        return ("palindromic", g.copy())
    # invariant-min: sort rows lexicographically
    idx = np.lexsort(g.T)
    return ("invariant", g[idx,:])
