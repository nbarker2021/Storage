import hashlib, json, time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

def sha256(obj)->str:
    if isinstance(obj, (dict, list)):
        s = json.dumps(obj, sort_keys=True, separators=(",",":"))
    else:
        s = str(obj)
    return hashlib.sha256(s.encode()).hexdigest()

@dataclass
class LedgerEntry:
    step: int
    phase: str  # Bind|Collision|Expansion|Act
    payload: Dict[str, Any]
    prev_hash: str
    timestamp: float = field(default_factory=lambda: time.time())
    hash: str = ""

    def finalize(self):
        body = {
            "step": self.step,
            "phase": self.phase,
            "payload": self.payload,
            "prev_hash": self.prev_hash,
            "timestamp": round(self.timestamp, 9),
        }
        self.hash = sha256(body)
        return self

class Ledger:
    """
    Minimal deterministic ledger with hash chaining and replay.
    """
    def __init__(self, seed: str="CQE-SEED"):
        self.entries: List[LedgerEntry] = []
        self.seed = sha256(seed)

    @property
    def head(self)->str:
        return self.entries[-1].hash if self.entries else self.seed

    def append(self, phase: str, payload: Dict[str, Any]):
        e = LedgerEntry(step=len(self.entries)+1, phase=phase, payload=payload, prev_hash=self.head).finalize()
        self.entries.append(e)
        return e.hash

    def replay_ok(self, other:'Ledger')->bool:
        if len(self.entries)!=len(other.entries): return False
        return all(a.hash==b.hash and a.prev_hash==b.prev_hash for a,b in zip(self.entries, other.entries))

    def export(self)->List[Dict[str, Any]]:
        return [e.__dict__ for e in self.entries]
