from typing import List, Tuple
import numpy as np

OCTAD = np.array([[1,0,0],[0,1,0],[0,0,1],[-1,0,0],[0,-1,0],[0,0,-1],[1,1,0],[-1,1,0]], dtype=float)

def parity_grid(n:int=4)->np.ndarray:
    g = np.fromfunction(lambda i,j: (i+j)%2, (n,n))
    return g.astype(int)

def contradictions(g: np.ndarray)->int:
    n = g.shape[0]
    c = 0
    # simple border mismatches row/col parity as a toy contradiction count
    c += int(np.sum(g[0,:])%2!=0)
    c += int(np.sum(g[-1,:])%2!=0)
    c += int(np.sum(g[:,0])%2!=0)
    c += int(np.sum(g[:,-1])%2!=0)
    return c

def rotate_grid(g: np.ndarray, k:int)->np.ndarray:
    return np.rot90(g, k=k%4)

def canonicalize(g: np.ndarray)->np.ndarray:
    # choose rotation with minimal binary value
    candidates = [rotate_grid(g,k) for k in range(4)]
    def key(arr):
        return int(''.join(map(str, arr.flatten().astype(int))), 2)
    return min(candidates, key=key)

def expand_to_8D(g: np.ndarray)->Tuple[np.ndarray, np.ndarray]:
    """
    Toy embedding: stack two 4x4 layers into 8D 'faces' by SVD-like lift.
    """
    a = g.copy().astype(float)
    b = rotate_grid(g,1).astype(float)
    return a, b
