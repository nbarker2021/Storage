
import numpy as np

def fold_stability(triad_helices:int, mirror_contacts:int)->float:
    # more mirrors => more stability up to saturation
    t = max(0, triad_helices)
    m = max(0, mirror_contacts)
    return float(min(1.0, 0.2*t + 0.1*m))

def predict_pitch(n_turns:int)->float:
    # toy DNA-like pitch in bp per turn
    return float(10.5 + 0.1*(n_turns%3 - 1))
