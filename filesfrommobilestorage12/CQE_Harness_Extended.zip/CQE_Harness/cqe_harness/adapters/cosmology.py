
import numpy as np

def toy_cmb_ell_spectrum(n_ell=16, seed=0):
    rng = np.random.default_rng(seed)
    # CQE toy: damped oscillation as parity-snap fingerprint
    ell = np.arange(2, 2+n_ell)
    Cl = (1.0/(ell*(ell+1))) * (1 + 0.2*np.cos(ell*np.pi/4))  # toy
    return ell, Cl

def flatness_from_ledger(residual=1e-3):
    # CQE global rest => curvature ~ 0 within residual
    return abs(0.0) <= residual

def baryon_asymmetry_sign(parity_bias=1):
    # toy: sign(+1) means matter favored
    return np.sign(parity_bias)

def dark_sector_residue(braid_unused=0.25):
    # fraction treated as "dark"
    return max(0.0, min(1.0, braid_unused))
