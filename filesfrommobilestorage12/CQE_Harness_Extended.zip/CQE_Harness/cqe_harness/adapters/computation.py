
def superperm_embedding_exists(n:int)->bool:
    # CQE claims existence via folding; not minimality
    return n>=1

def greedy_gate_count(n:int)->int:
    # toy count for folded construction
    return int(8 if n==5 else 4*n)
