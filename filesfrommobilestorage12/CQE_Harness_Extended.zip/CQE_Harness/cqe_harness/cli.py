import importlib, json, argparse

TESTS = [
    "cqe_harness.tests.invariants",
    "cqe_harness.tests.three_body_lockstep",
    "cqe_harness.tests.image_roundtrip",
    "cqe_harness.tests.cosmo_cmb",
    "cqe_harness.tests.quantum_bell",
    "cqe_harness.tests.thermo_entropy",
    "cqe_harness.tests.info_bounds",
    "cqe_harness.tests.linguistics_parse",
    "cqe_harness.tests.biology_folding",
    "cqe_harness.tests.computation_superperm",
    "cqe_harness.tests.math_godel_lattice",
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    results = {}
    for mod in TESTS:
        m = importlib.import_module(mod)
        results[mod.split(".")[-1]] = m.run()
    if args.json:
        print(json.dumps(results, indent=2))
    else:
        for k,v in results.items():
            print(f"[{k}] -> {v}")

if __name__ == "__main__":
    main()
