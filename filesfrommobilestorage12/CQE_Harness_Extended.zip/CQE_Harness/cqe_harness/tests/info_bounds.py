
from cqe_harness.adapters.information import cqe_compressibility_ratio, kolmogorov_hint
def run():
    ratio = cqe_compressibility_ratio(1_000_000, structure=0.7)
    hint = kolmogorov_hint(10000, motif_count=128)
    return {"compress_ratio_lb": float(ratio), "kolmogorov_hint_bits": int(hint)}
