
from cqe_harness.adapters.biology import fold_stability, predict_pitch
def run():
    stab = fold_stability(triad_helices=4, mirror_contacts=6)
    pitch = predict_pitch(n_turns=7)
    return {"stability": float(stab), "pitch_bp_per_turn": float(pitch)}
