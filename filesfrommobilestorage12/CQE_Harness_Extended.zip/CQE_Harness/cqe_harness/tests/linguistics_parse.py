
from cqe_harness.adapters.linguistics import canonical_parse_score, proto_merge_3
def run():
    score = canonical_parse_score(ambigs=7, constraints=3)
    token = proto_merge_3("English","Quechua","Yoruba")
    return {"parse_score": float(score), "proto_token": token}
