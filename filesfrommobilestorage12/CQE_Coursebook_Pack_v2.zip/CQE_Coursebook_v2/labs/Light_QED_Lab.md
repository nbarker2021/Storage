# Lab: Light & QED — Octet + Mirror + Receipts

Objective: Stabilize an optical experiment (polarization + spectrum) with CQE and produce a 4‑bit commit.

Token Pack (examples)
- wavelength_nm ∈ [350, 900], power_mW, polarization ∈ {L,R,X,Y}, coherence ∈ {coh,incoh}, detector_SNR, grating_lpmm.

Octet Views
1) Polarization: L  2) Polarization: R  3) Linear-X  4) Linear-Y
5) Spectral narrow  6) Spectral broad  7) Coherent  8) Incoherent

Mirror
Forward: source→polarizer→spectrograph→detector
Inverse: detector model→spectral deconvolution→polarization inverse→source constraints
Tolerance: ΔI/I ≤ 1.5% across bands; DoP error ≤ 0.02.

Δ‑Cookbook (examples)
- Swap LC bias; retune analyzer angle.
- Constrain deconvolution kernel to physically plausible PSD.
- Clamp stray-light floor via dark-frame parity.

Strict Ratchet
Tighten ΔI/I to 1.0%, DoP error to 0.015 after first pass.

Receipts
- Mirror votes: 22/24, view votes ≥ 6/8.
- Hashes: data, configs, thresholds.
- 4‑bit: 1011 (example).

Worksheet
Fill: token cards, octet table, mirror residuals, Δ‑edits, strict deltas, receipts.
