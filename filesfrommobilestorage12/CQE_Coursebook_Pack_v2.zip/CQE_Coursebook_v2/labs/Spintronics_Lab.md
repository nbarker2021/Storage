# Lab: Spintronics — Chiral Spin Filters at Room Temperature

Objective: Validate a chiral nanohelix as a spin filter using CQE.

Tokens
- helix_handedness ∈ {L,R}, diameter_nm, pitch_nm, material, J_in (μA), B_ext (mT), T (K).

Octet
1) L‑hand no B  2) R‑hand no B  3) L‑hand +B  4) R‑hand +B
5) Low‑bias  6) High‑bias  7) DC  8) AC

Mirror
Encode: device→I–V–P (spin polarization)
Decode: polarization model→expected I–V under symmetry
Tolerance: |P_meas − P_model| ≤ 0.05 absolute.

Δ‑Cookbook
- Repaint bias gradient; reduce contact resistance asymmetry.
- Thermal pre‑conditioning sweep.

Strict
Tighten polarization bound to 0.03.

Receipts
Votes + hashes, 4‑bit example: 1101.
