# Lab: Plasma Braiding — Parity & Chirality Mapping

Objective: Detect braided flux structures and chirality flips in MHD data using CQE.

Tokens
- B_field map(t,x,y,z), v_plasma, resistivity, probe cadence, domain masks.

Octet
1) Left‑hand braid  2) Right‑hand braid  3) Null sheet  4) Reconnection zone
5) Low‑β  6) High‑β  7) Quiescent  8) Burst

Mirror
Forward MHD step vs. inverse constrained step; helicity conservation within ε.
Tolerance: helicity error ≤ 2%, Poincaré map fixed‑point stability.

Δ‑Cookbook
- Local resistivity floor; adaptive timestep around current sheets.
- Flux‑surface relabeling to remove gauge drift.

Strict
Helicity error → 1% after first pass.

Receipts
Votes + hashes, 4‑bit example: 1010.
