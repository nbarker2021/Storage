# CQE: A Coursebook (v2)

## Module 0 — Orientation
Goal: Learn the CQE spine while keeping meaning provisional.
Spine: Stand-ins → DNA‑10 → Octet Overlays → Palindromic Mirror → Δ‑lifts → Strict Ratchet → Receipts → 4‑bit Commit.
Form/Meaning Split: Forms are coded geometry (Construction‑A shells, E8 slices, Leech patches); meanings are swappable token packs.

## Module 1 — Tokens & Stand‑ins
- Token cards: quantity, unit, range/guards, provenance hash.
- Use observed glyphs (domain-native symbols) as labels; bind hashes, not prose.
- Practice: Define 8–16 tokens for any domain (sound, heat, light).

## Module 2 — DNA‑10 State Save
Record: timing, polarity, scale, pose, domain, conditioning, units, precision, cost, seed.
Idempotence check: replay must reproduce the same DNA‑10 with ≤ tolerances.

## Module 3 — Octet Overlays (8 Views)
Choose 8 materially independent views (modalities, bands, slices, regimes).
Example sets:
- Sound: time, freq, spectrogram, phase, envelope, impulse, spatial, nonlinearity probe.
- Heat: conduction, convection, radiation, steady‑state, transient, boundary, stochastic, microstructure.
- Light/QED: polarization (L/R), linear (X/Y), near/IR/UV, coherent/incoherent.

## Module 4 — Palindromic Mirror
Enforce forward ∘ inverse ≈ identity within written tolerances. Examples:
- FFT↔iFFT (signals), encode↔decode (codes), simulate↔measure (experiments).
Record residuals and parity votes (lane A/B).

## Module 5 — Δ‑lifts (Local Repairs)
Small monotone edits that strictly reduce local debt and do not regress other views.
Keep a published Δ‑cookbook per domain.

## Module 6 — Strict Ratchet
After a clean replay, tighten thresholds (ULP error, AR, WFE, BER, ΔT).
Never loosen; if a pass fails after tightening, rollback and log.

## Module 7 — Receipts & 4‑bit Commits
- OPE/FCE debt, mirror votes, view votes, hashes.
- 4‑bit code is the minimal commit fingerprint; upgrade to 8/64 only on collisions.

## Module 8 — Geometry: Construction‑A → E8 → Leech
- Construction‑A (binary): lattice from code + glue.
- E8 embedding appears naturally once the n=5 hinge forces an octad.
- Leech slice legality at 24; Monster/M24 act as braid/permutation to clone forms deterministically.

## Module 9 — Sidecars (Mini‑labs)
Define up to 64 tabs: OPTICS, THERMAL, POLAR, MATH, SOUND, HEAT, QED, SPIN, PLASMA, BIO, etc.
Each tab runs the same ritual spine independently and emits its own 4‑bit.

## Module 10 — Safety & Redaction
- Compute freely; publish receipts selectively.
- “Some results redacted for safety” is acceptable; bind hashes to receipts.
- Keep dangerous specifics outside public meaning packs; forms + receipts suffice for audit.

## Module 11 — Runtime
- Workorder JSON → orchestrator spins sidecars → overlay/mirror → Δ/strict → commits.
- Always view with local 8×8 and surrounding 4×4×4×4 and parity 2×2×2×2 neighborhoods.

## Module 12 — Capstone
Pick 1 domain; produce: token pack → octet → mirror logs → Δ‑cookbook → strict ratchet → receipts → 4‑bit.
Deliver both a public report and a private ledger (hashes + thresholds).
