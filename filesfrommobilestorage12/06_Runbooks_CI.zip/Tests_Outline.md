# Tests Outline
E8, Shelling/TAC, Underverse, n=5 C[8], DTT boundary, DNA replay, Bridge invariants, SAP checks.
