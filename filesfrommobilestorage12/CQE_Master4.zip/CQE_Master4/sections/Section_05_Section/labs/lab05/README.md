Run: python lab05.py --tokens tokens_sample_05.csv
