Run: python lab12.py --tokens tokens_sample_12.csv
