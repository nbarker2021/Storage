Run: python lab14.py --tokens tokens_sample_14.csv
