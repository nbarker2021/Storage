# Section 14

**Scene:** Instructor (I) and Learner (L) at a whiteboard.

**Goals**
- Run pipeline
- Inspect commit
- Record receipts

**I:** Today we run the CQE core and examine outputs.
**L:** Let's do it.

Open `labs/lab14` and run the script.
