Run: python lab03.py --tokens tokens_sample_03.csv
