Run: python lab07.py --tokens tokens_sample_07.csv
