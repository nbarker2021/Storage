Run: python lab00.py --tokens tokens_sample_00.csv
