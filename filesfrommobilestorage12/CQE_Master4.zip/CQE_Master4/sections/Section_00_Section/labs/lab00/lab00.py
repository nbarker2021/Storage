
# Lab 00 runner
import argparse, os, json, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "..","..","..","harness"))
from cqe_core import run_pipeline
ap = argparse.ArgumentParser()
ap.add_argument("--tokens", required=True)
ap.add_argument("--out", default="commit_out")
args = ap.parse_args()
os.makedirs(args.out, exist_ok=True)
res = run_pipeline(args.tokens)
open(os.path.join(args.out,"commit.json"),"w").write(json.dumps(res["commit"], indent=2))
print("Commit:", res["commit"]["code"])
