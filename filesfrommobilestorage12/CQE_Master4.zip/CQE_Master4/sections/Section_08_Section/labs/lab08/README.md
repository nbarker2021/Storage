Run: python lab08.py --tokens tokens_sample_08.csv
