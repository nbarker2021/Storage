Run: python lab09.py --tokens tokens_sample_09.csv
