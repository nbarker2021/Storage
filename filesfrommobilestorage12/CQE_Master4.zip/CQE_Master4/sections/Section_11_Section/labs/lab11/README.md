Run: python lab11.py --tokens tokens_sample_11.csv
