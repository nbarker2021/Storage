Run: python lab10.py --tokens tokens_sample_10.csv
