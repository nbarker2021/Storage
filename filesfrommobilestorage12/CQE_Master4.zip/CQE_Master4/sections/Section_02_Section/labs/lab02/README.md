Run: python lab02.py --tokens tokens_sample_02.csv
