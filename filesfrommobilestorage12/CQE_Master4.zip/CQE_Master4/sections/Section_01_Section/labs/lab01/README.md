Run: python lab01.py --tokens tokens_sample_01.csv
