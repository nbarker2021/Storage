Run: python lab13.py --tokens tokens_sample_13.csv
