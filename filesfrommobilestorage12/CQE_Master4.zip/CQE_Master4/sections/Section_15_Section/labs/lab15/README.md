Run: python lab15.py --tokens tokens_sample_15.csv
