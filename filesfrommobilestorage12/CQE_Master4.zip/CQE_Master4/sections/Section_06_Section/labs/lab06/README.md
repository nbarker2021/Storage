Run: python lab06.py --tokens tokens_sample_06.csv
