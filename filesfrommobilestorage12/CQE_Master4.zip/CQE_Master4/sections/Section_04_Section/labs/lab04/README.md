Run: python lab04.py --tokens tokens_sample_04.csv
