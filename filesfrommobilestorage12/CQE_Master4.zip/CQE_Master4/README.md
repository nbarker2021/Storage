# CQE Master 16-Part Course
Run labs inside sections.
