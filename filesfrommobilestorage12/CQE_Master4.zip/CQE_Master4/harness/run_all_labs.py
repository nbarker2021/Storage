print('placeholder runner; run labs individually')
