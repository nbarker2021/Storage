
from __future__ import annotations
import csv, json, hashlib, math, random
from typing import List, Dict, Any, Tuple

def set_seed(seed: int = 1337):
    random.seed(seed)

def load_tokens_csv(path: str):
    rows = []
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)
    for i, row in enumerate(rows):
        row.setdefault("token_id", str(i))
        row.setdefault("text", "")
        row.setdefault("bucket", "ABCD"[i % 4])
    return rows

def bucketize(rows):
    buckets = {"A": [], "B": [], "C": [], "D": []}
    for row in rows:
        b = row.get("bucket","A")
        if b not in buckets:
            b = "A"
        buckets[b].append(row)
    return buckets

def colorize(buckets):
    for bkey, items in buckets.items():
        for it in items:
            h = hashlib.sha256((it.get("text","")+it["token_id"]).encode()).hexdigest()
            it["color_id"] = int(h[:2], 16) % 16
            it["gradient"] = int(h[2:4], 16) / 255.0
    return buckets

def combos_of_four(keys):
    order = keys * 2
    res = []
    for i in range(len(order)-3):
        res.append(tuple(order[i:i+4]))
    uniq, seen = [], set()
    for c in res:
        if c not in seen:
            seen.add(c); uniq.append(c)
    return uniq

def simulate_overlay(buckets, drive):
    profiles = []
    for bkey in drive:
        vec = [0.0]*16
        for it in buckets[bkey]:
            idx = it["color_id"]
            w = 0.5 + 0.5*it["gradient"]
            vec[idx] += w
        for _ in range(2):
            vec = [0.25*vec[(i-1)%16] + 0.5*vec[i] + 0.25*vec[(i+1)%16] for i in range(16)]
        profiles.append(vec)
    inter = [min(profiles[0][i], profiles[1][i], profiles[2][i], profiles[3][i]) for i in range(16)]
    score = sum(inter)
    return {"drive": drive, "profiles": profiles, "intersection": inter, "score": score}

def palindromic_rest(overlays):
    if not overlays:
        return {"rest":[0.0]*16, "src": []}
    acc = [0.0]*16
    tot = 0.0
    for ov in overlays:
        w = max(1e-9, ov["score"])
        tot += w
        inter = ov["intersection"]
        for i in range(16):
            acc[i] += w*inter[i]
    base = [a/tot for a in acc]
    pal = [(base[i] + base[-1-i]) * 0.5 for i in range(16)]
    return {"rest": pal, "src": [{"drive": ov["drive"], "score": ov["score"]} for ov in overlays]}

def receipts(rest):
    mean = sum(rest)/len(rest)
    var = sum((x-mean)**2 for x in rest)/len(rest)
    std = var**0.5
    rho_num = sum(rest[i]*rest[-1-i] for i in range(len(rest)))
    rho_den = sum(x*x for x in rest) + 1e-9
    rho = rho_num / rho_den
    uni = 1.0/len(rest)
    ece = sum(abs(x - uni) for x in rest)/len(rest)
    return {"std": std, "rho_lr": rho, "ece": ece}

def commit_4bit(receipts_dict):
    th_std = 0.08
    th_rho = 0.50
    th_ece = 0.03
    bits = [
        1 if receipts_dict["std"] < th_std else 0,
        1 if receipts_dict["rho_lr"] > th_rho else 0,
        1 if receipts_dict["ece"] < th_ece else 0,
        1 if (0.2 < receipts_dict["std"] + receipts_dict["ece"] < 0.6) else 0
    ]
    code = "".join(str(b) for b in bits)
    h = hashlib.sha256(json.dumps({"bits":bits, "receipts": receipts_dict}, sort_keys=True).encode()).hexdigest()
    return {"bits": bits, "code": code, "merkle_root": h}

def run_pipeline(tokens_csv: str, seed: int=1337):
    set_seed(seed)
    rows = load_tokens_csv(tokens_csv)
    buckets = colorize(bucketize(rows))
    drives = combos_of_four(list(buckets.keys()))
    overlays = [simulate_overlay(buckets, d) for d in drives]
    overlays.sort(key=lambda o: o["score"], reverse=True)
    overlays = overlays[:6]
    pal = palindromic_rest(overlays)
    rcp = receipts(pal["rest"])
    com = commit_4bit(rcp)
    return {"overlays": [{"drive": ov["drive"], "score": ov["score"]} for ov in overlays],
            "rest": pal["rest"], "receipts": rcp, "commit": com}
