
import json, os, hashlib, glob, sys

def sha256_bytes(b: bytes)->str:
    return hashlib.sha256(b).hexdigest()

def file_hash(path:str)->str:
    with open(path,"rb") as f:
        return sha256_bytes(f.read())

def merkle_root(files):
    # simple pairwise hash fold (not strict merkle tree, but deterministic)
    hashes = [file_hash(p) for p in sorted(files)]
    acc = "".join(hashes).encode()
    return sha256_bytes(acc)

def load_registry(root):
    carts = sorted(glob.glob(os.path.join(root,"registry","cartridges","C*.json")))
    bens  = sorted(glob.glob(os.path.join(root,"registry","benches","B*.json")))
    C = [json.load(open(p)) for p in carts]
    B = [json.load(open(p)) for p in bens]
    return carts, bens, C, B

def validate(C,B):
    ids = {c["id"] for c in C}
    ok = True
    for b in B:
        for cid in b["cartridges"]:
            if cid not in ids:
                print(f"[ERROR] Bench {b['id']} references missing cartridge {cid}")
                ok = False
    return ok

if __name__ == "__main__":
    root = os.path.dirname(os.path.abspath(__file__))
    carts,bens,C,B = load_registry(root)
    ok = validate(C,B)
    reg_root = merkle_root(carts + bens)
    print("Cartridges:", len(C))
    print("Benches   :", len(B))
    print("Registry root (sha256):", reg_root)
    if not ok:
        sys.exit(1)
    # Print compact tokens/receipts manifest
    for c in C:
        print(f"\n== {c['id']} {c['name']} ==")
        tnames = ", ".join(t["name"] for t in c["tokens"])
        print("Tokens:", tnames)
        rnames = "; ".join(f"{r['name']}[{r['pass_metric']}]" for r in c["receipts"])
        print("Receipts:", rnames)
