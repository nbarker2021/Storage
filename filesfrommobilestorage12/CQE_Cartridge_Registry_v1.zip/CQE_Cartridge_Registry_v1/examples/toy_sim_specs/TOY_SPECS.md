# Toy Sim Specs (Domain-free)

- **C03 Period-doubled rest**: iterate x_{t+1} = a - x_t^2 (logistic-like) with mild jitter; detect 1/2 subharmonic peak.
- **C05 Handedness gate**: 2-lane random walk with chiral bias; mirror the lattice and verify pass_ratio sign flip.
- **C08 Large loop current**: Hückel-like cycle on N nodes; cut/restore one edge and measure circulation sign stability.
- **C14 Burst-coded replay**: generate sparse bursts, encode with small codebook, recover and compare hashes.
- **Benches**: compose the above into octet/triad runs; compute 4-bit commit from receipt passes.
