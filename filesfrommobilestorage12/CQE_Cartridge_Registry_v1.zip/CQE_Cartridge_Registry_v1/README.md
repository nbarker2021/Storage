# CQE Cartridge Registry v1

**Build date:** 2025-09-20T06:19:55.208512Z

This package defines 18 **CQE cartridges** (domain-agnostic pattern modules) and 4 **benches** (precomposed octets/triads) for chamber runs.
It contains JSON schemas, cartridge specs, bench specs, and a tiny Python validator that assembles a Merkle-like root over the registry.

## Layout
- `schemas/` — JSON Schemas (cartridge, bench)
- `registry/cartridges/` — `C01..C18.json`
- `registry/benches/` — `BA..BD.json`
- `examples/toy_sim_specs/` — short notes for neutral micro-tests
- `cqe_registry_demo.py` — loads/validates, prints receipts plan, computes registry root
- `LICENSE` — MIT

## Cartridges (short list)
C01 Multi-rail error-controlled | C02 One-way corridor | C03 Period-doubled rest | C04 Reversible magnifier | C05 Handedness gate |
C06 Gauge-tilted pathing | C07 Multi-octave rack | C08 Large loop current | C09 Trickle source | C10 Secondary-structure switch |
C11 Paired-token co-emergence | C12 Ligand-free gate hijack | C13 Mode switch via cross-coupling | C14 Burst-coded replay |
C15 Commit-time regime change | C16 Weak seed bias | C17 Exogenous corridor perturbation | C18 Finite motif lexicon

## Benches
- **BA – Periodic**: C03, C07, C13, C14
- **BB – Geometry**: C05, C06, C08
- **BC – Control**: C01, C02, C04
- **BD – Priors & Lexicon**: C09, C11, C16, C18

## How to use
1. Edit/add cartridges under `registry/cartridges/` (follow schema).
2. Compose benches under `registry/benches/`.
3. Run `cqe_registry_demo.py` to validate, list tokens/receipts, and compute the registry root.
4. Load selected benches into your chamber; each cartridge lists stand-in tokens, receipts, and a neutral micro-test.

## Notes
- All artifacts are **semantics-free**; attach meaning only after 4-bit commit.
- Receipts are phrased as inequalities you can implement in your chamber (pass/fail + margin).
- The Merkle-like root commits the exact registry content for reproducibility.
