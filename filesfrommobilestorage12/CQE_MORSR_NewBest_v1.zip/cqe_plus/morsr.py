
from __future__ import annotations
from typing import Dict, Any, List
from dataclasses import dataclass
import json, math, statistics, time, hashlib, collections

from .overlay import EO
from .operators import op_Rtheta, op_WeylReflect, op_Midpoint, op_ParityMirror

@dataclass
class Policy:
    eps_phi: float
    strict_only: bool
    plateau_cap: int
    midpoint_requires_parity_drop: bool
    shell_mode: str
    shell_base: float
    shell_factors: List[int]
    stop_metric: str
    stop_threshold: float
    ema_alpha: float
    sector_balance_lambda: float

def _hash(obj): return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()

def _phi(eo: EO, pol_weights):
    return eo.compute_phi_scalar({"geometry": pol_weights.get("geometry",1.0),
                                  "parity": pol_weights.get("parity",1.0),
                                  "sparsity": pol_weights.get("sparsity",0.02)})

def _build_shell(mask_len, mode, base, mult, stage, viz=None, graph=None, active_idxs=None):
    if mode == "radial":
        R = min(1.0, float(base) * (int(mult) ** stage))
        # If viz radii not available, approximate by index scaling
        allowed = set(i for i in range(mask_len) if (i/float(mask_len-1)) <= R)
        return allowed, {"R": R}
    else:
        hops = int(round(float(base) * (int(mult) ** stage)))
        visited = set(active_idxs or [])
        frontier = set(active_idxs or [])
        for _ in range(max(0,hops)):
            nxt=set()
            for u in frontier:
                for v in ((u-1,u+1) if 0<u<mask_len-1 else (u+1,)):
                    if 0<=v<mask_len and v not in visited:
                        visited.add(v); nxt.add(v)
            frontier=nxt
            if not frontier: break
        return visited, {"hops": hops}

def pulse(seed: EO, policy_json: Dict[str,Any], region_out: str, handshakes_out: str):
    pol = Policy(
        eps_phi=policy_json["acceptance"]["eps_phi"],
        strict_only=policy_json["acceptance"]["strict_only"],
        plateau_cap=policy_json["acceptance"]["plateau_cap"],
        midpoint_requires_parity_drop=policy_json["acceptance"]["midpoint_requires_parity_drop"],
        shell_mode=policy_json["shells"]["mode"],
        shell_base=policy_json["shells"]["base"],
        shell_factors=policy_json["shells"]["factors"],
        stop_metric=policy_json["shells"]["stop_metric"],
        stop_threshold=policy_json["shells"]["stop_threshold"],
        ema_alpha=policy_json["shells"]["ema_alpha"],
        sector_balance_lambda=policy_json["operators"]["sector_balance_lambda"],
    )
    # Initialize region
    region = {"policy": policy_json, "stages": [], "rings": [], "overlay_store": {}, "boundaries": [], "status": None}
    reason_hist = collections.Counter()

    # helper to log handshake
    hs_lines = []
    def log_hs(op, overlay_id, b, a, reason):
        hs_lines.append({"version":"morsr_handshake_v1",
                         "overlay_id": overlay_id, "op": op,
                         "phi_before": b, "phi_after": a, "delta": a-b,
                         "reason": reason, "signature": "sig:DEMO"})
        reason_hist[reason]+=1

    # Stage loop
    ret_ema = None
    stage = 0
    active0 = [i for i,b in enumerate(seed.present[:240]) if b]
    weights = {"geometry": policy_json["geometry"]["weight"], "parity": policy_json["geometry"]["parity_weight_lane"], "sparsity": policy_json["geometry"]["sparsity_weight"]}

    while True:
        mult = pol.shell_factors[min(stage, len(pol.shell_factors)-1)]
        allowed, shell_meta = _build_shell(240, pol.shell_mode, pol.shell_base, mult, stage, None, None, active0)

        stage_accepts = 0
        stage_attempts = 0
        stage_delta = 0.0

        # ring 0 (seed)
        seed.update_invariants()
        ring0 = {"ring": 0, "lanes":[{"lane_id":0,"op":"Identity","overlay_id":seed.hash_id(),"accepted":True,"phi":_phi(seed,weights)}]}
        if stage==0:
            region["rings"].append(ring0)

        # ring 1 candidates: Rtheta, Midpoint, WeylReflect
        def attempt(op_name, fn):
            nonlocal stage_attempts, stage_accepts, stage_delta
            stage_attempts += 1
            # clone
            cand = EO(present=seed.present[:], w=seed.w[:], phi=seed.phi[:], pose=seed.pose.copy())
            b = _phi(cand, weights)
            fn(cand)
            a = _phi(cand, weights)
            # shell check
            cand_idxs = [i for i,bp in enumerate(cand.present[:240]) if bp]
            if not all(i in allowed for i in cand_idxs):
                log_hs(op_name, cand.hash_id(), b, a, "out_of_shell")
                return {"op": op_name, "accepted": False, "phi_before": b, "phi_after": a, "delta": a-b, "reason": "out_of_shell"}
            # acceptance
            eps = pol.eps_phi
            accepted = False
            reason = "delta_increase"
            if a <= b - eps:
                accepted = True; reason="strict_decrease"
            elif abs(a-b) <= eps and pol.plateau_cap > 0:
                # demo: allow one plateau globally per pulse
                pol.plateau_cap -= 1
                accepted = True; reason="plateau"
            else:
                accepted = False; reason=("delta_increase")
            if op_name=="Midpoint" and accepted:
                # toy parity proxy: require even # of actives post-op (strict drop simulated by flipping odd->even)
                pre = sum(1 for x in seed.present if x) % 2
                post = sum(1 for x in cand.present if x) % 2
                if not (pre != post):  # require change in parity proxy
                    accepted=False; reason="parity_fail"
            if accepted:
                stage_accepts += 1; stage_delta += (a-b)
            log_hs(op_name, cand.hash_id(), b, a, reason)
            rec = {"op": op_name, "overlay_id": cand.hash_id(),
                   "accepted": accepted, "phi_before": b, "phi_after": a, "delta": a-b, "reason": reason}
            if accepted:
                region["overlay_store"][cand.hash_id()] = cand.to_json()
            return rec

        lane_results = []
        lane_results.append(attempt("Rtheta", lambda c: op_Rtheta(c, step=1)))
        lane_results.append(attempt("Midpoint", op_Midpoint))
        lane_results.append(attempt("WeylReflect", lambda c: op_WeylReflect(c, simple_idx=0)))
        region["rings"].append({"ring": 1, "lanes": lane_results, "shell": shell_meta, "stage": stage})

        # return metric
        if policy_json["shells"]["stop_metric"] == "accept_rate":
            ret = stage_accepts / max(1, stage_attempts)
        elif policy_json["shells"]["stop_metric"] == "novelty":
            ret = sum(1 for l in lane_results if l["accepted"])
        else:
            ret = max(0.0, -stage_delta)

        ret_ema = ret if ret_ema is None else (pol.ema_alpha*ret + (1-pol.ema_alpha)*ret_ema)
        region["stages"].append({"stage": stage, "shell": shell_meta, "return": ret, "return_ema": ret_ema,
                                 "accepts": stage_accepts, "attempts": stage_attempts, "delta_phi": stage_delta})

        if ret < pol.stop_threshold and ret_ema < pol.stop_threshold:
            region["status"]="terminated_threshold"; break

        stage += 1
        if stage >= len(pol.shell_factors):
            region["status"]="terminated_factor_exhausted"; break

    # write artifacts
    with open(handshakes_out, "w") as f:
        for line in hs_lines:
            f.write(json.dumps(line)+"\n")
    with open(region_out, "w") as f:
        json.dump(region, f, indent=2)

    # metrics
    metrics = {
        "total_attempts": sum(s["attempts"] for s in region["stages"]),
        "total_accepts": sum(s["accepts"] for s in region["stages"]),
        "total_strict_gain": sum(max(0.0, -s["delta_phi"]) for s in region["stages"]),
        "stages": region["stages"],
        "reason_counts": dict(collections.Counter([l["reason"] for r in region["rings"] if r["ring"]==1 for l in r["lanes"]])),
        "sector_coverage": {},  # placeholder in this minimal build
    }
    with open(handshakes_out.replace(".jsonl","_metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    return region
