
import json, argparse, random, math
from pathlib import Path
from .overlay import EO
from .morsr import pulse

def mint_demo_seed(out_path: str):
    # Create a tiny reproducible seed overlay with a few active roots
    random.seed(42)
    present = [False]*248
    for i in [3, 11, 29, 47, 88, 144, 201]:
        present[i]=True
    w = [0.0]*248
    phi = [None]*248
    for i,b in enumerate(present):
        if b:
            w[i]=1.0
            phi[i]= (i*0.1) % (2*math.pi)
    eo = EO(present=present, w=w, phi=phi, pose={"seed":"demo"})
    Path(out_path).write_text(json.dumps(eo.to_json(), indent=2))

def run_morsr(seed_path: str, policy_path: str, out_region: str, out_hs: str):
    seed = EO(**json.loads(Path(seed_path).read_text())["nodes"], pose=json.loads(Path(seed_path).read_text()).get("pose",{}))
    policy = json.loads(Path(policy_path).read_text())
    pulse(seed, policy, out_region, out_hs)

def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp1 = sp.add_parser("mint-demo")
    sp1.add_argument("--out", required=True)
    sp2 = sp.add_parser("morsr")
    sp2.add_argument("--seed", required=True)
    sp2.add_argument("--policy", required=True)
    sp2.add_argument("--region-out", required=True)
    sp2.add_argument("--handshakes-out", required=True)
    args = ap.parse_args()
    if args.cmd=="mint-demo":
        mint_demo_seed(args.out)
    else:
        run_morsr(args.seed, args.policy, args.region_out, args.handshakes_out)

if __name__ == "__main__":
    main()
