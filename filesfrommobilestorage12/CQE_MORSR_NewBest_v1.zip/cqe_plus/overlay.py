
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any
import math, json, hashlib, statistics

N = 248

@dataclass
class EO:
    present: List[bool]
    w: List[float]
    phi: List[float]  # use None as float("nan") sentinel if needed
    pose: Dict[str, Any] = field(default_factory=dict)
    invariants: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> Dict[str, Any]:
        return {"frame":"e8_canonical_v1","nodes":{"present":self.present,"w":self.w,"phi":self.phi},"pose":self.pose}

    def update_invariants(self):
        active = [i for i,b in enumerate(self.present) if b]
        self.invariants = {
            "active_count": len(active),
            "active_indices_sample": active[:16],
        }

    def hash_id(self) -> str:
        b = json.dumps(self.to_json(), sort_keys=True).encode("utf-8")
        return hashlib.sha256(b).hexdigest()

    def compute_phi_scalar(self, weights) -> float:
        # Simple, deterministic Φ: geometry (adjacency proxy), parity proxy, sparsity
        # Geometry: encourage contiguous phases for active nodes (variance penalty)
        act_phases = [self.phi[i] for i,b in enumerate(self.present) if b and self.phi[i] is not None]
        geom = (statistics.pvariance(act_phases) if len(act_phases) >= 2 else 0.0)
        # Parity proxy: even count preferred (toy proxy for syndromes)
        parity_lane = (sum(1 for b in self.present if b) % 2)
        parity_global = (sum(1 for b in self.present[:240] if b) % 2)
        parity = parity_lane + parity_global
        # Sparsity: L1 on weights
        sparsity = sum(abs(x) for i,x in enumerate(self.w) if self.present[i])
        return (weights["geometry"] * geom
                + weights["parity"] * parity
                + weights["sparsity"] * 0.001 * sparsity)
