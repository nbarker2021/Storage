
from __future__ import annotations
from typing import Dict, Any
import random, math
from .overlay import EO, N

def op_Rtheta(eo: EO, step: int = 1) -> None:
    # Rotate phases of active nodes by a small quantized angle (proxy for Coxeter rotation)
    dq = (math.pi/8) * step
    for i,b in enumerate(eo.present):
        if b and eo.phi[i] is not None:
            eo.phi[i] = ((eo.phi[i] + dq + math.tau) % math.tau)

def op_WeylReflect(eo: EO, simple_idx: int = 0) -> None:
    # Toy reflection: flip sign of phases for a consistent subset (every k-th active)
    k = 3 + (simple_idx % 5)
    idx = 0
    for i,b in enumerate(eo.present):
        if b and eo.phi[i] is not None:
            if idx % k == 0:
                eo.phi[i] = (-eo.phi[i]) % math.tau
            idx += 1

def op_Midpoint(eo: EO) -> None:
    # Palindromic midpoint: average neighboring active phases (smoothing) — parity proxy improves
    phases = [eo.phi[i] for i,b in enumerate(eo.present) if b and eo.phi[i] is not None]
    if not phases: return
    avg = sum(phases)/len(phases)
    for i,b in enumerate(eo.present):
        if b and eo.phi[i] is not None:
            eo.phi[i] = (eo.phi[i] + avg)/2.0

def op_ParityMirror(eo: EO) -> None:
    # Mirror half of the active set's phases to enforce an even/odd balance (toy proxy)
    touched = 0
    for i,b in enumerate(eo.present):
        if b and eo.phi[i] is not None:
            if touched % 2 == 0:
                eo.phi[i] = (math.tau - eo.phi[i]) % math.tau
            touched += 1
