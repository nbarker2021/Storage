# cqe_plus_best_v1 (session-aggregate minimal system)
This is a self-contained, session-built package implementing:
- Policy stamping
- Shell protocol (radial × factors)
- Monotone acceptance (ΔΦ ≤ 0), with Midpoint parity proxy rule
- Reason-coded handshakes
- Overlay store for accepted overlays
- Metrics export

## Quick run
python -m cqe_plus.cli mint-demo --out examples/seed_demo.json
python -m cqe_plus.cli morsr --seed examples/seed_demo.json --policy cqe_plus/policy/cqe_policy_v1.json --region-out examples/region.json --handshakes-out examples/handshakes.jsonl
