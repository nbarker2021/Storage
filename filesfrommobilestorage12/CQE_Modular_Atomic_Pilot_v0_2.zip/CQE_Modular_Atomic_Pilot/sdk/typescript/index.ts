export type Pack = {
  weyl_id: number;
  chamber_id: number;
  gsl: { base: number; octave_k: number; riser: number };
  meta: Record<string, any>;
  payload: Record<string, any>;
  fastlane: boolean;
  pack_id?: string;
  hash?: string;
};
export interface Module {
  NAME: string;
  KIND: string;
  accept(pack: Pack): boolean;
  process(pack: Pack): Promise<Pack>;
}
