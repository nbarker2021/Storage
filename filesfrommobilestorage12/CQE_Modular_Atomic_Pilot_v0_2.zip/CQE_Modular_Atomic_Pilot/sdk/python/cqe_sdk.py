
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple
import hashlib, json, os, math, random, time

def sha256hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

@dataclass
class Pack:
    weyl_id: int
    chamber_id: int
    gsl: Dict[str, int]
    meta: Dict[str, Any]
    payload: Dict[str, Any]
    fastlane: bool = True
    pack_id: str = field(default_factory=lambda: sha256hex(os.urandom(16)))
    hash: str = ""

    def seal(self) -> "Pack":
        body = json.dumps({
            "weyl_id": self.weyl_id, "chamber_id": self.chamber_id,
            "gsl": self.gsl, "meta": self.meta, "payload": self.payload,
            "fastlane": self.fastlane,
        }, sort_keys=True).encode()
        self.hash = sha256hex(body)
        return self

class Module:
    KIND = "custom"; NAME = "base"; DETERMINISTIC = True; FENCE_RULES: List[str] = []
    def __init__(self, config: Dict[str, Any] | None = None) -> None: self.config = config or {}
    def accept(self, pack: Pack) -> bool: return True
    def process(self, pack: Pack) -> Pack: raise NotImplementedError

# --- Core modules ---

class Normalizer(Module):
    KIND="normalizer"; NAME="normalizer"
    def process(self, pack: Pack) -> Pack:
        p = pack.payload
        comp = p.get("comparator", {"order_key":["ts","id"],"metrics":["exact"],"tolerances":{"exact":1.0}})
        pack.meta["comparator"] = comp
        # canonicalize prompt
        pack.payload["prompt_norm"] = " ".join(str(p.get("prompt","")).split())
        return pack.seal()

class WeylSlicer(Module):
    KIND="slicer"; NAME="weyl_slicer"
    def process(self, pack: Pack) -> Pack:
        # annotate which slice; real system would apply Weyl reflection to content
        pack.meta["slice"] = f"H{pack.weyl_id}"
        return pack.seal()

class GradientPainter(Module):
    KIND="painter"; NAME="gradient"
    def process(self, pack: Pack) -> Pack:
        # Simple synthetic gradient stats (novelty, alias, parity_debt, latency)
        rnd = random.Random(sha256hex((pack.hash + "grad").encode())[:8])
        novelty = rnd.uniform(0.4, 1.0)
        alias = rnd.uniform(0.0, 0.4)
        parity_debt = rnd.uniform(0.0, 0.2)
        latency = rnd.uniform(0.0, 0.2)
        gain = novelty - 0.6*alias - 0.3*parity_debt - 0.2*latency
        pack.meta["grad"] = {"novelty":novelty,"alias":alias,"parity_debt":parity_debt,"latency":latency,"gain":gain}
        return pack.seal()

class BraidComposer(Module):
    KIND="composer"; NAME="braid"; FENCE_RULES=["all8_closure","dual","compose"]
    def __init__(self, config=None): super().__init__(config or {"chambers":4096})
    def process(self, pack: Pack) -> Pack:
        # Build per-chamber winner map across 8 slices with a simple score; ensure stability via margin
        chambers = int(self.config.get("chambers", 4096))
        rnd = random.Random(sha256hex((pack.payload.get("prompt_norm","") + str(pack.meta.get("window_id"))).encode())[:16])
        winners = []
        min_margin = 1.0
        for t in range(chambers):
            scores = [rnd.random() for _ in range(8)]  # mock BraidScore
            k = max(range(8), key=lambda i: scores[i])
            # φ tiebreak: prefer closest to slice id in circular order
            ties = [i for i,s in enumerate(scores) if abs(s - scores[k]) < 1e-9]
            if len(ties) > 1:
                def circ_dist(i,j): 
                    d=abs(i-j); return min(d, 8-d)
                k = min(ties, key=lambda i: circ_dist(i, pack.weyl_id))
            # margin
            runner = sorted(scores)[-2]
            margin = scores[k] - runner
            min_margin = min(min_margin, margin)
            winners.append((t,k,margin))
        pack.meta["braid"] = {
            "winner_min_margin": round(min_margin, 4),
            "winners_hash": sha256hex(json.dumps(winners[:128]).encode()),  # hash sample for brevity
            "chambers": chambers
        }
        return pack.seal()

class ReceiptsEngine(Module):
    KIND="receipts"; NAME="receipts"
    def process(self, pack: Pack) -> Pack:
        # Simulate receipts passing and attach seals; use pack hash as seed
        seed = int(sha256hex(pack.hash.encode())[:8], 16)
        rnd = random.Random(seed)
        all8 = True
        dual = True
        compose = True
        # Tiny probability to simulate a fence failure; then fix by replay (here we just set pass)
        if rnd.random() < 0.01:
            all8 = False
        if not all8:  # "replay"
            all8 = True
        pack.meta["receipts"] = {
            "all8_closure": all8, "dual": dual, "compose": compose,
            "seal": sha256hex((pack.hash + "sealed").encode())
        }
        return pack.seal()

class ComplianceGate(Module):
    KIND="compliance"; NAME="compliance"
    def process(self, pack: Pack) -> Pack:
        # Placeholder: in real system, check PII, anchors, retention, caps
        pack.meta["compliance"] = {"policy":"edge_checks: all8, dual, compose, capability_proof", "passed": True}
        return pack.seal()

class NuggetMint(Module):
    KIND="nugget"; NAME="mint"
    def __init__(self, outdir: str, config=None):
        super().__init__(config)
        self.outdir = outdir
        os.makedirs(outdir, exist_ok=True)
    def process(self, pack: Pack) -> Pack:
        prompt = pack.payload.get("prompt_norm","")
        answer = f"[CQE] One-shot sealed answer for: {prompt}"
        # Digests
        input_digest = sha256hex(prompt.encode())
        output_digest = sha256hex(answer.encode())
        token_id = "mtok_" + sha256hex((pack.hash + str(time.time())).encode())[:16]
        token = {
            "token_id": token_id,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "weyl_id": pack.weyl_id, "chamber_id": pack.chamber_id,
            "gsl": pack.gsl, "phi_mode":{"enabled":True,"gradient":True,"window":[13,21,34]},
            "edge_fence":"end_of_window",
            "input_digest": input_digest, "output_digest": output_digest,
            "user_comparator": pack.meta.get("comparator", {}),
            "braid_receipt": {
                "all8_closure": pack.meta.get("receipts",{}).get("all8_closure", True),
                "dual": pack.meta.get("receipts",{}).get("dual", True),
                "compose": pack.meta.get("receipts",{}).get("compose", True),
                "winner_hash": pack.meta.get("braid",{}).get("winners_hash",""),
                "runnerup_margin_min": pack.meta.get("braid",{}).get("winner_min_margin",0.0),
                "zero_event_index": 104
            },
            "caps": pack.meta.get("caps",[]),
            "ledger_refs": {"macrocycle_seal": pack.meta.get("receipts",{}).get("seal",""), "pack_ids":[pack.pack_id]},
            "sidecar": {}
        }
        path = os.path.join(self.outdir, f"{token_id}.json")
        with open(path,"w") as f: json.dump(token, f, indent=2)
        pack.meta["minted_token_path"] = path
        pack.meta["answer"] = answer
        return pack.seal()
