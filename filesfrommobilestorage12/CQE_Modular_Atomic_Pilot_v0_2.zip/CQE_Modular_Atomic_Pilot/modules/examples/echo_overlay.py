from cqe_sdk import Module, Pack
class EchoOverlay(Module):
    KIND="overlay"; NAME="echo_overlay"
    def process(self, pack: Pack) -> Pack:
        text = pack.payload.get("prompt","")
        pack.meta["overlay_variants"] = [text, text.upper(), text.lower()]
        return pack.seal()
