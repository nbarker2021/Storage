
# Phys.org Quantum Chemistry ML-XC (Sept 20, 2025) – CQE Mapping

**Core claim:** Learned XC functional achieves ~rung-3 (meta-GGA-like) accuracy using rung-2 complexity by inverting many-body references on light atoms/molecules; validated with transfer tests.

**CQE fold-in:**
- **Octet:** {Li,C,N,O,Ne; H2, LiH; GGA; learned-XC; basis sweep; MB→DFT; DFT→MB; transfer-to-solids}
- **Mirror:** MB→DFT ↔ DFT→MB (palindromic residual bands), train↔eval swap
- **Δ-lifts:** gradient correction → range-separation tweak → density smoothing
- **Strict:** MAE 0.08→0.05→0.03 eV gates; SC 0.95→0.99 ratchet
- **Receipt (demo):** MAE 0.048 eV, MSE 0.004 eV², SC 0.982 → **fourbit = 1011** (provisional)

**Next:** Second octet (solids proxy) + cross-benchmark on small organic set.
