# CQE Governance v0.2 (always-on)

- Output modes: **Blueprint**, **Summary**, **Redacted**.
- Bio/dual-use content must not emit actionable protocols. Summaries only; numerical placeholders allowed when needed.
- Any lane that attempts unsafe spill is forced to four-bit `0001` and quarantined to Non-Working Album with a breadcrumb only.
- Receipts bind meaning only after commit; stand-ins remain semantics-free until pass.
- Logs: hash-only provenance; no sensitive raw payload in receipts.
- This file: generated 2025-09-20T14:52:03.381636Z.