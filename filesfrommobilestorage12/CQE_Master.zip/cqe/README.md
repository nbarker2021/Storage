# CQE Master Pack (v0.2)

This bundle contains:
- `receipt_abi.json` — the 4‑bit ABI (bits, opcodes, payload schema).
- `viewers.json` — 8×8 local, 4×4×4×4 surround, and parity shell viewer config.
- `receipts_demo.csv` — safe synthetic receipts for four actors (demo).
- `playbooks.json` — BroadbandComb octet/mirror/Δ/strict playbook.
- `hotzones.json` — 4‑bit caps & nudges for stabilization.
- `safety_policies.md` — governance v0.2 (always‑on).
- `sidecars_catalog.json` — 16 baseline rails.
- `workorder.json` — provenance + Merkle root.

## Quick start
1. Load `viewers.json` to set the viewers.
2. Append your evidence metrics and stamp a four‑bit per `receipt_abi.json`.
3. If a hot zone appears, apply a cap from `hotzones.json`.
4. Keep everything ledgered under `workorder.json`.