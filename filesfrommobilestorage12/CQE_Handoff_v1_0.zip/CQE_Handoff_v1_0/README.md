# CQE Handoff Package v1.0

**Timestamp (UTC):** 2025-09-20 21:28 UTC

This package bundles everything needed to **learn, run, and hand-verify** the CQE method offline:
- Docs: method rationale, by-hand guides, and walk-throughs.
- Worksheets (printable): n=4→pal rest, n=5→octad census, mirror logs, strict ratchets, ledger receipts, card-deck mapping.
- Harness: a tiny Python SDK to run OCTET→MIRROR→Δ→STRICT→LEDGER with sample datasets and a CLI.
- Datasets: all session examples encoded as compare sets with receipts (4-bit commits + hashes).
- Cards: printable blank cards & suit glyphs to build the **paper+ink** kit (decks + ledger).
- Templates: CSV/JSON forms to add your own tokens and view plans.

## Quick start
1. **Print** key worksheets from `/worksheets` (WS-1 … WS-8).
2. **Install** Python 3.10+ and run the harness:
   ```bash
   cd harness
   python -m cqe_harness.run --dataset ../datasets/session_examples.json --plan default
   ```
3. **Compare** receipts and hot-zones to your worksheet outcomes.
4. **Swap** `templates/tokens_template.csv` with your tokens to re-run on your data.
5. **By-hand mode:** use `/docs/By_Hand_Solver_Guide.pdf` + `/cards/Card_Kit.pdf` with decks and a notebook.

## Contents
- `/docs` – reference PDFs and guides
- `/worksheets` – printable forms
- `/harness` – runnable Python SDK + CLI
- `/datasets` – example compare-sets and receipts
- `/cards` – printable card kit
- `/templates` – CSV/JSON templates for your data

See `/docs/Tools_and_Methods.pdf` and `/docs/Test_Harness_User_Guide.pdf` for details.
