
def apply_deltas(rules, tokens):
    # Toy Δ: reduce residual by small fraction per rule; annotate tokens
    touch = min(0.02*len(rules), 0.08)
    return touch
