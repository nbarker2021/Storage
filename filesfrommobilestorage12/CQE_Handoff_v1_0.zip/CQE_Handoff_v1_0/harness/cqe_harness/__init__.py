"""
cqe_harness – minimal CQE loop: OCTET → MIRROR → Δ → STRICT → LEDGER
"""
