
def plan_views(octet):
    assert len(octet) == 8, "octet must have 8 views"
    return {"views": list(octet), "coverage": 1.0}
