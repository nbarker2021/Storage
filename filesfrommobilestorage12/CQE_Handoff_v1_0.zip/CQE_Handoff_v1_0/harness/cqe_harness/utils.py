
import hashlib, json, math

def merkle_root_from_obj(obj):
    def flatten(o):
        if isinstance(o, dict):
            return "{" + ",".join(f"{k}:{flatten(v)}" for k,v in sorted(o.items())) + "}"
        if isinstance(o, list):
            return "[" + ",".join(flatten(v) for v in o) + "]"
        return str(o)
    s = flatten(obj)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def fourbit_from_debts(ope, fce, passes):
    # Simple 4-bit: [pass, ope_ok, fce_ok, parity_bit]
    b0 = 1 if passes else 0
    b1 = 1 if ope <= 0.05 else 0
    b2 = 1 if fce <= 0.05 else 0
    b3 = (b0 ^ b1 ^ b2) & 1
    return f"{b0}{b1}{b2}{b3}"
