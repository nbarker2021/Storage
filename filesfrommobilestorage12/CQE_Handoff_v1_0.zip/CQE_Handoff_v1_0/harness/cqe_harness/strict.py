
def ratchet(thresholds, ope, fce, passed):
    new = dict(thresholds)
    if passed:
        new["OPE"] = max(0.0, thresholds["OPE"] - 0.01)
        new["FCE"] = max(0.0, thresholds["FCE"] - 0.01)
    return new
