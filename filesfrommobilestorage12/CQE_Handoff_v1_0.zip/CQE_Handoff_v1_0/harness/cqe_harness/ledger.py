
from .utils import merkle_root_from_obj, fourbit_from_debts

def commit(page):
    root = merkle_root_from_obj(page)
    four = fourbit_from_debts(page["debts"]["OPE"], page["debts"]["FCE"], page["passes"])
    page["merkle"] = root
    page["fourbit"] = four
    return page
