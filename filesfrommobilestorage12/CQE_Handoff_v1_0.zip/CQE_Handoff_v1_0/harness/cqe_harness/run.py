
import json, argparse
from .overlay import plan_views
from .mirror import mirror_check
from .delta import apply_deltas
from .strict import ratchet
from .ledger import commit
from .utils import merkle_root_from_obj

def run_once(example, thresholds):
    views = plan_views(example["octet"])
    base_debt = mirror_check(example["mirror"], example["tokens"])
    delta_touch = apply_deltas(example.get("delta",[]), example["tokens"])
    OPE = max(0.0, base_debt - 0.5*delta_touch)
    FCE = max(0.0, base_debt - 0.3*delta_touch)
    passes = (OPE <= thresholds["OPE"]) and (FCE <= thresholds["FCE"])
    new_thresh = ratchet(thresholds, OPE, FCE, passes)
    page = {
        "id": example["id"],
        "views": views["views"],
        "thresholds_before": thresholds,
        "debts":{"OPE":round(OPE,4),"FCE":round(FCE,4)},
        "passes": passes,
        "tokens":[{k:v for k,v in t.items() if k!="glyphs"} for t in example["tokens"]],
        "delta": example.get("delta",[]),
    }
    return commit(page), new_thresh

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--plan", default="default")
    ap.add_argument("--out", default="receipts.json")
    args = ap.parse_args()
    with open(args.dataset,"r",encoding="utf-8") as f:
        data = json.load(f)
    thresholds = {"OPE":0.05,"FCE":0.05}
    receipts = []
    for ex in data["examples"]:
        page, thresholds = run_once(ex, thresholds)
        receipts.append(page)
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump({"receipts":receipts,"final_thresholds":thresholds}, f, indent=2)
    print(f"Wrote {args.out}")

if __name__ == "__main__":
    main()
