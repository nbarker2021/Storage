
def mirror_check(spec, tokens):
    # Toy: if any token violates guard, count as mismatch; else pass.
    debt = 0.0
    for t in tokens:
        g = t.get("guards", {})
        if "min" in g and t["value"] < g["min"]: debt += 0.02
        if "max" in g and t["value"] > g["max"]: debt += 0.02
    # pretend forward/back residuals add 0.01 per token
    debt += 0.01*len(tokens)
    return max(0.0, min(0.2, debt))
