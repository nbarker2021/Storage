# Paper4 Observer Calculus

Expanded full draft of Paper 4: Witness, observer calculus, and contradictions.

>>> Full expansion from session tokens will be populated here in detail.
