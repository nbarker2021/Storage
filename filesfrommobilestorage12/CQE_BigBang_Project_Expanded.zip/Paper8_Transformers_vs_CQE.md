# Paper8 Transformers vs CQE

Expanded full draft of Paper 8: AI, transformers, and CQE ledger proofs.

>>> Full expansion from session tokens will be populated here in detail.
