# CQE Big Bang Project (Expanded Drafts)

This repository contains the 10 expanded papers derived from our session work.

- [Paper1_Foundations_CQE_and_BigBang.md](./Paper1_Foundations_CQE_and_BigBang.md)
- [Paper2_Geometry_and_1-64-1_Cycle.md](./Paper2_Geometry_and_1-64-1_Cycle.md)
- [Paper3_Entropy_and_Energetics.md](./Paper3_Entropy_and_Energetics.md)
- [Paper4_Observer_Calculus.md](./Paper4_Observer_Calculus.md)
- [Paper5_Alena_Operator_and_Tensor.md](./Paper5_Alena_Operator_and_Tensor.md)
- [Paper6_Physics_and_GR_Extensions.md](./Paper6_Physics_and_GR_Extensions.md)
- [Paper7_Chemistry_Biology_Mappings.md](./Paper7_Chemistry_Biology_Mappings.md)
- [Paper8_Transformers_vs_CQE.md](./Paper8_Transformers_vs_CQE.md)
- [Paper9_Critique_and_Falsifiers.md](./Paper9_Critique_and_Falsifiers.md)
- [Paper10_Grand_Demo_and_Universal_Sim.md](./Paper10_Grand_Demo_and_Universal_Sim.md)
