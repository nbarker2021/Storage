# CQE Big Bang Project

This repository contains 10 longform technical papers developed from the full session logs.
Each paper expands on core CQE principles, physics/biology/computation applications, demonstrations, and falsifiers.
All documents are designed to be complete, with no details omitted.
