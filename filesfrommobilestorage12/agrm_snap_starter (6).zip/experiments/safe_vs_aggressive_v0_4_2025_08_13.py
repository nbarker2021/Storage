import argparse, numpy as np, time, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_4_2025_08_13 import AGRMController_v0_4_2025_08_13
def make_points(n, seed): rng=np.random.default_rng(seed); return rng.random((n,2))
def run_cfg(name, cfg, n=400, seed=7):
    pts=make_points(n,seed); t0=time.time(); ctrl=AGRMController_v0_4_2025_08_13(cfg=cfg)
    res=ctrl.solve(pts,max_ticks=cfg.get("max_ticks",8)); dt=(time.time()-t0)*1000; s=res["stats"]
    print(f"[{name}] ms={dt:.1f} ticks={s['ticks']} steps={s['steps']} stalls={s['stalls']} thrash={s['thrash']} sectors={s['sectors_visited']} inv_steps={s['inverse_steps']} inv_hits={s['inverse_hits']} cov_gain={s['coverage_gain']} inv_roi={res['inverse_roi']:.3f}")
    return dt,res
def main():
    safe={"num_shells":8,"num_sectors":32,"theta_open":0.6,"theta_close":0.3,"cooldown":2,"align_gain":0.2,"max_steps_per_arm":6,"inverse_budget":1,"max_ticks":8}
    aggressive={"num_shells":8,"num_sectors":32,"theta_open":0.2,"theta_close":-0.2,"cooldown":0,"align_gain":0.0,"max_steps_per_arm":16,"inverse_budget":4,"max_ticks":8}
    dt_s,r_s=run_cfg("SAFE",safe); dt_a,r_a=run_cfg("AGGR",aggressive)
    print("\nSUMMARY:",{"time_ms":{"safe":dt_s,"aggressive":dt_a},"safe":r_s["stats"],"aggressive":r_a["stats"],"safe_inv_roi":r_s["inverse_roi"],"aggr_inv_roi":r_a["inverse_roi"]})
if __name__=="__main__": main()
