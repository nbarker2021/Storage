def check(mirror):
    residual = mirror.get("residual", 1.0)
    tol = mirror.get("tolerance", 0.0)
    return residual, residual <= tol