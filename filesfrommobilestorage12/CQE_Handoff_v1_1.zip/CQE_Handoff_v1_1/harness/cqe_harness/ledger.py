import hashlib, json
def commit_bits(ok_octet, ok_mirror, ok_delta, ok_strict):
    return "".join("1" if b else "0" for b in [ok_octet, ok_mirror, ok_delta, ok_strict])

def evidence_hash(record):
    s = json.dumps(record, sort_keys=True).encode()
    return hashlib.sha256(s).hexdigest()