import json, argparse
from . import overlay, mirror, delta, strict, ledger

def run(dataset_path, plan_path, out_path):
    with open(dataset_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    with open(plan_path, "r", encoding="utf-8") as f:
        plan = json.load(f)
    results = []
    for item in data:
        passed, ok_octet = overlay.coverage(item["views"], plan["accept"]["octet_min_pass"])
        resid, ok_mirror = mirror.check(item["mirror"])
        debt_before = resid
        debt_after, shaved = delta.apply(item.get("delta_allowed", []), debt_before)
        ok_delta = debt_after <= debt_before
        ok_strict = strict.ratchet(item.get("strict", {}))
        bits = ledger.commit_bits(ok_octet, ok_mirror, ok_delta, ok_strict)
        rec = {
            "id": item["id"],
            "title": item["title"],
            "octet_passed": passed,
            "ok_octet": ok_octet,
            "mirror_residual": resid,
            "ok_mirror": ok_mirror,
            "delta_shaved": shaved,
            "ok_delta": ok_delta,
            "ok_strict": ok_strict,
            "4bit": bits
        }
        rec["hash"] = ledger.evidence_hash(rec)
        results.append(rec)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--plan", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    run(args.dataset, args.plan, args.out)