def coverage(views, min_pass=6):
    passed = sum(1 for v in views if v.get("score",0) >= 1)
    return passed, passed >= min_pass