def apply(deltas_allowed, debt_before):
    # toy: each allowed delta can shave 0.01 debt, up to 0.03
    shave = min(0.01 * len(deltas_allowed), 0.03)
    return max(debt_before - shave, 0.0), shave