def ratchet(strict):
    # Accept if 'new' <= 'prev' for all keys
    ok = True
    for k, v in strict.items():
        if isinstance(v, dict) and "prev" in v and "new" in v:
            if v["new"] > v["prev"]: ok = False
    return ok