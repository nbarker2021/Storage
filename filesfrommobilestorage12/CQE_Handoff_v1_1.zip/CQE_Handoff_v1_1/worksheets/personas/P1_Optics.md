# Optics Lead (Station S2) — One‑Pager (Deck + Balsa Variant)

**Inputs:** domain tokens → A..8; 9 assembled; 10 parity twin; J/Q/K observers; Jokers for Cartan links.  
**Quick metrics:** list 3–5 simple measurements you can do by hand (bench, ruler, overlay, timing).  
**Octet plan:** define 8 views relevant to your station.  
**Mirror:** define forward/inverse swap.  
**Δ‑cookbook:** 3 allowed small fixes.  
**Strict:** 2 bounds to ratchet.  
**Ledger note:** what constitutes a 4‑bit pass here?

**Balsa variant:** cut balsa strips; tape cards as faces of a cube/hypercube scaffold; use colored string for parity lanes; attach sticky tags with measurements. Re‑pose scaffold to test mirror equivalence.