# WS‑5: Δ‑Monotonicity & Strict Ratchet

List allowed small rewrites; show debt↓ and no regression; when all pass, tighten one bound.