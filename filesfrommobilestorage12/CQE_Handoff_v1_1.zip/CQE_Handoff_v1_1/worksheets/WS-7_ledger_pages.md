# WS‑7: Ledger

Row template: id | 4‑bit | votes | hash | thresholds | notes.