# WS‑6: Octet Overlay

Eight colored view boxes + gray mirror box; space for metrics and local votes.