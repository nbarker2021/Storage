# WS‑8: Card Mapping

Map A..10,J,Q,K,Jokers to your domain tokens and observers; record crossover jokers.