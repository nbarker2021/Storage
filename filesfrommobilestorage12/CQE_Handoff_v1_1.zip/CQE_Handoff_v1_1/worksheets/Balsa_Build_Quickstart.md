# Balsa Build Quickstart

- Cut 12 balsa strips (edge lengths equal); tape to form a cube; optional: extend to 4D via shadow scaffolds.
- Tape cards to faces/edges as view panels; use string for parity lanes; add translucent overlays for mirror.
- Rotate/flip scaffold to test equivariance; snap a phone photo; staple printouts to ledger page.