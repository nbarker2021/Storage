# WS‑2: n=5 → Octad Census

Insert symbol 5 into each of 16 cells; run local repairs; group into 8 inequivalent classes.