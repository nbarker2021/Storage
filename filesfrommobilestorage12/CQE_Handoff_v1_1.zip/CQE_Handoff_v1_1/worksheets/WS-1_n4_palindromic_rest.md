# WS‑1: n=4 Palindromic Rest

Draw 4×4; build the n=4 rest; mark mirror lanes; record forks and repairs.