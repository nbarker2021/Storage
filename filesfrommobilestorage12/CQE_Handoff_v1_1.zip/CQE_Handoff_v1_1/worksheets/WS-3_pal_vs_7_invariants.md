# WS‑3: 1 Palindromic + 7 Invariants

From WS‑2, identify the one class re‑canonicalizing to palindrome; list the seven invariant non‑palindromes.