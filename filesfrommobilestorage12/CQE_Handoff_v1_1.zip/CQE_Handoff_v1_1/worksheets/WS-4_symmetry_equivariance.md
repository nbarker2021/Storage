# WS‑4: Symmetry‑Equivariance

Apply rotations/reflections; verify class labels permute within the octad.