# CQE Tools & Methods (v1.1)

**Spine:** Octet → Mirror → Δ‑lift → Strict → Ledger.

- **Octet overlays:** define 8 materially independent views (modalities/slices/scales). Each view yields a local score (0/1 or float). Coverage = fraction of views that pass the acceptance criterion.
- **Mirror:** a forward/inverse or swapped‑order replay. Acceptance if distance ≤ tolerance (L2/L∞, or domain metric). Palindromic rest when forward∘inverse ≈ identity.
- **Δ‑lift (local repair):** a small, declared rewrite allowed by the cookbook (e.g., change one kernel, adjust a bias). Must reduce debt and never regress other passing views.
- **Strict ratchet:** thresholds tighten only after a pass; never loosen automatically.
- **Ledger:** compact 4‑bit commit (one bit per gate class) + evidence hash (Merkle).

**Determinism:** all steps are finite, checkable arithmetic/geometry.  
**Reproducibility:** receipts + dataset hash = 1:1 replay.