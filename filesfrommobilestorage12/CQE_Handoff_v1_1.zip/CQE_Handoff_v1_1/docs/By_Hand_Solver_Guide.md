# By‑Hand Solver Guide (Deck + Journal)

**You need:** paper notebook, pencils, 2 standard card decks (different back colors), sticky notes, tape, ruler.

1) **Stand‑ins:** map quantities to cards (A=primitive token, 2=pair synth, …, 8=octet completion; 9=assembled candidate; 10=parity twin; J/Q/K=witness/observer; Jokers=Cartan/subharmonic cross‑room links).
2) **DNA‑10 strip:** on a sticky note write: timing, polarity, scale, pose, domain, conditioning, units, precision, cost, seed.
3) **Octet:** lay 8 cards (one per view). Color by deck = parity lanes.
4) **Mirror:** flip sequence or swap order; check pal rest using ruler/overlay; record mismatch as debt.
5) **Δ‑lift:** only cookbook‑allowed fixes. Mark red line on the changed card; re‑test locally.
6) **Strict:** if all pass, tighten a bound in gold ink; otherwise keep previous bound.
7) **Ledger:** shade 4 boxes (Octet/Mirror/Δ/Strict). If ≥4 bits lit, copy to Master Ledger with a short hash of the page id + date.

**Tip:** If you hit an edge (needs “outside” info), place a Joker + arrow to a new sub‑deck and continue there.