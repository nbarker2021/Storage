# All Tests Overview

Included compare sets:
- **session_examples.json** — OPTICS/THERMAL/POLAR/MATH miniature.
- **why10_examples.json** — the ten WHY exemplars (octet necessity; mirror; Δ monotonicity; strict; receipts; Leech/Monster clones; card method; sound/subharmonics; thermodynamics/Landauer; global spine).

Each entry has: id, title, hypothesis, 8 views, mirror pairs, deltas allowed, strict thresholds, and expected 4‑bit.