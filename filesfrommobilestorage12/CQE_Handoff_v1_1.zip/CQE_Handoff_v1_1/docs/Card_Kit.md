# Card Kit (8 suits variant)

- Suits (example): Optics ♦, Thermal ♥, Polar ♣, Math ♠, Spin ⧫, Bio ♥︎, Plasma ⨂, Systems ⧖ (replace with your domains).
- Ranks: A..10, J,Q,K, plus **Witness‑1/2/3** (after 10), **8 Jokers** (two colors per chamber‑pair). Print 2–4 copies per suit.
- Back colors: deck‑A (light), deck‑B (dark) = parity lanes.
- Print on card stock; cut; add dry‑erase sleeves if available.