# Test Harness User Guide

Run:
```
cd harness
python -m cqe_harness.run --dataset ../datasets/why10_examples.json --plan plan_why10.json --out receipts_why10.json
```
Outputs `receipts_*.json` with coverage, mirror residual, Δ count, strict status, 4‑bit commit, and evidence hash.

**Swap your data:** Copy `templates/tokens_template.csv` and `templates/plan_template.json` and point `--dataset` and `--plan` to your files.