#!/usr/bin/env python
"""
Monolith Slicer
---------------
Reads a large Python file and emits per-symbol modules under target_dir.
- Top-level classes/functions become separate files.
- Adds a header docstring and preserves source text.
- Writes an index.json mapping names -> files for later refactoring.
This is a *helper* for manual refactors; review generated code before use.
"""
from __future__ import annotations
import ast, json
from pathlib import Path
import argparse

def slice_file(src: Path, target_dir: Path) -> Path:
    target_dir.mkdir(parents=True, exist_ok=True)
    text = src.read_text(encoding="utf-8")
    tree = ast.parse(text)
    lines = text.splitlines()
    index = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = node.name
            start = node.lineno - 1
            ends = [getattr(n, "lineno", None) for n in tree.body
                    if getattr(n, "lineno", None) and getattr(n, "lineno") > node.lineno]
            end = (min(ends)-1) if ends else len(lines)
            snippet = "\n".join(lines[start:end])
            out = target_dir / f"{name.lower()}.py"
            header = f'"""Slice extracted from {src.name}: symbol {name}"""\n\n'
            out.write_text(header + snippet + "\n", encoding="utf-8")
            index[name] = str(out)
    idx = target_dir / "index.json"
    idx.write_text(json.dumps(index, indent=2), encoding="utf-8")
    return idx

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src", type=Path, help="Path to monolith .py file")
    ap.add_argument("--out", type=Path, default=Path("src/cqe/slices"), help="Target directory for slices")
    args = ap.parse_args()
    idx = slice_file(args.src, args.out)
    print(f"Sliced index -> {idx}")

if __name__ == "__main__":
    main()
