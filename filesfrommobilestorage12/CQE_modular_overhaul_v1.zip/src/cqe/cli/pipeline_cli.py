"""
Run a named sequence of plugins on input text and write results.
"""
from __future__ import annotations
import argparse
from pathlib import Path
from typing import List, Dict, Any

from cqe.pipeline.core import Pipeline
from cqe.extensions import registry as R

def main() -> None:
    parser = argparse.ArgumentParser(description="CQE plugin pipeline")
    parser.add_argument("--text", required=True, help="Input text")
    parser.add_argument("--out", default="runs/pipeline", help="Output directory")
    parser.add_argument("--steps", default="tokenizer,graph,pose,metrics,exporter",
                        help="Comma-separated step names in order")
    args = parser.parse_args()

    steps: List[str] = [s.strip() for s in args.steps.split(",") if s.strip()]
    pipeline = Pipeline(steps=[R.create(name) for name in steps])

    initial: Dict[str, Any] = {"text": args.text}
    res = pipeline.run(initial, Path(args.out), params={})
    print(f"✅ Pipeline complete. Steps: {steps}")
    print(res)

if __name__ == "__main__":
    main()
