"""
CQE Pipeline core orchestrates Step plugins.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List
from pathlib import Path

from cqe.abc.interfaces import Step, Context

@dataclass(slots=True)
class Pipeline:
    steps: List[Step] = field(default_factory=list)

    def run(self, initial: Dict[str, Any], outdir: Path, params: Dict[str, Any] | None = None) -> Dict[str, Any]:
        ctx = Context(outdir=outdir, params=params or {})
        data = dict(initial)
        for step in self.steps:
            data = step.run(data, ctx)
        return data
