"""
Simple plugin registry for CQE steps.
"""
from __future__ import annotations
from typing import Callable, Dict, Type
from cqe.abc.interfaces import Step

_REGISTRY: Dict[str, Type[Step]] = {}

def register(name: str) -> Callable[[Type[Step]], Type[Step]]:
    def deco(cls: Type[Step]) -> Type[Step]:
        cls.name = name  # type: ignore[attr-defined]
        _REGISTRY[name] = cls
        return cls
    return deco

def create(name: str, **kwargs) -> Step:
    cls = _REGISTRY[name]
    return cls(**kwargs)  # type: ignore[call-arg]

def available() -> Dict[str, Type[Step]]:
    return dict(_REGISTRY)
