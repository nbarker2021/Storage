from __future__ import annotations
from typing import Dict, Any
from cqe.abc.interfaces import Step, Context
from cqe.extensions.registry import register
import hashlib

def _h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

@register("pose")
class PoseSolver:
    def run(self, data: Dict[str, Any], ctx: Context) -> Dict[str, Any]:
        text = str(data.get("text",""))
        data["pose"] = {"kind": "token-graph", "hash": _h(text)}
        return data
