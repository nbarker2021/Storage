from __future__ import annotations
from typing import Dict, Any
from cqe.abc.interfaces import Step, Context
from cqe.extensions.registry import register

@register("metrics")
class Metrics:
    def run(self, data: Dict[str, Any], ctx: Context) -> Dict[str, Any]:
        toks = data.get("tokens", [])
        data["metrics"] = {"token_count": len(toks), "unique": len(set(toks))}
        return data
