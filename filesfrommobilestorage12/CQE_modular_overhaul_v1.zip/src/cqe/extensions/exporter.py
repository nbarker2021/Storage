from __future__ import annotations
from typing import Dict, Any
from pathlib import Path
from cqe.abc.interfaces import Step, Context
from cqe.extensions.registry import register
from cqe.harness.core import write_receipt

@register("exporter")
class Exporter:
    def run(self, data: Dict[str, Any], ctx: Context) -> Dict[str, Any]:
        outdir: Path = ctx.outdir
        write_receipt(outdir, data)
        return data
