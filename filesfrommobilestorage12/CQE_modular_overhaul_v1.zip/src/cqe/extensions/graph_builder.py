from __future__ import annotations
from typing import Dict, Any
from cqe.abc.interfaces import Step, Context
from cqe.extensions.registry import register

@register("graph")
class GraphBuilder:
    def run(self, data: Dict[str, Any], ctx: Context) -> Dict[str, Any]:
        toks = data.get("tokens", [])
        edges = [(toks[i], toks[i+1]) for i in range(len(toks)-1)]
        data["graph"] = {"nodes": list(dict.fromkeys(toks)), "edges": edges}
        return data
