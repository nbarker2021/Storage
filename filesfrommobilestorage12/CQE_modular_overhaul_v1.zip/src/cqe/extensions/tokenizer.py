from __future__ import annotations
from typing import Dict, Any
from cqe.abc.interfaces import Step, Context
from cqe.extensions.registry import register

@register("tokenizer")
class Tokenizer:
    def __init__(self, sep: str = " "):
        self.sep = sep
    def run(self, data: Dict[str, Any], ctx: Context) -> Dict[str, Any]:
        text = str(data.get("text", ""))
        data["tokens"] = [t for t in text.split(self.sep) if t]
        return data
