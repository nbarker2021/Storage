"""
Abstract interfaces for CQE pipeline steps.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Any, Dict

@dataclass(slots=True)
class Context:
    outdir: "Path"  # forward ref to avoid heavy imports
    params: Dict[str, Any]

class Step(Protocol):
    name: str
    def run(self, data: Dict[str, Any], ctx: Context) -> Dict[str, Any]: ...
