from cqe.cli.bootstrap import main as bootstrap

def test_bootstrap(tmp_path, monkeypatch):
    monkeypatch.setenv("CQE_HOME", str(tmp_path / ".cqe"))
    monkeypatch.setenv("CQE_RUNS", str(tmp_path / "runs"))
    monkeypatch.setenv("CQE_LOGS", str(tmp_path / "logs"))
    monkeypatch.setenv("CQE_DATA", str(tmp_path / "data"))
    bootstrap()
    for sub in [".cqe", "runs", "logs", "data"]:
        assert (tmp_path / sub).exists()
