from cqe.extensions.registry import available
def test_registry_has_defaults():
    names = set(available().keys())
    assert {"tokenizer","graph","pose","metrics","exporter"} <= names
