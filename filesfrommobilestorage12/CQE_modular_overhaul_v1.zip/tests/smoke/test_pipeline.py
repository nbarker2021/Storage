from pathlib import Path
from cqe.pipeline.core import Pipeline
from cqe.extensions import registry as R

def test_pipeline(tmp_path: Path):
    steps = [R.create(n) for n in ["tokenizer","graph","pose","metrics","exporter"]]
    p = Pipeline(steps=steps)
    res = p.run({"text":"a b c a"}, tmp_path / "plout", params={})
    assert "tokens" in res and res["metrics"]["token_count"] == 4
    assert (tmp_path/"plout"/"ledger.jsonl").exists()
