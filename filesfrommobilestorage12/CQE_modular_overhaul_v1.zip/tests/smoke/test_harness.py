from pathlib import Path
from cqe.harness.core import run_harness

def test_harness(tmp_path: Path):
    out = tmp_path / "out"
    res = run_harness("hello", out)
    assert (out/"ledger.jsonl").exists()
    assert res["status"] == "ok"
