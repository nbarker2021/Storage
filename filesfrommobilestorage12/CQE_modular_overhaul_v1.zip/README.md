# CQE Modular Extensions

This adds:
- A plugin-based pipeline (`cqe-pipeline`)
- A minimal harness that writes JSONL receipts (`cqe-harness`)
- A bootstrapper for directories (`cqe-bootstrap`)
- A **monolith slicer** utility to split large files into module slices

## Quickstart
```
pip install -e .
python -m cqe.cli.bootstrap
python -m cqe.cli.harness_cli --text "hello" --out runs/demo
python -m cqe.cli.pipeline_cli --text "a b c a" --out runs/pipeline --steps tokenizer,graph,pose,metrics,exporter
```
