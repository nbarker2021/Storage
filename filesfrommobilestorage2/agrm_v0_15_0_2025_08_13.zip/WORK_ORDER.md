
# Updated Work Order (v0.15.0, 2025-08-13)
1) Stabilize **snapshots/restore** with end-to-end tests and conflict handling (merge strategy options).
2) Harden **promotion invariants** (persist TTL metadata; auto-demotion after expiry).
3) Expand **RAG adapters** (PDF, HTML, code) + glyph/shell tagging on ingest.
4) Hook **SNAP Ops Center** into ingest & mannequin (auto-compat scoring post-ingest).
5) Add **DuckDB indexing** toggles and universe queries (by family/type/tag).
6) Build **CI** workflow (lint/type/tests/perf smoke).
7) Integrate **FastLane** decisions into controller outputs pipeline end-to-end.
8) Implement **Agent façade** (service endpoints mapping to CLI verbs; auth and rate limits).
9) Performance passes for **ANN adjacency** with larger N and FAISS/HNSW installs.
10) Documentation polish and examples (Safe-Cube policies, universes cookbook, CLI cheatsheet).
