# AGRM Service Stub

Run with FastAPI/uvicorn if installed; otherwise use CLI.
