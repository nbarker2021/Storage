
def create_app():
    try:
        from fastapi import FastAPI
        from pydantic import BaseModel
    except Exception:
        # Fallback: minimal shim object
        class App: 
            def __init__(self): self.info = "FastAPI not installed; use CLI instead."
        return App()

    from agrm.archivist.repository import Repository
    from agrm.universe.manager import UniverseManager
    from agrm.snap.ops_center import SnapOpsCenter
    from agrm.agrm.promotion import PromotionManager

    app = FastAPI(title="AGRM Service")

    class PromoteReq(BaseModel):
        source: str
        target: str
        quality: float
        result: dict

    @app.get("/health")
    def health(): return {"ok": True}

    @app.post("/promote")
    def promote(req: PromoteReq):
        REPO="/mnt/data/repository_store_v0_1_2025_08_13"
        REG ="/mnt/data/universe_registry_v0_1_2025_08_13"
        pm = PromotionManager(REPO, REG, quality_threshold=0.7)
        out = pm.stage_result("svc", req.result, req.quality, req.source, req.target)
        return out.__dict__

    return app
