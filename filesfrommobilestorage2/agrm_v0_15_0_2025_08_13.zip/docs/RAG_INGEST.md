
# RAG Ingest (adapter interface)
- Default adapter: `simple_text_parser(path, chunk_chars)` → SNAPs of family=`doc`, type=`chunk`.

- CLI: `agrm ingest-doc --file <path> --universe DocumentUniverse [--family doc] [--type fact]`.

- Future: plug advanced parsers (PDF, HTML, embeddings) under `agrm/plugins/rag/`.

