
# Promotion Invariants
- **TTL 24h**: staged results must be fully re-evaluated within 24 hours.

- **Policy acceptance**: target universe policies must allow `family=result`, `type=agrm_output` (or be unset).

- **Archivist trail**: all stage/promote events are posted to Archivist.

