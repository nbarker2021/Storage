# v0_10_0_2025_08_13
- Initial monorepo packaging.
- Ported modules into packages; added config skeleton; added shims.
