
from typing import Dict, Any, List, Tuple
import math, time

class SnapOpsCenter:
    """Ingests slice/result SNAPs, computes compatibility, and writes recommendations.

    Compatibility is a heuristic in [0,1] using family/type co-occurrence and simple tag overlaps.
    """
    def __init__(self, repository, archivist=None):
        self.repo = repository
        self.arch = archivist

    def _load_meta(self, snap_id: str) -> Dict[str,Any]:
        try:
            return self.repo.load(snap_id).get("meta", {})
        except Exception:
            return {}

    def _score_pair(self, A: Dict[str,Any], B: Dict[str,Any]) -> float:
        if not A or not B:
            return 0.0
        fam = 1.0 if A.get("family")==B.get("family") else 0.6 if (A.get("family") and B.get("family")) else 0.0
        typ = 1.0 if A.get("type")==B.get("type") else 0.6 if (A.get("type") and B.get("type")) else 0.0
        tagsA = A.get("tags", {}); tagsB = B.get("tags", {})
        keys = set(tagsA.keys()) | set(tagsB.keys())
        if not keys:
            tag_sim = 0.5
        else:
            match=0; total=0
            for k in keys:
                va, vb = tagsA.get(k), tagsB.get(k)
                if isinstance(va,(int,float)) and isinstance(vb,(int,float)):
                    # 1 - normalized absolute difference
                    denom = max(1.0, abs(va) + abs(vb))
                    match += 1.0 - min(1.0, abs(va - vb)/denom)
                else:
                    match += 1.0 if va==vb and va is not None else 0.0
                total += 1
            tag_sim = match/max(1,total)
        return max(0.0, min(1.0, 0.4*fam + 0.4*typ + 0.2*tag_sim))

    def assess_slice_against_universe(self, slice_snap_id: str, universe_snap_ids: List[str]) -> Dict[str,Any]:
        S = self._load_meta(slice_snap_id)
        if not S:
            return {"slice": slice_snap_id, "ok": False, "reason": "slice_not_found"}
        best = []
        for uid in universe_snap_ids[:2000]:  # cap
            U = self._load_meta(uid)
            score = self._score_pair(S, U)
            best.append((score, uid))
        best.sort(reverse=True, key=lambda x:x[0])
        recs = [{"snap_id": sid, "score": float(sc)} for sc, sid in best[:10]]
        # Write recommendation as a new SNAP
        rec_id = f"opsrec::{slice_snap_id}::{int(time.time())}"
        payload = {"meta": {"snap_id": rec_id, "family":"ops", "type":"recommendation",
                            "tags":{"count": len(recs)}, "lineage":{"source": slice_snap_id}},
                   "content": {"recommendations": recs}}
        self.repo.save(rec_id, payload)
        if self.arch:
            self.arch.post("ops", {"event":"ops_recommendation","slice":slice_snap_id,"rec_id":rec_id})
        return {"slice": slice_snap_id, "recommendation_snap": rec_id, "top": recs}

    def label_preference(self, snap_id: str, label: str, weight: float=1.0) -> bool:
        try:
            obj = self.repo.load(snap_id)
            meta = obj.get("meta", {})
            tags = meta.get("tags", {})
            prefs = tags.get("preferences", {})
            prefs[label] = float(weight)
            tags["preferences"] = prefs
            meta["tags"] = tags
            obj["meta"] = meta
            self.repo.save(snap_id, obj)
            return True
        except Exception:
            return False
