
from dataclasses import dataclass, field
from typing import Optional, Dict, Any

@dataclass
class AGRMConfig:
    vws_force_grid: bool = True
    vws_N_guard: int = 4000
    vws_grid_size: int = 64
    seeding_strategy: str = "grid"
    vws_skip_seed: bool = False

    use_adjacency_prefilter: bool = False
    adj_k: int = 8
    adj_buckets: int = 64

    enable_sap: bool = False
    enable_archivist: bool = False
    enable_fastlane: bool = False
    enable_snap_ops: bool = False

    repository_root: str = "/mnt/data/repository_store_v0_1_2025_08_13"
    universe_registry_root: str = "/mnt/data/universe_registry_v0_1_2025_08_13"

    fastlane_threshold: float = 0.75
    run_version: str = "v0_7_demo_int"

    # Priors
    prior_profile_path: Optional[str] = None

    # Arbitrary extras
    extra: Dict[str, Any] = field(default_factory=dict)
