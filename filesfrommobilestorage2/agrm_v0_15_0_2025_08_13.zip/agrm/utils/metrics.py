
import time
from contextlib import contextmanager

class Counter:
    def __init__(self):
        self.c = 0
    def inc(self, x=1): self.c += x
    def value(self): return self.c

class Gauge:
    def __init__(self, v=0): self.v=v
    def set(self, v): self.v=v
    def get(self): return self.v

@contextmanager
def timer():
    t0 = time.perf_counter()
    yield lambda: (time.perf_counter() - t0)
