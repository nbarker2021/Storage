def score(a,b): return 1.0
