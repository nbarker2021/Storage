
import argparse, importlib, json, os, random, sys, time, platform, traceback

DEFAULT_TESTS = [
    "cqe_harness.tests.invariants",
    "cqe_harness.tests.three_body_lockstep",
    "cqe_harness.tests.image_roundtrip",
    "cqe_harness.tests.cosmo_cmb",
    "cqe_harness.tests.quantum_bell",
    "cqe_harness.tests.thermo_entropy",
    "cqe_harness.tests.info_bounds",
    "cqe_harness.tests.linguistics_parse",
    "cqe_harness.tests.biology_folding",
    "cqe_harness.tests.computation_superperm",
    "cqe_harness.tests.math_godel_lattice",
]

def parse_kv(items):
    out = {}
    for kv in items or []:
        if "=" in kv:
            k, v = kv.split("=", 1)
            out[k.strip()] = v.strip()
    return out

def normalize_suite_output(name, raw):
    """Coerce arbitrary suite outputs (bools, dicts of bools, custom dicts) to a uniform schema."""
    suite = {}
    # If raw is simple bool
    if isinstance(raw, bool):
        suite[name] = {"status": "pass" if raw else "fail", "metrics": {}}
        return suite
    # If raw is dict of bools
    if isinstance(raw, dict) and all(isinstance(v, bool) for v in raw.values()):
        for k, v in raw.items():
            suite[k] = {"status": "pass" if v else "fail", "metrics": {}}
        return suite
    # If raw is dict of dicts or mixed; try to detect "status"
    if isinstance(raw, dict):
        for k, v in raw.items():
            if isinstance(v, dict):
                status = v.get("status")
                if status not in ("pass", "fail", "error"):
                    # infer from boolean-like fields
                    if "ok" in v and isinstance(v["ok"], bool):
                        status = "pass" if v["ok"] else "fail"
                    else:
                        # If all nested are booleans and True -> pass
                        if all(isinstance(x, bool) for x in v.values()) and all(v.values()):
                            status = "pass"
                        elif any(isinstance(x, bool) for x in v.values()) and not all(v.values()):
                            status = "fail"
                        else:
                            status = "pass"
                suite[k] = {"status": status, "metrics": {kk: vv for kk, vv in v.items() if kk != "status"}}
            else:
                # primitive -> boolean metric
                suite[k] = {"status": "pass" if bool(v) else "fail", "metrics": {"value": v}}
        return suite
    # Fallback
    suite[name] = {"status": "pass", "metrics": {"raw": raw}}
    return suite

def main():
    ap = argparse.ArgumentParser(description="CQE Harness CLI")
    ap.add_argument("--json", action="store_true", help="Print JSON results to stdout")
    ap.add_argument("--suite", help="Comma-separated suite modules to run (overrides defaults)")
    ap.add_argument("--select", action="append", help="Repeatable. Specific dotted test module(s) to run.")
    ap.add_argument("--seed", type=int, help="Random seed for reproducibility")
    ap.add_argument("--param", action="append", help="Repeatable k=v overrides passed to tests")
    ap.add_argument("--out", help="Write JSON results to file")
    ap.add_argument("--fail-on", choices=["none","any","critical"], default="any", help="Exit code policy")
    args = ap.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    tests = DEFAULT_TESTS[:]
    if args.suite:
        tests = [s.strip() for s in args.suite.split(",") if s.strip()]
    if args.select:
        tests = args.select

    params = parse_kv(args.param)

    started = time.time()
    suites = {}
    failed = errors = passed = 0

    for modname in tests:
        key = modname.split(".")[-1]
        try:
            mod = importlib.import_module(modname)
            run = getattr(mod, "run", None)
            if run is None:
                raise RuntimeError(f"{modname} has no run()")
            # Support optional params
            try:
                raw = run(params=params)
            except TypeError:
                raw = run()
            suite = normalize_suite_output(key, raw)
            suites[key] = suite
            for tname, tres in suite.items():
                status = tres.get("status", "pass")
                if status == "pass":
                    passed += 1
                elif status == "fail":
                    failed += 1
                elif status == "error":
                    errors += 1
        except Exception as e:
            suites[key] = {"__suite__": {"status":"error","error": str(e), "traceback": traceback.format_exc()}}
            errors += 1

    payload = {
        "schema": "cqe-harness/1.0",
        "run_id": f"run-{int(started)}",
        "timestamp": started,
        "duration_ms": int((time.time()-started)*1000),
        "seed": args.seed,
        "platform": {"python": sys.version, "system": platform.platform()},
        "summary": {"passed": passed, "failed": failed, "errors": errors},
        "suites": suites
    }

    out = json.dumps(payload, indent=2)
    if args.out:
        with open(args.out, "w") as f:
            f.write(out)
    if args.json or not args.out:
        print(out)

    rc = 0
    if args.fail_on == "any" and (failed or errors):
        rc = 2
    elif args.fail_on == "critical":
        # mark tests as {"critical": true} inside test dicts to activate
        crit = False
        for s in suites.values():
            for t in (s.values() if isinstance(s, dict) else []):
                if isinstance(t, dict) and t.get("critical") and t.get("status") != "pass":
                    crit = True
                    break
            if crit: break
        rc = 2 if crit else 0
    sys.exit(rc)

if __name__ == "__main__":
    main()
