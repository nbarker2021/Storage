
from cqe_harness.adapters.quantum import bell_tile_flip_trial, decohere_parity
def run():
    S = bell_tile_flip_trial()
    series = decohere_parity()
    return {"CHSH_S": float(S), "decohere_len": int(len(series))}
