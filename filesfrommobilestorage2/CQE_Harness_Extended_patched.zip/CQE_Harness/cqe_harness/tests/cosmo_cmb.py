
from cqe_harness.adapters.cosmology import toy_cmb_ell_spectrum, flatness_from_ledger, baryon_asymmetry_sign, dark_sector_residue
def run():
    ell, Cl = toy_cmb_ell_spectrum()
    return {"has_spectrum": bool(len(ell)>0 and len(Cl)>0),
            "flatness_ok": bool(flatness_from_ledger()),
            "baryon_sign": int(baryon_asymmetry_sign(1)),
            "dark_residue": float(dark_sector_residue(0.25))}
