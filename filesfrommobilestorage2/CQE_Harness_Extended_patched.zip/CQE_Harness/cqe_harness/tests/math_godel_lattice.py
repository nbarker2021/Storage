
from cqe_harness.adapters.mathematics import godel_safe_closure, lattice_closure_rank
def run():
    safe = godel_safe_closure(axioms=10, contradictions=7)
    e8_ok = lattice_closure_rank(8)
    leech_ok = lattice_closure_rank(24)
    return {"godel_safe": bool(safe), "E8_admissible": bool(e8_ok), "Leech_admissible": bool(leech_ok)}
