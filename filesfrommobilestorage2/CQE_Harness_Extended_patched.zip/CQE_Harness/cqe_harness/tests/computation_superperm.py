
from cqe_harness.adapters.computation import superperm_embedding_exists, greedy_gate_count
def run():
    ex5 = superperm_embedding_exists(5)
    gates = greedy_gate_count(5)
    return {"embed_exists_n5": bool(ex5), "greedy_gates": int(gates)}
