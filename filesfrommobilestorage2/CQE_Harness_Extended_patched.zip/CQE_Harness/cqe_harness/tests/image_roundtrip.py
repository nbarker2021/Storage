import numpy as np
from cqe_harness.adapters.image_codec import encode_image, decode_image

def run():
    rng = np.random.default_rng(7)
    img = (rng.integers(0,2,size=(32,32))).astype(np.uint8)
    runs, meta = encode_image(img)
    rec = decode_image(runs, meta)
    ok = np.array_equal(img, rec)
    return {"image_roundtrip_ok": bool(ok), "compressed_runs": int(len(runs)), "pixels": int(img.size)}
