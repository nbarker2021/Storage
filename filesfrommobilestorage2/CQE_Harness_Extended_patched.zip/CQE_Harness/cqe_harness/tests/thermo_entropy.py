
from cqe_harness.adapters.thermo import scqe_entropy, delta_energy
def run():
    S = scqe_entropy(bits=256, contradictions=8)
    dE = delta_energy(actions=120, saved=35)
    return {"S_cqe": float(S), "delta_E": int(dE)}
