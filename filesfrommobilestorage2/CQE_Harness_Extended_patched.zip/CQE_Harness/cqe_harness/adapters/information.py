
import numpy as np

def cqe_compressibility_ratio(n_bits:int, structure:float)->float:
    """
    structure in [0,1]; 1=highly structured => better compression
    """
    structure = min(1.0, max(0.0, structure))
    # toy lower bound ratio
    return float(max(0.1, 1.0 - 0.6*structure))

def kolmogorov_hint(n_bits:int, motif_count:int)->int:
    # hint bits ~ log2(motif_count) + constants
    from math import log2
    mc = max(1, motif_count)
    return int(max(1, np.ceil(log2(mc))+4))
