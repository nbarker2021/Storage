
def godel_safe_closure(axioms:int, contradictions:int)->bool:
    # CQE: only closes finite contradiction sets under declared axioms
    return contradictions <= axioms

def lattice_closure_rank(rank:int)->bool:
    # toy: E8 and Leech are admissible closures
    return rank in (8,24)
