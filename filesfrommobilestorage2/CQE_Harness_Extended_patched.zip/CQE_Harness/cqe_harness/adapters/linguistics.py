
def canonical_parse_score(ambigs:int, constraints:int)->float:
    # higher constraints reduce ambiguity
    ambigs = max(0, ambigs)
    constraints = max(0, constraints)
    return float(1.0/(1.0 + ambigs) + 0.1*constraints)

def proto_merge_3(lang_a:str, lang_b:str, lang_c:str)->str:
    # toy: interleave heads as a proto codec token
    return f"[{lang_a[0]}-{lang_b[0]}-{lang_c[0]}]"
