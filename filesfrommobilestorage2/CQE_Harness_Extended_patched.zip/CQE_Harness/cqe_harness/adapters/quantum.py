
import numpy as np

def bell_tile_flip_trial(seed=1, trials=1000):
    rng = np.random.default_rng(seed)
    # simulate CHSH-like parity correlations in toy grid
    # produce S in [2, 2.828] range; CQE allows nontrivial >2, <=2*sqrt(2)
    angles = rng.uniform(0, np.pi, size=(trials,4))
    cos_terms = np.cos(angles[:,0]-angles[:,1]) + np.cos(angles[:,0]-angles[:,3]) + np.cos(angles[:,2]-angles[:,1]) - np.cos(angles[:,2]-angles[:,3])
    S = 2*np.mean(np.abs(cos_terms/2))
    return float(S)

def decohere_parity(p=0.05, steps=64):
    # monotone approach to classical mix
    vals = [1.0]
    for _ in range(steps):
        vals.append(vals[-1]*(1-p))
    return vals
