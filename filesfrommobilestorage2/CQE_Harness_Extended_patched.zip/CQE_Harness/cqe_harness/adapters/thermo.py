
import numpy as np

def scqe_entropy(bits:int, contradictions:int)->float:
    # simple: S = contradictions * log 2 scaled by occupancy
    p = min(1.0, max(0.0, contradictions/max(1,bits)))
    return float(- (p*np.log2(max(p,1e-12)) + (1-p)*np.log2(max(1-p,1e-12))))

def delta_energy(actions:int, saved:int)->int:
    # toy: used - saved
    return int(actions - saved)
