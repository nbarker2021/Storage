
# CQE Full Harness (Minimal, Runnable)

Pure-Python harness to exercise the CQE pipeline: glyphs → carriers → overlays → pal-rest → receipts → commit → ledger.
Run:
```
python -m harness.run_harness
python -m tests.run_tests
```

Outputs in `harness/out/`. Goldens in `harness/golden/`.
