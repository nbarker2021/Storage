
# Worksheet 00 — First CQE run

1) Choose a config in `harness/10why/why01_bits.json`.
2) Run: `python -m harness.run_harness`
3) Inspect: `harness/out/reports/toy_bits.json`
4) Verify: `python -m tests.run_tests`
