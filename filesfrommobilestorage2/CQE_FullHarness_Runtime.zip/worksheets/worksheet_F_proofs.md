
# Worksheet F — Proofs & Falsifiers

We assert:
F1: n=5 overlays produce 8 views and one best pal-choice.
F2: n=4 palindrome candidate is stable under reverse.
F3: Replay idempotence holds (commit stable).
F4: Invariance under mirror preserves P bit in pal case.
