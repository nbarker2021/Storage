
import json, os, glob, time
from pathlib import Path
from cqe_unified.carriers import Carrier
from cqe_unified.sim import eight_overlays, choose_pal_rest
from cqe_unified.receipts import receipts
from cqe_unified.ledger import append_commit
from cqe_unified.sidecars_brainwaves import eeg_bands
from cqe_unified.sidecars_arith import checksums

OUT = Path(__file__).parent/"out"/"reports"
LEDGER = Path(__file__).parent/"ledger"/"commits.jl"
GOLDEN = Path(__file__).parent/"golden"
CFGDIR = Path(__file__).parent/"10why"

def make_signal(fs, dur, alpha_hz, theta_hz, alpha_amp, theta_amp):
    import math
    N = int(fs*dur)
    sig = []
    for n in range(N):
        t = n/fs
        val = alpha_amp*math.sin(2*math.pi*alpha_hz*t) + theta_amp*math.sin(2*math.pi*theta_hz*t)
        sig.append(val)
    return sig

def run_one(cfg_path, prev=None):
    cfg = json.loads(Path(cfg_path).read_text())
    name = cfg["name"]
    report = {"config": Path(cfg_path).name, "name": name}

    if "bits" in cfg:
        car = Carrier.from_bits(cfg["bits"], suit=cfg.get("suit","S"))
    elif "signal" in cfg:
        s = cfg["signal"]
        sig = make_signal(**s)
        bands = eeg_bands(sig, fs=s["fs"])
        # derive bits from thresholding alpha/theta ratio
        alpha = bands.get("alpha",0.0)
        theta = bands.get("theta",0.0)
        ratio = (alpha+1e-9)/(theta+1e-9)
        bits = [1 if ratio > 1.0 else 0]*16
        car = Carrier.from_bits(bits, suit="H")
        report["bands"] = bands
    elif "blue_bits" in cfg and "red_bits" in cfg:
        blue = Carrier.from_bits(cfg["blue_bits"], suit="S")
        red  = Carrier.from_bits(cfg["red_bits"], suit="D")
        # riffle to model interaction
        car = blue.riffle_with(red)
    else:
        raise ValueError("Unknown config schema")

    overlays = eight_overlays(car)
    best_name, pal_view = choose_pal_rest(car)
    rcpts = receipts(car, pal_view, prev)
    report["overlays"] = list(overlays.keys())
    report["pal_choice"] = best_name
    report["receipts"] = rcpts

    # add simple checksums to payload face bits
    report["checksums"] = checksums(car.face_bits())

    OUT.mkdir(parents=True, exist_ok=True)
    out_path = OUT/(name + ".json")
    out_path.write_text(json.dumps(report, indent=2))

    # ledger
    append_commit(str(LEDGER), {"name": name, "commit": rcpts["commit"], "bits": rcpts["receipts"]["bits"] if "receipts" in rcpts else rcpts["bits"]})
    return report

def main(freeze_golden=False):
    prev = None
    reports = []
    for cfg in sorted(glob.glob(str(CFGDIR/"*.json"))):
        rep = run_one(cfg, prev)
        prev = Carrier.from_bits(rep["checksums"]["sum"].to_bytes(2, "little"), suit="C") if False else None
        reports.append(rep)

    # summary
    summary = {
        "count": len(reports),
        "names": [r["name"] for r in reports],
        "commits": [r["receipts"]["commit"] for r in reports]
    }
    (OUT/"summary.json").write_text(json.dumps(summary, indent=2))

    if freeze_golden:
        GOLDEN.mkdir(parents=True, exist_ok=True)
        for r in reports:
            (GOLDEN/(r["name"]+".root")).write_text(r["receipts"]["commit"])

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--freeze-golden", action="store_true")
    args = ap.parse_args()
    main(freeze_golden=args.freeze_golden)
