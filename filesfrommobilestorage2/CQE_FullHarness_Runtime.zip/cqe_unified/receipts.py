
from typing import Dict, Any
from .carriers import Carrier
from .utils import canonical_json, merkle_root

def receipts(car: Carrier, pal_view: Dict[str,Any], prev_car: Carrier=None) -> Dict[str, Any]:
    # Bits: P (palindrome?), M (mirror-invariant?), Δ (local change?), S (strict run-length decreased?),
    # L (ledgered: has merkle root)
    pal_car = Carrier.from_dict(pal_view)
    bits = {}
    # P
    bits["P"] = int(pal_car.face_bits() == list(reversed(pal_car.face_bits())))
    # M
    bits["M"] = int(pal_car.face_bits() == pal_car.mirror().face_bits())
    # Δ
    if prev_car:
        # local if Hamming distance <= 2 on faces
        before = prev_car.face_bits()
        after = pal_car.face_bits()
        hd = sum(1 for a,b in zip(before, after) if a!=b) + abs(len(before)-len(after))
        bits["Δ"] = int(hd <= 2)
        # S
        prev_run = prev_car.run_lengths()["suit"]
        cur_run = pal_car.run_lengths()["suit"]
        bits["S"] = int(cur_run <= prev_run)
    else:
        bits["Δ"] = 1
        bits["S"] = 1
    payload = {"pal_view": pal_view, "bits": bits}
    root = merkle_root([canonical_json(payload)])
    bits["L"] = 1
    return {"bits": bits, "commit": root}
