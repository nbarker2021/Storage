
from typing import List, Dict

def checksums(x: List[int]) -> Dict[str,int]:
    s = sum(x)
    xor = 0
    mn = 10**9
    mx = -10**9
    for v in x:
        xor ^= v
        mn = min(mn, v)
        mx = max(mx, v)
    return {"sum": s, "xor": xor, "min": mn, "max": mx}
