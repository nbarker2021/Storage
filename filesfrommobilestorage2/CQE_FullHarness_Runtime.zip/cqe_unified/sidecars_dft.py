
import cmath, math
from typing import List, Dict

def dft(signal: List[float]) -> List[complex]:
    N = len(signal)
    out = []
    for k in range(N):
        s = 0j
        for n in range(N):
            angle = -2j*math.pi*k*n/N
            s += signal[n]*cmath.exp(angle)
        out.append(s)
    return out

def band_power_dft(signal: List[float], bands: Dict[str, tuple], fs: float) -> Dict[str,float]:
    # naive DFT power estimate
    N = len(signal)
    X = dft(signal)
    freqs = [fs*k/N for k in range(N)]
    power = {}
    for name, (f0,f1) in bands.items():
        p = 0.0
        for k, Xk in enumerate(X):
            f = freqs[k]
            if f0 <= f <= f1:
                p += (abs(Xk)**2)/N
        power[name] = p
    return power
