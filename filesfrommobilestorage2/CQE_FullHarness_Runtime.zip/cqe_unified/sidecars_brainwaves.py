
from typing import List, Dict
from .sidecars_dft import band_power_dft

BANDS = {
    "delta": (0.5,4),
    "theta": (4,8),
    "alpha": (8,12),
    "beta": (12,30),
    "gamma": (30,80),
}

def eeg_bands(signal: List[float], fs: float=256.0) -> Dict[str,float]:
    return band_power_dft(signal, BANDS, fs)
