
from dataclasses import dataclass
from typing import List, Dict, Any

SUITS = ["C","S","D","H"]  # clubs, spades, diamonds, hearts
RANKS = ["A","2","3","4","5","6","7","8","9","T","J","Q","K"]

@dataclass
class Card:
    rank: str   # "A","2",...,"K"
    suit: str   # "C","S","D","H"
    face: int   # 1 = up, 0 = down

    def bit(self) -> int:
        return 1 if self.face else 0

    def to_dict(self) -> Dict[str, Any]:
        return {"r": self.rank, "s": self.suit, "f": self.face}

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Card":
        return Card(d["r"], d["s"], d["f"])

class Carrier:
    def __init__(self, seq: List[Card]):
        self.seq = list(seq)

    @staticmethod
    def from_bits(bits: List[int], suit="S", rank_cycle=None) -> "Carrier":
        rank_cycle = rank_cycle or RANKS
        seq = []
        for i,b in enumerate(bits):
            seq.append(Card(rank_cycle[i % len(rank_cycle)], suit, 1 if b else 0))
        return Carrier(seq)

    def reverse(self) -> "Carrier":
        return Carrier(list(reversed(self.seq)))

    def mirror(self) -> "Carrier":
        # swap red/black suits (C,S) <-> (D,H), flip faces
        swap = {"C":"D","S":"H","D":"C","H":"S"}
        return Carrier([Card(c.rank, swap[c.suit], 1-c.face) for c in self.seq])

    def riffle_with(self, other: "Carrier") -> "Carrier":
        out = []
        a, b = self.seq, other.seq
        for i in range(max(len(a),len(b))):
            if i < len(a): out.append(a[i])
            if i < len(b): out.append(b[i])
        return Carrier(out)

    def run_lengths(self) -> Dict[str,int]:
        # longest run of identical faces and identical suits
        if not self.seq: return {"face":0,"suit":0}
        max_face = max_suit = 1
        cf = cs = 1
        for i in range(1, len(self.seq)):
            if self.seq[i].face == self.seq[i-1].face:
                cf += 1
                max_face = max(max_face, cf)
            else:
                cf = 1
            if self.seq[i].suit == self.seq[i-1].suit:
                cs += 1
                max_suit = max(max_suit, cs)
            else:
                cs = 1
        return {"face": max_face, "suit": max_suit}

    def to_dict(self) -> Dict[str, Any]:
        return {"seq":[c.to_dict() for c in self.seq]}

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Carrier":
        return Carrier([Card.from_dict(x) for x in d["seq"]])

    def face_bits(self) -> List[int]:
        return [c.face for c in self.seq]

    def suit_string(self) -> str:
        return "".join([c.suit for c in self.seq])
