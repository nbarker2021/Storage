
from typing import Dict, Any, List, Tuple
from .carriers import Carrier

def eight_overlays(car: Carrier) -> Dict[str, Dict[str, Any]]:
    # Produce 8 "views": identity, reverse, mirror, mirror+reverse,
    # position mod 2 mask, suit parity swap, top-half, bottom-half.
    views = {}
    seq = car.seq
    views["id"] = car.to_dict()
    views["rev"] = car.reverse().to_dict()
    views["mir"] = car.mirror().to_dict()
    views["mir_rev"] = car.mirror().reverse().to_dict()

    # mod2 mask: flip faces on even positions
    mod2 = Carrier([c for c in seq])
    for i, c in enumerate(mod2.seq):
        if i % 2 == 0:
            mod2.seq[i].face = 1 - c.face
    views["mod2flip"] = mod2.to_dict()

    # suit parity swap: swap C<->S and D<->H
    swap = {"C":"S","S":"C","D":"H","H":"D"}
    sp = Carrier([type(seq[0])(c.rank, swap[c.suit], c.face) for c in seq])
    views["suit_swap"] = sp.to_dict()

    half = len(seq)//2
    top = Carrier(seq[:half])
    bot = Carrier(seq[half:])
    views["top"] = top.to_dict()
    views["bottom"] = bot.to_dict()
    return views

def palindromic_score(bits: List[int]) -> int:
    # Hamming distance to its reverse
    n = len(bits)
    return sum(1 for i in range(n) if bits[i] != bits[n-1-i])

def choose_pal_rest(car: Carrier) -> Tuple[str, Dict[str, Any]]:
    overlays = eight_overlays(car)
    best = None
    best_name = None
    for name, view in overlays.items():
        c = Carrier.from_dict(view)
        score = palindromic_score(c.face_bits())
        # tie-breaker: shorter max run of suits
        rls = c.run_lengths()["suit"]
        val = (score, rls)
        if best is None or val < best:
            best = val
            best_name = name
    return best_name, overlays[best_name]
