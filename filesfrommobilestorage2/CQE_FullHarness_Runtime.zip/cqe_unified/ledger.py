
import time, json, os
from pathlib import Path

def append_commit(path: str, entry):
    Path(os.path.dirname(path)).mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps({"ts": time.time(), **entry}) + "\n")
