
from dataclasses import dataclass
from typing import Optional, Dict

@dataclass
class Glyph:
    observed: str
    declared: Optional[str] = None
    inferred: Optional[str] = None

    def resolved(self) -> str:
        # Observed label always trumps assumed/inferred
        return self.observed or self.declared or self.inferred or ""

class GlyphTable:
    def __init__(self):
        self._table: Dict[str, Glyph] = {}

    def upsert(self, key: str, observed: Optional[str]=None, declared: Optional[str]=None, inferred: Optional[str]=None):
        g = self._table.get(key, Glyph(observed or "", declared, inferred))
        if observed is not None:
            g.observed = observed
        if declared is not None:
            g.declared = declared
        if inferred is not None:
            g.inferred = inferred
        self._table[key] = g

    def resolved_map(self) -> Dict[str, str]:
        return {k: v.resolved() for k,v in self._table.items()}
