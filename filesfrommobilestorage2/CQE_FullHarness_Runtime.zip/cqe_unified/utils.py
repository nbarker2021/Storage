
import json, hashlib

def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",",":"))

def merkle_root(chunks):
    # simple merkle: hash leaves with sha256, pairwise up, duplicate last if odd
    if not chunks:
        return sha256_hex(b"")
    layer = [sha256_hex(c.encode() if isinstance(c, str) else c) for c in chunks]
    while len(layer) > 1:
        next_layer = []
        for i in range(0, len(layer), 2):
            if i+1 < len(layer):
                pair = (layer[i] + layer[i+1]).encode()
            else:
                pair = (layer[i] + layer[i]).encode()
            next_layer.append(sha256_hex(pair))
        layer = next_layer
    return layer[0]

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
