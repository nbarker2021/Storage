
from pathlib import Path
import json, sys

BASE = Path(__file__).parents[1]
OUT = BASE/"harness/out/reports"
GOLDEN = BASE/"harness/golden"

def iter_reports():
    for rpt in OUT.glob("*.json"):
        if rpt.name == "summary.json":
            continue
        yield rpt

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    GOLDEN.mkdir(parents=True, exist_ok=True)
    have_golden = any(GOLDEN.glob("*.root"))
    if not have_golden:
        print("[warn] No golden roots found; creating from current reports.")
        for rpt in iter_reports():
            data = json.loads(rpt.read_text())
            (GOLDEN/(data["name"]+".root")).write_text(data["receipts"]["commit"])

    ok = True
    for rpt in iter_reports():
        data = json.loads(rpt.read_text())
        gpath = GOLDEN/(data["name"]+".root")
        if not gpath.exists():
            print(f"[FAIL] Missing golden for {data['name']}")
            ok = False
            continue
        golden = gpath.read_text().strip()
        new = data["receipts"]["commit"]
        if golden != new:
            print(f"[FAIL] Commit mismatch for {data['name']}")
            print("  golden:", golden)
            print("    new:", new)
            ok = False
        else:
            print(f"[OK] {data['name']}")
    if not ok:
        sys.exit(1)
    print("OK — all goldens matched.")

if __name__ == "__main__":
    main()
