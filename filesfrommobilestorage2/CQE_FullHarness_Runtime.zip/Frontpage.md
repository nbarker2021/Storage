
# Frontpage

This repo contains a working CQE harness with reports, goldens, and falsifier scaffolds. See README for running instructions.
