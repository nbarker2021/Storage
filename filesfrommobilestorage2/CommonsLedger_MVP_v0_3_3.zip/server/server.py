\
import os, json, time, hashlib, random
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
from typing import Dict, Any, List

ROOT = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.abspath(os.path.join(ROOT, ".."))
DATA = os.path.join(BASE, "data")

import sys, yaml
sys.path.append(os.path.join(BASE,"sidecar_adapters"))
from sidecar_adapters.speedlight_router import Ledger, MintEngine, get_adapter_status

with open(os.path.join(BASE,"config","policy.yaml"),"r") as f:
    policy = yaml.safe_load(f)

ledger = Ledger(DATA)
engine = MintEngine(policy, ledger)

# In-memory lab sessions
LABS = {}

def read_json(req: BaseHTTPRequestHandler) -> Dict[str,Any]:
    length = int(req.headers.get("Content-Length","0") or "0")
    body = req.rfile.read(length) if length else b"{}"
    try:
        return json.loads(body.decode("utf-8"))
    except Exception:
        return {}

def respond(res: BaseHTTPRequestHandler, code: int, obj: Dict[str,Any]):
    b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    res.send_response(code)
    res.send_header("Content-Type","application/json; charset=utf-8")
    res.send_header("Content-Length", str(len(b)))
    res.end_headers()
    res.wfile.write(b)

def seed_grid_from_text(w: int, h: int, text: str):
    grid = [[0]*w for _ in range(h)]
    bits = hashlib.sha256((text or " ").encode("utf-8")).digest()
    idx = 0
    for y in range(h):
        for x in range(w):
            b = bits[idx % len(bits)]
            grid[y][x] = 1 if (b & (1 << (x % 8))) else 0
            idx += 1
    return grid

def step_life(grid):
    h, w = len(grid), len(grid[0])
    nxt = [[0]*w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            s = 0
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    if dy==0 and dx==0: continue
                    yy, xx = (y+dy)%h, (x+dx)%w
                    s += grid[yy][xx]
            alive = grid[y][x]==1
            if alive and (s==2 or s==3): nxt[y][x]=1
            elif not alive and s==3: nxt[y][x]=1
            else: nxt[y][x]=0
    return nxt

def short_id(prefix: str, payload: Dict[str,Any]) -> str:
    h = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()[:10]
    return f"{prefix}{h}"

def inv_path(actor_id: str) -> str:
    return os.path.join(DATA, "inventory", f"{actor_id}.json")

def ensure_inventory(actor_id: str) -> Dict[str,Any]:
    p = inv_path(actor_id)
    if os.path.exists(p):
        return json.load(open(p))
    inv = {"actor_id":actor_id,
           "journals":3, "subjournals":9,
           "decks":{"invariant":24,"hypothesis":12},
           "credits":{"MERIT":0,"CARETAKER":0,"AEGIS":0,"INFRA":0,"GAIA":0,"VANGOGH":0,"MYTHOS":0,"DAVINCI":0,"THETA":0,"ORBIT":0}}
    os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump(inv, open(p,"w"))
    return inv

def save_inventory(inv: Dict[str,Any]):
    json.dump(inv, open(inv_path(inv["actor_id"]), "w"))

class App(BaseHTTPRequestHandler):
    def do_POST(self):
        p = urlparse(self.path).path

        if p == "/submit":
            obj = read_json(self)
            if not obj.get("actor_id") or not obj.get("domain_claims"):
                return respond(self, 400, {"error":"missing actor_id or domain_claims"})
            rid_raw = short_id("C", obj)
            ledger.append({"type":"contribution","rid":rid_raw,"obj":obj,"ts":time.time()})
            rid, minted = engine.mint(obj)
            inv = ensure_inventory(obj["actor_id"])
            for k,v in minted.items():
                inv["credits"][k] = round(inv["credits"].get(k,0)+float(v),6)
            save_inventory(inv)
            return respond(self, 200, {"receipt_id":rid, "minted":minted})

        elif p == "/metrics/mint_preview":
            obj = read_json(self)
            return respond(self, 200, engine.preview(obj))

        elif p == "/settle":
            obj = read_json(self)
            if "revenue_fiat" not in obj or "patterns" not in obj:
                return respond(self, 400, {"error":"missing revenue_fiat or patterns"})
            engine.settle_paid_service(obj)
            return respond(self, 200, {"status":"ok"})

        elif p == "/payout_wallet":
            data = json.load(open(os.path.join(DATA,"payout_wallet.json")))
            return respond(self, 200, data)

        elif p == "/policy/get":
            return respond(self, 200, policy)

        elif p == "/policy/set":
            obj = read_json(self)
            # minimal: allow updating domain scales and payout fraction
            if "domains" in obj: policy["domains"] = obj["domains"]
            if "payout_split" in obj: policy["payout_split"] = obj["payout_split"]
            with open(os.path.join(BASE,"config","policy.yaml"),"w") as f:
                import yaml
                yaml.safe_dump(policy, f)
            return respond(self, 200, {"status":"ok","policy":policy})

        elif p == "/inventory/get":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            inv = ensure_inventory(actor)
            return respond(self, 200, inv)

        elif p == "/upload":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            fn = obj.get("filename","untitled.txt")
            content = obj.get("content","")
            pid = short_id("P", {"a":actor,"fn":fn,"c":content[:200]})
            rec = {"paper_id":pid,"actor_id":actor,"filename":fn,"content":content,"tokens":[],"ts":time.time()}
            # Tokenize using optional geotokenizer to align with morphonic stack
            from sidecar_adapters.optional_adapters import geotokenize
            rec["tokens"] = geotokenize(content)
            os.makedirs(os.path.join(DATA,"uploads"), exist_ok=True)
            json.dump(rec, open(os.path.join(DATA,"uploads", f"{pid}.json"),"w"))
            ledger.append({"type":"upload","paper_id":pid,"actor":actor,"ts":time.time()})
            return respond(self, 200, {"paper_id":pid,"token_count":len(rec["tokens"])})

        elif p == "/tiles/init":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            papers, drafts = [], []
            updir = os.path.join(DATA,"uploads")
            if os.path.isdir(updir):
                for name in os.listdir(updir):
                    rec = json.load(open(os.path.join(updir,name)))
                    if rec.get("actor_id")==actor:
                        papers.append({"paper_id":rec["paper_id"],"title":rec["filename"],"snippet":rec["content"][:160]})
            drdir = os.path.join(DATA,"drafts")
            if os.path.isdir(drdir):
                for name in os.listdir(drdir):
                    dr = json.load(open(os.path.join(drdir,name)))
                    if dr.get("actor_id")==actor:
                        drafts.append({"draft_id":dr["draft_id"],"title":dr["title"],"summary":dr["summary"]})
            inv = ensure_inventory(actor)
            return respond(self, 200, {"papers":papers, "drafts":drafts, "inventory":inv})

        elif p == "/tiles/combine":
            obj = read_json(self)
            actor = obj.get("actor_id","anon")
            inputs = obj.get("inputs",[])
            inv = ensure_inventory(actor)
            if inv["journals"] <= 0:
                return respond(self, 400, {"error":"no journals available"})
            recs = []
            for pid in inputs:
                path = os.path.join(DATA,"uploads", f"{pid}.json")
                if os.path.exists(path):
                    recs.append(json.load(open(path)))
            if len(recs) < 2:
                return respond(self, 400, {"error":"need at least two papers"})
            common = set(recs[0]["tokens"])
            for r in recs[1:]:
                common &= set(r["tokens"])
            common_terms = sorted(list(common))[:24]
            title = "Synthesis: " + (" ".join(common_terms[:6]) or "New Draft")
            summary = "Links: " + ", ".join([r["filename"] for r in recs])
            draft = {"draft_id": short_id("D", {"a":actor,"ins":inputs,"t":title}),
                     "actor_id":actor,
                     "title":title,
                     "summary":summary,
                     "inputs":inputs,
                     "suggested_terms":common_terms,
                     "created":time.time()}
            os.makedirs(os.path.join(DATA,"drafts"), exist_ok=True)
            json.dump(draft, open(os.path.join(DATA,"drafts", f"{draft['draft_id']}.json"), "w"))
            inv["journals"] -= 1
            inv["subjournals"] = max(0, inv["subjournals"]-1)
            save_inventory(inv)
            ledger.append({"type":"combine","actor":actor,"inputs":inputs,"draft_id":draft["draft_id"],"ts":time.time()})
            return respond(self, 200, {"draft":draft, "inventory":inv})

        elif p == "/lab/run":
            obj = read_json(self)
            did = obj.get("draft_id")
            size = int(obj.get("size", 24))
            path = os.path.join(DATA,"drafts", f"{did}.json")
            if not os.path.exists(path):
                return respond(self, 404, {"error":"draft not found"})
            dr = json.load(open(path))
            text = dr["title"] + " " + " ".join(dr.get("suggested_terms",[])) + " " + dr.get("summary","")
            grid = seed_grid_from_text(size, size, text)
            sid = short_id("LAB", {"d":did, "t":time.time()})
            LABS[sid] = {"grid":grid,"draft_id":did,"tick":0, "passes":0, "trials":0}
            ledger.append({"type":"lab_start","draft_id":did,"session_id":sid,"ts":time.time()})
            return respond(self, 200, {"session_id":sid, "grid":grid, "tick":0})

        elif p == "/lab/step":
            obj = read_json(self)
            sid = obj.get("session_id")
            sess = LABS.get(sid)
            if not sess:
                return respond(self, 404, {"error":"session not found"})
            sess["grid"] = step_life(sess["grid"])
            sess["tick"] += 1
            return respond(self, 200, {"session_id":sid, "grid":sess["grid"], "tick":sess["tick"]})

        elif p == "/lab/record":
            # record a pass/fail for the current lab; reflected in mint previews that include 'lab' evidence
            obj = read_json(self)
            sid = obj.get("session_id")
            passed = bool(obj.get("passed", False))
            sess = LABS.get(sid)
            if not sess:
                return respond(self, 404, {"error":"session not found"})
            sess["trials"] += 1
            if passed: sess["passes"] += 1
            ledger.append({"type":"lab_result","session_id":sid,"passed":passed,"ts":time.time()})
            return respond(self, 200, {"status":"ok", "trials":sess["trials"], "passes":sess["passes"]})

        else:
            return respond(self, 404, {"error":"unknown endpoint"})

def run():
    host, port = "127.0.0.1", 8787
    print(f"CommonsLedger MVP v0.3 running at http://{host}:{port}")
    HTTPServer((host, port), App).serve_forever()

if __name__ == "__main__":
    run()


def load_json_file(path, default):
    try:
        if os.path.exists(path):
            return json.load(open(path,"r",encoding="utf-8"))
    except Exception:
        pass
    return default

def save_json_file(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path,"w",encoding="utf-8"), indent=2)
