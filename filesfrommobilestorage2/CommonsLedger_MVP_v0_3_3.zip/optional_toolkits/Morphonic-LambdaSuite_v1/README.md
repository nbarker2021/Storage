# Morphonic Lambda Suite v1

See docs/MGLC_Spec_v1.0.md for the formal spec.