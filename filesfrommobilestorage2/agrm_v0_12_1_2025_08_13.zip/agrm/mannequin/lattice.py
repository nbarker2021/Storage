
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Iterator
import math, json, time
from pathlib import Path

from ..archivist.archivist_v0_1_2025_08_13 import Repository
from ..universe.universe_manager_v0_1_2025_08_13 import UniverseManager
from ..sap.sap_v0_1_2025_08_13 import Sentinel, Arbiter, Porter, SAPEvent

PHI = (1 + 5**0.5)/2

DORMANT = "dormant"
WARM    = "warm"
ACTIVE  = "active_slice"

@dataclass
class SliceHandle:
    key: str
    nodes: List[Dict[str, Any]]           # materialized node metas
    coords: List[Tuple[float,...]]        # 8D lattice coords (placeholder mapping)
    edges: List[Tuple[int,int]]           # local adjacency list (indices into nodes)
    budget_used: int
    criteria: Dict[str, Any]

class SliceStream:
    """Wave-by-wave slice streamer with SAP gates and Porter custody."""
    def __init__(self, mannequin: "LatticeMannequinV2", all_nodes: List[Dict[str,Any]], criteria: Dict[str,Any], wave_size:int):
        self.m = mannequin
        self.criteria = criteria
        self.all_nodes = all_nodes
        self.wave_size = max(1, int(wave_size))
        self.offset = 0
        self.total = len(all_nodes)

    def __iter__(self) -> Iterator[SliceHandle]:
        return self

    def __next__(self) -> SliceHandle:
        if self.offset >= self.total:
            raise StopIteration
        end = min(self.total, self.offset + self.wave_size)
        chunk = self.all_nodes[self.offset:end]
        coords = [self.m._to_e8(m) for m in chunk]
        edges = self.m._adj_for_slice(coords, k=self.m.k_neighbors)
        key = f"{self.m.universe_name}:{len(chunk)}:{int(time.time())}:{self.offset}"
        sh = SliceHandle(key=key, nodes=chunk, coords=coords, edges=edges, budget_used=len(chunk), criteria=self.criteria)

        # Porter custody (record carrying event)
        self.m.porter.carry({"slice_key": key, "count": len(chunk)}, meta={"universe": self.m.universe_name, "offset": self.offset})

        self.offset = end
        return sh

class LatticeMannequinV2:
    """
    Toggleable, SAP-gated mannequin with budgets and wave streaming.
    """
    def __init__(self, universe_name: str, *, repo_root: str, registry_root: str,
                 max_nodes:int=5000, max_edges:int=20000, k_neighbors:int=4):
        self.universe_name = universe_name
        self.repo_root = repo_root
        self.registry_root = registry_root
        self.um = UniverseManager(repo_root, registry_root)
        self.repo = Repository(repo_root)
        self.state = DORMANT
        self.manifest_path = Path(registry_root) / f"{universe_name}.manifest.json"
        self.manifest: Dict[str, Any] = {}
        self.active: Optional[SliceHandle] = None

        # Budgets / adjacency
        self.max_nodes = int(max_nodes)
        self.max_edges = int(max_edges)
        self.k_neighbors = int(k_neighbors)

        # SAP subsystem
        self.sentinel = Sentinel()
        self.arbiter  = Arbiter()
        self.porter   = Porter(io_allowed=True)
        # Example rule: deny if requested predicted nodes would exceed budget by > 25%
        def rule_budget(ev: SAPEvent):
            if ev.type=="slice_request":
                pred = int(ev.payload.get("predicted_nodes", 0))
                if pred > int(self.max_nodes * 1.25):
                    from types import SimpleNamespace
                    return SimpleNamespace(allow=False, reason=f"predicted_nodes {pred} exceeds max {self.max_nodes} by >25%", actions=["deny"])
            return None
        self.sentinel.register_rule(rule_budget)
        # Policy rule: enforce universe policies (family/type allow/deny, safe_cube requirement)
        def rule_policy(ev: SAPEvent):
            if ev.type != 'slice_request':
                return None
            # fetch universe policies
            try:
                u = self.um.get_universe(self.universe_name)
                pol = u.spec.policies or {}
            except Exception:
                pol = {}
            fam_allow = set(pol.get('family_allow', []))
            fam_deny  = set(pol.get('family_deny', []))
            typ_allow = set(pol.get('type_allow', []))
            typ_deny  = set(pol.get('type_deny', []))
            safe_cube = bool(pol.get('safe_cube', False))
            crit = ev.payload.get('criteria', {})
            fam = set(crit.get('family', [])) if crit.get('family') else set()
            typ = set(crit.get('type', [])) if crit.get('type') else set()
            # deny if any requested family in deny; or if allow list exists and request not subset
            if fam_deny and fam.intersection(fam_deny):
                from types import SimpleNamespace
                return SimpleNamespace(allow=False, reason='family_denied', actions=['deny'])
            if fam_allow and fam and not fam.issubset(fam_allow):
                from types import SimpleNamespace
                return SimpleNamespace(allow=False, reason='family_not_allowed', actions=['deny'])
            if typ_deny and typ.intersection(typ_deny):
                from types import SimpleNamespace
                return SimpleNamespace(allow=False, reason='type_denied', actions=['deny'])
            if typ_allow and typ and not typ.issubset(typ_allow):
                from types import SimpleNamespace
                return SimpleNamespace(allow=False, reason='type_not_allowed', actions=['deny'])
            # if safe_cube requested, require tags constraints in criteria (minimal proxy)
            if safe_cube and not crit.get('tags'):
                from types import SimpleNamespace
                return SimpleNamespace(allow=False, reason='safe_cube_requires_tags', actions=['deny'])
            return None
        self.sentinel.register_rule(rule_policy)

    # --- Manifest ---
    def build_manifest(self, force: bool=False) -> Dict[str, Any]:
        if self.manifest_path.exists() and not force:
            self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
            return self.manifest
        comp = self.um.compose(self.universe_name)
        metas = comp.get("metas", [])
        brief = []
        for m in metas:
            brief.append({
                "snap_id": m.get("snap_id", ""),
                "family":  m.get("family", ""),
                "type":    m.get("type", ""),
                "tags":    m.get("tags", {}),
                "created_ts": m.get("created_ts", 0.0),
            })
        self.manifest = {"universe": self.universe_name, "count": len(brief), "metas": brief}
        self.manifest_path.write_text(json.dumps(self.manifest, indent=2), encoding="utf-8")
        return self.manifest

    def toggle(self, on: bool):
        if on:
            if not self.manifest:
                self.build_manifest(force=False)
            self.state = WARM
        else:
            self.state = DORMANT
            self.active = None

    # --- Deterministic placeholder 8D embedding ---
    def _to_e8(self, meta: Dict[str, Any]) -> Tuple[float,...]:
        t = meta.get("tags", {})
        f = meta.get("family", "na")
        ty = meta.get("type", "na")
        s = float(t.get("score", t.get("snap_score", 0.0)))
        age = max(0.0, (time.time() - float(meta.get("created_ts", 0.0))) / (3600*24)) if meta.get("created_ts") else 0.0
        return (
            (hash(f) % 997) / 997.0,
            (hash(ty) % 991) / 991.0,
            math.tanh(s),
            1.0 / (1.0 + age),
            math.sin(PHI * (s+0.1)),
            math.cos(PHI * (s+0.2)),
            (s % 1.0),
            (age % 7.0)/7.0
        )

    def _adj_for_slice(self, coords: List[Tuple[float,...]], k: int=4) -> List[Tuple[int,int]]:
        import numpy as np
        if not coords:
            return []
        X = np.array(coords, dtype=float)
        edges = set()
        for i in range(X.shape[0]):
            d = np.linalg.norm(X - X[i], axis=1)
            nn = np.argsort(d)[1:min(k+1, X.shape[0])]
            for j in nn:
                a,b = (i,int(j)) if i<int(j) else (int(j),i)
                edges.add((a,b))
        return sorted(edges)

    # --- Filter and rank metas by criteria ---
    def _filter_rank(self, criteria: Dict[str, Any]) -> List[Dict[str,Any]]:
        metas = self.manifest.get("metas", [])
        filt = []
        fam = criteria.get("family"); typ = criteria.get("type"); tag = criteria.get("tags", {})
        for m in metas:
            ok = True
            if fam and m.get("family") not in fam: ok=False
            if typ and m.get("type") not in typ: ok=False
            for k,v in tag.items():
                if k.endswith("_gt"):
                    key=k[:-3]; ok = ok and (m.get("tags",{}).get(key,-1) > v)
                elif k.endswith("_lt"):
                    key=k[:-3]; ok = ok and (m.get("tags",{}).get(key,1e9) < v)
                else:
                    ok = ok and (m.get("tags",{}).get(k) == v)
            if ok: filt.append(m)
        # Sort: score/snap_score desc, then recency
        filt.sort(key=lambda m:(-float(m.get("tags",{}).get("score", m.get("tags",{}).get("snap_score",0.0))), -float(m.get("created_ts",0.0))))
        return filt

    # --- Predict resource footprint of a slice request ---
    def _predict_cost(self, count:int) -> Dict[str,int]:
        # naive edge estimate: ~ k_neighbors * n / 2 (undirected)
        e = max(0, int(self.k_neighbors * max(0,count) / 2))
        return {"nodes": int(count), "edges": e}

    # --- SAP-gated activation: stream waves within budgets ---
    def activate_stream(self, criteria: Dict[str, Any], *, wave_size:int=128, max_nodes:int=None) -> Tuple[Optional[SliceStream], Dict[str,Any]]:
        assert self.state != DORMANT, "Toggle on (WARM) before slicing."
        candidates = self._filter_rank(criteria)
        if not candidates:
            return None, {"allow": True, "reason": "no_matches", "predicted_nodes": 0}

        # Predict and SAP gate
        predicted = min(len(candidates), max_nodes if max_nodes is not None else len(candidates))
        ev = SAPEvent(type="slice_request", payload={"predicted_nodes": predicted, "criteria": criteria})
        verdict = self.sentinel.evaluate(ev)
        allow = bool(getattr(verdict, "allow", True))
        reason = getattr(verdict, "reason", "ok")

        if not allow:
            return None, {"allow": False, "reason": reason, "predicted_nodes": predicted}

        # Enforce budget locally
        budget_nodes = min(predicted, self.max_nodes)
        stream = SliceStream(self, candidates[:budget_nodes], criteria, wave_size=wave_size)
        self.state = ACTIVE
        return stream, {"allow": True, "reason": reason, "predicted_nodes": predicted, "budget_nodes": budget_nodes}
