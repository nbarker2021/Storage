
import argparse, json
from ..config.schema import AGRMConfig
from ..mannequin.lattice import LatticeMannequinV2 as Mannequin

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--universe", required=True)
    ap.add_argument("--repo_root", default="/mnt/data/repository_store_v0_1_2025_08_13")
    ap.add_argument("--reg_root", default="/mnt/data/universe_registry_v0_1_2025_08_13")
    ap.add_argument("--wave_size", type=int, default=64)
    args = ap.parse_args()

    m = Mannequin(args.universe, repo_root=args.repo_root, registry_root=args.reg_root)
    m.build_manifest(); m.toggle(on=True)
    stream, gate = m.activate_stream(criteria={"tags":{}}, wave_size=args.wave_size)
    print(json.dumps({"gate": gate, "has_stream": stream is not None}, indent=2))

if __name__ == "__main__":
    main()
