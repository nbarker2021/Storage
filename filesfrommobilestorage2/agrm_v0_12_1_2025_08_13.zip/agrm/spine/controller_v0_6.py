
import numpy as np
from .statebus_v0_4_2025_08_13 import StateBus_v0_4_2025_08_13 as Bus
from .navigator_v0_4_2025_08_13 import NavigatorGR_v0_4_2025_08_13 as Nav
from .vws_bridge_v0_1_2025_08_13 import seed_vws_from_mdhg_v0_1_2025_08_13 as seed
from .mdhg_v0_2_2025_08_13 import MDHG_v0_2_2025_08_13 as MDHG
from .inlinehash_v0_3_2025_08_13 import InlineHasher_v0_3_2025_08_13 as InlineH
from .vws_bridge_inline_v0_3_2025_08_13 import seed_vws_from_inline_v0_3_2025_08_13 as seed_inline
from .dualwrite_v0_1_2025_08_13 import DualWriteQueue_v0_1_2025_08_13 as Dual
from .dualwrite_journal_v0_1_2025_08_13 import DualWriteJournal_v0_1_2025_08_13 as DWJ
from ..snap.snap_v0_1_2025_08_13 import create_snap
from ..sfbb.plugin_loader_v0_1_2025_08_13 import load_plugin_from_path
from .patch_policy_v0_1_2025_08_13 import PatchPolicy_v0_1_2025_08_13
from .promotion_guard_v0_1_2025_08_13 import adjust_sampling_cfg
from ..mdhg.vws_bridge_v0_2_2025_08_13 import seed_vws_from_mdhg as seed_vws_new
from ..mdhg.adjacency_v0_1_2025_08_13 import build_adjacency, build_elevators
class AGRMController_v0_6_2025_08_13:
    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        # optional SFBB plugin
        self._sfbb_policy = None
        try:
            p = self.cfg.get('sfbb_plugin_path')
            if p:
                mod = load_plugin_from_path(p)
                scorer = getattr(mod, 'EdgeScoreProviderImpl', None)
                scorer = scorer() if scorer else None
                self._sfbb_policy = PatchPolicy_v0_1_2025_08_13(scorer=scorer)
        except Exception:
            self._sfbb_policy = None
        self.bus = Bus()
        if self.cfg.get('prior_profile_path'):
            try:
                import json
                with open(self.cfg['prior_profile_path'],'r',encoding='utf-8') as f:
                    prof = json.load(f)
                self.bus.stats['prior_family'] = prof.get('family')
                self.bus.stats['prior_loaded'] = True
            except Exception:
                self.bus.stats['prior_loaded'] = False
        self.navigator = Nav(self.cfg, self.bus)
        self.dual = Dual()
        self.journal = DWJ(dir_path=self.cfg.get('journal_dir','snapshots/journal'))
        self.mdhg = None
        self.inline = None
    
    def _seed_vws(self, points):
        # choose bridge version: new mdhg v0_2 when requested; else fall back to legacy import 'seed'
        strategy = self.cfg.get("seeding_strategy", "grid")
        force_grid = bool(self.cfg.get("vws_force_grid", True))
        N_guard = int(self.cfg.get("vws_N_guard", 4000))
        grid_k = int(self.cfg.get("vws_grid_k", 4))
        grid_radius = int(self.cfg.get("vws_grid_radius", 1))
        try_new = bool(self.cfg.get("use_new_vws_bridge", True))
        if try_new:
            res = seed_vws_new(points, strategy=strategy, grid_size=self.cfg.get("vws_grid_size",64),
                               force_grid=force_grid, N_guard=N_guard, journal=None)
            return res
        else:
            return seed(self.mdhg, points, build_k=grid_k, grid_radius=grid_radius)
def _build_mdhg(self, points):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        m = MDHG(dim=points.shape[1], decay_lambda=self.cfg.get("mdhg_decay", 0.01))
        n = points.shape[0]
        center = points.mean(axis=0); vecs = points - center
        angles = _np.arctan2(vecs[:,1], vecs[:,0])
        num_floors = self.cfg.get("num_sectors", 32)
        sec_edges = _np.linspace(-_np.pi, _np.pi, num_floors+1)
        sectors = _np.digitize(angles, sec_edges) - 1
        for i in range(n):
            meta = {"building": self.cfg.get("building","default"), "floor": f"F{sectors[i]}", "room": "R0"}
            m.insert(i, points[i], meta)
        for i in range(n): m.bump_heat([i])
        return m
    def solve(self, points, max_ticks=8):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        mode = self.cfg.get('hash_mode','auto')
        use_inline = False
        if mode=='inline': use_inline=True
        elif mode=='mdhg': use_inline=False
        else:
            # auto: prefer inline for moderate dims/size, escalate if needed later
            use_inline = (points.shape[1] <= int(self.cfg.get('inline_dim_thresh',16)) and points.shape[0] <= int(self.cfg.get('inline_n_thresh',5000)))
        if use_inline:
            self.inline = self._build_inline(points)
            self.bus.vws = seed_inline(self.inline, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128))
        else:
            self.mdhg = self._build_mdhg(points)
            # replay journal before seeding VWS
            try:
                applied = self.journal.replay_into_mdhg(self.mdhg, since_ts=0.0)
                self.bus.stats['journal_applied'] = int(applied)
            except Exception:
                self.bus.stats['journal_applied'] = 0
            self.bus.vws = None if self.cfg.get('vws_skip_seed') else self._seed_vws(points)  # patchedself.mdhg, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128), seeding_strategy=self.cfg.get('vws_seeding','exact'), grid_size=self.cfg.get('vws_grid_size',16), grid_k=self.cfg.get('vws_grid_k',4), grid_radius=self.cfg.get('vws_grid_radius',1))
        _ = self.navigator.assign_shells_and_sectors(points)
        # optional adjacency prefilter
        if self.cfg.get('use_adjacency_prefilter'):
            try:
                adj = build_adjacency(points, k=int(self.cfg.get('adj_k',8)), buckets=int(self.cfg.get('adj_buckets',64)))
                elev = build_elevators(points, adj, quota=int(points.shape[0]//50))
                self.bus.stats['adj_avg_degree'] = float(adj.get('avg_degree',0.0))
                self.bus.stats['elevators'] = int(elev.get('count',0))
            except Exception as e:
                self.bus.stats['adj_error'] = str(e)[:80]
        chosen_all = []
        escalated = False
        for _ in range(max_ticks):
            chosen = self.navigator.sweep_step(points)
            # optional SFBB reweighting of patch candidates if navigator exposes them
            try:
                if self._sfbb_policy and hasattr(self.navigator, 'last_candidates'):
                    ranked = self._sfbb_policy.choose(points, self.navigator.last_candidates, {"tick": len(chosen_all)})
                    # if ranked differs, prefer ranked order where possible
                    chosen = ranked[:len(chosen)] if ranked else chosen
            except Exception:
                pass
            chosen_all.extend(chosen)
            if self.inline is not None:
                delta = self.inline.consume_delta()
                if delta.get('heat') or delta.get('edges'):
                    try:
                        fpath = self.journal.append(delta.get('heat',{}), delta.get('edges',[]))
                        # mirror into dual queue for future MDHG flush
                        for i,h in (delta.get('heat') or {}).items(): self.dual.heat[i]+=h
                        for (a,b,w) in (delta.get('edges') or []): self.dual.record_edge_weight(a,b,w)
                        create_snap({"universes":["work.fast"],"n_level":1.0,"provenance":{"event":"journal_flush","phase":"tick"},"meta":{"file":fpath}}, kind="journal_flush")
                    except Exception:
                        pass
            # --- AUTO-ESCALATE CHECKS ---
            if self.cfg.get("hash_mode","auto")=="auto" and self.inline is not None and not escalated:
                ticks = max(1, int(self.bus.stats.get("ticks",1)))
                steps = max(1, int(self.bus.stats.get("steps",1)))
                thrash = float(self.bus.stats.get("thrash",0.0))
                coverage = float(self.bus.stats.get("coverage_gain",0.0))
                thrash_per_step = thrash/steps
                coverage_rate = coverage/ticks
                inline_stats = self.inline.stats()
                mean_bucket = inline_stats.get("mean_bucket_size", 0.0)
                # thresholds
                tau = float(self.cfg.get("auto_thrash_tau", 0.8))
                kappa = float(self.cfg.get("auto_coverage_kappa", 0.15))
                beta = float(self.cfg.get("auto_bucket_beta", 8.0))
                need_escalate = (thrash_per_step >= tau) or (coverage_rate <= kappa) or (mean_bucket >= beta)
                if need_escalate:
                    # Build MDHG and transfer dual state
                    self.mdhg = self._build_mdhg(points)
                    # replay journal first
                    try:
                        applied = self.journal.replay_into_mdhg(self.mdhg, since_ts=0.0)
                        self.bus.stats['journal_applied_escalate'] = int(applied)
                    except Exception:
                        self.bus.stats['journal_applied_escalate'] = 0
                    # apply dual edges/heat
                    try:
                        self.dual.flush_to_mdhg(self.mdhg)
                    except Exception:
                        pass
                    # seed VWS from MDHG and flip path
                    self.bus.vws = None if self.cfg.get('vws_skip_seed') else self._seed_vws(points)  # patchedself.mdhg, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128), seeding_strategy=self.cfg.get('vws_seeding','exact'), grid_size=self.cfg.get('vws_grid_size',16), grid_k=self.cfg.get('vws_grid_k',4), grid_radius=self.cfg.get('vws_grid_radius',1))
                    self.inline = None
                    escalated = True
        # --- Promotion / Staging policy ---
        policy = self.cfg.get("promotion_policy","sample_full")  # "fast_allowed" | "sample_full" | "must_pass_full"
        mode = self.cfg.get("hash_mode","auto")
        staged = (mode in ("auto","inline") and self.inline is not None)
        info = {"staged": staged, "policy": policy}
        brief = self._metrics_brief()
        info["fast_metrics"] = brief
        # auto-escalation SNAP (if we switched to MDHG during run)
        if self.cfg.get("hash_mode","auto")=="auto" and self.inline is None and self.mdhg is not None:
            try:
                create_snap({
                    "universes":["work.fast"],
                    "n_level": 1.0,
                    "provenance":{"event":"auto_escalate","thresholds":{
                        "tau": float(self.cfg.get("auto_thrash_tau",0.8)),
                        "kappa": float(self.cfg.get("auto_coverage_kappa",0.15)),
                        "beta": float(self.cfg.get("auto_bucket_beta",8.0))
                    }},
                    "meta":{"pre_metrics": brief}
                }, kind="auto_escalate")
            except Exception:
                pass
        decision = "canonical"
        if staged:
            if policy=="fast_allowed":
                decision = "promoted"
            else:
                sample = self._promotion_check(points, sample_ticks=int(self.cfg.get("promotion_sample_ticks",3)))
                info["sample_metrics"] = sample
                # Gate rules
                thrash_ok = brief["thrash_per_step"] <= float(self.cfg.get("promote_thrash_tau", 0.8))
                cover_ok  = brief["coverage_rate"]    >= float(self.cfg.get("promote_coverage_kappa", 0.15))
                # Compare with sample (MDHG) for sanity
                delta_cover = sample["coverage_rate"] - brief["coverage_rate"]
                delta_thrash= brief["thrash_per_step"] - sample["thrash_per_step"]
                info["delta_cover"] = delta_cover; info["delta_thrash"] = delta_thrash
                if policy=="must_pass_full":
                    decision = "promoted" if (thrash_ok and cover_ok and delta_cover<=0.05 and delta_thrash>=-0.05) else "quarantined"
                else:
                    decision = "promoted" if (thrash_ok and cover_ok) else "quarantined"
            try:
                create_snap({
                    "universes":["work.fast"],
                    "n_level": 1.0,
                    "provenance":{"event":"promotion_decision","policy":policy},
                    "meta":{"decision": decision, "info": info}
                }, kind="promotion")
            except Exception:
                pass
        return {"stats": self.bus.stats, "chosen": chosen_all, "meta": self.bus.meta, "verdict": decision, "info": info}


    def _build_inline(self, points):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        ih = InlineH(dim=points.shape[1], grid=float(self.cfg.get("inline_grid", 32.0)), proj_dims=int(self.cfg.get("inline_proj_dims", 8)), seed=int(self.cfg.get("inline_seed", 17)))
        n = points.shape[0]
        center = points.mean(axis=0); vecs = points - center
        angles = _np.arctan2(vecs[:,1], vecs[:,0])
        num_floors = self.cfg.get("num_sectors", 32)
        sec_edges = _np.linspace(-_np.pi, _np.pi, num_floors+1)
        sectors = _np.digitize(angles, sec_edges) - 1
        for i in range(n):
            meta = {"building": self.cfg.get("building","default"), "floor": f"F{sectors[i]}", "room": "R0"}
            ih.insert(i, points[i], meta)
        for i in range(n): ih.bump_heat([i])
        # prime dual-write with current inline state
        dual_export = ih.export_dualwrite()
        for i,h in dual_export['heat'].items(): self.dual.heat[i]+=h
        for (a,b,w) in dual_export['edges']: self.dual.record_edge_weight(a,b,w)
        try:
            fpath = self.journal.append(dual_export.get('heat',{}), dual_export.get('edges',[]))
            create_snap({"universes":["work.fast"],"n_level":1.0,"provenance":{"event":"journal_flush","phase":"init"},"meta":{"file":fpath}}, kind="journal_flush")
        except Exception:
            pass
        return ih

    def _metrics_brief(self):
        ticks = max(1, int(self.bus.stats.get("ticks",1)))
        steps = max(1, int(self.bus.stats.get("steps",1)))
        thrash = float(self.bus.stats.get("thrash",0.0))
        coverage = float(self.bus.stats.get("coverage_gain",0.0))
        return {
            "thrash_per_step": thrash/steps,
            "coverage_rate": coverage/ticks,
            "sectors_visited": int(self.bus.stats.get("sectors_visited",0)),
            "ticks": ticks, "steps":steps
        }

    def _promotion_check(self, points, sample_ticks:int=3):
        # apply promotion guard cfg
        self.cfg = adjust_sampling_cfg(self.cfg, N=points.shape[0])
        # Run a tiny MDHG solve to compare core metrics
        old_bus = self.bus; old_nav = self.navigator; old_inline = self.inline; old_mdhg = self.mdhg
        try:
            from .statebus_v0_4_2025_08_13 import StateBus_v0_4_2025_08_13 as Bus
            from .navigator_v0_4_2025_08_13 import NavigatorGR_v0_4_2025_08_13 as Nav
            from .vws_bridge_v0_1_2025_08_13 import seed_vws_from_mdhg_v0_1_2025_08_13 as seed
            from .mdhg_v0_2_2025_08_13 import MDHG_v0_2_2025_08_13 as MDHG
            self.bus = Bus()
        if self.cfg.get('prior_profile_path'):
            try:
                import json
                with open(self.cfg['prior_profile_path'],'r',encoding='utf-8') as f:
                    prof = json.load(f)
                self.bus.stats['prior_family'] = prof.get('family')
                self.bus.stats['prior_loaded'] = True
            except Exception:
                self.bus.stats['prior_loaded'] = False; self.navigator = Nav(self.cfg, self.bus)
            m = self._build_mdhg(points); self.mdhg = m
            self.bus.vws = None if self.cfg.get('vws_skip_seed') else self._seed_vws(points)  # patchedm, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128), seeding_strategy=self.cfg.get('vws_seeding','exact'), grid_size=self.cfg.get('vws_grid_size',16), grid_k=self.cfg.get('vws_grid_k',4), grid_radius=self.cfg.get('vws_grid_radius',1))
            _ = self.navigator.assign_shells_and_sectors(points)
        # optional adjacency prefilter
        if self.cfg.get('use_adjacency_prefilter'):
            try:
                adj = build_adjacency(points, k=int(self.cfg.get('adj_k',8)), buckets=int(self.cfg.get('adj_buckets',64)))
                elev = build_elevators(points, adj, quota=int(points.shape[0]//50))
                self.bus.stats['adj_avg_degree'] = float(adj.get('avg_degree',0.0))
                self.bus.stats['elevators'] = int(elev.get('count',0))
            except Exception as e:
                self.bus.stats['adj_error'] = str(e)[:80]
            for _ in range(sample_ticks):
                _ = self.navigator.sweep_step(points)
            sample_metrics = self._metrics_brief()
            return sample_metrics
        finally:
            self.bus = old_bus; self.navigator = old_nav; self.inline = old_inline; self.mdhg = old_mdhg
