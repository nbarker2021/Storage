
import math
import numpy as np

def random_sampler(N:int, d:int=2, seed:int=0):
    rng = np.random.default_rng(seed)
    return rng.random((N, d))

def lhs_sampler(N:int, d:int=2, seed:int=0):
    # Latin Hypercube Sampling in [0,1]^d
    rng = np.random.default_rng(seed)
    result = np.zeros((N, d), dtype=float)
    for j in range(d):
        perm = rng.permutation(N)
        bins = (perm + rng.random(N)) / N
        result[:, j] = bins
    return result

def poisson_disk_sampler(N:int, d:int=2, seed:int=0, radius:float=None, k:int=30):
    """
    Bridson's algorithm for 2D. For d>2, fall back to LHS.
    N is a soft target; algorithm stops when no more points fit.
    """
    if d != 2:
        return lhs_sampler(N, d=d, seed=seed)
    rng = np.random.default_rng(seed)
    if radius is None:
        # heuristic: radius ~ c / sqrt(N)
        radius = 0.85/math.sqrt(N)
    r = radius
    k = int(k)
    cell_size = r/math.sqrt(2)
    grid_w = int(math.ceil(1/cell_size))
    grid_h = int(math.ceil(1/cell_size))
    grid = -np.ones((grid_w, grid_h), dtype=int)
    points = []
    active = []

    def grid_coords(p):
        return int(p[0]/cell_size), int(p[1]/cell_size)

    # first point
    p0 = rng.random(2)
    points.append(p0); active.append(0)
    gx, gy = grid_coords(p0); 
    gx = min(grid_w-1, max(0, gx)); gy = min(grid_h-1, max(0, gy))
    grid[gx, gy] = 0

    while active and len(points) < N:
        idx = rng.integers(0, len(active))
        base_idx = active[idx]
        base = points[base_idx]
        found = False
        for _ in range(k):
            theta = rng.random()*2*math.pi
            rad = r*(1 + rng.random())
            cand = base + np.array([math.cos(theta), math.sin(theta)])*rad
            if not (0 <= cand[0] < 1 and 0 <= cand[1] < 1):
                continue
            cgx, cgy = grid_coords(cand)
            if not (0 <= cgx < grid_w and 0 <= cgy < grid_h):
                continue
            ok = True
            # check neighbors
            for ix in range(max(0, cgx-2), min(grid_w, cgx+3)):
                for iy in range(max(0, cgy-2), min(grid_h, cgy+3)):
                    j = grid[ix, iy]
                    if j >= 0 and np.linalg.norm(points[j]-cand) < r:
                        ok = False; break
                if not ok: break
            if ok:
                points.append(cand); active.append(len(points)-1)
                grid[cgx, cgy] = len(points)-1; found = True
                break
        if not found:
            active.pop(idx)
    return np.array(points, dtype=float)
