
from typing import Dict, Any, List, Tuple
import numpy as np

def _bins(points: np.ndarray, buckets:int=64):
    N, d = points.shape
    if d < 2:
        raise ValueError("adjacency grid binning expects at least 2D points")
    mins = points[:, :2].min(axis=0)
    maxs = points[:, :2].max(axis=0)
    span = np.maximum(maxs - mins, 1e-9)
    coords = (points[:, :2] - mins) / span
    ij = np.minimum(buckets-1, np.maximum(0, (coords * buckets).astype(int)))
    bins: Dict[Tuple[int,int], List[int]] = {}
    for idx, (i,j) in enumerate(ij):
        bins.setdefault((int(i),int(j)), []).append(idx)
    return ij, bins, mins, maxs, span

def build_adjacency(points: np.ndarray, k:int=8, buckets:int=64, backend:str='grid') -> Dict[str,Any]:
    N, d = points.shape
    if backend in ('faiss','hnsw'):
        # Use ANN adapters to build neighbor graph fast; fallback inside adapters
        if backend=='faiss':
            from ..plugins.ann.faiss_adapter import knn as ann_knn  # type: ignore
        else:
            from ..plugins.ann.hnsw_adapter import knn as ann_knn  # type: ignore
        I, _ = ann_knn(points, points, k=k+1)
        edges=set()
        for i in range(N):
            for j in I[i,1:]:  # skip self
                a,b = (int(i),int(j)) if i<int(j) else (int(j),int(i))
                edges.add((a,b))
        edges = sorted(edges)
        return {"N": int(N), "edges": edges, "avg_degree": (2*len(edges))/max(1, N)}
    # default: grid-binned local kNN
    ij, bins, *_ = _bins(points, buckets=buckets)
    edges = set()
    neigh = [(di,dj) for di in (-1,0,1) for dj in (-1,0,1)]
    for idx, (i,j) in enumerate(ij):
        cand_idx = []
        for di,dj in neigh:
            key = (int(i)+di, int(j)+dj)
            if key in bins:
                cand_idx.extend(bins[key])
        if not cand_idx:
            continue
        cand = np.array(cand_idx, dtype=int)
        dists = np.linalg.norm(points[cand] - points[idx], axis=1)
        order = np.argsort(dists)[:k+1]  # include self; we’ll skip it
        for ord_idx in order:
            j2 = int(cand[ord_idx])
            if j2 == idx: 
                continue
            a,b = (idx,j2) if idx<j2 else (j2,idx)
            edges.add((a,b))
    edges = sorted(edges)
    return {"N": int(N), "edges": edges, "avg_degree": (2*len(edges))/max(1, N)}

def build_elevators(points: np.ndarray, adjacency: Dict[str,Any], quota:int= 0) -> Dict[str,Any]:
    # keep simple: select a few long-range random shortcuts
    N = int(adjacency["N"])
    edges=set(adjacency["edges"])
    rng = np.random.default_rng(23)
    extra = set()
    max_extra = min(quota, max(0, N//50))
    for _ in range(max_extra):
        a, b = int(rng.integers(0,N)), int(rng.integers(0,N))
        if a==b: continue
        e = (a,b) if a<b else (b,a)
        if e not in edges:
            extra.add(e)
    elevators = sorted(extra)
    return {"elevators": elevators, "count": len(elevators)}
