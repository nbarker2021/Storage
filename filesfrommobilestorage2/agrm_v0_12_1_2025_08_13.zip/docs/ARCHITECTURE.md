# Architecture

Spine, MDHG, AGRM, SAP, Archivist, SNAP, Universe, Mannequin, Plugins.
