
import sys, json, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[0]))

from core.universe.universe_manager_v0_1_2025_08_13 import UniverseManager, UniverseSpec
from core.archivist.archivist_v0_1_2025_08_13 import Repository
from core.mannequin.mannequin_v0_2_2025_08_13 import LatticeMannequinV2, DORMANT, WARM, ACTIVE

def run():
    repo_root = "/mnt/data/repository_store_v0_1_2025_08_13"
    reg_root  = "/mnt/data/universe_registry_v0_1_2025_08_13"
    um = UniverseManager(repo_root, reg_root)
    repo = Repository(repo_root)

    # Seed some SNAPs if needed
    if not repo.list():
        for i in range(30):
            sid = f"culture-creative-v0_1_demo-{int(time.time())}-{i}"
            meta = {"snap_id": sid, "family":"culture", "type":"creative", "version":"v0_1_demo", "created_ts": time.time(), "tags":{"snap_score": 0.55 + 0.015*i}}
            repo.save(sid, {"meta": meta, "content": {"payload": f"demo-{i}"}})

    # Build a universe view
    if "TaskUniverse_Stream" not in um.list_universes():
        um.create_universe(UniverseSpec(
            name="TaskUniverse_Stream",
            selectors={"family":["culture"], "type":["creative"], "tags":{}},
            policies={"isolated": True}
        ))

    # Mannequin v2 lifecycle
    m = LatticeMannequinV2("TaskUniverse_Stream", repo_root=repo_root, registry_root=reg_root, max_nodes=500, k_neighbors=6)
    m.build_manifest(force=True)
    m.toggle(on=True)

    # Request a large slice but stream in small waves; SAP will deny if predicted >> budget
    criteria = {"family":["culture"], "type":["creative"], "tags":{"snap_score_gt": 0.56}}
    stream, gate = m.activate_stream(criteria, wave_size=64, max_nodes=None)

    out = {"gate": gate, "waves": []}
    if stream is None:
        out["status"] = "denied_or_empty"
    else:
        # pull two waves for demo
        for i, sh in zip(range(2), stream):
            out["waves"].append({
                "key": sh.key,
                "count": sh.budget_used,
                "edges": len(sh.edges),
                "coord_sample": sh.coords[:1]
            })
        m.toggle(on=False)
        out["final_state"] = m.state

    return out

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
