import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

import json, time
from pathlib import Path
from agrm.archivist.repository import Repository
from agrm.universe.manager import UniverseManager, UniverseSpec
from agrm.mannequin.lattice import LatticeMannequinV2

REPO = '/mnt/data/repository_store_v0_1_2025_08_13'
REG  = '/mnt/data/universe_registry_v0_1_2025_08_13'

def run():
    repo = Repository(REPO)
    if not repo.list():
        for i in range(5):
            sid = f'safe-culture-creative-{int(time.time())}-{i}'
            meta = {"snap_id": sid, "family":"culture","type":"creative","created_ts": time.time(),"tags":{"snap_score":0.7}}
            repo.save(sid, {"meta":meta, "content":{}})
    um = UniverseManager(REPO, REG)
    if 'SafeCubeUniverse' not in um.list_universes():
        um.create_universe(UniverseSpec(name='SafeCubeUniverse', selectors={"family":["culture"],"type":["creative"]}, policies={"safe_cube": True}))
    m = LatticeMannequinV2('SafeCubeUniverse', repo_root=REPO, registry_root=REG)
    m.build_manifest(); m.toggle(on=True)
    # Missing tags -> should be denied by safe_cube policy
    stream, gate = m.activate_stream(criteria={"family":["culture"],"type":["creative"]}, wave_size=4)
    return {"gate": gate}

if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
