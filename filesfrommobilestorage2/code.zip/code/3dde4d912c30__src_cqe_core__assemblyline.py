Text file: 3dde4d912c30__src_cqe_core__assemblyline.py
Latest content with line numbers:
1	"""AssemblyLine Monitor – validates atomic boundaries & entropy futures.
2	
3	• register_boundary_check(callback) – callback returns dict matching BoundaryValidationSchema
4	• register_entropy_check(callback) – callback returns dict matching EntropyFuturesSchema
5	• run_cycle() – executes all checks, logs events, feeds ValidationManager
6	• Auto-scheduled by background thread every INTERVAL seconds.
7	"""
8	from __future__ import annotations
9	import threading, time, json, pathlib, datetime
10	from typing import Callable, Dict, List, Any
11	import jsonschema
12	from PIL import Image, PngImagePlugin
13	from .dual_governance import default as gov
14	from .validation import validator
15	
16	SCHEMA_DIR = pathlib.Path(__file__).resolve().parent.parent.parent / 'schemas'
17	BOUNDARY_SCHEMA = json.loads((SCHEMA_DIR / 'BoundaryValidationSchema.json').read_text())
18	ENTROPY_SCHEMA = json.loads((SCHEMA_DIR / 'EntropyFuturesSchema.json').read_text())
19	
20	class AssemblyLine:
21	def _extract_meta(self, path: pathlib.Path) -> dict | None:
22	    try:
23	        img = Image.open(path)
24	        info = img.info
25	        if 'cqe_meta' in info:
26	            import json
27	            return json.loads(info['cqe_meta'])
28	    except Exception:
29	        pass
30	    return None
31	
32	    INTERVAL = 5.0  # seconds
33	
34	    def __init__(self):
35	        self.boundary_checks: List[Callable[[], Dict[str, Any]]] = []
36	        self.entropy_checks: List[Callable[[], Dict[str, Any]]] = []
37	        self._thread = threading.Thread(target=self._loop, daemon=True)
38	        self._thread.start()
39	
40	    def register_boundary_check(self, fn: Callable[[], Dict[str, Any]]):
41	        self.boundary_checks.append(fn)
42	
43	    def register_entropy_check(self, fn: Callable[[], Dict[str, Any]]):
44	        self.entropy_checks.append(fn)
45	
46	    def _loop(self):
47	        while True:
48	            self.run_cycle()
49	            time.sleep(self.INTERVAL)
50	
51	    def run_cycle(self):
52	        ts = datetime.datetime.utcnow().isoformat()
53	        for fn in self.boundary_checks:
54	            data = fn()
55	            data['timestamp'] = ts
56	            jsonschema.validate(data, BOUNDARY_SCHEMA)
57	            gov.record_event('assembly_boundary', data)
58	            validator.register(f"boundary_{data['structure_id']}_{ts}", lambda: data['confinement_ok'] and data['chemical_specificity_ok'] and data['informational_boundary_ok'])
59	        for fn in self.entropy_checks:
60	            data = fn()
61	            data['timestamp'] = ts
62	            jsonschema.validate(data, ENTROPY_SCHEMA)
63	            gov.record_event('assembly_entropy', data)
64	            validator.register(f"entropy_{data['segment_id']}_{ts}", lambda: data['delta_S'] <= 0 and data['reversible'])
65	# Scan PNG files in working directory for new metadata (optional simple scan)
66	for png_path in pathlib.Path('.').glob('pixels_out/*.png'):
67	    meta = self._extract_meta(png_path)
68	    if meta:
69	        if 'entropy' in meta:
70	            data_ent = {'segment_id': png_path.stem,
71	                        'delta_S': meta.get('entropy',0),
72	                        'forecast_S': meta.get('entropy',0),
73	                        'reversible': meta.get('entropy',0)<=0}
74	            try:
75	                jsonschema.validate(data_ent, ENTROPY_SCHEMA)
76	                gov.record_event('assembly_entropy_png', data_ent)
77	            except jsonschema.ValidationError:
78	                gov.record_event('assembly_entropy_png_fail', {'path': str(png_path)})
79	
80	
81	# singleton
82	default = AssemblyLine()
83	
84	__all__ = ['default', 'AssemblyLine']
85	