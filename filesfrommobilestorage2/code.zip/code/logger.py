Text file: logger.py
Latest content with line numbers:
1	"""
2	Logging utilities for Aletheia system.
3	"""
4	
5	import logging
6	import sys
7	
8	def setup_logger(name: str, verbose: bool = False) -> logging.Logger:
9	    """Setup a logger with appropriate formatting."""
10	    logger = logging.getLogger(name)
11	    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
12	    
13	    # Console handler
14	    handler = logging.StreamHandler(sys.stdout)
15	    handler.setLevel(logging.DEBUG if verbose else logging.INFO)
16	    
17	    # Formatter
18	    formatter = logging.Formatter(
19	        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
20	        datefmt='%Y-%m-%d %H:%M:%S'
21	    )
22	    handler.setFormatter(formatter)
23	    
24	    logger.addHandler(handler)
25	    
26	    return logger
27	
28	