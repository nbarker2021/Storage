#!/usr/bin/env python3.11
"""Consolidate all formalizations into organized document."""

import json
from pathlib import Path
from collections import defaultdict

# Load extracted formalizations
with open('/home/ubuntu/all_formalizations.json', 'r') as f:
    all_formalizations = json.load(f)

print(f"Loaded {len(all_formalizations)} papers")

# Organize by category
categories = {
    'E8_Lattice': [],
    'Riemann_Hypothesis': [],
    'P_vs_NP': [],
    'Yang_Mills': [],
    'MORSR': [],
    'Sacred_Geometry': [],
    'Conservation_Laws': [],
    'Dimensional_Theory': [],
    'WorldForge': [],
    'ALENA': [],
    'TQF': [],
    'Other': []
}

# Categorize papers
for paper in all_formalizations:
    filepath = paper['filepath']
    filename = Path(filepath).name.lower()
    
    if 'e8' in filename or 'lattice' in filename:
        categories['E8_Lattice'].append(paper)
    elif 'riemann' in filename:
        categories['Riemann_Hypothesis'].append(paper)
    elif 'np' in filename or 'p_vs_np' in filename or 'alena' in filename:
        categories['P_vs_NP'].append(paper)
    elif 'yang' in filename or 'mills' in filename:
        categories['Yang_Mills'].append(paper)
    elif 'morsr' in filename:
        categories['MORSR'].append(paper)
    elif 'sacred' in filename or 'geometry' in filename or 'fibonacci' in filename:
        categories['Sacred_Geometry'].append(paper)
    elif 'conservation' in filename or 'entropy' in filename or 'phi' in filename:
        categories['Conservation_Laws'].append(paper)
    elif 'dimensional' in filename or 'dimension' in filename:
        categories['Dimensional_Theory'].append(paper)
    elif 'worldforge' in filename or 'world' in filename:
        categories['WorldForge'].append(paper)
    elif 'alena' in filename:
        categories['ALENA'].append(paper)
    elif 'tqf' in filename:
        categories['TQF'].append(paper)
    else:
        categories['Other'].append(paper)

# Create consolidated document
output = []
output.append("# Complete Formalization Catalog")
output.append("=" * 80)
output.append("")
output.append("**Extracted from 92 papers in the Aletheia CQE System**")
output.append("")
output.append("## Summary Statistics")
output.append("")
output.append(f"- **Total Papers:** {len(all_formalizations)}")
output.append(f"- **Total Definitions:** {sum(len(p['definitions']) for p in all_formalizations)}")
output.append(f"- **Total Theorems:** {sum(len(p['theorems']) for p in all_formalizations)}")
output.append(f"- **Total Lemmas:** {sum(len(p['lemmas']) for p in all_formalizations)}")
output.append(f"- **Total Propositions:** {sum(len(p['propositions']) for p in all_formalizations)}")
output.append(f"- **Total Corollaries:** {sum(len(p['corollaries']) for p in all_formalizations)}")
output.append(f"- **Total Axioms:** {sum(len(p['axioms']) for p in all_formalizations)}")
output.append(f"- **Total Equations:** {sum(len(p['equations']) for p in all_formalizations)}")
output.append(f"- **Total Algorithms:** {sum(len(p['algorithms']) for p in all_formalizations)}")
output.append("")
output.append("---")
output.append("")

# Process each category
for category_name, papers in categories.items():
    if not papers:
        continue
    
    output.append(f"## {category_name.replace('_', ' ')}")
    output.append("")
    output.append(f"**Papers in category:** {len(papers)}")
    output.append("")
    
    # Collect all items from this category
    all_defs = []
    all_thms = []
    all_lems = []
    all_props = []
    all_cors = []
    all_axs = []
    all_eqs = []
    all_algs = []
    
    for paper in papers:
        source = Path(paper['filepath']).name
        
        for item in paper['definitions']:
            all_defs.append((source, item))
        for item in paper['theorems']:
            all_thms.append((source, item))
        for item in paper['lemmas']:
            all_lems.append((source, item))
        for item in paper['propositions']:
            all_props.append((source, item))
        for item in paper['corollaries']:
            all_cors.append((source, item))
        for item in paper['axioms']:
            all_axs.append((source, item))
        for item in paper['equations']:
            all_eqs.append((source, item))
        for item in paper['algorithms']:
            all_algs.append((source, item))
    
    # Write definitions
    if all_defs:
        output.append(f"### Definitions ({len(all_defs)})")
        output.append("")
        for i, (source, item) in enumerate(all_defs[:50], 1):  # Limit to 50 per category
            output.append(f"**Def {item['number']}** (from `{source}`)")
            output.append(f"> {item['content']}")
            output.append("")
        if len(all_defs) > 50:
            output.append(f"*... and {len(all_defs) - 50} more definitions*")
            output.append("")
    
    # Write theorems
    if all_thms:
        output.append(f"### Theorems ({len(all_thms)})")
        output.append("")
        for i, (source, item) in enumerate(all_thms[:50], 1):
            output.append(f"**Theorem {item['number']}** (from `{source}`)")
            output.append(f"> {item['content']}")
            output.append("")
        if len(all_thms) > 50:
            output.append(f"*... and {len(all_thms) - 50} more theorems*")
            output.append("")
    
    # Write lemmas
    if all_lems:
        output.append(f"### Lemmas ({len(all_lems)})")
        output.append("")
        for i, (source, item) in enumerate(all_lems[:30], 1):
            output.append(f"**Lemma {item['number']}** (from `{source}`)")
            output.append(f"> {item['content']}")
            output.append("")
        if len(all_lems) > 30:
            output.append(f"*... and {len(all_lems) - 30} more lemmas*")
            output.append("")
    
    # Write propositions
    if all_props:
        output.append(f"### Propositions ({len(all_props)})")
        output.append("")
        for i, (source, item) in enumerate(all_props[:30], 1):
            output.append(f"**Proposition {item['number']}** (from `{source}`)")
            output.append(f"> {item['content']}")
            output.append("")
        if len(all_props) > 30:
            output.append(f"*... and {len(all_props) - 30} more propositions*")
            output.append("")
    
    # Write axioms
    if all_axs:
        output.append(f"### Axioms ({len(all_axs)})")
        output.append("")
        for i, (source, item) in enumerate(all_axs[:20], 1):
            output.append(f"**Axiom {item['number']}** (from `{source}`)")
            output.append(f"> {item['content']}")
            output.append("")
        if len(all_axs) > 20:
            output.append(f"*... and {len(all_axs) - 20} more axioms*")
            output.append("")
    
    # Write algorithms
    if all_algs:
        output.append(f"### Algorithms ({len(all_algs)})")
        output.append("")
        for i, (source, item) in enumerate(all_algs[:20], 1):
            output.append(f"**Algorithm {item['number']}** (from `{source}`)")
            output.append(f"> {item['content']}")
            output.append("")
        if len(all_algs) > 20:
            output.append(f"*... and {len(all_algs) - 20} more algorithms*")
            output.append("")
    
    output.append("---")
    output.append("")

# Write to file
output_file = '/home/ubuntu/COMPLETE_FORMALIZATION_CATALOG.md'
with open(output_file, 'w') as f:
    f.write('\n'.join(output))

print(f"Created {output_file}")
print(f"Total lines: {len(output)}")

