Text file: 56f232645b80__cqe_core__cqe_harness_v1.py
Latest content with line numbers:
2	# -*- coding: utf-8 -*-
3	"""
4	CQE Controller Harness — single-file skeleton
5	=============================================
6	
7	This module implements a receipts-first, geometry-governed controller that:
8	  • Senses (slice calculus observables on wedge lattices W=80/240 for decagon/octagon viewers)
9	  • Plans (Socratic Q/A on objectives and invariants)
10	  • Acts (pose rotation/reflection, least-action repair, clone tiling, lattice switch)
11	  • Checks (ΔΦ monotonicity, validators across LATT/CRT/FRAC/SACNUM stubs)
12	  • Emits receipts (append-only JSONL ledger + latent pose cache row)
13	
14	It is intentionally self-contained (stdlib only) and designed to be dropped into a repo
15	as the spine. Real slice validators can be wired in later by replacing stub methods.
16	
17	Usage (CLI):
18	    python cqe_harness.py --text "some phrase" --policy channel-collapse --out runs/demo
19	
20	Outputs:
21	  • runs/<stamp>/ledger.jsonl        (receipts)
22	  • runs/<stamp>/lpc.csv             (latent pose cache rows)
23	  • runs/<stamp>/summary.txt         (human-readable summary)
24	
25	Author: CQE custodian
26	License: MIT (adjust as needed)
27	"""
28	
29	from __future__ import annotations
30	import argparse
31	import dataclasses as dc
32	import hashlib
33	import json
34	import math
35	import os
36	import random
37	import sys
38	import time
39	from collections import defaultdict, Counter
40	from dataclasses import dataclass
41	from datetime import datetime
42	from pathlib import Path
43	from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
44	
45	# --------------------------------------------------------------------------------------
46	# Utility: hash + timestamps
47	# --------------------------------------------------------------------------------------
48	
49	def now_stamp() -> str:
50	    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")
51	
52	def sha256_hex(obj: Any) -> str:
53	    b = json.dumps(obj, sort_keys=True, ensure_ascii=False).encode("utf-8")
54	    return hashlib.sha256(b).hexdigest()
55	
56	# --------------------------------------------------------------------------------------
57	# Tokenization → faces (decagon/octagon) — minimal, deterministic
58	# --------------------------------------------------------------------------------------
59	
60	@dc.dataclass
61	class Face:
62	    """A 'face' is a small numeric stream view (mod 10 / mod 8) for slice calculus.
63	    values: base-M integers in [0, M-1].
64	    base:   M (10 for decagon, 8 for octagon)
65	    label:  free-form (e.g., 'decagon'/'octagon')
66	    """
67	    values: List[int]
68	    base: int
69	    label: str
70	
71	
72	def text_to_faces(text: str) -> Tuple[Face, Face]:
73	    """Map text into two aligned numeric streams: mod10 (decagon) and mod8 (octagon).
74	    Deterministic, lossy by design (shape-first)."""
75	    # Simple deterministic mapping: bytes → rolling hash → digits
76	    h = 1469598103934665603  # FNV offset
77	    d10: List[int] = []
78	    d8: List[int] = []
79	    for ch in text.encode("utf-8", errors="ignore"):
80	        h ^= ch
81	        h *= 1099511628211
82	        h &= (1 << 64) - 1
83	        d10.append((h // 2654435761) % 10)
84	        d8.append((h // 11400714819323198485) % 8)
85	    if not d10:
86	        d10 = [0]
87	        d8 = [0]
88	    return Face(d10, 10, "decagon"), Face(d8, 8, "octagon")
89	
90	# --------------------------------------------------------------------------------------
91	# Slice lattice & observables
92	# --------------------------------------------------------------------------------------
93	
94	@dc.dataclass
95	class SliceObservables:
96	    theta: List[float]                 # lattice angles
97	    extreme_idx: List[int]             # i(θ): index of extreme sample
98	    quadrant_bins: List[Tuple[int,int,int,int]]  # q(θ): counts per quadrant-like bin
99	    chord_hist: List[Counter]          # hΔ(θ): histogram of chord steps
100	    perm: List[List[int]]              # π(θ): permutation of sample order (top-k simplified)
101	    braid_current: List[int]           # B(θ): adjacent transposition count per step
102	    energies: Dict[str, float]         # Dirichlet energies over chosen signals
103	
104	
105	class SliceSensors:
106	    def __init__(self, W: int = 80, topk: int = 16):
107	        self.W = W
108	        self.topk = topk
109	        self.theta = [2 * math.pi * m / W for m in range(W)]
110	
111	    # --- projections & helpers ---
112	    @staticmethod
113	    def _project_stream(vals: Sequence[int], base: int, theta: float) -> List[float]:
114	        # Treat each sample as a point on its base-gon; project onto direction θ
115	        out: List[float] = []
116	        for v in vals:
117	            ang = 2 * math.pi * (v % base) / base
118	            out.append(math.cos(ang - theta))
119	        return out
120	
121	    @staticmethod
122	    def _argmax_idx(arr: Sequence[float]) -> int:
123	        best, idx = -1e9, 0
124	        for i, x in enumerate(arr):
125	            if x > best:
126	                best, idx = x, i
127	        return idx
128	
129	    @staticmethod
130	    def _quadrant_bins(vals: Sequence[int], base: int, theta: float) -> Tuple[int,int,int,int]:
131	        # Bin positions after rotation; 4 equal arcs on the circle
132	        bins = [0,0,0,0]
133	        for v in vals:
134	            ang = (2 * math.pi * (v % base) / base - theta) % (2 * math.pi)
135	            q = int((ang / (2 * math.pi)) * 4.0) % 4
136	            bins[q] += 1
137	        return tuple(bins)  # type: ignore
138	
139	    @staticmethod
140	    def _chord_hist(vals: Sequence[int], base: int) -> Counter:
141	        # Count step differences mod base for consecutive samples
142	        c = Counter()
143	        for a, b in zip(vals, vals[1:]):
144	            step = (b - a) % base
145	            c[step] += 1
146	        return c
147	
148	    @staticmethod
149	    def _perm_by_projection(vals: Sequence[int], base: int, theta: float, topk: int) -> List[int]:
150	        # Sort indices by projection descending; return top-k indices