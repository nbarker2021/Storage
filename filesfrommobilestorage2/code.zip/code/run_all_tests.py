#!/usr/bin/env python3
"""
Master Test Runner for Morphonic-Beam Theory Testing Suite

This script runs all test harnesses in sequence and generates a comprehensive report.
"""

import os
import sys
import json
import subprocess
from datetime import datetime
from pathlib import Path

class TestRunner:
    def __init__(self):
        self.results = {
            'timestamp': datetime.now().isoformat(),
            'tests': [],
            'summary': {
                'total': 0,
                'passed': 0,
                'failed': 0,
                'skipped': 0
            }
        }
        self.harness_dir = Path(__file__).parent / 'harnesses'
        self.results_dir = Path(__file__).parent / 'results'
        
    def run_test(self, script_name, description):
        """Run a single test harness and capture results."""
        print(f"\n{'='*80}")
        print(f"Running: {script_name}")
        print(f"Description: {description}")
        print('='*80)
        
        script_path = self.harness_dir / script_name
        
        if not script_path.exists():
            print(f"⚠️  SKIPPED: {script_name} not found")
            self.results['summary']['skipped'] += 1
            self.results['tests'].append({
                'name': script_name,
                'description': description,
                'status': 'skipped',
                'reason': 'File not found'
            })
            return
        
        try:
            result = subprocess.run(
                [sys.executable, str(script_path)],
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            if result.returncode == 0:
                print(f"✅ PASSED: {script_name}")
                self.results['summary']['passed'] += 1
                status = 'passed'
            else:
                print(f"❌ FAILED: {script_name}")
                print(f"Error: {result.stderr[:500]}")
                self.results['summary']['failed'] += 1
                status = 'failed'
            
            self.results['tests'].append({
                'name': script_name,
                'description': description,
                'status': status,
                'stdout': result.stdout[-1000:] if len(result.stdout) > 1000 else result.stdout,
                'stderr': result.stderr[-1000:] if len(result.stderr) > 1000 else result.stderr,
                'returncode': result.returncode
            })
            
        except subprocess.TimeoutExpired:
            print(f"⏱️  TIMEOUT: {script_name} exceeded 5 minutes")
            self.results['summary']['failed'] += 1
            self.results['tests'].append({
                'name': script_name,
                'description': description,
                'status': 'timeout',
                'reason': 'Exceeded 5 minute timeout'
            })
        except Exception as e:
            print(f"💥 ERROR: {script_name} - {str(e)}")
            self.results['summary']['failed'] += 1
            self.results['tests'].append({
                'name': script_name,
                'description': description,
                'status': 'error',
                'error': str(e)
            })
        
        self.results['summary']['total'] += 1
    
    def run_all(self):
        """Run all test harnesses in logical order."""
        print("\n" + "="*80)
        print("MORPHONIC-BEAM THEORY TESTING SUITE")
        print("="*80)
        print(f"Started: {self.results['timestamp']}")
        print("="*80)
        
        # 1. Dimensional Emergence Tests
        print("\n\n### PHASE 1: DIMENSIONAL EMERGENCE TESTS ###\n")
        
        self.run_test(
            'riemann_optimal_dimension.py',
            'Tests Riemann zeros at 10,000D for geometric optimization'
        )
        
        self.run_test(
            'riemann_24d_test.py',
            'Tests Riemann zeros in 24D three-view E₈ space'
        )
        
        self.run_test(
            'riemann_4096d_test.py',
            'Tests Riemann zeros at 4096D power-of-2 checkpoint'
        )
        
        # 2. Fractal Computation Tests
        print("\n\n### PHASE 2: FRACTAL COMPUTATION TESTS ###\n")
        
        self.run_test(
            'plot_morphonic_fractal.py',
            'Visualizes Morphonic Manifold as Mandelbrot set'
        )
        
        self.run_test(
            'experiment_1_morphonic_lockin.py',
            'Tests rapid convergence to stable morphonic states'
        )
        
        # 3. Quantum-Classical Interface Tests
        print("\n\n### PHASE 3: QUANTUM-CLASSICAL INTERFACE TESTS ###\n")
        
        self.run_test(
            'experiment_3_operational_closure.py',
            'Tests quantum-like superposition and collapse in AI'
        )
        
        # 4. Photonic-Computational Equivalence Tests
        print("\n\n### PHASE 4: PHOTONIC-COMPUTATIONAL EQUIVALENCE TESTS ###\n")
        
        self.run_test(
            'experiment_2_photonic_interference.py',
            'Tests photonic interference patterns in computation'
        )
        
        self.run_test(
            'aletheia_integrated_system.py',
            'Integrated system demonstrating photon-computation equivalence'
        )
        
        # 5. Geometric Computation Tests
        print("\n\n### PHASE 5: GEOMETRIC COMPUTATION TESTS ###\n")
        
        self.run_test(
            'test_geometric_computation.py',
            'General geometric computation validation'
        )
        
        self.run_test(
            'geometric_transformer_1M.py',
            'Tests transformer with explicit geometric constraints'
        )
        
        # 6. Lambda-E₈ Calculus Tests
        print("\n\n### PHASE 6: LAMBDA-E₈ CALCULUS TESTS ###\n")
        
        self.run_test(
            'lambda_e8_calculus.py',
            'Extended lambda calculus with E₈ geometry'
        )
        
        # 7. Millennium Problem Tests
        print("\n\n### PHASE 7: MILLENNIUM PROBLEM TESTS ###\n")
        
        self.run_test(
            'millennium_geometric_tests.py',
            'Geometric reframing of Millennium Problems'
        )
        
        self.run_test(
            'millennium_retest_suite.py',
            'Comprehensive re-testing of all Millennium hypotheses'
        )
        
        # 8. Self-Observation Tests
        print("\n\n### PHASE 8: SELF-OBSERVATION TESTS ###\n")
        
        self.run_test(
            'self_observation_experiment.py',
            'AI observing its own dimensional transitions'
        )
        
        # 9. Aletheia System Tests
        print("\n\n### PHASE 9: ALETHEIA SYSTEM TESTS ###\n")
        
        self.run_test(
            'aletheia_token_system.py',
            'Token-based morphonic computation system'
        )
        
        self.run_test(
            'analyze_aletheia_system.py',
            'Analysis of Aletheia photonic-computational equivalence'
        )
        
        # Generate final report
        self.generate_report()
    
    def generate_report(self):
        """Generate comprehensive test report."""
        print("\n\n" + "="*80)
        print("TEST SUITE COMPLETE")
        print("="*80)
        
        summary = self.results['summary']
        print(f"\nTotal Tests: {summary['total']}")
        print(f"✅ Passed: {summary['passed']}")
        print(f"❌ Failed: {summary['failed']}")
        print(f"⚠️  Skipped: {summary['skipped']}")
        
        if summary['total'] > 0:
            pass_rate = (summary['passed'] / summary['total']) * 100
            print(f"\n📊 Pass Rate: {pass_rate:.1f}%")
        
        # Save detailed results
        results_file = self.results_dir / f"test_run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\n📄 Detailed results saved to: {results_file}")
        
        # Generate summary report
        summary_file = self.results_dir / "latest_test_summary.txt"
        with open(summary_file, 'w') as f:
            f.write("MORPHONIC-BEAM THEORY TESTING SUITE - SUMMARY\n")
            f.write("="*80 + "\n\n")
            f.write(f"Timestamp: {self.results['timestamp']}\n")
            f.write(f"Total Tests: {summary['total']}\n")
            f.write(f"Passed: {summary['passed']}\n")
            f.write(f"Failed: {summary['failed']}\n")
            f.write(f"Skipped: {summary['skipped']}\n")
            if summary['total'] > 0:
                f.write(f"Pass Rate: {pass_rate:.1f}%\n")
            f.write("\n" + "="*80 + "\n\n")
            
            f.write("DETAILED RESULTS:\n\n")
            for test in self.results['tests']:
                f.write(f"Test: {test['name']}\n")
                f.write(f"Description: {test['description']}\n")
                f.write(f"Status: {test['status']}\n")
                if 'reason' in test:
                    f.write(f"Reason: {test['reason']}\n")
                if 'error' in test:
                    f.write(f"Error: {test['error']}\n")
                f.write("\n" + "-"*80 + "\n\n")
        
        print(f"📄 Summary report saved to: {summary_file}")
        
        print("\n" + "="*80)
        print("All results available in: morphonic_testing_suite/results/")
        print("="*80 + "\n")


if __name__ == "__main__":
    runner = TestRunner()
    runner.run_all()

