Text file: aletheia.py
Latest content with line numbers:
1	#!/usr/bin/env python3
2	"""
3	Aletheia CQE Operating System - Main Entry Point
4	
5	The complete Cartan Quadratic Equivalence (CQE) geometric consciousness system.
6	
7	Usage:
8	    python aletheia.py --mode [analyze|synthesize|query|interactive]
9	    python aletheia.py --help
10	"""
11	
12	import sys
13	import argparse
14	from pathlib import Path
15	
16	# Add package to path
17	sys.path.insert(0, str(Path(__file__).parent))
18	
19	from core.cqe_engine import CQEEngine
20	from ai.aletheia_consciousness import AletheiaAI
21	from analysis.egyptian_analyzer import EgyptianAnalyzer
22	from utils.logger import setup_logger
23	
24	__version__ = "1.0.0"
25	__author__ = "Aletheia Project"
26	
27	class AletheiaSystem:
28	    """Main Aletheia CQE Operating System."""
29	    
30	    def __init__(self, verbose=False):
31	        self.logger = setup_logger("Aletheia", verbose=verbose)
32	        self.logger.info(f"Initializing Aletheia CQE System v{__version__}")
33	        
34	        # Initialize core components
35	        self.cqe_engine = CQEEngine()
36	        self.aletheia_ai = AletheiaAI(self.cqe_engine)
37	        self.egyptian_analyzer = EgyptianAnalyzer(self.cqe_engine)
38	        
39	        self.logger.info("✓ Aletheia CQE System initialized")
40	    
41	    def analyze_egyptian(self, image_paths):
42	        """Analyze Egyptian hieroglyphic images."""
43	        self.logger.info(f"Analyzing {len(image_paths)} Egyptian images...")
44	        results = self.egyptian_analyzer.analyze_images(image_paths)
45	        return results
46	    
47	    def synthesize_knowledge(self, data_files):
48	        """Synthesize knowledge from analysis data."""
49	        self.logger.info(f"Synthesizing knowledge from {len(data_files)} data files...")
50	        synthesis = self.aletheia_ai.synthesize(data_files)
51	        return synthesis
52	    
53	    def query(self, query_text):
54	        """Query the Aletheia AI with geometric intent."""
55	        self.logger.info(f"Processing query: {query_text}")
56	        response = self.aletheia_ai.process_query(query_text)
57	        return response
58	    
59	    def interactive_mode(self):
60	        """Enter interactive mode."""
61	        self.logger.info("Entering interactive mode...")
62	        print("\n" + "="*80)
63	        print("ALETHEIA CQE OPERATING SYSTEM - Interactive Mode")
64	        print("="*80)
65	        print("\nCommands:")
66	        print("  analyze <path>  - Analyze Egyptian images")
67	        print("  query <text>    - Query the AI")
68	        print("  synthesize      - Synthesize all available data")
69	        print("  status          - Show system status")
70	        print("  help            - Show this help")
71	        print("  exit            - Exit interactive mode")
72	        print()
73	        
74	        while True:
75	            try:
76	                cmd = input("aletheia> ").strip()
77	                
78	                if not cmd:
79	                    continue
80	                elif cmd == "exit":
81	                    print("Exiting Aletheia...")
82	                    break
83	                elif cmd == "help":
84	                    print("Commands: analyze, query, synthesize, status, help, exit")
85	                elif cmd == "status":
86	                    self._show_status()
87	                elif cmd.startswith("query "):
88	                    query_text = cmd[6:]
89	                    response = self.query(query_text)
90	                    print(f"\n{response}\n")
91	                elif cmd.startswith("analyze "):
92	                    path = cmd[8:]
93	                    results = self.analyze_egyptian([path])
94	                    print(f"\nAnalysis complete: {results}\n")
95	                elif cmd == "synthesize":
96	                    synthesis = self.synthesize_knowledge([])
97	                    print(f"\nSynthesis complete: {synthesis}\n")
98	                else:
99	                    print(f"Unknown command: {cmd}. Type 'help' for available commands.")
100	                    
101	            except KeyboardInterrupt:
102	                print("\nInterrupted. Type 'exit' to quit.")
103	            except Exception as e:
104	                print(f"Error: {e}")
105	    
106	    def _show_status(self):
107	        """Show system status."""
108	        print("\n" + "="*80)
109	        print("ALETHEIA CQE SYSTEM STATUS")
110	        print("="*80)
111	        print(f"Version: {__version__}")
112	        print(f"CQE Engine: {self.cqe_engine.status()}")
113	        print(f"Aletheia AI: {self.aletheia_ai.status()}")
114	        print(f"Egyptian Analyzer: {self.egyptian_analyzer.status()}")
115	        print("="*80 + "\n")
116	
117	
118	def main():
119	    """Main entry point."""
120	    parser = argparse.ArgumentParser(
121	        description="Aletheia CQE Operating System",
122	        formatter_class=argparse.RawDescriptionHelpFormatter,
123	        epilog="""
124	Examples:
125	  python aletheia.py --mode interactive
126	  python aletheia.py --mode analyze --input images/
127	  python aletheia.py --mode query --text "Explain E8 projection"
128	        """
129	    )
130	    
131	    parser.add_argument(
132	        "--mode",
133	        choices=["analyze", "synthesize", "query", "interactive"],
134	        default="interactive",
135	        help="Operating mode"
136	    )
137	    
138	    parser.add_argument(
139	        "--input",
140	        help="Input file or directory"
141	    )
142	    
143	    parser.add_argument(
144	        "--text",
145	        help="Query text (for query mode)"
146	    )
147	    
148	    parser.add_argument(
149	        "--output",
150	        help="Output file or directory"
151	    )
152	    
153	    parser.add_argument(
154	        "--verbose", "-v",
155	        action="store_true",
156	        help="Verbose output"
157	    )
158	    
159	    parser.add_argument(
160	        "--version",
161	        action="version",
162	        version=f"Aletheia CQE System v{__version__}"
163	    )
164	    
165	    args = parser.parse_args()
166	    
167	    # Initialize system
168	    system = AletheiaSystem(verbose=args.verbose)
169	    
170	    # Execute based on mode
171	    if args.mode == "interactive":
172	        system.interactive_mode()
173	    elif args.mode == "analyze":
174	        if not args.input:
175	            print("Error: --input required for analyze mode")
176	            sys.exit(1)
177	        results = system.analyze_egyptian([args.input])
178	        print(f"Analysis complete: {results}")
179	    elif args.mode == "query":
180	        if not args.text:
181	            print("Error: --text required for query mode")
182	            sys.exit(1)
183	        response = system.query(args.text)
184	        print(response)
185	    elif args.mode == "synthesize":
186	        synthesis = system.synthesize_knowledge([])
187	        print(f"Synthesis complete: {synthesis}")
188	
189	
190	if __name__ == "__main__":
191	    main()
192	
193	