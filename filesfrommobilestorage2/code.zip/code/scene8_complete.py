Text file: scene8_complete.py
Latest content with line numbers:
551	    
552	    def _rasterize_cpu(self, coords_3d: np.ndarray,
553	                      camera_pos: np.ndarray,
554	                      camera_target: np.ndarray) -> np.ndarray:
555	        """CPU fallback rasterization."""
556	        # Create blank image
557	        pixels = np.zeros((self.height, self.width, 3), dtype=np.uint8)
558	        
559	        # Simple orthographic projection to screen space
560	        # Map 3D coords to screen coordinates
561	        x, y, z = coords_3d
562	        
563	        # Map to screen (assuming coords in [-5, 5] range)
564	        sx = int((x + 5) / 10 * (self.width - 1))
565	        sy = int((y + 5) / 10 * (self.height - 1))
566	        
567	        # Clamp to screen bounds
568	        sx = max(0, min(self.width - 1, sx))
569	        sy = max(0, min(self.height - 1, sy))
570	        
571	        # Draw point with radius
572	        radius = 5
573	        for dy in range(-radius, radius + 1):
574	            for dx in range(-radius, radius + 1):
575	                if dx*dx + dy*dy <= radius*radius:
576	                    px = sx + dx
577	                    py = sy + dy
578	                    if 0 <= px < self.width and 0 <= py < self.height:
579	                        # Color based on depth (z coordinate)
580	                        color_intensity = int((z + 5) / 10 * 255)
581	                        color_intensity = max(0, min(255, color_intensity))
582	                        pixels[py, px] = [0, color_intensity, 0]  # Green
583	        
584	        return pixels
585	    
586	    def render_from_prompt(self, prompt: str,
587	                          duration: float = 1.0,
588	                          fps: float = 30.0,
589	                          ghost_run_first: bool = True) -> VideoStream:
590	        """
591	        Render video from natural language prompt using mini AI.
592	        
593	        This is the main entry point that demonstrates CQE principles:
594	        1. Intent-as-Slice (understand prompt)
595	        2. Ghost-run (simulate before commit)
596	        3. Geometric generation (E8 trajectory → frames)
597	        4. Governance (ΔΦ, DR, parity checks)
598	        5. Provenance (full receipts)
599	        
600	        Args:
601	            prompt: Natural language description
602	            duration: Video duration in seconds
603	            fps: Frames per second
604	            ghost_run_first: Whether to ghost-run before rendering
605	        
606	        Returns:
607	            VideoStream with rendered frames
608	        """
609	        num_frames = max(1, int(duration * fps))
610	        
611	        # Step 1: Understand prompt (Intent-as-Slice)
612	        print(f"\n[1] Understanding prompt: '{prompt}'")
613	        intent = self.ai.understand_prompt(prompt, num_frames)
614	        print(f"  Selected action: {intent.action}")
615	        print(f"  Projection type: {intent.projection_type}")
616	        print(f"  Digital root: {intent.digital_root}")
617	        print(f"  Parity: {intent.parity}")
618	        print(f"  Score: {intent.score:.4f}")
619	        
620	        # Step 2: Ghost-run (simulate before commit)
621	        if ghost_run_first:
622	            print(f"\n[2] Ghost-run (simulating before commit)...")
623	            prediction = self.ai.ghost_run(intent)
624	            print(f"  ΔΦ: {prediction['delta_phi']:.4f}")
625	            print(f"  Entropy decreasing: {prediction['entropy_decreasing']}")
626	            print(f"  DR stable: {prediction['digital_root_stable']}")
627	            print(f"  Parity consistent: {prediction['parity_consistent']}")
628	            print(f"  Passes governance: {prediction['passes_governance']}")
629	            print(f"  Estimated time: {prediction['estimated_render_time']:.2f}s")
630	            
631	            if not prediction['passes_governance']:
632	                print("  WARNING: Ghost-run predicts governance failure!")
633	        
634	        # Step 3: Render frames from E8 trajectory
635	        print(f"\n[3] Rendering {num_frames} frames...")
636	        frames = []
637	        
638	        for i, e8_state in enumerate(intent.e8_trajectory):
639	            frame = self.render_frame(
640	                e8_state,
641	                projection_type=intent.projection_type
642	            )
643	            frame.frame_number = i
644	            frames.append(frame)
645	            
646	            if (i + 1) % 10 == 0:
647	                print(f"  Rendered {i + 1}/{num_frames} frames...")
648	        
649	        # Step 4: Create video stream
650	        world_id = hashlib.md5(prompt.encode()).hexdigest()[:8]