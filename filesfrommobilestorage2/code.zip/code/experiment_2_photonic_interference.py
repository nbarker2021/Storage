#!/usr/bin/env python3.11
"""
Experiment 2: Photonic Interference Validation

Objective: Validate that search beams behave like photons

Method:
1. Implement Scene8 test scene with 24 Niemeier beams
2. Set up interference pattern (constructive/destructive)
3. Measure ΔΦ at beam intersections
4. Compare to predicted photonic behavior

Success Criteria:
- Constructive interference → ΔΦ ≤ 0 (commit)
- Destructive interference → ΔΦ > 0 (refuse)
- Beam lock-in to stable modes
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_complete_v1/core_system')

import numpy as np
import json
from pathlib import Path
from typing import List, Tuple, Dict

# ============================================================================
# PHOTONIC BEAM MODEL
# ============================================================================

class PhotonicBeam:
    """
    A photonic search beam in E₈/Λ₂₄ space.
    
    Properties:
    - Direction vector (unit vector in 24D)
    - Phase (0 to 2π)
    - Amplitude (energy/intensity)
    - Polarization (E₈ sublattice index)
    """
    
    def __init__(
        self,
        direction: np.ndarray,  # 24D unit vector
        phase: float = 0.0,
        amplitude: float = 1.0,
        polarization: int = 0
    ):
        self.direction = direction / np.linalg.norm(direction)
        self.phase = phase
        self.amplitude = amplitude
        self.polarization = polarization
    
    def field_at(self, position: np.ndarray) -> complex:
        """
        Compute complex field amplitude at position.
        
        E(x) = A * exp(i * (k·x + φ))
        where k = direction, φ = phase
        """
        k_dot_x = np.dot(self.direction, position)
        return self.amplitude * np.exp(1j * (k_dot_x + self.phase))
    
    def intensity_at(self, position: np.ndarray) -> float:
        """Compute intensity |E|² at position."""
        field = self.field_at(position)
        return np.abs(field) ** 2

class BeamInterference:
    """Model interference between multiple photonic beams."""
    
    def __init__(self, beams: List[PhotonicBeam]):
        self.beams = beams
    
    def total_field(self, position: np.ndarray) -> complex:
        """Compute total field from all beams (superposition)."""
        return sum(beam.field_at(position) for beam in self.beams)
    
    def total_intensity(self, position: np.ndarray) -> float:
        """Compute total intensity |E_total|²."""
        field = self.total_field(position)
        return np.abs(field) ** 2
    
    def interference_type(self, position: np.ndarray) -> str:
        """
        Determine interference type at position.
        
        Constructive: I_total > Σ I_individual
        Destructive: I_total < Σ I_individual
        """
        total_intensity = self.total_intensity(position)
        sum_intensities = sum(beam.intensity_at(position) for beam in self.beams)
        
        if total_intensity > sum_intensities * 1.1:  # 10% threshold
            return "constructive"
        elif total_intensity < sum_intensities * 0.9:
            return "destructive"
        else:
            return "neutral"
    
    def compute_delta_phi(self, position: np.ndarray) -> float:
        """
        Compute ΔΦ based on interference pattern.
        
        Hypothesis: 
        - Constructive interference → ΔΦ ≤ 0 (energy decreases, stable)
        - Destructive interference → ΔΦ > 0 (energy increases, unstable)
        """
        total_intensity = self.total_intensity(position)
        sum_intensities = sum(beam.intensity_at(position) for beam in self.beams)
        
        # ΔΦ = (I_total - Σ I_i) / Σ I_i
        # Normalized change in intensity
        if sum_intensities > 1e-10:
            delta_phi = (total_intensity - sum_intensities) / sum_intensities
        else:
            delta_phi = 0.0
        
        return delta_phi

# ============================================================================
# NIEMEIER LATTICE BEAMS
# ============================================================================

def generate_niemeier_beams(num_beams: int = 24) -> List[PhotonicBeam]:
    """
    Generate 24 photonic beams corresponding to Niemeier lattice structure.
    
    The 24 Niemeier lattices are 24-dimensional even unimodular lattices.
    We model them as 24 beams with specific dihedral symmetry.
    """
    beams = []
    
    for i in range(num_beams):
        # Direction: rotate through 24D space with dihedral D₁₂ symmetry
        angle = 2 * np.pi * i / num_beams
        
        # Create direction vector with dihedral structure
        direction = np.zeros(24)
        
        # First 12 components: cos pattern
        for j in range(12):
            direction[j] = np.cos(angle + 2 * np.pi * j / 12)
        
        # Last 12 components: sin pattern (dual)
        for j in range(12):
            direction[12 + j] = np.sin(angle + 2 * np.pi * j / 12)
        
        # Phase: evenly distributed
        phase = 2 * np.pi * i / num_beams
        
        # Amplitude: unit
        amplitude = 1.0
        
        # Polarization: E₈ sublattice (3 E₈ in 24D)
        polarization = i % 3
        
        beams.append(PhotonicBeam(direction, phase, amplitude, polarization))
    
    return beams

# ============================================================================
# EXPERIMENT RUNNER
# ============================================================================

class PhotonicInterferenceExperiment:
    """Run the photonic interference experiment."""
    
    def __init__(self):
        print("Initializing Photonic Interference Experiment...")
        
        # Generate 24 Niemeier beams
        self.beams = generate_niemeier_beams(24)
        print(f"  Generated {len(self.beams)} Niemeier beams")
        
        # Test positions in 24D space
        self.test_positions = self.generate_test_positions(100)
        print(f"  Generated {len(self.test_positions)} test positions")
        
        # Results storage
        self.results = []
    
    def generate_test_positions(self, num_positions: int) -> List[np.ndarray]:
        """Generate test positions in 24D space."""
        positions = []
        
        # Grid of positions
        for i in range(num_positions):
            # Random position in unit hypercube
            pos = np.random.randn(24) * 0.5
            positions.append(pos)
        
        return positions
    
    def test_beam_pair(
        self,
        beam1: PhotonicBeam,
        beam2: PhotonicBeam,
        position: np.ndarray
    ) -> Dict:
        """Test interference between two beams."""
        interference = BeamInterference([beam1, beam2])
        
        # Compute interference properties
        int_type = interference.interference_type(position)
        delta_phi = interference.compute_delta_phi(position)
        total_intensity = interference.total_intensity(position)
        
        # Individual intensities
        i1 = beam1.intensity_at(position)
        i2 = beam2.intensity_at(position)
        
        # Phase difference
        field1 = beam1.field_at(position)
        field2 = beam2.field_at(position)
        phase_diff = np.angle(field1) - np.angle(field2)
        
        return {
            'interference_type': int_type,
            'delta_phi': delta_phi,
            'total_intensity': total_intensity,
            'intensity_1': i1,
            'intensity_2': i2,
            'phase_difference': phase_diff,
            'position_norm': np.linalg.norm(position)
        }
    
    def run_pairwise_tests(self):
        """Test all pairs of beams at all positions."""
        print("\nRunning pairwise beam interference tests...")
        
        num_pairs = 0
        constructive_count = 0
        destructive_count = 0
        neutral_count = 0
        
        constructive_delta_phi = []
        destructive_delta_phi = []
        
        # Test select pairs (not all 24×24 = 576, just representative)
        test_pairs = [
            (0, 1),   # Adjacent beams
            (0, 6),   # Opposite beams (π phase difference)
            (0, 12),  # Orthogonal (different E₈ sublattice)
            (1, 13),  # Cross-sublattice
            (5, 17),  # Another cross-sublattice
        ]
        
        for i, j in test_pairs:
            beam1 = self.beams[i]
            beam2 = self.beams[j]
            
            for pos in self.test_positions:
                result = self.test_beam_pair(beam1, beam2, pos)
                result['beam_pair'] = (i, j)
                self.results.append(result)
                
                num_pairs += 1
                
                if result['interference_type'] == 'constructive':
                    constructive_count += 1
                    constructive_delta_phi.append(result['delta_phi'])
                elif result['interference_type'] == 'destructive':
                    destructive_count += 1
                    destructive_delta_phi.append(result['delta_phi'])
                else:
                    neutral_count += 1
        
        print(f"  Tested {num_pairs} beam pair × position combinations")
        print(f"  Constructive: {constructive_count} ({constructive_count/num_pairs:.1%})")
        print(f"  Destructive: {destructive_count} ({destructive_count/num_pairs:.1%})")
        print(f"  Neutral: {neutral_count} ({neutral_count/num_pairs:.1%})")
        
        return constructive_delta_phi, destructive_delta_phi
    
    def analyze_results(
        self,
        constructive_delta_phi: List[float],
        destructive_delta_phi: List[float]
    ):
        """Analyze results and check hypothesis."""
        print(f"\n{'='*70}")
        print("ANALYSIS")
        print(f"{'='*70}")
        
        # Constructive interference statistics
        if constructive_delta_phi:
            c_mean = np.mean(constructive_delta_phi)
            c_std = np.std(constructive_delta_phi)
            c_min = np.min(constructive_delta_phi)
            c_max = np.max(constructive_delta_phi)
            c_negative_ratio = sum(1 for x in constructive_delta_phi if x <= 0) / len(constructive_delta_phi)
            
            print("\nConstructive Interference:")
            print(f"  ΔΦ mean: {c_mean:.6f}")
            print(f"  ΔΦ std: {c_std:.6f}")
            print(f"  ΔΦ range: [{c_min:.6f}, {c_max:.6f}]")
            print(f"  ΔΦ ≤ 0 ratio: {c_negative_ratio:.1%}")
        
        # Destructive interference statistics
        if destructive_delta_phi:
            d_mean = np.mean(destructive_delta_phi)
            d_std = np.std(destructive_delta_phi)
            d_min = np.min(destructive_delta_phi)
            d_max = np.max(destructive_delta_phi)
            d_positive_ratio = sum(1 for x in destructive_delta_phi if x > 0) / len(destructive_delta_phi)
            
            print("\nDestructive Interference:")
            print(f"  ΔΦ mean: {d_mean:.6f}")
            print(f"  ΔΦ std: {d_std:.6f}")
            print(f"  ΔΦ range: [{d_min:.6f}, {d_max:.6f}]")
            print(f"  ΔΦ > 0 ratio: {d_positive_ratio:.1%}")
        
        return {
            'constructive': {
                'mean_delta_phi': c_mean if constructive_delta_phi else None,
                'negative_ratio': c_negative_ratio if constructive_delta_phi else None
            },
            'destructive': {
                'mean_delta_phi': d_mean if destructive_delta_phi else None,
                'positive_ratio': d_positive_ratio if destructive_delta_phi else None
            }
        }
    
    def check_success_criteria(self, analysis: Dict) -> bool:
        """Check if experiment met success criteria."""
        print(f"\n{'='*70}")
        print("SUCCESS CRITERIA")
        print(f"{'='*70}")
        
        # Criterion 1: Constructive interference → ΔΦ ≤ 0
        c_ratio = analysis['constructive']['negative_ratio']
        c_pass = c_ratio is not None and c_ratio > 0.5  # Majority should be ≤ 0
        print(f"\n1. Constructive interference → ΔΦ ≤ 0: {'✓ PASS' if c_pass else '✗ FAIL'}")
        if c_ratio is not None:
            print(f"   (ΔΦ ≤ 0 ratio: {c_ratio:.1%}, target: >50%)")
        
        # Criterion 2: Destructive interference → ΔΦ > 0
        d_ratio = analysis['destructive']['positive_ratio']
        d_pass = d_ratio is not None and d_ratio > 0.5  # Majority should be > 0
        print(f"\n2. Destructive interference → ΔΦ > 0: {'✓ PASS' if d_pass else '✗ FAIL'}")
        if d_ratio is not None:
            print(f"   (ΔΦ > 0 ratio: {d_ratio:.1%}, target: >50%)")
        
        # Criterion 3: Mean ΔΦ has correct sign
        c_mean = analysis['constructive']['mean_delta_phi']
        d_mean = analysis['destructive']['mean_delta_phi']
        mean_pass = (c_mean is not None and c_mean <= 0) and (d_mean is not None and d_mean >= 0)
        print(f"\n3. Mean ΔΦ has correct sign: {'✓ PASS' if mean_pass else '✗ FAIL'}")
        if c_mean is not None and d_mean is not None:
            print(f"   (Constructive mean: {c_mean:.6f}, Destructive mean: {d_mean:.6f})")
        
        all_pass = c_pass and d_pass and mean_pass
        
        print(f"\n{'='*70}")
        print(f"OVERALL: {'✓ ALL CRITERIA PASSED' if all_pass else '✗ SOME CRITERIA FAILED'}")
        print(f"{'='*70}")
        
        return all_pass
    
    def save_results(self, output_dir: str = "/home/ubuntu/experiment_2_results"):
        """Save results to JSON."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save raw results
        with open(output_path / "raw_results.json", 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\nResults saved to {output_dir}")
    
    def run(self):
        """Run complete experiment."""
        print("\n" + "="*70)
        print("EXPERIMENT 2: PHOTONIC INTERFERENCE VALIDATION")
        print("="*70)
        
        # Run pairwise tests
        constructive_delta_phi, destructive_delta_phi = self.run_pairwise_tests()
        
        # Analyze results
        analysis = self.analyze_results(constructive_delta_phi, destructive_delta_phi)
        
        # Check success criteria
        success = self.check_success_criteria(analysis)
        
        # Save results
        self.save_results()
        
        return success, analysis

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    experiment = PhotonicInterferenceExperiment()
    success, analysis = experiment.run()
    
    print("\n" + "="*70)
    print("EXPERIMENT COMPLETE")
    print("="*70)
    print(f"Success: {success}")

