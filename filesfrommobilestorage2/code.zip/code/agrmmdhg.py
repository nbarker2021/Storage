Text file: agrmmdhg.py
Reading lines: 1-500 (file has 2558 lines)
Latest content with line numbers:
1	# ===========================================================
2	# === AGRM System Implementation Codebase (Final Version) ===
3	# ===========================================================
4	# Based on validated blueprint derived from user documents and session discussion.
5	# Includes: Multi-agent architecture, Modulation Controller, Bidirectional Builder,
6	# Salesman Validator/Patcher, Path Audit Agent, Hybrid Hashing,
7	# Ephemeral Memory (MDHG-Hash Integration), Dynamic Midpoint, Spiral Reentry,
8	# Comprehensive Comments.
9	
10	import math
11	import time
12	import random
13	from collections import deque, Counter, defaultdict
14	from typing import Any, Dict, List, Tuple, Set, Optional, Union
15	import numpy as np # Assuming numpy is available for calculations like norm
16	
17	# Try importing sklearn for KDTree, but provide fallback
18	try:
19	    from sklearn.neighbors import KDTree, BallTree
20	    HAS_SKLEARN = True
21	except ImportError:
22	    HAS_SKLEARN = False
23	    print("WARNING: scikit-learn not found. Neighbor searches will use less efficient fallback.")
24	
25	# ===========================================================
26	# === Multi-Dimensional Hamiltonian Golden Ratio Hash Table ===
27	# ===========================================================
28	# Full implementation based on user-provided code and description.
29	# Source: User Upload mdhg_hash.py content [cite: 1027-1096]
30	# Integrated into AGRM system for high-complexity state/cache (n>5).
31	
32	class MDHGHashTable:
33	    """
34	    Multi-Dimensional Hamiltonian Golden Ratio Hash Table.
35	    A hash table implementation that uses multi-dimensional organization,
36	    Hamiltonian paths for navigation, and golden ratio-based sizing
37	    to achieve optimal performance for structured access patterns.
38	
39	    AGRM Integration Notes:
40	    - Used for complex state (n>5) in AGRM's hybrid hashing.
41	    - Stores values as tuples: (actual_value, metadata_dict),
42	      where metadata_dict contains flags like {'source': 'dict', 'retain_flag': True}.
43	    - Adaptation logic can be influenced by Modulation Controller signals.
44	    - Includes full logic for buildings, floors, rooms (conceptual), velocity region,
45	      dimensional core, conflict handling, Hamiltonian path navigation, and dynamic adaptation.
46	    """
47	    def __init__(self, capacity: int = 1024, dimensions: int = 3, load_factor_threshold: float = 0.75, config: Dict = {}):
48	        """
49	        Initialize the hash table.
50	        Args:
51	            capacity: Initial capacity of the hash table
52	            dimensions: Number of dimensions for the hash space (tunable by AGRM context)
53	            load_factor_threshold: When to resize the table
54	            config: Dictionary for additional MDHG-specific parameters
55	        """
56	        self.PHI = (1 + math.sqrt(5)) / 2 # Golden ratio [cite: 1018-1019]
57	        self.config = config # Store config for internal use
58	
59	        # Core configuration
60	        self.capacity = max(capacity, 16) # Ensure minimum capacity
61	        self.dimensions = max(dimensions, 1) # Ensure at least 1 dimension
62	        self.load_factor_threshold = load_factor_threshold
63	        self.size = 0
64	
65	        # Multi-dimensional organization [cite: 1012-1017]
66	        self.buildings = self._initialize_buildings()
67	        self.location_map = {} # Maps keys to their current location (building_id, region_type, location_spec)
68	
69	        # Navigation components
70	        self.hamiltonian_paths = {} # Pre-computed paths for critical points [cite: 1020-1022, 1037]
71	        self.path_cache = {} # Cache of paths between points or for key sets
72	        self.shortcuts = {} # Direct connections between buildings/regions [cite: 1022]
73	
74	        # Access pattern tracking
75	        self.access_history = deque(maxlen=config.get("mdhg_access_history_len", 100)) # Track recent accesses
76	        self.access_frequency = Counter() # Track frequency of key access
77	        self.co_access_matrix = defaultdict(Counter) # Track keys accessed together [cite: 1022]
78	        self.path_usage = Counter() # Track usage of cached paths
79	
80	        # Statistics
81	        self.stats = {
82	            'puts': 0, 'gets': 0, 'hits': 0, 'misses': 0, 'collisions': 0,
83	            'probes_total': 0, 'max_probes': 0, 'reorganizations': 0,
84	            'resizes': 0, 'promotions_velocity': 0, 'relocations_from_velocity': 0,
85	            'clusters_relocated': 0
86	        }
87	
88	        # Optimization timing
89	        self.last_minor_optimization = time.time()
90	        self.last_major_optimization = time.time()
91	        self.operations_since_optimization = 0
92	
93	        # Initialize the structure (compute initial paths, etc.)
94	        self._initialize_structure()
95	        print(f"MDHGHashTable initialized: Capacity={self.capacity}, Dimensions={self.dimensions}, Buildings={len(self.buildings)}")
96	
97	    def _initialize_buildings(self) -> Dict:
98	        """ Initialize the building structure based on golden ratio proportions. """
99	        # Determine number of buildings, ensuring at least 1
100	        building_count = max(1, int(math.log(max(2, self.capacity), self.PHI)))
101	        buildings = {}
102	        # Ensure base capacity calculation avoids division by zero
103	        base_capacity_per_building = self.capacity // building_count if building_count > 0 else self.capacity
104	        if base_capacity_per_building < 16: base_capacity_per_building = 16 # Ensure minimum size
105	
106	        print(f"  MDHG: Initializing {building_count} buildings, base capacity per building: {base_capacity_per_building}")
107	
108	        for b in range(building_count):
109	            building_id = f"B{b}"
110	            # Calculate regions using golden ratio [cite: 1018]
111	            # Ensure minimum sizes for regions
112	            velocity_region_size = max(4, int(base_capacity_per_building / (self.PHI ** 2)))
113	            core_region_base_size = max(8, int(velocity_region_size * self.PHI)) # Base size before dimensioning
114	
115	            dimension_sizes = self._calculate_dimension_sizes(core_region_base_size)
116	            # Actual core capacity is product of dimension sizes
117	            core_capacity = math.prod(dimension_sizes) if dimension_sizes else 0
118	
119	            print(f"    Building {building_id}: Velocity Region Size={velocity_region_size}, Core Capacity={core_capacity}, Dim Sizes={dimension_sizes}")
120	
121	            buildings[building_id] = {
122	                'velocity_region': [None] * velocity_region_size, # Fast access [cite: 1022]
123	                'dimensional_core': {}, # Main storage, dict maps coords -> (key, value_tuple) [cite: 1022]
124	                'conflict_structures': {}, # Handles collisions beyond path probing [cite: 1022]
125	                'dimension_sizes': dimension_sizes, # For coordinate calculation
126	                'hot_keys': set(), # Keys frequently accessed in this building
127	                'access_count': 0, # Track building usage
128	                'core_capacity': core_capacity # Store calculated core capacity
129	            }
130	        return buildings
131	
132	    def _calculate_dimension_sizes(self, core_region_base_size: int) -> List[int]:
133	        """ Calculate sizes for each dimension using golden ratio proportions. """
134	        if self.dimensions <= 0: return []
135	        # Estimate base size per dimension
136	        # Using geometric mean approach: base_size ^ dimensions ≈ core_region_base_size
137	        # Add epsilon to avoid potential log(0) or root(0) issues if base_size is tiny
138	        safe_base_size = max(1, core_region_base_size)
139	        base_size = max(2.0, safe_base_size ** (1.0/self.dimensions)) # Use float for calculation
140	
141	        sizes = []
142	        product = 1.0
143	        # Scale dimensions using PHI, ensuring minimum size 2
144	        for i in range(self.dimensions):
145	            # Example scaling: could use other GR-based factors
146	            # Ensure denominator is safe
147	            phi_exponent = i / max(1.0, float(self.dimensions - 1))
148	            size_float = base_size / (self.PHI ** phi_exponent)
149	            size = max(2, int(round(size_float))) # Round before int conversion
150	            sizes.append(size)
151	            product *= size
152	
153	        # Optional: Adjust sizes slightly if product is too far off target
154	        # This part requires careful balancing logic to avoid infinite loops or drastic changes
155	        # print(f"      Calculated dimension sizes: {sizes} (Product: {product}, Target Base: {core_region_base_size})")
156	        return sizes
157	
158	    def _initialize_structure(self):
159	        """ Initialize the hash table structure with navigation components. """
160	        # Pre-compute critical Hamiltonian paths for each building [cite: 1037]
161	        print("  MDHG: Initializing structure (paths, shortcuts)...")
162	        for building_id, building in self.buildings.items():
163	            self._initialize_building_paths(building_id, building)
164	        # Initialize shortcuts between buildings
165	        self._initialize_building_shortcuts()
166	        print("  MDHG: Structure initialization complete.")
167	
168	
169	    def _initialize_building_paths(self, building_id: str, building: Dict):
170	        """ Initialize Hamiltonian paths for critical points in a building. """
171	        dimension_sizes = building.get('dimension_sizes')
172	        if not dimension_sizes:
173	            # print(f"    Skipping path init for {building_id}: No dimensions.")
174	            return # Skip if no dimensions
175	
176	        # Generate critical points (corners, center)
177	        critical_points = set()
178	        # Add corner points
179	        corners = self._generate_corner_points(dimension_sizes)
180	        critical_points.update(corners)
181	        # Add center point
182	        center = tuple(d // 2 for d in dimension_sizes)
183	        critical_points.add(center)
184	
185	        # Compute and store paths for these critical points
186	        building_paths = {}
187	        computed_count = 0
188	        for point in critical_points:
189	            # Ensure point is valid within dimensions
190	            if len(point) != self.dimensions: continue
191	            valid_point = all(0 <= point[i] < dimension_sizes[i] for i in range(self.dimensions))
192	
193	            if valid_point:
194	                path = self._compute_hamiltonian_path(building_id, point)
195	                if path: # Only store if path computation succeeds
196	                    path_key = (building_id, point)
197	                    building_paths[path_key] = path # Store paths per building first
198	                    computed_count += 1
199	
200	        self.hamiltonian_paths.update(building_paths) # Add building paths to global store
201	        # print(f"    Initialized {computed_count} Hamiltonian paths for building {building_id}.")
202	
203	
204	    def _generate_corner_points(self, dimension_sizes: List[int]) -> List[Tuple]:
205	        """ Generate corner points for a multi-dimensional space. """
206	        if not dimension_sizes: return []
207	        corners = []
208	        num_dims = len(dimension_sizes)
209	        num_corners = 2 ** num_dims
210	        for i in range(num_corners):
211	(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)