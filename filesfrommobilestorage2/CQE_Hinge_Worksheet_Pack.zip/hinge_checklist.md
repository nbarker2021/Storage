# CQE Hinge @ n=4→5 — Hand Worksheet

This packet lets you verify, by hand, that:
1) n=4 canonicalizes to a unique palindromic rest on the 4×4 grid;
2) n=5 cannot be added without opening **exactly eight** inequivalent insertion classes (the octad).

## Materials
- `grid_blank.png` — print several copies
- `grid_guide.png` — reference for axis vs off-axis exemplars
- Pen/pencil + two colors (parity lanes)

## Steps
1. **Build the n=4 rest**  
   - Place symbols 1–4 using parity-preserving overlaps.  
   - Resolve forks by Alena priorities (palindromic fix → minimal defects → minimal motion → avoid Joker → lowest rank).  
   - Re-run canonicalization once; the layout should be unchanged (idempotence).

2. **Enumerate n=5 insertions (16 loci)**
   - For each cell on a fresh blank grid: insert ‘5’, run local repairs without using >1 Joker.  
   - Mark whether the result re-canonicalizes to a rest.

3. **Quotient by symmetry**  
   - Group successful loci by dihedral symmetries with parity (rotations/reflections preserve class).  
   - You should have **eight** inequivalent classes (compare with `grid_guide.png`).  
   - Identify which class re-canonicalizes to a palindrome (expect 1 palindromic + 7 invariant non-palindromes).

4. **Record receipts**
   - Parity Lock: forward/back mirror passes.  
   - Idempotence: canonicalization stable.  
   - Rotation Invariance: class label preserved up to permutation under D8.  
   - Octad Necessity: exactly eight inequivalent classes.

## Falsifiers (keep these live)
- **F1**: lawful n=5 extension with <8 or >8 classes.  
- **F2**: lawful n=4 covering that cannot be palindromized under Alena.  
- **F3**: a “palindromic” n=5 class that fails idempotence on replay.  
- **F4**: rotation/mirror maps a class outside the octad orbit.

If any F1–F4 holds, the hinge claim fails and CQE must adjust.

---

## Notes
- The light gray top/bottom rows indicate parity lanes.
- “Axis” vs “Off” markers in `grid_guide.png` are *exemplars only*; all eight classes are defined **up to symmetry with parity**.
