from dataclasses import dataclass, field
from typing import List, Dict, Any

SUIT_COLOR = {0:0, 1:0, 2:1, 3:1}

@dataclass
class Carrier:
    symbols: List[int]
    faces: List[int]
    suits: List[int]
    meta: Dict[str, Any] = field(default_factory=dict)

    def reverse(self):
        return Carrier(self.symbols[::-1], self.faces[::-1], self.suits[::-1], dict(self.meta))

    def mirror(self):
        swap = {0:2, 2:0, 1:3, 3:1}
        faces = [1 - f for f in self.faces]
        suits = [swap[s] for s in self.suits]
        return Carrier(list(self.symbols), faces, suits, dict(self.meta))

    def parity_lane(self) -> List[int]:
        return [SUIT_COLOR[s] for s in self.suits]

    def hamming_to(self, other) -> int:
        d = 0
        for a,b in zip(self.symbols, other.symbols): d += 0 if a==b else 1
        for a,b in zip(self.faces, other.faces): d += 0 if a==b else 1
        for a,b in zip(self.suits, other.suits): d += 0 if a==b else 1
        return d

    def run_lengths(self) -> int:
        if not self.faces: return 0
        mx = cur = 1
        for i in range(1, len(self.faces)):
            if self.faces[i] == self.faces[i-1]:
                cur += 1; mx = max(mx, cur)
            else:
                cur = 1
        return mx

    @classmethod
    def from_glyphs(cls, glyphset, seed=0):
        labels = [g.label() for g in glyphset.glyphs]
        uniq = sorted(set(labels))
        lut = {lab:i%53 for i,lab in enumerate(uniq)}
        symbols = [lut[lab] for lab in labels]
        faces = [ (len(lab) % 2) for lab in labels ]
        def suit_of(lab):
            h=0
            for ch in lab: h = (h*131 + ord(ch)) & 0xffffffff
            return h % 4
        suits = [suit_of(lab) for lab in labels]
        return cls(symbols, faces, suits, meta={"labels":labels})
