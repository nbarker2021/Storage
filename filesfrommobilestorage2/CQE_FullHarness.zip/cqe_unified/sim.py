from dataclasses import dataclass
from typing import List, Dict, Any
import random
from .carriers import Carrier

@dataclass
class Overlay:
    name: str
    carrier: Carrier

def gen_overlays(c: Carrier, seed=0) -> List[Overlay]:
    rnd = random.Random(seed)
    overlays = []
    overlays.append(Overlay("id", c))
    overlays.append(Overlay("reverse", c.reverse()))
    overlays.append(Overlay("mirror", c.mirror()))
    for k in (1,3,5):
        cc = Carrier(c.symbols[k:]+c.symbols[:k], c.faces[k:]+c.faces[:k], c.suits[k:]+c.suits[:k], dict(c.meta))
        overlays.append(Overlay(f"rot{k}", cc))
    idx = list(range(len(c.symbols)))
    rnd.shuffle(idx)
    cc = Carrier([c.symbols[i] for i in idx], [c.faces[i] for i in idx], [c.suits[i] for i in idx], dict(c.meta))
    overlays.append(Overlay("perm", cc))
    return overlays[:8]

def choose_pal_rest(c: Carrier, seed=0) -> Dict[str, Any]:
    overlays = gen_overlays(c, seed=seed)
    scored = []
    for ov in overlays:
        r = ov.carrier.reverse()
        score = ov.carrier.hamming_to(r)
        scored.append((score, ov))
    scored.sort(key=lambda x: (x[0], x[1].name))
    best_score, best_ov = scored[0]
    return {"pal_score":best_score, "choice":best_ov.name, "rest":best_ov.carrier,
            "overlays":[(s, ov.name) for s,ov in scored]}
