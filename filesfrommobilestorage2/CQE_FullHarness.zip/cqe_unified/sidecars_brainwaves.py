from .sidecars_dft import power_spectrum
BANDS = {"delta":(0.5,4.0),"theta":(4,8),"alpha":(8,12),"beta":(12,30),"gamma":(30,100)}
def band_power(signal, fs):
    ps = power_spectrum(signal)
    N = len(signal)
    freqs = [fs*k/N for k in range(N)]
    out={}
    for name,(f0,f1) in BANDS.items():
        p=0.0
        for f,pk in zip(freqs, ps):
            if f0 <= f <= f1: p += pk
        out[name]=p
    return out
