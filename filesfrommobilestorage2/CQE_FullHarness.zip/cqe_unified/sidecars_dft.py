import cmath, math
def dft(signal):
    N = len(signal); out=[]
    for k in range(N):
        s=0j
        for n in range(N):
            s += signal[n] * cmath.exp(-2j*math.pi*k*n/N)
        out.append(s)
    return out
def power_spectrum(signal):
    X = dft(signal)
    return [ (abs(z)**2)/len(signal) for z in X ]
