from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

@dataclass
class Glyph:
    observed: str
    declared: Optional[str]
    inferred: Optional[str]
    meta: Dict[str, Any] = field(default_factory=dict)

    def label(self) -> str:
        return self.observed or self.declared or self.inferred or ""

@dataclass
class GlyphSet:
    glyphs: List[Glyph]
    overrides: int = 0

    @classmethod
    def from_rows(cls, rows):
        gs = []
        overrides = 0
        for r in rows:
            g = Glyph(observed=r.get("observed",""),
                      declared=r.get("declared"),
                      inferred=r.get("inferred"),
                      meta={k:v for k,v in r.items() if k not in ("observed","declared","inferred")})
            base = g.declared or g.inferred
            if g.observed and base and g.observed != base:
                overrides += 1
            gs.append(g)
        return cls(gs, overrides)
