import json, hashlib

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")

def merkle_root(items):
    if not items:
        return sha256_bytes(b"")
    layer = [sha256_bytes(canonical_json(x)) for x in items]
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i+1] if i+1 < len(layer) else a
            nxt.append(sha256_bytes((a+b).encode("utf-8")))
        layer = nxt
    return layer[0]
