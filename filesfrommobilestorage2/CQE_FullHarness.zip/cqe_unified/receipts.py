from .carriers import Carrier
from .utils import merkle_root

def adjacent_swap_distance(a: Carrier, b: Carrier) -> int:
    pos_a = {}
    for i, val in enumerate(a.symbols):
        pos_a.setdefault(val, []).append(i)
    pos_b = {}
    for i, val in enumerate(b.symbols):
        pos_b.setdefault(val, []).append(i)
    dist = 0
    for val in pos_a.keys():
        la, lb = pos_a[val], pos_b.get(val, [])
        for i in range(min(len(la), len(lb))):
            dist += abs(la[i]-lb[i])
    return dist

def receipts(prev: Carrier, rest: Carrier, overrides: int, prev_bound: int=None):
    P = (rest.hamming_to(rest.reverse()) == 0)
    M = (rest.hamming_to(rest.mirror()) == 0)
    delta = adjacent_swap_distance(prev, rest)
    max_allowed = max(1, len(prev.symbols)//4)
    D = (delta <= max_allowed)
    prev_run = prev.run_lengths()
    rest_run = rest.run_lengths()
    S = (rest_run <= prev_run)
    L = (overrides > 0)
    return {"P":P,"M":M,"D":D,"S":S,"L":L,
            "metrics":{"adj_swap_dist":delta,"max_allowed":max_allowed,
                       "prev_run":prev_run,"rest_run":rest_run,"overrides":overrides}}

def commit(items):
    root = merkle_root(items)
    return {"merkle_root":root, "items":items}
