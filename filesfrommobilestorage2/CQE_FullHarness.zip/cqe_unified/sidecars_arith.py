def checksum_ints(ints):
    total = sum(ints)
    xorv = 0
    for x in ints: xorv ^= x
    return {"sum":total,"xor":xorv,"min":min(ints) if ints else 0,"max":max(ints) if ints else 0}
