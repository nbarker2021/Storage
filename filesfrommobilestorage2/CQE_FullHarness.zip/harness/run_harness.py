import os, json, argparse, csv, pathlib
from cqe_unified.glyphs import GlyphSet
from cqe_unified.carriers import Carrier
from cqe_unified.sim import choose_pal_rest
from cqe_unified.receipts import receipts, commit
from cqe_unified.ledger import Ledger
from cqe_unified.sidecars_brainwaves import band_power
from cqe_unified.sidecars_arith import checksum_ints

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "harness" / "out"
GOLDEN = ROOT / "harness" / "golden"
BASE = ROOT / "harness" / "baselines"

def read_csv_rows(p):
    with open(p, newline="") as f:
        r = csv.DictReader(f)
        return list(r)

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, sort_keys=True)

def run_glyphs_to_commit(cfg):
    gs = GlyphSet.from_rows(cfg["glyph_rows"])
    c0 = Carrier.from_glyphs(gs)
    pal = choose_pal_rest(c0, seed=cfg.get("seed",0))
    rest = pal["rest"]
    rec = receipts(prev=c0, rest=rest, overrides=gs.overrides)
    payload = [ {"name":cfg["name"]},
                {"overlays": pal["overlays"]},
                {"receipts": rec} ]
    com = commit(payload)
    return {"commit": com, "receipts": rec, "choice": pal["choice"], "pal_score": pal["pal_score"]}

def run_brainwaves(cfg):
    rows = []
    with open(ROOT / cfg["path"]) as f:
        rd = csv.DictReader(f)
        for r in rd: rows.append(r)
    sig = [float(r["signal"]) for r in rows]
    fs = cfg["fs"]
    bp = band_power(sig, fs)
    payload = [{"name":cfg["name"]},{"band_power":bp}]
    com = commit(payload)
    return {"commit":com, "band_power":bp}

def run_palrest_sweep(cfg):
    gs = GlyphSet.from_rows(cfg["glyph_rows"])
    c0 = Carrier.from_glyphs(gs)
    pal = choose_pal_rest(c0, seed=cfg.get("seed",0))
    rest = pal["rest"]
    rec = receipts(prev=c0, rest=rest, overrides=gs.overrides)
    payload = [{"name":cfg["name"]},{"choice":pal["choice"]},{"receipts":rec}]
    com = commit(payload)
    return {"commit":com, "choice":pal["choice"], "receipts":rec}

def run_sound(cfg):
    rows = []
    with open(ROOT / cfg["path"]) as f:
        rd = csv.DictReader(f)
        for r in rd: rows.append(r)
    amps = [float(r["amp"]) for r in rows]
    rolloff = amps[-1] / amps[0] if amps else 0.0
    payload = [{"name":cfg["name"]},{"rolloff":rolloff},{"n":len(amps)}]
    com = commit(payload)
    return {"commit":com, "rolloff":rolloff, "n":len(amps)}

def run_arith(cfg):
    res = checksum_ints(cfg["ints"])
    payload = [{"name":cfg["name"]},{"checksum":res}]
    com = commit(payload)
    return {"commit":com, "checksum":res}

def run_policy(cfg):
    users = read_csv_rows(ROOT / cfg["users"])
    rules = read_csv_rows(ROOT / cfg["rules"])
    decisions = []
    ctx_map = {u["user_id"]:u["context"] for u in users}
    allows = {r["rule"]:r["allow_context"] for r in rules}
    order = {"guest":0,"member":1,"admin":2}
    for uid,ctx in ctx_map.items():
        row = {"user":uid}
        for rule,ctx_req in allows.items():
            ok = (order[ctx] >= order[ctx_req])
            row[rule] = "ALLOW" if ok else "DENY"
        decisions.append(row)
    payload = [{"name":cfg["name"]},{"decisions":decisions}]
    com = commit(payload)
    return {"commit":com, "decisions":decisions}

def run_collision(cfg):
    gs = GlyphSet.from_rows(cfg["glyph_rows"])
    c0 = Carrier.from_glyphs(gs)
    label_to_sym = {}
    collisions = []
    for lab, sym in zip(c0.meta["labels"], c0.symbols):
        if sym in label_to_sym and label_to_sym[sym] != lab:
            collisions.append((sym, label_to_sym[sym], lab))
        else:
            label_to_sym[sym] = lab
    payload = [{"name":cfg["name"]},{"collisions":collisions}]
    com = commit(payload)
    return {"commit":com, "n_collisions":len(collisions),"collisions":collisions}

def run_replay(cfg):
    r1 = run_glyphs_to_commit(cfg)
    r2 = run_glyphs_to_commit(cfg)
    idem = (r1["commit"]["merkle_root"] == r2["commit"]["merkle_root"])
    payload = [{"name":cfg["name"]},{"idempotent":idem},{"root":r1["commit"]["merkle_root"]}]
    com = commit(payload)
    return {"commit":com, "idempotent":idem, "root":r1["commit"]["merkle_root"]}

def redact_text(s):
    return s.replace("name:","name:XXXX")

def run_redaction(cfg):
    rows = cfg["glyph_rows"]
    redacted = [redact_text(r["observed"]) for r in rows]
    payload = [{"name":cfg["name"]},{"redacted":redacted}]
    com = commit(payload)
    return {"commit":com, "redacted":redacted}

def run_proofs(cfg):
    rows = [{"observed":str(i),"declared":str(i),"inferred":str(i)} for i in range(1,6)]
    gs = GlyphSet.from_rows(rows)
    c = Carrier.from_glyphs(gs)
    pal = choose_pal_rest(c, seed=cfg.get("seed",0))
    overlays = pal["overlays"]
    pal_scores = [s for s,_ in overlays]
    min_score = min(pal_scores)
    count_min = sum(1 for s,_ in overlays if s==min_score)
    F1 = (len(overlays)==8 and count_min==1)
    rows4 = [{"observed":str(i),"declared":str(i),"inferred":str(i)} for i in range(1,5)]
    c4 = Carrier.from_glyphs(GlyphSet.from_rows(rows4))
    rest4 = c4.reverse()
    P4 = (rest4.hamming_to(rest4.reverse())==0)
    F2 = P4
    idem = run_replay({"name":"tmp","mode":"glyphs_to_commit","seed":0,"glyph_rows":rows})
    F3 = idem["idempotent"]
    from cqe_unified.receipts import receipts as rc
    rec0 = rc(prev=c, rest=c, overrides=0)
    recR = rc(prev=c.reverse(), rest=c.reverse(), overrides=0)
    recM = rc(prev=c.mirror(), rest=c.mirror(), overrides=0)
    F4 = (rec0["P"]==recR["P"]==recM["P"]) and (rec0["S"]==recR["S"]==recM["S"])
    proofs = {"F1":F1,"F2":F2,"F3":F3,"F4":F4,
              "pal_overlays":overlays, "count_min":count_min, "min_score":min_score}
    com = commit([{"name":"proofs_falsifiers"},{"proofs":proofs}])
    return {"commit":com, "proofs":proofs}

RUNNERS = {
  "glyphs_to_commit": run_glyphs_to_commit,
  "brainwaves_bandpower": run_brainwaves,
  "palrest_sweep": run_palrest_sweep,
  "sound_spectrum_check": run_sound,
  "arith_checksum": run_arith,
  "policy_map": run_policy,
  "collision_scan": run_collision,
  "replay_idempotence": run_replay,
  "redaction_demo": run_redaction,
  "proofs": run_proofs,
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--only")
    parser.add_argument("--freeze-golden", action="store_true")
    args = parser.parse_args()
    out_root = (ROOT/"harness"/"out"); out_root.mkdir(parents=True, exist_ok=True)
    (ROOT/"harness"/"out"/"reports").mkdir(parents=True, exist_ok=True)
    (ROOT/"harness"/"ledger").mkdir(parents=True, exist_ok=True)
    cfg_paths = list((ROOT/"harness"/"10why").glob("*.json"))
    cfg_paths += list((ROOT/"harness"/"proofs").glob("*.json"))
    results = {}
    for p in cfg_paths:
        cfg = json.loads(p.read_text()); name = cfg["name"]
        if args.only and not name.startswith(args.only): continue
        res = RUNNERS[cfg["mode"]](cfg)
        results[name] = res
        with open(ROOT/"harness"/"out"/"reports"/f"{name}.json","w") as f:
            json.dump(res, f, indent=2, sort_keys=True)
        Ledger(str(ROOT/"harness"/"ledger"/"commits.jl")).append({"name":name, "commit":res["commit"]})
    if args.freeze_golden:
        (ROOT/"harness"/"golden").mkdir(parents=True, exist_ok=True)
        for name,res in results.items():
            with open(ROOT/"harness"/"golden"/f"{name}_golden.json","w") as f:
                json.dump({"root":res["commit"]["merkle_root"]}, f, indent=2, sort_keys=True)
    with open(ROOT/"harness"/"out"/"summary.json","w") as f:
        json.dump({k:v["commit"]["merkle_root"] for k,v in results.items()}, f, indent=2, sort_keys=True)

if __name__ == "__main__":
    main()
