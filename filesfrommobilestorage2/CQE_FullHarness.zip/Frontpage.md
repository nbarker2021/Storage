# CQE‑FullHarness

See README.md for full details.
