Complete CQE harness with goldens & tests.
