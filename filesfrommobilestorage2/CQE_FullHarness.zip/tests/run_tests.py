import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT/"harness"/"out"/"reports"
GOLDEN = ROOT/"harness"/"golden"
def load_json(p): return json.loads(p.read_text())
def main():
    reports = list(OUT.glob("*.json"))
    if not reports:
        print("No reports found. Run: python -m harness.run_harness")
        sys.exit(2)
    fails = []
    for rep in reports:
        name = rep.stem
        gold_p = GOLDEN/f"{name}_golden.json"
        if not gold_p.exists():
            continue
        rep_root = load_json(rep)["commit"]["merkle_root"]
        gold_root = load_json(gold_p)["root"]
        if rep_root != gold_root:
            fails.append((name, rep_root, gold_root))
    if fails:
        print("FAILED:", len(fails), "mismatches")
        for n, r, g in fails:
            print(f" - {n}: got {r}, expected {g}")
        sys.exit(1)
    print("OK — all goldens matched.")
    sys.exit(0)
if __name__ == "__main__":
    main()
