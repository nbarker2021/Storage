#!/usr/bin/env python3
"""
CQE Framework Test Runner
=========================

This script provides an easy way to run all CQE framework tests and generate
comprehensive reports. It includes the RAG-based agent tools implementation
and complete testing coverage.

Usage:
    python3 run_cqe_tests.py                    # Run all tests
    python3 run_cqe_tests.py --quick            # Run quick test suite
    python3 run_cqe_tests.py --performance      # Run performance tests only
    python3 run_cqe_tests.py --help             # Show help
"""

import sys
import json
import time
import argparse
from cqe_complete_testing_framework import CQETestingFramework, print_testing_manual

def main():
    """Main test runner function"""
    parser = argparse.ArgumentParser(description='CQE Framework Test Runner')
    parser.add_argument('--quick', action='store_true', 
                       help='Run quick test suite (basic functionality only)')
    parser.add_argument('--performance', action='store_true',
                       help='Run performance tests only')
    parser.add_argument('--manual', action='store_true',
                       help='Print testing manual')
    parser.add_argument('--output', type=str, default='cqe_test_results.json',
                       help='Output file for test results (default: cqe_test_results.json)')
    parser.add_argument('--verbose', action='store_true',
                       help='Enable verbose output')
    
    args = parser.parse_args()
    
    if args.manual:
        print_testing_manual()
        return
    
    print("="*80)
    print("CQE FRAMEWORK COMPREHENSIVE TEST RUNNER")
    print("="*80)
    print(f"Start time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Initialize test framework
    test_framework = CQETestingFramework()
    test_framework.setUp()
    
    try:
        if args.quick:
            print("Running QUICK test suite...")
            results = run_quick_tests(test_framework)
        elif args.performance:
            print("Running PERFORMANCE tests...")
            results = run_performance_tests(test_framework)
        else:
            print("Running COMPLETE test suite...")
            results = test_framework.run_all_tests()
        
        # Save results to file
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        print(f"\nTest results saved to: {args.output}")
        
        # Print summary
        print_test_summary(results)
        
        # Return appropriate exit code
        if results['test_execution']['success_rate'] == 1.0:
            print("\n✅ ALL TESTS PASSED!")
            sys.exit(0)
        else:
            print(f"\n❌ {results['test_execution']['failed_tests']} TESTS FAILED!")
            sys.exit(1)
            
    except Exception as e:
        print(f"\n💥 TEST RUNNER ERROR: {e}")
        sys.exit(2)
    finally:
        test_framework.tearDown()

def run_quick_tests(test_framework):
    """Run a quick subset of tests for basic validation"""
    quick_tests = [
        test_framework.test_law_1_quadratic_invariance_basic,
        test_framework.test_law_2_boundary_only_entropy_basic,
        test_framework.test_law_3_auditable_governance_basic,
        test_framework.test_law_4_optimized_efficiency_basic,
        test_framework.test_dna_encoding_all_data_types
    ]
    
    test_results = []
    start_time = time.time()
    
    for test_method in quick_tests:
        test_name = test_method.__name__
        print(f"Running {test_name}...")
        
        try:
            test_method()
            test_results.append({
                'test_name': test_name,
                'status': 'PASSED',
                'error': None
            })
        except Exception as e:
            test_results.append({
                'test_name': test_name,
                'status': 'FAILED',
                'error': str(e)
            })
    
    total_time = time.time() - start_time
    passed_tests = [r for r in test_results if r['status'] == 'PASSED']
    
    return {
        'test_execution': {
            'total_tests': len(test_results),
            'passed_tests': len(passed_tests),
            'failed_tests': len(test_results) - len(passed_tests),
            'success_rate': len(passed_tests) / len(test_results),
            'total_execution_time': total_time,
            'test_type': 'quick'
        },
        'test_results': test_results
    }

def run_performance_tests(test_framework):
    """Run performance-focused tests"""
    performance_tests = [
        test_framework.test_law_4_optimized_efficiency_basic,
        test_framework.test_law_4_performance_scalability,
        test_framework.test_performance_stress_large_data,
        test_framework.test_concurrent_operations_simulation
    ]
    
    test_results = []
    start_time = time.time()
    
    for test_method in performance_tests:
        test_name = test_method.__name__
        print(f"Running {test_name}...")
        
        try:
            test_method()
            test_results.append({
                'test_name': test_name,
                'status': 'PASSED',
                'error': None
            })
        except Exception as e:
            test_results.append({
                'test_name': test_name,
                'status': 'FAILED',
                'error': str(e)
            })
    
    total_time = time.time() - start_time
    passed_tests = [r for r in test_results if r['status'] == 'PASSED']
    
    return {
        'test_execution': {
            'total_tests': len(test_results),
            'passed_tests': len(passed_tests),
            'failed_tests': len(test_results) - len(passed_tests),
            'success_rate': len(passed_tests) / len(test_results),
            'total_execution_time': total_time,
            'test_type': 'performance'
        },
        'test_results': test_results
    }

def print_test_summary(results):
    """Print a formatted test summary"""
    print("\n" + "="*80)
    print("TEST EXECUTION SUMMARY")
    print("="*80)
    
    execution = results['test_execution']
    print(f"Test Type: {execution.get('test_type', 'complete').upper()}")
    print(f"Total Tests: {execution['total_tests']}")
    print(f"Passed: {execution['passed_tests']}")
    print(f"Failed: {execution['failed_tests']}")
    print(f"Success Rate: {execution['success_rate']:.1%}")
    print(f"Execution Time: {execution['total_execution_time']:.2f} seconds")
    
    if execution['failed_tests'] > 0:
        print("\nFAILED TESTS:")
        for result in results['test_results']:
            if result['status'] == 'FAILED':
                print(f"  ❌ {result['test_name']}")
                if result['error']:
                    print(f"     Error: {result['error']}")
    
    if 'system_statistics' in results:
        print("\nSYSTEM STATISTICS:")
        gov_stats = results['system_statistics']['governance']
        enc_stats = results['system_statistics']['dna_encoder']
        
        print(f"  Governance Operations: {gov_stats['total_operations']}")
        print(f"  Governance Success Rate: {gov_stats['success_rate']:.1%}")
        print(f"  DNA Strands Created: {enc_stats['total_strands']}")
        print(f"  Encoding Success Rate: {enc_stats['encoding_success_rate']:.1%}")
        print(f"  Decoding Success Rate: {enc_stats['decoding_success_rate']:.1%}")
    
    if 'law_compliance' in results:
        print("\nLAW COMPLIANCE:")
        compliance = results['law_compliance']
        for law, status in compliance.items():
            status_icon = "✅" if status else "❌"
            print(f"  {status_icon} {law.replace('_', ' ').title()}: {'COMPLIANT' if status else 'NON-COMPLIANT'}")
    
    if 'recommendations' in results and results['recommendations']:
        print("\nRECOMMENDATIONS:")
        for i, rec in enumerate(results['recommendations'], 1):
            print(f"  {i}. {rec}")

if __name__ == "__main__":
    main()

