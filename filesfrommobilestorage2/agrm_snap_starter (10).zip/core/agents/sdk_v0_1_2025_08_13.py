
from typing import Dict, Any
from .contracts_v0_1_2025_08_13 import Capability_v0_1_2025_08_13
class BaseAgent_v0_1_2025_08_13:
    AGENT_ID = "base"; VERSION = "v0_1_2025_08_13"; CAPABILITIES = []
    def plan(self, inputs: Dict[str, Any]) -> Dict[str, Any]: return {"plan":"noop"}
    def act(self, inputs: Dict[str, Any]) -> Dict[str, Any]: return {"result":"noop"}
    def snapshot_state(self) -> Dict[str, Any]: return {"agent_id": self.AGENT_ID, "version": self.VERSION}
    def restore_state(self, snap: Dict[str, Any]): return None
    @classmethod
    def spec(cls):
        return {"agent_id": cls.AGENT_ID, "version": cls.VERSION, "capabilities":[{"name":c.name,"inputs":c.inputs,"outputs":c.outputs,"description":c.description} for c in cls.CAPABILITIES]}
class EchoAgent_v0_1_2025_08_13(BaseAgent_v0_1_2025_08_13):
    AGENT_ID = "echo.agent"
    CAPABILITIES = [Capability_v0_1_2025_08_13(name="echo", inputs=["text"], outputs=["text"], description="Returns same text.")]
    def act(self, inputs): return {"text": inputs.get("text","")}
class TSPAgent_v0_1_2025_08_13(BaseAgent_v0_1_2025_08_13):
    AGENT_ID = "tsp.agent"
    CAPABILITIES = [Capability_v0_1_2025_08_13(name="tsp_route", inputs=["points"], outputs=["tour","length"], description="AGRM + patching + portfolio.")]
    def act(self, inputs):
        import numpy as np
        from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL
        from core.agrm.patching_v0_1_2025_08_13 import patch_loop_v0_1_2025_08_13 as patch_loop, tour_length_v0_1_2025_08_13 as tour_len
        from core.agrm.salesman_portfolio_v0_1_2025_08_13 import choose_and_improve_v0_1_2025_08_13 as portfolio
        pts = np.asarray(inputs["points"], dtype=float)
        ctrl=CTRL(cfg={"theta_open":0.5,"theta_close":0.2,"cooldown":1,"num_sectors":32,"num_shells":8,"vws_k":5,"vws_edges":128,"max_ticks":8,"building":"default"})
        res=ctrl.solve(pts, max_ticks=8); sectors=res["meta"]["sectors"]
        partial=list(dict.fromkeys(res["chosen"]))[:max(3,min(12,len(res["chosen"])))]
        tour, _=patch_loop(pts, partial, sectors, budget_edges=80, budget_iter=60)
        L0=tour_len(pts, tour)
        entropy_proxy = min(1.0, res["stats"]["coverage_gain"]/max(1,len(set(sectors))))
        tour2, _ = portfolio(pts, tour, entropy_proxy)
        L1=tour_len(pts, tour2)
        return {"tour": tour2, "length": float(L1), "pre_length": float(L0)}
