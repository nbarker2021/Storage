
from .vector_sketch_v0_1_2025_08_13 import VS
def seed_vws_from_mdhg_v0_1_2025_08_13(mdhg, points, building=None, k_each=5, top_edges=128):
    vws = VS()
    for (a,b),w in mdhg.edges(topk=top_edges, building=building):
        if a<b: vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+int(w)
        else: vws.edge_freq[(b,a)] = vws.edge_freq.get((b,a),0)+int(w)
    import numpy as np
    points=np.asarray(points,dtype=float)
    for i in range(points.shape[0]):
        q = points[i]
        neigh = mdhg.k_nn(q, k=k_each, building=building)
        for j in neigh:
            a,b = (i,j) if i<j else (j,i)
            vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+1
    return vws
