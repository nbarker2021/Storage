
import sys, pathlib, json, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.snap.ops_center_v0_1_2025_08_13 import SnapOpsCenter_v0_1_2025_08_13 as Ops

ops = Ops()

payload = {
  "name": "A Short Story About A Dragon",
  "text": "Once upon a time a dragon met a wizard in a faraway kingdom. A short story about courage."
}

profiles = [
  {"name":"speedy-inline", "hash_mode":"auto", "inline_dim_thresh":16, "inline_n_thresh":5000, "entropy_proxy":0.3},
  {"name":"mdhg-heavy", "hash_mode":"mdhg", "entropy_proxy":0.6, "auto_thrash_tau":0.7}
]

task = {"tags":["creative","culture"], "seed": 11, "n_points": 120, "ticks": 4}

res = ops.roundtrip(payload, profiles, task, target_universe="work")
print(json.dumps(res, indent=2))
