
# Minimal example: prefer shorter edges (inverse distance) as a stand-in for a real superpermutation heuristic.
import numpy as np

class EdgeScoreProviderImpl:
    def score_edges(self, points, candidate_edges, context):
        pts = np.asarray(points, dtype=float)
        scores = {}
        for a,b in candidate_edges:
            i,j = (a,b) if a<b else (b,a)
            d = np.linalg.norm(pts[i]-pts[j])
            scores[(i,j)] = 1.0/(d+1e-9)
        return scores
