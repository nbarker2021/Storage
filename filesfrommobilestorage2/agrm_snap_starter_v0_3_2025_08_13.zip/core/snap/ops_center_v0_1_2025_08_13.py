
"""
SNAP Ops Center v0_1_2025_08_13
- Manages SNAPDNA profiles: classify, evaluate, compute compatibility, suggest hybrids,
  and coordinate promotion with Archivist.
"""
import time, json
from typing import Dict, Any, List
from core.snap.snap_types_v0_1_2025_08_13 import SnapTaxonomy_v0_1_2025_08_13 as Tax
from core.snap.snap_classifier_v0_1_2025_08_13 import classify_payload
from core.snap.snap_promoter_v0_1_2025_08_13 import promotion_decision, allowed_universes
from core.snap.compat_v0_1_2025_08_13 import bucketize
from core.snap.evaluator_v0_1_2025_08_13 import evaluate_profile
from core.snap.hybridizer_v0_1_2025_08_13 import fuse_profiles
from core.repo.archivist_v0_1_2025_08_13 import Archivist_v0_1_2025_08_13 as Archivist
from core.snap.snap_v0_1_2025_08_13 import create_snap

class SnapOpsCenter_v0_1_2025_08_13:
    def __init__(self):
        self.tax = Tax()
        self.arc = Archivist()

    def classify(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        cls = classify_payload(payload)
        return cls

    def compatibility(self, cls: Dict[str, Any], task_tags: List[str]) -> Dict[str, List[str]]:
        universes = ["user","doc","work.fast","work","gov"]
        return bucketize(cls.get("families",[]), cls.get("types",[]), task_tags, universes)

    def evaluate(self, profile: Dict[str, Any], task: Dict[str, Any]) -> Dict[str, Any]:
        return evaluate_profile(profile, task)

    def suggest_hybrid(self, pA: Dict[str, Any], pB: Dict[str, Any], alpha: float=0.5) -> Dict[str, Any]:
        return fuse_profiles(pA, pB, alpha=alpha)

    def promote_if_allowed(self, classification: Dict[str, Any], target_universe: str):
        dec = promotion_decision(classification, target_universe)
        meta = {"classification": classification, "target": target_universe, "decision": dec}
        create_snap({"universes":[target_universe], "n_level":1.0, "provenance":{"event":"ops_center_promotion"}, "meta": meta}, kind="ops_promotion")
        return dec

    def record_archivist(self, universe: str, rec: Dict[str, Any]):
        self.arc.add(universe, rec)
        return True

    def roundtrip(self, payload: Dict[str, Any], profiles: List[Dict[str, Any]], task: Dict[str, Any], target_universe: str):
        cls = self.classify(payload)
        compat = self.compatibility(cls, task.get("tags",[]))
        evals = [self.evaluate(p, task) for p in profiles]
        best_idx = min(range(len(evals)), key=lambda i: (0-evals[i]["coverage_rate"], evals[i]["thrash_per_step"], evals[i]["elapsed_s"]))
        best = profiles[best_idx]
        decision = self.promote_if_allowed(cls, target_universe)
        snap_meta = {"cls":cls, "compat":compat, "evals":evals, "best":best, "decision":decision}
        create_snap({"universes":[target_universe], "n_level":1.0, "provenance":{"event":"ops_center_roundtrip"}, "meta": snap_meta}, kind="ops_roundtrip")
        return {"classification": cls, "compatibility": compat, "evaluations": evals, "chosen_profile": best, "promotion": decision}
