
"""
Rule-based SNAP Classifier v0_1_2025_08_13
- Lightweight heuristics to tag text/files with families and types.
- Returns {families:[], types:[], confidence:0..1, staged: bool}
"""
import os, re
from typing import Dict, Any
from .snap_types_v0_1_2025_08_13 import SnapTaxonomy_v0_1_2025_08_13 as Tax

FICTION_CUES = {"once upon a time", "dragon", "wizard", "princess", "kingdom", "sci-fi", "novel", "fantasy", "poem"}
FACTUAL_CUES = {"according to", "dataset", "report", "figure", "table", "experiment", "method", "results", "conclusion"}
CULTURE_CUES = {"movie", "music", "art", "culture", "literature", "meme"}
CODE_EXTS = {".py",".js",".ts",".java",".cpp",".c",".rs",".go",".rb",".swift",".cs"}

def classify_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    tax = Tax()
    text = (payload.get("text") or "").lower()
    name = (payload.get("name") or "").lower()
    path = (payload.get("path") or "").lower()
    ext = os.path.splitext(path)[1] if path else ""

    families=set(); types=set(); staged=True; conf=0.5

    # File-type hints
    if ext in CODE_EXTS or re.search(r"(class\s|def\s|function\s)", text):
        families.add("code"); types.add("source_code"); conf=0.8; staged=False
    # Creative writing
    if any(k in text for k in FICTION_CUES) or "short story" in name or "poem" in name:
        families.update({"fiction","culture","user"}); types.add("creative_writing"); conf=max(conf,0.8); staged=True
    # Factual / analysis
    if any(k in text for k in FACTUAL_CUES):
        families.add("factual"); types.add("analysis"); conf=max(conf,0.7); staged=False
    # Culture
    if any(k in text for k in CULTURE_CUES):
        families.add("culture"); conf=max(conf,0.7)

    # Fallbacks
    if not families:
        families.add("unclassified"); types.add("raw"); conf=0.3; staged=True

    # Ensure registered
    for f in list(families): tax.ensure_family(f)
    for t in list(types): tax.ensure_type(t, list(families))

    return {"families": sorted(families), "types": sorted(types), "confidence": conf, "staged": staged}
