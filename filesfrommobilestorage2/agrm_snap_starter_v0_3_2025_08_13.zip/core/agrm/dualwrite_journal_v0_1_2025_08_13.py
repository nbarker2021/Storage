
"""
DualWriteJournal v0_1_2025_08_13
- Append-only journal of inline hasher learning (heat/edges batches).
- Safe for crash-recovery; can replay into MDHG on boot or promotion.
"""
import json, time
from pathlib import Path

class DualWriteJournal_v0_1_2025_08_13:
    def __init__(self, dir_path="snapshots/journal", max_bytes=2_000_000):
        self.dir = Path(dir_path); self.dir.mkdir(parents=True, exist_ok=True)
        self.max_bytes = int(max_bytes)
        self.file = self._next_file()

    def _next_file(self):
        ts=int(time.time()); p = self.dir / f"dwj_{ts}.jsonl"
        p.touch()
        return p

    def append(self, heat: dict, edges: list):
        rec = {"ts": time.time(), "heat": heat, "edges": edges}
        line = json.dumps(rec)
        if self.file.stat().st_size + len(line) + 1 > self.max_bytes:
            self.file = self._next_file()
        with self.file.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        return str(self.file)

    def replay_into_mdhg(self, mdhg, since_ts: float = 0.0):
        count=0
        for p in sorted(self.dir.glob("dwj_*.jsonl")):
            with p.open("r", encoding="utf-8") as f:
                for line in f:
                    rec = json.loads(line)
                    if rec.get("ts",0) < since_ts: continue
                    for i,h in rec.get("heat",{}).items():
                        mdhg.heat[int(i)] += float(h)
                    for a,b,w in rec.get("edges",[]):
                        if a>b: a,b=b,a
                        mdhg.edge[(int(a),int(b))] += float(w)
                    count+=1
        return count
