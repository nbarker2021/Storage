
from .salesman_2opt_v0_1_2025_08_13 import two_opt_loop_v0_1_2025_08_13 as two_opt
from .salesman_3opt_v0_1_2025_08_13 import three_opt_loop_v0_1_2025_08_13 as three_opt
def choose_and_improve_v0_1_2025_08_13(points, tour, entropy_proxy: float):
    if entropy_proxy < 0.35:
        return two_opt(points, tour, max_iter=120)
    else:
        return three_opt(points, tour, max_iter=20, samples=120)
