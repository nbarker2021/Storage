
"""
Promotion Sampling Guard v0_1_2025_08_13
- Ensure sampling won't trigger exact seeding at large N.
"""
from typing import Dict, Any

def adjust_sampling_cfg(cfg: Dict[str,Any], N:int) -> Dict[str,Any]:
    out = dict(cfg or {})
    out.setdefault("seeding_strategy", "grid")
    out.setdefault("vws_skip_seed", True)
    out.setdefault("force_grid", True)
    out.setdefault("N_guard", 4000)
    return out
