
"""
SubprocessAdapter_v0_1_2025_08_13
- Spawns a local CLI agent that reads/writes JSON on stdin/stdout.
- Good for mannequin/test agents.
"""
import subprocess, json, shlex
class SubprocessAdapter_v0_1_2025_08_13:
    def __init__(self, cmd):
        self.cmd = cmd if isinstance(cmd, list) else shlex.split(cmd)
    def _run(self, phase, inputs):
        p = subprocess.Popen(self.cmd + [phase], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate(json.dumps(inputs) + "\n", timeout=10)
        if p.returncode != 0:
            raise RuntimeError(f"subproc error: {err.strip()}")
        return json.loads(out)
    def plan(self, inputs): return self._run("plan", inputs)
    def act(self, inputs): return self._run("act", inputs)
