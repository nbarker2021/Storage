\
import os, json, yaml
from sidecar_adapters.speedlight_router import Ledger, MintEngine

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
policy = yaml.safe_load(open(os.path.join(BASE,"config","policy.yaml")))
ledger = Ledger(os.path.join(BASE,"data"))
engine = MintEngine(policy, ledger)

def preview_of(obj):
    p = engine.preview(obj)
    return p["factors"], p["minted"], p["total_scaled"]

def test_safety_gate():
    obj = {"actor_id":"t1","summary":"x","details":"y","domain_claims":["MERIT"],
           "evidence":{"endorsements":[],"lineage_refs":[],"deployments":0,"safety":{"non_coercive":False,"non_weaponizable":True,"harm_reduction_pass":True}}}
    f, minted, total = preview_of(obj)
    assert total == 0.0

def test_factors_monotonicity():
    base = {"actor_id":"t2","summary":"x","details":"y","domain_claims":["MERIT"],
            "evidence":{"endorsements":[],"lineage_refs":[],"deployments":0,"safety":{"non_coercive":True,"non_weaponizable":True,"harm_reduction_pass":True},"lab":{"trials":1,"passes":0}}}
    f0, _, t0 = preview_of(base)
    # add endorsements
    base["evidence"]["endorsements"] = [{"witness_id":"w1","statement":"ok","confidence":0.9}]
    f1, _, t1 = preview_of(base)
    assert t1 >= t0
    # add lineage
    base["evidence"]["lineage_refs"] = [{"source_id":"doi:X","score":0.8,"kind":"paper"}]
    f2, _, t2 = preview_of(base)
    assert t2 >= t1
    # deployments
    base["evidence"]["deployments"] = 9
    f3, _, t3 = preview_of(base)
    assert t3 >= t2
    # lab pass
    base["evidence"]["lab"] = {"trials":10,"passes":10}
    f4, _, t4 = preview_of(base)
    assert t4 >= t3

if __name__ == "__main__":
    test_safety_gate()
    test_factors_monotonicity()
    print("OK v3")
