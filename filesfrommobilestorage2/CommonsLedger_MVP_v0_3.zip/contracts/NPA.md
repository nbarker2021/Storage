# Node Participation Agreement (NPA) — CommonsLedger MVP

**Node** ingests corpus, verifies, fulfills Specifics Requests, and routes royalties.

- **Fees & Splits**: Node fee for fulfilled work; creator royalties pass‑through; 50% of platform net to Shared Relief Pool.
- **Governance**: Enforce AEGIS (safety), ORBIT (consent), MYTHOS (cultural auth), privacy redaction.
- **Compliance**: KYC/AML on fiat legs; respect licenses.
- **Audit**: Keep logs; allow audit.
- **Termination**: Either party may terminate; obligations to creators/pool survive.
