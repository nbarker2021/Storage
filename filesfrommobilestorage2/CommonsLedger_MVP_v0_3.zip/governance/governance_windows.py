def aegis_pass(safety: dict) -> bool:
    return bool(safety.get("non_coercive")) and bool(safety.get("non_weaponizable")) and bool(safety.get("harm_reduction_pass"))

def mythos_authorized(lineage_refs: list) -> bool:
    return any(ref.get("kind") == "mythos" and float(ref.get("score",0)) >= 0.5 for ref in lineage_refs)

def orbit_ready(endorsements: list) -> bool:
    return any(float(e.get("confidence",0)) >= 0.8 and "mediate" in e.get("statement","").lower() for e in endorsements)
