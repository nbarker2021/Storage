# CommonsLedger MVP v0.1 (No external deps)

Evidence-grade social benefits ledger: submit a contribution → governance checks → mint domain credits → route royalties → fill a shared relief pool (50% platform net).

## Structure
- contracts/: DCRA, NPA, Corpus Addendum, Buyer Terms
- schemas/: JSON Schemas for Contribution Proof, Lineage Edge, Royalty Statement, Specifics Request
- sidecar_adapters/speedlight_router.py: mint + ledger + royalty routing (uses SpeedLightPlus if present)
- server/server.py: minimal HTTP server (POST /submit, /settle, /payout_wallet)
- web/index.html: static UI
- examples/overdose_example.json
- governance/: governance windows stubs
- node/org_node.py: corpus ingest + naive lineage matching
- config/policy.yaml: domain scales + 50% split
- tests/test_mint.py

## Run
python server/server.py
# open web/index.html and submit
# or:
curl -s -X POST http://127.0.0.1:8787/submit -H "Content-Type: application/json" --data @examples/overdose_example.json

# simulate a paid service settlement (routes 50% to payout wallet, remainder to creators):
curl -s -X POST http://127.0.0.1:8787/settle -H "Content-Type: application/json" --data '{"service_id":"S1","revenue_fiat":1000,"patterns":[{"pattern_id":"P1","creator_id":"street-medic-001","weight":1.0,"domain_breakdown":{"MERIT":0.7,"AEGIS":0.3}}]}'


## Tiles & Lab UI
- Start server: `python server/server.py`
- Open `web/tiles_lab.html` (file://) for a drag‑and‑drop CA tiles board.
- Paste 2+ papers, drag to board, Shift+Click to select, **Fuse** to get link suggestions.
- **Make Draft** consumes a Sub‑Journal; **Mint** consumes a Journal and mints contribution credits.
- **Start Lab/Step/Auto** toggles a simple CA "lab" canvas (server‑side steps; no external deps).
- Inventory (`/profile`) tracks Journals/Sub‑Journals per actor.


## v0.2 — Tiles & Lab
- New endpoints: /upload, /tiles/init, /tiles/combine, /inventory/get, /lab/run, /lab/step
- New UI: web/ca.html — upload papers, combine (spends 1 journal), run CA-based lab on draft.
- Inventory: journals/subjournals initialized per actor; credits reflect mint results.

## v0.3 — Refined mint metric & adapters
- New mint formula: composite of Endorsements (E), Lineage (L), Deployments (R), Lab Quality (Q), Novelty (N), ΔΦ savings, gated by AEGIS safety; supply governor keeps totals near a target.
- New endpoints: /metrics/mint_preview, /policy/get, /policy/set, /lab/record.
- Optional toolkits auto-detected from /optional_toolkits (unzipped from your uploaded zips, if present): GeoTokenizer, GeometryOnlyTransformer, LatticeBuilder, Moonshine DB.
