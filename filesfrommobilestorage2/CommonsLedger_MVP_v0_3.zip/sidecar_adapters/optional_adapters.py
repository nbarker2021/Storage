\
# Optional adapters for GeoTokenizer, GeometryOnlyTransformer, LatticeBuilder, Moonshine DB.
import os, json, hashlib, math, importlib.util

OPT_ROOT = os.path.join(os.path.dirname(__file__), "..", "optional_toolkits")

def _dyn_import(path, modname):
    try:
        spec = importlib.util.spec_from_file_location(modname, path)
        if not spec: return None
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m
    except Exception:
        return None

def find_module_named(root, name_fragment):
    for dirpath, _, files in os.walk(root):
        for f in files:
            if f.endswith(".py") and name_fragment.lower() in f.lower():
                return os.path.join(dirpath, f)
    return None

# GeoTokenizer
def geotokenize(text: str):
    """Return list of geo-tokens (fallback: simple word tokens)."""
    # Try to find a tokenizer module
    p = find_module_named(OPT_ROOT, "geotoken")
    if p:
        m = _dyn_import(p, "geotokenizer_mod")
        if m and hasattr(m, "tokenize"):
            try:
                return m.tokenize(text)
            except Exception:
                pass
    # Fallback
    out, buf = [], []
    for ch in text.lower():
        if ch.isalnum(): buf.append(ch)
        else:
            if buf: out.append("".join(buf)); buf=[]
    if buf: out.append("".join(buf))
    return [t for t in out if len(t)>=3]

# GeometryOnlyTransformer novelty score
def novelty(tokens, corpus_signature=None):
    """Return novelty in [0,1]; use geometry-only transformer if available; else token uniqueness heuristic."""
    p = find_module_named(OPT_ROOT, "geometry")
    if p:
        m = _dyn_import(p, "geom_transformer_mod")
        if m and hasattr(m, "novelty_score"):
            try:
                return max(0.0, min(1.0, float(m.novelty_score(tokens, corpus_signature))))
            except Exception:
                pass
    # Fallback: rarity proxy
    uniq = len(set(tokens)); total = max(1, len(tokens))
    return max(0.0, min(1.0, (uniq/total)**0.5))

# MDHG distance / lattice signal (optional lattice validator)
def mdhg_signal(tokens):
    """Return MDHG routing signal in [0,1]."""
    p = find_module_named(OPT_ROOT, "lattice")
    if p:
        m = _dyn_import(p, "lattice_mod")
        if m and hasattr(m, "mdhg_signal"):
            try:
                return max(0.0, min(1.0, float(m.mdhg_signal(tokens))))
            except Exception:
                pass
    # Fallback: mild boost if token length suggests structured math
    mathy = sum(1 for t in tokens if any(c.isdigit() for c in t) or t in {"theorem","lemma","proof","e8","leech","niemeier","lattice","monster"})
    return max(0.0, min(1.0, math.tanh(0.25*mathy)))

# Monster Moonshine DB cross-hit (optional)
def moonshine_crosshit(tokens):
    """Return cross-hit score in [0,1] measuring links to moonshine contexts if DB present."""
    root = os.path.join(OPT_ROOT, "MonsterMoonshineDB_v1")
    if os.path.isdir(root):
        # naive: if any moonshine keyword appears, boost
        kws = {"moonshine","monster","j-invariant","modular","hauptmodul","vertex","VOA","fischer","conway","golay"}
        hits = len(set(tokens) & kws)
        return max(0.0, min(1.0, math.tanh(0.5*hits)))
    return 0.0
