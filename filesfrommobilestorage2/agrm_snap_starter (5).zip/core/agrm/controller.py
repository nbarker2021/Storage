
from __future__ import annotations
from typing import Any, Dict
import numpy as np

from .statebus import StateBus
from .navigator import NavigatorGR
from .builder import PathBuilder
from .validator import EdgeValidator
from .salesman import Salesman
from .audit import Auditor
from .vector_sketch import vector_warm_start

class AGRMController:
    """
    Minimal controller that always begins with a Vector Warm-Start (VWS).
    This wires the cold-start heuristic into the runtime without touching
    the legacy solver file. Build/patch/salesman stages remain placeholders.
    """
    def __init__(self, cfg: Dict[str, Any] | None = None):
        self.cfg = cfg or {}
        self.bus = StateBus()
        self.validator = EdgeValidator(self.cfg)
        self.navigator = NavigatorGR(self.cfg)
        self.salesman = Salesman(self.cfg)
        self.auditor = Auditor(self.cfg)

    def solve(self, points: np.ndarray) -> Dict[str, Any]:
        if not isinstance(points, np.ndarray):
            points = np.asarray(points, dtype=float)
        # 1) Vector Warm-Start
        vws = vector_warm_start(points, k=self.cfg.get("vws_k", 8), seeds=self.cfg.get("vws_seeds", 8))
        # store priors on the bus for downstream use
        self.bus.current_phase = "vws"
        self.bus.vws = vws  # type: ignore[attr-defined]

        # 2) Navigator shell/sector prep (placeholder)
        try:
            meta = self.navigator.assign_shells_and_sectors(points)  # TODO
            self.bus.update_sweep_data(meta)  # TODO
        except NotImplementedError:
            meta = None

        # 3) Build loop (placeholder)
        #    In a future commit, PathBuilder will read self.bus.vws.edge_freq, etc.
        try:
            builder = PathBuilder(self.cfg, self.bus)
            progressed = builder.step()  # TODO
        except NotImplementedError:
            progressed = False

        # 4) Salesman + Audit placeholders
        result = {
            "phase": self.bus.current_phase,
            "vws": {
                "greedy_best_len": getattr(vws, "greedy_best_len", None),
                "knn_edges": len(getattr(vws, "knn_edges", [])),
                "angle_hist": getattr(vws, "angle_hist", []),
            },
            "meta_ready": meta is not None,
            "progressed": progressed,
        }
        return result
