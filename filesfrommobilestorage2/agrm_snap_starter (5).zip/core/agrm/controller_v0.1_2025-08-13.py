
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from .statebus import StateBus
from .navigator import NavigatorGR
from .builder import PathBuilder
from .validator import EdgeValidator
from .salesman import Salesman
from .audit import Auditor
from .vector_sketch_v0.1_2025_08_13 import vector_warm_start

class AGRMController_v0.1_2025_08_13:
    """
    Controller that begins with Vector Warm-Start (VWS).
    Versioned filename, as requested.
    """
    def __init__(self, cfg: Dict[str, Any] | None = None):
        self.cfg = cfg or {}
        self.bus = StateBus()
        self.validator = EdgeValidator(self.cfg)
        self.navigator = NavigatorGR(self.cfg)
        self.salesman = Salesman(self.cfg)
        self.auditor = Auditor(self.cfg)

    def solve(self, points: np.ndarray) -> Dict[str, Any]:
        if not isinstance(points, np.ndarray):
            points = np.asarray(points, dtype=float)
        vws = vector_warm_start(points, k=self.cfg.get("vws_k", 8), seeds=self.cfg.get("vws_seeds", 8))
        self.bus.current_phase = "vws"
        self.bus.vws = vws  # type: ignore
        result = {
            "phase": self.bus.current_phase,
            "vws": {
                "greedy_best_len": getattr(vws, "greedy_best_len", None),
                "knn_edges": len(getattr(vws, "knn_edges", [])),
                "angle_hist": getattr(vws, "angle_hist", []),
            },
            "meta_ready": False,
            "progressed": False,
        }
        return result
