
import numpy as np
from .statebus_v0.2_2025_08_13 import StateBus_v0.2_2025_08_13
from .navigator_v0.2_2025_08_13 import NavigatorGR_v0.2_2025_08_13
from .vector_sketch_v0.1_2025_08_13 import vector_warm_start

class AGRMController_v0.2_2025_08_13:
    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.bus = StateBus_v0.2_2025_08_13()
        self.navigator = NavigatorGR_v0.2_2025_08_13(self.cfg, self.bus)

    def solve(self, points: np.ndarray, max_ticks: int=5):
        if not isinstance(points, np.ndarray):
            points = np.asarray(points, dtype=float)
        # VWS
        vws = vector_warm_start(points, k=self.cfg.get("vws_k", 8), seeds=self.cfg.get("vws_seeds", 8))
        self.bus.vws = vws
        self.bus.current_phase = "vws"
        # meta
        meta = self.navigator.assign_shells_and_sectors(points)
        self.bus.current_phase = "sweep"
        # ticks
        chosen_all = []
        for _ in range(max_ticks):
            chosen = self.navigator.sweep_step(points)
            chosen_all.extend(chosen)
        # summary
        return {
            "stats": self.bus.stats,
            "chosen_count": len(chosen_all),
            "unique_chosen": len(set(chosen_all)),
        }
