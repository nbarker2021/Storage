
import math, numpy as np
from .e8dof_state_v0.1_2025_08_13 import E8DoFState_v0.1_2025_08_13, phi_stagger_schedule_v0.1_2025_08_13

class NavigatorGR_v0.2_2025_08_13:
    def __init__(self, cfg, bus):
        self.cfg = cfg
        self.bus = bus
        self.num_shells = cfg.get("num_shells", 6)
        self.num_sectors = cfg.get("num_sectors", 24)
        self.theta_open = cfg.get("theta_open", 0.0)    # gate open threshold
        self.theta_close = cfg.get("theta_close", -0.5) # gate close threshold
        self.max_steps_per_arm = cfg.get("max_steps_per_arm", 12)

        # State (start centered, no rotation; modest sigma/phi)
        self.state = E8DoFState_v0.1_2025_08_13(0.0,0.0,0.0, 0.0,0.0,0.0, 1.0, 0.1)

    def assign_shells_and_sectors(self, points: np.ndarray):
        # Center and polar bins
        center = points.mean(axis=0)
        vecs = points - center
        radii = np.linalg.norm(vecs, axis=1) + 1e-9
        angles = np.arctan2(vecs[:,1], vecs[:,0]) # [-pi,pi]
        # shells
        rmin, rmax = radii.min(), radii.max()
        shell_edges = np.linspace(rmin, rmax+1e-9, self.num_shells+1)
        shells = np.digitize(radii, shell_edges) - 1
        # sectors
        sec_edges = np.linspace(-math.pi, math.pi, self.num_sectors+1)
        sectors = np.digitize(angles, sec_edges) - 1
        meta = {
            "center": center.tolist(),
            "shells": shells.tolist(),
            "sectors": sectors.tolist(),
            "shell_edges": shell_edges.tolist(),
            "sec_edges": sec_edges.tolist(),
        }
        self.bus.meta = meta
        return meta

    def _route_efficiency(self, points, idx):
        # Simple proxy: combine (i) VWS edge frequency around idx and (ii) sector alignment with φ-stagger
        vws = self.bus.vws
        if vws is None:
            return -1.0
        # edge score
        ef = 0.0
        for j in range(points.shape[0]):
            a,b = (idx,j) if idx<j else (j,idx)
            ef += vws.edge_freq.get((a,b), 0)
        ef = math.log(1.0 + ef)
        # sector/phase alignment: prefer sectors near current phase
        sectors = self.bus.meta.get("sectors")
        if not sectors:
            return ef
        sec = sectors[idx]
        # map φ in [0,1) to sector in [0,num_sectors)
        target_sec = int(self.state.phi * self.num_sectors) % self.num_sectors
        align = 1.0 - abs((sec - target_sec) % self.num_sectors) / (self.num_sectors/2.0)
        return ef + 0.5*align

    def sweep_step(self, points: np.ndarray):
        # one fan step from the "most packed, closest non-shared quadrants": approximate by
        # sorting sectors by VWS angle histogram density and taking the best non-used sectors
        used = set()
        sectors = self.bus.meta["sectors"]
        shells = self.bus.meta["shells"]
        n = points.shape[0]
        # density by sector
        counts = {}
        for s in sectors:
            counts[s] = counts.get(s, 0) + 1
        sec_order = sorted(counts.keys(), key=lambda s: (-counts[s], s))
        moved = 0
        max_steps = self.max_steps_per_arm
        chosen = []
        for sec in sec_order:
            if sec in used: continue
            # pick the nearest point in this sector that we haven't visited (proxy: smallest shell index)
            cand = [i for i in range(n) if sectors[i]==sec]
            if not cand: continue
            cand.sort(key=lambda i: shells[i])
            idx = cand[0]
            # route efficiency gate
            R = self._route_efficiency(points, idx)
            if R >= self.theta_open:
                chosen.append(idx)
                used.add(sec)
                moved += 1
                self.bus.note_gate(True)
            else:
                self.bus.note_gate(False)
            if moved >= max_steps:
                break
        self.bus.bump("ticks", 1)
        self.bus.bump("steps", moved)
        self.bus.stats["sectors_visited"] += len(used)
        # update phase
        from .e8dof_state_v0.1_2025_08_13 import phi_stagger_schedule_v0.1_2025_08_13
        self.state.phi = phi_stagger_schedule_v0.1_2025_08_13(self.bus.stats["ticks"], self.state.phi)
        if moved == 0:
            self.bus.bump("stalls", 1)
        return chosen
