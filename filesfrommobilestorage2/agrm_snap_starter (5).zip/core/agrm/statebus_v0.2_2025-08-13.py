
class StateBus_v0.2_2025_08_13:
    """
    Minimal run-time bus: stores priors (VWS), sweep meta, gating stats, and phase.
    """
    def __init__(self):
        self.current_phase = "init"
        self.vws = None
        self.meta = {}
        self.stats = {
            "ticks": 0,
            "steps": 0,
            "gates_open": 0,
            "gates_close": 0,
            "thrash": 0,          # open->close->open flips
            "stalls": 0,
            "sectors_visited": 0,
        }
        self._gate_last = None

    def note_gate(self, opened: bool):
        last = self._gate_last
        now = "open" if opened else "close"
        if last and last != now:
            self.stats["thrash"] += 1
        self._gate_last = now
        if opened: self.stats["gates_open"] += 1
        else: self.stats["gates_close"] += 1

    def bump(self, k: str, v: int=1):
        self.stats[k] = self.stats.get(k, 0) + v
