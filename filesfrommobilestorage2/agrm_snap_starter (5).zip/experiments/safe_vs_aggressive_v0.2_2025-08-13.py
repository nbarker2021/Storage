import argparse, numpy as np, time
from core.agrm.controller_v0.2_2025_08_13 import AGRMController_v0.2_2025_08_13

def make_points(n, seed):
    rng = np.random.default_rng(seed)
    return rng.random((n, 2))

def run_cfg(name, cfg, n=400, seed=7):
    pts = make_points(n, seed)
    t0 = time.time()
    ctrl = AGRMController_v0.2_2025_08_13(cfg=cfg)
    res = ctrl.solve(pts, max_ticks=cfg.get("max_ticks", 6))
    dt = (time.time() - t0)*1000
    print("[{}] ms={:.1f} steps={} ticks={} stalls={} thrash={} sectors={} chosen={} unique={}".format(
        dt, res['stats']['steps'], res['stats']['ticks'], res['stats']['stalls'], res['stats']['thrash'],
        res['stats']['sectors_visited'], res['chosen_count'], res['unique_chosen']
    ))
    return dt, res

def main():
    safe = {
        "num_shells": 8, "num_sectors": 32,
        "theta_open": 0.5, "theta_close": 0.0,
        "max_steps_per_arm": 6,
        "max_ticks": 8,
        "vws_k": 8, "vws_seeds": 8,
    }
    aggressive = {
        "num_shells": 8, "num_sectors": 32,
        "theta_open": 0.0, "theta_close": -0.5,
        "max_steps_per_arm": 16,
        "max_ticks": 8,
        "vws_k": 8, "vws_seeds": 8,
    }
    dt_safe, r_safe = run_cfg("SAFE", safe)
    dt_aggr, r_aggr = run_cfg("AGGR", aggressive)
    summary = {
        "safe": r_safe, "aggressive": r_aggr,
        "time_ms": {"safe": dt_safe, "aggressive": dt_aggr},
        "observations": [
            "SAFE: fewer steps, more stalls, less thrash",
            "AGGR: more steps, fewer stalls, more thrash"
        ]
    }
    print("\nSUMMARY:", summary)

if __name__ == "__main__":
    main()
