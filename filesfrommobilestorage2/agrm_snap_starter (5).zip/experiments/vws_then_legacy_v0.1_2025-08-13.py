import argparse, numpy as np
from core.agrm.solver_legacy_v0.1_2025_08_13 import LegacyAGRMSolver
from core.agrm.controller_v0.1_2025_08_13 import AGRMController_v0.1_2025_08_13

def make_points(n, seed):
    rng = np.random.default_rng(seed)
    return rng.random((n, 2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--n", type=int, default=150)
    args = ap.parse_args()
    pts = make_points(args.n, args.seed)
    # Controller (VWS only) demo
    ctrl = AGRMController_v0.1_2025_08_13(cfg={})
    res = ctrl.solve(pts)
    print("[CTRL VWS]", res["vws"]["greedy_best_len"])
    # Legacy solver smoke
    solver = LegacyAGRMSolver(config={})
    try:
        sres = solver.solve(pts)
        print("[LEGACY] ok", type(sres))
    except Exception as e:
        print("[LEGACY] error:", e)

if __name__ == "__main__":
    main()
