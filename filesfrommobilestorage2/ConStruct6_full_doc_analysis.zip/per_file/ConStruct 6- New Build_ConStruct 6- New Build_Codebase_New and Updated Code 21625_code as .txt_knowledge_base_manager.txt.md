# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/New and Updated Code 21625/code as .txt/knowledge_base_manager.txt

**Extension:** .txt

**Lines:** 41 | **Words:** 118

## Headings (1)
- # knowledge_base_manager.py

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

# knowledge_base_manager.py
import json
import os

class KnowledgeBaseManager:
    def __init__(self, database_file='knowledge_base.json'):
        self.database_file = database_file
        self.database = self.load_database()

    def load_database(self):
        if os.path.exists(self.database_file):
            with open(self.database_file, 'r') as f:
                return json.load(f)
        return {}

    def save_database(self):
        with open(self.database_file, 'w') as f:
            json.dump(self.database, f, indent=4)

    def add_entry(self, key, value):
        self.database[key] = value
        self.save_database()

    def get_entry(self, key):
        return self.database.get(key)

    def update_entry(self, key, value):
        if key in self.database:
            self.database[key] = value
            self.save_database()
            return True
        return False

    def delete_entry(self, key):
        if key in self.database:
            del self.database[key]
            self.save_database()
            return True
        return False

