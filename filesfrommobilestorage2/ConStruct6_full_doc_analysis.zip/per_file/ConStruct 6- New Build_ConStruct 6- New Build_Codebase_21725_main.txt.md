# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/21725/main.txt

**Extension:** .txt

**Lines:** 91 | **Words:** 312

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 13
- superpermutation: 13
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

from config import ConfigManager
from construct import SuperpermutationProblem, SuperpermutationStrategy
from analysis import SuperpermutationAnalyzer
from utility import ProgressTracker
from documentation_tool import DocumentationTool
from data_manager import DataManager
from think_tank import ThinkTank
from assembly_line import AssemblyLine, Component
from error_handler import ErrorHandler
from dtt import DTT

def get_user_input(prompt):
    while True:
        response = input(prompt).lower()
        if response in ['y', 'n']:
            return response == 'y'
        print("Please enter 'y' for yes or 'n' for no.")

def main():
    config = ConfigManager()
    config.load_settings('config.json')
    
    data_manager = DataManager('data.json')
    progress_tracker = ProgressTracker()
    documentation_tool = DocumentationTool()
    think_tank = ThinkTank()
    error_handler = ErrorHandler()

    n = config.get_setting('n', 8)  # Default to n=8 if not specified
    auto_loop = config.get_setting('auto_loop', False)  # Default to manual mode
    iteration = 1

    while True:
        try:
            print(f"\nStarting iteration {iteration} for n={n}")
            
            problem = SuperpermutationProblem(n)
            strategy = SuperpermutationStrategy(problem, auto_mode=auto_loop)
            
            assembly_line = AssemblyLine(auto_mode=auto_loop)
            assembly_line.add_component(Component("Formulate", problem.formulate))
            assembly_line.add_component(Component("Solve", strategy.solve))
            assembly_line.add_component(Component("Analyze", lambda x: SuperpermutationAnalyzer(x, n)))
            assembly_line.add_component(Component("ThinkTank", think_tank.analyze_problem))
            
            result = assembly_line.assemble()
            
            formulated_problem, superpermutation, analysis, insights = result
            
            coverage = analysis.calculate_coverage()
            efficiency = analysis.calculate_efficiency()
            imperfect_transitions = analysis.identify_imperfect_transitions()
            hierarchy = analysis.analyze_hierarchy()
            
            documentation_tool.start_new_iteration()
            documentation_tool.add_section("Config", config.settings)
            documentation_tool.add_section("Progress", progress_tracker.generate_report())
            documentation_tool.add_section("Result", {
                "superpermutation": superpermutation,
                "length": len(superpermutation),
                "coverage": coverage,
                "efficiency": efficiency,
                "imperfect_transitions": imperfect_transitions,
                "hierarchy": hierarchy
            })
            documentation_tool.add_section("Insights", insights)
            
            print(f"\nIteration {iteration} complete.")
            print(f"Superpermutation length: {len(superpermutation)}")
            print(f"Coverage: {coverage:.2%}")
            print(f"Efficiency: {efficiency:.2%}")
            
            if not auto_loop and not get_user_input("Would you like to start a new iteration? (y/n): "):
                break
            
            iteration += 1
            
        except Exception as e:
            error_handler.handle_error(e, f"Error in main execution for n={n}, iteration={iteration}")
            if not auto_loop and not get_user_input("An error occurred. Would you like to try again? (y/n): "):
                break

    print("All iterations complete. Generating final results...")
    final_report = documentation_tool.generate_report()
    documentation_tool.save_report(f"superpermutation_n{n}_final_report.json")
    print(final_report)

if __name__ == "__main__":
    main()

