# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/base code for backup/best code as it stands/SequenceMemory class.txt

**Extension:** .txt

**Lines:** 36 | **Words:** 141

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

class SequenceMemory:
    def __init__(self):
        self.winners = {}
        self.losers = {}
        self.prodigals = {}
        self.laminates = []
        self.anti_laminates = []

    def add_winner(self, n, sequence):
        if n not in self.winners:
            self.winners[n] = []
        self.winners[n].append(sequence)

    def add_loser(self, n, sequence):
        if n not in self.losers:
            self.losers[n] = []
        self.losers[n].append(sequence)

    def add_prodigal(self, n, sequence):
        if n not in self.prodigals:
            self.prodigals[n] = []
        self.prodigals[n].append(sequence)

    def add_laminate(self, sequence, score):
        self.laminates.append((sequence, score))
        self.laminates.sort(key=lambda x: x[1], reverse=True)
        if len(self.laminates) > 100:  # Keep only top 100 laminates
            self.laminates = self.laminates[:100]

    def add_anti_laminate(self, sequence, penalty):
        self.anti_laminates.append((sequence, penalty))
        self.anti_laminates.sort(key=lambda x: x[1])
        if len(self.anti_laminates) > 100:  # Keep only top 100 anti-laminates
            self.anti_laminates = self.anti_laminates[:100]

