# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/base code for backup/best code as it stands/SequenceAnalyzer class.txt

**Extension:** .txt

**Lines:** 84 | **Words:** 408

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

class SequenceAnalyzer:
    def calculate_permutation_coverage(self, sequence):
        n = max(int(char) for char in sequence)
        all_permutations = set(''.join(map(str, p)) for p in itertools.permutations(range(1, n+1)))
        covered_permutations = set()
        
        for i in range(len(sequence) - n + 1):
            substring = sequence[i:i+n]
            if substring in all_permutations:
                covered_permutations.add(substring)
        
        return len(covered_permutations) / len(all_permutations)

    def calculate_connectivity_score(self, sequence):
        score = 0
        n = max(int(char) for char in sequence)
        for i in range(len(sequence) - 1):
            if int(sequence[i]) + 1 == int(sequence[i+1]) or (sequence[i] == str(n) and sequence[i+1] == '1'):
                score += 1
        return score / (len(sequence) - 1)

    def analyze_sequence_hierarchy(self, sequence):
        n = max(int(char) for char in sequence)
        hierarchy = {}
        for i in range(1, n+1):
            sub_sequence = ''.join(char for char in sequence if int(char) <= i)
            hierarchy[i] = self.calculate_permutation_coverage(sub_sequence)
        return hierarchy

    def analyze_imperfect_transitions(self, sequence):
        imperfect_transitions = []
        n = max(int(char) for char in sequence)
        for i in range(len(sequence) - 1):
            if int(sequence[i]) + 1 != int(sequence[i+1]) and not (sequence[i] == str(n) and sequence[i+1] == '1'):
                imperfect_transitions.append((i, sequence[i], sequence[i+1]))
        return imperfect_transitions

    def analyze_breakpoint(self, sequence, breakpoint):
        n = max(int(char) for char in sequence)
        left_context = sequence[max(0, breakpoint-n):breakpoint]
        right_context = sequence[breakpoint:min(len(sequence), breakpoint+n)]
        return {
            'left_context': left_context,
            'right_context': right_context,
            'left_permutation': self.is_permutation(left_context),
            'right_permutation': self.is_permutation(right_context)
        }

    def is_permutation(self, substring):
        n = len(set(substring))
        return len(substring) == n and set(substring) == set(str(i) for i in range(1, n+1))

    def is_valid_superpermutation(self, sequence):
        n = max(int(char) for char in sequence)
        all_permutations = set(''.join(map(str, p)) for p in itertools.permutations(range(1, n+1)))
        
        for i in range(len(sequence) - n + 1):
            substring = sequence[i:i+n]
            if substring in all_permutations:
                all_permutations.remove(substring)
        
        return len(all_permutations) == 0

    def count_imperfections(self, sequence):
        imperfections = 0
        n = max(int(char) for char in sequence)
        for i in range(len(sequence) - 1):
            if int(sequence[i]) + 1 != int(sequence[i+1]) and not (sequence[i] == str(n) and sequence[i+1] == '1'):
                imperfections += 1
        return imperfections

    def find_longest_perfect_segment(self, sequence):
        longest_segment = 0
        current_segment = 1
        n = max(int(char) for char in sequence)
        for i in range(len(sequence) - 1):
            if int(sequence[i]) + 1 == int(sequence[i+1]) or (sequence[i] == str(n) and sequence[i+1] == '1'):
                current_segment += 1
            else:
                longest_segment = max(longest_segment, current_segment)
                current_segment = 1
        return max(longest_segment, current_segment)

