# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/21725/construct.txt

**Extension:** .txt

**Lines:** 156 | **Words:** 600

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 39
- superpermutation: 39
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

import math
import itertools
import networkx as nx
from typing import List

class SuperpermutationProblem:
    def __init__(self, n: int):
        self.n = n
        self.symbols = list(range(1, n + 1))

    def formulate(self) -> List[str]:
        return [''.join(map(str, p)) for p in itertools.permutations(self.symbols)]

class SuperpermutationStrategy:
    def __init__(self, problem: SuperpermutationProblem, auto_mode: bool = False):
        self.problem = problem
        self.auto_mode = auto_mode

    def solve(self):
        selector = DynamicStrategySelector(self.problem)
        strategy_name, strategy_func = selector.select_strategy()
        print(f"Using strategy: {strategy_name}")
        
        if not self.auto_mode:
            if not get_user_input(f"Proceed with {strategy_name}? (y/n): "):
                return None  # Or implement alternative strategy selection

        superpermutation = strategy_func(self)
        refined_superpermutation = FormulaRefinement.refine_superpermutation(superpermutation, self.problem.n)
        
        if not self.auto_mode:
            print(f"Initial length: {len(superpermutation)}")
            print(f"Refined length: {len(refined_superpermutation)}")
            if not get_user_input("Accept refined superpermutation? (y/n): "):
                return superpermutation

        return refined_superpermutation

    def n_minus_1_shell(self) -> str:
        n = self.problem.n
        if n <= 2:
            return ''.join(map(str, range(1, n+1)))
        
        shell = self.n_minus_1_shell_recursive(n-1)
        return shell + str(n) + shell[1:]

    def n_minus_1_shell_recursive(self, n: int) -> str:
        if n == 2:
            return '12'
        prev_shell = self.n_minus_1_shell_recursive(n-1)
        return prev_shell + str(n) + prev_shell[1:]

    def prodigal_combination(self) -> str:
        n = self.problem.n
        shell = self.n_minus_1_shell()
        result = shell
        unused = set(self.problem.formulate())
        
        while unused:
            for i in range(len(result) - n + 1):
                substring = result[i:i+n]
                if substring in unused:
                    unused.remove(substring)
            
            if not unused:
                break
            
            next_perm = min(unused, key=lambda x: self._overlap(result, x))
            result += next_perm[self._overlap(result, next_perm):]
        
        return result

    def _overlap(self, s1: str, s2: str) -> int:
        for i in range(min(len(s1), len(s2)), 0, -1):
            if s1[-i:] == s2[:i]:
                return i
        return 0

    def de_bruijn_graph(self) -> str:
        n = self.problem.n
        graph = nx.DiGraph()
        
        permutations = self.problem.formulate()
        
        for perm in permutations:
            graph.add_edge(perm[:-1], perm[1:], label=perm[-1])
        
        circuit = list(nx.eulerian_circuit(graph))
        
        superpermutation = circuit[0][0]
        for edge in circuit:
            superpermutation += graph[edge[0]][edge[1]]['label']
        
        return superpermutation

class DynamicStrategySelector:
    def __init__(self, problem: SuperpermutationProblem):
        self.problem = problem
        self.strategies = [
            ('n_minus_1_shell', SuperpermutationStrategy.n_minus_1_shell),
            ('prodigal_combination', SuperpermutationStrategy.prodigal_combination),
            ('de_bruijn_graph', SuperpermutationStrategy.de_bruijn_graph)
        ]

    def select_strategy(self):
        n = self.problem.n
        if n <= 5:
            return self.strategies[0]  # n_minus_1_shell for small n
        elif 5 < n <= 7:
            return self.strategies[1]  # prodigal_combination for medium n
        else:
            return self.strategies[2]  # de_bruijn_graph for large n

class FormulaRefinement:
    @staticmethod
    def refine_superpermutation(superpermutation: str, n: int) -> str:
        refined = FormulaRefinement.rotate_segment(superpermutation, n)
        refined = FormulaRefinement.optimize_k_mers(refined, n)
        refined = FormulaRefinement.replace_prodigal(refined, n)
        return refined

    @staticmethod
    def rotate_segment(superpermutation: str, n: int) -> str:
        best = superpermutation
        for i in range(len(superpermutation)):
            rotated = superpermutation[i:] + superpermutation[:i]
            if len(set(rotated[j:j+n] for j in range(len(rotated)-n+1))) > len(set(best[j:j+n] for j in range(len(best)-n+1))):
                best = rotated
        return best

    @staticmethod
    def optimize_k_mers(superpermutation: str, n: int) -> str:
        k = n - 1
        k_mers = [superpermutation[i:i+k] for i in range(len(superpermutation)-k+1)]
        unique_k_mers = sorted(set(k_mers), key=k_mers.index)
        return ''.join(unique_k_mers)

    @staticmethod
    def replace_prodigal(superpermutation: str, n: int) -> str:
        permutations = [''.join(p) for p in itertools.permutations(''.join(str(i) for i in range(1, n+1)))]
        for i in range(len(superpermutation) - n + 1):
            if superpermutation[i:i+n] not in permutations:
                for perm in permutations:
                    if perm[0] == superpermutation[i-1] and perm[-1] == superpermutation[i+n]:
                        superpermutation = superpermutation[:i] + perm + superpermutation[i+n:]
                        break
        return superpermutation

def get_user_input(prompt: str) -> bool:
    while True:
        response = input(prompt).lower()
        if response in ['y', 'n']:
            return response == 'y'
        print("Please enter 'y' for yes or 'n' for no.")

