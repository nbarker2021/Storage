# File: ConStruct 6- New Build/ConStruct 6- New Build/~$an n=8 sequence.docx

**Extension:** .docx

**Lines:** 1 | **Words:** 9

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

(Error reading file: File is not a zip file)