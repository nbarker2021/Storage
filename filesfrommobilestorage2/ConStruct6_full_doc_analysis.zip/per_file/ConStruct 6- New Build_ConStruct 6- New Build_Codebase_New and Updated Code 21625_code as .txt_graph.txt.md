# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/New and Updated Code 21625/code as .txt/graph.txt

**Extension:** .txt

**Lines:** 33 | **Words:** 132

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

import networkx as nx
from typing import List, Tuple

class SupepermutationGraph:
    def __init__(self, n: int):
        self.n = n
        self.graph = self.create_graph()

    def create_graph(self) -> nx.DiGraph:
        G = nx.DiGraph()
        permutations = self.generate_permutations()
        for perm in permutations:
            for i in range(self.n):
                next_perm = perm[1:] + perm[0]
                G.add_edge(perm, next_perm)
                perm = next_perm
        return G

    def generate_permutations(self) -> List[str]:
        import itertools
        return [''.join(map(str, p)) for p in itertools.permutations(range(1, self.n + 1))]

    def find_hamiltonian_path(self) -> List[str]:
        return nx.approximation.traveling_salesman_problem(self.graph, cycle=False)

    def visualize_graph(self) -> None:
        import matplotlib.pyplot as plt
        pos = nx.spring_layout(self.graph)
        nx.draw(self.graph, pos, with_labels=True, node_color='lightblue', node_size=500, font_size=8, arrows=True)
        plt.title(f"Superpermutation Graph for n={self.n}")
        plt.show()

