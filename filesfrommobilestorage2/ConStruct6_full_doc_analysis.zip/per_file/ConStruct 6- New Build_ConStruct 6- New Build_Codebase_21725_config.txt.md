# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/21725/config.txt

**Extension:** .txt

**Lines:** 45 | **Words:** 182

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

import json

def get_user_input(prompt: str) -> bool:
    while True:
        response = input(prompt).lower()
        if response in ['y', 'n']:
            return response == 'y'
        print("Please enter 'y' for yes or 'n' for no.")

class ConfigManager:
    def __init__(self):
        self.settings = {
            'n': 8,
            'auto_loop': False,
            # ... other default settings
        }

    def load_settings(self, file_path):
        try:
            with open(file_path, 'r') as f:
                loaded_settings = json.load(f)
                self.settings.update(loaded_settings)
        except FileNotFoundError:
            print(f"Config file {file_path} not found. Using default settings.")
            if get_user_input("Would you like to create a new config file? (y/n): "):
                self.save_settings(file_path)
        except json.JSONDecodeError:
            print(f"Error parsing {file_path}. Using default settings.")
            if get_user_input("Would you like to overwrite the existing config file? (y/n): "):
                self.save_settings(file_path)

    def get_setting(self, key, default=None):
        return self.settings.get(key, default)

    def set_setting(self, key, value):
        self.settings[key] = value
        if get_user_input(f"Setting '{key}' updated. Would you like to save the changes? (y/n): "):
            self.save_settings('config.json')

    def save_settings(self, file_path):
        with open(file_path, 'w') as f:
            json.dump(self.settings, f, indent=4)
        print(f"Settings saved to {file_path}")

