# File: ConStruct 6- New Build/ConStruct 6- New Build/Codebase/21725/analysis.txt

**Extension:** .txt

**Lines:** 42 | **Words:** 159

## Headings (0)
(none)

## Keyword Hits
- SFBB: 0
- superperm: 15
- superpermutation: 15
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0

---

## Full Content

import math

class SuperpermutationAnalyzer:
    def __init__(self, superpermutation, n):
        self.superpermutation = superpermutation
        self.n = n

    def calculate_coverage(self):
        total_permutations = math.factorial(self.n)
        covered_permutations = len(set(self.superpermutation[i:i+self.n] for i in range(len(self.superpermutation) - self.n + 1)))
        return covered_permutations / total_permutations

    def calculate_efficiency(self):
        lower_bound = sum(math.factorial(i) for i in range(1, self.n + 1))
        return lower_bound / len(self.superpermutation)

    def analyze_hierarchy(self):
        hierarchy = []
        for i in range(2, self.n + 1):
            sub_superpermutation = self._extract_sub_superpermutation(i)
            hierarchy.append(f"n={i}: {sub_superpermutation}")
        return hierarchy

    def identify_imperfect_transitions(self):
        imperfect = []
        for i in range(len(self.superpermutation) - self.n):
            transition = self.superpermutation[i:i+self.n+1]
            if transition[:-1] != transition[1:]:
                imperfect.append(f"Position {i}: {transition}")
        return imperfect

    def _extract_sub_superpermutation(self, k):
        result = ""
        used_permutations = set()
        for i in range(len(self.superpermutation) - k + 1):
            perm = self.superpermutation[i:i+k]
            if perm not in used_permutations:
                result += perm[-1]
                used_permutations.add(perm)
        return result

