
import sys, pathlib, json, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.mdhg_v0_1_2025_08_13 import MDHG_v0_1_2025_08_13

def main():
    rng = np.random.default_rng(0)
    m = MDHG_v0_1_2025_08_13(dim=4, decay_lambda=0.05)
    base = rng.random((200,4))
    for i in range(200): m.insert(i, base[i])
    hot_ids = [1,3,5,7,9]
    for _ in range(10): m.bump_heat(hot_ids); m.decay()
    nn = m.k_nn(base[1] + 0.001, k=5)
    print("kNN near 1:", nn)
    print("top edges:", m.edges(topk=5))
    snap = m.snapshot()
    print("snapshot keys:", list(snap.keys()))
    m2 = MDHG_v0_1_2025_08_13.restore(snap)
    print("restored dim:", m2.dim, "vecs:", len(m2.vecs))

if __name__ == "__main__":
    main()
