
import sys, pathlib, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_4_2025_08_13 import AGRMController_v0_4_2025_08_13
from core.agrm.patching_v0_1_2025_08_13 import tour_length_v0_1_2025_08_13 as length_patching, patch_loop_v0_1_2025_08_13
from core.agrm.salesman_2opt_v0_1_2025_08_13 import tour_length_v0_1_2025_08_13 as length_2opt, two_opt_loop_v0_1_2025_08_13

def build_naive_tour(points, chosen):
    n = points.shape[0]
    chosen_order = []
    seen = set()
    for c in chosen:
        if c not in seen:
            chosen_order.append(c); seen.add(c)
    remaining = [i for i in range(n) if i not in seen]
    if len(chosen_order) < 3:
        chosen_order = list(range(min(3,n)))
        remaining = [i for i in range(n) if i not in chosen_order]
    tour = chosen_order[:]
    for k in remaining:
        best_pos, best_delta = 0, float("inf")
        for idx in range(len(tour)):
            a, b = tour[idx], tour[(idx+1)%len(tour)]
            delta = float(np.linalg.norm(points[a]-points[k]) + np.linalg.norm(points[k]-points[b]) - np.linalg.norm(points[a]-points[b]))
            if delta < best_delta:
                best_delta, best_pos = delta, idx+1
        tour.insert(best_pos, k)
    return tour

def main():
    rng = np.random.default_rng(42)
    pts = rng.random((200,2))
    ctrl = AGRMController_v0_4_2025_08_13(cfg={"theta_open":0.5,"theta_close":0.2,"cooldown":1,"max_steps_per_arm":8,"num_sectors":32,"num_shells":8})
    res = ctrl.solve(pts, max_ticks=8)
    chosen = res["chosen"]; sectors = res["meta"]["sectors"]
    partial = []
    seen=set()
    for c in chosen:
        if c not in seen:
            partial.append(c); seen.add(c)
    if len(partial)<3: partial = list(range(3))
    tour_patch, stats = patch_loop_v0_1_2025_08_13(pts, partial, sectors, budget_edges=200, budget_iter=200)
    L_before = length_2opt(pts, tour_patch)
    tour_opt, delta = two_opt_loop_v0_1_2025_08_13(pts, tour_patch, max_iter=200)
    L_after = length_2opt(pts, tour_opt)
    print("2-opt Δ:", L_after - L_before, "L_before:", L_before, "L_after:", L_after)

if __name__ == "__main__":
    main()
