
class StateBus_v0_4_2025_08_13:
    def __init__(self):
        self.current_phase = "init"
        self.vws = None
        self.meta = {"visited_sectors": set()}
        self.stats = {
            "ticks": 0, "steps": 0, "stalls": 0,
            "gates_open": 0, "gates_close": 0,
            "thrash": 0, "sectors_visited": 0,
            "inverse_steps": 0, "inverse_hits": 0,
            "thrash_by_sector": {}, "coverage_gain": 0,
            "main_R_sum": 0.0, "inverse_R_sum": 0.0
        }
        self._gate = {}
        self._cool = {}
    def note_gate(self, sec: int, opened: bool):
        prev = self._gate.get(sec, False)
        if opened != prev:
            self.stats["thrash"] += 1
            self.stats["thrash_by_sector"][sec] = self.stats["thrash_by_sector"].get(sec, 0) + 1
        self._gate[sec] = opened
        if opened: self.stats["gates_open"] += 1
        else: self.stats["gates_close"] += 1
    def cooldown(self, sec: int) -> int: return self._cool.get(sec, 0)
    def set_cooldown(self, sec: int, v: int): self._cool[sec] = max(0, int(v))
    def tick_cooldowns(self):
        for k in list(self._cool.keys()): self._cool[k] = max(0, self._cool[k]-1)
    def bump(self, key, val=1): self.stats[key] = self.stats.get(key, 0) + val
