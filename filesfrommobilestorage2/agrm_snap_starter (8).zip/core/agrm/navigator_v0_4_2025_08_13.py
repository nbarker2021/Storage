
import math, numpy as np
from .e8dof_state_v0_1_2025_08_13 import E8DoFState_v0_1_2025_08_13, phi_stagger_schedule_v0_1_2025_08_13
class NavigatorGR_v0_4_2025_08_13:
    def __init__(self, cfg, bus):
        self.cfg=cfg; self.bus=bus
        self.num_shells=cfg.get("num_shells",8); self.num_sectors=cfg.get("num_sectors",32)
        self.theta_open=cfg.get("theta_open",0.5); self.theta_close=cfg.get("theta_close",0.2)
        self.align_gain=cfg.get("align_gain",0.2); self.cooldown=cfg.get("cooldown",1)
        self.inverse_budget=cfg.get("inverse_budget",1); self.max_steps_per_arm=cfg.get("max_steps_per_arm",8)
        self.state=E8DoFState_v0_1_2025_08_13(0,0,0,0,0,0,1.0,0.1)
    def assign_shells_and_sectors(self, points):
        center=points.mean(axis=0); vecs=points-center; radii=np.linalg.norm(vecs,axis=1)+1e-9
        angles=np.arctan2(vecs[:,1],vecs[:,0]); rmin,rmax=radii.min(),radii.max()
        shell_edges=np.linspace(rmin,rmax+1e-9,self.num_shells+1); shells=np.digitize(radii,shell_edges)-1
        sec_edges=np.linspace(-math.pi,math.pi,self.num_sectors+1); sectors=np.digitize(angles,sec_edges)-1
        self.bus.meta.update({"center":center.tolist(),"shells":shells.tolist(),"sectors":sectors.tolist(),"shell_edges":shell_edges.tolist(),"sec_edges":sec_edges.tolist()})
        return self.bus.meta
    def _route_efficiency(self, points, idx):
        vws=self.bus.vws; ef=0.0
        if vws is not None:
            for j in range(points.shape[0]):
                a,b=(idx,j) if idx<j else (j,idx); ef+=vws.edge_freq.get((a,b),0)
        ef=math.log1p(ef); sectors=self.bus.meta.get("sectors",[])
        if not sectors: return ef, 0.0, -1
        sec=sectors[idx]; target=int(self.state.phi*self.num_sectors)%self.num_sectors
        align=1.0-abs((sec-target)%self.num_sectors)/(self.num_sectors/2.0)
        return ef+0.5*align, align, sec
    def _gate(self, sec, score, align):
        theta_o=self.theta_open - self.align_gain*align
        theta_c=self.theta_close + self.align_gain*align
        cd=self.bus.cooldown(sec); opened=self.bus._gate.get(sec, False)
        if opened:
            if score<=theta_c and cd<=0: opened=False; self.bus.set_cooldown(sec, self.cooldown)
        else:
            if score>=theta_o and cd<=0: opened=True; self.bus.set_cooldown(sec, self.cooldown)
        self.bus.note_gate(sec, opened)
        return opened
    def sweep_step(self, points):
        used=set(); sectors=self.bus.meta["sectors"]; shells=self.bus.meta["shells"]; n=points.shape[0]
        counts={}; 
        for s in sectors: counts[s]=counts.get(s,0)+1
        sec_order=sorted(counts.keys(), key=lambda s:(-counts[s],s))
        moved=0; chosen=[]; main_R_acc=0.0; main_moves=0
        for sec in sec_order:
            if sec in used: continue
            cand=[i for i in range(n) if sectors[i]==sec]
            if not cand: continue
            cand.sort(key=lambda i:shells[i]); idx=cand[0]
            score,align,sec_=self._route_efficiency(points,idx)
            if self._gate(sec_,score,align):
                chosen.append(idx); used.add(sec); moved+=1; main_R_acc+=score; main_moves+=1
                if sec not in self.bus.meta["visited_sectors"]:
                    self.bus.meta["visited_sectors"].add(sec); self.bus.bump("coverage_gain",1)
            if moved>=self.max_steps_per_arm: break
        inv_budget=self.inverse_budget
        if inv_budget>0:
            target=int(self.state.phi*self.num_sectors)%self.num_sectors
            inv_sec=(target+self.num_sectors//2)%self.num_sectors
            inv_cand=[i for i in range(n) if sectors[i]==inv_sec]
            if inv_cand:
                inv_cand.sort(key=lambda i:shells[i]); idx=inv_cand[0]
                score,align,sec_=self._route_efficiency(points,idx); score_probe=score-0.2
                if self._gate(sec_,score_probe,align) and inv_budget>0:
                    chosen.append(idx); moved+=1; self.bus.bump("inverse_steps",1); self.bus.stats["inverse_R_sum"]+=score
                    if sec_ not in self.bus.meta["visited_sectors"]:
                        self.bus.meta["visited_sectors"].add(sec_); self.bus.bump("coverage_gain",1)
                    if score >= (self.theta_open+0.2): self.bus.bump("inverse_hits",1)
        if main_moves>0: self.bus.stats["main_R_sum"] += main_R_acc/max(1,main_moves)
        self.bus.bump("ticks",1); self.bus.bump("steps",moved); self.bus.stats["sectors_visited"] += len(used)
        self.state.phi = phi_stagger_schedule_v0_1_2025_08_13(self.bus.stats["ticks"], self.state.phi)
        if moved==0: self.bus.bump("stalls",1)
        self.bus.tick_cooldowns()
        return chosen
