
import numpy as np

def tour_length_v0_1_2025_08_13(points, tour):
    L=0.0
    for a,b in zip(tour, tour[1:]+tour[:1]):
        L += float(np.linalg.norm(points[a]-points[b]))
    return L

def two_opt_once_v0_1_2025_08_13(points, tour):
    n=len(tour); best=None; best_delta=0.0
    def edge_len(a,b): return float(np.linalg.norm(points[a]-points[b]))
    for i in range(n-1):
        for k in range(i+2, n if i>0 else n-1):
            a,b = tour[i], tour[(i+1)%n]
            c,d = tour[k], tour[(k+1)%n]
            delta = (edge_len(a,c)+edge_len(b,d)) - (edge_len(a,b)+edge_len(c,d))
            if delta < best_delta:
                best_delta = delta; best = (i+1, k)
    if best is None: return tour, 0.0
    i1,k = best
    new_tour = tour[:i1] + list(reversed(tour[i1:k+1])) + tour[k+1:]
    return new_tour, best_delta

def two_opt_loop_v0_1_2025_08_13(points, tour, max_iter=200):
    total_delta = 0.0
    for _ in range(max_iter):
        tour, delta = two_opt_once_v0_1_2025_08_13(points, tour)
        if delta >= 0.0: break
        total_delta += delta
    return tour, total_delta
