
import numpy as np
from .statebus_v0_4_2025_08_13 import StateBus_v0_4_2025_08_13
from .navigator_v0_4_2025_08_13 import NavigatorGR_v0_4_2025_08_13
from .vector_sketch_v0_1_2025_08_13 import vector_warm_start
class AGRMController_v0_4_2025_08_13:
    def __init__(self, cfg=None):
        self.cfg=cfg or {}
        self.bus=StateBus_v0_4_2025_08_13()
        self.navigator=NavigatorGR_v0_4_2025_08_13(self.cfg, self.bus)
    def solve(self, points, max_ticks=8):
        if not isinstance(points, np.ndarray): points=np.asarray(points, dtype=float)
        self.bus.vws = vector_warm_start(points, k=self.cfg.get("vws_k",8), seeds=self.cfg.get("vws_seeds",8))
        self.bus.current_phase="sweep"
        _ = self.navigator.assign_shells_and_sectors(points)
        chosen_all = []
        for _ in range(max_ticks): chosen_all.extend(self.navigator.sweep_step(points))
        return {"stats": self.bus.stats, "chosen": chosen_all, "meta": self.bus.meta}
