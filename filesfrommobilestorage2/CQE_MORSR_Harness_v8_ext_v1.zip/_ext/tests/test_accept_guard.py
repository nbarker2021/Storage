
from cqe_ext.acceptance import AcceptGuard

def test_accept_guard_paths():
    policy_ext = {
        "acceptance":{
            "eps_phi":1e-6,
            "plateau_cap":0,
            "midpoint_requires_parity_drop":True,
            "quorum":{"enabled":True,"metrics":["geom","parity","sparsity"],"rule":"m_of_n","m":2},
            "escrow":{"enabled":True,"cap":1e-3,"horizon":3}
        }
    }
    guard = AcceptGuard(policy_ext)
    bc = {"geom":1.0,"parity":2.0,"sparsity":0.1}
    ac = {"geom":0.9,"parity":1.5,"sparsity":0.11}  # improves on at least two metrics
    btot = 2.0
    atot = 2.0 + 5e-7  # small uphill
    acc, reason = guard.decide("Rtheta", btot, atot, bc, ac, None, None)
    assert acc is True and reason in ("escrow_uphill","strict_decrease")
