CQE/MORSR Extensions v1 — Escrow, Φ quorum, Thermostat, Counterfactual shells, NegProof cache, ZK parity stub.
See policy/cqe_policy_ext_v1.json and cqe_ext/* modules for integration points.