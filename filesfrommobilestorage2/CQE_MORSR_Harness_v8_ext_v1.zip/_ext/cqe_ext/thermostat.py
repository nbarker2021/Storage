
from __future__ import annotations
from typing import Dict, Any

class SectorThermostat:
    def __init__(self, target_ratio_min: float, kp: float=0.5, ki: float=0.0, kd: float=0.0,
                 initial_lambda: float=0.0, bounds=(-1.0,1.0)):
        self.target = target_ratio_min
        self.kp, self.ki, self.kd = kp, ki, kd
        self.err_int = 0.0
        self.last_err = None
        self.lam = initial_lambda
        self.bounds = bounds

    def step(self, sector_hist: Dict[str,int]) -> float:
        if not sector_hist:
            return self.lam
        mx = max(sector_hist.values())
        mn = min(sector_hist.values())
        ratio = (mn / mx) if mx>0 else 1.0
        err = self.target - ratio
        self.err_int += err
        derr = 0.0 if self.last_err is None else (err - self.last_err)
        self.last_err = err
        delta = self.kp*err + self.ki*self.err_int + self.kd*derr
        self.lam = max(self.bounds[0], min(self.bounds[1], self.lam + delta))
        return self.lam
