
from __future__ import annotations
from typing import Dict, Any
import json, hashlib, time
from pathlib import Path

class NegativeProofCache:
    def __init__(self, path: str):
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        self.idx_file = self.path/"index.jsonl"

    @staticmethod
    def _key(policy_hash: str, seed_hash: str, shell_fingerprint: str) -> str:
        s = f"{policy_hash}|{seed_hash}|{shell_fingerprint}"
        return hashlib.sha256(s.encode()).hexdigest()

    def check(self, policy_hash: str, seed_hash: str, shell_fingerprint: str) -> bool:
        key = self._key(policy_hash, seed_hash, shell_fingerprint)
        if not self.idx_file.exists():
            return False
        for line in self.idx_file.read_text().splitlines():
            try:
                rec = json.loads(line)
                if rec.get("key")==key:
                    return True
            except: pass
        return False

    def add(self, policy_hash: str, seed_hash: str, shell_fingerprint: str, metrics: Dict[str,Any]):
        key = self._key(policy_hash, seed_hash, shell_fingerprint)
        rec = {"key": key, "policy_hash": policy_hash, "seed_hash": seed_hash,
               "shell": shell_fingerprint, "metrics": metrics, "ts": time.time()}
        with open(self.idx_file, "a") as f:
            f.write(json.dumps(rec)+"\n")
