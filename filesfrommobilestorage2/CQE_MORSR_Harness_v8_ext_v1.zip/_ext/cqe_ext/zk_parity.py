
from __future__ import annotations
from typing import Dict, Any
import hashlib, json

def prove_lane_global_syndromes(lane_digest: str, global_digest: str, lane_norm: int, global_norm: int, salt: str) -> str:
    payload = {"ld": lane_digest, "gd": global_digest, "ln": int(lane_norm), "gn": int(global_norm), "salt": salt}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

def verify_proof(proof: str, lane_digest: str, global_digest: str, lane_norm: int, global_norm: int, salt: str) -> bool:
    expected = prove_lane_global_syndromes(lane_digest, global_digest, lane_norm, global_norm, salt)
    return expected == proof
