
from __future__ import annotations
from typing import Dict, Any, List
import json, hashlib, time, copy, math
from pathlib import Path
from . import overlay as ovl
from . import operators as ops
from cqe_ext.phi_ensemble import compute_components, total_phi
from cqe_ext.acceptance import AcceptGuard
from cqe_ext.thermostat import SectorThermostat
from cqe_ext.cache import NegativeProofCache
from cqe_ext.shells_cf import fingerprint_radial, fingerprint_graph, pick_winner

def sha256_hex(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

def overlay_from_json(path: str) -> ovl.EO:
    data = json.loads(Path(path).read_text())
    nodes = data["nodes"]
    pres_raw = nodes["present"]
    present = []
    for v in pres_raw:
        if isinstance(v, bool): present.append(v)
        elif isinstance(v, (int,float)): present.append(bool(int(v)))
        elif isinstance(v, str): present.append(v.lower() in ('1','true','t','yes','y'))
        else: present.append(bool(v))
    return ovl.EO(present=present, w=nodes["w"], phi=nodes["phi"], pose=data.get("pose",{}))

def to_json(eo: ovl.EO) -> Dict[str,Any]:
    return {"frame":"e8_canonical_v1","nodes":{"present":eo.present,"w":eo.w,"phi":eo.phi},"pose":eo.pose}

def parity_norms(eo: ovl.EO) -> Dict[str,int]:
    lane_norm = sum(1 for b in eo.present if b) % 2
    global_norm = sum(1 for b in eo.present[:240] if b) % 2
    return {"lane_norm": lane_norm, "global_norm": global_norm}

def morsr_ext(seed_overlay_path: str, base_policy_path: str, ext_policy_path: str,
              region_out: str, handshakes_out: str, cache_dir: str = "negproof_cache"):
    seed = overlay_from_json(seed_overlay_path)
    base_policy = json.loads(Path(base_policy_path).read_text()) if base_policy_path else {"geometry":{"weight":1.0},"parity":{}}
    ext_policy  = json.loads(Path(ext_policy_path).read_text())
    policy = {"base": base_policy, "ext": ext_policy}

    guard = AcceptGuard(ext_policy)
    npc = NegativeProofCache(cache_dir)

    seed_json = to_json(seed)
    seed_hash = sha256_hex(json.dumps(seed_json, sort_keys=True).encode())
    policy_hash = sha256_hex(json.dumps(policy, sort_keys=True).encode())

    region = {"policy":{"base":base_policy,"ext":ext_policy},
              "rings":[], "stages":[], "overlay_store":{}, "status":None}

    variants = ext_policy["shells"]["counterfactual"]["variants"]
    selection_metric = ext_policy["shells"]["counterfactual"]["selection_metric"]

    for stage_idx in range(2):  # two-stage demo (radial vs graph), can be extended
        varA, varB = variants[0], variants[1]
        fpA = fingerprint_radial(varA["base"], varA["factor"], stage_idx) if varA["mode"]=="radial" else fingerprint_graph(varA["base"], varA["factor"], stage_idx)
        fpB = fingerprint_radial(varB["base"], varB["factor"], stage_idx) if varB["mode"]=="radial" else fingerprint_graph(varB["base"], varB["factor"], stage_idx)

        if ext_policy.get("negative_proof_cache",{}).get("enabled",False):
            if npc.check(policy_hash, seed_hash, fpA) and npc.check(policy_hash, seed_hash, fpB):
                region["stages"].append({"stage": stage_idx, "skipped":"negative_proof_cache_hit"})
                continue

        def try_ops(fp, variant):
            results = []
            def attempt(op_name, apply_op):
                # clone
                cand = ovl.EO(present=seed.present[:], w=seed.w[:], phi=seed.phi[:], pose=seed.pose.copy())
                bcomp = compute_components(to_json(seed)); btot = total_phi(bcomp, {"geom":1.0,"parity":1.0,"sparsity":0.02})
                pb = {"lane_norm": sum(1 for b in seed.present if b), "global_norm": sum(1 for b in seed.present[:240] if b)}
                # apply op if available
                ok = True
                try:
                    apply_op(cand)
                except Exception as e:
                    ok = False
                acomp = compute_components(to_json(cand)); atot = total_phi(acomp, {"geom":1.0,"parity":1.0,"sparsity":0.02})
                pa = {"lane_norm": sum(1 for b in cand.present if b), "global_norm": sum(1 for b in cand.present[:240] if b)}
                accepted, reason = guard.decide(op_name, btot, atot, bcomp, acomp, pb, pa)
                results.append({"variant": variant["mode"], "fp": fp, "op": op_name, "phi_before": btot, "phi_after": atot,
                                "delta": atot - btot, "accepted": accepted, "reason": reason, "ok": ok, "overlay_id": sha256_hex(json.dumps(to_json(cand), sort_keys=True).encode())})
            # Attempt set
            if hasattr(ops, "op_Rtheta"):
                attempt("Rtheta", lambda c: ops.op_Rtheta(c, step=1))
            if hasattr(ops, "op_Midpoint"):
                attempt("Midpoint", lambda c: ops.op_Midpoint(c))
            if hasattr(ops, "op_WeylReflect"):
                attempt("WeylReflect", lambda c: ops.op_WeylReflect(c, simple_idx=0))
            return results

        statsA = try_ops(fpA, varA)
        statsB = try_ops(fpB, varB)

        def summarize(stats):
            accepts = sum(1 for r in stats if r["accepted"])
            strict_gain = sum(-r["delta"] for r in stats if r["delta"] < 0)
            return {"accepts": accepts, "strict_gain": strict_gain}

        sa = summarize(statsA); sb = summarize(statsB)
        winner = pick_winner(sa, sb, selection_metric=selection_metric)
        region["stages"].append({"stage": stage_idx, "variantA": {"fp": fpA, "stats": sa, "lanes": statsA},
                                 "variantB": {"fp": fpB, "stats": sb, "lanes": statsB}, "winner": winner})

        thr = ext_policy.get("negative_proof_cache",{}).get("threshold", 1e-3)
        if sa["strict_gain"] < thr and sb["strict_gain"] < thr:
            npc.add(policy_hash, seed_hash, fpA, sa)
            npc.add(policy_hash, seed_hash, fpB, sb)

    region["status"] = "completed_ext"
    Path(region_out).write_text(json.dumps(region, indent=2))
    with open(handshakes_out, "w") as f:
        for st in region["stages"]:
            if "variantA" in st:
                for rec in st["variantA"]["lanes"] + st["variantB"]["lanes"]:
                    f.write(json.dumps(rec)+"\n")
