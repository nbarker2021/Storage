Earth Fusion Stitch
