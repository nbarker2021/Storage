Zip I/O Stitch
