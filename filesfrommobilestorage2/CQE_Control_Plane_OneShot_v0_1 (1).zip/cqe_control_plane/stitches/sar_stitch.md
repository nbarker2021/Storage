SAR Stitch
