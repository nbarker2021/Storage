CQE for Humans — quick guide
