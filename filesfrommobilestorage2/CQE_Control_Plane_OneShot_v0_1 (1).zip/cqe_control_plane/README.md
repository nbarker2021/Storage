# CQE Control Plane — One‑Shot Mode
See runtime/config.yaml, ui/octad_braid.html, registry/, compliance/, stitches/, proofs/, dashboards/, nuggets/
