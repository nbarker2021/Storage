
import sys, pathlib, json, numpy as np, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agents.registry_v0_1_2025_08_13 import AgentRegistry_v0_1_2025_08_13 as AgentRegistry
from core.agents.contracts_v0_1_2025_08_13 import AgentSpec_v0_1_2025_08_13 as AgentSpec, Capability_v0_1_2025_08_13 as Capability, Permission_v0_1_2025_08_13 as Permission, Task_v0_1_2025_08_13 as Task
from core.agents.sdk_v0_1_2025_08_13 import EchoAgent_v0_1_2025_08_13 as EchoAgent, TSPAgent_v0_1_2025_08_13 as TSPAgent
from core.agents.orchestrator_v0_1_2025_08_13 import Orchestrator_v0_1_2025_08_13 as Orchestrator
from core.repo.archivist_v0_1_2025_08_13 import Archivist_v0_1_2025_08_13 as Archivist
from core.utils.export_v0_1_2025_08_13 import to_jsonl

def build_registry():
    reg = AgentRegistry()
    echo_spec = AgentSpec(agent_id="echo.agent", version="v0_1_2025_08_13",
        capabilities=[Capability(name="echo", inputs=["text"], outputs=["text"])],
        permissions=[Permission(scope="universe:user", reason="echo returns user text")],
        tags=["text","utility"])
    tsp_spec = AgentSpec(agent_id="tsp.agent", version="v0_1_2025_08_13",
        capabilities=[Capability(name="tsp_route", inputs=["points"], outputs=["tour","length"])],
        permissions=[Permission(scope="universe:work", reason="route is work-universe")],
        tags=["route","graph","geometry"])
    reg.register(echo_spec); reg.register(tsp_spec)
    return reg

def main():
    reg = build_registry()
    orch = Orchestrator(reg)
    agents = {"echo.agent": EchoAgent(), "tsp.agent": TSPAgent()}
    arc = Archivist()
    arc.add("work", {"kind":"spec","name":"TSP","notes":"Routing tasks"})
    arc.add("user", {"kind":"pref","name":"tone","value":"concise"})
    projected = arc.projector(["work","user"], predicates={"limit":5})
    print("Projector keys:", list(projected.keys()))
    rng = np.random.default_rng(11); pts = rng.random((90,2)).tolist()
    t = Task(intent="route", requires=["tsp_route"], universes=["work"], inputs={"points": pts, "context": projected}, constraints={"seconds": 5.0, "hot_tags": ["graph","geometry"]})
    r = orch.route(t, agents)
    print("Selected agent:", r.get("agent"))
    print("Plan ok:", r.get("plan_stats",{}).get("ok"), "Act ok:", r.get("output_stats",{}).get("ok"))
    if "output" in r and "length" in r["output"]:
        print("Route length:", r["output"]["length"])
    rows = [{"ts": time.time(), "agent": r.get("agent"), **(r.get("plan_stats",{})), "phase":"plan"}, {"ts": time.time(), "agent": r.get("agent"), **(r.get("output_stats",{})), "phase":"act"}]
    path = to_jsonl("experiments/out/agents_metrics.jsonl", rows); print("Metrics JSONL:", path)

if __name__ == "__main__": main()
