
from dataclasses import dataclass
@dataclass
class E8DoFState_v0_1_2025_08_13:
    x: float; y: float; z: float; roll: float; pitch: float; yaw: float; sigma: float; phi: float
