
"""
DualWriteQueue_v0_1_2025_08_13
Records lightweight hashing events (inline path) and can apply them to MDHG later.
- Stores edges with weights and heat per id.
- On flush, updates MDHG .edge and .heat maps directly (and leaves MDHG.vecs/meta alone).
"""
from collections import defaultdict

class DualWriteQueue_v0_1_2025_08_13:
    def __init__(self):
        self.heat = defaultdict(float)        # id -> heat
        self.edges = defaultdict(float)       # (a,b) -> weight

    def record_heat(self, ids):
        for i in ids:
            self.heat[i] += 1.0
        # optional: also edges for co-use of this batch
        for a in ids:
            for b in ids:
                if a<b:
                    self.edges[(a,b)] += 1.0

    def record_edge_weight(self, a, b, w=1.0):
        if a>b: a,b=b,a
        self.edges[(a,b)] += float(w)

    def flush_to_mdhg(self, mdhg):
        # mdhg expected to have .heat and .edge dicts
        for i, h in self.heat.items():
            mdhg.heat[i] += float(h)
        for (a,b), w in self.edges.items():
            if a>b: a,b=b,a
            mdhg.edge[(a,b)] += float(w)
        # clear after flush
        self.heat.clear(); self.edges.clear()
        return True
