
"""
AgentCenter_v0_1_2025_08_13
- Manages registered agents, lifecycles, and adapters.
- Provides "porter" interface for moving data (respecting universe scopes).
"""
from .registry_v0_1_2025_08_13 import AgentRegistry_v0_1_2025_08_13 as Registry
class AgentCenter_v0_1_2025_08_13:
    def __init__(self, registry=None):
        self.registry = registry or Registry()
        self.adapters = {}
    def add_adapter(self, name, adapter):
        self.adapters[name] = adapter
    def get_adapter(self, name):
        return self.adapters.get(name)
