
import numpy as np
from agrm.mdhg.samplers import random_sampler, lhs_sampler, poisson_disk_sampler

def test_shapes():
    Xr = random_sampler(100, d=3)
    Xl = lhs_sampler(100, d=3)
    Xp = poisson_disk_sampler(200, d=2)
    assert Xr.shape == (100,3)
    assert Xl.shape == (100,3)
    assert Xp.shape[1] == 2 and Xp.shape[0] > 0

