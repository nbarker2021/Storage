
"""
VWS Bridge (refreshed)
- Seeding strategies: grid | exact | lhs | poisson | random
- Force-grid guard (for large N): forbids non-grid when N>=N_guard and force_grid=True.
- Sampler-based strategies pick nearest actual points to sampler sites.
"""
from typing import Dict, Any
import numpy as np
from .samplers import lhs_sampler, poisson_disk_sampler, random_sampler

def seed_vws_from_mdhg(points: np.ndarray, *, strategy:str="grid", grid_size:int=64,
                       force_grid:bool=True, N_guard:int=4000, journal=None,
                       seed_count:int=None, sampler_seed:int=23) -> Dict[str,Any]:
    N, d = points.shape
    if force_grid and N >= N_guard and strategy != "grid":
        if journal: journal.log("seed_guard_violation", N=N, asked=strategy, N_guard=N_guard)
        raise RuntimeError(f"force_grid active: N={N} >= {N_guard}, strategy='{strategy}' forbidden")

    chosen = []
    if strategy == "grid":
        # Simple uniform grid select: choose nearest points to grid centroids
        g = max(2, int(grid_size))
        xs = np.linspace(0,1,g); ys = np.linspace(0,1,g)
        idxs = []
        for x in xs:
            for y in ys:
                target = np.array([x,y] + [0]*(d-2), dtype=float)
                j = np.argmin(((points[:, :d] - target)**2).sum(axis=1))
                idxs.append(int(j))
        chosen = sorted(set(idxs))
        if journal: journal.log("seed_branch", branch="grid", N=N, picks=len(chosen), grid_size=grid_size)
    elif strategy == "exact":
        if journal: journal.log("seed_branch", branch="exact", N=N)
        dists = np.linalg.norm(points[:, None, :] - points[None, :, :], axis=2)
        central = np.argsort(dists.sum(axis=1))[:min(64, N)].tolist()
        chosen = central
    elif strategy in ("lhs","poisson","random"):
        K = int(np.sqrt(N)) if seed_count is None else int(seed_count)
        if strategy=="lhs":
            sites = lhs_sampler(K, d=d, seed=sampler_seed)
        elif strategy=="poisson":
            sites = poisson_disk_sampler(K, d=d, seed=sampler_seed)
        else:
            sites = random_sampler(K, d=d, seed=sampler_seed)
        idxs = []
        for s in sites:
            j = int(np.argmin(np.linalg.norm(points - s, axis=1)))
            idxs.append(j)
        chosen = sorted(set(idxs))
        if journal: journal.log("seed_branch", branch=strategy, N=N, picks=len(chosen))
    else:
        if journal: journal.log("seed_error", msg="unknown strategy", asked=strategy)
        raise ValueError(f"unknown strategy: {strategy}")
    return {"strategy": strategy, "indices": chosen, "N": N}
