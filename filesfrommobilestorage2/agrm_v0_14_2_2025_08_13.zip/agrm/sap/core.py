
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

@dataclass
class SAPEvent:
    type: str
    payload: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SAPVerdict:
    allow: bool
    reason: str = ""
    actions: List[str] = field(default_factory=list)

class Sentinel:
    """Top-level governance: evaluates rules, escalates to Arbiter, and routes via Porter."""
    def __init__(self, rules: Optional[List[Callable[[SAPEvent], Optional[SAPVerdict]]]] = None):
        self.rules = rules or []
        self.violations: List[Dict[str, Any]] = []

    def register_rule(self, rule: Callable[[SAPEvent], Optional[SAPVerdict]]):
        self.rules.append(rule)

    def evaluate(self, event: SAPEvent) -> SAPVerdict:
        for rule in self.rules:
            v = rule(event)
            if v is not None and not v.allow:
                self.violations.append({"event": event, "verdict": v})
                return v
        return SAPVerdict(True, "sentinel_pass")

class Arbiter:
    """Determines quarantine/stop-and-defer; can demand state inspection."""
    def __init__(self):
        self.quarantine_log: List[Dict[str, Any]] = []

    def quarantine(self, event: SAPEvent, reason: str) -> SAPVerdict:
        v = SAPVerdict(False, reason=reason, actions=["quarantine","defer"])
        self.quarantine_log.append({"event": event, "verdict": v})
        return v

class Porter:
    """Only allowed carrier of data; enforces i/o gates and journaling."""
    def __init__(self, io_allowed: bool = True):
        self.io_allowed = io_allowed
        self.log: List[Dict[str, Any]] = []

    def carry(self, data: Any, meta: Dict[str, Any]) -> bool:
        self.log.append({"meta": meta, "size": getattr(data, "__len__", lambda:None)()})
        return self.io_allowed

# Mid/Base level mirrors would compose Sentinel/Arbiter/Porter per family group.
