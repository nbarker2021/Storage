
import json, pathlib
from typing import Dict, Any

def load_profile(path: str) -> Dict[str, Any]:
    p = pathlib.Path(path)
    return json.loads(p.read_text(encoding="utf-8"))
