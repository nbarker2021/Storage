from ..agrm.fastlane import FastLane

import numpy as np
from ..utils.journal import Journal_v0_1_2025_08_13 as Journal
import time
from ..mdhg.vws_bridge import seed_vws_from_mdhg as seed_vws
from ..mdhg.adjacency import build_adjacency, build_elevators
from ..sap.core import Sentinel, Arbiter, Porter, SAPEvent
from ..archivist.repository import Repository, Archivist, Projector
from ..snap.ops_center import SnapOpsCenter

class AGRMController_v0_7_2025_08_13:
    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.journal = Journal()
        self.stats = {}

    def solve(self, points, max_ticks=3):
        t0 = time.perf_counter()
        pts = np.asarray(points, dtype=float)
        N, d = pts.shape
        # Optional governance + archivist + fastlane + snap ops (flagged)
        enable_sap     = bool(self.cfg.get("enable_sap", False))
        enable_archive = bool(self.cfg.get("enable_archivist", False))
        enable_fast    = bool(self.cfg.get("enable_fastlane", False))
        enable_snapops = bool(self.cfg.get("enable_snap_ops", False))

        if enable_sap:
            self.sentinel = Sentinel()
            # Example minimal rule: block if cfg says forbidden (demo only)
            def forbid(ev: SAPEvent):
                if ev.payload.get("forbidden"): 
                    from types import SimpleNamespace
                    return SimpleNamespace(allow=False, reason="forbidden_content", actions=["quarantine"])
                return None
            self.sentinel.register_rule(forbid)
            self.arbiter = Arbiter()
            self.porter  = Porter(io_allowed=True)

        if enable_archive:
            self.repo = Repository(self.cfg.get("repository_root", "/mnt/data/repository_store_v0_1_2025_08_13"))
            self.archivist = Archivist(self.repo)
            self.projector = Projector()

        if enable_snapops:
            self.snap_ops = SnapOpsCenter()
            # Register one example family/type rule; users extend this registry externally
            self.snap_ops.register_family_type("culture","creative", {"compat":{"preferred_with":["fiction"], "avoid_with":["science"]}, "weights":{"coverage":1.0,"freshness":0.4}})
    

        # Seeding
        vws = None if self.cfg.get("vws_skip_seed") else seed_vws(
            pts,
            strategy=self.cfg.get("seeding_strategy","grid"),
            grid_size=int(self.cfg.get("vws_grid_size",64)),
            force_grid=bool(self.cfg.get("vws_force_grid",True)),
            N_guard=int(self.cfg.get("vws_N_guard",4000)),
            journal=self.journal
        )
        self.stats["seed_strategy"] = vws["strategy"] if vws else "skipped"
        self.stats["seed_picks"] = int(len(vws["indices"])) if vws else 0

        # Optional adjacency prefilter
        if self.cfg.get("use_adjacency_prefilter"):
            adj = build_adjacency(pts, k=int(self.cfg.get("adj_k",8)), buckets=int(self.cfg.get("adj_buckets",64)))
            elv = build_elevators(pts, adj, quota=int(N//50))
            self.stats["adj_avg_degree"] = float(adj.get("avg_degree",0.0))
            self.stats["elevators"] = int(elv.get("count",0))
        else:
            self.stats["adj_avg_degree"] = 0.0
            self.stats["elevators"] = 0

        # Fake sweep stats for demonstration (since core navigator not wired here)
        steps = max_ticks * 6
        ticks = max_ticks
        coverage = min(1.0, 0.1 + 0.02 * self.stats["seed_picks"])

        
        # --- Integration tail (flagged) ---
        total_sec = time.perf_counter() - t0
        summary = {
            "duration_sec": total_sec,"verdict": "promoted", "steps": steps, "ticks": ticks, "coverage_rate": coverage, **self.stats}

        if enable_sap:
            ver = self.sentinel.evaluate(SAPEvent(type="solve_summary", payload={"forbidden": False}))
            self.stats["sap_allow"] = bool(getattr(ver, "allow", True))

        if enable_snapops:
            artifact = {"families": self.cfg.get("snap_families", ["culture"]), 
                        "types": self.cfg.get("snap_types", ["creative"]), 
                        "meta": {"coverage": coverage, "freshness_days": self.cfg.get("freshness_days", 7)}}
            cands = self.snap_ops.propose(artifact)
            assess = [self.snap_ops.assess(c) for c in cands]
            self.stats["snap_score"] = float(assess[0].score) if assess else 0.0

        if enable_archive:
            meta = self.archivist.snapshot("culture","creative", self.cfg.get("run_version","v0_7_demo"),
                                           content=summary, tags={"snap_score": self.stats.get("snap_score",0.0)})
            self.stats["snapshot_id"] = meta.snap_id
            _ = self.projector.emit({"msg":"solve complete", "snap_id": meta.snap_id})

        # Simple fast-lane: gate on coverage rate (demo). Real version uses dedicated FastLane class.
        if enable_fast:
            fl = FastLane(quality_threshold=float(self.cfg.get("fastlane_threshold", 0.75)))
            dec = fl.submit(key=f"run:{N}", result=summary, quality=coverage)
            self.stats["fastlane"] = "promoted" if dec.promoted else ("staged" if dec.staged else "unknown")

        return {"verdict": "promoted", "stats": summary}
    