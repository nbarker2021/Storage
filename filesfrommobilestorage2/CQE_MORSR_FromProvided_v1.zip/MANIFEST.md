# Curated CQE/MORSR Build (from provided files only)

Included components: harness code (latest), essential data (matrix pack, E8 nodes, subroots, lane-permutation proof, MORSR goldens), and E8 neighbor/reflect JSONs.

## Files
- `code/cqe/__init__.py` — 13 bytes — sha256:75ad4f4c2943325f
- `code/cqe/__pycache__/__init__.cpython-311.pyc` — 157 bytes — sha256:0a75e06a133e3f40
- `code/cqe/__pycache__/canonicalize.cpython-311.pyc` — 2772 bytes — sha256:86c86ea434322e99
- `code/cqe/__pycache__/cli.cpython-311.pyc` — 17173 bytes — sha256:29d5a2f7dfd43d2b
- `code/cqe/__pycache__/codes.cpython-311.pyc` — 5185 bytes — sha256:4fee80da2055ab4d
- `code/cqe/__pycache__/config.cpython-311.pyc` — 903 bytes — sha256:4ee0cf3272d72f79
- `code/cqe/__pycache__/e8.cpython-311.pyc` — 4211 bytes — sha256:19fc81fc197b7786
- `code/cqe/__pycache__/morsr.cpython-311.pyc` — 8944 bytes — sha256:2fe4c17b758cef95
- `code/cqe/__pycache__/operators.cpython-311.pyc` — 3861 bytes — sha256:b71f66ac86cd40dc
- `code/cqe/__pycache__/overlay.cpython-311.pyc` — 11850 bytes — sha256:bc0e106f1dc70884
- `code/cqe/__pycache__/triple.cpython-311.pyc` — 11001 bytes — sha256:7ff6ef835aed0eed
- `code/cqe/adapters/__pycache__/audio_adapter.cpython-311.pyc` — 4347 bytes — sha256:61cad1f0a2bd8695
- `code/cqe/adapters/__pycache__/superperm_adapter.cpython-311.pyc` — 6048 bytes — sha256:1925e206a2bc507c
- `code/cqe/adapters/audio_adapter.py` — 2059 bytes — sha256:4dead18d4a544cca
- `code/cqe/adapters/h4_embed.py` — 486 bytes — sha256:8be4f962e190e5be
- `code/cqe/adapters/h4_indices.json` — 73 bytes — sha256:67904e7435ecbb07
- `code/cqe/adapters/superperm_adapter.py` — 2642 bytes — sha256:a171ddcd2f3c4791
- `code/cqe/canonicalize.py` — 1083 bytes — sha256:e3a2e439d2006a81
- `code/cqe/cli.py` — 7529 bytes — sha256:ed77c2693c4b1fd7
- `code/cqe/codes.py` — 2320 bytes — sha256:b22bf2b248726588
- `code/cqe/config.py` — 646 bytes — sha256:fd72f62771e62c3a
- `code/cqe/e8.py` — 1441 bytes — sha256:5a241bd413bf450d
- `code/cqe/geo/__pycache__/e8_geo.cpython-311.pyc` — 6198 bytes — sha256:f2b5fd800164dc81
- `code/cqe/geo/e8_geo.py` — 2451 bytes — sha256:61ccbe2dbb6af146
- `code/cqe/morsr.py` — 6727 bytes — sha256:c879d6fa3a680063
- `code/cqe/operators.py` — 2438 bytes — sha256:11b8ca468ed5ca44
- `code/cqe/ops_script.py` — 2037 bytes — sha256:42d64725a1a151a6
- `code/cqe/overlay.py` — 5578 bytes — sha256:4169df8407e9df06
- `code/cqe/triple.py` — 5663 bytes — sha256:1132e2df0d832037
- `code/cqe/viz/__pycache__/colorize.cpython-311.pyc` — 5078 bytes — sha256:05bffe0aeb40a806
- `code/cqe/viz/colorize.py` — 2481 bytes — sha256:7df08d793adc5f15
- `code/requirements.txt` — 13 bytes — sha256:a89575b0722e9293
- `data/e8_nodes.json` — 38165 bytes — sha256:a05c161a3c5a750d
- `data/e8_viz_nodes.json` — 37021 bytes — sha256:1a19d3437317962b
- `data/lane_permutation_rowspace_report.json` — 1568 bytes — sha256:bf78b5f8884eb843
- `data/matrix_pack.json` — 8032 bytes — sha256:47a85836c172818c
- `data/subroot_indices.json` — 331 bytes — sha256:724e53888aaa34aa
- `examples/morsr_golden_handshakes.jsonl` — 3589 bytes — sha256:e480f032758d2b96
- `examples/morsr_golden_neighbor_M.json` — 7605 bytes — sha256:bddedef3ea5ef2bd
- `examples/morsr_golden_neighbor_Rtheta.json` — 7631 bytes — sha256:2e35d22fd7d79112
- `examples/morsr_golden_region.json` — 2620 bytes — sha256:857d78ff9950bcfa
- `examples/morsr_golden_seed.json` — 7605 bytes — sha256:0f4ad1da41c52681
- `neighbors/e8_graph_edges.json` — 74531 bytes — sha256:cda8327e9033a544
- `neighbors/e8_neighbor_degrees.json` — 62 bytes — sha256:3ef26829d8594068