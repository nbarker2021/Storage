
import json, math, itertools
from typing import List, Tuple
from ..overlay import EO
from ..canonicalize import canonicalize

def detect_n(seq: str) -> int:
    # crude: scan for max digit/letter in the sequence (assuming permutations of 1..n or abc..)
    alphabet = sorted(set(seq))
    # filter non-alnum
    alphabet = [c for c in alphabet if c.isalnum()]
    if not alphabet: return 0
    # assume '1'.. or 'a'..
    if '1' in alphabet or '2' in alphabet:
        digits = [int(c) for c in seq if c.isdigit()]
        return max(digits) if digits else 0
    else:
        letters = [c for c in seq if c.isalpha()]
        mx = max(ord(c.lower()) for c in letters) - ord('a') + 1
        return mx

def window_perms(seq: str, n: int) -> List[Tuple[str,int]]:
    # Return list of (perm_string, index) windows where index is position in seq
    out = []
    for i in range(len(seq)-n+1):
        window = seq[i:i+n]
        if len(set(window))==n:
            out.append((window, i))
    return out

def lehmer_code(perm: List[int]) -> List[int]:
    code = []
    for i in range(len(perm)):
        c = 0
        for j in range(i+1, len(perm)):
            if perm[j] < perm[i]: c += 1
        code.append(c)
    return code

def perm_from_string(s: str) -> List[int]:
    # Map chars to 0..n-1 in order of first appearance
    seen = {}
    arr = []
    nxt=0
    for ch in s:
        if ch not in seen:
            seen[ch]=nxt; nxt+=1
        arr.append(seen[ch])
    return arr

def overlay_from_superperm(seq: str) -> EO:
    n = detect_n(seq)
    if n<3: raise ValueError("sequence too small to be a superpermutation")
    windows = window_perms(seq, n)
    eo = EO()
    # seed: mark three present nodes
    for i in [0,1,2]: eo.present[i]=True; eo.w[i]=0.7; eo.phi[i]=0.0
    # map each permutation window to a node index using a stable hash of its Lehmer code
    for w, pos in windows:
        p = perm_from_string(w)
        code = lehmer_code(p)
        h = 0
        for v in code:
            h = (h*131 + v + 17) % 1000003
        idx = h % 248
        eo.present[idx]=True
        # accumulate some weight as frequency surrogate
        eo.w[idx] = min(1.0, eo.w[idx] + 0.05)
    eo.update_invariants()
    j = canonicalize(eo.to_json())
    eo.canon = j["canon"]
    return eo, n, len(windows)

def cli_build(args):
    import json
    with open(args.seq_file, "r") as f:
        seq = f.read().strip()
    eo, n, k = overlay_from_superperm(seq)
    with open(args.out_overlay, "w") as f:
        json.dump(eo.to_json(), f, indent=2)
    print(f"Built overlay from superperm (n={n}, windows={k}) -> {args.out_overlay}")
