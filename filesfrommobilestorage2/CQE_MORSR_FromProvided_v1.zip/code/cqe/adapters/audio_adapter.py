
import json, random
from typing import List, Tuple
import numpy as np
from ..codes import ext_golay_24, gf2_matmul
from ..overlay import EO
from ..canonicalize import canonicalize

G24, H24 = ext_golay_24()

def text_to_symbols(s: str) -> List[int]:
    # very rough: map ascii to 0..31 (base32-like), pad
    out = []
    for ch in s.encode('utf-8', errors='ignore'):
        out.append((ch >> 3) & 31)  # take top 5 bits
    return out

def encode_golay_frames(symbols: List[int]) -> List[np.ndarray]:
    # pack 12 bits of message into a codeword using generator G24 (12x24)
    # We'll group 12 symbols as bits: symbol%2 gives 1 bit; (toy demo)
    frames = []
    i = 0
    while i < len(symbols):
        m = np.zeros(12, dtype=int)
        for b in range(12):
            if i < len(symbols):
                m[b] = symbols[i] & 1
            i += 1
        cw = gf2_matmul(m.reshape(1,12), G24)  # 1x24
        frames.append(cw.reshape(-1))
    return frames

def inject_ber(cw: np.ndarray, ber: float = 0.02) -> np.ndarray:
    out = cw.copy()
    for i in range(len(out)):
        if random.random() < ber:
            out[i] ^= 1
    return out

def overlay_from_audio(text: str, ber: float = 0.02) -> EO:
    syms = text_to_symbols(text)
    frames = encode_golay_frames(syms)
    eo = EO()
    # Project code bits onto overlay present indices
    base = 0
    for cw in frames[:8]:  # limit to 8 frames to stay sparse
        noisy = inject_ber(cw, ber=ber)
        for j,bit in enumerate(noisy):
            if bit==1:
                idx = (base + j) % 248
                eo.present[idx]=True
                eo.w[idx] = min(1.0, eo.w[idx] + 0.3)
        base = (base + 31) % 248
    eo.update_invariants()
    j = canonicalize(eo.to_json())
    eo.canon = j["canon"]
    return eo, len(frames)

def cli_build(args):
    eo, nf = overlay_from_audio(args.text, ber=args.ber)
    with open(args.out_overlay, "w") as f:
        json.dump(eo.to_json(), f, indent=2)
    print(f"Built overlay from audio text (frames={nf}) -> {args.out_overlay}")
