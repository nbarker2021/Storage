
from typing import List, Dict
import math

def hann(N:int, n:int)->float:
    return 0.5*(1-math.cos(2*math.pi*n/(N-1))) if N>1 else 1.0

def fft_naive(x: List[complex])->List[complex]:
    N = len(x)
    out = []
    for k in range(N):
        s = 0+0j
        for n in range(N):
            ang = -2j*math.pi*k*n/N
            s += x[n]*complex(math.cos(2*math.pi*k*n/N), -math.sin(2*math.pi*k*n/N))
        out.append(s)
    return out

def welch_psd(signal: List[float], fs: float, seglen: int=128, overlap: float=0.5) -> Dict[str, float]:
    if seglen>len(signal): seglen=len(signal)
    step = max(1, int(seglen*(1-overlap)))
    psd_accum = [0.0]*seglen
    wsum = 0.0
    count = 0
    for start in range(0, len(signal)-seglen+1, step):
        seg = signal[start:start+seglen]
        w = [hann(seglen, n) for n in range(seglen)]
        xw = [seg[n]*w[n] for n in range(seglen)]
        X = fft_naive([complex(v,0.0) for v in xw])
        Pxx = [(abs(X[k])**2) for k in range(seglen)]
        psd_accum = [psd_accum[k]+Pxx[k] for k in range(seglen)]
        wsum += sum([wi*wi for wi in w])
        count += 1
    if count==0: count=1
    psd = [v/(count*wsum) for v in psd_accum]
    # one-sided bins
    freqs = [fs*k/seglen for k in range(seglen//2)]
    power = psd[:seglen//2]
    # band powers (delta/theta/alpha/beta/gamma)
    def band(fmin,fmax):
        s=0.0
        for f,p in zip(freqs, power):
            if fmin<=f<fmax: s+=p
        return s
    bands = {
        "delta": band(0.5,4),
        "theta": band(4,8),
        "alpha": band(8,12),
        "beta": band(12,30),
        "gamma": band(30,100)
    }
    return bands
