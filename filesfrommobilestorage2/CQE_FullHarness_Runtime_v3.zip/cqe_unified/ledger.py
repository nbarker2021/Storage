
import json, hashlib, time
from pathlib import Path

class Ledger:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("")
        self._prev = self._last_hash()

    def _last_hash(self):
        try:
            last = None
            for line in self.path.read_text().splitlines():
                last = json.loads(line).get("chain_hash")
            return last or "0"*64
        except Exception:
            return "0"*64

    def append(self, payload: dict, note: str=""):
        payload = dict(payload)
        payload["ts"] = time.time()
        payload["note"] = note
        # compute commit hash
        h = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        chain = hashlib.sha256((self._prev + h).encode()).hexdigest()
        payload["commit"] = h
        payload["prev_hash"] = self._prev
        payload["chain_hash"] = chain
        with self.path.open("a") as f:
            f.write(json.dumps(payload)+"\n")
        self._prev = chain
        return payload
