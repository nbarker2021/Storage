
from typing import Dict, List, Tuple

SUIT_MAP = {"C":"S", "S":"C", "D":"H", "H":"D"}

def mirror_state(cards: List[Tuple[str,int,int]])->List[Tuple[str,int,int]]:
    """Mirror a state: reverse order, swap suits across color lanes, flip face bit.
    Card tuple: (suit:str in C,S,D,H, rank:int 1..13, face:int 0/1).
    """
    rev = list(reversed(cards))
    out = []
    for s,r,f in rev:
        out.append((SUIT_MAP[s], r, 1-f))
    return out

def mirror_invariant(cards: List[Tuple[str,int,int]])->int:
    return 1 if mirror_state(cards) == cards else 0
