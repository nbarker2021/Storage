
from typing import Dict, List, Tuple
from .dihedral import d8_orbit_representative_4x4, d8_actions_grid_4x4

def checker_parity_4x4(pos:int)->int:
    r, c = divmod(pos,4)
    return (r + c) & 1

def lane_parity_4x4(pos:int)->int:
    """Top/bottom lane parity (rows 0-1 = 0, rows 2-3 = 1)."""
    r, c = divmod(pos,4)
    return 0 if r<2 else 1

def axis_class_4x4(pos:int)->int:
    """Classify by proximity to axes: 0=corner,1=edge,2=center(2x2),3=axis-cross (useful disambiguation)."""
    r,c = divmod(pos,4)
    if (r in (0,3)) and (c in (0,3)):
        return 0  # corner
    if (r in (0,3)) ^ (c in (0,3)):
        return 1  # edge
    if (r in (1,2)) and (c in (1,2)):
        return 2  # 2x2 center block
    return 3  # should not happen in 4x4; kept for completeness


def octad_classes_n5()->Dict[str, List[int]]:
    bins = {}
    corner_set = {0,3,12,15}
    center_set  = {5,6,9,10}
    for pos in range(16):
        rep = d8_orbit_representative_4x4(pos)
        if rep in center_set:
            # drop center orbit from n=5 octad accounting
            continue
        chk = checker_parity_4x4(pos)
        lane = lane_parity_4x4(pos)
        if rep in corner_set:
            code = (lane<<1)|chk  # 0..3
            key = f"C|{code}"
        else:
            # edge: orientation 0=horizontal (r in {0,3}), 1=vertical
            r,c = divmod(pos,4)
            eori = 0 if r in (0,3) else 1
            q = lane ^ chk
            key = f"E|{eori}|{q}"
        bins.setdefault(key, []).append(pos)
    return bins
def expect_octad_eight():
    bins = octad_classes_n5()
    return len(bins)==8, bins
