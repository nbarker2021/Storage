
from typing import List

def rotate(seq: List[int], k: int) -> List[int]:
    n = len(seq)
    k %= n
    return seq[k:]+seq[:k]

def reverse(seq: List[int]) -> List[int]:
    return list(reversed(seq))

def d8_actions_grid_4x4(pos):
    """Return all positions equivalent to pos in 4x4 grid under D8 (rotations/reflections). pos in [0..15]."""
    def idx(r,c): return r*4+c
    def rc(p): return (p//4, p%4)
    r,c = rc(pos)
    # 8 symmetries
    syms = set()
    mats = []
    # rotations 0,90,180,270 and reflections over vertical/horizontal/diag/anti-diag
    transforms = [
        lambda r,c:(r,c),                                # identity
        lambda r,c:(c,3-r),                              # rot90
        lambda r,c:(3-r,3-c),                            # rot180
        lambda r,c:(3-c,r),                              # rot270
        lambda r,c:(r,3-c),                              # mirror vertical
        lambda r,c:(3-r,c),                              # mirror horizontal
        lambda r,c:(c,r),                                # diag
        lambda r,c:(3-c,3-r),                            # anti-diag
    ]
    for f in transforms:
        rr,cc = f(r,c)
        syms.add(idx(rr,cc))
    return sorted(syms)

def d8_orbit_representative_4x4(pos):
    return d8_actions_grid_4x4(pos)[0]
