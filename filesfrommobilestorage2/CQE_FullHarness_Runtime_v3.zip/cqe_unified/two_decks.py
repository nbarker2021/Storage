
from typing import List, Tuple

def zip_pairs(blue: List[int], red: List[int]) -> List[Tuple[int,int]]:
    return list(zip(blue, red))

def overlay_or(blue_bits: List[int], red_bits: List[int]) -> List[int]:
    return [ (b|r) for b,r in zip(blue_bits, red_bits) ]

def overlay_xor(blue_bits: List[int], red_bits: List[int]) -> List[int]:
    return [ (b^r) for b,r in zip(blue_bits, red_bits) ]

def commutator(a: List[int], b: List[int]) -> List[int]:
    """Positions where a->b changed (1) else 0."""
    return [ 1 if x!=y else 0 for x,y in zip(a,b) ]
