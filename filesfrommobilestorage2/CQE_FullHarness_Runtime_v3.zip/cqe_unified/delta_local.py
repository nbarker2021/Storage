
from typing import List, Tuple

def adjacent_swap_distance(a: List[int], b: List[int]) -> int:
    """Minimal number of adjacent swaps to turn a into b, assuming same multiset and unique elements."""
    pos = {v:i for i,v in enumerate(b)}
    mapped = [pos[v] for v in a]
    # count inversions
    # Fenwick could be faster; for small n do O(n log n) merge sort count
    def count_inv(arr):
        def sort_count(lst):
            n = len(lst)
            if n<=1: return lst,0
            mid=n//2
            L,cL=sort_count(lst[:mid])
            R,cR=sort_count(lst[mid:])
            i=j=0; merged=[]; c=cL+cR
            while i<len(L) and j<len(R):
                if L[i] <= R[j]:
                    merged.append(L[i]); i+=1
                else:
                    merged.append(R[j]); j+=1; c += len(L)-i
            merged.extend(L[i:]); merged.extend(R[j:])
            return merged,c
        return sort_count(arr)[1]
    return count_inv(mapped)

def rotation_min_adjacent_swaps(a: List[int], b: List[int]) -> Tuple[int,int]:
    """Return minimal adjacent swaps over all rotations (single cut) of a into b. Returns (min_swaps, best_k)."""
    n = len(a)
    best = (10**9, 0)
    for k in range(n):
        rot = a[k:]+a[:k]
        d = adjacent_swap_distance(rot, b)
        if d < best[0]:
            best = (d, k)
    return best

def delta_locality(a: List[int], b: List[int], max_swaps:int=2) -> Tuple[int, dict]:
    """Δ=1 if there's a rotation (single cut) plus <=max_swaps adjacent swaps to turn a into b."""
    swaps, k = rotation_min_adjacent_swaps(a,b)
    ok = 1 if swaps <= max_swaps else 0
    return ok, {"swaps": swaps, "cut": k}
