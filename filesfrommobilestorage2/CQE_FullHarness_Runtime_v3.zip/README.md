
# CQE Full Harness Runtime v3

This repo implements the CQE primitives and runs all proofs/falsifiers in one go.

- Octad/Dihedral engine (n=5 ⇒ 8 classes under D8 × parity lanes)
- Δ-locality via single-cut + adjacent-swaps
- Mirror invariance checker (suit color swap + face flip + reverse)
- Two-deck algebra (zip, XOR overlay, commutator)
- Welch PSD sidecar (Hann window + naive FFT)
- Ledger with chain hash
- Harness & tests for determinism and falsifiers

## Quick run

```bash
python -m harness.run_all
python -m tests.run_tests
python -m tests.test_falsifiers
```
