
import json, hashlib, math, random
from pathlib import Path
from cqe_unified.ledger import Ledger
from cqe_unified.delta_local import delta_locality
from cqe_unified.mirror import mirror_invariant, mirror_state
from cqe_unified.two_decks import zip_pairs, overlay_xor, commutator
from cqe_unified.sidecars_dft import welch_psd
from cqe_unified.octad import expect_octad_eight

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/"harness"/"out"
OUT.mkdir(parents=True, exist_ok=True)

def sha256(obj)->str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()

def palindromic_rest(seq):
    """Choose pal rest: prefer top (as-is) if reversed has worse suit-run metric; here we just compare inverse count surrogate."""
    # smaller 'inversion-like' surrogate on identity vs reversed (toy)
    score_id = sum(1 for i in range(len(seq)-1) if seq[i]<=seq[i+1])
    score_rev= sum(1 for i in range(len(seq)-1) if seq[-1-i]<=seq[-2-i])
    return "top" if score_id>=score_rev else "reversed"


def receipts_bits(suits, faces, seqA, seqB):
    # P: palindrome test of suits sequence equality under reverse
    P = 1 if suits == list(reversed(suits)) else 0
    # M: mirror-invariance of the card tuples
    ranks = [(i%13)+1 for i in range(len(suits))]
    cards = [(s,r,f) for s,r,f in zip(suits, ranks, faces)]
    M = mirror_invariant(cards)
    # Δ: locality between seqA->seqB (indices)
    d_ok, info = delta_locality(seqA, seqB, max_swaps=2)
    # S: strictness -> did we tighten max run length of same suit?
    def max_run(xs):
        m=c=1
        for i in range(1,len(xs)):
            if xs[i]==xs[i-1]: c+=1
            else: m=max(m,c); c=1
        return max(m,c)
    S = 1 if max_run(seqB) <= max_run(seqA) else 0
    # L: ledger presence (1 if we will log it)
    L = 1
    return {"P":P,"M":M,"Δ":d_ok,"S":S,"L":L, "delta_info":info}
def config_toy_bits():
    # seq: indices 0..15; suits alternate in small pattern; faces represent bitstring
    seqA = list(range(16))
    seqB = list(range(16))
    suits = ["C","S","D","H"]*4
    faces = [1,0,1,1, 0,1,0,0, 1,1,0,1, 0,0,1,0]
    pal = palindromic_rest(seqA)
    bits = receipts_bits(suits, faces, seqA, seqB)
    return {"name":"toy_bits","pal_choice":pal,"receipts":bits, "checksum":{"sum":sum(faces),"xor": (sum(faces) & 1)}}

def config_pal_probe():
    seqA = list(range(12))
    seqB = list(range(12))
    suits = ["C","S","S","C","D","H","H","D","C","S","S","C"]
    faces = [1 if i%3==0 else 0 for i in range(12)]
    pal = palindromic_rest(seqA)
    bits = receipts_bits(suits, faces, seqA, seqB)
    return {"name":"palindrome_probe","pal_choice":pal,"receipts":bits}

def config_two_deck_xor():
    blue = [0,0,1,1]  # inputs packed as parity aid
    red  = [0,1,1,0]  # XOR
    zipped = zip_pairs(blue, red)
    overlay = overlay_xor(blue, red)
    delta = commutator(blue, red)
    # build suits/faces for receipts (toy): suits alternate; faces use red
    suits = ["C","S","D","H"]
    faces = red
    seqA = list(range(4)); seqB = list(range(4))
    pal = palindromic_rest(seqA)
    bits = receipts_bits(suits, faces, seqA, seqB)
    return {"name":"interaction_xor","zipped":zipped,"overlay_xor":overlay,"delta":delta,"pal_choice":pal,"receipts":bits}

def config_eeg_mock():
    # build synthetic: alpha 10 Hz + theta 6 Hz, fs=256 Hz, N=1024
    import math
    fs=256.0; N=1024
    t=[n/fs for n in range(N)]
    sig=[math.sin(2*math.pi*10*tt)+0.64*math.sin(2*math.pi*6*tt) for tt in t]
    bands = welch_psd(sig, fs, seglen=128, overlap=0.5)
    suits = ["C","S","D","H","C","S","D","H"]
    faces = [1,0,1,0,1,0,1,0]
    seqA = list(range(len(suits))); seqB = list(range(len(suits)))
    pal = palindromic_rest(seqA)
    bits = receipts_bits(suits, faces, seqA, seqB)
    return {"name":"eeg_mock","bands":bands,"pal_choice":pal,"receipts":bits}

def run_all():
    ledger = Ledger(OUT/"ledger.jsonl")
    reports = []
    for cfg in [config_toy_bits(), config_pal_probe(), config_two_deck_xor(), config_eeg_mock()]:
        payload = {"name": cfg["name"], "report": cfg}
        signed = ledger.append(payload, note=f"auto-run {cfg['name']}")
        rep_path = OUT/f"{cfg['name']}.json"
        rep_path.write_text(json.dumps(signed, indent=2))
        reports.append((cfg["name"], signed["commit"]))
    # Octad check
    ok, bins = expect_octad_eight()
    (OUT/"octad_bins.json").write_text(json.dumps({"ok":ok, "bins":bins}, indent=2))
    return reports, ok

if __name__ == "__main__":
    reps, ok = run_all()
    print("Reports:", reps)
    print("Octad==8:", ok)
