
import json, re
from pathlib import Path
from cqe_unified.ledger import Ledger
from harness.run_all import run_all, OUT

def main():
    reps, ok = run_all()
    assert ok, "Octad class count must be 8"
    # re-run for determinism of 'report' content (ignoring timestamps and chain hashes)
    run_all()
    lines = [json.loads(l) for l in (OUT/'ledger.jsonl').read_text().splitlines()]
    # Group by name
    from collections import defaultdict
    by = defaultdict(list)
    for row in lines:
        by[row['name']].append(row)
    for name, rows in by.items():
        assert len(rows)>=2, f"Need at least two runs for determinism check on {name}"
        a=rows[-1]['report']; b=rows[-2]['report']
        assert a==b, f"Report mismatch for {name}"
    print("All tests passed.")
if __name__ == "__main__":
    main()
