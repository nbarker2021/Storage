
# CQE v3 — One-Click Proof Pack

- Build: `python -m harness.run_all`
- Tests: `python -m tests.run_tests`
- Falsifiers: `python -m tests.test_falsifiers`

Outputs land in `harness/out/` (reports and ledger). The octad partition is in `octad_bins.json`.
