
# Worksheet — n=5 Octad

1) Draw a 4×4 grid and label cells 0..15.
2) Color checkerboard parity; shade top row block (rows 0–1) as lane 0, bottom block as lane 1.
3) Place the symbol '5' in each cell in turn; group positions by dihedral symmetries (rotations/reflections).
4) Split groups further by (lane, checker) to get 8 non-conjugate classes for corners and edges.
5) Confirm code: see `harness/out/octad_bins.json` with 8 classes.
