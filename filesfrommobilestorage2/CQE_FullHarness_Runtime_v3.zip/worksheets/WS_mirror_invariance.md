
# Worksheet — Mirror Invariance

Construct a hand with suits symmetric under color-swap and reverse, faces alternating. Run `mirror_invariant` to verify M=1.
