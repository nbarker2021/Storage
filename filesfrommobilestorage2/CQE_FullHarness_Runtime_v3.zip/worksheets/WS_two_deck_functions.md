
# Worksheet — Two-Deck Functions

Goal: build XOR with two 4-row decks. Blue=inputs, Red=outputs. Align rows and check overlay XOR equals Red.
Run `python -m harness.run_all` and inspect `interaction_xor.json` in `harness/out`.
