
# Worksheet — Δ Locality

Take sequence A and B; compute whether a single cut plus ≤2 adjacent swaps can transform A→B.
Use `delta_locality(a,b,max_swaps=2)`.
