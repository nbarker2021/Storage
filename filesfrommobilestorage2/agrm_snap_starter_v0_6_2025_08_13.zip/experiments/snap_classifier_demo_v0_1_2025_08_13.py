
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.snap.snap_classifier_v0_1_2025_08_13 import classify_payload
from core.snap.snap_promoter_v0_1_2025_08_13 import promotion_decision, allowed_universes

payload = {"name":"A Short Story About A Dragon", "text":"Once upon a time a dragon met a wizard in a faraway kingdom."}
cls = classify_payload(payload)
print("Classification:", cls)
print("Allowed universes:", allowed_universes(cls["families"], cls["types"]))
print("Decision to gov:", promotion_decision(cls, "gov"))
print("Decision to user:", promotion_decision(cls, "user"))
