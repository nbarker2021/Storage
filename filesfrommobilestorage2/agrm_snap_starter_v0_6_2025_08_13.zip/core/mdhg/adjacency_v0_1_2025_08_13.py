
from typing import Dict, Any, List, Tuple
import numpy as np

def _bins(points: np.ndarray, buckets:int=64):
    N, d = points.shape
    mins = points[:, :2].min(axis=0)
    maxs = points[:, :2].max(axis=0)
    span = np.maximum(maxs - mins, 1e-9)
    coords = (points[:, :2] - mins) / span
    ij = np.minimum(buckets-1, np.maximum(0, (coords * buckets).astype(int)))
    bins = {}
    for idx, (i,j) in enumerate(ij):
        bins.setdefault((int(i),int(j)), []).append(idx)
    return ij, bins, mins, maxs, span

def build_adjacency(points: np.ndarray, k:int=8, buckets:int=64) -> Dict[str,Any]:
    N, d = points.shape
    ij, bins, mins, maxs, span = _bins(points, buckets=buckets)
    edges = set()
    # neighborhood offsets (3x3)
    neigh = [(di,dj) for di in (-1,0,1) for dj in (-1,0,1)]
    for idx, (i,j) in enumerate(ij):
        cand_idx = []
        for di,dj in neigh:
            key = (i+di, j+dj)
            if key in bins:
                cand_idx.extend(bins[key])
        if idx in cand_idx:
            cand_idx.remove(idx)
        if not cand_idx:
            continue
        # compute distances on this small set
        P = points[cand_idx]
        dist = np.linalg.norm(P - points[idx], axis=1)
        nn_local = [cand_idx[t] for t in np.argsort(dist)[:k]]
        for j2 in nn_local:
            a, b = (idx, j2) if idx<j2 else (j2, idx)
            edges.add((a,b))
    edges = sorted(edges)
    return {"N": N, "edges": edges, "avg_degree": (2*len(edges))/max(1,N)}

def build_elevators(points: np.ndarray, adjacency: Dict[str,Any], quota:int= 0) -> Dict[str,Any]:
    # keep simple: select a few long-range random shortcuts
    N = adjacency["N"]; edges=set(adjacency["edges"])
    rng = np.random.default_rng(23)
    extra = set()
    max_extra = min(quota, max(0, N//50))
    for _ in range(max_extra):
        a, b = int(rng.integers(0,N)), int(rng.integers(0,N))
        if a==b: continue
        e = (a,b) if a<b else (b,a)
        if e not in edges:
            extra.add(e)
    elevators = sorted(extra)
    return {"elevators": elevators, "count": len(elevators)}
