
from typing import Dict
from .contracts_v0_1_2025_08_13 import Task_v0_1_2025_08_13
from .registry_v0_1_2025_08_13 import AgentRegistry_v0_1_2025_08_13
from .policies_v0_1_2025_08_13 import check_access
from .sdk_v0_1_2025_08_13 import BaseAgent_v0_1_2025_08_13
from ..snap.snap_v0_1_2025_08_13 import create_snap
from .sandbox_v0_1_2025_08_13 import Budgets_v0_1_2025_08_13, run_with_budgets_v0_1_2025_08_13
from .routing_mdhg_v0_1_2025_08_13 import pick_agent_by_mdhg_v0_1_2025_08_13
class Orchestrator_v0_1_2025_08_13:
    def __init__(self, registry: AgentRegistry_v0_1_2025_08_13, sap_rules=None):
        self.registry = registry; self.sap_rules = sap_rules or {}
    def _pick(self, task: Task_v0_1_2025_08_13):
        cands = []
        need = set(task.requires)
        for spec in self.registry.all():
            have = set(c.name for c in spec.capabilities)
            if need.issubset(have):
                cands.append(spec)
        if task.allow_agents:
            cands = [s for s in cands if s.agent_id in task.allow_agents]
        if cands and task.constraints.get('hot_tags'):
            sel = pick_agent_by_mdhg_v0_1_2025_08_13(cands, task); 
            return sel
        return cands[0] if cands else None
    def route(self, task: Task_v0_1_2025_08_13, agents: Dict[str, BaseAgent_v0_1_2025_08_13]):
        spec = self._pick(task)
        if not spec: return {"error":"no-agent"}
        ok, why = check_access(spec, task)
        if not ok: return {"error":"policy-deny","reason":why,"agent":spec.agent_id}
        agent = agents.get(spec.agent_id)
        if not agent: return {"error":"agent-not-loaded","agent":spec.agent_id}
        try:
            budgets = Budgets_v0_1_2025_08_13(seconds=task.constraints.get('seconds', 5.0))
            plan_fn = lambda: agent.plan(task.inputs)
            out_fn = lambda: agent.act(task.inputs)
            plan, pstats = run_with_budgets_v0_1_2025_08_13(plan_fn, task.inputs, budgets)
            out, ostats = run_with_budgets_v0_1_2025_08_13(out_fn, task.inputs, budgets)
            result = {"agent": spec.agent_id, "plan": plan, "plan_stats": pstats.__dict__, "output": out, "output_stats": ostats.__dict__}
            if not pstats.ok or not ostats.ok:
                snap = create_snap({"task": task.__dict__, "agent": spec.agent_id, "meta": {"capabilities":[c.name for c in spec.capabilities]},"plan_stats": pstats.__dict__, "out_stats": ostats.__dict__}, kind="agent_budget")
                result["budget_snap"] = snap
            return result
        except Exception as e:
            snap = create_snap({"task": task.__dict__, "agent": spec.agent_id, "error": str(e)}, kind="agent_error")
            return {"error":"agent-exception","agent":spec.agent_id,"snap":snap,"msg":str(e)}
