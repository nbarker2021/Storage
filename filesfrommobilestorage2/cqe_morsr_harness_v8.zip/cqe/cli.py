
import json, argparse
from .overlay import EO
from .canonicalize import canonicalize
from .morsr import pulse

def cmd_mint_seed(args):
    eo = EO()
    # simple A2 seed: activate three indices (0,1,2 for harness)
    eo.present[0]=eo.present[1]=eo.present[2]=True
    eo.w[0]=eo.w[1]=eo.w[2]=0.7
    eo.phi[0]=0.0; eo.phi[1]=1.5708; eo.phi[2]=3.1416
    eo.update_invariants()
    j = canonicalize(eo.to_json())
    eo.canon = j["canon"]
    with open(args.out, "w") as f:
        json.dump(j, f, indent=2)
    print("Minted seed overlay ->", args.out)

def cmd_morsr(args):
    with open(args.seed, "r") as f:
        seed_json = json.load(f)
    # build EO from json (minimal)
    nodes = seed_json["nodes"]
    present_b64 = nodes["present"]
    bits = list(reversed([int(b) for byte in list(__import__('base64').b64decode(present_b64)) for b in [(byte>>7)&1, (byte>>6)&1, (byte>>5)&1, (byte>>4)&1, (byte>>3)&1, (byte>>2)&1, (byte>>1)&1, byte&1]]))[:248]
    eo = EO()
    eo.present = [bool(b) for b in bits]
    eo.w = [float(x or 0.0) for x in nodes["w"]]
    eo.phi = [x if x is None else float(x) for x in nodes["phi"]]
    eo.pose = seed_json.get("pose", eo.pose)
    eo.update_invariants()
    result = pulse(eo, max_rings=2)
    with open(args.region_out, "w") as f:
        json.dump(result["region"], f, indent=2)
    with open(args.handshakes_out, "w") as f:
        for h in result["handshakes"]:
            f.write(json.dumps(h)+"\n")
    print("MORSR complete. Region ->", args.region_out, "Handshakes ->", args.handshakes_out)

def main():
    ap = argparse.ArgumentParser(prog="cqe")
    sub = ap.add_subparsers(dest="cmd", required=True)
    m1 = sub.add_parser("mint-seed")
    m1.add_argument("--out", default="seed_overlay.json")
    m1.set_defaults(func=cmd_mint_seed)
    m2 = sub.add_parser("morsr")
    m2.add_argument("--seed", required=True)
    m2.add_argument("--region-out", default="region.json")
    m2.add_argument("--handshakes-out", default="handshakes.jsonl")
    m2.set_defaults(func=cmd_morsr)
    args = ap.parse_args()
    args.func(args)

if __name__=="__main__":
    main()


# ----- Adapters -----
from .adapters.superperm_adapter import cli_build as sp_cli_build
from .adapters.audio_adapter import cli_build as audio_cli_build

def cmd_superperm(args):
    sp_cli_build(args)

def cmd_audio(args):
    audio_cli_build(args)

# register
def _extend_cli():
    import argparse
    ap = argparse.ArgumentParser(prog="cqe-adapters")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("superperm")
    sp.add_argument("--seq-file", required=True)
    sp.add_argument("--out-overlay", default="sp_overlay.json")
    sp.set_defaults(func=cmd_superperm)
    au = sub.add_parser("audio")
    au.add_argument("--text", required=True)
    au.add_argument("--ber", type=float, default=0.02)
    au.add_argument("--out-overlay", default="audio_overlay.json")
    au.set_defaults(func=cmd_audio)
    return ap

if __name__=="__main__":
    # If invoked directly, expose adapter CLI
    ap = _extend_cli()
    args = ap.parse_args()
    args.func(args)


# ----- Viz: colorize & plot -----
from .viz.colorize import colorize_nodes, coxeter_plane_basis, project_roots_to_plane
from .geo.e8_geo import R

def cmd_colorize(args):
    meta = colorize_nodes()
    with open(args.out_json, "w") as f:
        json.dump(meta, f, indent=2)
    if args.png:
        B = coxeter_plane_basis()
        P = project_roots_to_plane(B)
        import matplotlib.pyplot as plt
        xs, ys = P[:,0], P[:,1]
        colors = [meta[i]["hex"] for i in range(240)]
        plt.figure(figsize=(6,6))
        plt.scatter(xs, ys, s=14, c=colors, edgecolors='none')
        plt.axis('equal'); plt.axis('off')
        plt.tight_layout()
        plt.savefig(args.png, dpi=180)
        plt.close()
    print("Colorization complete ->", args.out_json, args.png)

def _extend_cli_viz(sub):
    cz = sub.add_parser("colorize")
    cz.add_argument("--out-json", default="viz_nodes.json")
    cz.add_argument("--png", default="e8_viz.png")
    cz.set_defaults(func=cmd_colorize)

# Patch main CLI factory if present
def patched_main():
    import argparse
    ap = argparse.ArgumentParser(prog="cqe")
    sub = ap.add_subparsers(dest="cmd", required=True)
    # re-register original commands
    m1 = sub.add_parser("mint-seed"); m1.add_argument("--out", default="seed_overlay.json"); m1.set_defaults(func=cmd_mint_seed)
    m2 = sub.add_parser("morsr")
    m2.add_argument("--seed", required=True)
    m2.add_argument("--region-out", default="region.json")
    m2.add_argument("--handshakes-out", default="handshakes.jsonl")
    m2.set_defaults(func=cmd_morsr)
    # adapters
    sp = sub.add_parser("superperm"); sp.add_argument("--seq-file", required=True); sp.add_argument("--out-overlay", default="sp_overlay.json"); sp.set_defaults(func=cmd_superperm)
    au = sub.add_parser("audio"); au.add_argument("--text", required=True); au.add_argument("--ber", type=float, default=0.02); au.add_argument("--out-overlay", default="audio_overlay.json"); au.set_defaults(func=cmd_audio)
    # viz
    _extend_cli_viz(sub)
    args = ap.parse_args()
    args.func(args)

if __name__=="__main__":
    patched_main()


# ----- Triple projection CLI -----
from .triple import E8Triple
def cmd_triple(args):
    import json, base64
    from .overlay import b64_present
    def load(path):
        with open(path, "r") as f:
            j = json.load(f)
        eo = EO()
        nodes = j.get('nodes', {})
        # present may be base64 from b64_present
        pres_b64 = nodes.get('present')
        if isinstance(pres_b64, str):
            # decode like b64_present encoded
            # we reuse EO default decoder by evaluating bytes => bools
            data = base64.b64decode(pres_b64.encode('utf-8'))
            present = []
            for byte in data:
                for k in range(8):
                    present.append( bool((byte >> k) & 1) )
            present = present[:248]
            eo.present = present
        else:
            # fallback: list of bools
            eo.present = nodes.get('present', eo.present)
        eo.w = nodes.get('w', eo.w)
        eo.phi = nodes.get('phi', eo.phi)
        eo.pose = j.get('pose', eo.pose)
        eo.update_invariants()
        return eo
    L = load(args.left)
    C = load(args.center)
    R = load(args.right)
    allow=None
    if args.allow_sectors:
        # map labels to indices matching viz module
        lbls = [s.strip() for s in args.allow_sectors.split(',') if s.strip()]
        label_to_idx = {"E":0,"ENE":1,"NE":2,"N":3,"NW":4,"WNW":5,"W":6,"S":7}
        allow=[label_to_idx[x] for x in lbls if x in label_to_idx]
    tri = E8Triple.from_three(L, C, R, w_left=args.w_left, w_right=args.w_right, allow_sectors=allow)
    solve = tri.to_solve_overlay()
    with open(args.out_overlay, "w") as f:
        json.dump(solve.to_json(), f, indent=2)
    print("Triple projection ->", args.out_overlay)

def _extend_cli_triple(sub):
    tp = sub.add_parser("triple")
    tp.add_argument("--left", required=True)
    tp.add_argument("--center", required=True)
    tp.add_argument("--right", required=True)
    tp.add_argument("--out-overlay", default="solve_overlay.json")
    tp.add_argument("--w-left", type=float, default=0.15)
    tp.add_argument("--w-right", type=float, default=0.15)
    tp.add_argument("--allow-sectors", default="", help="comma list of sector labels, e.g., NE,N")
    tp.set_defaults(func=cmd_triple)
