
import json, os
from typing import List, Dict
from ..e8 import e8_nodes_248

H4_JSON_PATH = os.path.join(os.path.dirname(__file__), "h4_indices.json")

def load_h4_indices() -> Dict[str, List[int]]:
    if not os.path.exists(H4_JSON_PATH):
        # placeholder: empty lists to keep pipeline stable
        return {"H4": [], "notes":"Populate this file with 120 indices that form an H4 slice within E8 if available."}
    with open(H4_JSON_PATH, "r") as f:
        return json.load(f)
