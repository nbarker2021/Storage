
import json, hashlib
from .config import TOL

def canonicalize(eo_json: dict) -> dict:
    # Deterministic: round weights/phases, gauge phase of max-weight active to 0, produce a hash.
    nodes = eo_json["nodes"]
    w = [round(float(x or 0.0), 8) for x in nodes["w"]]
    phi = [None if (x is None) else round(float(x), 9) for x in nodes["phi"]]
    # gauge: set smallest-index active with max w to phi=0
    active = [i for i,v in enumerate(w) if v>0]
    if active:
        mx = max(w[i] for i in active)
        idx = min(i for i in active if w[i]==mx)
        if phi[idx] is not None: phi[idx] = 0.0
    nodes["w"]=w; nodes["phi"]=phi
    eo_json["nodes"]=nodes
    # score tuple for lexicographic ordering would go here (Weyl neighborhood skipped in harness)
    canon_bytes = json.dumps(eo_json, sort_keys=True).encode()
    eo_json.setdefault("canon",{})
    eo_json["canon"]["hash_id"] = "sha256:" + hashlib.sha256(canon_bytes).hexdigest()
    eo_json["canon"].setdefault("weyl_actions", [])
    eo_json["canon"].setdefault("gauge", "phase_ref_axis=0")
    return eo_json
