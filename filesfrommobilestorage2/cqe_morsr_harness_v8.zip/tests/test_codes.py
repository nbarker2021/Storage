
import numpy as np
from cqe.codes import ext_hamming_84, ext_golay_24, gf2_matmul

def test_hamming_orthogonality():
    G,H = ext_hamming_84()
    assert G.shape==(4,8) and H.shape==(4,8)
    assert (gf2_matmul(G, H.T)==0).all()

def test_golay_orthogonality():
    G,H = ext_golay_24()
    assert G.shape==(12,24) and H.shape==(12,24)
    assert (gf2_matmul(G, H.T)==0).all()
