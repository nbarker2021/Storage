
import json, tempfile, os
from cqe.overlay import EO
from cqe.triple import E8Triple

def test_triple_projection_basic():
    # build three sparse overlays
    def mk(idx_list):
        eo = EO()
        for i in idx_list:
            eo.present[i]=True; eo.w[i]=0.6; eo.phi[i]=0.0
        eo.update_invariants(); return eo
    L = mk([0,10,20]); C = mk([1,11,21]); R = mk([2,12,22])
    tri = E8Triple.from_three(L,C,R)
    solve = tri.to_solve_overlay()
    # Must remain an EO and have some active set
    assert isinstance(solve, EO)
    assert sum(1 for b in solve.present if b) >= 3
