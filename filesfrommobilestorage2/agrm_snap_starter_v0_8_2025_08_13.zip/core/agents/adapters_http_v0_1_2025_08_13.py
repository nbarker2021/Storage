
"""
HTTPAdapter_v0_1_2025_08_13
- Defines an interface to call external agents over HTTP.
- Exposes plan() and act() via POST endpoints; handles timeouts and JSON.
"""
import json, urllib.request, urllib.error
class HTTPAdapter_v0_1_2025_08_13:
    def __init__(self, base_url, timeout=10.0, headers=None):
        self.base_url = base_url.rstrip("/"); self.timeout = float(timeout); self.headers = headers or {"Content-Type":"application/json"}
    def _post(self, path, payload):
        req = urllib.request.Request(self.base_url + path, data=json.dumps(payload).encode("utf-8"), headers=self.headers, method="POST")
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    def plan(self, inputs): return self._post("/plan", inputs)
    def act(self, inputs): return self._post("/act", inputs)
