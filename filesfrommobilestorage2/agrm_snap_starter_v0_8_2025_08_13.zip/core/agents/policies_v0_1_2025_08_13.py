
from .contracts_v0_1_2025_08_13 import AgentSpec_v0_1_2025_08_13, Task_v0_1_2025_08_13
ALLOWED_UNIVERSE_SCOPES = {"user","doc","work","work.fast","gov"}
def check_access(spec: AgentSpec_v0_1_2025_08_13, task: Task_v0_1_2025_08_13) -> (bool, str):
    requested = set(task.universes)
    if not requested.issubset(ALLOWED_UNIVERSE_SCOPES):
        return False, "unknown-universe"
    granted = set()
    for p in spec.permissions:
        if p.scope.startswith("universe:"):
            parts = p.scope.split(":")
            if len(parts)==2:
                granted.add(parts[1])
    if not requested.issubset(granted):
        return False, "insufficient-universe-scope"
    have = set(c.name for c in spec.capabilities)
    need = set(task.requires)
    if not need.issubset(have):
        return False, "missing-capability"
    return True, "ok"
