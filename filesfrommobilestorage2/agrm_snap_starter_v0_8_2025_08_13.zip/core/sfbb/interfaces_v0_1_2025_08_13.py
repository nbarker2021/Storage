
"""
SFBB Interfaces v0_1_2025_08_13
Defines lightweight protocols for superpermutation-derived tools that we can plug into AGRM/MDHG.
"""
from typing import Dict, List, Tuple, Any

Edge = Tuple[int,int]

class EdgeScoreProvider:
    """Return a score per candidate edge (higher = more preferred)."""
    def score_edges(self, points, candidate_edges: List[Edge], context: Dict[str,Any]) -> Dict[Edge, float]:
        raise NotImplementedError

class BridgeLocator:
    """Locate 'bridge' positions or constraints that should bias sequencing/patching."""
    def locate(self, sequence_or_graph: Any, context: Dict[str,Any]) -> Dict[str,Any]:
        raise NotImplementedError

class SeedPolicy:
    """Choose initial seeds or 'prodigals' based on n-level constraints and prior outcomes."""
    def select_seeds(self, n:int, history: Dict[str,Any], k:int=8) -> List[Any]:
        raise NotImplementedError
