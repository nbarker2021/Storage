
import numpy as np
from collections import defaultdict
class MDHG_v0_2_2025_08_13:
    
    def __init__(self, dim:int, decay_lambda:float=0.01):
        self.dim = dim; self.decay_lambda = decay_lambda
        self.vecs = {}
        self.meta = {}
        self.heat = defaultdict(float); self.edge = defaultdict(float)
        self.by_building = defaultdict(lambda: defaultdict(lambda: defaultdict(set)))
        self.floor_cache = defaultdict(set)
    def route_meta(self, meta:dict):
        b = meta.get("building","default"); f = meta.get("floor","F0"); r = meta.get("room","R0")
        return b,f,r
    def insert(self, id:int, vec, meta:dict):
        v = np.asarray(vec, dtype=float).reshape(-1)
        assert v.shape[0]==self.dim
        b,f,r = self.route_meta(meta)
        self.vecs[id]=v; self.meta[id]={"building":b,"floor":f,"room":r}
        self.by_building[b][f][r].add(id); self.floor_cache[(b,f)].add(id)
        return id
    def bump_heat(self, ids, meta=None):
        ids = list(ids)
        for i in ids: self.heat[i] += 1.0
        for a in ids:
            for b in ids:
                if a<b: self.edge[(a,b)] += 1.0
    def decay(self):
        for k in list(self.heat.keys()):
            self.heat[k] *= (1.0 - self.decay_lambda)
            if self.heat[k] < 1e-6: del self.heat[k]
        for k in list(self.edge.keys()):
            self.edge[k] *= (1.0 - self.decay_lambda)
            if self.edge[k] < 1e-6: del self.edge[k]
    def k_nn(self, qvec, k=8, building=None, floor=None):
        q = np.asarray(qvec, dtype=float).reshape(-1)
        if building is None:
            cand_ids = list(self.vecs.keys())
        else:
            if floor is None:
                cand_ids = []
                for (b,f), ids in self.floor_cache.items():
                    if b==building: cand_ids.extend(list(ids))
            else:
                cand_ids = list(self.floor_cache[(building,floor)])
        dists=[]
        for i in cand_ids:
            v=self.vecs[i]; d=float(np.linalg.norm(q-v)); dists.append((d,i))
        dists.sort(key=lambda x:x[0])
        return [i for _,i in dists[:k]]
    def edges(self, topk=64, building=None):
        items = list(self.edge.items())
        if building is not None:
            items = [((a,b),w) for (a,b),w in items if self.meta.get(a,{}).get("building")==building and self.meta.get(b,{}).get("building")==building]
        items.sort(key=lambda kv: kv[1], reverse=True)
        return items[:topk]

    def add_edges(self, triples):
        for a,b,w in triples:
            if a>b: a,b=b,a
            self.edge[(a,b)] += float(w)
