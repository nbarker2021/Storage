
import importlib, sys, json
from pathlib import Path
import numpy as np, pandas as pd
from engine.cqe_engine import CQEEngine

DIALECTS=[("B2","dialects.b2","compile_b2","examples/b2.cqe"),
          ("B3","dialects.b3","compile_b3","examples/b3.cqe"),
          ("B4","dialects.b4","compile_b4","examples/b4.cqe"),
          ("B5","dialects.b5","compile_b5","examples/b5.cqe"),
          ("B8","dialects.b8","compile_b8","examples/b8.cqe"),
          ("B10","dialects.b10","compile_b10","examples/b10.cqe"),
          ("B16","dialects.b16","compile_b16","examples/b16.cqe")]
TRIALS = 200

def run_dialect(tag, modpath, funcname, exfile):
    mod = importlib.import_module(modpath); compile_fn=getattr(mod, funcname)
    src = Path(exfile).read_text()
    ir = compile_fn(src)
    eng = CQEEngine(seed=42)
    ece_b=[]; ece_a=[]; slope=[]; white=[]; rho=[]; leak=[]; hamming=[]
    for t in range(TRIALS):
        r = eng.run_ir(ir)
        ece_b.append(r.ece_before); ece_a.append(r.ece_after); slope.append(r.slope_after)
        white.append(r.whiteness_p); rho.append(r.cross_rho); leak.append(r.leakage)
        hamming.append(r.hamming)
    return {
        "dialect": tag,
        "ece_before": float(np.mean(ece_b)),
        "ece_after": float(np.mean(ece_a)),
        "slope_after": float(np.mean(slope)),
        "whiteness_p": float(np.mean(white)),
        "cross_rho": float(np.mean(rho)),
        "leakage": float(np.mean(leak)),
        "mean_hamming": float(np.mean(hamming))
    }

def main():
    results=[]
    for tag,mp,fn,ex in DIALECTS:
        results.append(run_dialect(tag, mp, fn, ex))
    outdir=Path("results"); outdir.mkdir(exist_ok=True, parents=True)
    Path(outdir/"summary.json").write_text(json.dumps({"results":results}, indent=2))
    df = pd.DataFrame(results); df.to_csv(outdir/"summary.csv", index=False)
    print(json.dumps({"results":results}, indent=2))

if __name__ == "__main__":
    sys.path.insert(0, str(Path('.').resolve()))
    main()
