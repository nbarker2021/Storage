
from engine.cqe_engine import IRProgram
def compile_b2(src:str)->IRProgram:
    ops=[]; meta={'base':'B2'}
    for line in src.splitlines():
        s=line.strip().lower()
        if not s or s.startswith('#'): continue
        if s=='rest': ops.append(('REST',{}))
        elif s=='hlp': ops.append(('HLP',{}))
        elif s=='braid': ops.append(('BRAID',{'cadence':[2,4,8,13]}))
        elif s=='nudge': ops.append(('NUDGE',{}))
        elif s=='commit': ops.append(('COMMIT',{}))
        elif s.startswith('strength'): meta['strength']=float(s.split()[1])
    return IRProgram(ops=ops, meta=meta)
