
from engine.cqe_engine import IRProgram
def compile_b16(src:str)->IRProgram:
    ops=[]; meta={'base':'B16'}
    for line in src.splitlines():
        s=line.strip().lower()
        if not s: continue
        if s=='frame': ops.append(('REST',{}))
        elif s=='canon': ops.append(('HLP',{}))
        elif s=='scan': ops.append(('BRAID',{'cadence':[4,8,16]}))
        elif s=='tick': ops.append(('NUDGE',{}))
        elif s=='commit': ops.append(('COMMIT',{}))
        elif s.startswith('strength'): meta['strength']=float(s.split()[1])
    return IRProgram(ops=ops, meta=meta)
