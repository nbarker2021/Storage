
from engine.cqe_engine import IRProgram
def compile_b10(src:str)->IRProgram:
    ops=[]; meta={'base':'B10'}
    for line in src.splitlines():
        s=line.strip().lower()
        if not s: continue
        if s=='rest10': ops.append(('REST',{}))
        elif s=='hlp10': ops.append(('HLP',{}))
        elif s=='measure': ops.append(('BRAID',{'cadence':[2,5,10]}))
        elif s=='nudge10': ops.append(('NUDGE',{}))
        elif s=='commit10': ops.append(('COMMIT',{}))
        elif s.startswith('strength'): meta['strength']=float(s.split()[1])
    return IRProgram(ops=ops, meta=meta)
