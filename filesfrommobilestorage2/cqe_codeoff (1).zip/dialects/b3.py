
from engine.cqe_engine import IRProgram
def compile_b3(src:str)->IRProgram:
    ops=[]; meta={'base':'B3'}
    for line in src.splitlines():
        t=line.strip().split()
        if not t: continue
        k=t[0].lower()
        if k=='rest3': ops.append(('REST',{}))
        elif k=='hlp3': ops.append(('HLP',{}))
        elif k=='triad': ops.append(('BRAID',{'cadence':[3,6,12]}))
        elif k=='nudge3': ops.append(('NUDGE',{}))
        elif k=='commit3': ops.append(('COMMIT',{}))
        elif k=='strength': meta['strength']=float(t[1])
    return IRProgram(ops=ops, meta=meta)
