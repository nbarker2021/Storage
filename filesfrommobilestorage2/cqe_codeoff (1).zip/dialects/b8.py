
from engine.cqe_engine import IRProgram
def compile_b8(src:str)->IRProgram:
    ops=[]; meta={'base':'B8'}
    for line in src.splitlines():
        s=line.strip().lower()
        if not s: continue
        if s=='octrest': ops.append(('REST',{}))
        elif s=='octhlp': ops.append(('HLP',{}))
        elif s=='octad': ops.append(('BRAID',{'cadence':[8]}))
        elif s=='pulse': ops.append(('NUDGE',{}))
        elif s=='seal': ops.append(('COMMIT',{}))
        elif s.startswith('strength'): meta['strength']=float(s.split()[1])
    return IRProgram(ops=ops, meta=meta)
