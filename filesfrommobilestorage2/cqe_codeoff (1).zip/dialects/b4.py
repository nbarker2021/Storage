
from engine.cqe_engine import IRProgram
def compile_b4(src:str)->IRProgram:
    ops=[]; meta={'base':'B4'}
    token_map={'acgt':'REST','pair':'HLP','helix':'BRAID','edit':'NUDGE','write':'COMMIT'}
    for raw in src.splitlines():
        s=raw.strip().split('#')[0].strip()
        if not s: continue
        if s.startswith('strength'): meta['strength']=float(s.split()[1]); continue
        op=token_map.get(s.split()[0].lower())
        if op=='BRAID': ops.append(('BRAID',{'cadence':[2,4,8,13]}))
        elif op: ops.append((op,{}))
    return IRProgram(ops=ops, meta=meta)
