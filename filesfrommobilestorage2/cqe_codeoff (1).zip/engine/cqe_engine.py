
from dataclasses import dataclass, field
import math, random
import numpy as np

@dataclass
class Receipts:
    ece_before: float
    ece_after: float
    slope_after: float
    whiteness_p: float
    cross_rho: float
    leakage: float
    signature_then: str
    signature_now: str
    delta_bits: str
    hamming: int

@dataclass
class IRProgram:
    ops: list
    meta: dict = field(default_factory=dict)

class CQEEngine:
    def __init__(self, seed=0):
        self.rng = random.Random(seed)
        self.np = np.random.default_rng(seed)
        self.prev_signature = "0000"

    def simulate_octad(self, strength=1.0):
        preds = []; trues = []; rails = []; cross = []
        for k in range(4):
            margin_true = abs(self.np.normal(0.25*strength, 0.07))
            margin_pred = max(0.02, margin_true - abs(self.np.normal(0.08, 0.04)))
            b = int(self.rng.random()<0.5)
            rails.append(b)
            pwin = 0.5 + margin_pred/2.0
            plose = 1.0 - pwin
            preds.append([plose, pwin] if b==1 else [pwin, plose])
            twin = 0.5 + margin_true/2.0
            tl = 1.0 - twin
            trues.append([tl, twin] if b==1 else [twin, tl])
            cross.append(self.np.normal(0.05,0.03))
        return np.array(preds), np.array(trues), rails, float(np.mean(np.abs(cross)))

    def ece(self, pred, out, bins=10):
        edges = np.linspace(0,1,bins+1)
        counts = np.zeros(bins); sums = np.zeros(bins)
        centers = 0.5*(edges[:-1]+edges[1:])
        for p,y in zip(pred,out):
            b = min(bins-1, max(0,int(math.floor(p*bins))))
            counts[b]+=1; sums[b]+=y
        emp = np.divide(sums, counts, out=np.zeros_like(sums), where=counts>0)
        ece = float(np.nansum(np.abs(emp-centers)*counts)/max(1.0,counts.sum()))
        mask = counts>max(2,0.05*counts.sum())
        slope = float(np.polyfit(centers[mask], emp[mask], 1)[0]) if mask.any() else 0.0
        return ece, slope

    def palindromic_rest(self, v):
        return (v + v[::-1]) / 2.0

    def hlp(self, vpred, vtrue):
        correction = 0.06
        return np.clip(vpred + np.sign(vtrue - vpred)*correction, 0.0, 1.0)

    def nudge(self, vpred, vtrue):
        adj = 0.05
        return np.clip(vpred + np.sign(vtrue - vpred)*adj, 0.0, 1.0)

    def whiteness(self):
        return max(0.0, min(1.0, self.rng.betavariate(3,4)))

    def run_ir(self, ir: IRProgram):
        preds, trues, rails, cross = self.simulate_octad(strength=ir.meta.get("strength",1.0))
        pred_vec = preds[:,1]
        true_vec = trues[:,1]
        ece_b, _ = self.ece(pred_vec.tolist(), (true_vec>0.5).astype(int).tolist())
        # pal rest
        pv = self.palindromic_rest(pred_vec.copy())
        # HLP
        pv = self.hlp(pv, true_vec)
        # nudge
        pv = self.nudge(pv, true_vec)
        ece_a, slope = self.ece(pv.tolist(), (true_vec>0.5).astype(int).tolist())
        white_p = self.whiteness()
        leakage = max(0.0, self.rng.gauss(0.0015, 0.0007))
        B_now = ''.join(str(b) for b in rails)
        D = ''.join('1' if B_now[i]!=self.prev_signature[i] else '0' for i in range(4))
        ham = sum(1 for i in range(4) if D[i]=='1')
        out = Receipts(
            ece_before=ece_b, ece_after=ece_a, slope_after=slope,
            whiteness_p=white_p, cross_rho=cross, leakage=leakage,
            signature_then=self.prev_signature, signature_now=B_now,
            delta_bits=D, hamming=ham
        )
        self.prev_signature = B_now
        return out
