# Public Receipt — Sound Lab (Redacted)

- Project: SOUND_DEMO_001
- Octet: 8 views (time/STFT/CQT/perturbations)
- Mirror residual: ≤ 9e−4 across passing views
- Strict: SNR_min = 20 dB (raised from 18 dB)
- Mirror votes: 23/24; View votes: 64/64
- 4‑bit commit: 1011
- Page‑hash: (redacted here; present in private ledger)

Some details redacted for safety; all metrics reproducible from the workorder and tokens.
