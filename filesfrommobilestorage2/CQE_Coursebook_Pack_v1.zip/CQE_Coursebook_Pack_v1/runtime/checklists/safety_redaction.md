# Safety & Redaction Guidelines

- Prefer **receipts** (metrics, hashes) over raw artifacts.
- Summarize like an LLM; if needed, write “some results redacted for safety.”
- Do not publish sensitive operational parameters; keep them in private ledger.
- Keep **Non‑Working** album: failures are breadcrumbs, but redact specifics if risky.
