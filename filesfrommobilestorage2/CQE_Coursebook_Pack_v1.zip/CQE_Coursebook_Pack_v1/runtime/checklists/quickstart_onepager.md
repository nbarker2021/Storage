# CQE Quick‑Start One‑Pager

1) Tokens → DNA‑10  
2) Octet (8 views)  
3) Mirror each → pass/fail  
4) Δ‑lift one local fix → re‑mirror  
5) Tighten one bound (strict)  
6) Receipt + 4‑bit  
7) File working & non‑working  
8) Only then add meaning back.
