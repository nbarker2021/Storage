# CQE Coursebook v1.0
**Date:** 2025-09-20  
**License:** CC BY 4.0 (educational use encouraged)  
**Authoring note:** This book is meant to be printed or read alongside the supplied worksheets.

---

## What is CQE?
**CQE** (Code → Lattice → Overlay → Mirror → Commit) is a human-runnable method for solving mixed-domain problems with tight, checkable receipts.
You start with **stand-in tokens** (numbers with units), capture a **DNA‑10** state, explore **eight views** (an **octet**), enforce a **mirror** (forward∘inverse≈identity),
apply a **Δ‑lift** (tiny local repair), tighten **strict** thresholds (never loosen), and finish with a **4‑bit commit** plus receipts.

This book teaches CQE from scratch and gives you two worked labs (Sound; Heat/Entropy).

---

## How to use this book
- Each module has: a short theory primer, a concrete example, a worksheet, and a tiny commit.
- Keep a color notebook: Gray (rest), 8 hues (views), Red (Δ‑lifts), Gold (strict), Blue (receipts).
- File **Working** and **Non‑Working** pages separately; both are valuable.

---

# Module 0 — Orientation & Kit

**Goal:** Hold the whole machine in your hands.

### Theory
- **Form vs Meaning.** Form is the fixed, testable geometry (your ritual). Meaning is labels you swap.
- **Receipts over rhetoric.** Small proofs beat long prose.

### Practice
- Assemble: Master Ledger (commits), Working Album, Non‑Working Album.
- Print these templates (in /templates): Token Card, DNA‑10 Card, Octet Overlay, Mirror Test, Δ‑lift Cookbook, Strict Ratchet Log, Receipts Ledger, Commit Strips.

### Micro‑commit
Sign the first ledger line: “Kit assembled; ready.” (4‑bit placeholder `0000`).

---

# Module 1 — Stand‑in Tokens & DNA‑10

**Goal:** Capture inputs without over‑interpreting.

### Theory
- A **stand‑in token** is a number *with* units and guards, but *without* domain claims.
- **DNA‑10** = one‑line state save: timing, polarity, scale, pose, domain, conditioning, units, precision, cost, seed.

### Practice (Sound mini‑example)
Create tokens:
- sample_rate = 16000 Hz (guard: ±0)
- frame_len = 20 ms (guard: 10–40 ms)
- band = [300, 3400] Hz
- rms_target = −18 LUFS ±1

Write DNA‑10: “timing=20 ms hop; polarity=mono; scale=±1; pose=time→freq; domain=audio; conditioning=band‑limited; units=SI; precision=1e‑3; cost=low; seed=1337”.

### Worksheet
Use **Token Card** and **DNA‑10 Card** templates.

### Micro‑commit
Record tokens hash; 4‑bit stays `0000` (no tests yet).

---

# Module 2 — Construction‑A & the n=4→5 hinge

**Goal:** Understand why eight views are *forced*.

### Theory (compressed)
- Construction‑A (binary): parity checks decide membership (finite, mechanical).
- **n=4** palindromic rest on a 4×4 parity grid is unique (up to pose).
- Adding a 5th symbol forces **eight** inequivalent insertion classes → the **octad** is necessary.

### Practice
- Build the n=4 palindrome on the 4×4 sheet.
- Attempt all n=5 insertions; group into eight classes.

### Micro‑commit
Attach a photo of your grid; ledger note: “found 1 pal + 7 invariants”; provisional `0001`.

---

# Module 3 — Octet Overlays (Designing 8 views)

**Goal:** Cover the space with eight materially independent views.

### Theory
- Views should be orthogonal in stress: method, metric, slice, regime, noise, pose, time, frequency.
- Surround viewers: 8×8 local detail, 4×4×4×4 neighborhood, 2×2×2×2 parity shell.

### Practice (Sound)
Pick an octet: {time, STFT_short, STFT_long, CQT, band+6 dB, band−6 dB, burst_noise, low_SNR}.
Predict one fragility per view.

### Worksheet
Use **Octet Overlay**; mark a small hypothesis under each panel.

### Micro‑commit
Record octet definition; `0010` (design registered).

---

# Module 4 — Mirror (Palindromic Rest)

**Goal:** Enforce forward∘inverse≈identity with a numeric tolerance.

### Theory
- Examples: FFT↔iFFT; encode↔decode; simulate↔measure overlay.
- Declare tolerances (L2, SNR, ΔE, etc.).

### Practice (Sound)
Run STFT→iSTFT for each view (on a short clip). Residual L2 ≤ 1e−3 passes. Note any fails.

### Worksheet
Use **Mirror Test Table** (view; metric; value; pass/fail).

### Micro‑commit
If ≥4 views pass: provisional `0011`.

---

# Module 5 — Δ‑lifts (Local Repairs)

**Goal:** Write and apply legal local fixes that reduce debt and avoid regression.

### Theory
- A Δ‑lift is a *local*, *monotone* change (debt↓) that preserves prior passes.
- Examples: bias repaint; window swap; unit fix; phase unwarp.

### Practice (Sound)
For a failing burst‑noise view: swap window to DPSS; add a median filter ⋯ re‑mirror.

### Worksheet
Use **Δ‑lift Cookbook** (preconditions; action; expected change; regression guard).

### Micro‑commit
If the view now passes and others remain green: set `0101`.

---

# Module 6 — Strict Ratchet

**Goal:** Tighten thresholds *only after* a pass and never loosen.

### Theory
- Ratchets encode maturity; couple each raised bound to a date and rationale.

### Practice (Sound)
Raise SNR_min from 18→20 dB system‑wide; re‑run mirror checks.

### Worksheet
Use **Strict Ratchet Log**.

### Micro‑commit
If all still pass: `0111`.

---

# Module 7 — Receipts & 4‑bit Commits

**Goal:** Make the work portable & reproducible with tiny proofs.

### Theory
- Receipts = debts (OPE/FCE), view votes, mirror votes, hashes.
- 4‑bit commit is a compact fingerprint; escalate to 8/64‑bit if collision risk grows.

### Practice
Write a receipt line: date, page id, metrics (e.g., residual≤9e−4; SNR≥20 dB), **4‑bit** `1011`.

### Worksheet
Use **Receipts Ledger** and **Commit Strips**.

### Micro‑commit
Stamp `1011` and file the page in Working.

---

# Module 8 — Sidecars (Domain Mini‑Labs)

**Goal:** Add specialized rails without changing logic.

### Theory
- Same ritual across up to 64 sidecars (MATH, OPTICS, HEAT/ENTROPY, LIGHT/QED, SPINTRONICS, PLASMA, RNA/PROTEIN, etc.).
- Meaning is attached via token packs; geometry is unchanged.

### Practice
Add **HEAT/ENTROPY** sidecar to Sound: compute Shannon H before/after Δ; discuss entropy debt change.

### Worksheet
Token cards + Octet + Mirror for the sidecar.

### Micro‑commit
Cross‑sidecar receipt (blue) with `1011` mirrored in both rails.

---

# Module 9 — Viewers & Hot‑Zone Caps

**Goal:** Detect and stabilize where to work.

### Theory
- 8×8 local viewer, 4×4×4×4 surround, 2×2×2×2 parity shell.
- Hot‑zone heuristics: hinge (n=4→5), subharmonic clusters (Cartan‑like), mirror drift streaks.
- Caps: `phase_unwrap`, `cartan_snap`, `bias_repaint` are standard Δs.

### Practice
Tag two hot zones; apply one cap each; re‑prove non‑regression.

### Worksheet
Use **Octet Overlay** + **Mirror Table** again; hot‑zone notes in margins.

### Micro‑commit
Record cap usage in Δ‑cookbook; no 4‑bit change unless thresholds tighten.

---

# Module 10 — Safety & Redaction

**Goal:** Share value while safeguarding sensitive specifics.

### Theory
- Publish receipts and hashes; redact operational detail if necessary.
- “Talk like an LLM”: summarize, report metrics, state “some results redacted for safety” when appropriate.

### Practice
Write a one‑page public result for Sound lab with no raw audio and no sensitive parameters; include the 4‑bit and hashes.

### Worksheet
**Public Receipt** template (use the Receipts Ledger).

### Micro‑commit
Archive public receipt in /examples.

---

# Module 11 — Runtime: OS/API/Workorders

**Goal:** Make the process runnable and auditable by others.

### Theory
- Filesystem contract: /tokens, /views, /receipts, /commits, /safety.
- API verbs: spin_sidecar, overlay_octet, mirror, delta_lift, ratchet, commit.
- **Workorder**: deterministic run plan with inputs, views, tolerances, allowed Δs, and expected receipts.

### Practice
Fill a **sample_workorder.json** (see /runtime/specs).

### Micro‑commit
Dry‑run on paper; `1011` when your plan is replayable by a peer.

---

# Module 12 — Capstone (choose one)

**A. Sound → Light mapping**  
**B. Heat/Entropy reversible vs irreversible**  
**C. Toroidal optics mini‑spec**

Deliver: tokens, DNA‑10, octet, mirror logs, Δ‑lifts, strict ratchets, receipts, 4‑bit, and a public receipt.

---

## Appendices

### A — Quick‑start One‑Pager
(Also in /runtime/checklists/quickstart_onepager.md)

1) Tokens → DNA‑10  
2) Octet (8 views)  
3) Mirror each → pass/fail  
4) Δ‑lift 1 thing → re‑mirror  
5) Tighten 1 bound (strict)  
6) Receipt + 4‑bit  
7) File working & non‑working  
8) Only then add meaning back.

### B — Glossary
Stand‑in token; DNA‑10; Octet; Mirror; Δ‑lift; Strict ratchet; Receipt; 4‑bit.

### C — Frequently Asked
- *Do I need group theory?* No. The octet is used operationally.
- *Why 8 views?* n=5 forces an octad from the n=4 palindrome—minimal lawful branching.
- *Can I do fewer?* You can, but you lose coverage; receipt quality drops.

---

**End of coursebook.**

