# Lab A — Sound (Octet → Mirror → Δ → Strict → Commit)

## Objective
Process a short audio clip through an octet of views, enforce mirror, apply a Δ‑lift, tighten a strict bound, and produce a 4‑bit receipt.

## Materials
- Any short mono WAV (speech or tone) @ 16 kHz
- The templates: Token Card, DNA‑10, Octet Overlay, Mirror Test, Δ‑lift, Strict Log, Receipts Ledger, Commit Strips

## Steps
1) Tokens (stand‑ins): sr=16000 Hz ±0; frame=20 ms (hop 10 ms); band=[300,3400] Hz; SNR_min=18 dB.
2) DNA‑10: timing=20 ms; polarity=mono; scale=±1; pose=time→freq; domain=audio; conditioning=band; units=SI; precision=1e‑3; cost=low; seed=1337.
3) Octet: {time, STFT_short, STFT_long, CQT, band+6 dB, band−6 dB, burst_noise, low_SNR}.
4) Mirror: STFT→iSTFT; residual L2 ≤ 1e−3 is pass.
5) Likely fail: burst_noise.
6) Δ‑lift: window swap (DPSS) + median transient smoother.
7) Re‑mirror: confirm pass and no regression in other views.
8) Strict: raise SNR_min 18→20 dB; re‑test.
9) Receipts: record residual≤9e−4; SNR≥20 dB; mirror votes; view votes.
10) Commit: 4‑bit **1011**; file Working page; publish redacted receipt.

## Deliverables
- Photos/scans of the filled templates
- One‑page public receipt (metrics + 4‑bit; no raw audio)