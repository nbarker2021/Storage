# Lab B — Heat & Entropy (Reversible vs Irreversible)

## Objective
Compare two transforms on the same dataset—one lossless (reversible), one lossy (irreversible)—and quantify entropy and “entropy debt”.

## Materials
- Any CSV time‑series (e.g., sensor readings)
- Templates: Token Card, DNA‑10, Octet, Mirror, Δ‑lift, Strict, Receipts

## Steps
1) Tokens: dataset_id, length, unit guards; reversible_transform=lossless ZIP; irreversible_transform=quantization→ZIP.
2) DNA‑10: timing=batch; polarity=N/A; scale=normalized; pose=time→symbol; domain=data; conditioning=de‑trend; units=SI; precision=raw; cost=low; seed=42.
3) Octet: {raw histogram H, block H, delta H, run‑length H, reversible size, irreversible size, Kolmogorov proxy, adversarial shuffle}.
4) Mirror: reversible decode∘encode≈identity; irreversible fails mirror by design—capture ΔH.
5) Δ‑lift: tune quantizer to minimize ΔH while meeting a target file size.
6) Strict: tighten max ΔH after pass.
7) Receipts: H_before, H_after, size_before/after, ΔH; votes.
8) Commit: 4‑bit **1011** when reversible passes and lossy meets strict.

## Deliverables
- Filled worksheets + a public receipt with entropy numbers and commit.