
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import math

@dataclass
class SnapCandidate:
    family: str
    type: str
    meta: Dict[str, Any]

@dataclass
class SnapAssessment:
    preferred_with: List[str]
    avoid_with: List[str]
    score: float
    rationale: str

class SnapOpsCenter:
    def __init__(self):
        self.registry: Dict[Tuple[str,str], Dict[str, Any]] = {}

    def register_family_type(self, family: str, type_: str, rules: Dict[str, Any]):
        self.registry[(family, type_)] = rules

    def assess(self, candidate: SnapCandidate) -> SnapAssessment:
        key = (candidate.family, candidate.type)
        rules = self.registry.get(key, {})
        compat = rules.get("compat", {})
        preferred = compat.get("preferred_with", [])
        avoid = compat.get("avoid_with", [])
        # toy scoring using weights + meta coverage
        weights = rules.get("weights", {"coverage": 1.0, "freshness": 0.5})
        cov = float(candidate.meta.get("coverage", 0.0))
        fr  = float(candidate.meta.get("freshness_days", 30))
        score = weights["coverage"]*cov + weights["freshness"]*math.exp(-fr/30.0)
        return SnapAssessment(preferred_with=preferred, avoid_with=avoid, score=score,
                              rationale=f"coverage={cov}, freshness={fr}d, weights={weights}")

    def propose(self, artifact: Dict[str, Any]) -> List[SnapCandidate]:
        fams = artifact.get("families", [])
        types = artifact.get("types", [])
        return [SnapCandidate(f, t, meta=artifact.get("meta", {})) for f in fams for t in types]
