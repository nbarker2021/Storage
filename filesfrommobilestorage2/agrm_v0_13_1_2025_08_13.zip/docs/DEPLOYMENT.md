# Deployment

CLI, library, service modes; configs in YAML; CI/CD outline.
