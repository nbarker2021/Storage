
from __future__ import annotations
import json, hashlib
from typing import List, Dict, Any
import numpy as np
import pandas as pd
from .ast_ir import Node
from .canonicalize import snap_key
from .sigma import assign_sigma, sheaf_consistent

def HEX(s: str)->str: return hashlib.sha256(s.encode()).hexdigest()

def bits_from_hash(hx: str):
    b=int(hx[:2],16)
    return [(b>>k)&1 for k in range(8)]

def lane_from_bits(bits):
    b1=sum(bits)%2
    idx = bits.index(1) if 1 in bits else 0
    b2=idx%2
    b3=0 if bits[0]==1 else 1
    return b1,b2,b3,4*b1+2*b2+b3

def energy(bits): 
    return 1.0 if bits and bits[0]!=bits[-1] else 0.0

def make_ledger(exprs: List[Node], tag: str) -> pd.DataFrame:
    rows=[]
    for i,n in enumerate(exprs):
        sk=snap_key(n)
        bits=bits_from_hash(sk)
        b1,b2,b3,L = lane_from_bits(bits)
        stitch="L" if (L%2==0) else "S"
        strand="A" if (i%3!=2) else "C"
        rows.append({
            "epoch":tag,"step":i,"snap_key":sk[:16],
            "b1":b1,"b2":b2,"b3":b3,"lane":L,
            "stitch":stitch,"strand":strand,
            "energy_before":energy(bits),"energy_after":min(energy(bits), energy(bits[::-1])),
            "sigma":assign_sigma(n),"sheaf_ok":sheaf_consistent(n)
        })
    return pd.DataFrame(rows)

def mean_run_length(seq):
    if not seq: return 0.0
    runs=[]; cur=seq[0]; L=1
    for x in seq[1:]:
        if x==cur: L+=1
        else: runs.append(L); cur=x; L=1
    runs.append(L); 
    return float(np.mean(runs))

def ci_summary(df: pd.DataFrame) -> Dict[str,Any]:
    n=len(df); first=df.iloc[:max(1,n//10)]
    octet = set(first["lane"].tolist())==set(range(8))
    energy_ok = (df["energy_after"]<=df["energy_before"]+1e-12).all()
    runA = mean_run_length(df["strand"].tolist())
    runL = mean_run_length(df["stitch"].tolist())
    twin = (2.0<=runA<=4.0) and (2.0<=runL<=4.0)
    return {"octet_forcing":"PASS" if octet else "FAIL",
            "energy_monotone":"PASS" if energy_ok else "FAIL",
            "twin_helix_runs":"PASS" if twin else "WARN",
            "run_mean_A":runA,"run_mean_L":runL}
