
from __future__ import annotations
from .ast_ir import Node
from .canonicalize import snap_key, snap_key_strict

def depth_mul(x: Node) -> int:
    if x.op in ("const","var"): return 0
    child=max((depth_mul(a) for a in x.args), default=0)
    return (1+child) if x.op=="mul" else child

def assign_sigma(n: Node) -> str:
    return "strict" if depth_mul(n)>=2 else "relaxed"

def sheaf_consistent(n: Node) -> int:
    ck = snap_key(n); sk = snap_key_strict(n)
    return 1 if ck==sk else 0
