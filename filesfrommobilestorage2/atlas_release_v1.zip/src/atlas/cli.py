
from __future__ import annotations
import argparse
from pathlib import Path
from .simulate import run_demo

def main():
    ap=argparse.ArgumentParser(description="Atlas — Equivariant Canon + Σ + Assimilation demo")
    ap.add_argument("--outdir", type=str, required=True)
    ap.add_argument("--N", type=int, default=2000)
    ap.add_argument("--epochs", type=int, default=4)
    args=ap.parse_args()
    run_demo(Path(args.outdir), N=args.N, epochs=args.epochs)

if __name__=="__main__":
    main()
