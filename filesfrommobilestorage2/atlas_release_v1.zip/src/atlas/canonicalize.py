
from __future__ import annotations
import json, hashlib
from typing import Dict
from .ast_ir import Node, OPS_ASSOC, OPS_COMM, is_int_const, is_wild_const, const_int, ir_to_tuple

def HEX(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()

def alpha_rename(n: Node, mapping: Dict[str,str]|None=None) -> Node:
    if mapping is None: mapping={}
    if n.op=="var":
        v=n.args[0]
        if v not in mapping: mapping[v]=f"v{len(mapping)}"
        return Node("var",(mapping[v],))
    if n.op=="const": return n
    return Node(n.op, tuple(alpha_rename(a,mapping) for a in n.args))

def flatten(n: Node) -> Node:
    if n.op in ("const","var"): return n
    if n.op in OPS_ASSOC:
        items=[]
        def collect(x):
            if x.op==n.op:
                for a in x.args: collect(a)
            else:
                items.append(flatten(x))
        collect(n)
        return Node(n.op, tuple(items))
    return Node(n.op, tuple(flatten(a) for a in n.args))

def sort_comm(n: Node) -> Node:
    if n.op in ("const","var"): return n
    if n.op in OPS_COMM:
        kids=[sort_comm(a) for a in n.args]
        kids_sorted=sorted(kids, key=lambda k: json.dumps(ir_to_tuple(k)))
        return Node(n.op, tuple(kids_sorted))
    return Node(n.op, tuple(sort_comm(a) for a in n.args))

def const_fold(n: Node) -> Node:
    if n.op in ("const","var"): return n
    kids=[const_fold(a) for a in n.args]
    if n.op=="neg" and is_int_const(kids[0]):
        return const_int(-kids[0].args[1])
    if n.op=="add":
        total=0; others=[]; wildcard=False
        for k in kids:
            if is_int_const(k): total+=k.args[1]
            elif is_wild_const(k): wildcard=True; others.append(k)
            else: others.append(k)
        if wildcard:
            if total!=0: others.append(const_int(total))
            return Node("add", tuple(others))
        if not others: return const_int(total)
        if total!=0: others.append(const_int(total))
        return Node("add", tuple(others))
    if n.op=="mul":
        total=1; others=[]; has_zero=False; wildcard=False
        for k in kids:
            if is_int_const(k):
                if k.args[1]==0: has_zero=True
                else: total*=k.args[1]
            elif is_wild_const(k):
                wildcard=True; others.append(k)
            else: others.append(k)
        if has_zero: return const_int(0)
        if wildcard:
            if total!=1: others.insert(0,const_int(total))
            return Node("mul", tuple(others))
        if not others: return const_int(total)
        if total!=1: others.insert(0,const_int(total))
        return Node("mul", tuple(others))
    if n.op=="sub":
        a,b = kids
        if is_int_const(a) and is_int_const(b): return const_int(a.args[1]-b.args[1])
        return Node("add",(a, Node("neg",(b,))))
    return Node(n.op, tuple(kids))

def canonicalize(n: Node) -> Node:
    x=alpha_rename(n)
    x=flatten(x); x=sort_comm(x); x=const_fold(x)
    x=flatten(x); x=sort_comm(x)
    return x

def canonicalize_strict(n: Node) -> Node:
    x=alpha_rename(n); x=flatten(x)
    def sort_comm_strict(y: Node) -> Node:
        if y.op in ("const","var"): return y
        if y.op=="add":
            kids=[sort_comm_strict(a) for a in y.args]
            kids_sorted=sorted(kids, key=lambda k: json.dumps(ir_to_tuple(k)))
            return Node("add", tuple(kids_sorted))
        return Node(y.op, tuple(sort_comm_strict(a) for a in y.args))
    x=sort_comm_strict(x); x=const_fold(x); x=flatten(x); x=sort_comm_strict(x)
    return x

def snap_key(n: Node) -> str:
    return HEX(json.dumps(ir_to_tuple(canonicalize(n))))

def snap_key_strict(n: Node) -> str:
    return HEX(json.dumps(ir_to_tuple(canonicalize_strict(n))))
