
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Tuple

@dataclass(frozen=True)
class Node:
    op: str
    args: Tuple[Any, ...]

def var(name: str) -> Node:
    return Node("var", (name,))

def const_int(k: int) -> Node:
    return Node("const", ("int", int(k)))

def const_wild() -> Node:
    return Node("const", ("wild","*"))

def add(a: Node, b: Node) -> Node:
    return Node("add",(a,b))

def mul(a: Node, b: Node) -> Node:
    return Node("mul",(a,b))

def sub(a: Node, b: Node) -> Node:
    return Node("sub",(a,b))

def neg(a: Node) -> Node:
    return Node("neg",(a,))

OPS_COMM = {"add","mul"}
OPS_ASSOC = {"add","mul"}

def is_int_const(n: Node) -> bool:
    return n.op=="const" and n.args[0]=="int"

def is_wild_const(n: Node) -> bool:
    return n.op=="const" and n.args[0]=="wild"

def ir_to_tuple(n: Node):
    if n.op=="const":
        tag,val = n.args
        return ("const", (tag, val))
    if n.op=="var":
        return ("var", n.args[0])
    return (n.op, tuple(ir_to_tuple(a) for a in n.args))

def render(n: Node) -> str:
    if n.op=="const":
        tag,val = n.args
        return f"{val}" if tag=="int" else "*"
    if n.op=="var": return n.args[0]
    if n.op=="neg": return f"(-{render(n.args[0])})"
    if n.op in ("add","mul","sub"):
        sep = "+" if n.op=="add" else "*" if n.op=="mul" else "-"
        return "(" + sep.join(render(a) for a in n.args) + ")"
    return f"{n.op}(" + ",".join(render(a) for a in n.args) + ")"
