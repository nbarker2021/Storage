
from __future__ import annotations
import math, random
from .ast_ir import Node, const_wild, is_int_const
from .canonicalize import canonicalize

def bucket_small_constants(n: Node) -> Node:
    c=canonicalize(n)
    def bucket(x: Node) -> Node:
        if x.op=="const" and is_int_const(x):
            k=x.args[1]
            if abs(k)<=2: return const_wild()
            return Node("const", ("int", int(math.copysign(3,k))))
        if x.op=="var": return x
        return Node(x.op, tuple(bucket(a) for a in x.args))
    return bucket(c)

def sample_equiv(n1: Node, n2: Node, samples: int=16) -> bool:
    def walk_vars(n):
        out=set()
        def w(x):
            if x.op=="var": out.add(x.args[0])
            for a in x.args:
                if isinstance(a,Node): w(a)
        w(n); 
        return sorted(out)
    def eval_node(n, env):
        if n.op=="const":
            tag,val = n.args
            return 1 if tag=="wild" else int(val)
        if n.op=="var": return env[n.args[0]]
        if n.op=="neg": return -eval_node(n.args[0], env)
        if n.op=="add": return sum(eval_node(a, env) for a in n.args)
        if n.op=="mul":
            p=1
            for a in n.args: p*=eval_node(a, env)
            return p
        if n.op=="sub":
            a=eval_node(n.args[0],env); b=eval_node(n.args[1],env)
            return a-b
        raise ValueError("unknown op")
    vars_list=sorted(set(walk_vars(n1))|set(walk_vars(n2)))
    for _ in range(samples):
        env={v: random.randint(-3,3) for v in vars_list}
        if eval_node(n1, env)!=eval_node(n2, env): return False
    return True
