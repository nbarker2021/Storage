
from __future__ import annotations
import json, hashlib
from typing import Dict, List
from .ast_ir import Node
from .canonicalize import canonicalize, canonicalize_strict, ir_to_tuple
from .family import bucket_small_constants, sample_equiv
from .sigma import sheaf_consistent

AssimilationIndex: Dict[int, Dict] = {}

def HEX(s: str)->str: return hashlib.sha256(s.encode()).hexdigest()

def add_rule(delta_id: int, kind: str, guard: str, detail: Dict):
    AssimilationIndex[delta_id] = {
        "kind":kind, "guard":guard, "detail":detail,
        "proof_cid": HEX(kind+json.dumps(detail))[:16]
    }

# Pre-populate two example rules
add_rule(1, "CANON_TWEAK", "overlap_mul_inconsistent", {"canon":"strict_mul"})
add_rule(2, "FAMILY_MINT", "small_const", {"bucket":"abs<=2→*; abs>2→±3"})

def AOP32(delta_id:int, lane_mask:int, winding_mask:int, mode_bits:int, energy_mode:int)->int:
    return ((delta_id & 0xFFF)<<20) | ((lane_mask & 0xFF)<<12) | ((winding_mask & 0x3F)<<6) | ((mode_bits & 0xF)<<2) | (energy_mode & 0x3)

def apply_assimilation(n: Node, ops: List[int], proof_tax: Dict[str,int]) -> Node:
    for op in ops:
        delta_id = (op>>20) & 0xFFF
        rule = AssimilationIndex.get(delta_id)
        if not rule: continue
        kind = rule["kind"]
        if kind=="CANON_TWEAK":
            if sheaf_consistent(n)==0:
                nc = canonicalize(n); ns = canonicalize_strict(n)
                proof_tax["samples"] += 10
                if sample_equiv(nc, ns, samples=10): n = ns
        elif kind=="FAMILY_MINT":
            nb = bucket_small_constants(n)
            if json.dumps(ir_to_tuple(nb)) != json.dumps(ir_to_tuple(canonicalize(n))):
                proof_tax["samples"] += 8
                if sample_equiv(canonicalize(n), nb, samples=8): n = nb
    return n
