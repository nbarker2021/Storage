
from __future__ import annotations
import json, random, hashlib
from typing import List
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from .ast_ir import Node, var, const_int, add, mul, sub, neg, ir_to_tuple
from .canonicalize import canonicalize
from .family import bucket_small_constants
from .assimilation import apply_assimilation, AOP32
from .ledger import make_ledger, ci_summary

random.seed(2025); np.random.seed(2025)

def gen_expr(depth=0, max_depth=3, nvars=8) -> Node:
    if depth>=max_depth or random.random()<0.2:
        return var(f"x{random.randint(0,nvars-1)}") if random.random()<0.5 else const_int(random.randint(-5,5))
    r=random.random()
    if r<0.45: return add(gen_expr(depth+1,max_depth,nvars), gen_expr(depth+1,max_depth,nvars))
    if r<0.9:  return mul(gen_expr(depth+1,max_depth,nvars), gen_expr(depth+1,max_depth,nvars))
    if r<0.95: return sub(gen_expr(depth+1,max_depth,nvars), gen_expr(depth+1,max_depth,nvars))
    return neg(gen_expr(depth+1,max_depth,nvars))

def drift(n: Node) -> Node:
    import re
    if n.op=="const" and n.args[0]=="int":
        k=n.args[1]
        if random.random()<0.3: k += random.choice([-1,1])
        return Node("const",("int",k))
    if n.op=="var":
        v=n.args[0]
        if random.random()<0.3:
            m=re.match(r"x(\d+)", v)
            if m:
                idx=int(m.group(1)); return Node("var",(f"x{(idx+1)%8}",))
        return n
    kids=[drift(a) for a in n.args]
    import random as rr
    if n.op in {"add","mul"} and rr.random()<0.5:
        kids = kids[::-1]
    return Node(n.op, tuple(kids))

def key_raw(n: Node) -> str:
    from .ast_ir import render
    return hashlib.sha256(render(n).encode()).hexdigest()

def key_snap(n: Node) -> str:
    return hashlib.sha256(json.dumps(ir_to_tuple(canonicalize(n))).encode()).hexdigest()

def key_family(n: Node) -> str:
    return hashlib.sha256(json.dumps(ir_to_tuple(bucket_small_constants(n))).encode()).hexdigest()

def cross_hit(ea: List[Node], eb: List[Node], key_fn) -> float:
    sa=set(key_fn(n) for n in ea); sb=set(key_fn(n) for n in eb)
    return len(sa&sb)/max(len(sb),1)

def run_demo(outdir: Path, N=2000, epochs=4):
    outdir.mkdir(parents=True, exist_ok=True)
    e = [ [gen_expr(max_depth=3, nvars=8) for _ in range(N)] ]
    for t in range(1,epochs):
        e.append([ drift(x) for x in e[t-1] ])

    ledgers = [ make_ledger(e[t], f"E{t+1}") for t in range(epochs) ]
    for t,df in enumerate(ledgers):
        df.to_csv(outdir/f"ledger_E{t+1}.csv", index=False)
        ci = ci_summary(df)
        pd.DataFrame([ci]).to_csv(outdir/f"ci_E{t+1}.csv", index=False)

    rows=[]
    for t in range(1,epochs):
        rows.append({"pair":f"E{t}→E{t+1}","mode":"RAW","hit":cross_hit(e[t-1],e[t],key_raw)})
        rows.append({"pair":f"E{t}→E{t+1}","mode":"SNAP","hit":cross_hit(e[t-1],e[t],key_snap)})
        rows.append({"pair":f"E{t}→E{t+1}","mode":"FAMILY","hit":cross_hit(e[t-1],e[t],key_family)})
    df_hits = pd.DataFrame(rows)
    df_hits.to_csv(outdir/"cross_epoch_hits.csv", index=False)

    OP_R1 = AOP32(1, lane_mask=0xFF, winding_mask=0b000101, mode_bits=0b0000, energy_mode=1)
    OP_R2 = AOP32(2, lane_mask=0xFF, winding_mask=0b001010, mode_bits=0b0001, energy_mode=0)
    ops_stream = [OP_R1, OP_R2]
    with open(outdir/"ops_stream.hex","w") as f:
        for op in ops_stream: f.write(f"{op:08x}\n")

    from .sigma import sheaf_consistent
    proof_tax={"samples":0}
    novelty_rows=[]
    for t in range(1,epochs):
        before = e[t]
        after  = [ apply_assimilation(n, ops_stream, proof_tax) for n in before ]
        fam_after = [key_snap(n) for n in after]
        sheaf_bits = [sheaf_consistent(n) for n in after]
        fam_E1 = set(key_family(n) for n in e[0])
        residual = [1 if (k not in fam_E1 or s==0) else 0 for k,s in zip(fam_after, sheaf_bits)]
        novelty_rows.append({"epoch":f"E{t+1}", "r_after": sum(residual)/len(residual)})
        make_ledger(after, f"E{t+1}_after").to_csv(outdir/f"ledger_E{t+1}_after.csv", index=False)
    pd.DataFrame(novelty_rows).to_csv(outdir/"residual_novelty.csv", index=False)

    summary = {"N":N,"epochs":epochs,"proof_tax_samples":proof_tax["samples"]}
    with open(outdir/"summary.json","w") as f: json.dump(summary, f, indent=2)

    # Plots
    plt.figure(figsize=(6,4))
    pivot = df_hits.pivot(index="pair", columns="mode", values="hit").reset_index()
    for col in ["RAW","SNAP","FAMILY"]:
        plt.plot(pivot["pair"], pivot[col], marker="o", label=col)
    plt.title("Cross-epoch hit rate")
    plt.ylabel("Hit rate"); plt.xlabel("Epoch pair"); plt.legend()
    plt.tight_layout(); plt.savefig(outdir/"plot_cross_epoch_hits.png", dpi=140); plt.close()

    plt.figure(figsize=(6,4))
    df_r = pd.read_csv(outdir/"residual_novelty.csv")
    plt.plot(df_r["epoch"], df_r["r_after"], marker="o")
    plt.title("Residual novelty r_t after assimilation")
    plt.ylabel("Residual novelty"); plt.xlabel("Epoch")
    plt.tight_layout(); plt.savefig(outdir/"plot_residual_novelty.png", dpi=140); plt.close()
