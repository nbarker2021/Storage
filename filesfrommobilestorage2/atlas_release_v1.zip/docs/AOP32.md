AOP32 layout and semantics.
