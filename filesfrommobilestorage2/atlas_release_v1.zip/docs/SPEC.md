Spec content as described in-session.
