Evaluation steps and interpretation.
