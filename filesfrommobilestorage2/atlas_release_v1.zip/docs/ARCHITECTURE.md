Architecture content as described in-session.
