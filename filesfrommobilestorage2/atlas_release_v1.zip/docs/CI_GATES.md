CI gates as described in-session.
