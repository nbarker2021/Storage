# Atlas Release v1

See SPEC.md, ARCHITECTURE.md, CI_GATES.md, AOP32.md, EVALUATION.md.
