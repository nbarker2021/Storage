
import sys, json, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from core.universe.universe_manager_v0_1_2025_08_13 import UniverseManager, UniverseSpec
from core.archivist.archivist_v0_1_2025_08_13 import Repository, Archivist
from core.mannequin.mannequin_v0_1_2025_08_13 import LatticeMannequin, DORMANT, WARM, ACTIVE

def run():
    repo_root = "/mnt/data/repository_store_v0_1_2025_08_13"
    reg_root  = "/mnt/data/universe_registry_v0_1_2025_08_13"

    # Ensure a couple of SNAPs exist (reuse prior demo content if present)
    repo = Repository(repo_root)
    if not repo.list():
        for i in range(5):
            sid = f"culture-creative-v0_1_demo-{int(time.time())}-{i}"
            meta = {"snap_id": sid, "family":"culture", "type":"creative", "version":"v0_1_demo", "created_ts": time.time(), "tags":{"score": 0.65 + 0.07*i}}
            repo.save(sid, {"meta": meta, "content": {"payload": f"demo-{i}"}})

    # Create a Task universe if missing
    um = UniverseManager(repo_root, reg_root)
    if "TaskUniverse_CultureSnap" not in um.list_universes():
        TU = um.create_universe(UniverseSpec(
            name="TaskUniverse_CultureSnap",
            selectors={"family":["culture"], "type":["creative"], "tags":{}},
            policies={"isolated": True}
        ))

    # Mannequin lifecycle
    mannequin = LatticeMannequin("TaskUniverse_CultureSnap", repo_root=repo_root, registry_root=reg_root)
    manifest = mannequin.build_manifest(force=True)
    mannequin.toggle(on=True)   # WARM
    sl = mannequin.activate_slice(criteria={"family":["culture"], "type":["creative"], "tags":{"snap_score_gt":0.0}}, budget=3)

    out = {
        "state_after_toggle": "WARM",
        "slice_state": "ACTIVE" if mannequin.state==ACTIVE else mannequin.state,
        "slice_key": sl.key,
        "slice_nodes": sl.nodes,
        "slice_edges": sl.edges[:10],
        "coords_sample": sl.coords[:2],
        "budget_used": sl.budget_used
    }

    mannequin.deactivate_slice()
    mannequin.toggle(on=False)  # DORMANT
    out["final_state"] = mannequin.state
    return out

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
