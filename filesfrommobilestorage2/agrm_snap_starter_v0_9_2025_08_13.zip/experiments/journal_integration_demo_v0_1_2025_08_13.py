
import sys, pathlib, numpy as np, json
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL

rng = np.random.default_rng(42)
pts = rng.random((150,2))

# First run stays inline, writes journal deltas
ctrl1 = CTRL(cfg={
  "hash_mode":"auto",
  "num_sectors":32, "num_shells":8,
  "auto_thrash_tau": 10.0, "auto_coverage_kappa": 0.0, "auto_bucket_beta": 999.0,  # avoid escalation
  "promotion_policy":"fast_allowed"
})
res1 = ctrl1.solve(pts, max_ticks=3)
print("Run1 verdict:", res1["verdict"], "journal_applied:", res1["stats"].get("journal_applied"))

# Second run forces MDHG path; should replay journal before seeding
ctrl2 = CTRL(cfg={
  "hash_mode":"mdhg",
  "num_sectors":32, "num_shells":8
})
res2 = ctrl2.solve(pts, max_ticks=1)
print("Run2 mode: MDHG, journal_applied:", res2["stats"].get("journal_applied"))
