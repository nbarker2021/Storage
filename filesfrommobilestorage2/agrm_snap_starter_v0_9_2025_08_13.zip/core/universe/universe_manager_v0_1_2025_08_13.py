from dataclasses import dataclass, field, asdict
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import json, time, copy

@dataclass
class UniverseSpec:
    name: str
    parent: Optional[str] = None
    template: Optional[str] = None
    selectors: Dict[str, Any] = field(default_factory=dict)
    overlays: Dict[str, Any] = field(default_factory=dict)
    policies: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Universe:
    name: str
    created_ts: float
    spec: UniverseSpec
    snaps: List[str] = field(default_factory=list)
    overlays: Dict[str, Any] = field(default_factory=dict)
    lineage: List[str] = field(default_factory=list)

class UniverseManager:
    def __init__(self, repo_root: str, registry_root: str):
        self.repo_root = Path(repo_root)
        self.registry_root = Path(registry_root)
        self.registry_root.mkdir(parents=True, exist_ok=True)

    def _repo_path(self, snap_id: str) -> Path:
        return self.repo_root / f"{snap_id}.json"

    def _load_snap(self, snap_id: str) -> Dict[str, Any]:
        p = self._repo_path(snap_id)
        if not p.exists():
            raise FileNotFoundError(f"SNAP not found: {snap_id}")
        return json.loads(p.read_text(encoding="utf-8"))

    def _list_snaps(self) -> List[str]:
        return sorted([p.stem for p in self.repo_root.glob("*.json")])

    def _u_path(self, name: str) -> Path:
        return self.registry_root / f"{name}.json"

    def list_universes(self) -> List[str]:
        return sorted([p.stem for p in self.registry_root.glob("*.json")])

    def get_universe(self, name: str) -> 'Universe':
        p = self._u_path(name)
        data = json.loads(p.read_text(encoding="utf-8"))
        spec = UniverseSpec(**data["spec"])
        return Universe(name=data["name"], created_ts=data["created_ts"], spec=spec,
                        snaps=list(data.get("snaps", [])), overlays=data.get("overlays", {}),
                        lineage=list(data.get("lineage", [])))

    def save_universe(self, u: 'Universe') -> str:
        p = self._u_path(u.name)
        payload = {"name": u.name, "created_ts": u.created_ts, "spec": asdict(u.spec),
                   "snaps": u.snaps, "overlays": u.overlays, "lineage": u.lineage}
        p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return str(p)

    def _match_snap(self, snap: Dict[str, Any], selectors: Dict[str, Any]) -> bool:
        meta = snap.get("meta", {})
        fam_ok = not selectors.get("family") or (meta.get("family") in selectors.get("family", []))
        typ_ok = not selectors.get("type") or (meta.get("type") in selectors.get("type", []))
        tags = meta.get("tags", {})
        tag_sel = selectors.get("tags", {})
        for k,v in tag_sel.items():
            if k.endswith("_gt"):
                key=k[:-3]
                if not (tags.get(key, -1) > v): return False
            elif k.endswith("_lt"):
                key=k[:-3]
                if not (tags.get(key, 1e9) < v): return False
            else:
                if tags.get(k) != v: return False
        return bool(fam_ok and typ_ok)

    def _select_snaps(self, selectors: Dict[str, Any]) -> List[str]:
        snap_ids = self._list_snaps()
        out = []
        for sid in snap_ids:
            snap = self._load_snap(sid)
            if self._match_snap(snap, selectors):
                out.append(sid)
        return out

    def create_universe(self, spec: UniverseSpec) -> 'Universe':
        base_snaps = []
        lineage = []
        if spec.parent:
            parent = self.get_universe(spec.parent)
            base_snaps = list(parent.snaps)
            lineage = parent.lineage + [parent.name]
        selected = self._select_snaps(spec.selectors) if spec.selectors else []
        snaps = sorted(set(base_snaps + selected))
        adds = set(spec.overlays.get("add", []))
        rems = set(spec.overlays.get("remove", []))
        snaps = [s for s in snaps if s not in rems] + [s for s in adds if s not in snaps]
        u = Universe(name=spec.name, created_ts=time.time(), spec=spec, snaps=snaps, overlays=spec.overlays, lineage=lineage)
        self.save_universe(u)
        return u

    def fork_universe(self, base_name: str, new_name: str, overlays: Dict[str, Any]) -> 'Universe':
        base = self.get_universe(base_name)
        spec = base.spec
        spec2 = UniverseSpec(name=new_name, parent=base_name, selectors=spec.selectors, overlays=overlays, policies=spec.policies, metadata=spec.metadata)
        return self.create_universe(spec2)

    def compose(self, name: str) -> Dict[str, Any]:
        u = self.get_universe(name)
        metas = []
        for sid in u.snaps:
            snap = self._load_snap(sid)
            metas.append(snap["meta"])
        return {"universe": u.name, "count": len(u.snaps), "lineage": u.lineage, "policies": u.spec.policies, "metas": metas}

    def diff(self, a: str, b: str) -> Dict[str, Any]:
        ua = self.get_universe(a); ub = self.get_universe(b)
        set_a, set_b = set(ua.snaps), set(ub.snaps)
        return {"only_a": sorted(set_a - set_b), "only_b": sorted(set_b - set_a), "both": sorted(set_a & set_b)}
