
"""
VWS Bridge v0_2_2025_08_13
- Explicit seeding strategies: "grid" (O(N)) vs "exact" (O(N^2)).
- Runtime logging of chosen branch with N and params.
- Force-grid guard: raises if N >= N_guard and strategy != "grid".
"""
from typing import Dict, Any, Tuple
import numpy as np

def seed_vws_from_mdhg(points: np.ndarray, *, strategy:str="grid", grid_size:int=64,
                        force_grid:bool=True, N_guard:int=4000, journal=None) -> Dict[str,Any]:
    N = int(points.shape[0])
    if force_grid and N >= N_guard and strategy != "grid":
        if journal: journal.log("seed_guard_violation", N=N, asked=strategy, N_guard=N_guard)
        raise RuntimeError(f"force_grid active: N={N} >= {N_guard}, strategy='{strategy}' forbidden")
    chosen = None
    if strategy == "grid":
        # lightweight sampling: stratify by value range in first 2 dims
        d = min(2, points.shape[1])
        mins = points[:, :d].min(axis=0)
        maxs = points[:, :d].max(axis=0)
        # create grid_size buckets and sample 1 per bucket where possible
        idxs = []
        buckets = max(1, grid_size)
        rng = np.random.default_rng(17)
        # simple LHS-like sampling
        for b in range(buckets):
            target = mins + (maxs - mins) * ((b + rng.random(d)) / buckets)
            # nearest point to target
            j = np.argmin(((points[:, :d] - target)**2).sum(axis=1))
            idxs.append(int(j))
        chosen = sorted(set(idxs))
        if journal: journal.log("seed_branch", branch="grid", N=N, picks=len(chosen), grid_size=grid_size)
    elif strategy == "exact":
        # EXPENSIVE: pairwise norms to find a central seed set (mocked simple)
        if journal: journal.log("seed_branch", branch="exact", N=N)
        dists = np.linalg.norm(points[:, None, :] - points[None, :, :], axis=2)
        central = np.argsort(dists.sum(axis=1))[:min(64, N)].tolist()
        chosen = central
    else:
        if journal: journal.log("seed_error", msg="unknown strategy", asked=strategy)
        raise ValueError(f"unknown strategy: {strategy}")
    return {"strategy": strategy, "indices": chosen, "N": N}
