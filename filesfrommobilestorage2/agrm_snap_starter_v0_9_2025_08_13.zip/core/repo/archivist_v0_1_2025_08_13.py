
class Archivist_v0_1_2025_08_13:
    def __init__(self):
        self.store = {"user":[], "doc":[], "work":[], "work.fast":[], "gov":[]} 
    def add(self, universe: str, item: dict):
        assert universe in self.store, "unknown-universe"
        self.store[universe].append(item)
    def projector(self, universes, predicates=None):
        predicates = predicates or {}
        out = {}
        for u in universes:
            if u in self.store:
                items = self.store[u]
                out[u] = items[:predicates.get("limit", 10)]
        return out
