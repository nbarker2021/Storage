
import numpy as np, random
def tour_length_v0_1_2025_08_13(points, tour):
    L=0.0
    for a,b in zip(tour, tour[1:]+tour[:1]):
        L += float(np.linalg.norm(points[a]-points[b]))
    return L
def _gain(points, a,b,c,d,e,f):
    def d(x,y): return float(np.linalg.norm(points[x]-points[y]))
    base = d(a,b)+d(c,d)+d(e,f)
    cand = [ d(a,c)+d(b,d)+d(e,f), d(a,b)+d(c,e)+d(d,f), d(a,d)+d(e,b)+d(c,f),
             d(a,c)+d(d,e)+d(b,f), d(a,e)+d(d,b)+d(c,f), d(a,d)+d(e,c)+d(b,f),
             d(a,e)+d(c,b)+d(d,f)]
    best = min(cand)
    return base - best
def three_opt_once_v0_1_2025_08_13(points, tour, samples=200):
    n=len(tour); best=None; best_gain=0.0
    for _ in range(samples):
        i = random.randrange(0, n-5)
        j = random.randrange(i+2, n-3)
        k = random.randrange(j+2, n-1)
        a,b = tour[i], tour[(i+1)%n]
        c,d = tour[j], tour[(j+1)%n]
        e,f = tour[k], tour[(k+1)%n]
        g = _gain(points, a,b,c,d,e,f)
        if g > best_gain:
            best_gain = g; best = (i+1, j+1, k+1)
    if best is None: return tour, 0.0
    i1, j1, k1 = best
    new = tour[:i1] + list(reversed(tour[i1:j1])) + list(reversed(tour[j1:k1])) + tour[k1:]
    return new, -best_gain if best_gain>0 else 0.0
def three_opt_loop_v0_1_2025_08_13(points, tour, max_iter=30, samples=200):
    total_delta = 0.0
    for _ in range(max_iter):
        tour, delta = three_opt_once_v0_1_2025_08_13(points, tour, samples=samples)
        if delta >= 0.0: break
        total_delta += delta
    return tour, total_delta
