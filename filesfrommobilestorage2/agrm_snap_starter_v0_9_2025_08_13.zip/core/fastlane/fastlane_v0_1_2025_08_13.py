
from dataclasses import dataclass
from typing import Any, Dict

@dataclass
class FastLaneDecision:
    staged: bool
    promoted: bool
    reason: str

class FastLane:
    def __init__(self, quality_threshold: float = 0.7):
        self.quality_threshold = quality_threshold
        self.staging: Dict[str, Dict[str, Any]] = {}
        self.promoted: Dict[str, Dict[str, Any]] = {}

    def submit(self, key: str, result: Dict[str, Any], quality: float) -> FastLaneDecision:
        self.staging[key] = {"result": result, "quality": quality}
        if quality >= self.quality_threshold:
            self.promoted[key] = self.staging.pop(key)
            return FastLaneDecision(staged=False, promoted=True, reason="meets threshold")
        return FastLaneDecision(staged=True, promoted=False, reason="below threshold, awaiting full path")

    def promote_after_full(self, key: str, ok: bool) -> FastLaneDecision:
        if key in self.staging and ok:
            self.promoted[key] = self.staging.pop(key)
            return FastLaneDecision(staged=False, promoted=True, reason="full path passed")
        return FastLaneDecision(staged=key in self.staging, promoted=False, reason="full path failed or not found")
