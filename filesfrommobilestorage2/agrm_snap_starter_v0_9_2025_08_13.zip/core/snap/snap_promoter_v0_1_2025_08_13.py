
"""
SNAP Promoter v0_1_2025_08_13
- Decides universe promotion based on families/types and guardrails.
"""
from typing import Dict, Any, List

FORBID_TO_GOV = {"fiction","creative_writing"}
FORBID_TO_WORK = {"fiction"}

def allowed_universes(families: List[str], types: List[str]) -> List[str]:
    fam = set(families); typ = set(types)
    allow = {"user","doc","work","gov","work.fast"}
    if "fiction" in fam or "creative_writing" in typ:
        allow.discard("gov"); allow.discard("work")
    return sorted(list(allow))

def promotion_decision(classif: Dict[str, Any], target_universe: str) -> Dict[str, Any]:
    fam=set(classif.get("families",[])); typ=set(classif.get("types",[]))
    allowed = set(allowed_universes(list(fam), list(typ)))
    verdict = "promote" if target_universe in allowed else "quarantine"
    return {"verdict": verdict, "allowed": sorted(list(allowed))}
