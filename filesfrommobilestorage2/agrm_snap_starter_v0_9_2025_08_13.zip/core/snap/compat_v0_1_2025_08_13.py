
"""
SNAP Compatibility Scoring v0_1_2025_08_13
- Computes preference buckets between a SNAP's families/types and a task signature.
- Returns {"preferred":[...], "neutral":[...], "disfavored":[...] } for universes and task tags.
"""
from typing import Dict, List, Any

PREF_WEIGHT = {
    # family/type -> tag weight adjustments (positive prefers, negative disfavors)
    "fiction": {"gov": -2.0, "work": -1.5, "culture": +1.0, "creative": +1.2},
    "creative_writing": {"gov": -2.0, "work": -1.0, "culture": +1.2, "creative": +1.5},
    "factual": {"work": +0.5, "gov": +0.8, "analysis": +0.5},
    "source_code": {"work": +0.6, "dev": +1.0},
    "culture": {"culture": +0.8},
}

def score(families: List[str], types: List[str], task_tags: List[str], target_universe: str) -> float:
    fset=set(families); tset=set(types); tags=set(task_tags or [])
    base = 0.0
    # universe bias
    for k in fset|tset:
        w = PREF_WEIGHT.get(k,{}).get(target_universe, 0.0); base += w
    # tag alignments
    for k in fset|tset:
        for tag in tags:
            base += PREF_WEIGHT.get(k,{}).get(tag, 0.0) * 0.5
    return base

def bucketize(families: List[str], types: List[str], task_tags: List[str], universes: List[str]) -> Dict[str, List[str]]:
    items = [(u, score(families, types, task_tags, u)) for u in universes]
    # thresholds: >=0.5 preferred, <=-0.5 disfavored
    pref, neu, dis = [], [], []
    for u, s in items:
        if s >= 0.5: pref.append(u)
        elif s <= -0.5: dis.append(u)
        else: neu.append(u)
    return {"preferred": pref, "neutral": neu, "disfavored": dis}
