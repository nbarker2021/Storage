
import json, time, hashlib
from pathlib import Path
SCHEMA_VERSION = "v0_1_2025_08_13"
def _hash(obj)->str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode("utf-8")).hexdigest()[:16]
def create_snap(payload: dict, kind: str="generic", out_dir="snapshots/snaps")->str:
    rec = {"ts": time.time(), "schema": SCHEMA_VERSION, "kind": kind, "payload": payload}
    h = _hash(rec)
    p = Path(out_dir); p.mkdir(parents=True, exist_ok=True)
    f = p / f"SNAP_{kind}_{int(rec['ts'])}_{h}.json"
    f.write_text(json.dumps(rec, indent=2), encoding="utf-8")
    return str(f)
def load_snap(path: str)->dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))
def fuse_snaps(paths: list, kind: str="fusion", out_dir="snapshots/snaps")->str:
    snaps = [load_snap(p) for p in paths]
    payload = {"snaps": snaps}
    return create_snap(payload, kind=kind, out_dir=out_dir)
