
"""
SNAP Hybridizer v0_1_2025_08_13
- Fuses two profiles into a hybrid with weighted parameters; records provenance.
"""
from typing import Dict, Any

def fuse_profiles(pA: Dict[str, Any], pB: Dict[str, Any], alpha: float=0.5) -> Dict[str, Any]:
    def pick(k, default=None):
        a=pA.get(k); b=pB.get(k)
        if isinstance(a,(int,float)) and isinstance(b,(int,float)):
            return (1-alpha)*a + alpha*b
        return b if alpha>=0.5 else a if a is not None else b if b is not None else default
    out = {
        "name": f"hybrid({pA.get('name','A')}+{pB.get('name','B')})",
        "hash_mode": pA.get("hash_mode","auto") if alpha<0.5 else pB.get("hash_mode","auto"),
        "inline_dim_thresh": int(pick("inline_dim_thresh", 16)),
        "inline_n_thresh": int(pick("inline_n_thresh", 5000)),
        "auto_thrash_tau": float(pick("auto_thrash_tau", 0.8)),
        "auto_coverage_kappa": float(pick("auto_coverage_kappa", 0.15)),
        "auto_bucket_beta": float(pick("auto_bucket_beta", 8.0)),
        "promotion_policy": pA.get("promotion_policy","sample_full"),
        "entropy_proxy": float(pick("entropy_proxy", 0.4)),
        "provenance": {"parents":[pA.get("name","A"), pB.get("name","B")], "alpha": alpha}
    }
    return out
