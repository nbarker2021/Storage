
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
import math, json
from pathlib import Path
import time

from ..archivist.archivist_v0_1_2025_08_13 import Repository
from ..universe.universe_manager_v0_1_2025_08_13 import UniverseManager

PHI = (1 + 5**0.5)/2

DORMANT = "dormant"
WARM    = "warm"
ACTIVE  = "active_slice"

@dataclass
class SliceHandle:
    key: str
    nodes: List[Dict[str, Any]]           # materialized node metas
    coords: List[Tuple[float,...]]        # 8D lattice coords (placeholder mapping)
    edges: List[Tuple[int,int]]           # local adjacency list (indices into nodes)
    budget_used: int
    criteria: Dict[str, Any]

class LatticeMannequin:
    """
    Toggleable lattice representation of a Universe.
    - DORMANT: only manifest on disk (no memory).
    - WARM: manifest + lightweight indices loaded.
    - ACTIVE: specific slice materialized (by criteria), graph adjacency built only for that slice.
    """
    def __init__(self, universe_name: str, *, repo_root: str, registry_root: str):
        self.universe_name = universe_name
        self.repo_root = repo_root
        self.registry_root = registry_root
        self.um = UniverseManager(repo_root, registry_root)
        self.repo = Repository(repo_root)
        self.state = DORMANT
        self.manifest_path = Path(registry_root) / f"{universe_name}.manifest.json"
        self.manifest: Dict[str, Any] = {}
        self.active: Optional[SliceHandle] = None

    # --- Lifecycle ---
    def build_manifest(self, force: bool=False) -> Dict[str, Any]:
        """
        Build a compact manifest recording the SNAP ids and minimal tags for quick selection.
        """
        if self.manifest_path.exists() and not force:
            self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
            return self.manifest

        comp = self.um.compose(self.universe_name)
        metas = comp.get("metas", [])
        # Compact: only keep fields we need for selection + quick scoring
        brief = []
        for m in metas:
            brief.append({
                "snap_id": m.get("snap_id", ""),
                "family":  m.get("family", ""),
                "type":    m.get("type", ""),
                "tags":    m.get("tags", {}),
                "created_ts": m.get("created_ts", 0.0),
            })
        self.manifest = {"universe": self.universe_name, "count": len(brief), "metas": brief}
        self.manifest_path.write_text(json.dumps(self.manifest, indent=2), encoding="utf-8")
        return self.manifest

    def toggle(self, on: bool):
        if on:
            if not self.manifest:
                self.build_manifest(force=False)
            self.state = WARM
        else:
            self.state = DORMANT
            self.active = None

    # --- Mapping to 8D lattice (placeholder deterministic embedding) ---
    def _to_e8(self, meta: Dict[str, Any]) -> Tuple[float,...]:
        """
        Deterministic 8D mapping using tags; placeholder for real E8 embedding.
        Keeps values bounded and roughly separated.
        """
        t = meta.get("tags", {})
        f = meta.get("family", "na")
        ty = meta.get("type", "na")
        s = float(t.get("score", 0.0))
        age = max(0.0, (time.time() - float(meta.get("created_ts", 0.0))) / (3600*24)) if meta.get("created_ts") else 0.0
        # simple bounded transforms
        return (
            (hash(f) % 997) / 997.0,
            (hash(ty) % 991) / 991.0,
            math.tanh(s),
            1.0 / (1.0 + age),
            math.sin(PHI * (s+0.1)),
            math.cos(PHI * (s+0.2)),
            (s % 1.0),
            (age % 7.0)/7.0
        )

    # --- Build local adjacency for a slice (k-NN on coords) ---
    def _adj_for_slice(self, coords: List[Tuple[float,...]], k: int=4) -> List[Tuple[int,int]]:
        import numpy as np
        if not coords:
            return []
        X = np.array(coords, dtype=float)
        edges = set()
        for i in range(X.shape[0]):
            d = np.linalg.norm(X - X[i], axis=1)
            nn = np.argsort(d)[1:k+1]
            for j in nn:
                a,b = (i,int(j)) if i<int(j) else (int(j),i)
                edges.add((a,b))
        return sorted(edges)

    # --- Activate slice ---
    def activate_slice(self, criteria: Dict[str, Any], budget: int=128) -> SliceHandle:
        assert self.state != DORMANT, "Toggle on (WARM) before slicing."
        metas = self.manifest.get("metas", [])
        # Filter by simple criteria on tags/family/type
        filt = []
        for m in metas:
            ok = True
            fam = criteria.get("family"); typ = criteria.get("type"); tag = criteria.get("tags", {})
            if fam and m.get("family") not in fam: ok=False
            if typ and m.get("type") not in typ: ok=False
            for k,v in tag.items():
                if k.endswith("_gt"):
                    key=k[:-3]; ok = ok and (m.get("tags",{}).get(key,-1) > v)
                elif k.endswith("_lt"):
                    key=k[:-3]; ok = ok and (m.get("tags",{}).get(key,1e9) < v)
                else:
                    ok = ok and (m.get("tags",{}).get(k) == v)
            if ok: filt.append(m)
        # Rank by score then recency, cap by budget
        filt.sort(key=lambda m:(-float(m.get("tags",{}).get("score",0.0)), -float(m.get("created_ts",0.0))))
        nodes = filt[:budget]
        coords = [self._to_e8(m) for m in nodes]
        edges = self._adj_for_slice(coords, k=4)
        key = f"{self.universe_name}:{len(nodes)}:{int(time.time())}"
        self.active = SliceHandle(key=key, nodes=nodes, coords=coords, edges=edges, budget_used=len(nodes), criteria=criteria)
        self.state = ACTIVE
        return self.active

    def deactivate_slice(self):
        self.active = None
        if self.state == ACTIVE:
            self.state = WARM
