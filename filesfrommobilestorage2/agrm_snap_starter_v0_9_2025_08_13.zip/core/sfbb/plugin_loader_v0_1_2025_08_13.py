
"""
SFBB Plugin Loader v0_1_2025_08_13
Dynamic module loader that extracts provider classes by name.
"""
import importlib.util, types, sys
from pathlib import Path

def load_plugin_from_path(path: str):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    modname = "sfbb_plugin_" + p.stem
    spec = importlib.util.spec_from_file_location(modname, str(p))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)  # type: ignore
    return mod
