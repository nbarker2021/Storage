
import numpy as np, json, base64
from cqe.overlay import EO
from cqe.geo import e8_geo as e8g
from cqe.morsr import pulse

def _load_eo(path):
    j = json.load(open(path)); eo = EO()
    pres = j["nodes"]["present"]; w=j["nodes"]["w"]; phi=j["nodes"]["phi"]
    data = base64.b64decode(pres.encode("ascii"))
    bits=[]; present=[False]*248
    for byte in data:
        for k in range(8):
            bits.append((byte>>k)&1)
    for i in range(min(248, len(bits))):
        present[i]=bool(bits[i])
    eo.present=present
    for i,val in enumerate(w[:248]): eo.w[i]=float(val) if val is not None else 0.0
    for i,val in enumerate(phi[:248]): eo.phi[i]=float(val) if val is not None else 0.0
    eo.pose = j.get("pose", {})
    return eo

def test_weyl_invariance_of_degrees():
    assert (e8g.DEGS == 56).all()

def test_monotone_acceptance():
    # Mint a seed and ensure all accepted handshakes obey ΔΦ<=0
    from cqe.cli import cmd_mint_seed
    from types import SimpleNamespace
    path = "/mnt/data/_seed_test.json"
    cmd_mint_seed(SimpleNamespace(out=path))
    seed = _load_eo(path)
    out = pulse(seed)
    for h in out["handshakes"]:
        tr = h.get("ops_trace") or []
        if not tr: continue
        assert tr[0]["phi_after"] <= tr[0]["phi_before"] + 1e-9

def test_coxeter_plane_sanity():
    from cqe.viz.colorize import coxeter_plane_basis, project_roots_to_plane
    B = coxeter_plane_basis()
    P = project_roots_to_plane(B)
    assert P.shape == (240,2)
    assert np.isfinite(P).all()
