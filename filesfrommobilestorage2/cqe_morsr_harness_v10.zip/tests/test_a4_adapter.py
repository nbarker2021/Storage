
from cqe.adapters.superperm_a4 import find_A4_indices, embed_perm_to_EO

def test_a4_indices_count():
    idx = find_A4_indices()
    # Typical A4 has 20 roots; allow tolerance 16..24 due to numeric span pick
    assert 16 <= len(idx) <= 24

def test_embed_perm_populates_only_a4():
    idx = set(find_A4_indices())
    eo = embed_perm_to_EO([2,1,3,4,5])  # one inversion
    actives = {i for i,b in enumerate(eo.present[:240]) if b}
    assert actives.issubset(idx)
