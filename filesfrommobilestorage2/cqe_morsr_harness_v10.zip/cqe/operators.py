
import math
from typing import Dict, Any
from .overlay import EO

def op_Rtheta(eo: EO, step: int = 1) -> EO:
    # Advance coxeter_k and rotate any defined phases by small rational step
    k = (eo.pose.get("coxeter_k",0) + step) % 30
    eo.pose["coxeter_k"]=k
    for i,phi in enumerate(eo.phi):
        if phi is not None:
            eo.phi[i] = phi + (math.pi/2) * (step/15.0)
    return eo

def op_Midpoint(eo: EO) -> EO:
    # Toy midpoint: flip a few low-weight inactive nodes on to reduce parity syndromes
    from .overlay import lane_bits_from_overlay, syndrome_lane
    lane = lane_bits_from_overlay(eo.present)
    synd = syndrome_lane(lane)
    # turn on up to 3 nodes in lanes that cause syndrome bits to drop (toy heuristic)
    flips = 0
    for lane_idx, s in enumerate(synd):
        if s!=0 and flips<3:
            # find first inactive node with this lane index
            for i,b in enumerate(eo.present):
                if not b and i%8==lane_idx:
                    eo.present[i]=True; eo.w[i]=0.5; eo.phi[i]=0.0
                    flips += 1; break
    return eo

def op_ParityMirror(eo: EO) -> EO:
    # No-op for harness except toggling a mirror flag in pose
    eo.pose["diag_auto_id"] = 1 - int(eo.pose.get("diag_auto_id",0))
    return eo

def op_SingleInsert(eo: EO, idx: int, weight: float = 0.7, phi: float = 0.0) -> EO:
    if 0<=idx<248 and not eo.present[idx]:
        eo.present[idx]=True; eo.w[idx]=weight; eo.phi[idx]=phi
    return eo


def op_WeylReflect(eo: EO, simple_idx: int = 0) -> EO:
    """Reflect active E8 root indices (0..239) by the given simple root.
    Cartan placeholders (>=240) are left unchanged. We map weights/phi by sum merge.
    """
    from .geo.e8_geo import reflect_root_index
    # copy current state
    new_present = eo.present[:]
    new_w = eo.w[:]
    new_phi = eo.phi[:]
    moved = {}
    for i,b in enumerate(eo.present[:240]):
        if not b: continue
        j = reflect_root_index(i, simple_idx)
        if j != i:
            new_present[i] = False
            # merge at j
            new_present[j] = True
            new_w[j] = min(1.0, (new_w[j] if new_w[j] else 0.0) + (eo.w[i] if eo.w[i] else 0.0))
            new_phi[j] = eo.phi[i] if eo.phi[i] is not None else new_phi[j]
            moved[i]=j
    eo.present = new_present
    eo.w = new_w
    eo.phi = new_phi
    # record move
    eo.pose["we yl_simple_idx"] = simple_idx
    return eo
