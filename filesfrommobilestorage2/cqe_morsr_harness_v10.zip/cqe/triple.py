
from typing import Dict, Any, List, Optional
import math
from .overlay import EO
from .canonicalize import canonicalize
from .viz.colorize import colorize_nodes
from .overlay import lane_bits_from_overlay, golay_bits_from_overlay, syndrome_lane, syndrome_golay
from .operators import op_WeylReflect

VIZ = None
def _meta():
    global VIZ
    if VIZ is None:
        VIZ = colorize_nodes()  # idx -> meta
    return VIZ

def _sector_bins(eo: EO) -> Dict[int, List[int]]:
    meta = _meta()
    bins = {s: [] for s in range(8)}
    for i,b in enumerate(eo.present[:240]):
        if not b: continue
        m = meta.get(i)
        if not m: continue
        s = int(m["sector_idx"])
        bins[s].append(i)
    return bins

class E8Triple:
    """
    Holds three overlays (Left/Internal, Center, Right/External) and projects L/R into C
    with sector-aware routing, weighting, and center-only parity fixes guided by ECC syndromes.
    """
    def __init__(self, left: EO, center: EO, right: EO, w_left: float = 0.15, w_right: float = 0.15, allow_sectors: Optional[List[int]] = None):
        self.left = left
        self.center = center
        self.right = right
        self.w_left = w_left
        self.w_right = w_right
        self.allow_sectors = allow_sectors  # list of sector indices (0..7) or None for all

    @staticmethod
    def from_three(left: EO, center: EO, right: EO, **kwargs) -> "E8Triple":
        return E8Triple(left, center, right, **kwargs)

    def project_into_center(self) -> EO:
        meta = _meta()
        C = EO(present=self.center.present[:], w=self.center.w[:], phi=self.center.phi[:], pose=self.center.pose.copy())
        Lbins = _sector_bins(self.left)
        Rbins = _sector_bins(self.right)
        Cbins = _sector_bins(self.center)
        for s in range(8):
            if self.allow_sectors is not None and s not in self.allow_sectors:
                continue
            targets = Cbins[s] if Cbins[s] else []
            if not targets:
                candidates = [i for i,b in enumerate(self.center.present[:240]) if b]
                targets = candidates[:8] if candidates else list(range(0,8))
            for idx in Lbins[s]:
                t = min(targets, key=lambda j: abs(meta[j]["theta_deg"] - meta[idx]["theta_deg"]))
                C.present[t] = True
                C.w[t] = min(1.0, (C.w[t] if C.w[t] else 0.0) + self.w_left)
            for idx in Rbins[s]:
                t = min(targets, key=lambda j: abs(meta[j]["theta_deg"] - meta[idx]["theta_deg"]))
                C.present[t] = True
                C.w[t] = min(1.0, (C.w[t] if C.w[t] else 0.0) + self.w_right)
        C.update_invariants()
        cj = canonicalize(C.to_json()); C.canon = cj["canon"]
        prov = C.pose.get("provenance", {})
        prov["triple_projection"] = {
            "left_id": getattr(self.left.canon, "hash_id", None) if hasattr(self.left, "canon") else None,
            "center_id": getattr(self.center.canon, "hash_id", None) if hasattr(self.center, "canon") else None,
            "right_id": getattr(self.right.canon, "hash_id", None) if hasattr(self.right, "canon") else None,
            "w_left": self.w_left, "w_right": self.w_right, "allow_sectors": self.allow_sectors
        }
        C.pose["provenance"] = prov
        return C

    def _center_parity_fix(self, C: EO, max_trials: int = 32) -> EO:
        """
        Try small flips of active indices that align with nonzero lane/golay syndromes.
        Accept only non-increasing Φ; keep the best candidate.
        """
        base_phi = C.compute_PHI()
        best = C; best_phi = base_phi
        lane = lane_bits_from_overlay(C.present)
        golay = golay_bits_from_overlay(C.present)
        sL = syndrome_lane(lane)
        sG = syndrome_golay(golay)
        targets = []
        for i,b in enumerate(C.present[:240]):
            if not b: continue
            Llen=len(sL); Glen=len(sG)
            if sL[i % Llen] != 0 or sG[i % Glen] != 0:
                targets.append(i)
        targets += [i for i,b in enumerate(C.present[:240]) if b][:8]
        seen = set()
        for i in targets[:max_trials]:
            if i in seen: continue
            seen.add(i)
            cand = EO(present=C.present[:], w=C.w[:], phi=C.phi[:], pose=C.pose.copy())
            if cand.present[i]:
                cand.w[i] = max(0.0, cand.w[i] - 0.2)
                if cand.w[i] == 0.0: cand.present[i] = False
            else:
                cand.present[i] = True; cand.w[i] = min(1.0, cand.w[i] + 0.2)
            cand.update_invariants()
            phi_after = cand.compute_PHI()
            if phi_after <= best_phi:
                best, best_phi = cand, phi_after
        return best

    def force_center_parity(self, C: EO) -> EO:
        """Center-only corrections: first ECC-guided flips; then optional small Weyl nudge."""
        C1 = self._center_parity_fix(C, max_trials=32)
        if C1.compute_PHI() <= C.compute_PHI():
            return C1
        phi_before = C.compute_PHI(); best=C; best_phi=phi_before
        for sidx in (0,1,2,7):
            cand = EO(present=C.present[:], w=C.w[:], phi=C.phi[:], pose=C.pose.copy())
            op_WeylReflect(cand, simple_idx=sidx); cand.update_invariants()
            pa = cand.compute_PHI()
            if pa <= best_phi:
                best, best_phi = cand, pa
        return best

    def to_solve_overlay(self) -> EO:
        C1 = self.project_into_center()
        C2 = self.force_center_parity(C1)
        C2.update_invariants()
        canon = canonicalize(C2.to_json()); C2.canon = canon["canon"]
        C2.pose["frame"] = "solve"
        return C2
