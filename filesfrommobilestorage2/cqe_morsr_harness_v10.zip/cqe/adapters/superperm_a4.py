
import numpy as np
from typing import List, Dict
from ..geo import e8_geo as e8g
from ..overlay import EO

def _orth(A):
    # Orthonormal basis of columns of A via QR
    Q, _ = np.linalg.qr(A)
    return Q

def find_A4_indices(tol=1e-6) -> List[int]:
    """Pick the first 4 simple roots in the provided E8.simple root matrix as an A4 basis,
    then return all root indices whose vectors lie in the span of those 4 (i.e., zero residual perpendicular).
    Expect ~20 roots for A4.
    """
    S = e8g.SIMPLE  # (8x8, simple roots as rows)
    A = S[:4,:].T   # 8x4 basis (first four simple roots)
    Q = _orth(A)    # 8x4 orthonormal columns spanning A4 subspace
    R = e8g.R       # 240x8 roots
    proj = R @ Q @ Q.T
    residual = R - proj
    mask = (np.sum(residual**2, axis=1) <= tol)
    idx = np.where(mask)[0].tolist()
    return idx

def embed_perm_to_EO(perm: List[int]) -> EO:
    """Given a permutation of 1..5, activate A4 roots that correspond to inversions.
    For each inversion (i<j and perm[i] > perm[j]) we pick one A4 root index deterministically by angle order.
    This is a faithful, fixed embedding to test CQE geometry on S5 without hash-spray.
    """
    idxs = find_A4_indices()
    # order those indices by their angle in Coxeter plane via the colorizer metadata
    from ..viz.colorize import colorize_nodes
    meta = colorize_nodes()
    def theta(i): return meta[i]["theta_deg"]
    a4_sorted = sorted([i for i in idxs if i in meta], key=theta)
    if not a4_sorted:
        a4_sorted = idxs[:]
    eo = EO()
    # Map inversions to successive a4 roots cyclically
    invs = []
    for i in range(len(perm)):
        for j in range(i+1, len(perm)):
            if perm[i] > perm[j]:
                invs.append((i,j))
    for k,_ in enumerate(invs):
        if not a4_sorted: break
        idx = a4_sorted[k % len(a4_sorted)]
        eo.present[idx] = True; eo.w[idx] = min(1.0, eo.w[idx] + 0.6)
    eo.update_invariants()
    eo.pose["adapter"] = {"type":"superperm_a4", "perm": perm, "a4_indices": a4_sorted[:8]}
    return eo
