
import itertools
from typing import List, Tuple, Dict
import numpy as np

# Enumerate E8 roots (norm^2 = 2)
def e8_roots() -> np.ndarray:
    roots = []
    # Type I: (±1, ±1, 0,...,0)
    for i in range(8):
        for j in range(i+1, 8):
            for s1 in (+1,-1):
                for s2 in (+1,-1):
                    v = np.zeros(8, dtype=float)
                    v[i]=s1; v[j]=s2
                    roots.append(v)
    # Type II: 1/2(±1,...,±1) with even # of minus
    for signs in itertools.product([+1,-1], repeat=8):
        if (sum(1 for s in signs if s==-1) % 2) == 0:
            v = 0.5*np.array(signs, dtype=float)
            roots.append(v)
    R = np.array(roots, dtype=float)
    # sanity
    l2 = np.einsum('ij,ij->i', R, R)
    assert np.allclose(l2, 2.0)
    # consistent ordering
    R = np.array(sorted([tuple(v) for v in R]))
    return R

R = e8_roots()

# Simple roots (one common choice)
SIMPLE = np.array([
    [ 1, -1,  0,  0,  0,  0,  0,  0],
    [ 0,  1, -1,  0,  0,  0,  0,  0],
    [ 0,  0,  1, -1,  0,  0,  0,  0],
    [ 0,  0,  0,  1, -1,  0,  0,  0],
    [ 0,  0,  0,  0,  1, -1,  0,  0],
    [ 0,  0,  0,  0,  0,  1, -1,  0],
    [ 0,  0,  0,  0,  0,  1,  1,  0],
    [-0.5,-0.5,-0.5,-0.5,-0.5,-0.5,-0.5, 0.5]
], dtype=float)

# Map vectors to indices (rounded tuples)
V2I: Dict[Tuple[float,...], int] = {tuple(v): i for i,v in enumerate(R)}

def reflect_vec(v: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    # alpha·alpha = 2
    return v - np.dot(v, alpha) * alpha

def reflect_root_index(i: int, simple_idx: int) -> int:
    v = R[i]
    a = SIMPLE[simple_idx]
    w = reflect_vec(v, a)
    key = tuple(w.tolist())
    # exact since coordinates are multiples of 0.5
    j = V2I.get(key, None)
    if j is None:
        # fallback rounding if needed
        key = tuple([round(x,6) for x in w.tolist()])
        # rebuild a rounded map once
        rounded = {tuple([round(x,6) for x in r.tolist()]): idx for idx,r in enumerate(R)}
        j = rounded[key]
    return j

def neighbor_adjacency() -> Tuple[list, np.ndarray]:
    # dot=1 adjacency -> degree 56
    G = R @ R.T
    n = R.shape[0]
    A = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i+1, n):
            if abs(G[i,j] - 1.0) < 1e-9:
                A[i].append(j)
                A[j].append(i)
    degs = np.array([len(nei) for nei in A])
    return A, degs

ADJ, DEGS = neighbor_adjacency()  # precompute
