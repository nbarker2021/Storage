
import json, math
from typing import Dict, Any, List
import numpy as np
from ..geo.e8_geo import R, SIMPLE

def reflection_matrix(alpha: np.ndarray) -> np.ndarray:
    # s_alpha(v) = v - (v·alpha) alpha ; alpha·alpha = 2 -> matrix I - alpha alpha^T
    return np.eye(8) - np.outer(alpha, alpha)

def coxeter_matrix(simple: np.ndarray = SIMPLE) -> np.ndarray:
    M = np.eye(8)
    # product of simple reflections (order chosen as listed)
    for a in simple:
        M = reflection_matrix(a) @ M
    return M

def coxeter_plane_basis() -> np.ndarray:
    C = coxeter_matrix()
    w, V = np.linalg.eig(C)
    # target eigen-angle ~ 2π/30
    target = 2*math.pi/30.0
    arg = np.angle(w)  # in [-pi,pi]
    idx = np.argmin(np.abs(((arg+2*math.pi)%(2*math.pi)) - target))
    v = V[:, idx]
    e1 = np.real(v); e2 = np.imag(v)
    # Orthonormalize
    def norm(x): 
        n = np.linalg.norm(x)
        return x/n if n>0 else x
    e1 = norm(e1)
    # make e2 orthogonal to e1
    e2 = e2 - np.dot(e2,e1)*e1
    e2 = norm(e2)
    B = np.stack([e1, e2], axis=1)  # 8x2
    return B

def project_roots_to_plane(B: np.ndarray) -> np.ndarray:
    # R (240x8) * B (8x2) -> coords (240x2)
    return R @ B

SECTOR_LABELS = ["E", "ENE", "NE", "N", "NW", "WNW", "W", "S"]  # 8 sectors, 45° bins

def sector_of_angle(theta: float) -> int:
    # theta radians; map to [0,2π)
    t = (theta + 2*math.pi) % (2*math.pi)
    # 8 bins of width 45°
    sector = int((t + math.pi/8) // (math.pi/4)) % 8
    return sector

def hsv_to_hex(h: float, s: float, v: float) -> str:
    import colorsys
    r,g,b = colorsys.hsv_to_rgb(h,s,v)
    return "#{:02x}{:02x}{:02x}".format(int(r*255),int(g*255),int(b*255))

def colorize_nodes() -> Dict[int, Dict[str, Any]]:
    B = coxeter_plane_basis()
    P = project_roots_to_plane(B)  # 240x2
    # normalize radius to [0,1]
    r = np.linalg.norm(P, axis=1)
    rmax = r.max() if r.max()>0 else 1.0
    out = {}
    for i,(x,y) in enumerate(P):
        theta = math.atan2(y,x)
        sector = sector_of_angle(theta)
        label = SECTOR_LABELS[sector]
        radius = math.sqrt(x*x + y*y) / rmax
        # hue per sector; gradient via radius; keep saturation 1
        h = sector / 8.0
        s = 1.0
        v = 0.5 + 0.5*radius
        color = hsv_to_hex(h, s, v)
        out[i] = {"sector_idx": sector, "sector_label": label,
                  "theta_deg": math.degrees(theta), "radius": radius,
                  "hex": color}
    return out
