
import numpy as np

def gf2_matmul(A,B): return (A @ B) % 2

def gf2_row_reduce(A: np.ndarray):
    A = A.copy() % 2
    m, n = A.shape
    row = 0
    pivots = []
    for col in range(n):
        pivot = None
        for r in range(row, m):
            if A[r, col] == 1:
                pivot = r; break
        if pivot is None: continue
        if pivot != row:
            A[[row, pivot]] = A[[pivot, row]]
        pivots.append(col)
        for r in range(m):
            if r != row and A[r, col] == 1:
                A[r, :] ^= A[row, :]
        row += 1
        if row == m: break
    return A, pivots

def gf2_nullspace(A: np.ndarray) -> np.ndarray:
    A = A.copy() % 2
    m, n = A.shape
    R, pivots = gf2_row_reduce(A)
    pivset = set(pivots)
    free_cols = [j for j in range(n) if j not in pivset]
    Ns = []
    for f in free_cols:
        v = np.zeros(n, dtype=int); v[f]=1
        # back-substitute
        for i in reversed(range(len(pivots))):
            p = None
            # find leading 1 in row i
            for j in range(n):
                if R[i,j]==1: p=j; break
            if p is None: continue
            s = 0
            for j in range(p+1, n):
                if R[i,j]==1 and v[j]==1: s ^= 1
            v[p]=s
        Ns.append(v)
    if len(Ns)==0: return np.zeros((0,n), dtype=int)
    return np.stack(Ns, axis=0)

def ext_hamming_84():
    G = np.array([
        [1,0,0,0, 0,1,1,1],
        [0,1,0,0, 1,0,1,1],
        [0,0,1,0, 1,1,0,1],
        [0,0,0,1, 1,1,1,0]
    ], dtype=int)
    H = gf2_nullspace(G)
    assert H.shape==(4,8)
    assert np.all(gf2_matmul(G, H.T)==0)
    return G, H

def poly_to_vec(degs, n):
    v = np.zeros(n, dtype=int)
    for d in degs: v[d % n] = 1
    return v

def ext_golay_24():
    # (23,12) cyclic via generator, then even parity extension
    n23 = 23
    g_degs = [11,9,7,6,5,1,0]
    g_vec = poly_to_vec(g_degs, n23)
    rows23 = []
    row = g_vec.copy()
    for _ in range(12):
        rows23.append(row.copy())
        row = np.roll(row, 1)
    G23 = np.stack(rows23, axis=0)   # 12x23
    parity_col = (G23.sum(axis=1) % 2).reshape(-1,1)
    G24 = np.concatenate([G23, parity_col], axis=1)  # 12x24
    H24 = gf2_nullspace(G24)
    assert H24.shape==(12,24)
    assert np.all(gf2_matmul(G24, H24.T)==0)
    return G24, H24
