
import numpy as np
from .statebus_v0_4_2025_08_13 import StateBus_v0_4_2025_08_13 as Bus
from .navigator_v0_4_2025_08_13 import NavigatorGR_v0_4_2025_08_13 as Nav
from .vws_bridge_v0_1_2025_08_13 import seed_vws_from_mdhg_v0_1_2025_08_13 as seed
from .mdhg_v0_2_2025_08_13 import MDHG_v0_2_2025_08_13 as MDHG
class AGRMController_v0_6_2025_08_13:
    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.bus = Bus()
        self.navigator = Nav(self.cfg, self.bus)
        self.mdhg = None
    def _build_mdhg(self, points):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        m = MDHG(dim=points.shape[1], decay_lambda=self.cfg.get("mdhg_decay", 0.01))
        n = points.shape[0]
        center = points.mean(axis=0); vecs = points - center
        angles = _np.arctan2(vecs[:,1], vecs[:,0])
        num_floors = self.cfg.get("num_sectors", 32)
        sec_edges = _np.linspace(-_np.pi, _np.pi, num_floors+1)
        sectors = _np.digitize(angles, sec_edges) - 1
        for i in range(n):
            meta = {"building": self.cfg.get("building","default"), "floor": f"F{sectors[i]}", "room": "R0"}
            m.insert(i, points[i], meta)
        for i in range(n): m.bump_heat([i])
        return m
    def solve(self, points, max_ticks=8):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        self.mdhg = self._build_mdhg(points)
        self.bus.vws = seed(self.mdhg, points, building=self.cfg.get("building","default"), k_each=self.cfg.get("vws_k",5), top_edges=self.cfg.get("vws_edges",128))
        _ = self.navigator.assign_shells_and_sectors(points)
        chosen_all = []
        for _ in range(max_ticks):
            chosen_all.extend(self.navigator.sweep_step(points))
        return {"stats": self.bus.stats, "chosen": chosen_all, "meta": self.bus.meta, "verdict":"pass"}
