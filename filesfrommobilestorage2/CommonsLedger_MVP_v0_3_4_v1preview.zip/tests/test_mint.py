import json, os, yaml
from sidecar_adapters.speedlight_router import Ledger, MintEngine

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
policy = yaml.safe_load(open(os.path.join(BASE,"config","policy.yaml")))
ledger = Ledger(os.path.join(BASE,"data"))
engine = MintEngine(policy, ledger)

def test_mint_example():
    obj = json.load(open(os.path.join(BASE,"examples","overdose_example.json")))
    rid, minted = engine.mint(obj)
    assert rid and isinstance(minted, dict)
    assert minted.get("MERIT",0) > 0

if __name__ == "__main__":
    test_mint_example()
    print("OK")
