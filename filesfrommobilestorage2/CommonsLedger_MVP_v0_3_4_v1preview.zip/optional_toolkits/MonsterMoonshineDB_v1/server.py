from api import serve

if __name__ == '__main__':
    serve()
