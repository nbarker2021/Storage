\
import os, json, time, hashlib, threading, math
from typing import Dict, Any, Tuple

try:
    from speedlight_sidecar_plus import SpeedLightPlus
except Exception:
    SpeedLightPlus = None

ADAPTER_STATUS = {"geotokenizer": False, "novelty": False, "mdhg": False, "moonshine": False}
try:
    from .optional_adapters import geotokenize, novelty, mdhg_signal, moonshine_crosshit  # type: ignore
    ADAPTER_STATUS.update({"geotokenizer": True, "novelty": True, "mdhg": True, "moonshine": True})
except Exception:
    try:
        from optional_adapters import geotokenize, novelty, mdhg_signal, moonshine_crosshit  # type: ignore
        ADAPTER_STATUS.update({"geotokenizer": True, "novelty": True, "mdhg": True, "moonshine": True})
    except Exception:
        # Provide safe fallbacks
        def geotokenize(s: str): 
            return re.findall(r"[A-Za-z0-9_]+", s or "")
        def novelty(tokens, corpus_signature=None): 
            if not tokens: return 0.0
            uniq = len(set(tokens)); return max(0.05, min(1.0, uniq/200.0))
        def mdhg_signal(tokens): 
            return 0.1 if tokens else 0.0
        def moonshine_crosshit(tokens): 
            return 0.0


_LOCK = threading.Lock()

class Ledger:
    def __init__(self, base_dir: str):
        self.base = base_dir
        os.makedirs(self.base, exist_ok=True)
        self.ledger_path = os.path.join(self.base, "ledger.jsonl")
        self.payout_wallet = os.path.join(self.base, "payout_wallet.json")
        self.mint_stats = os.path.join(self.base, "mint_stats.json")
        if not os.path.exists(self.payout_wallet):
            with open(self.payout_wallet,"w") as f:
                json.dump({"balance_fiat":0.0}, f)
        if not os.path.exists(self.mint_stats):
            with open(self.mint_stats,"w") as f:
                json.dump({"actor_avgs":{}, "node_avg":0.0, "N":0}, f)

    def append(self, entry: Dict[str,Any]):
        with _LOCK, open(self.ledger_path,"a") as f:
            f.write(json.dumps(entry, ensure_ascii=False)+"\\n")

    def add_payout(self, amount: float):
        with _LOCK:
            data = json.load(open(self.payout_wallet))
            data["balance_fiat"] = round(data.get("balance_fiat",0.0)+float(amount), 2)
            json.dump(data, open(self.payout_wallet,"w"))

    def update_mint_stats(self, actor_id: str, total_mint: float):
        with _LOCK:
            st = json.load(open(self.mint_stats))
            N = st.get("N",0)
            node_avg = st.get("node_avg",0.0)
            node_avg = (node_avg*N + total_mint)/(N+1)
            st["node_avg"] = node_avg
            st["N"] = N+1
            aa = st.get("actor_avgs",{})
            aavg, ac = aa.get(actor_id, [0.0,0])
            aavg = (aavg*ac + total_mint)/(ac+1)
            aa[actor_id] = [aavg, ac+1]
            st["actor_avgs"] = aa
            json.dump(st, open(self.mint_stats,"w"))

    def get_mint_stats(self):
        return json.load(open(self.mint_stats))

class MintEngine:
    def __init__(self, policy: Dict[str,Any], ledger: Ledger):
        self.policy = policy
        self.ledger = ledger
        if SpeedLightPlus:
            self.sl = SpeedLightPlus(mem_bytes=64_000_000, disk_dir=os.path.join(ledger.base,".cache"), ledger_path=os.path.join(ledger.base,".sl_ledger.jsonl"))
        else:
            self.sl = None

    # --- scoring helpers ---
    def _endorsement_strength(self, endorsements):
        if not endorsements: return 0.0
        s = sum(float(e.get("confidence",0)) for e in endorsements)
        return min(1.0, math.log1p(s)/math.log1p(10.0))

    def _lineage_weight(self, lineage_refs):
        if not lineage_refs: return 0.0
        avg = sum(float(r.get("score",0)) for r in lineage_refs)/len(lineage_refs)
        kinds = len(set(r.get("kind") for r in lineage_refs))
        return max(0.0, min(1.0, avg * (1.0 + 0.06*(kinds-1))))

    def _realized_deploy(self, deployments: int):
        return min(1.0, math.sqrt(max(0, deployments))/8.0)

    def _safety_gate(self, safety: Dict[str,bool]):
        return bool(safety and safety.get("non_coercive") and safety.get("non_weaponizable") and safety.get("harm_reduction_pass"))

    def _lab_quality(self, lab):
        # lab: {"passes":int,"trials":int}
        if not lab: return 0.3
        t = max(1, int(lab.get("trials",0)))
        p = max(0, min(int(lab.get("passes",0))/t, 1.0))
        return max(0.2, 0.4 + 0.6*p)  # in [0.2, 1.0]

    def _delta_phi(self, receipts):
        # receipts: {"baseline_cost":float,"actual_cost":float}
        if not receipts: return 0.0
        b = max(0.0, float(receipts.get("baseline_cost",0.0)))
        a = max(0.0, float(receipts.get("actual_cost",0.0)))
        if b <= 0.0: return 0.0
        return max(0.0, min(1.0, (b - a)/b))

    def _novelty(self, text):
        toks = geotokenize(text or "")
        n = novelty(toks, corpus_signature=None)
        m = mdhg_signal(toks)
        moon = moonshine_crosshit(toks)
        # combine (bounded)
        return max(0.0, min(1.0, 0.6*n + 0.25*m + 0.15*moon))

    def _supply_governor(self, actor_id: str, total: float):
        stats = self.ledger.get_mint_stats()
        node_avg = stats.get("node_avg", 0.2)
        actor_avgs = stats.get("actor_avgs",{})
        aavg = actor_avgs.get(actor_id, [0.2,1])[0]
        target = 0.25  # target total mint per submission (tunable)
        scale = target / max(1e-6, (0.6*node_avg + 0.4*aavg))
        scale = max(0.5, min(1.5, scale))
        return total * scale

    def preview(self, contribution: Dict[str,Any]) -> Dict[str,Any]:
        actor = contribution.get("actor_id","anon")
        summary = (contribution.get("summary") or "") + " " + (contribution.get("details") or "")
        E = self._endorsement_strength(contribution.get("evidence",{}).get("endorsements",[]))
        L = self._lineage_weight(contribution.get("evidence",{}).get("lineage_refs",[]))
        R = self._realized_deploy(int(contribution.get("evidence",{}).get("deployments",0)))
        S_gate = self._safety_gate(contribution.get("evidence",{}).get("safety",{}))
        Q = self._lab_quality(contribution.get("evidence",{}).get("lab",{}))
        dPhi = self._delta_phi(contribution.get("evidence",{}).get("receipts",{}))
        N = self._novelty(summary)
        core = 0.15*E + 0.20*L + 0.15*R + 0.20*Q + 0.10*dPhi + 0.20*N
        core = max(0.0, min(1.0, core))  # bound
        gamma = 1.1
        base_total = (core ** gamma) if S_gate else 0.0
        # domain allocations by alpha_d
        alphas = self.policy.get("domains",{})
        total_alpha = sum(float(alphas.get(d,1.0)) for d in contribution.get("domain_claims",[])) or 1.0
        per_domain = {}
        for d in contribution.get("domain_claims",[]):
            a = float(alphas.get(d,1.0))
            per_domain[d] = a / total_alpha  # share
        # supply governor (preview uses current stats)
        total_scaled = self._supply_governor(actor, base_total)
        minted = {d: round(per_domain[d]*total_scaled, 6) for d in per_domain}
        return {"factors":{"E":E,"L":L,"R":R,"Q":Q,"N":N,"dPhi":dPhi,"S_gate":S_gate,"core":core,"base_total":base_total},
                "minted": minted, "total_scaled": round(total_scaled,6)}

    def mint(self, contribution: Dict[str,Any]) -> Tuple[str, Dict[str,float]]:
        prev = self.preview(contribution)
        minted = prev["minted"]
        rid = hashlib.sha256(json.dumps({"ts": time.time(), "actor":contribution.get("actor_id",""), "summary": contribution.get("summary","")}, sort_keys=True).encode("utf-8")).hexdigest()[:16]
        entry = {"type":"mint", "policy_version": pv,"rid":rid,"actor":contribution.get("actor_id"),"domains":minted, **prev["factors"], "ts":time.time()}
        self.ledger.append(entry)
        self.ledger.update_mint_stats(contribution.get("actor_id","anon"), prev["total_scaled"])
        return rid, minted

    def settle_paid_service(self, service: Dict[str,Any]):
        rev = float(service.get("revenue_fiat",0.0))
        patterns = service.get("patterns",[])
        payout_fraction = float(self.policy.get("payout_split",{}).get("payout_wallet_fraction", 0.5))
        creators_share = rev * (1.0 - payout_fraction)
        self.ledger.add_payout(rev * payout_fraction)
        total_weight = sum(max(0.0,float(p.get("weight",0))) for p in patterns) or 1.0
        for p in patterns:
            share = creators_share * (max(0.0,float(p.get("weight",0)))/ total_weight)
            entry = {"type":"royalty","service_id":service.get("service_id"),
                     "pattern_id":p.get("pattern_id"),"creator_id":p.get("creator_id"),
                     "fiat_amount": round(share,2),"ts":time.time(),
                     "domain_breakdown": p.get("domain_breakdown",{})}
            self.ledger.append(entry)
        self.ledger.append({"type":"payout_wallet_credit","amount": round(rev*payout_fraction,2),"ts":time.time()})


def get_adapter_status():
    return dict(ADAPTER_STATUS)
