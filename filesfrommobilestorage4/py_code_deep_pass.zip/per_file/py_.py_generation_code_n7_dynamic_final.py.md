# File: py/.py/generation_code_n7_dynamic_final.py

**Extension:** .py

**Lines:** 690 | **Words:** 3223

## Keyword Hits

- SFBB: 0

- superperm: 76

- superpermutation: 76

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 1

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 85

- golden: 14

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: analysis_scripts, heapq, itertools, math, networkx, random, time

- From-imports: collections, layout_memory

- Classes (2): PermutationData, ProdigalResult

- Functions (21): calculate_overlap, generate_permutations, calculate_distance, hash_permutation, unhash_permutation, is_valid_permutation, calculate_golden_ratio_points, get_kmers, initialize_data, generate_permutations_on_demand, calculate_score, construct_superpermutation, main, __init__, __str__, __repr__, __init__, calculate_permutations, calculate_overlap_rate, __str__, __repr__


---


## Full Source


```text

import itertools
import random
import math
import time
import networkx as nx
from collections import deque, defaultdict
import heapq
import analysis_scripts
from layout_memory import LayoutMemory

# --- Constants ---
N = 7  # The value of n (number of symbols).
PRODIGAL_OVERLAP_THRESHOLD = 0.98  # Initial minimum overlap rate for "Prodigal Results"
PRODIGAL_MIN_LENGTH = 10 #Reduced
HYPOTHETICAL_PRODIGAL_OVERLAP_THRESHOLD = 0.90 #Reduced
HYPOTHETICAL_PRODIGAL_MIN_LENGTH = 7
HYPOTHETICAL_PRODIGAL_GENERATION_COUNT = 50 # Number of Hypothetical Prodigals to Generate
WINNER_THRESHOLD = 0.75  # Not directly used in scoring
LOSER_THRESHOLD = 0.25  # Not directly used in scoring
NUM_ITERATIONS = 10000  #  Set a large number; it will likely stop earlier
LAYOUT_K_VALUES = [N - 1, N - 2]  # k values for Layout Memory
DE_BRUIJN_K_VALUES = [N - 1, N - 2]  # k values for De Bruijn graph generation
RANDOM_SEED = 42  # For reproducibility.  CHANGE THIS FOR EACH RUN.

# --- Helper Functions --- (These are identical to the n=8 versions)
def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings."""
    max_overlap = 0
    for i in range(1, min(len(s1), len(s2)) + 1):
        if s1[-i:] == s2[:i]:
            max_overlap = i
    return max_overlap

def generate_permutations(n: int) -> list[tuple[int, ...]]:
    """Generates all permutations of 1 to n."""
    return list(itertools.permutations(range(1, n + 1)))

def calculate_distance(p1: str, p2: str, n: int) -> int:
    """Calculates distance (n-1 - overlap)."""
    return (n - 1) - max(calculate_overlap(p1, p2), calculate_overlap(p2, p1))

def hash_permutation(permutation: tuple) -> int:
    """Hashes a permutation tuple to a unique integer."""
    result = 0
    n = len(permutation)
    for i, val in enumerate(permutation):
        result += val * (n ** (n - 1 - i))
    return result

def unhash_permutation(hash_value: int, n: int) -> tuple:
    """Converts a hash value back to a permutation tuple."""
    permutation = []
    for i in range(n - 1, -1, -1):
        val = hash_value // (n ** i)
        permutation.append(val + 1)  # Adjust to be 1-indexed
        hash_value -= val * (n ** i)
    return tuple(permutation)

def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a given sequence is a valid permutation."""
    return len(set(perm)) == n and min(perm) == 1 and max(perm) == n

def calculate_golden_ratio_points(length: int, levels: int = 1) -> list[int]:
    """Calculates multiple levels of golden ratio points."""
    phi = (1 + math.sqrt(5)) / 2
    points = []
    for _ in range(levels):
        new_points = []
        if not points:
            new_points = [int(length / phi), int(length - length / phi)]
        else:
            for p in points:
                new_points.extend([int(p / phi), int(p - p / phi)])
                new_points.extend([int((length-p) / phi) + p, int(length - (length-p) / phi)])
        points.extend(new_points)
        points = sorted(list(set(points)))  # Remove duplicates and sort
    return points

def get_kmers(sequence: str, n: int, k: int) -> set[str]:
    """Extracts all k-mers from a sequence, given n and k."""
    kmers = set()
    seq_list = [int(x) for x in sequence]
    for i in range(len(sequence) - n + 1):
        perm = tuple(seq_list[i:i+n])
        if is_valid_permutation(perm, n):
            if i >= k:
                kmer = "".join(str(x) for x in seq_list[i-k:i])
                kmers.add(kmer)
    return kmers
# --- Data Structures --- (Same as n=8 version)

class PermutationData:
    def __init__(self, permutation: tuple, in_sample: bool = False, creation_method: str = ""):
        """Stores data associated with a single permutation."""
        self.hash: int = hash_permutation(permutation)
        self.permutation: tuple = permutation
        self.in_sample: bool = in_sample  # Will always be False
        self.used_count: int = 0
        self.prodigal_status: list[int] = []
        self.creation_method: str = creation_method
        self.batch_ids: list[int] = [] #Not used
        self.used_in_final: bool = False
        self.neighbors: set[int] = set()

    def __str__(self) -> str:
        return (f"PermutationData(hash={self.hash}, permutation={self.permutation}, used_count={self.used_count}, "
                f"prodigal_status={self.prodigal_status}, creation_method={self.creation_method})")

    def __repr__(self) -> str:
        return self.__str__()

class ProdigalResult:
    def __init__(self, sequence: str, result_id: int):
        """Represents a 'Prodigal Result'."""
        self.id: int = result_id
        self.sequence: str = sequence
        self.length: int = len(sequence)
        self.permutations: set[int] = set()  # Store hashes
        self.calculate_permutations()
        self.overlap_rate: float = self.calculate_overlap_rate()

    def calculate_permutations(self):
        """Calculates and stores the set of permutations."""
        n = N
        for i in range(len(self.sequence) - n + 1):
            perm = tuple(int(x) for x in self.sequence[i:i + n])
            if is_valid_permutation(perm, n):
                self.permutations.add(hash_permutation(perm))

    def calculate_overlap_rate(self) -> float:
        """Calculates the overlap rate."""
        n = N
        total_length = sum(len(str(p)) for p in [unhash_permutation(x,n) for x in self.permutations])
        overlap_length = total_length - len(self.sequence)
        max_possible_overlap = (len(self.permutations) - 1) * (n - 1)
        if max_possible_overlap == 0:
            return 0
        return overlap_length / max_possible_overlap

    def __str__(self) -> str:
        return (f"ProdigalResult(id={self.id}, length={self.length}, "
                f"overlap_rate={self.overlap_rate:.4f}, num_permutations={len(self.permutations)})")

    def __repr__(self) -> str:
        return self.__str__()
# --- Initialization Function ---
def initialize_data(initial_n7_prodigals: list[str], initial_winners: dict, initial_losers: dict) -> tuple:
    """Initializes the data structures for the algorithm.
        Modified for n=7, no initial superpermutation, loads initial prodigals.
    Args:
        initial_n7_prodigals (list[str]): A list of initial n=7 Prodigal Result strings.
        initial_winners (dict):  Initial Winner k-mers and weights.
        initial_losers (dict): Initial Loser k-mers and weights.

    Returns:
        tuple: (prodigal_results, winners, losers, meta_hierarchy, limbo_list, eput, next_prodigal_id)
    """
    prodigal_results = {}  # {prodigal_id: ProdigalResult object}
    winners = initial_winners  # {kmer: weight}
    losers = initial_losers  # {kmer: weight}
    meta_hierarchy = {}  # Track strategy effectiveness
    limbo_list = set()  # Set of permutation hashes.
    eput = {}  # The Enhanced Permutation Universe Tracker

    # Add initial n=7 prodigals
    next_prodigal_id = 0
    for prodigal in initial_n7_prodigals:
        prodigal_results[next_prodigal_id] = ProdigalResult(prodigal, next_prodigal_id)
        next_prodigal_id += 1

    return prodigal_results, winners, losers, meta_hierarchy, limbo_list, eput, next_prodigal_id

# --- On-Demand Permutation Generation ---
def generate_permutations_on_demand(prefix: str, suffix: str, prodigal_results: dict, winners: dict, losers: dict,
                                   n: int, eput: dict, limbo_list: set, min_overlap: int,
                                   hypothetical_prodigals: dict = None, laminate_graphs: list = None) -> set[int]:
    """Generates permutations on demand, extending a given prefix or suffix.
       Prioritizes "Prodigal" extensions, uses "Winners" and "Losers," and
       avoids already-used permutations and the "Limbo List."  Also uses laminates.

    Args:
        prefix (str): The prefix of the current superpermutation.
        suffix (str): The suffix of the current superpermutation.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        n (int): The value of n.
        eput (dict): The Enhanced Permutation Universe Tracker.
        limbo_list (set): The set of permutation hashes to avoid.
        min_overlap (int):  The minimum required overlap.
        hypothetical_prodigals (dict): Optional dictionary of Hypothetical Prodigals
        laminate_graphs (list): List of laminate graphs.

    Returns:
        set[int]: A set of *permutation hashes* that are potential extensions.
    """
    valid_permutations = set()

    # Prioritize Hypothetical Prodigal extensions
    if hypothetical_prodigals:
        for prodigal_id, prodigal in hypothetical_prodigals.items():
            if prefix and prodigal.sequence.startswith(prefix[-min_overlap:]):
                for i in range(len(prodigal.sequence) - (n - 1)):
                    perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                    if analysis_scripts.is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                         valid_permutations.add(hash_permutation(perm))
            if suffix and prodigal.sequence.endswith(suffix[:min_overlap]):
                for i in range(len(prodigal.sequence) - (n - 1)):
                    perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                    if analysis_scripts.is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                        valid_permutations.add(hash_permutation(perm))

    # Prioritize Prodigal extensions
    for prodigal_id, prodigal in prodigal_results.items():
        if prefix and prodigal.sequence.startswith(prefix[-min_overlap:]):
            for i in range(len(prodigal.sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                if analysis_scripts.is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                    valid_permutations.add(hash_permutation(perm))
        if suffix and prodigal.sequence.endswith(suffix[:min_overlap]):
            for i in range(len(prodigal.sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                if analysis_scripts.is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                    valid_permutations.add(hash_permutation(perm))


    # Filter based on Limbo List and Laminate
    filtered_permutations = set()
    for perm_hash in valid_permutations:
        perm = unhash_permutation(perm_hash, n)
        perm_str = "".join(str(x) for x in perm)
        is_in_limbo = False

        # Basic Loser check (using 5-mers and 6-mers for n=7)
        for k in [6, 5]:  # Check 6-mers and 5-mers
            for i in range(len(perm_str) - k + 1):
                kmer = perm_str[i:i+k]
                if kmer in limbo_list:
                    is_in_limbo = True
                    break
            if is_in_limbo:
                break
        
        if not is_in_limbo:
            valid_perm = False
            if laminate_graphs:
                for laminate in laminate_graphs:
                    if analysis_scripts.is_compatible(perm, laminate, n, n - 1):
                        valid_perm = True
                        break
                    elif analysis_scripts.is_compatible(perm, laminate, n, n - 2):
                        valid_perm = True
                        break
            else: #If no laminates, pass.
                valid_perm = True
            if valid_perm:
                filtered_permutations.add(perm_hash)

    return filtered_permutations

# --- Scoring Function ---
def calculate_score(current_superpermutation: str, permutation_hash: int, prodigal_results: dict,
                    winners: dict, losers: dict, layout_memory: LayoutMemory, n: int,
                    golden_ratio_points: list[int], hypothetical_prodigals:dict) -> float:
    """Calculates the score for adding a permutation (n=7 version)."""
    permutation = unhash_permutation(permutation_hash, n)
    permutation_string = "".join(str(x) for x in permutation)
    overlap = calculate_overlap(current_superpermutation, permutation_string)
    score = overlap * 5  # Base score based on overlap

    # Prodigal Result Bonus (very high)
    prodigal_bonus = 0
    for prodigal_id, prodigal in prodigal_results.items():
        if permutation_string in prodigal.sequence:
            prodigal_bonus += prodigal.length * 100  # Large bonus
            break

    #Hypothetical bonus
    hypothetical_bonus = 0
    if hypothetical_prodigals:
        for h_prodigal_id, h_prodigal in hypothetical_prodigals.items():
            if permutation_string in h_prodigal.sequence:
                hypothetical_bonus +=  h_prodigal.length * 25

    # Winner and Loser Bonus/Penalty (using Layout Memory)
    k_values = [n - 1, n - 2]
    layout_bonus = 0
    for k in k_values:
        if len(current_superpermutation) >= k:
            kmer_end = current_superpermutation[-k:]
            kmer_start = permutation_string[:k]
            layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, 1)

    # Golden Ratio Bonus (small, dynamic)
    golden_ratio_bonus = 0
    insertion_point = len(current_superpermutation)
    for point in golden_ratio_points:
        distance = abs(insertion_point - point)
        golden_ratio_bonus += math.exp(-distance / (len(current_superpermutation)/20))  # Smaller divisor = tighter

    # Loser Penalty (Veto)
    loser_penalty = 0
    for k in [6, 5]:  # Check 6-mers and 5-mers for n=7
        for i in range(len(permutation_string) - k + 1):
            kmer = permutation_string[i:i+k]
            loser_penalty += losers.get(kmer, 0) * 5 # Penalty for losers

    # Higher-Order Winners/Losers
    higher_order_bonus = 0
    for seq_length in [2, 3]:  # Check sequences of length 2 and 3
      if len(current_superpermutation) >= (n * seq_length):
        prev_seq = current_superpermutation[-(n*seq_length):]
        prev_perms = []
        for i in range(len(prev_seq) - n + 1):
            pp = tuple(int(x) for x in prev_seq[i:i+n])
            if is_valid_permutation(pp, n):
                prev_perms.append(hash_permutation(pp))
        if len(prev_perms) >= (seq_length -1):
            current_seq = tuple(prev_perms[-(seq_length - 1):] + [permutation_hash])
            current_seq_hash = hash(current_seq)
            higher_order_bonus += winners.get(current_seq_hash, 0) * 5
            loser_penalty += losers.get(current_seq_hash, 0) * 5

    score += prodigal_bonus + layout_bonus + golden_ratio_bonus + hypothetical_bonus- loser_penalty + higher_order_bonus

    return score
# --- Main Construction Function ---

def construct_superpermutation(initial_permutations: list, prodigal_results: dict, winners: dict, losers: dict,
                              layout_memory: LayoutMemory, meta_hierarchy: dict, limbo_list: set, n: int,
                              hypothetical_prodigals: dict) -> tuple[str, set[int]]:
    """Constructs a superpermutation using the dynamic prodigal approach (n=7 version).

    Args:
        initial_permutations (list):  Empty list
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        layout_memory (LayoutMemory): The LayoutMemory object.
        meta_hierarchy (dict): Dictionary for tracking strategy effectiveness.
        limbo_list (set): Set of permutation hashes to avoid.
        n (int): The value of n.
        hypothetical_prodigals (dict): "Hypothetical Prodigals" to use.

    Returns:
        tuple: (superpermutation string, set of used permutation hashes)
    """

    superpermutation = ""
    used_permutations = set()

    # Initialize with the longest "Prodigal Result" (should be the initial 5906)
    if prodigal_results:
        best_prodigal_key = max(prodigal_results, key=lambda k: prodigal_results[k].length)
        superpermutation = prodigal_results[best_prodigal_key].sequence
        used_permutations.update(prodigal_results[best_prodigal_key].permutations)
    else:
        #Should never reach here.
        superpermutation = "1234567" #Bare minimum to start.
        used_permutations.add(hash_permutation((1,2,3,4,5,6,7)))

    golden_ratio_points = calculate_golden_ratio_points(len(superpermutation), levels=3)
    #Create Laminates
    laminates = [analysis_scripts.create_laminate(prodigal_results[key].sequence, n, k) for key in prodigal_results for k in LAYOUT_K_VALUES]


    while True:  # Continue until no more additions can be made or 5906 is hit
        best_candidate = None
        best_score = -float('inf')
        best_candidate_string = ""

        # Find frontier k-mers
        prefix = superpermutation[:n - 1]
        suffix = superpermutation[-(n - 1):]

        # Generate candidates (very small set, focused on the frontier)
        candidates = generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, used_permutations, limbo_list, n - 1, hypothetical_prodigals, laminates)
        if not candidates:
            candidates = generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, used_permutations, limbo_list, n - 2, hypothetical_prodigals, laminates)
        if not candidates:
            # print("No candidates found. Stopping.")  # Keep for debugging
            break  # No more candidates can be added
        #Deterministic selection from candidates:
        scored_candidates = []
        for candidate_hash in candidates:
            score = calculate_score(superpermutation, candidate_hash, prodigal_results, winners, losers, layout_memory, n, golden_ratio_points, hypothetical_prodigals)
            scored_candidates.append((score, candidate_hash))
        
        best_candidate = None
        if scored_candidates:
            scored_candidates.sort(reverse=True, key=lambda item: item[0]) #Sort by score, DESCENDING
            best_candidate = scored_candidates[0][1] #Get the hash

        if best_candidate is not None:
            best_candidate_perm = unhash_permutation(best_candidate, n)
            overlap = calculate_overlap(superpermutation, "".join(str(x) for x in best_candidate_perm))
            superpermutation += "".join(str(x) for x in best_candidate_perm)[overlap:]  # Add to superpermutation
            used_permutations.add(best_candidate)

            # Update golden ratio points
            golden_ratio_points = calculate_golden_ratio_points(len(superpermutation))

            # Prodigal Result Check
            new_prodigals = analysis_scripts.find_prodigal_results(superpermutation, n, min_length=PRODIGAL_MIN_LENGTH, overlap_threshold=PRODIGAL_OVERLAP_THRESHOLD)  #Use current thresholds
            for prodigal_seq in new_prodigals:
                is_new = True
                for existing_prodigal_id, existing_prodigal in prodigal_results.items():
                    if prodigal_seq in existing_prodigal.sequence:
                        is_new = False
                        break
                if is_new:
                    new_id = len(prodigal_results) + 1
                    prodigal_results[new_id] = ProdigalResult(prodigal_seq, new_id)
                    # print(f"New Prodigal Result found: {prodigal_seq}")  # Keep for debugging
                    #Create and add laminates:
                    laminates.append(analysis_scripts.create_laminate(prodigal_seq, n, n-1))
                    laminates.append(analysis_scripts.create_laminate(prodigal_seq, n, n-2))

            # Update ePUT
            perm_hash = best_candidate
            perm_string = "".join(str(x) for x in best_candidate_perm)
            if perm_hash not in eput:  # Should always be true here
                eput[perm_hash] = PermutationData(best_candidate_perm, in_sample=False, creation_method="dynamic_generation")
            eput[perm_hash].used_count += 1
            eput[perm_hash].used_in_final = True
            # Update neighbors in ePUT (using consistent k values)
            for k in [n - 1, n - 2]:
                prefix = superpermutation[:k]
                suffix = superpermutation[-k:]
                prefix_perms = set()
                suffix_perms = set()
                for i in range(len(prefix) - n + 1):
                    p = tuple(int(x) for x in prefix[i:i+n])
                    if is_valid_permutation(p,n):
                        prefix_perms.add(hash_permutation(p))
                for i in range(len(suffix) - n + 1):
                    p = tuple(int(x) for x in suffix[i:i+n])
                    if is_valid_permutation(p,n):
                        suffix_perms.add(hash_permutation(p))

                for other_perm_hash in prefix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        # Add to layout memory if not exist
                        kmer1 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[-k:])
                        kmer2 = perm_string[:k]
                        layout_memory.update_distances(kmer1,kmer2, len(superpermutation) - i - len(prefix), "n7_dynamic")
                for other_perm_hash in suffix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        kmer1 = perm_string[-k:]
                        kmer2 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[:k])
                        layout_memory.update_distances(kmer1, kmer2, 1, "n7_dynamic")
        else:
            break  # If we get here, we are stuck

        if len(superpermutation) >= 5906: #If we reach the target, break.
            break

    return superpermutation, used_permutations

# --- Main Function ---
def main():
    """
    Main function to execute the Dynamic Prodigal Assembly algorithm for n=7.
    Generates multiple distinct 5906 superpermutations.
    """
    # File Paths
    initial_winners_losers_n7_file = "initial_winners_losers_n7.txt"
    prodigal_results_n7_file = "prodigal_results_n7.txt"
    distinct_superpermutations_file = "distinct_superpermutations_n7.txt"
    layout_memory_file = "layout_memory_n7.pkl"

    # Load Initial Data
    initial_winners, initial_losers = {}, {}
    try:
        with open(initial_winners_losers_n7_file, "r") as f:
            for line in f:
                kmer, w_type, weight = line.strip().split(",")
                if w_type == "winner":
                    initial_winners[kmer] = int(weight)
                else:
                    initial_losers[kmer] = int(weight)
    except FileNotFoundError:
        print("Initial Winners/Losers file not found. Starting with empty.")

    initial_n7_prodigals = []
    try:
        with open(prodigal_results_n7_file, "r") as f:
            initial_n7_prodigals = [line.strip() for line in f]
    except FileNotFoundError:
        print("Initial n=7 Prodigal Results file not found.  Starting with empty.")
        #In this case, we will create an empty file
        with open(prodigal_results_n7_file, "w") as f:
            pass
    # Load existing distinct superpermutations
    existing_superpermutations = set()
    try:
        with open(distinct_superpermutations_file, "r") as f:
            for line in f:
                existing_superpermutations.add(line.strip())
    except FileNotFoundError:
        print("No existing distinct superpermutations file found.")
        #Create File
        with open(distinct_superpermutations_file, "w") as f:
            pass

    # Initialize data structures
    prodigal_results, winners, losers, meta_hierarchy, limbo_list, eput, next_prodigal_id = initialize_data(
        "", initial_n7_prodigals, initial_winners, initial_losers
    )  # Start with an EMPTY string

    #Create Initial Laminate
    laminates = []
    for prodigal in initial_n7_prodigals:
        laminates.append(analysis_scripts.create_laminate(prodigal, N, N-1))
        laminates.append(analysis_scripts.create_laminate(prodigal, N, N-2))
    #If no initial, create blank laminate
    if not laminates:
        laminates = [nx.DiGraph()]
    
    # Load Layout memory
    layout_memory = LayoutMemory()
    try:
        layout_memory.load_from_file(layout_memory_file)
        print("Loaded LayoutMemory from file.")
    except FileNotFoundError:
        print("No existing LayoutMemory file found. Starting with a new one.")

    distinct_count = len(existing_superpermutations)
    run_count = 0

    # --- Main Iterative Loop ---
    while True: # Keep generating until a stopping criterion is met
        run_count += 1
        print(f"Starting run {run_count}...")
        start_time = time.time()

        # Set a new random seed for each run
        random.seed(RANDOM_SEED + run_count)  # Use a different seed each run

        # 1. Generate Hypothetical Prodigals
        hypothetical_prodigals = analysis_scripts.generate_hypothetical_prodigals(prodigal_results, winners, losers, N)
        print(f"  Generated {len(hypothetical_prodigals)} hypothetical prodigals.")

        # 2. Construct Superpermutation (Dynamic, Prodigal-Focused)
        superpermutation, used_permutations = construct_superpermutation([], prodigal_results, winners, losers, layout_memory, meta_hierarchy, limbo_list, N, hypothetical_prodigals)
        print(f"  Superpermutation length: {len(superpermutation)}")

        # 3. Analysis and Updates
        analysis_results = analysis_scripts.analyze_superpermutation(superpermutation, N)
        print(f"  Valid: {analysis_results['validity']}")
        print(f"  Overlap Distribution: {analysis_results['overlap_distribution']}")
        
        # Check for 5906 and distinctness
        if analysis_results['validity'] and len(superpermutation) == 5906:
            is_distinct = True
            for existing_sp in existing_superpermutations:
                if not analysis_scripts.is_cyclically_distinct(superpermutation, existing_sp):
                    is_distinct = False
                    break

            if is_distinct:
                print("  Found a *distinct* 5906 superpermutation!")
                distinct_count += 1
                existing_superpermutations.add(superpermutation)
                with open(distinct_superpermutations_file, "a") as f:  # Append
                    f.write(superpermutation + "\n")
                #Create and add laminates
                new_lam_1 = analysis_scripts.create_laminate(superpermutation, N, N-1)
                new_lam_2 = analysis_scripts.create_laminate(superpermutation, N, N-2)
                laminates.append(new_lam_1)
                laminates.append(new_lam_2)
            else:
                print("  Found a 5906 superpermutation, but it's a duplicate.")
        else:
            print("  Run did not produce a valid minimal superpermutation.")
            
        # Update "Winners" and "Losers" (using the new superpermutation)
        new_winners, new_losers = analysis_scripts.calculate_winners_losers([superpermutation], N, k=N-1)
        new_winners2, new_losers2 = analysis_scripts.calculate_winners_losers([superpermutation], N, k=N-2)

        for kmer, weight in new_winners.items():
            winners[kmer] = winners.get(kmer, 0) + weight
        for kmer, weight in new_losers.items():
            losers[kmer] = losers.get(kmer, 0) + weight
        for kmer, weight in new_winners2.items():
            winners[kmer] = winners.get(kmer, 0) + weight
        for kmer, weight in new_losers2.items():
            losers[kmer] = losers.get(kmer, 0) + weight

        # Higher-Order Winners/Losers
        new_seq_winners, new_seq_losers = analysis_scripts.calculate_sequence_winners_losers([superpermutation], N)
        for seq_hash, weight in new_seq_winners.items():
            if seq_hash in winners:
                winners[seq_hash] += weight
            else:
                winners[seq_hash] = weight
        for seq_hash, weight in new_seq_losers.items():
            if seq_hash in losers:
                losers[seq_hash] += weight
            else:
                losers[seq_hash] = weight

        # Add new losers to limbo list
        for kmer, weight in losers.items():
            limbo_list.add(kmer)  # Add to limbo list

        # Find and add new prodigal results (stricter criteria).
        new_prodigals = analysis_scripts.find_prodigal_results(superpermutation, N, min_length=PRODIGAL_MIN_LENGTH, overlap_threshold=PRODIGAL_OVERLAP_THRESHOLD)
        for prodigal_seq in new_prodigals:
            is_new = True
            for existing_prodigal_id, existing_prodigal in prodigal_results.items():
                if prodigal_seq in existing_prodigal.sequence:
                    is_new = False
                    break
            if is_new:
                prodigal_results[next_prodigal_id] = ProdigalResult(prodigal_seq, next_prodigal_id)
                next_prodigal_id += 1
                #Create and add laminate
                laminates.append(analysis_scripts.create_laminate(prodigal_seq, N, N-1))
                laminates.append(analysis_scripts.create_laminate(prodigal_seq, N, N-2))


        # Update ePUT (add all *used* permutations)
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perm_hash = hash_permutation(perm)
                if perm_hash not in eput:
                    eput[perm_hash] = PermutationData(perm, in_sample=False, creation_method="dynamic_generation") # Dynamic
                eput[perm_hash].used_count += 1
                eput[perm_hash].used_in_final = True  # Mark as used in this iteration's superpermutation
                # Update neighbors in ePUT (using consistent k values)
                if i > 0:
                    prev_perm = s_tuple[i-1:i-1+n]
                    if is_valid_permutation(prev_perm, n):
                         eput[perm_hash].neighbors.add(hash_permutation(prev_perm))
                if i < len(s_tuple) - n:
                    next_perm = s_tuple[i+1:i+1+n]
                    if is_valid_permutation(next_perm, n):
                        eput[perm_hash].neighbors.add(hash_permutation(next_perm))

        # Update Layout Memory
        layout_memory.add_sequence(superpermutation, N, N-1, f"run_{run_count}")  # Add the new superpermutation
        layout_memory.add_sequence(superpermutation, N, N-2, f"run_{run_count}")

        # Update "Meta-Hierarchy" (simplified for this example)
        meta_hierarchy.setdefault("run_lengths", []).append(len(superpermutation))
        meta_hierarchy.setdefault("prodigal_counts", []).append(len(prodigal_results))
        total_hypotheticals = len(hypothetical_prodigals)
        successful_hypotheticals = 0
        for h_id, h_prodigal in hypothetical_prodigals.items():
            if h_prodigal.sequence in superpermutation:
               successful_hypotheticals += 1
        success_rate = ( successful_hypotheticals / total_hypotheticals) if total_hypotheticals > 0 else 0
        meta_hierarchy.setdefault("hypothetical_success_rate",[]).append(success_rate)


        end_time = time.time()
        print(f"  Run {run_count} completed in {end_time - start_time:.2f} seconds.")
        print(f"  Distinct 5906 superpermutations found so far: {distinct_count}")


        #Stopping Criteria
        if len(superpermutation) == 5906:
            # Check for early stopping based on lack of new distinct solutions
            is_new_solution = True
            for existing_sp in existing_superpermutations:
                if not analysis_scripts.is_cyclically_distinct(superpermutation, existing_sp):
                    is_new_solution = False
                    break

            if not is_new_solution:
                meta_hierarchy["no_new_solutions_count"] = meta_hierarchy.get("no_new_solutions_count",0) + 1
                if meta_hierarchy["no_new_solutions_count"] >= 20:
                    print("No new distinct 5906 solutions found in 20 iterations. Stopping.")
                    break
            else:
                meta_hierarchy["no_new_solutions_count"] = 0  # Reset counter
        if run_count >= 100:
            break


    layout_memory.save_to_file(layout_memory_file)

if __name__ == "__main__":
    random.seed(RANDOM_SEED)
    main()

```