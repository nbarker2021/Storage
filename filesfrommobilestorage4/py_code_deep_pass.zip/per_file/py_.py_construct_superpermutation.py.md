# File: py/.py/construct_superpermutation.py

**Extension:** .py

**Lines:** 195 | **Words:** 981

## Keyword Hits

- SFBB: 0

- superperm: 15

- superpermutation: 15

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 26

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: json, logging, random

- From-imports: analysis_scripts_final, laminate_utils, utils

- Classes (0): (none)

- Functions (3): generate_completion_candidates, generate_permutations_on_demand, calculate_score


---


## Full Source


```text

construct_superpermutation.py

# construct_superpermutation.py
import random
import logging
import json
# From our other files:
from utils import calculate_overlap, hash_permutation, unhash_permutation, is_valid_permutation
from analysis_scripts_final import is_prodigal, identify_anti_prodigals, calculate_winners_losers
from laminate_utils import is_compatible

def generate_completion_candidates(current_superpermutation: str, missing_permutations: set[int],
                                    prodigal_results: dict, winners: dict, losers: dict,
                                    n: int, eput: dict, limbo_list: set, anti_laminates:list) -> set[int]:
    """Generates candidate permutations for the completion phase.
    Prioritizes extending the current superpermutation, and those that use missing permuations.
    """
    candidates = set()
    min_overlap = n - 3  # Consider overlaps of n-1, n-2, and n-3

    # 1. Prioritize permutations that *contain* missing permutations as substrings
    missing_perm_strings = set("".join(str(x) for x in unhash_permutation(h, n)) for h in missing_permutations)
    for missing_perm_str in missing_perm_strings:
        # Find existing permutations that could connect to this missing permutation.
        for prodigal_id in prodigal_results:
            prodigal = prodigal_results[prodigal_id]['sequence']
            # Check overlaps with the *entire* prodigal sequence
            overlap_start = calculate_overlap(prodigal, missing_perm_str)
            overlap_end = calculate_overlap(missing_perm_str, prodigal)

            # Generate extensions, but ONLY if there's sufficient overlap with a prodigal
            if overlap_start >= min_overlap:
                candidates.update(generate_permutations_on_demand(prodigal, missing_perm_str, prodigal_results, winners, losers, n, eput, limbo_list, overlap_start, anti_laminates))
            if overlap_end >= min_overlap:
                candidates.update(generate_permutations_on_demand(missing_perm_str, prodigal, prodigal_results, winners, losers, n, eput, limbo_list, overlap_end, anti_laminates))

    # 2. Extend the ends of the current superpermutation (if not enough candidates)
    if len(candidates) < 100:  #  Adjust threshold as needed
        prefix = current_superpermutation[:n - 1]
        suffix = current_superpermutation[-(n - 1):]
        candidates.update(generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, eput, limbo_list, min_overlap, anti_laminates))

    # 3. "Bridge" to the missing permutations (if still not enough candidates)
    if len(candidates) < 100: # Adjust threshold
        for missing_perm_hash in missing_permutations:
            missing_perm = unhash_permutation(missing_perm_hash, n)
            missing_perm_string = "".join(str(x) for x in missing_perm)
            for k in [n - 1, n - 2, n-3]: #Iterate over overlap lengths
                prefix = missing_perm_string[:k]
                suffix = missing_perm_string[-k:]
                candidates.update(generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, eput, limbo_list, k, anti_laminates))

    # 4. If *still* not enough candidates, use high-ranking "Winners" (very limited)
    if len(candidates) < 100 and winners:  # Adjust threshold
        top_winners = heapq.nlargest(10, winners.items(), key=lambda item: item[1])  # Limit the number
        for winner, _ in top_winners:
            candidates.update(generate_permutations_on_demand(winner[:n - 1], winner[-(n - 1):], prodigal_results, winners, losers, n, eput, limbo_list, n - 2, anti_laminates))


    #Filter, based on eput and limbolist:
    filtered_candidates = set()
    for perm_hash in candidates:
        if perm_hash not in eput and perm_hash not in limbo_list:
            filtered_candidates.add(perm_hash)

    #Return top results:
    scored_candidates = []
    for cand_hash in filtered_candidates:
        score = calculate_score(current_superpermutation, cand_hash, prodigal_results, winners, losers, LayoutMemory(), n, missing_permutations, eput)
        scored_candidates.append((score, cand_hash))

    best_candidates = heapq.nlargest(100, scored_candidates, key=lambda item: item[0])
    final_candidates = set(x[1] for x in best_candidates)
    return final_candidates
    

def generate_permutations_on_demand(prefix: str, suffix: str, prodigal_results: dict, winners: dict, losers: dict,
                                   n: int, eput: dict, limbo_list: set, min_overlap: int, anti_laminates: list) -> set[int]:
    """Generates permutations on demand, extending a given prefix or suffix.
        Prioritizes "Prodigal" extensions, uses "Winners" and "Losers," and
        avoids already-used permutations and the "Limbo List."  Also uses anti-laminates.

    Args:
        prefix (str): The prefix of the current superpermutation.
        suffix (str): The suffix of the current superpermutation.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        n (int): The value of n.
        eput (dict): The Enhanced Permutation Universe Tracker.
        limbo_list (set): The set of permutation hashes to avoid.
        min_overlap (int):  The minimum required overlap.
        anti_laminates (list): List of anti-laminate graphs.

    Returns:
        set[int]: A set of *permutation hashes* that are potential extensions.
    """
    valid_permutations = set()

    # Prioritize Prodigal extensions
    for prodigal_id, prodigal_data in prodigal_results.items():
        prodigal_sequence = prodigal_data['sequence']
        if prefix and prodigal_sequence.startswith(prefix[-min_overlap:]):
            for i in range(len(prodigal_sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal_sequence[i:i + n])
                if is_valid_permutation(perm, n):
                    valid_permutations.add(hash_permutation(perm))
        if suffix and prodigal_sequence.endswith(suffix[:min_overlap]):
            for i in range(len(prodigal_sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal_sequence[i:i + n])
                if is_valid_permutation(perm, n):
                    valid_permutations.add(hash_permutation(perm))

    # Filter based on Limbo List and Anti-Laminates
    filtered_permutations = set()
    for perm_hash in valid_permutations:
        perm = unhash_permutation(perm_hash, n)
        perm_str = "".join(str(x) for x in perm)
        is_in_limbo = False

        # Basic Loser check (using n-1 and n-2 mers)
        for k in [n - 1, n - 2]:
            for i in range(len(perm_str) - k + 1):
                kmer = perm_str[i:i+k]
                if kmer in limbo_list:
                    is_in_limbo = True
                    break
            if is_in_limbo:
                break
        
        valid_perm = True
        if not is_in_limbo:
          for anti_laminate in anti_laminates:
            if not is_compatible(perm, anti_laminate, n, n-1):
                valid_perm = False
                break
            if not is_compatible(perm, anti_laminate, n, n-2):
                valid_perm = False
                break
        if valid_perm:
            filtered_permutations.add(perm_hash)

    return filtered_permutations


def calculate_score(current_superpermutation, permutation_hash, prodigal_results, winners, losers, layout_memory, n, missing_permutations, eput):
    """Calculates the score for adding a permutation.

    The score combines several factors:
    1. Overlap with the current superpermutation.
    2. Bonus for covering a missing permutation.
    3. Layout score (from LayoutMemory).
    4. Prodigal bonus.
    5. Winner/loser bonus/penalty.
    6. Anti-laminate penalty.
    7. Lookahead bonus.
    """

    permutation = unhash_permutation(permutation_hash, n)
    permutation_string = "".join(str(x) for x in permutation)
    overlap = calculate_overlap(current_superpermutation, permutation_string)

    score = overlap * 5  # Base score (adjust weight)

    if permutation_hash in missing_permutations:
        score += 1000  # Bonus for covering missing permutation (adjust weight)

    # Layout score
    k = n - 1
    if current_superpermutation: # Make sure it is not empty
        last_k_minus_1 = tuple(int(digit) for digit in current_superpermutation[-k:])
        kmer2 = tuple(int(digit) for digit in permutation_string[:k])
        score += layout_memory.get_layout_score(last_k_minus_1, kmer2) * 2  # Adjust weight

    # Prodigal bonus (if applicable)
    if str(permutation_hash) in prodigal_results:
        score += 500  # Adjust weight

    # Winner/loser bonus/penalty
    score += winners.get("".join(map(str,permutation)), 0)  # Using joined string for key
    score -= losers.get("".join(map(str,permutation)), 0)

    # Anti-laminate penalty (Not implemented yet)
    # score -= anti_laminate_penalty(permutation, anti_laminates)

    # Lookahead bonus (simplified)
    lookahead_bonus = 0
    for i in range(1, n + 1):
      lookahead_perm = permutation + (i,)
      if is_valid_permutation(lookahead_perm, n + 1):
        lookahead_kmer = "".join(map(str,lookahead_perm[-(n-1):]))
        lookahead_bonus += winners.get(lookahead_kmer,0) # Add winner bonus if its a winner.
    score += lookahead_bonus * 0.5 #Smaller weight.

    return score

```