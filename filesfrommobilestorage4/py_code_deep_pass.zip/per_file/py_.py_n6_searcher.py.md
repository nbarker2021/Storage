# File: py/.py/n6_searcher.py

**Extension:** .py

**Lines:** 280 | **Words:** 1241

## Keyword Hits

- SFBB: 0

- superperm: 22

- superpermutation: 19

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 6

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: itertools, logging, multiprocessing, random, time

- From-imports: analysis_scripts_final, laminate_utils, utils

- Classes (0): (none)

- Functions (9): generate_constrained_candidate, calculate_cell_winners_losers, bouncing_batch_test_n6, worker_task_n6, main, all_cell_coords, get_neighboring_cells, is_fully_compatible, backtrack


---


## Full Source


```text

# n6_searcher.py

import random
import logging
import multiprocessing
import time
import itertools
from utils import setup_logging, normalize_sequence, compute_checksum, generate_permutations, is_valid_permutation, calculate_overlap, hash_permutation, unhash_permutation
from analysis_scripts_final import calculate_winners_losers, identify_anti_prodigals, is_prodigal,  calculate_sequence_winners_losers, find_prodigal_results
from laminate_utils import create_n7_constraint_laminate, is_compatible, create_anti_laminate, update_laminate, merge_laminates

# Constants for n=6 search
TARGET_LENGTH = 871
N = 6
GRID_DIMENSIONS = (2,) * N  # Bouncing Batch grid
INITIAL_SEED = 42
MAX_ATTEMPTS = 1000  #Limit per worker
K_VALUE = 5

def generate_constrained_candidate(n, target_length, constraint_laminate, anti_laminates, winners, losers, seed):
    """Generates a candidate superpermutation of the target length, respecting laminates.
       Uses a backtracking search.
    """
    random.seed(seed)
    all_permutations = generate_permutations(n)
    random.shuffle(all_permutations)

    superpermutation = []
    current_length = 0

    #Helper function to check compatibility.
    def is_fully_compatible(perm, lam, anti_lams):
      for laminate in lam:
        if not is_compatible(perm, laminate, n, n-1):
            return False
        if not is_compatible(perm, laminate, n, n-2):
            return False
      for anti_laminate in anti_lams:
        if not is_compatible(perm, anti_laminate, n, n-1):
            return False
        if not is_compatible(perm, anti_laminate, n, n-2):
          return False
      return True

    def backtrack(current_permutation, current_length):
        nonlocal superpermutation
        if current_length == target_length:
            superperm_str = "".join(map(str, current_permutation))
            if verify_permutation_coverage(superperm_str, n):
                superpermutation = superperm_str
                return True  # Found a solution
            else:
                return False

        prefix = "".join(map(str,current_permutation[-(n-1):]))
        for perm in all_permutations:
            perm_tuple = tuple(perm)
            if is_fully_compatible(perm_tuple,[constraint_laminate], anti_laminates):
                overlap = calculate_overlap(prefix, "".join(map(str,perm_tuple)))
                if overlap > 0:
                    new_superpermutation = current_permutation + list(str(x) for x in perm_tuple[overlap:])
                    if len(new_superpermutation) <= target_length: #Prune
                        if backtrack(new_superpermutation, len(new_superpermutation)):
                            return True  # Solution found
        return False

    # Start with a random *compatible* permutation
    for perm in all_permutations:
        if is_fully_compatible(perm,[constraint_laminate], anti_laminates):
            if backtrack(list(str(x) for x in perm), len(perm)):
                return superpermutation
            break #If it cant find it with the first, it wont find it.
    return None

def calculate_cell_winners_losers(hypothetical_superpermutation, cell_permutations, n, k=None):
    """Calculates winners and losers based on a superpermutation and a cell's permutations."""
    if k is None:
        k = n - 1

    winners = {}
    losers = {}

    # Convert hypothetical superpermutation to a list of integers
    s_list = [int(x) for x in hypothetical_superpermutation]

    for i in range(len(s_list) - n + 1):
        perm = tuple(s_list[i:i+n])
        if is_valid_permutation(perm, n):
            # Check if this permutation belongs to the current cell
            if hash_permutation(perm) in cell_permutations:  # Use efficient hash lookup
                if i >= k:
                    kmer = tuple(s_list[i-k:i])
                    kmer_str = "".join(map(str,kmer))
                    # Simplified: Just count occurrences
                    winners[kmer_str] = winners.get(kmer_str, 0) + 1
                    # Could add more sophisticated weighting here,

    return winners, losers

def bouncing_batch_test_n6(candidates, n, grid_dimensions, winners, losers, anti_laminates, cell_coords, laminate, anti_laminate):
  """Simplified Bouncing Batch test for the n=6 search."""
  all_permutations = generate_permutations(n)
  cell_permutations = {}  # {cell_coords: set(permutation_hashes)}
  for perm in all_permutations:
    cell = assign_permutation_to_cell(perm, n, grid_dimensions)
    if cell not in cell_permutations:
        cell_permutations[cell] = set()
    cell_permutations[cell].add(hash_permutation(perm))

  # Initialize local winners, losers
  new_winners = {}
  new_losers = {}
  new_anti_prodigals = []

  #Process the specific cell only
  for candidate in candidates:
    cell_winners, cell_losers = calculate_cell_winners_losers(candidate, cell_permutations[cell_coords], n)

    # Update local winners and losers
    for kmer, count in cell_winners.items():
        new_winners[kmer] = new_winners.get(kmer, 0) + count
    for kmer, count in cell_losers.items():
        new_losers[kmer] = new_losers.get(kmer, 0) - count  # Losers are *negative*

    # Identify anti-prodigals within this candidate
    new_anti_prodigals.extend(identify_anti_prodigals([candidate], n, 5, 0.8, winners, losers, 2))  # Example Thresholds

    #Update Laminates
    laminate = update_laminate(laminate, [candidate], n, n-1, "positive")
    laminate = update_laminate(laminate, [candidate], n, n-2, "positive")

  anti_laminate = update_laminate(anti_laminate, new_anti_prodigals, n, n-1, "negative")
  anti_laminate = update_laminate(anti_laminate, new_anti_prodigals, n, n-2, "negative")
  #No longer returning is_valid or length, we do that in the worker task.
  return new_winners, new_losers, new_anti_prodigals, laminate, anti_laminate

def worker_task_n6(args):
    """Worker task for n=6 search."""
    seed, n, target_length, constraint_laminate, anti_laminates, winners, losers, num_candidates, cell_coords, laminate, anti_laminate = args #Added cell, and the two lams

    candidates = []
    for _ in range(num_candidates):
        candidate = generate_constrained_candidate(n, target_length, [constraint_laminate, laminate], anti_laminates, winners, losers, seed)
        if candidate:
          candidates.append(candidate)
        seed += 1 # Increment seed for next candidate.


    if candidates:
        new_winners, new_losers, new_anti_prodigals, laminate, anti_laminate = bouncing_batch_test_n6(candidates, n, winners, losers, anti_laminates, cell_coords, laminate, anti_laminate) #Pass in data
        valid_list = []
        length_list = []
        for candidate in candidates:
          is_valid_result = verify_permutation_coverage(candidate, n)
          length_result = len(candidate)
          valid_list.append(is_valid_result)
          length_list.append(length_result)
          #Immediately save if we have a winner.
          if is_valid_result and length_result == TARGET_LENGTH:
            normalized_candidate = normalize_sequence(candidate)
            checksum = compute_checksum(normalized_candidate)
            print(f"Found valid n=6 superpermutation of length 871!  Checksum: {checksum}")
            with open("found_871_superpermutation.txt", "w") as f:  # Save it!
                f.write(normalized_candidate)
            exit() # Exit
        return valid_list, length_list, new_winners, new_losers, new_anti_prodigals, candidates, cell_coords, laminate, anti_laminate #Return candidates too
    else:
        return [], [], {}, {}, [], [], cell_coords, laminate, anti_laminate

def main():
   #Setup
   setup_logging()
   random.seed(INITIAL_SEED) # Use a constant, known seed.
   #Load existing data.

    # --- Load Initial Data ---
   winners, losers = {}, {}
   try:
       with open("winners_losers_data_n8.txt", "r") as f: #Use n=8 data, as that is most complete.
           for line in f:
               kmer, weight = line.strip().split(",")
               if float(weight) > 0:
                   winners[kmer] = int(weight)
               else:
                   losers[kmer] = int(weight)
   except FileNotFoundError:
       print("Initial Winners/Losers file not found. Starting with empty.")

   #Create n=6 constraint Laminate
   constraint_laminate = None
   try:
       with open("best_superpermutation_n6.txt", "r") as f: # You might need to create this file manually.
           best_n6 = f.read().strip()
           constraint_laminate = create_n7_constraint_laminate(best_n6, N, N-1)  # Use create_n7...
           constraint_laminate_2 = create_n7_constraint_laminate(best_n6, N, N-2)
   except FileNotFoundError:
       print("Error: Could not find n=6 file to make constraint laminate")
       return

   anti_laminates = []
   num_processes = multiprocessing.cpu_count()  # Use all available cores

    #Initialize the laminates and anti
   laminates = {}
   anti_laminates = {}
   grid_dimensions = (2,)*N
   for cell_coords in all_cell_coords(grid_dimensions):
      laminates[cell_coords] = nx.DiGraph()
      anti_laminates[cell_coords] = nx.DiGraph()

   with multiprocessing.Pool(processes=num_processes) as pool:
        args_list = []
        seed = INITIAL_SEED
        for i in range(1000):  # Example: Try many batches of candidates
            for cell_coords in all_cell_coords(grid_dimensions): #All cells.
              args_list.append((seed, N, TARGET_LENGTH, [constraint_laminate, constraint_laminate_2], anti_laminates[cell_coords], winners, losers, 5, cell_coords, laminates[cell_coords], anti_laminates[cell_coords])) # Pass all to worker.  5 attempts.
              seed += 1

            results = pool.map(worker_task_n6, args_list)
            args_list = [] #Clear

            # Process results
            for valid_list, length_list, new_winners, new_losers, new_anti_prodigals, candidates, cell_coords, new_laminate, new_anti_laminate in results:
                for i in range(len(valid_list)):
                    if valid_list[i] and length_list[i] == TARGET_LENGTH:
                        normalized_candidate = normalize_sequence(candidates[i])
                        checksum = compute_checksum(normalized_candidate)
                        print(f"Found valid n=6 superpermutation of length 871!  Checksum: {checksum}")
                        with open("found_871_superpermutation.txt", "w") as f:  # Save it!
                            f.write(normalized_candidate)
                        return # Exit

                # Update  winners/losers (simplified)
                for kmer, count in new_winners.items():
                    winners[kmer] = winners.get(kmer, 0) + count
                for kmer, count in new_losers.items():
                    losers[kmer] = losers.get(kmer, 0) + count

                # Update anti-laminates, specific to each cell:
                if new_anti_prodigals:
                  anti_laminates[cell_coords] = update_laminate(anti_laminates[cell_coords], new_anti_prodigals, N, N-1, "negative")
                  anti_laminates[cell_coords] = update_laminate(anti_laminates[cell_coords], new_anti_prodigals, N, N-2, "negative")
                laminates[cell_coords] = new_laminate

            # "Bounce" the laminates (both positive and negative)
            new_laminates = {}
            new_anti_laminates = {}
            for cell_coords in laminates: #all cells
                neighbor_coords = get_neighboring_cells(cell_coords, GRID_DIMENSIONS) #Need to get the neighbors
                neighbor_laminates = [laminates[coords] for coords in neighbor_coords if coords in laminates] # Get all the neightbor laminates
                neighbor_anti_laminates = [anti_laminates[coords] for coords in neighbor_coords if coords in anti_laminates]

                # Merge with neighbors
                new_laminates[cell_coords] = merge_laminates(neighbor_laminates + [laminates[cell_coords]], method="intersection")  # Include self
                new_anti_laminates[cell_coords] = merge_laminates(neighbor_anti_laminates + [anti_laminates[cell_coords]], method="union")  # Include self

            laminates = new_laminates #Update for next loop
            anti_laminates = new_anti_laminates

   logging.info("n=6 search completed. No 871-length superpermutation found.")

#Helper function
def all_cell_coords(grid_dimensions):
  # Use the global variable, since this is n=6 specific.
  ranges = [range(2) for _ in range(N)]
  return list(itertools.product(*ranges))

#Helper function
def get_neighboring_cells(cell_coords, grid_dimensions):
    """Gets the coordinates of neighboring cells in the grid."""
    neighbors = []
    for i in range(len(cell_coords)):
        for delta in [-1, 1]:
            neighbor_coords = list(cell_coords)
            neighbor_coords[i] = (neighbor_coords[i] + delta) % grid_dimensions[i]  # Wrap around
            neighbors.append(tuple(neighbor_coords))
    return neighbors

if __name__ == "__main__":
    main()

```