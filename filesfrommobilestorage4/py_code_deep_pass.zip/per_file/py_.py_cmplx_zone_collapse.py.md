# File: py/.py/cmplx_zone_collapse.py

**Extension:** .py

**Lines:** 41 | **Words:** 199

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMRecursiveZoneCollapse

- Functions (5): __init__, _compute_center, collapse_shells, _group_by_shell, _distance


---


## Full Source


```text


from typing import List, Tuple, Dict
import math

class AGRMRecursiveZoneCollapse:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()
        self.last_zones: List[int] = []

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def collapse_shells(self, path: List[int], collapse_rate: float = 0.25, min_zone_size: int = 5) -> List[int]:
        print("[ZoneCollapse] Initiating recursive shell reduction...")
        zones = self._group_by_shell(path)
        self.last_zones = [len(z) for z in zones]

        pruned_path = []
        for i, zone in enumerate(zones):
            keep_count = max(min_zone_size, int(len(zone) * (1 - collapse_rate)))
            pruned_zone = zone[:keep_count]
            print(f"[ZoneCollapse] Shell {i}: kept {keep_count}/{len(zone)}")
            pruned_path.extend(pruned_zone)
        return pruned_path

    def _group_by_shell(self, path: List[int], num_shells: int = 5) -> List[List[int]]:
        distances = [(node, self._distance(self.center, self.nodes[node])) for node in path]
        max_d = max(d for _, d in distances) + 1e-5
        shell_map = [[] for _ in range(num_shells)]

        for node, dist in distances:
            shell_index = min(num_shells - 1, int((dist / max_d) * num_shells))
            shell_map[shell_index].append(node)

        return shell_map

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])


```