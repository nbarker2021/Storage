# File: py/.py/analysis_scripts_2.0.py

**Extension:** .py

**Lines:** 681 | **Words:** 3035

## Keyword Hits

- SFBB: 0

- superperm: 76

- superpermutation: 56

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 8

- debruijn: 2

- beam: 0

- orchestrator: 0

- hash: 46

- golden: 4

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

import itertools
import math
import networkx as nx
from collections import deque, defaultdict
import heapq
import random

def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings.

    Args:
        s1 (str): The first string.
        s2 (str): The second string.

    Returns:
        int: The length of the maximum overlap. Returns 0 if there is no overlap.
    """
    max_overlap = 0
    for i in range(1, min(len(s1), len(s2)) + 1):
        if s1[-i:] == s2[:i]:
            max_overlap = i
    return max_overlap

def calculate_distance(p1: str, p2: str, n: int) -> int:
    """Calculates distance (n-1 - overlap) between two permutation strings.

    Args:
        p1: First permutation string.
        p2: Second permutation string.
        n: The value of n.

    Returns: The distance
    """
    return (n - 1) - max(calculate_overlap(p1, p2), calculate_overlap(p2, p1))

def hash_permutation(permutation: tuple) -> int:
    """Hashes a permutation tuple to a unique integer.

    Args:
        permutation: The permutation tuple (e.g., (1, 2, 3, 4, 5, 6, 7, 8)).

    Returns:
        A unique integer hash value.
    """
    result = 0
    n = len(permutation)
    for i, val in enumerate(permutation):
        result += val * (n ** (n - 1 - i))
    return result

def unhash_permutation(hash_value: int, n: int) -> tuple:
    """Converts a hash value back to a permutation tuple.

    Args:
        hash_value: The integer hash value.
        n: The value of n.

    Returns:
        The corresponding permutation tuple.
    """
    permutation = []
    for i in range(n - 1, -1, -1):
        val = hash_value // (n ** i)
        permutation.append(val + 1)  # Adjust to be 1-indexed
        hash_value -= val * (n ** i)
    return tuple(permutation)

def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a given sequence is a valid permutation.

    Args:
        perm: The sequence (tuple of integers).
        n: The value of n.

    Returns:
        True if the sequence is a valid permutation, False otherwise.
    """
    return len(set(perm)) == n and min(perm) == 1 and max(perm) == n

def get_kmers(sequence: str, n: int, k: int) -> set[str]:
    """Extracts all k-mers from a sequence of digits, ensuring they form valid permutations.

    Args:
        sequence: The input sequence (string of digits).
        n: The value of n.
        k: The length of the k-mers to extract.

    Returns:
        A set of k-mer strings.
    """
    kmers = set()
    seq_list = [int(x) for x in sequence]  # Ensure sequence is treated as digits
    for i in range(len(sequence) - n + 1):
        perm = tuple(seq_list[i:i+n])
        if is_valid_permutation(perm, n):
            if i >= k:
                kmer = "".join(str(x) for x in seq_list[i-k:i])
                kmers.add(kmer)
    return kmers

def calculate_golden_ratio_points(length: int, levels: int = 1) -> list[int]:
    """Calculates multiple levels of golden ratio points within a sequence.

    Args:
        length (int): The total length of the sequence.
        levels (int): The number of recursive divisions to perform.

    Returns:
        list: A sorted list of unique golden ratio points (integers).
    """
    phi = (1 + math.sqrt(5)) / 2
    points = []
    for _ in range(levels):
        new_points = []
        if not points:
            new_points = [int(length / phi), int(length - length / phi)]
        else:
            for p in points:
                new_points.extend([int(p / phi), int(p - p / phi)])
                new_points.extend([int((length-p) / phi) + p, int(length - (length-p) / phi)])
        points.extend(new_points)
        points = sorted(list(set(points)))  # Remove duplicates and sort
    return points
    
    # --- Superpermutation Analysis ---

def analyze_superpermutation(superpermutation: str, n: int) -> dict:
    """Analyzes a given superpermutation and provides statistics.

    Args:
        superpermutation (str): The superpermutation string.
        n (int): The value of n (number of symbols).

    Returns:
        dict: A dictionary containing:
            - length: The length of the superpermutation.
            - validity: True if valid, False otherwise.
            - missing_permutations: A list of missing permutations (empty if valid).
            - overlap_distribution: A dictionary showing counts of each overlap length.
            - average_overlap: The average overlap between consecutive permutations.
    """
    permutations = set(itertools.permutations(range(1, n + 1)))
    s_tuple = tuple(int(x) for x in superpermutation)
    found_permutations = set()
    missing_permutations = []
    overlap_distribution = {}

    total_overlap = 0

    for i in range(len(s_tuple) - n + 1):
        perm = s_tuple[i:i+n]
        if is_valid_permutation(perm, n):  # Valid
            found_permutations.add(tuple(perm))  # Use tuples for set
            if i > 0:
                overlap = calculate_overlap("".join(str(x) for x in s_tuple[i-n:i]), "".join(str(x) for x in perm))
                total_overlap += overlap
                overlap_distribution[overlap] = overlap_distribution.get(overlap, 0) + 1

    missing_permutations = list(permutations - found_permutations)
    validity = len(missing_permutations) == 0
    average_overlap = total_overlap / (len(found_permutations) - 1) if len(found_permutations) > 1 else 0

    return {
        "length": len(superpermutation),
        "validity": validity,
        "missing_permutations": missing_permutations,
        "overlap_distribution": overlap_distribution,
        "average_overlap": average_overlap,
    }

# --- Prodigal Result Identification ---

def is_prodigal(sequence: str, permutations_in_sequence: list[tuple[int]], n: int, min_length: int, overlap_threshold: float) -> bool:
    """Checks if a sequence is a 'Prodigal Result'.

    Args:
        sequence (str): The sequence of digits to check.
        permutations_in_sequence (list):  A list of *tuples* representing the permutations contained in the sequence.
        n (int): The value of n.
        min_length (int): The minimum number of permutations for a "Prodigal Result."
        overlap_threshold (float): The minimum overlap rate (0 to 1).

    Returns:
        bool: True if the sequence is a "Prodigal Result," False otherwise.
    """
    if len(permutations_in_sequence) < min_length:
        return False

    total_length = sum(len(str(p)) for p in permutations_in_sequence)
    overlap_length = total_length - len(sequence)
    max_possible_overlap = (len(permutations_in_sequence) - 1) * (n - 1)

    if max_possible_overlap == 0:
        return False
    return (overlap_length / max_possible_overlap) >= overlap_threshold

def find_prodigal_results(superpermutation: str, n: int, min_length: int = None, overlap_threshold: float = 0.98) -> list[str]:
    """Identifies and returns a list of prodigal results within a given superpermutation.

    Args:
        superpermutation (str): The superpermutation string.
        n (int): The value of n.
        min_length (int): Minimum number of permutations in a prodigal result. Defaults to n-1
        overlap_threshold (float): Minimum overlap percentage. Defaults to 0.98

    Returns:
        list: A list of "Prodigal Result" sequences (strings).
    """
    prodigal_results = []
    superperm_list = [int(x) for x in superpermutation]  # Convert to list of integers
    if min_length is None:
        min_length = n-1

    for length in range(n * min_length, len(superpermutation) + 1):  # Iterate through possible lengths
        for i in range(len(superpermutation) - length + 1):  # Iterate through starting positions
            subsequence = tuple(superperm_list[i:i+length])  # Get the subsequence as a tuple
            permutations_in_subsequence = set()
            for j in range(len(subsequence) - n + 1):
                perm = subsequence[j:j+n]
                if is_valid_permutation(perm, n):  # Valid permutation
                    permutations_in_subsequence.add(tuple(perm))  # Use tuples

            if is_prodigal(subsequence, list(permutations_in_subsequence), n, min_length, overlap_threshold):
                prodigal_results.append("".join(str(x) for x in subsequence))  # Store as string
    return prodigal_results

# --- Anti-Prodigal Identification ---
def identify_anti_prodigals(superpermutations: list[str], n: int, k: int, overlap_threshold: float) -> set[str]:
    """Identifies and returns a list of 'anti-prodigal' k-mers.

    Args:
        superpermutations (list[str]): A list of superpermutation strings.
        n (int): The value of n.
        k (int): The length of k-mers.
        overlap_threshold (float): The *maximum* overlap allowed for an anti-prodigal

    Returns:
        set: A set of 'anti-prodigal' k-mers (strings).
    """
    anti_prodigals = set()
    for superpermutation in superpermutations:
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n):  # Valid
                if i > k:
                    kmer = "".join(str(x) for x in s_tuple[i-k:i])
                    overlap = calculate_overlap("".join(str(x) for x in s_tuple[i-k:i]), "".join(str(x) for x in perm))
                    if overlap < ( (n-1) * overlap_threshold):
                        anti_prodigals.add(kmer)
    return anti_prodigals
    
    # --- De Bruijn Graph Functions ---

def build_debruijn_graph(n: int, k: int, permutations=None, superpermutation=None) -> nx.DiGraph:
    """Builds a De Bruijn graph of order k for permutations of n symbols.

    Args:
        n: The number of symbols (e.g., 8 for n=8).
        k: The order of the De Bruijn graph (k-mers).
        permutations: (Optional) A list of permutation tuples.  If provided,
                      the graph is built ONLY from these permutations.
        superpermutation: (Optional) A superpermutation string. If provided,
                          the graph is built from the k-mers in this string.
                          Must provide one, and only one, of the two.

    Returns:
        A networkx.DiGraph representing the De Bruijn graph.
    """

    if (permutations is None and superpermutation is None) or (permutations is not None and superpermutation is not None):
        raise ValueError("Must provide either 'permutations' or 'superpermutation', but not both.")

    graph = nx.DiGraph()

    if permutations:
      for perm in permutations:
          perm_str = "".join(str(x) for x in perm)
          for i in range(len(perm_str) - k + 1):
              kmer1 = perm_str[i:i + k - 1]
              kmer2 = perm_str[i + 1:i + k]
              if len(kmer1) == k - 1 and len(kmer2) == k-1: #Should always be true
                graph.add_edge(kmer1, kmer2, weight=calculate_overlap(kmer1, kmer2))
    else: #Use superpermutation
        s_list = [int(x) for x in superpermutation]
        for i in range(len(s_list) - n + 1):
            perm = tuple(s_list[i:i+n])
            if is_valid_permutation(perm, n):
                #Valid permutation.
                if i >= k:
                  kmer1 = "".join(str(x) for x in s_list[i-k:i])
                  kmer2 = "".join(str(x) for x in s_list[i-k+1: i+1])
                  if len(kmer1) == k - 1 and len(kmer2) == k - 1:
                    graph.add_edge(kmer1, kmer2, weight = calculate_overlap(kmer1,kmer2))
    return graph

def add_weights_to_debruijn(graph: nx.DiGraph, winners: dict, losers: dict):
    """Adds 'winner_weight' and 'loser_weight' attributes to the edges of a De Bruijn graph.

    Args:
        graph: The De Bruijn graph (networkx.DiGraph).
        winners: A dictionary of Winner k-mers and their weights.
        losers: A dictionary of Loser k-mers and their weights.
    """

    for u, v, data in graph.edges(data=True):
        kmer = u[1:] + v[-1]  # Reconstruct the k-mer from the edge
        data['winner_weight'] = winners.get(kmer, 0)
        data['loser_weight'] = losers.get(kmer, 0)

def find_cycles(graph: nx.DiGraph) -> list[list[str]]:
    """Finds cycles in the De Bruijn graph using a simple DFS approach."""
    cycles = []
    visited = set()

    def dfs(node, path):
        visited.add(node)
        path.append(node)

        for neighbor in graph.neighbors(node):
            if neighbor == path[0] and len(path) > 1:  # Found a cycle
                cycles.append(path.copy())
            elif neighbor not in visited:
                dfs(neighbor, path)

        path.pop()
        visited.remove(node) #Correctly remove node

    for node in graph.nodes:
        if node not in visited:
            dfs(node, [])
    return cycles

def find_high_weight_paths(graph: nx.DiGraph, start_node: str, length_limit: int) -> list[list[str]]:
    """
    Finds high-weight paths in the De Bruijn graph starting from a given node.
    """
    best_paths = []
    best_score = -float('inf')

    def dfs(current_node, current_path, current_score):
        nonlocal best_score
        nonlocal best_paths

        if len(current_path) > length_limit:
            return

        current_score_adj = current_score
        if len(current_path) > 1:
            current_score_adj = current_score / (len(current_path)-1) #Average

        if current_score_adj > best_score:
            best_score = current_score_adj
            best_paths = [current_path.copy()]  # New best path
        elif current_score_adj == best_score and len(current_path) > 1: #Dont include starting nodes
            best_paths.append(current_path.copy())  # Add to list of best paths

        for neighbor in graph.neighbors(current_node):
            edge_data = graph.get_edge_data(current_node, neighbor)
            new_score = current_score + edge_data.get('weight', 0) + edge_data.get('winner_weight', 0) - edge_data.get('loser_weight', 0)
            dfs(neighbor, current_path + [neighbor], new_score)

    dfs(start_node, [start_node], 0)
    return best_paths

# --- Hypothetical Prodigal Generation ---
def generate_permutations_on_demand_hypothetical(current_sequence: str, kmer: str, n: int, k: int) -> set[int]:
    """Generates candidate permutations for hypothetical prodigals. More restrictive.

    Args:
        current_sequence (str): The sequence currently being built
        kmer (str): The k-mer to extend (either prefix or suffix).
        n (int): value of n
        k (int): The k value

    Returns:
        set[int]: A set of permutation *hashes*.
    """
    valid_permutations = set()
    all_perms = generate_permutations(n)  # Get *all* permutations
    for perm in all_perms:
        perm_str = "".join(str(x) for x in perm)
        if kmer == perm_str[:k] or kmer == perm_str[-k:]:
           valid_permutations.add(hash_permutation(perm))

    # We do NOT filter here, as these are for hypotheticals.
    return valid_permutations

def generate_mega_hypotheticals(prodigal_results: dict, winners:dict, losers:dict, n: int, num_to_generate: int = 20, min_length: int = 50, max_length: int = 200) -> dict:
    """Generates 'Mega-Hypothetical' Prodigals by combining existing Prodigals.

    Args:
        prodigal_results (dict): Dictionary of existing ProdigalResult objects.
        n (int): The value of n.
        num_to_generate (int): The number of Mega-Hypotheticals to generate.
        min_length (int): Minimum length (in permutations).
        max_length (int): Maximum length (in permutations).

    Returns:
        dict: A dictionary of new 'Mega-Hypothetical' ProdigalResult objects.
    """
    mega_hypotheticals = {}
    next_mega_id = -1  # Use negative IDs to distinguish

    for _ in range(num_to_generate):
        num_prodigals_to_combine = random.randint(2, 4)  # Combine 2-4 Prodigals
        #Select prodigals, but with a bias towards those with higher overlap and greater length
        prodigal_weights = [p.overlap_rate * p.length for p in prodigal_results.values()]
        selected_prodigal_ids = random.choices(list(prodigal_results.keys()), weights=prodigal_weights, k=num_prodigals_to_combine)
        selected_prodigals = [prodigal_results[pid] for pid in selected_prodigal_ids]

        # Sort by length, in any order.
        selected_prodigals.sort(key=lambda p: len(p.sequence))

        #Use golden ratio for lengths.
        phi = (1 + math.sqrt(5)) / 2
        total_target_length = random.randint(n * min_length, n* max_length)
        target_lengths = []

        remaining_length = total_target_length
        for i in range(len(selected_prodigals)-1):
            segment_length = int(remaining_length / (phi**(i+1)))
            target_lengths.append(segment_length)
            remaining_length -= segment_length
        target_lengths.append(remaining_length) # Add the final length.

        combined_sequence = ""
        
        #Randomize starting location
        start_location = random.randint(0,len(selected_prodigals)-1)
        prodigal_order = []
        for i in range(len(selected_prodigals)):
            prodigal_order.append(selected_prodigals[(start_location + i) % len(selected_prodigals)])

        for i in range(len(prodigal_order)):
            prodigal = prodigal_order[i]
            target_length = target_lengths[i]

            # Get a random section of the prodigal
            start_index = random.randint(0, max(0, len(prodigal.sequence) - target_length))  # Ensure valid start
            current_sequence = prodigal.sequence[start_index : start_index + target_length]
            
            # Connect to previous
            if combined_sequence != "":
                overlap = calculate_overlap(combined_sequence, current_sequence)
                if overlap == 0: #Need to use the combiner
                    prefix = combined_sequence[-(n-1):]
                    suffix = current_sequence[:n-1]
                    candidates = generate_permutations_on_demand_hypothetical(prefix, suffix,  n, n-1)
                    if candidates:
                        best_candidate = unhash_permutation(random.choice(list(candidates)), n)
                        overlap = calculate_overlap(combined_sequence,"".join(str(x) for x in best_candidate))
                        combined_sequence += "".join(str(x) for x in best_candidate)[overlap:]
                    else:
                        continue #Skip if we cannot connect.

                else: #Overlap exists
                    combined_sequence += current_sequence[overlap:]
            else:
                combined_sequence = current_sequence
        
        #Check if prodigal
        perms_in_sequence = set()
        for i in range(len(combined_sequence) - n + 1):
            perm = tuple(int(x) for x in combined_sequence[i:i+n])
            if is_valid_permutation(perm, n):
                perms_in_sequence.add(hash_permutation(perm))

        if is_prodigal(combined_sequence, [unhash_permutation(x,n) for x in perms_in_sequence], n, min_length=min_length, overlap_threshold=0.95) and len(perms_in_sequence) > 0:
            mega_hypotheticals[next_mega_id] = ProdigalResult(combined_sequence, next_mega_id)
            next_mega_id -= 1

    return mega_hypotheticals

# --- Higher-Order Winners and Losers ---

def calculate_sequence_winners_losers(superpermutations: list[str], n: int, sequence_length: int = 2) -> tuple[dict, dict]:
    """Calculates 'Winner' and 'Loser' weights for sequences of permutations.

    Args:
        superpermutations (list[str]): List of superpermutation strings.
        n (int): The value of n.
        sequence_length (int): The length of the permutation sequences to analyze (default: 2).

    Returns:
        tuple: (winners, losers), where winners and losers are dictionaries
               mapping sequence hashes (integers) to weights.
    """
    all_sequences = {}  # {seq_hash : count}

    for superperm in superpermutations:
        s_tuple = tuple(int(x) for x in superperm)
        perms = []
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n):
                perms.append(hash_permutation(perm))  # Append hash

        for i in range(len(perms) - (sequence_length - 1)):
            seq = tuple(perms[i:i + sequence_length])
            seq_hash = hash(seq)  # Hash the sequence of hashes.
            all_sequences[seq_hash] = all_sequences.get(seq_hash, 0) + 1

    # Divide into "shorter" and "longer"
    lengths = [len(s) for s in superpermutations]
    lengths.sort()
    median_length = lengths[len(lengths) // 2]
    shorter_superpermutations = [s for s in superpermutations if len(s) <= median_length]
    longer_superpermutations = [s for s in superpermutations if len(s) > median_length]

    winners = {}  # {seq_hash: weight}
    losers = {}  # {seq_hash: weight}
    shorter_counts = {}  # {seq_hash: count}
    for superperm in shorter_superpermutations:
        s_tuple = tuple(int(x) for x in superperm)
        perms = []
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perms.append(hash_permutation(perm)) # Append Hash
        for i in range(len(perms) - (sequence_length - 1)):
            seq = tuple(perms[i:i+sequence_length])
            seq_hash = hash(seq)
            shorter_counts[seq_hash] = shorter_counts.get(seq_hash, 0) + 1

    longer_counts = {} #{seq_hash: count}
    for superperm in longer_superpermutations:
        s_tuple = tuple(int(x) for x in superperm)
        perms = []
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perms.append(hash_permutation(perm)) #Append Hash
        for i in range(len(perms) - (sequence_length - 1)):
            seq = tuple(perms[i:i+sequence_length])
            seq_hash = hash(seq)
            longer_counts[seq_hash] = longer_counts.get(seq_hash, 0) + 1

    for seq_hash in all_sequences:
        score = shorter_counts.get(seq_hash, 0) - longer_counts.get(seq_hash, 0)
        if score > 0:
            winners[seq_hash] = score
        if score < 0:
            losers[seq_hash] = -score

    return winners, losers

# --- Missing Permutation Analysis ---
def analyze_missing_permutations(superpermutation: str, n: int) -> dict:
    """Analyzes the missing permutations in a superpermutation.

    Args:
        superpermutation (str): The (potentially incomplete) superpermutation string.
        n (int): The value of n.

    Returns:
        dict: Information about the missing permutations.  Currently includes:
            - missing_permutations: A list of the missing permutations (as tuples).
            - kmer_counts: Counts of k-mers (n-1, n-2) within missing permutations.
    """
    all_permutations = set(itertools.permutations(range(1, n + 1)))
    s_tuple = tuple(int(x) for x in superpermutation)
    found_permutations = set()
   
    for i in range(len(s_tuple) - n + 1):
        perm = s_tuple[i:i+n]
         if is_valid_permutation(perm, n):
            found_permutations.add(tuple(perm))

    missing_permutations = list(all_permutations - found_permutations)
    missing_count = len(missing_permutations)

    # Analyze k-mer distribution within missing permutations
    kmer_counts = defaultdict(int)
    for perm in missing_permutations:
        perm_str = "".join(str(x) for x in perm)
        for k in [n - 1, n - 2]:
            for i in range(len(perm_str) - k + 1):
                kmer = perm_str[i:i + k]
                kmer_counts[kmer] += 1

    return {
        "missing_permutations": missing_permutations,
        "missing_count": missing_count,
        "kmer_counts": dict(kmer_counts),  # Convert defaultdict to regular dict
    }

def analyze_prodigal_connections(prodigal_results: dict, superpermutations: list[str]) -> dict:
    """Analyzes how "Prodigal Results" are connected in superpermutations.

    Args:
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        superpermutations (list[str]): List of superpermutation strings.

    Returns:
      dict: A dictionary containing:
        "connection_counts": dict of {(prodigal_id1, prodigal_id2): count}
        "hub_prodigals": list of prodigal IDs that are frequently connected
        "isolated_prodigals": list of prodigal IDs with few connections
    """

    connection_counts = defaultdict(int) # (prodigal_id1, prodigal_id2) -> count
    all_prodigal_ids = set(prodigal_results.keys())
    hub_prodigals = set()
    isolated_prodigals = set()

    for superperm in superpermutations:
        present_prodigals = set()
        for p_id, p_data in prodigal_results.items():
            if p_data.sequence in superperm:
                present_prodigals.add(p_id)

        # Convert to a list of *contiguous* prodigal IDs.
        prodigal_ids_in_superperm = []
        last_index = -100 #Initialize to be far away.
        for p_id in sorted(present_prodigals, key=lambda x: superperm.find(prodigal_results[x].sequence)  ):
            current_index = superperm.find(prodigal_results[p_id].sequence)
            if abs(current_index - last_index) < N * prodigal_results[p_id].length: #Check if close enough.  Using N
                prodigal_ids_in_superperm.append(p_id)
            else: #Too far, start over
                prodigal_ids_in_superperm = [p_id]
            last_index = current_index

            # Analyze connections within the ordered list
            for i in range(len(prodigal_ids_in_superperm) - 1):
                p1 = prodigal_ids_in_superperm[i]
                p2 = prodigal_ids_in_superperm[i+1]
                connection_counts[(p1, p2)] += 1

    #Identify hubs and isolated
    total_connections = defaultdict(int)
    for p1, p2 in connection_counts:
        total_connections[p1] += 1
        total_connections[p2] += 1

    average_connections = sum(total_connections.values()) / len(total_connections) if total_connections else 0

    for p_id in all_prodigal_ids:
        if p_id not in total_connections:
            isolated_prodigals.add(p_id)
        elif total_connections[p_id] > average_connections * 2:  # Example: Twice the average
            hub_prodigals.add(p_id)

    return {
        "connection_counts": dict(connection_counts),
        "hub_prodigals": list(hub_prodigals),
        "isolated_prodigals": list(isolated_prodigals)
    }

def evaluate_hypothetical_prodigals(hypothetical_prodigals, superpermutations, n):
    """Evaluates how many hypothetical prodigals appear in a list of superpermutations

    Args:
        hypothetical_prodigals (dict): Dictionary of hypothetical prodigals
        superpermutations (list[str]): List of superpermutation strings
        n (int): Value of n

    Returns:
        tuple: (success_rate, successful_prodigals, failed_prodigals), where:
            success_rate: float, percentage of successful
            successful_prodigals: list of the successful prodigal strings.
            failed_prodigals: list of failed prodigal strings.
    """
    total_hypotheticals = len(hypothetical_prodigals)
    if total_hypotheticals == 0:
        return 0, [], []

    num_successful = 0
    successful_prodigals = []
    failed_prodigals = []

    for superperm in superpermutations:
        for h_id, h_prodigal in hypothetical_prodigals.items():
            if h_prodigal.sequence in superperm:
                num_successful += 1
                successful_prodigals.append(h_prodigal.sequence)
            else:
                failed_prodigals.append(h_prodigal.sequence)
    success_rate = (num_successful/total_hypotheticals) * 100

    return success_rate, successful_prodigals, failed_prodigals

```