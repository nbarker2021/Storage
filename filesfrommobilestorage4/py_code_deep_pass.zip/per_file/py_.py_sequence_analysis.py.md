# File: py/.py/sequence_analysis.py

**Extension:** .py

**Lines:** 58 | **Words:** 207

## Keyword Hits

- SFBB: 0

- superperm: 1

- superpermutation: 1

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: logging

- From-imports: collections, utils

- Classes (0): (none)

- Functions (3): verify_permutation_coverage, calculate_sequence_length, calculate_overlap_rate


---


## Full Source


```text

# sequence_analysis.py

from utils import is_valid_permutation, generate_permutations, normalize_sequence, compute_checksum
from collections import defaultdict
import logging

def verify_permutation_coverage(sequence: str, n: int) -> bool:
    """
    Verifies that a sequence contains all permutations of length n.

    Args:
        sequence (str): The superpermutation sequence.
        n (int): The value of n.

    Returns:
        bool: True if all permutations are covered, False otherwise.
    """
    expected_perms = set(generate_permutations(n))
    found_perms = set()
    seq_digits = [int(x) for x in sequence] # Convert to list.
    for i in range(len(seq_digits) - n + 1):
        perm = tuple(seq_digits[i:i + n])
        if is_valid_permutation(perm, n):
            found_perms.add(perm)
    coverage = expected_perms == found_perms
    logging.debug(f"Permutation coverage verification for n={n}: {coverage}")
    return coverage

def calculate_sequence_length(sequence: str) -> int:
    """
    Calculates the length of the sequence.

    Args:
        sequence (str): The sequence string.

    Returns:
        int: The length of the sequence.
    """
    length = len(sequence)
    logging.debug(f"Sequence length: {length}")
    return length

def calculate_overlap_rate(sequence: str, n: int) -> float:
    """
    Calculates the overlap rate of the sequence.

    Args:
        sequence (str): The sequence string.
        n (int): The value of n.

    Returns:
        float: The overlap rate.
    """
    total_possible_overlap = (n - 1) * (len(sequence) - n + 1)
    actual_overlap = (n * (len(sequence) - n + 1)) - len(sequence)
    overlap_rate = actual_overlap / total_possible_overlap if total_possible_overlap > 0 else 0.0
    logging.debug(f"Overlap rate for n={n}: {overlap_rate}")
    return overlap_rate

```