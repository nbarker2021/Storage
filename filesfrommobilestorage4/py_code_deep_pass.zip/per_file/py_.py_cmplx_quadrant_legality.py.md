# File: py/.py/cmplx_quadrant_legality.py

**Extension:** .py

**Lines:** 33 | **Words:** 148

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: typing

- Classes (1): AGRMQuadrantLegality

- Functions (4): __init__, _compute_center, _quadrant, is_crossing_illegal


---


## Full Source


```text


from typing import Dict, Tuple

class AGRMQuadrantLegality:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()
        self.node_quadrants = {nid: self._quadrant(coord) for nid, coord in nodes.items()}

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def _quadrant(self, coord: Tuple[float, float]) -> int:
        dx, dy = coord[0] - self.center[0], coord[1] - self.center[1]
        if dx >= 0 and dy >= 0:
            return 0
        elif dx < 0 and dy >= 0:
            return 1
        elif dx < 0 and dy < 0:
            return 2
        else:
            return 3

    def is_crossing_illegal(self, a: int, b: int, max_jump: int = 2) -> bool:
        qa = self.node_quadrants.get(a)
        qb = self.node_quadrants.get(b)
        if qa is None or qb is None:
            return False
        delta = abs(qa - qb)
        delta = min(delta, 4 - delta)  # wrap around
        return delta > max_jump


```