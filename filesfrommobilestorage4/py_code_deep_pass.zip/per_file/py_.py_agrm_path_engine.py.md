# File: py/.py/agrm_path_engine.py

**Extension:** .py

**Lines:** 83 | **Words:** 331

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 3

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math, random

- From-imports: typing

- Classes (1): AGRMPathEngine

- Functions (7): __init__, _precompute_distances, _classify_density, _get_candidates, _recursive_path, _validate_and_optimize, solve


---


## Full Source


```text

# agrm_path_engine.py
# Core AGRM Traversal Engine with Sweep, Recursive Decision Making, Midpoint Unlock, and Validation

import math
import random
from typing import List, Tuple, Dict

class AGRMPathEngine:
    def __init__(self, cities: List[Tuple[float, float]]):
        self.cities = cities
        self.n = len(cities)
        self.visited = set()
        self.path = []
        self.distances = self._precompute_distances()
        self.density_zones = self._classify_density()
        self.midpoint = self.n // 2

    def _precompute_distances(self) -> Dict[Tuple[int, int], float]:
        dist = {}
        for i in range(self.n):
            for j in range(i + 1, self.n):
                d = math.dist(self.cities[i], self.cities[j])
                dist[(i, j)] = d
                dist[(j, i)] = d
        return dist

    def _classify_density(self) -> Dict[int, str]:
        zone_map = {}
        for i in range(self.n):
            local_dists = sorted(
                [self.distances[(i, j)] for j in range(self.n) if j != i]
            )
            avg_dist = sum(local_dists[:6]) / 6
            if avg_dist < 20:
                zone_map[i] = "dense"
            elif avg_dist < 100:
                zone_map[i] = "mid"
            else:
                zone_map[i] = "sparse"
        return zone_map

    def _get_candidates(self, current: int) -> List[int]:
        candidates = []
        for i in range(self.n):
            if i not in self.visited:
                if len(self.visited) < self.midpoint:
                    if self.density_zones[i] != "sparse":
                        candidates.append(i)
                else:
                    candidates.append(i)
        return sorted(candidates, key=lambda x: self.distances[(current, x)])[:6]

    def _recursive_path(self, current: int):
        self.visited.add(current)
        self.path.append(current)
        candidates = self._get_candidates(current)
        for cand in candidates:
            if cand not in self.visited:
                self._recursive_path(cand)
                return

    def _validate_and_optimize(self):
        improved = True
        while improved:
            improved = False
            for i in range(1, self.n - 2):
                for j in range(i + 1, self.n):
                    if j - i == 1:
                        continue
                    a, b = self.path[i - 1], self.path[i]
                    c, d = self.path[j - 1], self.path[j % self.n]
                    if (self.distances[(a, b)] + self.distances[(c, d)]) > (
                        self.distances[(a, c)] + self.distances[(b, d)]
                    ):
                        self.path[i:j] = reversed(self.path[i:j])
                        improved = True

    def solve(self) -> List[int]:
        start = random.randint(0, self.n - 1)
        self._recursive_path(start)
        self._validate_and_optimize()
        return self.path


```