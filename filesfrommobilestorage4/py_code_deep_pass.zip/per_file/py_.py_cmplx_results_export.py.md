# File: py/.py/cmplx_results_export.py

**Extension:** .py

**Lines:** 44 | **Words:** 219

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 6

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: csv, json, matplotlib.pyplot

- From-imports: typing

- Classes (0): (none)

- Functions (3): export_results_to_csv, export_results_to_json, plot_comparison_graph


---


## Full Source


```text


import csv
import json
import matplotlib.pyplot as plt
from typing import Dict

def export_results_to_csv(results: Dict[str, Dict], filename: str = "agrm_results.csv"):
    if not results:
        print("[EXPORT] No results to export.")
        return
    with open(filename, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        headers = ["Dataset", "Cycles", "Runtime (s)", "Feedback Signals"]
        writer.writerow(headers)
        for name, data in results.items():
            row = [name, data.get('cycles'), data.get('runtime_sec'), data.get('feedback_signals')]
            writer.writerow(row)
    print(f"[EXPORT] Results saved to {filename}")

def export_results_to_json(results: Dict[str, Dict], filename: str = "agrm_results.json"):
    with open(filename, 'w') as jsonfile:
        json.dump(results, jsonfile, indent=4)
    print(f"[EXPORT] Results saved to {filename}")

def plot_comparison_graph(results: Dict[str, Dict], greedy_baseline: Dict[str, float], optimal_baseline: Dict[str, float]):
    datasets = list(results.keys())
    agrm_scores = [results[d]['cycles'] for d in datasets]
    greedy_scores = [greedy_baseline.get(d, None) for d in datasets]
    optimal_scores = [optimal_baseline.get(d, None) for d in datasets]

    plt.figure(figsize=(12, 6))
    plt.plot(datasets, agrm_scores, marker='o', label='AGRM (cycles)')
    plt.plot(datasets, greedy_scores, marker='x', linestyle='--', label='Greedy Baseline')
    plt.plot(datasets, optimal_scores, marker='s', linestyle=':', label='Known Optimal')

    plt.title("AGRM vs Greedy vs Optimal Comparison")
    plt.xlabel("Dataset")
    plt.ylabel("Cycle / Tour Cost Metric")
    plt.legend()
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


```