# File: py/.py/reconfigurator.py

**Extension:** .py

**Lines:** 179 | **Words:** 851

## Keyword Hits

- SFBB: 0

- superperm: 69

- superpermutation: 69

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 6

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: logging, random

- From-imports: analysis_scripts_final, utils

- Classes (1): Reconfigurator

- Functions (8): __init__, reconfigure_superpermutation, accept_change, mutate_swap, mutate_insert, mutate_delete, mutate_reverse, mutate_kmer_swap


---


## Full Source


```text

# reconfigurator.py
import random
import logging
from utils import calculate_overlap, is_valid_permutation, hash_permutation, unhash_permutation
from analysis_scripts_final import calculate_sequence_score, verify_permutation_coverage, find_prodigal_results, calculate_winners_losers, identify_anti_prodigals

class Reconfigurator:
    """
    Provides methods for reconfiguring (optimizing) existing superpermutations.
    """

    def __init__(self, n, winners, losers, layout_memory, laminates, anti_laminates):
        self.n = n
        self.winners = winners
        self.losers = losers
        self.layout_memory = layout_memory
        self.laminates = laminates
        self.anti_laminates = anti_laminates

    def reconfigure_superpermutation(self, superpermutation, max_attempts=1000, initial_temperature=1.0, cooling_rate=0.995, mutation_rate=0.1):
        """Attempts to improve a superpermutation using local modifications and simulated annealing.

        Args:
            superpermutation (str): The superpermutation string to reconfigure.
            max_attempts (int): Maximum number of reconfiguration attempts.
            initial_temperature (float): Initial temperature for simulated annealing.
            cooling_rate (float): Cooling rate for simulated annealing.

        Returns:
            str: The (potentially) improved superpermutation string.
        """

        current_superpermutation = list(superpermutation) # Work on a list for mutability
        current_score = calculate_sequence_score("".join(current_superpermutation), self.n, self.winners, self.losers, self.layout_memory, self.laminates, self.anti_laminates)
        temperature = initial_temperature
        
        for attempt in range(max_attempts):
            logging.debug(f"Reconfiguration attempt: {attempt + 1}, Temperature: {temperature:.4f}, Current Score: {current_score}")
            # Choose a mutation type randomly
            mutation_type = random.choice(["swap", "insert", "delete", "reverse", "kmer_swap"])

            if mutation_type == "swap":
                new_superpermutation = self.mutate_swap(current_superpermutation.copy()) #Must work on a copy
            elif mutation_type == "insert":
                new_superpermutation = self.mutate_insert(current_superpermutation.copy())
            elif mutation_type == "delete":
                new_superpermutation = self.mutate_delete(current_superpermutation.copy())
            elif mutation_type == "reverse":
                new_superpermutation = self.mutate_reverse(current_superpermutation.copy())
            elif mutation_type == "kmer_swap":
                new_superpermutation = self.mutate_kmer_swap(current_superpermutation.copy())
            else:
                new_superpermutation = current_superpermutation #Should not happen

            if new_superpermutation: #If a change was actually made
                new_score = calculate_sequence_score("".join(new_superpermutation), self.n, self.winners, self.losers, self.layout_memory, self.laminates, self.anti_laminates)

                # Decide whether to accept the change
                if self.accept_change(current_score, new_score, temperature):
                    current_superpermutation = new_superpermutation
                    current_score = new_score
                    logging.debug(f"Accepted mutation: {mutation_type}")

            # Cool down
            temperature *= cooling_rate
            if not verify_permutation_coverage("".join(current_superpermutation), self.n):
                return None #Not valid, so we discard.

        return "".join(current_superpermutation)

    def accept_change(self, old_score, new_score, temperature):
        """Decides whether to accept a change based on simulated annealing."""
        if new_score > old_score:
            return True  # Always accept improvements
        else:
            probability = math.exp((new_score - old_score) / temperature)
            return random.random() < probability

    def mutate_swap(self, superpermutation):
        """Swaps two permutations within a window."""
        window_size = self.n * 5  # Example window size
        start_index = random.randint(0, max(0, len(superpermutation) - window_size))
        end_index = min(len(superpermutation), start_index + window_size)

        # Find two valid permutation indices within the window
        valid_indices = []
        for i in range(start_index, end_index - self.n + 1):
            perm = tuple(int(x) for x in superpermutation[i:i + self.n])
            if is_valid_permutation(perm, self.n):
                valid_indices.append(i)

        if len(valid_indices) < 2:
            return None  # Not enough valid permutations to swap

        idx1, idx2 = random.sample(valid_indices, 2)
        perm1_slice = slice(idx1, idx1 + self.n)
        perm2_slice = slice(idx2, idx2 + self.n)
        superpermutation[perm1_slice], superpermutation[perm2_slice] = superpermutation[perm2_slice], superpermutation[perm1_slice]
        return superpermutation

    def mutate_insert(self, superpermutation):
        """Inserts a permutation at a random location."""
        #Insert a missing permutation
        missing_permutations = set()
        all_permutations = generate_permutations(self.n)
        s_tuple = tuple(int(x) for x in superpermutation)

        for p in all_permutations:
            found = False
            for i in range(len(s_tuple) - self.n + 1):
                if s_tuple[i:i+self.n] == p:
                    found = True
                    break
            if not found:
                missing_permutations.add(hash_permutation(p))
        candidates = generate_completion_candidates_n8("".join(superpermutation), missing_permutations, {}, self.winners, self.losers, self.n, [], [], [])

        if not candidates:
            return None

        insertion_point = random.randint(0, len(superpermutation))
        new_perm_hash = random.choice(list(candidates))
        new_perm = unhash_permutation(new_perm_hash, self.n)
        superpermutation = superpermutation[:insertion_point] + list(str(x) for x in new_perm) + superpermutation[insertion_point:]
        return superpermutation

    def mutate_delete(self, superpermutation):
        """Deletes a random permutation."""
        #Find a random permutation
        delete_pos = random.randint(0, len(superpermutation) - self.n)
        perm = tuple(int(x) for x in superpermutation[delete_pos:delete_pos + self.n])
        if is_valid_permutation(perm, self.n):
          superpermutation = superpermutation[:delete_pos] + superpermutation[delete_pos + self.n:] #Cut out that section.
          return superpermutation
        return None # Do nothing if not valid

    def mutate_reverse(self, superpermutation):
        """Reverses a random subsequence."""
        # Select a random subsequence of permutations
        start_pos = random.randint(0, len(superpermutation) - self.n)
        end_pos = random.randint(start_pos + self.n, min(len(superpermutation), start_pos + self.n * 5))  # Limit length

        #Make sure we are reversing valid perms
        valid = True
        for i in range(start_pos, end_pos -self.n + 1):
          perm = tuple(int(x) for x in superpermutation[i:i+self.n])
          if not is_valid_permutation(perm, self.n):
            valid = False
            break
        if valid:
          superpermutation[start_pos:end_pos] = superpermutation[start_pos:end_pos][::-1]  # Reverse that section
          return superpermutation
        return None

    def mutate_kmer_swap(self, superpermutation):
        """Swaps two overlapping k-mers within a window."""
        window_size = self.n * 3  # Example window size
        start_index = random.randint(0, max(0, len(superpermutation) - window_size))
        end_index = min(len(superpermutation), start_index + window_size)

        # Find two valid k-mer indices within the window
        k = self.n -1
        valid_indices = []
        for i in range(start_index, end_index - k + 1):
            kmer = tuple(int(x) for x in superpermutation[i:i + k])
            #We don't have to, but for consistency, we will check if the kmers are part of a valid permutation.
            if i > 0: #Need a previous perm
              perm = tuple(int(x) for x in superpermutation[i-1:i-1+self.n])
              if is_valid_permutation(perm, self.n):
                valid_indices.append(i)

        if len(valid_indices) < 2:
            return None  # Not enough valid k-mers to swap

        idx1, idx2 = random.sample(valid_indices, 2)
        kmer1_slice = slice(idx1, idx1 + k)
        kmer2_slice = slice(idx2, idx2 + k)
        superpermutation[kmer1_slice], superpermutation[kmer2_slice] = superpermutation[kmer2_slice], superpermutation[kmer1_slice]
        return superpermutation

```