# File: py/.py/teacher_safe.py

**Extension:** .py

**Lines:** 37 | **Words:** 146

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 1

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: yaml

- From-imports: agents.testlab, core.cmplx_logger, core.result_analyzer

- Classes (1): TeacherAgent

- Functions (2): __init__, step


---


## Full Source


```text

from core.cmplx_logger import log
from agents.testlab import TestLabAgent
from core.result_analyzer import ResultAnalyzerAgent

class TeacherAgent:
    def __init__(self):
        self.max_recovery_depth = 2

    def step(self, state):
        state.setdefault("_recovery_depth", 0)

        audit = state.get("audit", {})
        dataset = state.get("dataset", "")
        last_plan = state.get("plan_used", {})

        if audit.get("final_status") != "complete":
            if state["_recovery_depth"] >= self.max_recovery_depth:
                log("Maximum recovery attempts reached. Skipping further self-testing.", agent="Teacher", phase="Abort")
                return

            log("Poor performance detected, invoking TestLabAgent...", agent="Teacher", phase="Recovery")
            state["_recovery_depth"] += 1

            testlab = TestLabAgent(planner=None, dataset_path=dataset)
            fix_found, plan = testlab.run_variant_tests(last_plan)

            if fix_found:
                log("New improved plan found. Overwriting plan file...", agent="Teacher", phase="Learned")
                path = "presets/conservative_entropy.yaml"
                import yaml
                with open(path, "w") as f:
                    yaml.safe_dump(plan, f)
                log(f"Updated strategy saved to {path}", agent="Teacher", phase="Persist")
                state["_recovery_depth"] = 0
            else:
                log("No better plan found. Reverting.", agent="Teacher", phase="Failover")


```