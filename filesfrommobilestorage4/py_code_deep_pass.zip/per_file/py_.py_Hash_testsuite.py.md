# File: py/.py/Hash_testsuite.py

**Extension:** .py

**Lines:** 472 | **Words:** 1601

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 13

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 103

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: matplotlib.pyplot, numpy, random, time

- From-imports: typing

- Classes (1): HashTableBenchmark

- Functions (14): run_benchmarks, __init__, run_standard_tests, _test_standard_distribution, _test_skewed_distribution, _test_collision_resistance, _test_sequential_access, _test_load_factor_scaling, _measure_operations, plot_results, _plot_operation_times, _plot_load_factor_scaling, print_summary, _print_test_summary


---


## Full Source


```text

import time
import random
import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List, Any, Tuple

class HashTableBenchmark:
    """Benchmarking suite for hash table implementations."""
    
    def __init__(self):
        self.results = {}
        
    def run_standard_tests(self, hash_table, traditional_dict=None, n_operations=100000):
        """
        Run standard benchmark tests on hash tables.
        
        Args:
            hash_table: Hash table implementation to test
            traditional_dict: Optional traditional dict for comparison
            n_operations: Number of operations to perform
        
        Returns:
            Dictionary of benchmark results
        """
        print("Running standard distribution test...")
        std_results = self._test_standard_distribution(hash_table, traditional_dict, n_operations)
        
        print("Running skewed distribution test...")
        skew_results = self._test_skewed_distribution(hash_table, traditional_dict, n_operations)
        
        print("Running collision resistance test...")
        collision_results = self._test_collision_resistance(hash_table, traditional_dict, n_operations // 10)
        
        print("Running sequential access test...")
        sequential_results = self._test_sequential_access(hash_table, traditional_dict, n_operations)
        
        print("Running load factor scaling test...")
        load_factor_results = self._test_load_factor_scaling(hash_table, traditional_dict)
        
        # Collect all results
        results = {
            'standard': std_results,
            'skewed': skew_results,
            'collision': collision_results,
            'sequential': sequential_results,
            'load_factor': load_factor_results
        }
        
        self.results = results
        return results
        
    def _test_standard_distribution(self, hash_table, traditional_dict, n_operations):
        """Test with standard uniform distribution of keys."""
        # Generate random key-value pairs
        keys = [random.randint(0, n_operations * 10) for _ in range(n_operations)]
        values = [f"value_{i}" for i in range(n_operations)]
        
        # Test MDHG hash table
        hash_table_times = self._measure_operations(hash_table, keys, values)
        
        # Test traditional dict if provided
        dict_times = None
        if traditional_dict is not None:
            dict_times = self._measure_operations(traditional_dict, keys, values)
        
        return {
            'hash_table_times': hash_table_times,
            'dict_times': dict_times,
            'keys': keys,
            'values': values
        }
    
    def _test_skewed_distribution(self, hash_table, traditional_dict, n_operations):
        """Test with skewed distribution (some keys more frequent than others)."""
        # Generate skewed key distribution (80% of operations use 20% of key space)
        hot_keys = [random.randint(0, n_operations // 5) for _ in range(n_operations // 5)]
        
        keys = []
        for _ in range(n_operations):
            if random.random() < 0.8:
                # Use a hot key
                keys.append(random.choice(hot_keys))
            else:
                # Use a random key
                keys.append(random.randint(0, n_operations * 10))
        
        values = [f"value_{i}" for i in range(n_operations)]
        
        # Test MDHG hash table
        hash_table_times = self._measure_operations(hash_table, keys, values)
        
        # Test traditional dict if provided
        dict_times = None
        if traditional_dict is not None:
            dict_times = self._measure_operations(traditional_dict, keys, values)
        
        return {
            'hash_table_times': hash_table_times,
            'dict_times': dict_times,
            'hot_keys': hot_keys,
            'keys': keys,
            'values': values
        }
    
    def _test_collision_resistance(self, hash_table, traditional_dict, n_operations):
        """Test resistance to hash collisions."""
        # Generate keys designed to cause collisions
        # For example, strings with similar patterns
        keys = [f"collision{i % 100}-{i}" for i in range(n_operations)]
        values = [f"value_{i}" for i in range(n_operations)]
        
        # Test MDHG hash table
        hash_table_times = self._measure_operations(hash_table, keys, values)
        
        # Test traditional dict if provided
        dict_times = None
        if traditional_dict is not None:
            dict_times = self._measure_operations(traditional_dict, keys, values)
        
        return {
            'hash_table_times': hash_table_times,
            'dict_times': dict_times,
            'keys': keys,
            'values': values
        }
    
    def _test_sequential_access(self, hash_table, traditional_dict, n_operations):
        """Test with sequential access patterns."""
        # First insert some data
        keys = [i for i in range(n_operations // 10)]
        values = [f"value_{i}" for i in range(n_operations // 10)]
        
        for i in range(len(keys)):
            hash_table.put(keys[i], values[i])
            if traditional_dict is not None:
                traditional_dict[keys[i]] = values[i]
        
        # Generate sequential access patterns (e.g., iterating through keys in sequence)
        sequential_keys = []
        for _ in range(n_operations):
            # Create sequences of 5-10 sequential keys
            start = random.randint(0, len(keys) - 10)
            length = random.randint(5, 10)
            sequential_keys.extend(keys[start:start + length])
        
        # Test MDHG hash table (gets only)
        start_time = time.time()
        for key in sequential_keys:
            hash_table.get(key)
        hash_table_time = time.time() - start_time
        
        # Test traditional dict if provided
        dict_time = None
        if traditional_dict is not None:
            start_time = time.time()
            for key in sequential_keys:
                traditional_dict.get(key)
            dict_time = time.time() - start_time
        
        return {
            'hash_table_time': hash_table_time,
            'dict_time': dict_time,
            'sequential_keys': sequential_keys
        }
    
    def _test_load_factor_scaling(self, hash_table, traditional_dict):
        """Test how performance scales with increasing load factor."""
        load_factors = [0.1, 0.3, 0.5, 0.7, 0.9]
        base_capacity = 1000
        
        hash_table_results = []
        dict_results = []
        
        for load_factor in load_factors:
            # Calculate number of elements to insert
            n_elements = int(base_capacity * load_factor)
            
            # Create new hash table with fixed capacity
            test_hash_table = MDHGHashTable(capacity=base_capacity)
            test_dict = {} if traditional_dict is not None else None
            
            # Insert elements
            keys = [i for i in range(n_elements)]
            values = [f"value_{i}" for i in range(n_elements)]
            
            for i in range(n_elements):
                test_hash_table.put(keys[i], values[i])
                if test_dict is not None:
                    test_dict[keys[i]] = values[i]
            
            # Measure get performance
            test_keys = random.sample(keys, min(100, n_elements))
            
            start_time = time.time()
            for key in test_keys:
                test_hash_table.get(key)
            hash_table_time = time.time() - start_time
            
            dict_time = None
            if test_dict is not None:
                start_time = time.time()
                for key in test_keys:
                    test_dict.get(key)
                dict_time = time.time() - start_time
            
            hash_table_results.append(hash_table_time)
            dict_results.append(dict_time)
        
        return {
            'load_factors': load_factors,
            'hash_table_times': hash_table_results,
            'dict_times': dict_results
        }
    
    def _measure_operations(self, container, keys, values):
        """
        Measure time for put, get, and remove operations.
        
        Args:
            container: Hash table or dict to test
            keys: List of keys to use
            values: List of values to use
            
        Returns:
            Dictionary of operation times
        """
        n_operations = len(keys)
        
        # Measure put performance
        start_time = time.time()
        for i in range(n_operations):
            if hasattr(container, 'put'):
                container.put(keys[i], values[i])
            else:
                container[keys[i]] = values[i]
        put_time = time.time() - start_time
        
        # Measure get performance
        start_time = time.time()
        for i in range(n_operations):
            if hasattr(container, 'get'):
                container.get(keys[i])
            else:
                container.get(keys[i])
        get_time = time.time() - start_time
        
        # Measure remove performance (sample)
        sample_size = min(1000, n_operations)
        remove_keys = random.sample(keys, sample_size)
        
        start_time = time.time()
        for key in remove_keys:
            if hasattr(container, 'remove'):
                container.remove(key)
            else:
                container.pop(key, None)
        remove_time = time.time() - start_time
        
        # Scale remove time to estimate full removal time
        remove_time = remove_time * (n_operations / sample_size)
        
        return {
            'put': put_time,
            'get': get_time,
            'remove': remove_time,
            'total': put_time + get_time + remove_time
        }
    
    def plot_results(self):
        """Plot benchmark results."""
        if not self.results:
            print("No results to plot. Run benchmarks first.")
            return
        
        # Create figure with subplots
        fig, axs = plt.subplots(2, 2, figsize=(15, 12))
        
        # Plot standard distribution results
        self._plot_operation_times(axs[0, 0], 'Standard Distribution')
        
        # Plot skewed distribution results
        self._plot_operation_times(axs[0, 1], 'Skewed Distribution')
        
        # Plot collision resistance results
        self._plot_operation_times(axs[1, 0], 'Collision Resistance')
        
        # Plot load factor scaling
        self._plot_load_factor_scaling(axs[1, 1])
        
        # Adjust layout and show
        plt.tight_layout()
        plt.show()
    
    def _plot_operation_times(self, ax, title):
        """Plot operation times for a specific test."""
        test_key = title.lower().replace(' ', '_')
        if test_key not in self.results:
            return
        
        result = self.results[test_key]
        
        if 'hash_table_times' not in result or 'dict_times' not in result:
            return
        
        hash_times = result['hash_table_times']
        dict_times = result['dict_times']
        
        if not hash_times or not dict_times:
            return
        
        operations = ['put', 'get', 'remove', 'total']
        hash_values = [hash_times[op] for op in operations]
        dict_values = [dict_times[op] for op in operations]
        
        x = np.arange(len(operations))
        width = 0.35
        
        ax.bar(x - width/2, hash_values, width, label='MDHG Hash')
        ax.bar(x + width/2, dict_values, width, label='Dict')
        
        ax.set_title(title)
        ax.set_xticks(x)
        ax.set_xticklabels(operations)
        ax.set_ylabel('Time (seconds)')
        ax.legend()
        
        # Add speedup annotations
        for i, (hash_val, dict_val) in enumerate(zip(hash_values, dict_values)):
            speedup = dict_val / hash_val if hash_val > 0 else 0
            ax.annotate(f'{speedup:.2f}x', 
                       (x[i], max(hash_val, dict_val) * 1.05),
                       ha='center')
    
    def _plot_load_factor_scaling(self, ax):
        """Plot performance scaling with load factor."""
        if 'load_factor' not in self.results:
            return
        
        result = self.results['load_factor']
        
        load_factors = result['load_factors']
        hash_times = result['hash_table_times']
        dict_times = result['dict_times']
        
        if not hash_times or not dict_times:
            return
        
        ax.plot(load_factors, hash_times, 'o-', label='MDHG Hash')
        ax.plot(load_factors, dict_times, 's-', label='Dict')
        
        ax.set_title('Performance vs. Load Factor')
        ax.set_xlabel('Load Factor')
        ax.set_ylabel('Time (seconds)')
        ax.legend()
        
        # Add speedup annotations
        for i, (hash_val, dict_val) in enumerate(zip(hash_times, dict_times)):
            speedup = dict_val / hash_val if hash_val > 0 else 0
            ax.annotate(f'{speedup:.2f}x', 
                       (load_factors[i], max(hash_val, dict_val) * 1.05),
                       ha='center')
    
    def print_summary(self):
        """Print a summary of benchmark results."""
        if not self.results:
            print("No results to summarize. Run benchmarks first.")
            return
        
        print("\n" + "="*50)
        print("BENCHMARK SUMMARY")
        print("="*50)
        
        # Print standard distribution results
        self._print_test_summary('Standard Distribution', 'standard')
        
        # Print skewed distribution results
        self._print_test_summary('Skewed Distribution', 'skewed')
        
        # Print collision resistance results
        self._print_test_summary('Collision Resistance', 'collision')
        
        # Print sequential access results
        if 'sequential' in self.results:
            result = self.results['sequential']
            hash_time = result['hash_table_time']
            dict_time = result['dict_time']
            
            print("\n" + "-"*50)
            print(f"Sequential Access Test")
            print("-"*50)
            print(f"MDHG Hash: {hash_time:.6f} seconds")
            if dict_time:
                print(f"Dict:      {dict_time:.6f} seconds")
                speedup = dict_time / hash_time if hash_time > 0 else 0
                print(f"Speedup:   {speedup:.2f}x")
        
        # Print load factor scaling results
        if 'load_factor' in self.results:
            result = self.results['load_factor']
            load_factors = result['load_factors']
            hash_times = result['hash_table_times']
            dict_times = result['dict_times']
            
            print("\n" + "-"*50)
            print(f"Load Factor Scaling Test")
            print("-"*50)
            print(f"{'Load Factor':<15} {'MDHG Hash':<15} {'Dict':<15} {'Speedup':<10}")
            print("-"*55)
            
            for i, load_factor in enumerate(load_factors):
                hash_time = hash_times[i]
                dict_time = dict_times[i] if dict_times else None
                
                if dict_time:
                    speedup = dict_time / hash_time if hash_time > 0 else 0
                    print(f"{load_factor:<15.2f} {hash_time:<15.6f} {dict_time:<15.6f} {speedup:<10.2f}x")
                else:
                    print(f"{load_factor:<15.2f} {hash_time:<15.6f} {'N/A':<15} {'N/A':<10}")
    
    def _print_test_summary(self, title, test_key):
        """Print summary for a specific test."""
        if test_key not in self.results:
            return
        
        result = self.results[test_key]
        
        if 'hash_table_times' not in result or 'dict_times' not in result:
            return
        
        hash_times = result['hash_table_times']
        dict_times = result['dict_times']
        
        if not hash_times or not dict_times:
            return
        
        print("\n" + "-"*50)
        print(f"{title} Test")
        print("-"*50)
        print(f"{'Operation':<10} {'MDHG Hash':<15} {'Dict':<15} {'Speedup':<10}")
        print("-"*50)
        
        operations = ['put', 'get', 'remove', 'total']
        for op in operations:
            hash_time = hash_times[op]
            dict_time = dict_times[op]
            speedup = dict_time / hash_time if hash_time > 0 else 0
            
            print(f"{op:<10} {hash_time:<15.6f} {dict_time:<15.6f} {speedup:<10.2f}x")

# Run the benchmarks
def run_benchmarks():
    """Run benchmarks and display results."""
    # Create hash table and traditional dict
    mdhg_hash = MDHGHashTable(capacity=10000, dimensions=3)
    traditional_dict = {}
    
    # Create benchmark
    benchmark = HashTableBenchmark()
    
    # Run standard tests
    results = benchmark.run_standard_tests(mdhg_hash, traditional_dict, n_operations=10000)
    
    # Print summary
    benchmark.print_summary()
    
    # Plot results
    benchmark.plot_results()
    
    return results, benchmark

if __name__ == "__main__":
    results, benchmark = run_benchmarks()

```