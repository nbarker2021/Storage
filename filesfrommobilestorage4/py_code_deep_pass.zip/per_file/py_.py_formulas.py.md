# File: py/.py/formulas.py

**Extension:** .py

**Lines:** 90 | **Words:** 409

## Keyword Hits

- SFBB: 0

- superperm: 5

- superpermutation: 5

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 1

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math, networkx

- From-imports: collections, utils

- Classes (0): (none)

- Functions (10): sp_lower_bound, sp_additive, sp_v14, sp_v15, segment_length_v5, segment_length_v14, c_n_example, action_a1, action_a2, combined_formula_1


---


## Full Source


```text

# formulas.py
import math
import networkx as nx
from utils import generate_permutations, is_valid_permutation, calculate_overlap, kmer_to_int
from collections import defaultdict

# Constants
PHI = (1 + math.sqrt(5)) / 2  # Golden ratio
PI = math.pi
E = math.e

# --- Superpermutation Length Formulas ---

def sp_lower_bound(n):
    """Theoretical lower bound for SP(n). Status: Validated."""
    return sum(math.factorial(i) for i in range(1, n + 1))

def sp_additive(n, sp_n_minus_1):
    """Simple additive formula. Status: Deprecated (Incorrect for n>=6)."""
    return math.factorial(n) + sp_n_minus_1

def sp_v14(n, sp_n_minus_1):
    """Formula V14: SP(n-1) * (n / phi). Status: Promising (n=7)."""
    return sp_n_minus_1 * (n / PHI)

def sp_v15(n, sp_n_minus_1, c_n_minus_1):
    """Formula V15: n! + SP(n-1) + C(n-1) * (n/φ).  Status: Experimental."""
    return math.factorial(n) + sp_n_minus_1 + c_n_minus_1 * (n/PHI)

# ... (Other SP formula variations) ...

# --- Segment Length Formulas ---
def segment_length_v5(n):
    """Segment length formula V5. Status: Testing"""
    return (n + (sp_lower_bound(n) / PHI)) / (n * PHI)

def segment_length_v14(n, sp_n_minus_1):
    """Segment Length, derived from best SP formula. Status: Testing"""
    return sp_n_minus_1*(n/PHI) / math.factorial(n) #Placeholder, needs more testing.

# ... (Other segment length formula variations) ...

# --- Correction Term Formulas ---
def c_n_example(n):
	"""Example C(n) formula.  Status: Experimental."""
	return (n - 5) * (n-6) // 2 + (n-6)
# ... (Other C(n) formula variations) ...

# --- Action Function Formulas ---

def action_a1(superpermutation, n):
    """Overlap-based action. Status: Baseline."""
    s_list = [int(x) for x in superpermutation]
    action = 0
    for i in range(len(s_list) - n):
        perm = tuple(s_list[i:i + n])
        if is_valid_permutation(perm, n):
            if i > 0:
                prev_perm = tuple(s_list[i-1:i-1+n])
                if is_valid_permutation(prev_perm, n):
                  overlap = calculate_overlap("".join(map(str,prev_perm)), "".join(map(str, perm)))
                  action += (n - 1) - overlap
    return action

def action_a2(superpermutation, n, winners, losers):
    """Overlap and Winner/Loser based action. Status: Testing."""
    s_list = [int(x) for x in superpermutation]
    action = 0
    for i in range(len(s_list) - n + 1):
        perm = tuple(s_list[i:i + n])
        if is_valid_permutation(perm, n):
            if i > 0:
                prev_perm = tuple(s_list[i-1:i-1+n])
                if is_valid_permutation(prev_perm, n):
                    overlap = calculate_overlap("".join(map(str,prev_perm)), "".join(map(str, perm)))
                    action += (n - 1) - overlap
            for k in [n-1, n-2]:
                for j in range(len(perm) -k + 1):
                    kmer = "".join(map(str,perm[j:j+k]))
                    action += losers.get(kmer, 0) - winners.get(kmer,0) #Losers are negative, so add.
    return action

# ... (Other action function variations - A3, A4, A5, A6, A7, A8) ...

# --- Formula Combinations ---
def combined_formula_1(n, sp_n_minus_1):
    """Example of combining formulas. Status: Experimental."""
    return sp_v14(n, sp_n_minus_1) + c_n_example(n)

# ... (Other formula combinations) ...

```