# File: py/.py/agrm_modulation_brain.py

**Extension:** .py

**Lines:** 75 | **Words:** 356

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMModulationControllerBrain

- Functions (11): __init__, _compute_center, _compute_shells, analyze_entropy, detect_shell_failure, should_trigger_global_unlock, unlock_shell, is_shell_unlocked, record_zone_failure, is_zone_failed, angle


---


## Full Source


```text


from typing import List, Tuple, Dict, Set
import math

class AGRMModulationControllerBrain:
    def __init__(self, nodes: Dict[int, Tuple[float, float]], num_shells: int = 6):
        self.nodes = nodes
        self.num_shells = num_shells
        self.center = self._compute_center()
        self.shell_assignments = self._compute_shells()
        self.entropy_history: List[float] = []
        self.unlocked_shells: Set[int] = set()
        self.failed_zones: Set[int] = set()
        self.global_unlock_triggered = False
        self.unlock_threshold = 0.15
        self.collapse_threshold = 3
        self.collapse_count = 0

    def _compute_center(self):
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def _compute_shells(self) -> Dict[int, int]:
        shells = {}
        max_d = max(math.hypot(x - self.center[0], y - self.center[1]) for x, y in self.nodes.values())
        for nid, (x, y) in self.nodes.items():
            dist = math.hypot(x - self.center[0], y - self.center[1])
            shell_idx = min(self.num_shells - 1, int((dist / max_d) * self.num_shells))
            shells[nid] = shell_idx
        return shells

    def analyze_entropy(self, path: List[int]) -> float:
        def angle(a, b, c):
            ba = (a[0] - b[0], a[1] - b[1])
            bc = (c[0] - b[0], c[1] - b[1])
            cos = (ba[0]*bc[0] + ba[1]*bc[1]) / (math.hypot(*ba) * math.hypot(*bc) + 1e-9)
            return math.acos(max(-1.0, min(1.0, cos)))
        phi = (1 + math.sqrt(5)) / 2
        entropy = 0.0
        for i in range(1, len(path)-1):
            a, b, c = self.nodes[path[i-1]], self.nodes[path[i]], self.nodes[path[i+1]]
            delta = abs(angle(a, b, c) - phi)
            entropy += delta
        entropy /= max(1, len(path)-2)
        self.entropy_history.append(entropy)
        return entropy

    def detect_shell_failure(self, path: List[int]) -> bool:
        touched_shells = set(self.shell_assignments[n] for n in path)
        untouched = set(range(self.num_shells)) - touched_shells
        if untouched:
            self.collapse_count += 1
            return True
        return False

    def should_trigger_global_unlock(self) -> bool:
        if self.collapse_count >= self.collapse_threshold:
            self.global_unlock_triggered = True
        return self.global_unlock_triggered

    def unlock_shell(self, shell_index: int):
        self.unlocked_shells.add(shell_index)

    def is_shell_unlocked(self, shell_index: int):
        return self.global_unlock_triggered or (shell_index in self.unlocked_shells)

    def record_zone_failure(self, node_id: int):
        shell = self.shell_assignments.get(node_id)
        if shell is not None:
            self.failed_zones.add(shell)

    def is_zone_failed(self, node_id: int):
        shell = self.shell_assignments.get(node_id)
        return shell in self.failed_zones


```