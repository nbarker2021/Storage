# File: py/.py/completion_algorithm_n8_final.py

**Extension:** .py

**Lines:** 928 | **Words:** 4488

## Keyword Hits

- SFBB: 0

- superperm: 98

- superpermutation: 97

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 114

- golden: 18

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

import itertools
import random
import math
import time
import networkx as nx
from collections import deque, defaultdict
import heapq
from layout_memory import LayoutMemory  # Import the LayoutMemory class
import analysis_scripts

# --- Constants (Consistent with generation_code_n8_dynamic.py) ---
N = 8  # The value of n (number of symbols).
PRODIGAL_OVERLAP_THRESHOLD = 0.90  #  Start high, reduced dynamically.
PRODIGAL_MIN_LENGTH = 20
HYPOTHETICAL_PRODIGAL_OVERLAP_THRESHOLD = 0.95
HYPOTHETICAL_PRODIGAL_MIN_LENGTH = 20
HYPOTHETICAL_PRODIGAL_GENERATION_COUNT = 50
WINNER_THRESHOLD = 0.75 #Not directly used
LOSER_THRESHOLD = 0.25 #Not directly used.
#INITIAL_SAMPLE_SIZE = 100000000 # Not used
#NUM_ITERATIONS = 5 # Not directly used
#SUPER_BATCH_SIZE = 2000000 #Not Used
#BATCH_SIZE = 2000 # Not used.
LAYOUT_K_VALUES = [N - 1, N - 2]
DE_BRUIJN_K_VALUES = [N-1, N-2]
COMPLETION_SAMPLE_SIZE = 1000000  #  Target for candidate generation
RANDOM_SEED = 42  # For reproducibility

# --- Helper Functions (Replicated from generation_code_n8_dynamic.py for Standalone) ---
def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings."""
    max_overlap = 0
    for i in range(1, min(len(s1), len(s2)) + 1):
        if s1[-i:] == s2[:i]:
            max_overlap = i
    return max_overlap

def generate_permutations(n: int) -> list[tuple[int, ...]]:
    """Generates all permutations of 1 to n."""
    return list(itertools.permutations(range(1, n + 1)))

def calculate_distance(p1: str, p2: str, n: int) -> int:
    """Calculates distance (n-1 - overlap)."""
    return (n - 1) - max(calculate_overlap(p1, p2), calculate_overlap(p2, p1))

def hash_permutation(permutation: tuple) -> int:
    """Hashes a permutation tuple to a unique integer."""
    result = 0
    n = len(permutation)
    for i, val in enumerate(permutation):
        result += val * (n ** (n - 1 - i))
    return result

def unhash_permutation(hash_value: int, n: int) -> tuple:
    """Converts a hash value back to a permutation tuple."""
    permutation = []
    for i in range(n - 1, -1, -1):
        val = hash_value // (n ** i)
        permutation.append(val + 1)  # Adjust to be 1-indexed
        hash_value -= val * (n ** i)
    return tuple(permutation)

def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a given sequence is a valid permutation."""
    return len(set(perm)) == n and min(perm) == 1 and max(perm) == n

def calculate_golden_ratio_points(length: int, levels: int = 1) -> list[int]:
    """Calculates multiple levels of golden ratio points."""
    phi = (1 + math.sqrt(5)) / 2
    points = []
    for _ in range(levels):
        new_points = []
        if not points:
            new_points = [int(length / phi), int(length - length / phi)]
        else:
            for p in points:
                new_points.extend([int(p / phi), int(p - p / phi)])
                new_points.extend([int((length-p) / phi) + p, int(length - (length-p) / phi)])
        points.extend(new_points)
        points = sorted(list(set(points)))  # Remove duplicates and sort
    return points

def get_kmers(sequence: str, n: int, k: int) -> set[str]:
    """Extracts all k-mers from a sequence, given n and k."""
    kmers = set()
    seq_list = [int(x) for x in sequence]
    for i in range(len(sequence) - n + 1):
        perm = tuple(seq_list[i:i+n])
        if is_valid_permutation(perm, n):
            if i >= k:
                kmer = "".join(str(x) for x in seq_list[i-k:i])
                kmers.add(kmer)
    return kmers
    
    # START SECTION: Data Structures

class PermutationData:
    def __init__(self, permutation: tuple, in_sample: bool = False, creation_method: str = ""):
        """
        Stores data associated with a single permutation.

        Args:
            permutation (tuple): The permutation as a tuple of integers (1-indexed).
            in_sample (bool): True if the permutation was part of the initial sample
                             (Not used in completion).
            creation_method (str):  Describes how the permutation was generated
                                   (e.g., "prodigal_extension", "completion").
        """
        self.hash: int = hash_permutation(permutation)
        self.permutation: tuple = permutation
        self.in_sample: bool = in_sample  # Will likely always be False
        self.used_count: int = 0  # How many times this permutation has been used
        self.prodigal_status: list[int] = []  # List of ProdigalResult IDs it belongs to
        self.creation_method: str = creation_method
        self.batch_ids: list[int] = []  # Not used.
        self.used_in_final: bool = False  # True if in the current best superpermutation
        self.neighbors: set[int] = set()  # Set of hashes of neighboring permutations

    def __str__(self) -> str:
        """String representation for debugging."""
        return (f"PermutationData(hash={self.hash}, permutation={self.permutation}, used_count={self.used_count}, "
                f"prodigal_status={self.prodigal_status}, creation_method={self.creation_method})")

    def __repr__(self) -> str:
        return self.__str__()


class ProdigalResult:
    def __init__(self, sequence: str, result_id: int):
        """
        Represents a "Prodigal Result" - a highly efficient subsequence.

        Args:
            sequence (str): The superpermutation sequence (as a string of digits).
            result_id (int): A unique ID for this "Prodigal Result."
        """
        self.id: int = result_id
        self.sequence: str = sequence
        self.length: int = len(sequence)
        self.permutations: set[int] = set()  # Store hashes of permutations
        self.calculate_permutations()  # Calculate on creation
        self.overlap_rate: float = self.calculate_overlap_rate()

    def calculate_permutations(self):
        """Calculates and stores the set of permutations contained in the sequence."""
        n = N  # Use the global N value
        for i in range(len(self.sequence) - n + 1):
            perm = tuple(int(x) for x in self.sequence[i:i + n])
            if is_valid_permutation(perm, n):
                self.permutations.add(hash_permutation(perm))

    def calculate_overlap_rate(self) -> float:
        """Calculates the overlap rate of the sequence."""
        n = N  # Use the global N value
        total_length = sum(len(str(p)) for p in [unhash_permutation(x,n) for x in self.permutations])
        overlap_length = total_length - len(self.sequence)
        max_possible_overlap = (len(self.permutations) - 1) * (n - 1)
        if max_possible_overlap == 0:
            return 0  # Avoid division by zero
        return overlap_length / max_possible_overlap

    def __str__(self) -> str:
        """String representation for debugging."""
        return (f"ProdigalResult(id={self.id}, length={self.length}, "
                f"overlap_rate={self.overlap_rate:.4f}, num_permutations={len(self.permutations)})")

    def __repr__(self) -> str:
        return self.__str__()
        
        # START SECTION: Completion Candidate Generation

def generate_completion_candidates(current_superpermutation: str, missing_permutations: set[int],
                                  prodigal_results: dict, winners: dict, losers: dict,
                                  n: int, eput: dict, limbo_list: set) -> set[int]:
    """Generates candidate permutations for the completion phase.

    This function focuses on permutations that are likely to connect well with
    the existing superpermutation and fill in the missing permutations.  It
    prioritizes "Prodigal" extensions and uses "Winners/Losers" for guidance.

    Args:
        current_superpermutation (str): The current (incomplete) superpermutation.
        missing_permutations (set): A set of *hashes* of the missing permutations.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        n (int): The value of n.
        eput (dict): The Enhanced Permutation Universe Tracker.
        limbo_list (set): The Limbo List (set of permutation hashes).

    Returns:
        set: A set of permutation *hashes* that are good candidates for insertion.
    """
    candidates = set()
    min_overlap = n - 3  # Consider overlaps of n-1, n-2, and n-3

    # 1. Prioritize permutations that *contain* missing permutations as substrings
    missing_perm_strings = set("".join(str(x) for x in unhash_permutation(h, n)) for h in missing_permutations)
    for missing_perm_str in missing_perm_strings:
        # Find existing permutations that could connect to this missing permutation.
        for prodigal in prodigal_results.values():
            # Check overlaps with the *entire* prodigal sequence
            overlap_start = calculate_overlap(prodigal.sequence, missing_perm_str)
            overlap_end = calculate_overlap(missing_perm_str, prodigal.sequence)

            # Generate extensions, but ONLY if there's sufficient overlap with a prodigal
            if overlap_start >= min_overlap:
                candidates.update(generate_permutations_on_demand(prodigal.sequence, missing_perm_str, prodigal_results, winners, losers, n, eput, limbo_list, overlap_start, {}))
            if overlap_end >= min_overlap:
                candidates.update(generate_permutations_on_demand(missing_perm_str, prodigal.sequence, prodigal_results, winners, losers, n, eput, limbo_list, overlap_end,{}))

    # 2.  Extend the ends of the current superpermutation (if not enough candidates)
    if len(candidates) < COMPLETION_SAMPLE_SIZE:
        prefix = current_superpermutation[:n - 1]
        suffix = current_superpermutation[-(n - 1):]
        candidates.update(generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, eput, limbo_list, min_overlap,{}))

    # 3. "Bridge" to the missing permutations (if still not enough candidates)
    if len(candidates) < COMPLETION_SAMPLE_SIZE:
        for missing_perm_hash in missing_permutations:
            missing_perm = unhash_permutation(missing_perm_hash, n)
            missing_perm_string = "".join(str(x) for x in missing_perm)
            for k in [n - 1, n - 2, n-3]: #Iterate over overlap lengths
                prefix = missing_perm_string[:k]
                suffix = missing_perm_string[-k:]
                candidates.update(generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, eput, limbo_list, k, {}))

    # 4. If *still* not enough candidates, use high-ranking "Winners" (very limited)
    if len(candidates) < COMPLETION_SAMPLE_SIZE and winners:
        top_winners = heapq.nlargest(10, winners.items(), key=lambda item: item[1])  # Limit the number
        for winner, _ in top_winners:
            candidates.update(generate_permutations_on_demand(winner[:n - 1], winner[-(n - 1):], prodigal_results, winners, losers, n, eput, limbo_list, n - 2,{}))


    #Filter, based on eput and limbolist:
    filtered_candidates = set()
    for perm_hash in candidates:
        if perm_hash not in eput and perm_hash not in limbo_list:
            filtered_candidates.add(perm_hash)

    #Return top results:
    scored_candidates = []
    for cand_hash in filtered_candidates:
        score = calculate_score(current_superpermutation, cand_hash, prodigal_results, winners, losers, LayoutMemory(), n, [], {})
        scored_candidates.append((score, cand_hash))

    best_candidates = heapq.nlargest(COMPLETION_SAMPLE_SIZE, scored_candidates, key=lambda item: item[0])
    final_candidates = set(x[1] for x in best_candidates)
    return final_candidates
    
    def generate_permutations_on_demand(prefix: str, suffix: str, prodigal_results: dict, winners: dict, losers: dict,
                                   n: int, eput: dict, limbo_list: set, min_overlap: int,
                                   hypothetical_prodigals: dict = None) -> set[int]:
    """Generates permutations on demand, extending a given prefix or suffix.
       Prioritizes "Prodigal" extensions, uses "Winners" and "Losers," and
       avoids already-used permutations and the "Limbo List."  Also uses laminates.

    Args:
        prefix (str): The prefix of the current superpermutation.
        suffix (str): The suffix of the current superpermutation.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        n (int): The value of n.
        eput (dict): The Enhanced Permutation Universe Tracker.
        limbo_list (set): The set of permutation hashes to avoid.
        min_overlap (int):  The minimum required overlap.
        hypothetical_prodigals (dict): Optional dictionary of Hypothetical Prodigals

    Returns:
        set[int]: A set of *permutation hashes* that are potential extensions.
    """
    valid_permutations = set()

    # Prioritize Prodigal extensions
    for prodigal_id, prodigal in prodigal_results.items():
        if prefix and prodigal.sequence.startswith(prefix[-min_overlap:]):
            for i in range(len(prodigal.sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                if is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                    valid_permutations.add(hash_permutation(perm))
        if suffix and prodigal.sequence.endswith(suffix[:min_overlap]):
            for i in range(len(prodigal.sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                if is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                    valid_permutations.add(hash_permutation(perm))

    # Winner extensions (very small percentage)
    if random.random() < 0.0001 and winners:  # 0.01% chance
        top_winners = heapq.nlargest(10, winners.items(), key=lambda item: item[1])
        chosen_winner = random.choice(top_winners)[0]
        k = len(chosen_winner)
        if prefix and chosen_winner.startswith(prefix[-(k - 1):]):  # Corrected Index
            for i in range(1, n + 1):
                new_perm = tuple(int(x) for x in chosen_winner) + (i,)
                if is_valid_permutation(new_perm, n) and hash_permutation(new_perm) not in eput:
                    valid_permutations.add(hash_permutation(new_perm))
        elif suffix and chosen_winner.endswith(suffix[:(k - 1)]):  # Corrected Index
            for i in range(1, n + 1):
                new_perm = (i,) + tuple(int(x) for x in chosen_winner)
                if is_valid_permutation(new_perm, n) and hash_permutation(new_perm) not in eput:
                    valid_permutations.add(hash_permutation(new_perm))

    # Filter based on Limbo List and create final set of hashes
    filtered_permutations = set()
    for perm_hash in valid_permutations:
        perm_str = "".join(str(x) for x in unhash_permutation(perm_hash, n))
        is_in_limbo = False

        # Basic Loser check (can be expanded)
        for k in [7, 6]:  # Check 7-mers and 6-mers
            for i in range(len(perm_str) - k + 1):
                kmer = perm_str[i:i+k]
                if kmer in limbo_list:
                    is_in_limbo = True
                    break
            if is_in_limbo:
                break

        if not is_in_limbo:
            filtered_permutations.add(perm_hash)

    return filtered_permutations

def generate_permutations_on_demand_hypothetical(current_sequence: str, kmer: str, n: int, k: int) -> set[int]:
    """Generates candidate permutations for hypothetical prodigals. More restrictive.

    Args:
        current_sequence (str): The sequence currently being built
        kmer (str): The k-mer to extend (either prefix or suffix).
        n (int): value of n
        k (int): The k value

    Returns:
        set[int]: A set of permutation *hashes*.
    """
    valid_permutations = set()
    all_perms = generate_permutations(n)  # Get *all* permutations
    for perm in all_perms:
        perm_str = "".join(str(x) for x in perm)
        if kmer == perm_str[:k] or kmer == perm_str[-k:]:
           valid_permutations.add(hash_permutation(perm))

    # We do NOT filter here, as these are for hypotheticals.
    return valid_permutations

def generate_mega_hypotheticals(prodigal_results: dict, winners: dict, losers: dict, n: int, num_to_generate: int = 20, min_length: int = 50, max_length: int = 200) -> dict:
    """Generates 'Mega-Hypothetical' Prodigals by combining existing Prodigals.

    Args:
        prodigal_results (dict): Dictionary of existing ProdigalResult objects.
        winners (dict): "Winner" k-mer data.  Used for scoring connections.
        losers (dict): "Loser" k-mer data. Used for filtering.
        n (int): The value of n.
        num_to_generate (int): The number of Mega-Hypotheticals to generate.
        min_length (int): Minimum length (in permutations).
        max_length (int): Maximum length (in permutations).

    Returns:
        dict: A dictionary of new 'Mega-Hypothetical' ProdigalResult objects.
    """
    mega_hypotheticals = {}
    next_mega_id = -1  # Use negative IDs to distinguish

    for _ in range(num_to_generate):
        num_prodigals_to_combine = random.randint(2, 4)  # Combine 2-4 Prodigals
        #Select prodigals, but with a bias towards those with higher overlap and greater length
        prodigal_weights = [p.overlap_rate * p.length for p in prodigal_results.values()]
        selected_prodigal_ids = random.choices(list(prodigal_results.keys()), weights=prodigal_weights, k=num_prodigals_to_combine)
        selected_prodigals = [prodigal_results[pid] for pid in selected_prodigal_ids]

        # Sort by length, in any order.
        selected_prodigals.sort(key=lambda p: len(p.sequence))

        #Use golden ratio for lengths.
        phi = (1 + math.sqrt(5)) / 2
        total_target_length = random.randint(n * min_length, n* max_length)
        target_lengths = []

        remaining_length = total_target_length
        for i in range(len(selected_prodigals)-1):
            segment_length = int(remaining_length / (phi**(i+1)))
            target_lengths.append(segment_length)
            remaining_length -= segment_length
        target_lengths.append(remaining_length) # Add the final length.

        combined_sequence = ""
        
        #Randomize starting location.
        start_location = random.randint(0,len(selected_prodigals)-1)
        prodigal_order = []
        for i in range(len(selected_prodigals)):
            prodigal_order.append(selected_prodigals[(start_location + i) % len(selected_prodigals)])

        for i in range(len(prodigal_order)):
            prodigal = prodigal_order[i]
            target_length = target_lengths[i]

            # Get a random section of the prodigal, unless it is too short.
            start_index = random.randint(0, max(0, len(prodigal.sequence) - target_length))  # Ensure valid start
            current_sequence = prodigal.sequence[start_index : start_index + target_length]

            # Connect to previous
            if combined_sequence != "":
                overlap = calculate_overlap(combined_sequence, current_sequence)
                if overlap == 0: #Need to use the combiner
                    prefix = combined_sequence[-(n-1):]
                    suffix = current_sequence[:n-1]
                    candidates = generate_permutations_on_demand_hypothetical(prefix, suffix,  n, n-1)
                    if candidates:
                        # Choose the best candidate based on winners/losers (simplified scoring)
                        best_candidate = None
                        best_score = -float('inf')
                        for cand_hash in candidates:
                            cand_perm = unhash_permutation(cand_hash, n)
                            cand_str = "".join(str(x) for x in cand_perm)
                            score = 0
                            for k in [7, 6]: # Using values for n=8
                                for j in range(len(cand_str) - k + 1):
                                    kmer = cand_str[j:j+k]
                                    score += winners.get(kmer, 0)
                                    score -= losers.get(kmer, 0)

                            if score > best_score:
                                best_score = score
                                best_candidate = cand_str

                        overlap = calculate_overlap(combined_sequence, best_candidate)
                        combined_sequence += best_candidate[overlap:]
                    else:
                        continue #Skip if we cannot connect.

                else: #Overlap exists
                    combined_sequence += current_sequence[overlap:]
            else:
                combined_sequence = current_sequence
        
        #Check if prodigal
        perms_in_sequence = set()
        for i in range(len(combined_sequence) - n + 1):
            perm = tuple(int(x) for x in combined_sequence[i:i+n])
            if is_valid_permutation(perm, n):
                perms_in_sequence.add(hash_permutation(perm))

        if analysis_scripts.is_prodigal(combined_sequence, [unhash_permutation(x,n) for x in perms_in_sequence], n, min_length=min_length, overlap_threshold=0.95) and len(perms_in_sequence) > 0:
            mega_hypotheticals[next_mega_id] = ProdigalResult(combined_sequence, next_mega_id)
            next_mega_id -= 1

    return mega_hypotheticals
    
    # START SECTION: Scoring Function (for Completion)

def calculate_score(current_superpermutation: str, permutation_hash: int, prodigal_results: dict,
                    winners: dict, losers: dict, layout_memory: LayoutMemory, n: int,
                    golden_ratio_points: list[int], missing_permutations:set[int]) -> float:
    """Calculates the score for adding a permutation during completion.

    This version is tailored for the completion phase and prioritizes filling
    gaps and connecting to existing structures.

    Args:
        current_superpermutation (str): The current (incomplete) superpermutation.
        permutation_hash (int): The hash of the candidate permutation.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        layout_memory (LayoutMemory): The LayoutMemory object.
        n (int): The value of n.
        golden_ratio_points (list): List of golden ratio points.
        missing_permutations (set): Set of missing permuation hashes.

    Returns:
        float: The score for the candidate permutation. Higher is better.
    """
    permutation = unhash_permutation(permutation_hash, n)
    permutation_string = "".join(str(x) for x in permutation)
    overlap = calculate_overlap(current_superpermutation, permutation_string)
    score = overlap * 5  # Base score based on overlap

    # --- Prodigal Result Bonus (VERY HIGH) ---
    prodigal_bonus = 0
    for prodigal_id, prodigal in prodigal_results.items():
        if permutation_string in prodigal.sequence:
            prodigal_bonus += prodigal.length * 200  # Even Larger bonus during completion
            break  # Only check if contained, not full extension

    # --- Missing Permutation Bonus (CRUCIAL FOR COMPLETION) ---
    missing_bonus = 0
    if permutation_hash in missing_permutations:
        missing_bonus = 10000 # Very Large bonus.

    # --- Winner and Loser Bonus/Penalty (using Layout Memory) ---
    k_values = [n - 1, n - 2]
    layout_bonus = 0
    for k in k_values:
        if len(current_superpermutation) >= k:
            kmer_end = current_superpermutation[-k:]
            kmer_start = permutation_string[:k]
            layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, 1) # Check for adjacency

    # --- Golden Ratio Bonus (small, dynamic) ---
    golden_ratio_bonus = 0
    insertion_point = len(current_superpermutation)
    for point in golden_ratio_points:
        distance = abs(insertion_point - point)
        golden_ratio_bonus += math.exp(-distance / (len(current_superpermutation) / 20))

    # --- Loser Penalty (Veto) ---
    loser_penalty = 0
    for k in [7, 6]:  # Check 7-mers and 6-mers for n=8
         for i in range(len(permutation_string) - k + 1):
            kmer = permutation_string[i:i+k]
            loser_penalty += losers.get(kmer, 0) * 5 # Penalty for losers

    # --- Prodigal Disruption Penalty ---
    prodigal_disruption = 0
    for prodigal_id, prodigal in prodigal_results.items():
        if prodigal.sequence in current_superpermutation:
            # Check if insertion breaks it.
            if not (prodigal.sequence in current_superpermutation[:insertion_point + (n - 1)] and \
                    prodigal.sequence in current_superpermutation[insertion_point - (n - 1):]):
                prodigal_disruption += prodigal.length  # Penalty

    # Higher-Order Winners/Losers
    higher_order_bonus = 0
    for seq_length in [2, 3]:  # Check sequences of length 2 and 3
      if len(current_superpermutation) >= (n * seq_length):
        prev_seq = current_superpermutation[-(n*seq_length):]
        prev_perms = []
        for i in range(len(prev_seq) - n + 1):
            pp = tuple(int(x) for x in prev_seq[i:i+n])
            if is_valid_permutation(pp, n):
                prev_perms.append(hash_permutation(pp))
        if len(prev_perms) >= (seq_length -1):
            current_seq = tuple(prev_perms[-(seq_length - 1):] + [permutation_hash])
            current_seq_hash = hash(current_seq)
            higher_order_bonus += winners.get(current_seq_hash, 0) * 5 # Winner bonus
            loser_penalty += losers.get(current_seq_hash, 0) * 5 # Loser penalty

    score += prodigal_bonus + layout_bonus + golden_ratio_bonus + missing_bonus - loser_penalty - prodigal_disruption + higher_order_bonus

    return score
    
    def complete_superpermutation(superpermutation: str, n: int, all_permutations: list[tuple[int, ...]],
                              prodigal_results: dict, winners: dict, losers: dict,
                              layout_memory: LayoutMemory, limbo_list: set) -> str:
    """Adds missing permutations to a near-complete superpermutation.

    Args:
        superpermutation (str): The initial (incomplete) superpermutation.
        n (int): The value of n.
        all_permutations (list): A list of *all* n! permutations (as tuples).
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers.
        losers (dict): Dictionary of Loser k-mers.
        layout_memory (LayoutMemory): The LayoutMemory object.
        limbo_list (set): The Limbo List.

    Returns:
        str: The completed superpermutation.
    """
    missing_permutations = set()
    s_tuple = tuple(int(x) for x in superpermutation)

    for p in all_permutations:
        found = False
        for i in range(len(s_tuple) - n + 1):
            if s_tuple[i:i+n] == p:
                found = True
                break
        if not found:
            missing_permutations.add(hash_permutation(p))  # Store as hashes

    working_superpermutation = list(superpermutation)  # Convert to list for mutability
    eput = {} #Local ePUT

    #Populate ePUT with current superpermutation data:
    s_tuple = tuple(int(x) for x in superpermutation)
    for i in range(len(s_tuple) - n + 1):
        perm = s_tuple[i:i+n]
        if is_valid_permutation(perm, n):
            perm_hash = hash_permutation(perm)
            if perm_hash not in eput:
              eput[perm_hash] = PermutationData(perm, in_sample = False, creation_method="prodigal") # These are from previous runs
            eput[perm_hash].used_count += 1
            eput[perm_hash].used_in_final = True
            #Update neighbors
            if i > 0:
                prev_perm = s_tuple[i-1:i-1+n]
                if is_valid_permutation(prev_perm, n):
                     eput[perm_hash].neighbors.add(hash_permutation(prev_perm))
            if i < len(s_tuple) - n:
                next_perm = s_tuple[i+1:i+1+n]
                if is_valid_permutation(next_perm, n):
                    eput[perm_hash].neighbors.add(hash_permutation(next_perm))
    
    # --- Main Completion Loop ---
    num_added = 0
    total_missing = len(missing_permutations)
    
    #Create initial hypothetical prodigals
    hypothetical_prodigals = analysis_scripts.generate_hypothetical_prodigals(prodigal_results, winners, losers, n)
    
    while missing_permutations: # Continue until all permutations are added
        
        #Randomly select missing permutation
        missing_perm_hash = random.choice(list(missing_permutations))
        missing_perm = unhash_permutation(missing_perm_hash, n)
        best_insertion_point = -1
        best_score = -float('inf')

        # 1. Generate Targeted Candidates (using the modified function)
        candidates = generate_completion_candidates(
            "".join(str(x) for x in working_superpermutation),  # Current superperm
            missing_permutations,  # Remaining missing perms
            prodigal_results,       # Prodigal results
            winners,               # Winners
            losers,                # Losers
            n,                     # n
            eput,                  # ePUT
            limbo_list             # Limbo list
        )

        # 2. Evaluate Candidates and Insert (using the enhanced scoring function)
        golden_ratio_points = calculate_golden_ratio_points(len(working_superpermutation), levels=3)
        for candidate_hash in candidates:
            candidate_perm = unhash_permutation(candidate_hash, n)
            candidate_string = "".join(str(x) for x in candidate_perm)

            for i in range(len(working_superpermutation) + 1):
                # Calculate overlap if inserted here.
                overlap_start = calculate_overlap("".join(str(x) for x in working_superpermutation[max(0,i-(n-1)):i]), candidate_string)
                overlap_end = calculate_overlap(candidate_string, "".join(str(x) for x in working_superpermutation[i:i+(n-1)]))
                overlap = max(overlap_start, overlap_end)

                # "Prodigal Disruption":
                prodigal_disruption = 0
                for prodigal_id, prodigal in prodigal_results.items():
                    if prodigal.sequence in "".join(str(x) for x in working_superpermutation):
                        # Check if insertion breaks it.
                        if not (prodigal.sequence in "".join(str(x) for x in working_superpermutation[:i + (n - 1)]) and \
                                prodigal.sequence in "".join(str(x) for x in working_superpermutation[i - (n - 1):])):
                            prodigal_disruption += prodigal.length  # Penalty

                # Golden Ratio Bonus
                golden_ratio_bonus = 0
                for point in golden_ratio_points:
                    distance = abs(i - point)
                    golden_ratio_bonus += math.exp(-distance / (len(working_superpermutation) / 20))

                # Winner/Loser Bonus/Penalty (using Layout Memory)
                k_values = [n - 1, n - 2]
                layout_bonus = 0
                for k in k_values:
                    if i >= k:
                        kmer_end = "".join(str(x) for x in working_superpermutation[i-k:i])
                        kmer_start = candidate_string[:k]
                        layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, (len(working_superpermutation)-i) if overlap == 0 else 1)  # Use correct distance
                    kmer_end = candidate_string[-k:]
                    kmer_start = "".join(str(x) for x in working_superpermutation[i:i+k])
                    layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, 1)

                # --- Prodigal Bonus ---
                prodigal_bonus = 0
                for p_id, p_data in prodigal_results.items():
                    if candidate_string in p_data.sequence:
                        prodigal_bonus = p_data.length * 200
                        break

                # --- Loser Penalty (Veto) ---
                loser_penalty = 0
                for k in [7, 6]:  # Check 7-mers and 6-mers
                    for j in range(len(candidate_string) - k + 1):
                        kmer = candidate_string[j:j+k]
                        loser_penalty += losers.get(kmer, 0) * 5

                # --- Missing Permutation Bonus (CRUCIAL) ---
                missing_bonus = 0
                if candidate_hash in missing_permutations:
                    missing_bonus = 10000 # Very Large bonus.

                 # Higher-Order Winners/Losers
                higher_order_bonus = 0
                for seq_length in [2, 3]:  # Check sequences of length 2 and 3
                  if len(current_superpermutation) >= (n * seq_length):
                    prev_seq = current_superpermutation[-(n*seq_length):]
                    prev_perms = []
                    for i in range(len(prev_seq) - n + 1):
                        pp = tuple(int(x) for x in prev_seq[i:i+n])
                        if is_valid_permutation(pp, n):
                            prev_perms.append(hash_permutation(pp))
                    if len(prev_perms) >= (seq_length -1):
                        current_seq = tuple(prev_perms[-(seq_length - 1):] + [permutation_hash])
                        current_seq_hash = hash(current_seq)
                        higher_order_bonus += winners.get(current_seq_hash, 0) * 5
                        loser_penalty += losers.get(current_seq_hash, 0) * 5

                score = (overlap * 5) + layout_bonus + golden_ratio_bonus + missing_bonus + prodigal_bonus - loser_penalty - prodigal_disruption + higher_order_bonus

                if score > best_score:
                    best_score = score
                    best_insertion_point = i

        # --- Insertion ---
        if best_insertion_point != -1: #Should always find a spot
            #print(f"Inserting permutation: {unhash_permutation(missing_perm_hash, n)} at position {best_insertion_point}")
            working_superpermutation = working_superpermutation[:best_insertion_point] + list(str(x) for x in missing_perm) + working_superpermutation[best_insertion_point:]
            num_added += 1

            # --- Local Optimization (Swapping) ---
            for j in range(max(0, best_insertion_point - 10), min(len(working_superpermutation) - n, best_insertion_point + n + 10)):
                original_perm = tuple(int(x) for x in working_superpermutation[j:j + n])
                if not is_valid_permutation(original_perm,n):
                    continue
                for k in range(j + 1, min(len(working_superpermutation) - n, best_insertion_point + n * 2 + 10)):
                    compare_perm = tuple(int(x) for x in working_superpermutation[k:k + n])
                    if not is_valid_permutation(compare_perm,n):
                        continue
                    # Calculate overlap before and after swap
                    overlap_before = calculate_overlap("".join(str(x) for x in working_superpermutation[j - n:j]),
                                                     "".join(str(x) for x in original_perm)) + \
                                     calculate_overlap("".join(str(x) for x in original_perm),
                                                     "".join(str(x) for x in working_superpermutation[j + n:j + 2 * n]))

                    overlap_after = calculate_overlap("".join(str(x) for x in working_superpermutation[j - n:j]),
                                                    "".join(str(x) for x in compare_perm)) + \
                                    calculate_overlap("".join(str(x) for x in compare_perm),
                                                    "".join(str(x) for x in working_superpermutation[j + n:j + 2 * n]))

                    if overlap_after > overlap_before:
                        # Perform Swap
                        temp = working_superpermutation[j:j + n]
                        working_superpermutation[j:j + n] = working_superpermutation[k:k + n]
                        working_superpermutation[k:k + n] = temp

            #Update ePUT
            perm_hash = missing_perm_hash
            if perm_hash not in eput: #Should now always be the case.
               eput[perm_hash] = PermutationData(missing_perm, in_sample = False, creation_method="completion")
            eput[perm_hash].used_count = 1
            eput[perm_hash].used_in_final = True
            #Update neighbors in ePUT.  Less important here.
            perm_string = "".join(str(x) for x in missing_perm)
            for k in [n-1, n-2]:
                prefix = "".join(str(x) for x in working_superpermutation[:best_insertion_point + k])
                suffix = "".join(str(x) for x in working_superpermutation[best_insertion_point + len(perm_string)-k:])

                prefix_perms = set()
                suffix_perms = set()
                for i in range(len(prefix) - n + 1):
                    p = tuple(int(x) for x in prefix[i:i+n])
                    if is_valid_permutation(p,n):
                        prefix_perms.add(hash_permutation(p))
                for i in range(len(suffix) - n + 1):
                    p = tuple(int(x) for x in suffix[i:i+n])
                    if is_valid_permutation(p,n):
                        suffix_perms.add(hash_permutation(p))

                for other_perm_hash in prefix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        #Add to layout memory:
                        kmer1 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[-k:])
                        kmer2 = perm_string[:k]
                        layout_memory.update_distances(kmer1,kmer2, len(prefix) - i - k, "n8_completion")
                for other_perm_hash in suffix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        kmer1 = perm_string[-k:]
                        kmer2 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[:k])
                        layout_memory.update_distances(kmer1, kmer2, 1, "n8_completion")
            #Update Prodigals:
            new_prodigals = analysis_scripts.find_prodigal_results("".join(working_superpermutation), n, min_length=PRODIGAL_MIN_LENGTH, overlap_threshold=PRODIGAL_OVERLAP_THRESHOLD)
            for prodigal_seq in new_prodigals:
                is_new = True
                for existing_prodigal_id, existing_prodigal in prodigal_results.items():
                    if prodigal_seq in existing_prodigal.sequence:
                        is_new = False
                        break
                if is_new:
                    new_id = len(prodigal_results) + 1
                    prodigal_results[new_id] = ProdigalResult(prodigal_seq, new_id)
                    #print(f"New Prodigal Result found in completion: {prodigal_seq}")

        #Remove from missing
        missing_permutations.remove(missing_perm_hash)

        #Adjust Overlap Threshold and Length Threshold - Dynamic Adjustment
        missing_count = len(missing_permutations)
        if (missing_count % 500 == 0):
            print(f"Missing {missing_count} permutations")

    return "".join(working_superpermutation)
    
    # START SECTION: Main Function

def main():
    """
    Main function to execute the n=8 superpermutation completion algorithm.
    """
    n = 8

    # --- File Paths (IMPORTANT: Adjust these paths as needed) ---
    incomplete_superpermutation_file = "superpermutation_n8_best_dynamic.txt"  # Input: Best *incomplete* superpermutation
    winners_losers_file = "winners_losers_data_n8_dynamic.txt"  # Input: Winner/Loser data
    prodigal_results_file = "prodigal_results_n8_dynamic.txt"  # Input: Prodigal Results data
    layout_memory_file = "layout_memory_n8.pkl"  # Input
    output_superpermutation_file = "superpermutation_n8_complete.txt"  # Output: Completed superpermutation

    # --- Load Data ---
    try:
        with open(incomplete_superpermutation_file, "r") as f:
            superpermutation = f.read().strip()
    except FileNotFoundError:
        print(f"Error: Incomplete superpermutation file not found: {incomplete_superpermutation_file}")
        return

    winners, losers = {}, {}
    try:
        with open(winners_losers_file, "r") as f:
            for line in f:
                kmer, w_type, weight = line.strip().split(",")
                if w_type == "winner":
                    winners[kmer] = int(weight)
                elif w_type == "loser":
                    losers[kmer] = int(weight)
    except FileNotFoundError:
        print(f"Error: Winners/Losers file not found: {winners_losers_file}")
        return
 

    prodigal_results = {}
    try:
        with open(prodigal_results_file, 'r') as f:
            for line in f:
                sequence = line.strip()
                next_prodigal_id = len(prodigal_results)
                prodigal_results[next_prodigal_id] = analysis_scripts.ProdigalResult(sequence, next_prodigal_id)
    except FileNotFoundError:
        print(f"Error: Prodigal Results file not found: {prodigal_results_file}")
        return

    layout_memory = LayoutMemory()
    try:
        layout_memory.load_from_file(layout_memory_file)
        print("Loaded LayoutMemory")
    except:
        print("Layout Memory could not be loaded.")

    # --- Generate all n=8 permutations ---
    all_permutations = generate_permutations(n)

    # --- Limbo List (Load or create) ---
    limbo_list = set()  # Start with an empty Limbo List for completion

    # --- ePUT (Start Empty) ---
    eput = {} #Start with empty

    # --- Call the Completion Algorithm ---
    print(f"Starting completion process for n={n}...")
    start_time = time.time()
    completed_superpermutation = complete_superpermutation(
        superpermutation, n, all_permutations, prodigal_results, winners,
        losers, layout_memory, limbo_list
    )
    end_time = time.time()

    print(f"Completion completed in {end_time - start_time:.2f} seconds.")
    print(f"Final superpermutation length: {len(completed_superpermutation)}")

    # --- Verify ---
    analysis_results = analysis_scripts.analyze_superpermutation(completed_superpermutation, n)
    print(f"Verification Result: {analysis_results['validity']}")
    if not analysis_results['validity']:
        print("WARNING: Superpermutation is NOT valid!")
        print("Missing permutations:", analysis_results['missing_permutations'])


    # --- Save Results ---
    with open(output_superpermutation_file, "w") as f:
        f.write(completed_superpermutation)
    print(f"Complete superpermutation saved to {output_superpermutation_file}")

    #Update and save winner/loser data
    new_winners, new_losers = analysis_scripts.calculate_winners_losers([completed_superpermutation], n, k=7)
    new_winners2, new_losers2 = analysis_scripts.calculate_winners_losers([completed_superpermutation], n, k=8)
    for kmer, weight in new_winners.items():
        winners[kmer] = winners.get(kmer, 0) + weight
    for kmer, weight in new_losers.items():
        losers[kmer] = losers.get(kmer, 0) + weight
        limbo_list.add(kmer)  # Add to limbo list
    for kmer, weight in new_winners2.items():
        winners[kmer] = winners.get(kmer, 0) + weight
    for kmer, weight in new_losers2.items():
        losers[kmer] = losers.get(kmer, 0) + weight
        limbo_list.add(kmer)

    with open(winners_losers_file, "w") as f:
        for kmer, weight in winners.items():
            f.write(f"{kmer},winner,{weight}\n")
        for kmer, weight in losers.items():
            f.write(f"{kmer},loser,{weight}\n") # Loser weight should always be positive

    #Update and save prodigal results:
    new_prodigals = analysis_scripts.find_prodigal_results(completed_superpermutation, n)
    next_prodigal_id = len(prodigal_results)
    for prodigal_seq in new_prodigals:
        is_new = True
        for existing_prodigal_id, existing_prodigal in prodigal_results.items():
            if prodigal_seq in existing_prodigal.sequence:
                is_new = False
                break
        if is_new:
            prodigal_results[next_prodigal_id] = ProdigalResult(prodigal_seq, next_prodigal_id)
            next_prodigal_id += 1
    with open(prodigal_results_file, "w") as f:
        for prodigal_id, prodigal in prodigal_results.items():
            f.write(f"{prodigal.sequence}\n")

    #Update Layout memory
    layout_memory.add_sequence(completed_superpermutation, n, 7, "n8_completion")
    layout_memory.add_sequence(completed_superpermutation, n, 6, "n8_completion")
    layout_memory.save_to_file(layout_memory_file)


if __name__ == "__main__":
    random.seed(RANDOM_SEED)
    main()

```