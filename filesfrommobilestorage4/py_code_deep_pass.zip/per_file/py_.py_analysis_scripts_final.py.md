# File: py/.py/analysis_scripts_final.py

**Extension:** .py

**Lines:** 657 | **Words:** 3014

## Keyword Hits

- SFBB: 0

- superperm: 67

- superpermutation: 59

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 8

- debruijn: 2

- beam: 0

- orchestrator: 0

- hash: 43

- golden: 4

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: heapq, itertools, math, networkx, random

- From-imports: collections

- Classes (0): (none)

- Functions (22): calculate_overlap, hash_permutation, unhash_permutation, is_valid_permutation, get_kmers, calculate_golden_ratio_points, calculate_fixed_segments, generate_permutations, analyze_superpermutation, is_prodigal, find_prodigal_results, calculate_winners_losers, calculate_sequence_winners_losers, identify_anti_prodigals, build_debruijn_graph, add_weights_to_debruijn, find_cycles, find_high_weight_paths, generate_permutations_on_demand_hypothetical, generate_mega_hypotheticals, dfs, dfs


---


## Full Source


```text

import itertools
import math
import networkx as nx
from collections import deque, defaultdict
import heapq
import random  #Needed for Hypothetical Prodigal Generation


def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings.

    Args:
        s1 (str): The first string.
        s2 (str): The second string.

    Returns:
        int: The length of the maximum overlap. Returns 0 if there is no overlap.
    """
    max_overlap = 0
    for i in range(1, min(len(s1), len(s2)) + 1):
        if s1[-i:] == s2[:i]:
            max_overlap = i
    return max_overlap


def hash_permutation(permutation: tuple) -> int:
    """Hashes a permutation tuple to a unique integer.

    Args:
        permutation: The permutation tuple (e.g., (1, 2, 3, 4, 5, 6, 7, 8)).

    Returns:
        A unique integer hash value.
    """
    result = 0
    n = len(permutation)
    for i, val in enumerate(permutation):
        result += val * (n ** (n - 1 - i))
    return result


def unhash_permutation(hash_value: int, n: int) -> tuple:
    """Converts a hash value back to a permutation tuple.

    Args:
        hash_value: The integer hash value.
        n: The value of n.

    Returns:
        The corresponding permutation tuple.
    """
    permutation = []
    for i in range(n - 1, -1, -1):
        val = hash_value // (n ** i)
        permutation.append(val + 1)  # Adjust to be 1-indexed
        hash_value -= val * (n ** i)
    return tuple(permutation)


def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a given sequence is a valid permutation.

    Args:
        perm: The sequence (tuple of integers).
        n: The value of n.

    Returns:
        True if the sequence is a valid permutation, False otherwise.
    """
    return len(set(perm)) == n and min(perm) == 1 and max(perm) == n


def get_kmers(sequence: str, n: int, k: int) -> set[str]:
    """Extracts all k-mers from a sequence of digits, ensuring they form valid permutations.

    Args:
        sequence: The input sequence (string of digits).
        n: The value of n.
        k: The length of the k-mers to extract.

    Returns:
        A set of k-mer strings.
    """
    kmers = set()
    seq_list = [int(x) for x in sequence]  # Ensure sequence is treated as digits
    for i in range(len(sequence) - n + 1):
        perm = tuple(seq_list[i:i + n])
        if is_valid_permutation(perm, n):
            if i >= k:
                kmer = "".join(str(x) for x in seq_list[i - k:i])
                kmers.add(kmer)
    return kmers


def calculate_golden_ratio_points(length: int, levels: int = 1) -> list[int]:
    """Calculates multiple levels of golden ratio points within a sequence.

    Args:
        length (int): The total length of the sequence.
        levels (int): The number of recursive divisions to perform.

    Returns:
        list: A sorted list of unique golden ratio points (integers).
    """
    phi = (1 + math.sqrt(5)) / 2
    points = []
    for _ in range(levels):
        new_points = []
        if not points:
            new_points = [int(length / phi), int(length - length / phi)]
        else:
            for p in points:
                new_points.extend([int(p / phi), int(p - p / phi)])
                new_points.extend([int((length - p) / phi) + p, int(length - (length - p) / phi)])
        points.extend(new_points)
        points = sorted(list(set(points)))  # Remove duplicates and sort
    return points


def calculate_fixed_segments(length: int, segment_size: int, overlap_size: int) -> list[tuple[int, int]]:
    """Calculates start and end indices for fixed-size segments with overlap.

    Args:
        length (int): The total length of the sequence.
        segment_size (int): The desired size of each segment.
        overlap_size (int): The desired overlap between adjacent segments.

    Returns:
        list: A list of tuples, where each tuple contains the (start, end) indices of a segment.
    """
    segments = []
    start = 0
    while start < length:
        end = min(start + segment_size, length)
        segments.append((start, end))
        start += segment_size - overlap_size
    return segments

def generate_permutations(n: int) -> list[tuple[int, ...]]:
    """Generates all permutations of 1 to n.  Used for creating complete sets.

    Args:
        n (int): The number of symbols.

    Returns:
        list[tuple[int, ...]]: A list of all permutations as tuples.
    """
    return list(itertools.permutations(range(1, n + 1)))

# --- Superpermutation Analysis ---

def analyze_superpermutation(superpermutation: str, n: int) -> dict:
    """Analyzes a given superpermutation and provides statistics.

    Args:
        superpermutation (str): The superpermutation string.
        n (int): The value of n (number of symbols).

    Returns:
        dict: A dictionary containing:
            - length: The length of the superpermutation.
            - validity: True if valid, False otherwise.
            - missing_permutations: A list of missing permutations (empty if valid).
            - overlap_distribution: A dictionary showing counts of each overlap length.
            - average_overlap: The average overlap between consecutive permutations.
    """
    permutations = set(itertools.permutations(range(1, n + 1)))
    s_tuple = tuple(int(x) for x in superpermutation)
    found_permutations = set()
    missing_permutations = []
    overlap_distribution = {}

    total_overlap = 0

    for i in range(len(s_tuple) - n + 1):
        perm = s_tuple[i:i+n]
        if is_valid_permutation(perm, n):  # Valid
            found_permutations.add(tuple(perm))  # Use tuples for set
            if i > 0:
                overlap = calculate_overlap("".join(str(x) for x in s_tuple[i-n:i]), "".join(str(x) for x in perm))
                total_overlap += overlap
                overlap_distribution[overlap] = overlap_distribution.get(overlap, 0) + 1

    missing_permutations = list(permutations - found_permutations)
    validity = len(missing_permutations) == 0
    average_overlap = total_overlap / (len(found_permutations) - 1) if len(found_permutations) > 1 else 0

    return {
        "length": len(superpermutation),
        "validity": validity,
        "missing_permutations": missing_permutations,
        "overlap_distribution": overlap_distribution,
        "average_overlap": average_overlap,
    }

# --- Prodigal Result Identification ---

def is_prodigal(sequence: str, permutations_in_sequence: list[tuple[int]], n: int, min_length: int, overlap_threshold: float) -> bool:
    """Checks if a sequence is a 'Prodigal Result'.

    Args:
        sequence (str): The sequence of digits to check.
        permutations_in_sequence (list):  A list of *tuples* representing the
                                         permutations contained within the sequence.
        n (int): The value of n.
        min_length (int): The minimum number of permutations for a "Prodigal Result."
        overlap_threshold (float): The minimum overlap rate (0 to 1).

    Returns:
        bool: True if the sequence is a "Prodigal Result," False otherwise.
    """
    if len(permutations_in_sequence) < min_length:
        return False

    total_length = sum(len(str(p)) for p in permutations_in_sequence)
    overlap_length = total_length - len(sequence)
    max_possible_overlap = (len(permutations_in_sequence) - 1) * (n - 1)

    if max_possible_overlap == 0:
        return False
    return (overlap_length / max_possible_overlap) >= overlap_threshold

def find_prodigal_results(superpermutation: str, n: int, min_length: int = None, overlap_threshold: float = 0.98) -> list[str]:
    """Identifies and returns a list of prodigal results within a given superpermutation.

    Args:
        superpermutation (str): The superpermutation string.
        n (int): The value of n.
        min_length (int): Minimum number of permutations in a prodigal result.
                          Defaults to n-1.  This can be dynamically adjusted.
        overlap_threshold (float): Minimum overlap percentage. Defaults to 0.98,
                                   but can be dynamically adjusted.

    Returns:
        list: A list of "Prodigal Result" sequences (strings).
    """
    prodigal_results = []
    superperm_list = [int(x) for x in superpermutation]  # Convert to list of integers
    if min_length is None:
        min_length = n-1

    for length in range(n * min_length, len(superpermutation) + 1):  # Iterate through possible lengths
        for i in range(len(superpermutation) - length + 1):  # Iterate through starting positions
            subsequence = tuple(superperm_list[i:i+length])  # Get the subsequence as a tuple
            permutations_in_subsequence = set()
            for j in range(len(subsequence) - n + 1):
                perm = subsequence[j:j+n]
                if is_valid_permutation(perm, n):  # Valid permutation
                    permutations_in_subsequence.add(tuple(perm))  # Use tuples for set membership

            if is_prodigal(subsequence, list(permutations_in_subsequence), n, min_length, overlap_threshold):
                prodigal_results.append("".join(str(x) for x in subsequence))  # Store as string
    return prodigal_results

    # --- Winner/Loser Calculation ---

def calculate_winners_losers(superpermutations: list[str], n: int, k: int) -> tuple[dict, dict]:
    """Calculates "Winner" and "Loser" k-mer weights from a list of superpermutations.

    Args:
        superpermutations (list): A list of superpermutation strings.
        n (int): The value of n.
        k (int): The length of the k-mers to analyze.

    Returns:
        tuple: (winners, losers), where:
            - winners: A dictionary of {kmer: weight} for winning k-mers.
            - losers: A dictionary of {kmer: weight} for losing k-mers.
    """

    all_kmers = {}  # {kmer: total_count}
    for superpermutation in superpermutations:
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n):  # Valid
                if i > 0:
                    kmer = "".join(str(x) for x in s_tuple[i - k:i])
                    all_kmers[kmer] = all_kmers.get(kmer, 0) + 1

    # Divide into "shorter" and "longer" groups based on median length
    lengths = [len(s) for s in superpermutations]
    lengths.sort()
    median_length = lengths[len(lengths) // 2]
    shorter_superpermutations = [s for s in superpermutations if len(s) <= median_length]
    longer_superpermutations = [s for s in superpermutations if len(s) > median_length]

    winners = {}  # {kmer: weight}
    losers = {}  # {kmer: weight}

    shorter_counts = {}  # {kmer: count_in_shorter}
    for superpermutation in shorter_superpermutations:
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n):
                if i > 0:
                    kmer = "".join(str(x) for x in s_tuple[i - k:i])
                    shorter_counts[kmer] = shorter_counts.get(kmer, 0) + 1

    longer_counts = {}  # {kmer: count_in_longer}
    for superpermutation in longer_superpermutations:
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n):
                if i > 0:
                    kmer = "".join(str(x) for x in s_tuple[i - k:i])
                    longer_counts[kmer] = longer_counts.get(kmer, 0) + 1

    # Calculate weights based on the difference in counts
    for kmer in all_kmers:
        score = shorter_counts.get(kmer, 0) - longer_counts.get(kmer, 0)
        if score > 0:
            winners[kmer] = score
        elif score < 0:
            losers[kmer] = -score  # Store as positive weights

    return winners, losers


def calculate_sequence_winners_losers(superpermutations: list[str], n: int, sequence_length: int = 2) -> tuple[dict, dict]:
    """Calculates 'Winner' and 'Loser' weights for sequences of permutations.

    Args:
        superpermutations (list[str]): List of superpermutation strings.
        n (int): The value of n.
        sequence_length (int): The length of the permutation sequences to analyze (default: 2).

    Returns:
        tuple: (winners, losers), where winners and losers are dictionaries
               mapping sequence hashes (integers) to weights.
    """
    all_sequences = {} # {seq_hash : count}

    for superperm in superpermutations:
        s_tuple = tuple(int(x) for x in superperm)
        perms = []
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perms.append(hash_permutation(perm))  # Append hash

        for i in range(len(perms) - (sequence_length -1)):
            seq = tuple(perms[i:i+sequence_length])
            seq_hash = hash(seq) #Hash the sequence of hashes.
            all_sequences[seq_hash] = all_sequences.get(seq_hash, 0) + 1

    #Divide into "shorter" and "longer"
    lengths = [len(s) for s in superpermutations]
    lengths.sort()
    median_length = lengths[len(lengths)//2]
    shorter_superpermutations = [s for s in superpermutations if len(s) <= median_length]
    longer_superpermutations = [s for s in superpermutations if len(s) > median_length]

    winners = {}
    losers = {}
    shorter_counts = {}
    for superperm in shorter_superpermutations:
        s_tuple = tuple(int(x) for x in superperm)
        perms = []
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perms.append(hash_permutation(perm)) #Append hash
        for i in range(len(perms) - (sequence_length - 1)):
            seq = tuple(perms[i:i+sequence_length])
            seq_hash = hash(seq)
            shorter_counts[seq_hash] = shorter_counts.get(seq_hash, 0) + 1

    longer_counts = {}
    for superperm in longer_superpermutations:
        s_tuple = tuple(int(x) for x in superperm)
        perms = []
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perms.append(hash_permutation(perm))
        for i in range(len(perms) - (sequence_length - 1)):
            seq = tuple(perms[i:i+sequence_length])
            seq_hash = hash(seq)
            longer_counts[seq_hash] = longer_counts.get(seq_hash, 0) + 1

    for seq_hash in all_sequences:
        score = shorter_counts.get(seq_hash, 0) - longer_counts.get(seq_hash, 0)
        if score > 0:
            winners[seq_hash] = score
        if score < 0:
            losers[seq_hash] = -score

    return winners, losers

# --- Anti-Prodigal Identification ---
def identify_anti_prodigals(superpermutations, n, k, overlap_threshold):
    """Identifies and returns a list of 'anti-prodigal' k-mers.

    Args:
        superpermutations (list): A list of superpermutation strings.
        n (int): The value of n.
        k (int): The length of k-mers.
        overlap_threshold (float): The *maximum* overlap allowed for an anti-prodigal

    Returns:
        set: A set of 'anti-prodigal' k-mers (strings).
    """
    anti_prodigals = set()
    for superpermutation in superpermutations:
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n):  # Valid
                if i > k:
                    kmer = "".join(str(x) for x in s_tuple[i-k:i])
                    overlap = calculate_overlap("".join(str(x) for x in s_tuple[i-k:i]), "".join(str(x) for x in perm))
                    if overlap < ( (n-1) * overlap_threshold):  #  Condition for Anti-Prodigal
                        anti_prodigals.add(kmer)
    return anti_prodigals
    
    # --- De Bruijn Graph Functions ---

def build_debruijn_graph(n: int, k: int, permutations=None, superpermutation=None) -> nx.DiGraph:
    """Builds a De Bruijn graph of order k for permutations of n symbols.

    Args:
        n: The number of symbols (e.g., 8 for n=8).
        k: The order of the De Bruijn graph (k-mers).
        permutations: (Optional) A list of permutation tuples.  If provided,
                      the graph is built ONLY from these permutations.
        superpermutation: (Optional) A superpermutation string. If provided,
                          the graph is built from the k-mers in this string.
                          Must provide one, and only one, of the two.

    Returns:
        A networkx.DiGraph representing the De Bruijn graph.
    """

    if (permutations is None and superpermutation is None) or (permutations is not None and superpermutation is not None):
        raise ValueError("Must provide either 'permutations' or 'superpermutation', but not both.")

    graph = nx.DiGraph()

    if permutations:
      for perm in permutations:
          perm_str = "".join(str(x) for x in perm)
          for i in range(len(perm_str) - k + 1):
              kmer1 = perm_str[i:i + k - 1]
              kmer2 = perm_str[i + 1:i + k]
              if len(kmer1) == k - 1 and len(kmer2) == k-1: #Should always be true
                graph.add_edge(kmer1, kmer2, weight=calculate_overlap(kmer1, kmer2))
    else: #Use superpermutation
        s_list = [int(x) for x in superpermutation]
        for i in range(len(s_list) - n + 1):
            perm = tuple(s_list[i:i+n])
            if is_valid_permutation(perm, n):
                #Valid permutation.
                if i >= k:
                  kmer1 = "".join(str(x) for x in s_list[i-k:i])
                  kmer2 = "".join(str(x) for x in s_list[i-k+1: i+1])
                  if len(kmer1) == k - 1 and len(kmer2) == k - 1:
                    graph.add_edge(kmer1, kmer2, weight = calculate_overlap(kmer1,kmer2))
    return graph

def add_weights_to_debruijn(graph: nx.DiGraph, winners: dict, losers: dict):
    """Adds 'winner_weight' and 'loser_weight' attributes to the edges of a De Bruijn graph.

    Args:
        graph: The De Bruijn graph (networkx.DiGraph).
        winners: A dictionary of Winner k-mers and their weights.
        losers: A dictionary of Loser k-mers and their weights.
    """

    for u, v, data in graph.edges(data=True):
        kmer = u[1:] + v[-1]  # Reconstruct the k-mer from the edge
        data['winner_weight'] = winners.get(kmer, 0)
        data['loser_weight'] = losers.get(kmer, 0)

def find_cycles(graph: nx.DiGraph) -> list[list[str]]:
    """Finds cycles in the De Bruijn graph using a simple DFS approach."""
    cycles = []
    visited = set()

    def dfs(node, path):
        visited.add(node)
        path.append(node)

        for neighbor in graph.neighbors(node):
            if neighbor == path[0] and len(path) > 1:  # Found a cycle
                cycles.append(path.copy())
            elif neighbor not in visited:
                dfs(neighbor, path)

        path.pop()
        visited.remove(node) #Correctly remove node

    for node in graph.nodes:
        if node not in visited:
            dfs(node, [])
    return cycles

def find_high_weight_paths(graph: nx.DiGraph, start_node: str, length_limit: int) -> list[list[str]]:
    """
    Finds high-weight paths in the De Bruijn graph starting from a given node.
    """
    best_paths = []
    best_score = -float('inf')

    def dfs(current_node, current_path, current_score):
        nonlocal best_score
        nonlocal best_paths

        if len(current_path) > length_limit:
            return

        current_score_adj = current_score
        if len(current_path) > 1:
            current_score_adj = current_score / (len(current_path)-1) #Average

        if current_score_adj > best_score:
            best_score = current_score_adj
            best_paths = [current_path.copy()]  # New best path
        elif current_score_adj == best_score and len(current_path) > 1: #Dont include starting nodes
            best_paths.append(current_path.copy())  # Add to list of best paths

        for neighbor in graph.neighbors(current_node):
            edge_data = graph.get_edge_data(current_node, neighbor)
            new_score = current_score + edge_data.get('weight', 0) + edge_data.get('winner_weight', 0) - edge_data.get('loser_weight', 0)
            dfs(neighbor, current_path + [neighbor], new_score)

    dfs(start_node, [start_node], 0)
    return best_paths

# --- Hypothetical Prodigal Generation ---
def generate_permutations_on_demand_hypothetical(current_sequence: str, kmer: str, n: int, k: int) -> set[int]:
    """Generates candidate permutations for hypothetical prodigals. More restrictive.

    Args:
        current_sequence (str): The sequence currently being built
        kmer (str): The k-mer to extend (either prefix or suffix).
        n (int): value of n
        k (int): The k value

    Returns:
        set[int]: A set of permutation *hashes*.
    """
    valid_permutations = set()
    all_perms = generate_permutations(n)  # Get *all* permutations
    for perm in all_perms:
        perm_str = "".join(str(x) for x in perm)
        if kmer == perm_str[:k] or kmer == perm_str[-k:]:
           valid_permutations.add(hash_permutation(perm))

    # We do NOT filter here, as these are for hypotheticals.
    return valid_permutations

def generate_mega_hypotheticals(prodigal_results: dict, winners: dict, losers: dict, n: int, num_to_generate: int = 20, min_length: int = 50, max_length: int = 200) -> dict:
    """Generates 'Mega-Hypothetical' Prodigals by combining existing Prodigals.

    Args:
        prodigal_results (dict): Dictionary of existing ProdigalResult objects.
        winners (dict): "Winner" k-mer data.  Used for scoring connections.
        losers (dict): "Loser" k-mer data. Used for filtering.
        n (int): The value of n.
        num_to_generate (int): The number of Mega-Hypotheticals to generate.
        min_length (int): Minimum length (in permutations).
        max_length (int): Maximum length (in permutations).

    Returns:
        dict: A dictionary of new 'Mega-Hypothetical' ProdigalResult objects.
    """
    mega_hypotheticals = {}
    next_mega_id = -1  # Use negative IDs to distinguish

    for _ in range(num_to_generate):
        num_prodigals_to_combine = random.randint(2, 4)  # Combine 2-4 Prodigals
        #Select prodigals, but with a bias towards those with higher overlap and greater length
        prodigal_weights = [p.overlap_rate * p.length for p in prodigal_results.values()]
        selected_prodigal_ids = random.choices(list(prodigal_results.keys()), weights=prodigal_weights, k=num_prodigals_to_combine)
        selected_prodigals = [prodigal_results[pid] for pid in selected_prodigal_ids]

        # Sort by length, in any order.
        selected_prodigals.sort(key=lambda p: len(p.sequence))

        #Use golden ratio for lengths.
        phi = (1 + math.sqrt(5)) / 2
        total_target_length = random.randint(n * min_length, n* max_length)
        target_lengths = []

        remaining_length = total_target_length
        for i in range(len(selected_prodigals)-1):
            segment_length = int(remaining_length / (phi**(i+1)))
            target_lengths.append(segment_length)
            remaining_length -= segment_length
        target_lengths.append(remaining_length) # Add the final length.

        combined_sequence = ""
        
        #Randomize starting location.
        start_location = random.randint(0,len(selected_prodigals)-1)
        prodigal_order = []
        for i in range(len(selected_prodigals)):
            prodigal_order.append(selected_prodigals[(start_location + i) % len(selected_prodigals)])

        for i in range(len(prodigal_order)):
            prodigal = prodigal_order[i]
            target_length = target_lengths[i]

            # Get a random section of the prodigal, unless it is too short.
            start_index = random.randint(0, max(0, len(prodigal.sequence) - target_length))  # Ensure valid start
            current_sequence = prodigal.sequence[start_index : start_index + target_length]

            # Connect to previous
            if combined_sequence != "":
                overlap = calculate_overlap(combined_sequence, current_sequence)
                if overlap == 0: #Need to use the combiner
                    prefix = combined_sequence[-(n-1):]
                    suffix = current_sequence[:n-1]
                    candidates = generate_permutations_on_demand_hypothetical(prefix, suffix,  n, n-1)
                    if candidates:
                        # Choose the best candidate based on winners/losers (simplified scoring)
                        best_candidate = None
                        best_score = -float('inf')
                        for cand_hash in candidates:
                            cand_perm = unhash_permutation(cand_hash, n)
                            cand_str = "".join(str(x) for x in cand_perm)
                            score = 0
                            for k in [7, 6]: # Using values for n=8
                                for j in range(len(cand_str) - k + 1):
                                    kmer = cand_str[j:j+k]
                                    score += winners.get(kmer, 0)
                                    score -= losers.get(kmer, 0)

                            if score > best_score:
                                best_score = score
                                best_candidate = cand_str

                        overlap = calculate_overlap(combined_sequence, best_candidate)
                        combined_sequence += best_candidate[overlap:]
                    else:
                        continue #Skip if we cannot connect.

                else: #Overlap exists
                    combined_sequence += current_sequence[overlap:]
            else:
                combined_sequence = current_sequence
        
        #Check if prodigal
        perms_in_sequence = set()
        for i in range(len(combined_sequence) - n + 1):
            perm = tuple(int(x) for x in combined_sequence[i:i+n])
            if is_valid_permutation(perm, n):
                perms_in_sequence.add(hash_permutation(perm))

        if is_prodigal(combined_sequence, [unhash_permutation(x,n) for x in perms_in_sequence], n, min_length=min_length, overlap_threshold=0.95) and len(perms_in_sequence) > 0:
            mega_hypotheticals[next_mega_id] = ProdigalResult(combined_sequence, next_mega_id)
            next_mega_id -= 1

    return mega_hypotheticals

```