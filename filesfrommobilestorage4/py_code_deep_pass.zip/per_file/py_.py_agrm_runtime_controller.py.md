# File: py/.py/agrm_runtime_controller.py

**Extension:** .py

**Lines:** 81 | **Words:** 269

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 5

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (4): AGRMRuntimeController, BuilderAgent, AGRMEvaluator, NavigatorGR

- Functions (12): __init__, run_cycle, __init__, build_path, trigger_reroute, __init__, ingest_feedback, apply_modulation_if_needed, reset_required, __init__, run_sweep, trigger_reseed


---


## Full Source


```text

class AGRMRuntimeController:
    def __init__(self, navigator, builder_fwd, builder_rev, evaluator, salesman, feedback_bus):
        self.navigator = navigator
        self.builder_fwd = builder_fwd
        self.builder_rev = builder_rev
        self.evaluator = evaluator
        self.salesman = salesman
        self.feedback_bus = feedback_bus
        self.state = 'sweep'
        self.loop_counter = 0
        self.max_loops = 100

    def run_cycle(self):
        print(f"[AGRM] Cycle {self.loop_counter}: State = {self.state}")
        if self.state == 'sweep':
            self.navigator.run_sweep()
            self.state = 'build'
        elif self.state == 'build':
            self.builder_fwd.build_path()
            self.builder_rev.build_path()
            self.state = 'validate'
        elif self.state == 'validate':
            self.salesman.scan_path()
            self.state = 'feedback'
        elif self.state == 'feedback':
            batch = self.salesman.collect_feedback()
            self.feedback_bus.broadcast(batch)
            self.state = 'evaluator'
        elif self.state == 'evaluator':
            incoming = self.feedback_bus.collect_all()
            self.evaluator.ingest_feedback(incoming)
            self.evaluator.apply_modulation_if_needed()
            if self.evaluator.reset_required():
                self.state = 'sweep'
            else:
                self.state = 'complete'
        elif self.state == 'complete':
            print("[AGRM] Cycle complete.")
            return True
        self.loop_counter += 1
        if self.loop_counter >= self.max_loops:
            print("[AGRM] Max loop count exceeded.")
            return True
        return False

class BuilderAgent:
    def __init__(self):
        self.reroute_flag = False
    def build_path(self):
        print("[Builder] Building..." if not self.reroute_flag else "[Builder] Rerouting...")
        self.reroute_flag = False
    def trigger_reroute(self):
        self.reroute_flag = True

class AGRMEvaluator:
    def __init__(self):
        self.feedback_cache = []
        self.override_flag = False
    def ingest_feedback(self, feedback_batch):
        self.feedback_cache.extend(feedback_batch)
    def apply_modulation_if_needed(self):
        for signal in self.feedback_cache:
            if signal.get('type') == 'reroute_proposal' and signal.get('strain', 0) > 0.6:
                self.override_flag = True
                print("[Evaluator] Override triggered.")
        self.feedback_cache.clear()
    def reset_required(self) -> bool:
        return self.override_flag

class NavigatorGR:
    def __init__(self):
        self.reseed_triggered = False
    def run_sweep(self):
        if self.reseed_triggered:
            print("[NavigatorGR] Reseeded sweep...")
            self.reseed_triggered = False
        else:
            print("[NavigatorGR] Initial sweep...")
    def trigger_reseed(self):
        self.reseed_triggered = True


```