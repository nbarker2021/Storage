# File: py/.py/cmplx_run_final.py

**Extension:** .py

**Lines:** 51 | **Words:** 191

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 2

- MDHG: 0

- CMPLX: 2

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: os, pandas, yaml

- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

- Classes (0): (none)

- Functions (1): run_cmplx_cli


---


## Full Source


```text

import os
import yaml
import pandas as pd
from core.cmplx_logger import log
from core.runtime_controller import AGRMRuntimeController
from core.config_loader import load_config
from core.audit_output import save_audit_output
from plans.learning_plan_manager import LearningPlanManager
from agents.register_agents import register_agents

def run_cmplx_cli(dataset_path, plan_mode="generate", save_audit=True, recovery_depth=0):
    if recovery_depth > 2:
        log("Maximum recovery depth exceeded. Aborting self-triggered run.", agent="CLI", phase="RecursionGuard")
        return

    df = pd.read_csv(dataset_path)
    nodes = {int(row['id']): (row['x'], row['y']) for _, row in df.iterrows()}
    config = load_config(dataset_path)
    agent_manager = register_agents()
    runtime = AGRMRuntimeController(nodes)
    runtime.inject_agent_manager(agent_manager)

    if plan_mode == "generate":
        planner = LearningPlanManager()
        audit_path = os.path.join("results", "audit_result.json")
        plan = planner.generate_plan(audit_path, dataset_path)

    elif plan_mode.endswith(".yaml"):
        with open(plan_mode, 'r') as f:
            plan = yaml.safe_load(f)

    else:
        with open(os.path.join("presets", f"{plan_mode}.yaml"), 'r') as f:
            plan = yaml.safe_load(f)

    if "agents" in plan:
        agent_manager.replace_from_strategy(plan["agents"])

    agent_manager.get_agent("builder").configure(plan.get("builder", {}))
    runtime.set_max_cycles(plan.get("controller", {}).get("max_cycles", 100))

    runtime.state["plan_used"] = plan
    runtime.state["dataset"] = dataset_path
    runtime.state["_recovery_depth"] = recovery_depth

    while not runtime.is_terminated():
        runtime.run_cycle()

    if save_audit:
        save_audit_output(runtime.get_state(), output_path="results/audit_result.json")


```