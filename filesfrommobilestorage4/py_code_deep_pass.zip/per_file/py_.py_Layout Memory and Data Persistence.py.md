# File: py/.py/Layout Memory and Data Persistence.py

**Extension:** .py

**Lines:** 191 | **Words:** 686

## Keyword Hits

- SFBB: 0

- superperm: 23

- superpermutation: 23

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 5

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

# layout_memory.py
import pickle
import logging

class LayoutMemory:
    """Manages relationships and distances between k-mers in sequences."""

    def __init__(self):
        self.memory = {}  # {(kmer1, kmer2): data_dict}

    def add_sequence(self, superpermutation: str, n: int, k: int, source: str):
        """Adds k-mer relationships from a sequence to the memory.

        Args:
            superpermutation (str): The superpermutation string.
            n (int): The value of n.
            k (int): The k-mer length.
            source (str): The source identifier.
        """
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(k, len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if is_valid_permutation(perm, n): # Make sure is_valid_permutation is defined
                kmer1 = tuple(s_tuple[i - k:i]) # Store as tuples
                kmer2 = tuple(s_tuple[i - k + 1:i + 1]) # Store as tuples
                key = (kmer1, kmer2)
                if key not in self.memory:
                    self.memory[key] = {
                        "count": 0,
                        "sources": set(),
                        "distances": []
                    }
                data = self.memory[key]
                data["count"] += 1
                data["sources"].add(source)
                data["distances"].append(1)  # Default distance, can be adjusted

    def get_layout_score(self, kmer1: tuple, kmer2: tuple) -> float:
        """Calculates a layout score for a pair of k-mers.

        Args:
            kmer1 (tuple): The first k-mer.
            kmer2 (tuple): The second k-mer.

        Returns:
            float: The layout score.
        """
        key = (kmer1, kmer2)
        if key not in self.memory:
            return 0.0
        data = self.memory[key]
        score = data["count"]
        return score

    def save_to_file(self, filename: str):
        """Saves the LayoutMemory to a file using pickle.

        Args:
            filename (str): The file path.
        """
        with open(filename, 'wb') as f:
            pickle.dump(self.memory, f)
        logging.debug(f"LayoutMemory saved to {filename}.")

    def load_from_file(self, filename: str):
        """Loads the LayoutMemory from a file.

        Args:
            filename (str): The file path.
        """
        with open(filename, 'rb') as f:
            self.memory = pickle.load(f)
        logging.debug(f"LayoutMemory loaded from {filename}.")



# construct_superpermutation.py (Modified for data persistence)
import random
import logging
import json
from utils import calculate_overlap, hash_permutation, unhash_permutation, kmer_to_int, int_to_kmer, is_valid_permutation # Import is_valid_permutation
from layout_memory import LayoutMemory
from analysis_scripts_final import is_prodigal, generate_hypothetical_prodigals, generate_permutations

DATA_FILENAME = "superpermutation_data.json"

def construct_superpermutation(n, initial_sequence="", prodigal_results=None, winners=None, losers=None, layout_memory=None, limbo_list=None, eput=None):
    # ... (Initialization - as before)
    superpermutation = list(initial_sequence)
    if eput is None:
        eput = {}
    # ... (Initialize ePUT - using your logic)

    all_permutations = generate_permutations(n)
    missing_permutations = set(hash_permutation(p) for p in all_permutations) - set(eput.keys())

    # Load data from file if it exists
    try:
        with open(DATA_FILENAME, 'r') as f:
            data = json.load(f)
            prodigal_results = data.get("prodigal_results", {})
            winners = data.get("winners", {})
            losers = data.get("losers", {})
            limbo_list = set(data.get("limbo_list", []))
            layout_memory.memory = data.get("layout_memory", {})
            eput = data.get("eput", {})
    except FileNotFoundError:
        data = {}
        if layout_memory is None:
            layout_memory = LayoutMemory()

    while missing_permutations:
        best_candidate = None
        best_score = -float('inf')

        candidates = generate_candidates(superpermutation, missing_permutations, prodigal_results, winners, losers, layout_memory, n, eput, limbo_list)

        for candidate_hash in candidates:
            # ... (Rest of the loop - as before)

        if best_candidate:
            superpermutation = superpermutation[:best_insertion_point] + list(best_candidate) + superpermutation[best_insertion_point:]

            # ... (Update ePUT, layout memory, missing_permutations - as before)

            # Prodigal and hypothetical prodigal handling (Use your logic here)
            candidate_perm = tuple(int(x) for x in best_candidate)
            if is_prodigal(candidate_perm, all_permutations, n):
                prodigal_results[hash_permutation(candidate_perm)] = True

            hypothetical_prodigals = generate_hypothetical_prodigals(prodigal_results, winners, losers, n)
            # ... (Use hypothetical_prodigals in candidate generation)

            # Save data after each iteration
            data["prodigal_results"] = prodigal_results
            data["winners"] = winners
            data["losers"] = losers
            data["limbo_list"] = list(limbo_list)
            data["layout_memory"] = layout_memory.memory
            data["eput"] = eput
            with open(DATA_FILENAME, 'w') as f:
                json.dump(data, f)

        else:
            break

    return "".join(superpermutation)


# ... (generate_candidates and calculate_score - placeholders for now)

# superpermutation_generator.py (Modified to initialize LayoutMemory and pass it to construct_superpermutation)
import logging
from utils import setup_logging, normalize_sequence, compute_checksum
from construct_superpermutation import construct_superpermutation
from analysis_scripts_final import verify_permutation_coverage, calculate_sequence_length, calculate_overlap_rate, generate_permutations
from layout_memory import LayoutMemory

def main():
    setup_logging()
    n = 7  # or 8
    seed = 42
    layout_memory = LayoutMemory() # Initialize LayoutMemory

    # ... (Load layout memory from file if needed) ...

    all_permutations = generate_permutations(n) # Generate all permutations ONCE

    superpermutation = construct_superpermutation(n, initial_sequence="", prodigal_results={}, winners={}, losers={}, layout_memory=layout_memory, limbo_list=set(), eput={}) # Pass layout_memory

    if superpermutation:
        normalized_sequence = normalize_sequence(superpermutation)
        is_valid = verify_permutation_coverage(normalized_sequence, n)
        length = calculate_sequence_length(normalized_sequence)
        overlap_rate = calculate_overlap_rate(normalized_sequence, n)

        print(f"Superpermutation (seed {seed}): {normalized_sequence}")
        print(f"Valid coverage: {is_valid}")
        print(f"Length: {length}")
        print(f"Overlap rate: {overlap_rate:.4f}")

        # ... (Save layout memory to file if needed) ...

    else:
        print("Superpermutation generation failed.")

if __name__ == "__main__":
    main()

# utils.py (From Session 1)
# analysis_scripts_final.py (From Session 1)

```