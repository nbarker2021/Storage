# File: py/.py/tsp_node_loader.py

**Extension:** .py

**Lines:** 56 | **Words:** 201

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 3

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: os, re

- From-imports: typing

- Classes (1): TSPNodeLoader

- Functions (4): __init__, parse_file, get_nodes, summary


---


## Full Source


```text

import os
import re
from typing import Dict, Tuple, List

class TSPNodeLoader:
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.name = "unknown"
        self.dimension = 0
        self.nodes: Dict[int, Tuple[float, float]] = {}
        self.edge_weight_type = "EUC_2D"

    def parse_file(self):
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"TSP file not found: {self.filepath}")

        with open(self.filepath, 'r') as file:
            lines = file.readlines()

        coord_section = False
        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith("NAME"):
                self.name = line.split(":")[-1].strip()
            elif line.startswith("DIMENSION"):
                self.dimension = int(line.split(":")[-1].strip())
            elif line.startswith("EDGE_WEIGHT_TYPE"):
                self.edge_weight_type = line.split(":")[-1].strip()
            elif line.startswith("NODE_COORD_SECTION"):
                coord_section = True
                continue
            elif line.startswith("EOF"):
                break
            elif coord_section:
                parts = re.split(r'\s+', line)
                if len(parts) >= 3:
                    node_id = int(parts[0])
                    x = float(parts[1])
                    y = float(parts[2])
                    self.nodes[node_id] = (x, y)

        if len(self.nodes) != self.dimension:
            raise ValueError("Parsed node count does not match DIMENSION header.")

    def get_nodes(self) -> Dict[int, Tuple[float, float]]:
        return self.nodes

    def summary(self):
        print("\n[TSP FILE LOADED]")
        print(f"Name: {self.name}")
        print(f"Cities: {self.dimension}")
        print(f"Weight Type: {self.edge_weight_type}")


```