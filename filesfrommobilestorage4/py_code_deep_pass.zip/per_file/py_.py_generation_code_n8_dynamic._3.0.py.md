# File: py/.py/generation_code_n8_dynamic._3.0.py

**Extension:** .py

**Lines:** 655 | **Words:** 3143

## Keyword Hits

- SFBB: 0

- superperm: 86

- superpermutation: 86

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 1

- debruijn: 1

- beam: 0

- orchestrator: 0

- hash: 25

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

import itertools
import random
import time
import heapq
import copy
import networkx as nx
from collections import deque, defaultdict
import sys
import multiprocessing
import datetime
# Assuming de_bruijn_graph.py is in the same directory
from de_bruijn_graph import build_debruijn_graph, find_cycles, find_high_weight_paths, add_weights
import analysis_scripts as ascripts

# Constants for convenience
N_VALUE = 8  # The 'n' for superpermutations
K_VALUE = 7 # The 'k' for k-mer analysis in the De Bruijn Graph
PRODIGAL_MIN_LENGTH = 20
PRODIGAL_OVERLAP_THRESHOLD = 0.90
HYPOTHETICAL_PRODIGAL_MIN_LENGTH = 20
HYPOTHETICAL_PRODIGAL_OVERLAP_THRESHOLD = 0.95

# --- Prodigal Result Class ---
class ProdigalResult:
    def __init__(self, sequence, id_num):
        self.sequence = sequence
        self.id_num = id_num  # Unique ID for each prodigal
        self.permutations = set()
        self.calculate_permutations()
        self.overlap_rate = self.calculate_overlap_rate()

    def calculate_permutations(self):
      n = N_VALUE
      k = n - 1
      for i in range(len(self.sequence) - k):
          perm = tuple(int(x) for x in self.sequence[i:i+n])
          if len(set(perm)) == n and min(perm) == 1 and max(perm) == n:  # Check if it's a valid permutation
              self.permutations.add(ascripts.hash_permutation(perm))

    def calculate_overlap_rate(self):
        n = N_VALUE
        num_permutations = len(self.permutations)
        if num_permutations <= 1:
            return 0.0
        total_possible_overlap = (num_permutations - 1) * (n - 1)
        actual_overlap = len(self.sequence) - num_permutations
        return actual_overlap / total_possible_overlap if total_possible_overlap > 0 else 0.0

    def __repr__(self):
        return f"ProdigalResult(id={self.id_num}, len={len(self.sequence)}, overlap={self.overlap_rate:.4f}, perms={len(self.permutations)})"

# --- Permutation Data Class ---
class PermutationData:
    def __init__(self, permutation, creation_method="unknown"):
        self.permutation = permutation
        self.hash_value = ascripts.hash_permutation(permutation)
        self.creation_method = creation_method
        self.used_count = 0
        self.prodigal_status = None  # 'None', 'seed', 'member', or 'rejected'

    def __repr__(self):
        return f"PermData({self.permutation}, {self.creation_method}, used={self.used_count}, prodigal={self.prodigal_status})"
        def generate_permutations_on_demand_hypothetical(existing_seq, n, min_overlap, winners, k=K_VALUE):
    """Generates permutations for hypothetical prodigals (no used_permutations check)."""
    last_kmer = existing_seq[-(n - 1):]
    best_score = -float('inf')
    best_permutation = None

    for perm_tuple in itertools.permutations(range(1, n + 1)):
        perm_str = ''.join(map(str, perm_tuple))
        if perm_str.startswith(last_kmer):
            overlap = ascripts.calculate_overlap(existing_seq, perm_str)
            if overlap >= min_overlap:
                score = ascripts.calculate_score_hypothetical(existing_seq, perm_str, winners, n) #Modified to check for hypothetical prodigals
                if score > best_score:
                    best_score = score
                    best_permutation = perm_str
    return best_permutation

def generate_hypothetical_prodigals(prodigal_results, winners, losers, n, k=K_VALUE, num_to_generate=5):
    """Generates hypothetical prodigal results based on seeds and extensions."""
    hypothetical_prodigals = []
    seeds = []

    # Use existing prodigals as seeds
    for prodigal_id, prodigal in prodigal_results.items():
        seeds.append(prodigal.sequence)

    # Use high-scoring winners as seeds, if not enough prodigals
    if len(seeds) < num_to_generate:
        top_winners = heapq.nlargest(num_to_generate - len(seeds), winners.items(), key=lambda item: item[1])
        for winner, _ in top_winners:
            seeds.append(winner)

    prodigal_id_counter = max(prodigal_results.keys(), default=0) + 1

    for seed in seeds:
        # Extend in both directions
        forward_extension = extend_sequence(seed, n, winners, losers, direction="forward")
        backward_extension = extend_sequence(seed, n, winners, losers, direction="backward")

        # Combine extensions (removing duplicate part of the seed)
        combined_sequence = backward_extension[::-1] + forward_extension[len(seed):]

        # Check if it meets prodigal criteria
        if len(combined_sequence) >= PRODIGAL_MIN_LENGTH:
            hypothetical = ProdigalResult(combined_sequence, prodigal_id_counter)
            if hypothetical.overlap_rate >= PRODIGAL_OVERLAP_THRESHOLD:
                hypothetical_prodigals.append(hypothetical)
                prodigal_id_counter += 1
                print(f"    NEW HYPO PROD: {hypothetical}")

    return hypothetical_prodigals

def extend_sequence(seed_sequence, n, winners, losers, direction="forward", k=K_VALUE, extend_length=50):
    """Extends a sequence in a given direction using generate_permutations_on_demand."""
    extended_sequence = seed_sequence
    current_length = 0

    while current_length < extend_length:
        if direction == "forward":
            next_permutation = generate_permutations_on_demand_hypothetical(extended_sequence, n, n - 1, winners, k)
        elif direction == "backward":
            next_permutation = generate_permutations_on_demand_hypothetical(extended_sequence[::-1], n, n - 1, winners, k)
            if next_permutation:
                next_permutation = next_permutation[::-1]  # Reverse to maintain correct order
        else:
            raise ValueError("Invalid direction. Must be 'forward' or 'backward'.")

        if next_permutation is None:
            break  # No valid extension found

        if direction == "forward":
            extended_sequence += next_permutation[-1]
        else:
            extended_sequence = next_permutation[0] + extended_sequence

        current_length += 1

    return extended_sequence
    def construct_superpermutation(n, start_permutation, prodigal_results, winners, losers, max_attempts=100000):
    """Constructs a superpermutation using a guided, iterative approach."""
    global history_queue
    superpermutation = "".join(start_permutation)
    current_path = [ascripts.hash_permutation(start_permutation)]
    used_permutations = {ascripts.hash_permutation(start_permutation)}
    attempts = 0
    add_to_history({'type': 'start', 'permutation': start_permutation, 'path': current_path,
                    'superpermutation': superpermutation, 'timestamp': time.time(),
                    'winners_at_step': get_top_winners(winners, 50), 'losers_at_step': get_top_losers(losers, 50), 'prodigal_ids_at_step' : list(prodigal_results.keys()),
                    'laminate_at_step':"None"})
    permutations_added_this_batch = 0 #Track how many perm's have been added

    while attempts < max_attempts:
        next_permutation = generate_permutations_on_demand(superpermutation, current_path, used_permutations,
                                                            prodigal_results, winners, losers, n)
        if next_permutation:
            superpermutation += next_permutation[-1]
            current_path.append(ascripts.hash_permutation(tuple(int(x) for x in next_permutation)))
            used_permutations.add(ascripts.hash_permutation(tuple(int(x) for x in next_permutation)))
            attempts = 0  # Reset attempts counter on successful addition
            permutations_added_this_batch += 1 #Increment
        else:
            # Failure to find an extension.  Engage MORSR.
            fail_point_data = identify_fail_point(current_path, superpermutation)
            history_queue.put(fail_point_data)
            #Now wait for a message
            attempts+=1

        if permutations_added_this_batch % 5000 == 0 and permutations_added_this_batch != 0:
            print(f"Current length: {len(superpermutation)}, Permutations: {len(used_permutations)}, Attempts: {attempts}, Perms added: {permutations_added_this_batch}")
            ascripts.analyze_superpermutation(superpermutation, n)

        if permutations_added_this_batch > 20000: #Added to test completion
            superpermutation = complete_superpermutation_prodigal(superpermutation, list(itertools.permutations(range(1, n + 1))), prodigal_results, winners, losers, n)
            break

    return superpermutation, current_path, used_permutations

def generate_permutations_on_demand(superpermutation, current_path, used_permutations, prodigal_results, winners, losers, n, min_overlap=None, k=K_VALUE, max_attempts=100):
    """Generates the next permutation to add to the superpermutation."""
    global history_queue
    if min_overlap is None:
        min_overlap = n - 1

    last_kmer = superpermutation[-(n - 1):]
    best_score = -float('inf')
    best_permutation = None
    attempts = 0
    considered_permutations = []

    # Prioritize extending Prodigal Results
    for prodigal_id, prodigal in prodigal_results.items():
        if superpermutation.endswith(prodigal.sequence[:prodigal_min_length]):  # Check for the end
            for perm_tuple in itertools.permutations(range(1, n + 1)):
                perm_str = ''.join(map(str, perm_tuple))
                overlap = ascripts.calculate_overlap(prodigal.sequence, perm_str)
                if overlap >= min_overlap:
                    score = ascripts.calculate_score(prodigal.sequence, perm_str, winners, losers, n, prodigal_results)
                    considered_permutations.append((perm_str, score, overlap, prodigal_id, None))

        elif superpermutation.startswith(prodigal.sequence[-prodigal_min_length:]):  # Check for the start
             for perm_tuple in itertools.permutations(range(1, n + 1)):
                perm_str = ''.join(map(str, perm_tuple))
                overlap = ascripts.calculate_overlap( perm_str, prodigal.sequence)
                if overlap >= min_overlap:
                    score = ascripts.calculate_score(perm_str, prodigal.sequence, winners, losers, n, prodigal_results)
                    considered_permutations.append((perm_str, score, overlap, prodigal_id, None))
    # Filter considered_permutations to include only those with the maximum overlap
    if considered_permutations:
        max_overlap = max(item[2] for item in considered_permutations)
        considered_permutations = [item for item in considered_permutations if item[2] == max_overlap]

    while attempts < max_attempts:
        if considered_permutations:
             # Sort considered permutations by score (descending) and then by hash (ascending) for deterministic tie-breaking
            considered_permutations.sort(key=lambda x: (x[1], ascripts.hash_permutation(tuple(int(c) for c in x[0]))), reverse=True)
            chosen_permutation, score, overlap, prodigal_id, hypothetical_id = considered_permutations[0]
            if ascripts.hash_permutation(tuple(int(c) for c in chosen_permutation)) not in used_permutations:
                add_to_history({'type': 'permutation_added', 'permutation': chosen_permutation, 'score': score,
                                'overlap': overlap, 'prodigal_id': prodigal_id, 'hypothetical_id': hypothetical_id,
                                'alternatives': [(p[0], p[1]) for p in considered_permutations[1:]], 'timestamp': time.time(), 'depth' : 0, 'path': current_path,
                                'winners_at_step': get_top_winners(winners, 50), 'losers_at_step': get_top_losers(losers, 50), 'prodigal_ids_at_step' : list(prodigal_results.keys()),
                                'laminate_at_step':"None"})
                return chosen_permutation
            else:
                attempts+=1

        else: #If not extending, or connecting any prodigals
            for perm_tuple in itertools.permutations(range(1, n + 1)):
                perm_str = ''.join(map(str, perm_tuple))
                if perm_str.startswith(last_kmer):
                    overlap = ascripts.calculate_overlap(superpermutation, perm_str)
                    if overlap >= min_overlap:
                        score = ascripts.calculate_score(superpermutation, perm_str, winners, losers, n, prodigal_results)
                        if ascripts.hash_permutation(perm_tuple) not in used_permutations:
                            considered_permutations.append((perm_str, score, overlap, None, None))
            if considered_permutations:
                max_overlap = max(item[2] for item in considered_permutations)
                considered_permutations = [item for item in considered_permutations if item[2] == max_overlap]
                # Sort considered permutations by score (descending) and then by hash (ascending) for deterministic tie-breaking
                considered_permutations.sort(key=lambda x: (x[1], ascripts.hash_permutation(tuple(int(c) for c in x[0]))), reverse=True)

                chosen_permutation, score, overlap, prodigal_id, hypothetical_id = considered_permutations[0]

                add_to_history({'type': 'permutation_added', 'permutation': chosen_permutation, 'score': score,
                                'overlap': overlap, 'prodigal_id': prodigal_id, 'hypothetical_id': hypothetical_id,
                                'alternatives': [(p[0], p[1]) for p in considered_permutations[1:]], 'timestamp': time.time(), 'depth' : 0, 'path': current_path,
                                'winners_at_step': get_top_winners(winners, 50), 'losers_at_step': get_top_losers(losers, 50), 'prodigal_ids_at_step' : list(prodigal_results.keys()),
                                'laminate_at_step':"None"})
                return chosen_permutation
            else:
                return None

    return None  # No valid permutation found after max_attempts
    def identify_fail_point(current_path, superpermutation):
    """Identifies the point of failure and packages relevant data."""
    global history_queue

    fail_point_data = {
        'type': 'failure',
        'timestamp': time.time(),
        'current_path': current_path.copy(),  # Use copy to avoid modification
        'current_superpermutation': superpermutation,
    }
    return fail_point_data

def find_problem_origin(fail_point_data):
    """Analyzes the history to identify the most likely cause of the failure."""
    global history_queue
    history = []  # Will store relevant history entries

    # Iterate backwards through the history queue, up to a depth limit
    depth_limit = 50
    for i in range(min(history_queue.qsize(), depth_limit)):
        try:
            entry = history_queue.queue[-(i + 1)]  # Access elements in reverse order without modifying the queue
            history.append(entry)
        except IndexError:
            break  # Queue is smaller than depth_limit

    # Prioritize backtrack points
    for entry in reversed(history):  # Most recent first
        if entry['type'] == 'backtrack':
            #Return to the point right before the back track
            return history[history.index(entry) + 1]

    # Next, prioritize hypothetical prodigal creation
    for entry in reversed(history):
        if entry['type'] == 'hypothetical_created':
            return entry

    # Then, prioritize prodigal selection
    for entry in reversed(history):
        if entry['type'] == 'prodigal_selected':
            return entry

    # Finally, consider permutation additions with alternatives
    for entry in reversed(history):
        if entry['type'] == 'permutation_added' and entry['alternatives']:
            # Check if the chosen permutation had significantly worse score than alternatives
            chosen_score = entry['score']
            best_alternative_score = max(alt[1] for alt in entry['alternatives'])
            if best_alternative_score > chosen_score * 1.1:  # 10% threshold (example)
                return entry
            #Check if the choice included a loser
            for loser in entry['losers_at_step']:
                if loser in entry['permutation']:
                    return entry
    #If no origin found
    return history[-1]
    def ripple(origin_data, depth, max_depth=3):
    """Explores alternative choices from the problem origin."""
    if depth > max_depth:
        return []

    alternatives = []
    origin_type = origin_data['type']

    if origin_type == 'backtrack':
        # Explore alternative permutations considered *before* the backtrack
        for alt_perm, alt_score in origin_data['alternatives']:
            new_state = copy.deepcopy(origin_data)
            new_state['permutation'] = alt_perm
            new_state['score'] = alt_score
            #  Extend the superpermutation with the alternative
            new_state['superpermutation'] += alt_perm[-1]
            new_state['current_path'].append(ascripts.hash_permutation(tuple(int(c) for c in alt_perm)))
            new_state['used_permutations'].add(ascripts.hash_permutation(tuple(int(c) for c in alt_perm)))
            #  Recursively call ripple with reduced depth

            further_alternatives = ripple(new_state, depth + 1, max_depth)
            alternatives.extend(further_alternatives)
            alternatives.append(new_state) #Consider it an alternative, and return

    elif origin_type == 'hypothetical_created':
        #Try not using the hypothetical
        new_state = copy.deepcopy(origin_data)
        del new_state['hypothetical_id']
        further_alternatives = ripple(new_state, depth + 1, max_depth)
        alternatives.extend(further_alternatives)
        alternatives.append(new_state)  # Consider it an alternative, and return

    elif origin_type == 'prodigal_selected':
        # Try without using the prodigal, or other prodigals

        new_state = copy.deepcopy(origin_data)
        further_alternatives = ripple(new_state, depth + 1, max_depth)
        alternatives.extend(further_alternatives)
        alternatives.append(new_state)

    elif origin_type == 'permutation_added':
        # Explore alternative permutations from the history entry
        for alt_perm, alt_score in origin_data['alternatives']:
            new_state = copy.deepcopy(origin_data)
            new_state['permutation'] = alt_perm
            new_state['score'] = alt_score
            #  Extend the superpermutation with the alternative
            new_state['superpermutation'] += alt_perm[-1]
            new_state['current_path'].append(ascripts.hash_permutation(tuple(int(c) for c in alt_perm)))
            new_state['used_permutations'].add(ascripts.hash_permutation(tuple(int(c) for c in alt_perm)))

            #  Recursively call ripple with reduced depth
            further_alternatives = ripple(new_state, depth + 1, max_depth)
            alternatives.extend(further_alternatives)
            alternatives.append(new_state) #consider it an alternative

    return alternatives

def validate_state(state):
    """Validates the integrity of a proposed state from MORSR."""
    # 1. ePTU Consistency Check
    expected_used_permutations = set()
    n = N_VALUE  # Assuming N_VALUE is accessible globally

    for i in range(len(state['superpermutation']) - n + 1):
        perm_str = state['superpermutation'][i:i+n]
        if len(set(perm_str)) == n and all(c.isdigit() for c in perm_str):
            perm_tuple = tuple(int(c) for c in perm_str)
            if min(perm_tuple) == 1 and max(perm_tuple) == n: #valid perm
                expected_used_permutations.add(ascripts.hash_permutation(perm_tuple))

    if expected_used_permutations != state['used_permutations']:
        print("ePTU Validation Failed!")
        return False

    # 2. Prodigal Consistency Check (Simplified - Check if they are still valid prodigals)
    for prodigal_id, prodigal in state['prodigal_results'].items():
        if not ascripts.is_prodigal(prodigal.sequence, PRODIGAL_MIN_LENGTH, PRODIGAL_OVERLAP_THRESHOLD, n):
            print(f"Prodigal Validation Failed for ID: {prodigal_id}")
            return False

    return True  # All checks passed
    def get_top_winners(winners, num):
    """Returns the top N winners from the winners dictionary."""
    return dict(heapq.nlargest(num, winners.items(), key=lambda item: item[1]))

def get_top_losers(losers, num):
    """Returns the top N losers from the losers dictionary."""
    return dict(heapq.nsmallest(num, losers.items(), key=lambda item: item[1]))

def add_to_history(entry):
    """Adds an entry to the history queue."""
    global history_queue
    history_queue.put(entry)

def complete_superpermutation_prodigal(superpermutation, all_permutations, prodigal_results, winners, losers, n, min_overlap=None):
    """Completes a partial superpermutation using a prodigal-focused approach."""
    if min_overlap is None:
        min_overlap = n - 1

    print("Starting completion...")
    start_time = time.time()

    used_permutations = set()
    for i in range(len(superpermutation) - n + 1):
        perm_str = superpermutation[i:i + n]
        if len(set(perm_str)) == n and '0' not in perm_str:
            used_permutations.add(ascripts.hash_permutation(tuple(int(x) for x in perm_str)))

    missing_permutations = [p for p in all_permutations if ascripts.hash_permutation(p) not in used_permutations]
    print(f"Missing permutations: {len(missing_permutations)}")

    if not missing_permutations:
        print("Completion not needed. Already a complete superpermutation.")
        return superpermutation

    prodigal_graph = build_prodigal_graph(prodigal_results, n, min_overlap)

    # Iterate through missing permutations and attempt to add them
    permutations_added = 0  # Counter for permutations added in this completion attempt
    for perm_tuple in missing_permutations:
        perm_str = "".join(map(str, perm_tuple))
        added = False

        # 1. Try to extend existing prodigals
        for prodigal_id, prodigal in prodigal_results.items():
            if perm_str.startswith(prodigal.sequence[-(n - 1):]):  # Can extend at the end
                overlap = ascripts.calculate_overlap(prodigal.sequence, perm_str)
                if overlap >= min_overlap:
                    superpermutation += perm_str[overlap:]
                    for i in range(overlap, len(perm_str)):
                        new_perm = superpermutation[-(n+len(perm_str)-1-overlap):-(len(perm_str)-1-overlap)]
                        new_perm_tuple = tuple(int(x) for x in new_perm)
                        if len(set(new_perm_tuple)) == n and min(new_perm_tuple) == 1 and max(new_perm_tuple) == n:
                            used_permutations.add(ascripts.hash_permutation(new_perm_tuple))
                    added = True
                    permutations_added +=1
                    break
            elif prodigal.sequence.startswith(perm_str[1:]):  # Can extend at the beginning
                overlap = ascripts.calculate_overlap(perm_str, prodigal.sequence)
                if overlap >= min_overlap:
                    superpermutation = perm_str[:n-overlap] + superpermutation
                    for i in range(len(perm_str)-overlap):
                        new_perm = superpermutation[i:i+n]
                        new_perm_tuple = tuple(int(x) for x in new_perm)
                        if len(set(new_perm_tuple)) == n and min(new_perm_tuple) == 1 and max(new_perm_tuple) == n:
                            used_permutations.add(ascripts.hash_permutation(new_perm_tuple))
                    added = True
                    permutations_added += 1
                    break

        # 2. Try to connect prodigals using the prodigal graph
        if not added:
            for start_prodigal_id, start_prodigal in prodigal_results.items():
              for end_prodigal_id, end_prodigal in prodigal_results.items():
                if nx.has_path(prodigal_graph, start_prodigal_id, end_prodigal_id):
                    path = nx.shortest_path(prodigal_graph, start_prodigal_id, end_prodigal_id, weight = 'weight')
                    # Path is a list of prodigal IDs.
                    if perm_str.startswith(start_prodigal.sequence[-(n-1):]) and end_prodigal.sequence.startswith(perm_str[1:]):
                        temp_superpermutation = start_prodigal.sequence
                        valid_connection = True
                        for i in range(len(path) - 1):
                            current_prodigal = prodigal_results[path[i]]
                            next_prodigal = prodigal_results[path[i+1]]
                            connecting_perm = find_connecting_permutation(current_prodigal.sequence, next_prodigal.sequence, winners, losers, n, min_overlap)

                            if connecting_perm is None:
                                valid_connection = False
                                break
                            overlap = ascripts.calculate_overlap(current_prodigal.sequence, connecting_perm)

                            temp_superpermutation += connecting_perm[overlap:]
                        if valid_connection:
                            overlap = ascripts.calculate_overlap(temp_superpermutation, perm_str)
                            if overlap >= min_overlap:
                                superpermutation = superpermutation[:superpermutation.find(start_prodigal.sequence)] + temp_superpermutation + superpermutation[superpermutation.find(start_prodigal.sequence) + len(start_prodigal.sequence):]
                                superpermutation += perm_str[overlap:]
                                for i in range(len(perm_str) - overlap): #Correct
                                    new_perm = superpermutation[-(n - overlap + len(perm_str) - 1) + i:-(len(perm_str) -  1) + i + overlap ]
                                    new_perm_tuple = tuple(int(x) for x in new_perm)
                                    if len(set(new_perm_tuple)) == n and min(new_perm_tuple) == 1 and max(new_perm_tuple) == n:
                                        used_permutations.add(ascripts.hash_permutation(new_perm_tuple))

                                added = True
                                permutations_added += 1
                                break
              if added:
                break

        # 3. Fallback (general search, if no prodigal connections)
        if not added:
            last_kmer = superpermutation[-(n - 1):]
            for perm_tuple in itertools.permutations(range(1, n + 1)):
                perm_str = ''.join(map(str, perm_tuple))
                if perm_str.startswith(last_kmer):
                    overlap = ascripts.calculate_overlap(superpermutation, perm_str)
                    if overlap >= min_overlap and ascripts.hash_permutation(perm_tuple) not in used_permutations:
                        superpermutation += perm_str[overlap:]
                        used_permutations.add(ascripts.hash_permutation(perm_tuple))
                        added = True
                        permutations_added += 1
                        break

        if permutations_added % 100 == 0:
            print(f"Completion: Added {permutations_added} permutations. Current length: {len(superpermutation)}")
            ascripts.analyze_superpermutation(superpermutation, n) #Keep for updates.

    end_time = time.time()
    print(f"Completion finished in {end_time - start_time:.2f} seconds.")
    return superpermutation

def find_connecting_permutation(seq1, seq2, winners, losers, n, min_overlap):
    """Finds a permutation that connects two sequences with at least min_overlap."""
    for perm_tuple in itertools.permutations(range(1, n + 1)):
        perm_str = ''.join(map(str, perm_tuple))
        if seq1.endswith(perm_str[:n-1]) and seq2.startswith(perm_str[1:]):
             if ascripts.calculate_overlap(seq1, perm_str) >= min_overlap and ascripts.calculate_overlap(perm_str, seq2) >= min_overlap:
                return perm_str
    return None

def build_prodigal_graph(prodigal_results, n, min_overlap):
    """Builds a directed graph of Prodigal Results."""
    graph = nx.DiGraph()
    for prodigal_id, prodigal in prodigal_results.items():
        graph.add_node(prodigal_id)

    for (id1, prodigal1), (id2, prodigal2) in itertools.combinations(prodigal_results.items(), 2):
        for perm_tuple in itertools.permutations(range(1, n+1)):
            perm_str = "".join(map(str, perm_tuple))
            if prodigal1.sequence.endswith(perm_str[:n-1]) and prodigal2.sequence.startswith(perm_str[1:]):
                overlap = ascripts.calculate_overlap(prodigal1.sequence, perm_str)
                if overlap >= min_overlap:
                    graph.add_edge(id1, id2, weight=overlap)
            if prodigal2.sequence.endswith(perm_str[:n-1]) and prodigal1.sequence.startswith(perm_str[1:]):
                overlap = ascripts.calculate_overlap(prodigal2.sequence, perm_str)
                if overlap >= min_overlap:
                    graph.add_edge(id2, id1, weight=overlap)

    return graph

def morsr_process(history_queue, results_queue):
    """The main function for the MORSR process."""
    while True:
        try:
            message = history_queue.get()  # Wait for a message from the main process
            if message['type'] == 'failure':
                print("MORSR: Received failure message. Analyzing...")
                origin_data = find_problem_origin(message)

                if origin_data:
                    print(f"MORSR: Identified problem origin: {origin_data['type']}")
                    alternatives = ripple(origin_data, 0)

                    if alternatives:
                        best_alternative = max(alternatives, key=lambda x: len(x.get('superpermutation', "")))
                        print(f"MORSR: Found alternative state. Sending to main process. New Length: {len(best_alternative['superpermutation'])}")
                        results_queue.put(best_alternative)
                    else:
                        print("MORSR: No promising alternatives found.")
                else:
                    print("MORSR: Could not identify a problem origin.")

        except Exception as e:
            print(f"MORSR Error: {e}")

def save_data(superpermutation, winners, losers, prodigal_results, n):
    """Saves the superpermutation, winners, losers, and prodigals to files."""

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # Save superpermutation
    with open(f"results/superpermutation_n{n}_{timestamp}.txt", "w") as f:
        f.write(superpermutation)

    # Save winners
    with open(f"results/winners_n{n}_{timestamp}.txt", "w") as f:
        for kmer, score in winners.items():
            f.write(f"{kmer}:{score}\n")

    # Save losers
    with open(f"results/losers_n8_{timestamp}.txt", "w") as f:
        for kmer, score in losers.items():
            f.write(f"{kmer}:{score}\n")

    # Save prodigals
    with open(f"results/prodigals_n8_{timestamp}.txt", "w") as f:
        for prodigal_id, prodigal in prodigal_results.items():
            f.write(f"Prodigal ID: {prodigal.id_num}, Length: {len(prodigal.sequence)}, Overlap: {prodigal.overlap_rate:.4f}, Sequence (Start): {prodigal.sequence[:20]}, Sequence (End): {prodigal.sequence[-20:]}\n")

    print(f"Results saved with timestamp: {timestamp}")

def main():
    """Main function to control the superpermutation generation."""
    global history_queue, results_queue

    random_seed = 42  # Use a fixed seed for reproducibility
    random.seed(random_seed)
    print(f"Using random seed: {random_seed}")

    n = N_VALUE
    start_permutation = tuple(range(1, n + 1))
    prodigal_results = {}  # Initialize as an empty dictionary
    winners = defaultdict(int)  # Initialize as a defaultdict
    losers = defaultdict(int)   # Initialize as a defaultdict

    history_queue = multiprocessing.Queue()
    results_queue = multiprocessing.Queue()

    # Start the MORSR process
    morsr_p = multiprocessing.Process(target=morsr_process, args=(history_queue, results_queue))
    morsr_p.start()
    permutations_added_this_batch = 0

    # Load initial n=7 superpermutation as seed
    try:
        with open("results/superpermutation_n7.txt", "r") as f:
            initial_superpermutation = f.read().strip()
            # Extract the last n-1 characters to form an n=8 permutation
            start_permutation_n8 = initial_superpermutation[-(n-1):] + '8' #Adds 8 as the only valid option
            start_permutation = tuple(int(x) for x in start_permutation_n8)
            print(f"Loaded initial n=7 superpermutation and created n=8 start permutation: {start_permutation}")
    except FileNotFoundError:
        print("Could not find n=7 superpermutation file. Starting with default n=8 permutation.")
        start_permutation = tuple(range(1, n + 1))

    superpermutation, current_path, used_permutations = construct_superpermutation(
        n, start_permutation, prodigal_results, winners, losers
    )

    # --- Analysis and Output ---
    print("Final superpermutation:", superpermutation)
    print("Length of final superpermutation:", len(superpermutation))
    is_valid = ascripts.verify_superpermutation(superpermutation, n)
    print(f"Is valid superpermutation: {is_valid}")

    # Save results and analysis
    save_data(superpermutation, winners, losers, prodigal_results, n) # Added save

    morsr_p.terminate() #Make sure to end the process.

if __name__ == "__main__":
    multiprocessing.freeze_support()  # For Windows support
    main()


```