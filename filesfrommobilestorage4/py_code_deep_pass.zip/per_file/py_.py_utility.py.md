# File: py/.py/utility.py

**Extension:** .py

**Lines:** 272 | **Words:** 1232

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 9

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

# utility.py
import itertools
import subprocess
import os
import time
import hashlib
import math
import random
from config import ConfigManager  # Import ConfigManager
from typing import List, Tuple, Dict, Any, Callable #For the type hints

def get_user_input(prompt: str) -> bool:
    while True:
        response = input(prompt).lower()
        if response in ['y', 'n']:
            return response == 'y'
        print("Please enter 'y' for yes or 'n' for no.")

def is_valid_permutation(s: str, n: int) -> bool:
    """Checks if a string 's' is a valid permutation of numbers from 1 to n."""
    return len(s) == n and len(set(s)) == n and all(c.isdigit() and 1 <= int(c) <= n for c in s)

def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings."""
    for i in range(min(len(s1), len(s2)), 0, -1):
        if s1[-i:] == s2[:i]:
            return i
    return 0

def generate_permutations(n: int) -> List[str]:
    """Generates all permutations of numbers from 1 to n as strings."""
    symbols = [str(i) for i in range(1, n + 1)]
    return [''.join(p) for p in itertools.permutations(symbols)]

def kmer_to_int(kmer: str) -> int:
    """Converts a k-mer string to a unique integer representation."""
    #Assumes base <= 10
    result = 0
    for char in kmer:
        result = result * 10 + (int(char) -1) #Shift
    return result

def hash_permutation(permutation: Tuple[int, ...]) -> int:
    """Hashes a permutation tuple to a unique integer."""
    result = 0
    n = len(permutation)
    for val in permutation:
        result = result * (n + 1) + val
    return result

def unhash_permutation(hash_value: int, n: int) -> Tuple[int, ...]:
    """Converts a hash value back to a permutation tuple."""
    permutation = []
    for _ in range(n):
        val = hash_value % (n + 1)
        permutation.append(val)
        hash_value //= (n + 1)
    return tuple(permutation[::-1])  # Reverse

def compute_checksum(sequence: str) -> str:
    """Computes SHA-256 checksum of the sequence."""
    return hashlib.sha256(sequence.encode('utf-8')).hexdigest()

def assign_permutation_to_cell(permutation: Tuple[int, ...], n: int) -> Tuple[int, int, int]:
    """Assigns a permutation to a 3D cell based on digit counts."""
    group1_limit = math.ceil(n / 3)
    group2_limit = group1_limit + math.ceil((n - group1_limit) / 2)

    group1_count = 0
    group2_count = 0
    group3_count = 0

    for digit in map(int, permutation[:n-1]):  # Consider the first n-1 digits
        if digit <= group1_limit:
            group1_count += 1
        elif digit <= group2_limit:
            group2_count += 1
        else:
            group3_count += 1

    # Normalize the counts to get cell coordinates (e.g., 0-9)
    x = int((group1_count / (n - 1)) * 9)
    y = int((group2_count / (n - 1)) * 9)
    z = int((group3_count / (n - 1)) * 9)

    return x, y, z

def generate_hypothetical_prodigal(n: int, length: int) -> str:
    """Generates a hypothetical prodigal sequence of the given length."""
    if length < n:
        raise ValueError("Length must be at least n")

    # Start with a valid permutation
    symbols = [str(i) for i in range(1, n + 1)]
    prodigal = list(random.choice(list(itertools.permutations(symbols)))) # Start with a random permutation
    prodigal_str = "".join(map(str, prodigal))

    # Introduce an imperfection (simplest case: swap two elements)
    if n > 1:
      swap_index1 = random.randint(0, n - 1)
      swap_index2 = (swap_index1 + 1) % n  # Wrap around
      prodigal[swap_index1], prodigal[swap_index2] = prodigal[swap_index2], prodigal[swap_index1]
      prodigal_str = "".join(map(str, prodigal))

    # Extend to the desired length (add random digits)
    while len(prodigal_str) < length:
        prodigal_str += random.choice(symbols)

    return prodigal_str

class SystemSpecReader:
    """Reads system specifications (CPU, memory, etc.)."""

    def get_specs(self) -> Dict[str, Any]:
        """Returns a dictionary of system specifications."""
        return {
            'cpu_count': psutil.cpu_count(logical=False),
            'logical_cpu_count': psutil.cpu_count(logical=True),
            'total_memory_gb': psutil.virtual_memory().total / (1024**3),
            'available_memory_gb': psutil.virtual_memory().available / (1024**3),
            'platform': psutil.platform(),
            'os': os.name,
        }
class RestrictedEnvironment:
    """Manages a restricted execution environment (sandbox)."""

    def __init__(self, timeout: int = 60, memory_limit_mb: int = 512, num_processes: int = 1, temp_dir: str = "sandbox_temp"):
        self.timeout = timeout
        self.memory_limit_mb = memory_limit_mb
        self.num_processes = num_processes
        self.temp_dir = temp_dir  # Directory for temporary files
        config = ConfigManager()
        self.timeout = config.get_setting("sandbox_timeout", self.timeout)
        self.memory_limit_mb = config.get_setting("sandbox_memory_limit_mb", self.memory_limit_mb)
        self.num_processes = config.get_setting("sandbox_num_processes", self.num_processes)
        self._constructed = False

    def construct(self):
        """Sets up the sandbox environment (e.g., creates a temporary directory)."""
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)
        self._constructed = True

    def deconstruct(self):
        """Cleans up the sandbox environment (e.g., removes temporary files)."""
        if os.path.exists(self.temp_dir):
            try:
                for filename in os.listdir(self.temp_dir):
                    file_path = os.path.join(self.temp_dir, filename)
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        import shutil
                        shutil.rmtree(file_path)  # Use shutil.rmtree to remove directories
                os.rmdir(self.temp_dir) #Remove the now empty directory.
                self._constructed = False
            except Exception as e:
                print(f"Error during sandbox deconstruction: {e}")


def run_in_sandbox(self, code: str) -> Tuple[int, str, str]:
        """
        Runs the given Python code in a separate process with limited resources.
        SIMULATED VERSION - Does not actually execute code.
        """
        if not self._constructed:
            raise Exception("Sandbox not constructed. Call .construct() before use.")

        print(f"SIMULATED: Running code in sandbox (timeout={self.timeout}s, memory={self.memory_limit_mb}MB):")
        # print(code)  # Optionally print the code being "executed"
        return 0, "Simulated Output", ""  # Simulate successful execution

        # try:
        #     # Create a temporary file within the sandbox directory
        #     temp_file_path = os.path.join(self.temp_dir, "temp_script.py")
        #     with open(temp_file_path, "w") as f:
        #         f.write(code)

        #     # Construct the command to run.  We'd use resource limiting tools here if this weren't a simulation.
        #     command = [
        #         "python",
        #         temp_file_path  # Run the script from the temporary file
        #     ]

        #     # Use subprocess.run with a timeout
        #     result = subprocess.run(
        #         command,
        #         capture_output=True,  # Capture stdout and stderr
        #         text=True,           # Decode output as text
        #         timeout=self.timeout,  # Set a timeout
        #         check=False,          # Don't raise an exception for non-zero return codes
        #         cwd=self.temp_dir,   # Set the working directory to the sandbox
        #     )

        #     return result.returncode, result.stdout, result.stderr

        # except subprocess.TimeoutExpired:
        #     return -1, "", "TimeoutExpired: Process exceeded the time limit."
        # except Exception as e:
        #     return -2, "", f"An unexpected error occurred: {e}"
        # finally:
        #     # Clean up the temporary file, even if there was an error.
        #     if os.path.exists(temp_file_path):
        #         os.remove(temp_file_path)
        
        class DTT:
    """Deploys, tests, and times code execution, optionally within a sandbox."""

    def __init__(self, use_sandbox: bool = True, environment: RestrictedEnvironment = None):
        self.use_sandbox = use_sandbox
        self.environment = environment or RestrictedEnvironment()
        config = ConfigManager()
        self.use_sandbox = config.get_setting("dtt_use_sandbox", self.use_sandbox)
        if self.use_sandbox:
          self.environment.construct() #Construct the environment.

    def __del__(self):
        if self.use_sandbox and self.environment._constructed:
            self.environment.deconstruct()  # Deconstruct the environment when DTT is destroyed

    def deploy_and_test(self, code: str, test_cases: List[Dict[str, Any]] = None) -> List[Dict]:
        """Deploys, tests and times the code.

        Args:
            code: The code to run.
            test_cases: List of test cases of the form [{"input":<dict>, "expected":<value>}]
        """
        results = []
        #Simplified for simulation
        run_func = self.environment.run_in_sandbox if self.use_sandbox else self._run_directly

        #SIMULATED, NO FILE IO
        print(f"SIMULATED: Deploying and testing code (sandbox={self.use_sandbox})...")

        start_time = time.time()
        # return_code, stdout, stderr = run_func(code) #Removed
        return_code, stdout, stderr = 0, "Simulated Output", ""  # Simulate success
        end_time = time.time()
        execution_time = end_time - start_time

        results.append({
            "success": True, #return_code == 0,
            "output": stdout,
            "error": stderr,
            "time": execution_time
        })
        # Run test cases, if provided.  Also simulated.
        if test_cases:
            for case in test_cases:
                test_input = case["input"]
                expected_output = case["expected"]
                test_code = code + "\n" + f"result = solve(**{test_input})" + "\n" + "print(result)" #Create test to run.

                start_time = time.time()
                # ret, out, err = run_func(test_code) #Removed
                ret, out, err = 0, str(expected_output), "" #Simulate Success
                end_time = time.time()
                test_success = ret == 0 and out.strip() == str(expected_output)
                results.append({
                    'success': test_success,
                    'output': out,
                    'error': err,
                    'time': end_time-start_time
                })
        return results


    def _run_directly(self, code:str):
      """Helper method for direct execution"""
      #SIMULATED
      print("SIMULATED: Running code directly (no sandbox):\n", code)
      return 0, "Simulated Output", "" #Simplified return

```