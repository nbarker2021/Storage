# File: py/.py/tsp_node_loader (2).py

**Extension:** .py

**Lines:** 101 | **Words:** 391

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 22

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: os, re

- From-imports: typing

- Classes (1): TSPNodeLoader

- Functions (6): auto_load_tsp, select_tsp_dataset, __init__, parse_file, get_nodes, summary


---


## Full Source


```text


import os
import re
from typing import Dict, Tuple

class TSPNodeLoader:
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.name = "unknown"
        self.dimension = 0
        self.nodes: Dict[int, Tuple[float, float]] = {}
        self.edge_weight_type = "EUC_2D"

    def parse_file(self):
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"TSP file not found: {self.filepath}")
        with open(self.filepath, 'r') as file:
            lines = file.readlines()

        coord_section = False
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line.startswith("NAME"):
                self.name = line.split(":")[-1].strip()
            elif line.startswith("DIMENSION"):
                self.dimension = int(line.split(":")[-1].strip())
            elif line.startswith("EDGE_WEIGHT_TYPE"):
                self.edge_weight_type = line.split(":")[-1].strip()
            elif line.startswith("NODE_COORD_SECTION"):
                coord_section = True
                continue
            elif line.startswith("EOF"):
                break
            elif coord_section:
                parts = re.split(r'\s+', line)
                if len(parts) >= 3:
                    node_id = int(parts[0])
                    x = float(parts[1])
                    y = float(parts[2])
                    self.nodes[node_id] = (x, y)
        if len(self.nodes) != self.dimension:
            raise ValueError("Parsed node count does not match DIMENSION header.")

    def get_nodes(self) -> Dict[int, Tuple[float, float]]:
        return self.nodes

    def summary(self):
        print("\n[TSP FILE LOADED]")
        print(f"Name: {self.name}")
        print(f"Cities: {self.dimension}")
        print(f"Weight Type: {self.edge_weight_type}")

def auto_load_tsp(filepath: str):
    loader = TSPNodeLoader(filepath)
    loader.parse_file()
    loader.summary()

    dim = loader.dimension
    default_config = {
        'max_cycles': max(50, dim // 10),
        'shell_failure_limit': 3,
        'drift_threshold': 0.12,
        'entropy_floor': 0.04,
        'gradient_threshold': 2.0,
        'hysteresis_delay': 3
    }

    if dim > 1000:
        default_config['shell_failure_limit'] = 4
        default_config['hysteresis_delay'] = 5
    if dim > 5000:
        default_config['entropy_floor'] = 0.03
        default_config['drift_threshold'] = 0.10
    if dim > 10000:
        default_config['max_cycles'] = 200
        default_config['gradient_threshold'] = 2.5

    return loader, default_config

# ✅ Updated for dataset/NAME/NAME.tsp structure
TSPLIB_DATASETS = {
    'pcb442':      ('datasets/pcb442/pcb442.tsp', 'datasets/pcb442/pcb442.opt.tour'),
    'pr2392':      ('datasets/pr2392/pr2392.tsp', 'datasets/pr2392/pr2392.opt.tour'),
    'rl5915':      ('datasets/rl5915/rl5915.tsp', 'datasets/rl5915/rl5915.opt.tour'),
    'rl11849':     ('datasets/rl11849/rl11849.tsp', 'datasets/rl11849/rl11849.opt.tour'),
    'usa13509':    ('datasets/usa13509/usa13509.tsp', 'datasets/usa13509/usa13509.opt.tour'),
    'brd14051':    ('datasets/brd14051/brd14051.tsp', 'datasets/brd14051/brd14051.opt.tour'),
    'd15112':      ('datasets/d15112/d15112.tsp', 'datasets/d15112/d15112.opt.tour'),
    'pla33810':    ('datasets/pla33810/pla33810.tsp', 'datasets/pla33810/pla33810.opt.tour'),
    'pla85900':    ('datasets/pla85900/pla85900.tsp', 'datasets/pla85900/pla85900.opt.tour'),
}

def select_tsp_dataset(name: str):
    if name not in TSPLIB_DATASETS:
        raise ValueError(f"Unknown dataset: {name}")
    tsp_path, opt_path = TSPLIB_DATASETS[name]
    loader, config = auto_load_tsp(tsp_path)
    return loader, config, opt_path


```