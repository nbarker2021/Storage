# File: py/.py/layout copilot.py

**Extension:** .py

**Lines:** 116 | **Words:** 697

## Keyword Hits

- SFBB: 0

- superperm: 5

- superpermutation: 5

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math, pickle

- From-imports: (none)

- Classes (1): LayoutMemory

- Functions (7): __init__, add_sequence, get_layout_score, update_distances, merge_memory, save_to_file, load_from_file


---


## Full Source


```text

import math
import pickle

class LayoutMemory:
    def __init__(self):
        self.memory = {}  # { (kmer1, kmer2): { "count": int, "distances": [int], "average_distance": float, "min_distance": int, "max_distance": int, "sources": set} }

    def add_sequence(self, superpermutation, n, k, source):
        """Adds k-mer pair relationships from a superpermutation to the memory.

        Args:
            superpermutation (str): The superpermutation string.
            n (int): The value of n (number of symbols).
            k (int): The length of k-mers to consider (k and k-1).
            source (str): A string identifying the source of this data (e.g., "n7_5906", "n8_run1").
        """
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]
            if len(set(perm)) == n and min(perm) == 1 and max(perm) == n:  # Valid
                if i > 0:
                    for k_val in [k, k - 1]:  # Track both k and k-1 mers
                        if i >= k_val:
                            kmer1 = "".join(str(x) for x in s_tuple[i - k_val:i])
                            kmer2 = "".join(str(x) for x in s_tuple[i - k_val + 1:i + 1])
                            if (kmer1, kmer2) not in self.memory:
                                self.memory[(kmer1, kmer2)] = {"count": 0, "distances": [], "average_distance": 0.0, "min_distance": float('inf'), "max_distance": float('-inf'), "sources": set()}
                            self.memory[(kmer1, kmer2)]["count"] += 1
                            self.memory[(kmer1, kmer2)]["distances"].append(1)  # Adjacent in the sequence
                            self.memory[(kmer1, kmer2)]["average_distance"] = sum(self.memory[(kmer1, kmer2)]["distances"]) / self.memory[(kmer1, kmer2)]["count"]
                            self.memory[(kmer1, kmer2)]["min_distance"] = min(self.memory[(kmer1, kmer2)]["min_distance"], 1)
                            self.memory[(kmer1, kmer2)]["max_distance"] = max(self.memory[(kmer1, kmer2)]["max_distance"], 1)
                            self.memory[(kmer1, kmer2)]["sources"].add(source)


    def get_layout_score(self, kmer1, kmer2, proposed_distance):
        """Calculates a layout score for a pair of k-mers.

        Args:
            kmer1 (str): The first k-mer.
            kmer2 (str): The second k-mer.
            proposed_distance (int): The proposed distance between the k-mers.

        Returns:
            float: A score representing the compatibility of the proposed placement with
                   the layout memory. Higher scores are better.  Returns 0 if the
                   k-mer pair is not in the memory.
        """
        if (kmer1, kmer2) not in self.memory:
            return 0  # No information about this pair

        data = self.memory[(kmer1, kmer2)]
        count = data["count"]
        avg_distance = data["average_distance"]
        min_distance = data["min_distance"]
        max_distance = data["max_distance"]

        # Basic score based on count (frequency)
        score = count

        # Bonus/penalty for distance:
        if min_distance <= proposed_distance <= max_distance:
            # Within the observed range, give a bonus proportional to how close
            # it is to the average distance.  Use exponential decay.
            distance_from_avg = abs(proposed_distance - avg_distance)
            score += 10 * math.exp(-0.1 * distance_from_avg)  # Tune the 0.1 factor and the 10
        else:
            # Outside the observed range, apply a penalty.
            score -= 5

        return score

    def update_distances(self, kmer1, kmer2, distance, source):
        """Updates distances information, used by the completion algorithm and prodigal extension.

        Args:
            kmer1 (str): The first k-mer
            kmer2 (str): The second k-mer
            distance (int): The distance between the two.
            source (str): The source of this information.
        """
        if (kmer1, kmer2) not in self.memory:
             self.memory[(kmer1, kmer2)] = {"count": 0, "distances": [], "average_distance": 0.0, "min_distance": float('inf'), "max_distance": float('-inf'), "sources": set()}
        self.memory[(kmer1, kmer2)]["count"] += 1
        self.memory[(kmer1, kmer2)]["distances"].append(distance)
        self.memory[(kmer1, kmer2)]["average_distance"] = sum(self.memory[(kmer1, kmer2)]["distances"]) / self.memory[(kmer1, kmer2)]["count"]
        self.memory[(kmer1, kmer2)]["min_distance"] = min(self.memory[(kmer1, kmer2)]["min_distance"], distance)
        self.memory[(kmer1, kmer2)]["max_distance"] = max(self.memory[(kmer1, kmer2)]["max_distance"], distance)
        self.memory[(kmer1, kmer2)]["sources"].add(source)

    def merge_memory(self, other_memory):
        """Merges another LayoutMemory object into this one."""
        for (kmer1, kmer2), data in other_memory.memory.items():
            if (kmer1, kmer2) in self.memory:
                # Combine the data
                self.memory[(kmer1, kmer2)]["count"] += data["count"]
                self.memory[(kmer1, kmer2)]["distances"].extend(data["distances"])
                self.memory[(kmer1, kmer2)]["average_distance"] = sum(self.memory[(kmer1, kmer2)]["distances"]) / self.memory[(kmer1, kmer2)]["count"]
                self.memory[(kmer1, kmer2)]["min_distance"] = min(self.memory[(kmer1, kmer2)]["min_distance"], data["min_distance"])
                self.memory[(kmer1, kmer2)]["max_distance"] = max(self.memory[(kmer1, kmer2)]["max_distance"], data["max_distance"])
                self.memory[(kmer1, kmer2)]["sources"].update(data["sources"]) # Add the sources

            else:
                # Add the new entry
                self.memory[(kmer1, kmer2)] = data

    def save_to_file(self, filename):
        """Saves the LayoutMemory to a file."""
        with open(filename, 'wb') as f:
            pickle.dump(self.memory, f)


    def load_from_file(self, filename):
        """Loads the LayoutMemory from a file."""
        with open(filename, 'rb') as f:
            self.memory = pickle.load(f)

```