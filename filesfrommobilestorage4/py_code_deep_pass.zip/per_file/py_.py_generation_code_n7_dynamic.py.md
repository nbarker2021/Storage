# File: py/.py/generation_code_n7_dynamic.py

**Extension:** .py

**Lines:** 869 | **Words:** 4251

## Keyword Hits

- SFBB: 0

- superperm: 82

- superpermutation: 82

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 7

- debruijn: 6

- beam: 0

- orchestrator: 0

- hash: 81

- golden: 16

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: heapq, itertools, math, networkx, random, time

- From-imports: collections

- Classes (2): PermutationData, ProdigalResult

- Functions (30): calculate_overlap, generate_permutations, calculate_distance, hash_permutation, unhash_permutation, is_valid_permutation, calculate_golden_ratio_points, get_kmers, build_debruijn_graph, add_weights_to_debruijn, find_cycles, find_high_weight_paths, initialize_data, generate_permutations_on_demand_hypothetical, generate_hypothetical_prodigals, generate_permutations_on_demand, calculate_score, construct_superpermutation, is_cyclically_distinct, main, dfs, dfs, __init__, __str__, __repr__, __init__, calculate_permutations, calculate_overlap_rate, __str__, __repr__


---


## Full Source


```text

# generation_code_n7_dynamic.py: Generates distinct minimal superpermutations for n=7

import itertools
import random
import math
import time
import networkx as nx
from collections import deque, defaultdict
import heapq
#from layout_memory import LayoutMemory  # Assuming layout_memory.py is in the same directory #REMOVED, using in main
#import analysis_scripts  # Import the analysis functions #REMOVED, using in main

# --- Constants ---
N = 7  # The value of n (number of symbols).
PRODIGAL_OVERLAP_THRESHOLD = 0.98  # Initial minimum overlap rate for "Prodigal Results"
PRODIGAL_MIN_LENGTH = 10  # Initial minimum length for "Prodigal Results"
HYPOTHETICAL_PRODIGAL_OVERLAP_THRESHOLD = 0.95
HYPOTHETICAL_PRODIGAL_MIN_LENGTH = 7
HYPOTHETICAL_PRODIGAL_GENERATION_COUNT = 50
WINNER_THRESHOLD = 0.75  # Not directly used in scoring, but for analysis
LOSER_THRESHOLD = 0.25  # Not directly used in scoring, but for analysis
#INITIAL_SAMPLE_SIZE =  Removed for Dynamic
NUM_ITERATIONS = 1000  # Number of iterations.  Adjust as needed.
#SUPER_BATCH_SIZE =  Removed
#BATCH_SIZE =  Removed
LAYOUT_K_VALUES = [N - 1, N - 2]  # k values for Layout Memory
DE_BRUIJN_K_VALUES = [N - 1, N - 2]  # k values for De Bruijn graph generation
#COMPLETION_SAMPLE_SIZE =  Removed
RANDOM_SEED = 42  # For reproducibility

# --- Helper Functions ---

def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings."""
    max_overlap = 0
    for i in range(1, min(len(s1), len(s2)) + 1):
        if s1[-i:] == s2[:i]:
            max_overlap = i
    return max_overlap

def generate_permutations(n: int) -> list[tuple[int, ...]]:
    """Generates all permutations of 1 to n."""
    return list(itertools.permutations(range(1, n + 1)))

def calculate_distance(p1: str, p2: str, n: int) -> int:
    """Calculates distance (n-1 - overlap)."""
    return (n - 1) - max(calculate_overlap(p1, p2), calculate_overlap(p2, p1))

def hash_permutation(permutation: tuple) -> int:
    """Hashes a permutation tuple to a unique integer."""
    result = 0
    n = len(permutation)
    for i, val in enumerate(permutation):
        result += val * (n ** (n - 1 - i))
    return result

def unhash_permutation(hash_value: int, n: int) -> tuple:
    """Converts a hash value back to a permutation tuple."""
    permutation = []
    for i in range(n - 1, -1, -1):
        val = hash_value // (n ** i)
        permutation.append(val + 1)  # Adjust to be 1-indexed
        hash_value -= val * (n ** i)
    return tuple(permutation)

def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a given sequence is a valid permutation."""
    return len(set(perm)) == n and min(perm) == 1 and max(perm) == n

def calculate_golden_ratio_points(length: int, levels: int = 1) -> list[int]:
    """Calculates multiple levels of golden ratio points."""
    phi = (1 + math.sqrt(5)) / 2
    points = []
    for _ in range(levels):
        new_points = []
        if not points:
            new_points = [int(length / phi), int(length - length / phi)]
        else:
            for p in points:
                new_points.extend([int(p / phi), int(p - p / phi)])
                new_points.extend([int((length-p) / phi) + p, int(length - (length-p) / phi)])
        points.extend(new_points)
        points = sorted(list(set(points)))  # Remove duplicates and sort
    return points

def get_kmers(sequence: str, n: int, k: int) -> set[str]:
    """Extracts all k-mers from a sequence, given n and k."""
    kmers = set()
    seq_list = [int(x) for x in sequence]
    for i in range(len(sequence) - n + 1):
        perm = tuple(seq_list[i:i+n])
        if is_valid_permutation(perm, n):
            if i >= k:
                kmer = "".join(str(x) for x in seq_list[i-k:i])
                kmers.add(kmer)
    return kmers

def build_debruijn_graph(n: int, k: int, permutations=None, superpermutation=None) -> nx.DiGraph:
    """Builds a De Bruijn graph of order k for permutations of n symbols."""

    if (permutations is None and superpermutation is None) or (permutations is not None and superpermutation is not None):
        raise ValueError("Must provide either 'permutations' or 'superpermutation', but not both.")

    graph = nx.DiGraph()

    if permutations:
      for perm in permutations:
          perm_str = "".join(str(x) for x in perm)
          for i in range(len(perm_str) - k + 1):
              kmer1 = perm_str[i:i + k - 1]
              kmer2 = perm_str[i + 1:i + k]
              if len(kmer1) == k - 1 and len(kmer2) == k-1: #Should always be true
                graph.add_edge(kmer1, kmer2, weight=calculate_overlap(kmer1, kmer2))
    else: #Use superpermutation
        s_list = [int(x) for x in superpermutation]
        for i in range(len(s_list) - n + 1):
            perm = tuple(s_list[i:i+n])
            if is_valid_permutation(perm, n):
                #Valid permutation.
                if i >= k:
                  kmer1 = "".join(str(x) for x in s_list[i-k:i])
                  kmer2 = "".join(str(x) for x in s_list[i-k+1: i+1])
                  if len(kmer1) == k - 1 and len(kmer2) == k - 1:
                    graph.add_edge(kmer1, kmer2, weight = calculate_overlap(kmer1,kmer2))
    return graph

def add_weights_to_debruijn(graph: nx.DiGraph, winners: dict, losers: dict):
    """Adds 'winner_weight' and 'loser_weight' attributes to the edges of a De Bruijn graph."""

    for u, v, data in graph.edges(data=True):
        kmer = u[1:] + v[-1]  # Reconstruct the k-mer from the edge
        data['winner_weight'] = winners.get(kmer, 0)
        data['loser_weight'] = losers.get(kmer, 0)

def find_cycles(graph: nx.DiGraph) -> list[list[str]]:
    """Finds cycles in the De Bruijn graph using a simple DFS approach."""
    cycles = []
    visited = set()

    def dfs(node, path):
        visited.add(node)
        path.append(node)

        for neighbor in graph.neighbors(node):
            if neighbor == path[0] and len(path) > 1:  # Found a cycle
                cycles.append(path.copy())
            elif neighbor not in visited:
                dfs(neighbor, path)

        path.pop()
        visited.remove(node) #Correctly remove node

    for node in graph.nodes:
        if node not in visited:
            dfs(node, [])
    return cycles

def find_high_weight_paths(graph: nx.DiGraph, start_node: str, length_limit: int) -> list[list[str]]:
    """
    Finds high-weight paths in the De Bruijn graph starting from a given node.
    """
    best_paths = []
    best_score = -float('inf')

    def dfs(current_node, current_path, current_score):
        nonlocal best_score
        nonlocal best_paths

        if len(current_path) > length_limit:
            return

        current_score_adj = current_score
        if len(current_path) > 1:
            current_score_adj = current_score / (len(current_path)-1) #Average

        if current_score_adj > best_score:
            best_score = current_score_adj
            best_paths = [current_path.copy()]  # New best path
        elif current_score_adj == best_score and len(current_path) > 1: #Dont include starting nodes
            best_paths.append(current_path.copy())  # Add to list of best paths

        for neighbor in graph.neighbors(current_node):
            edge_data = graph.get_edge_data(current_node, neighbor)
            new_score = current_score + edge_data.get('weight', 0) + edge_data.get('winner_weight', 0) - edge_data.get('loser_weight', 0)
            dfs(neighbor, current_path + [neighbor], new_score)

    dfs(start_node, [start_node], 0)
    return best_paths
    
    # START SECTION: Data Structures

class PermutationData:
    def __init__(self, permutation: tuple, in_sample: bool = False, creation_method: str = ""):
        """
        Stores data associated with a single permutation.

        Args:
            permutation (tuple): The permutation as a tuple of integers (1-indexed).
            in_sample (bool): True if the permutation was part of the initial sample
                             (always False in the fully dynamic version).
            creation_method (str):  Describes how the permutation was generated
                                   (e.g., "prodigal_extension", "hypothetical_prodigal",
                                    "completion").
        """
        self.hash: int = hash_permutation(permutation)
        self.permutation: tuple = permutation
        self.in_sample: bool = in_sample  # Will likely always be False in this version
        self.used_count: int = 0  # How many times this permutation has been used
        self.prodigal_status: list[int] = []  # List of ProdigalResult IDs it belongs to
        self.creation_method: str = creation_method
        self.batch_ids: list[int] = []  # Removed
        self.used_in_final: bool = False  # True if in the current best superpermutation
        self.neighbors: set[int] = set()  # Set of hashes of neighboring permutations

    def __str__(self) -> str:
        """String representation for debugging."""
        return (f"PermutationData(hash={self.hash}, permutation={self.permutation}, used_count={self.used_count}, "
                f"prodigal_status={self.prodigal_status}, creation_method={self.creation_method})")

    def __repr__(self) -> str:
        return self.__str__()


class ProdigalResult:
    def __init__(self, sequence: str, result_id: int):
        """
        Represents a "Prodigal Result" - a highly efficient subsequence.

        Args:
            sequence (str): The superpermutation sequence (as a string of digits).
            result_id (int): A unique ID for this "Prodigal Result."
        """
        self.id: int = result_id
        self.sequence: str = sequence
        self.length: int = len(sequence)
        self.permutations: set[int] = set()  # Store hashes of permutations
        self.calculate_permutations()  # Calculate on creation
        self.overlap_rate: float = self.calculate_overlap_rate()

    def calculate_permutations(self):
        """Calculates and stores the set of permutations contained in the sequence."""
        n = N  # Use the global N value
        for i in range(len(self.sequence) - n + 1):
            perm = tuple(int(x) for x in self.sequence[i:i + n])
            if is_valid_permutation(perm, n):
                self.permutations.add(hash_permutation(perm))

    def calculate_overlap_rate(self) -> float:
        """Calculates the overlap rate of the sequence."""
        n = N  # Use the global N value
        total_length = sum(len(str(p)) for p in [unhash_permutation(x,n) for x in self.permutations])
        overlap_length = total_length - len(self.sequence)
        max_possible_overlap = (len(self.permutations) - 1) * (n - 1)
        if max_possible_overlap == 0:
            return 0  # Avoid division by zero
        return overlap_length / max_possible_overlap

    def __str__(self) -> str:
        """String representation for debugging."""
        return (f"ProdigalResult(id={self.id}, length={self.length}, "
                f"overlap_rate={self.overlap_rate:.4f}, num_permutations={len(self.permutations)})")

    def __repr__(self) -> str:
        return self.__str__()

# END SECTION: Data Structures

# START SECTION: Initialization and On-Demand Generation
def initialize_data(initial_n7_prodigals: list[str], initial_winners: dict, initial_losers: dict) -> tuple:
    """Initializes the data structures for the algorithm.
        Modified for n=7, no initial superpermutation, loads initial prodigals.
    Args:
        initial_n7_prodigals (list[str]): A list of initial n=7 Prodigal Result strings.
        initial_winners (dict):  Initial Winner k-mers and weights.
        initial_losers (dict): Initial Loser k-mers and weights.

    Returns:
        tuple: A tuple containing the initialized data structures:
               (prodigal_results, winners, losers, meta_hierarchy, limbo_list, eput, next_prodigal_id)
    """
    prodigal_results = {}  # {prodigal_id: ProdigalResult object}
    winners = initial_winners  # {kmer: weight}
    losers = initial_losers  # {kmer: weight}
    meta_hierarchy = {}  # Track strategy effectiveness
    limbo_list = set()  # Set of permutation hashes.
    eput = {}  # The Enhanced Permutation Universe Tracker

    # Add initial n=7 prodigals
    next_prodigal_id = 0
    for prodigal in initial_n7_prodigals:
        prodigal_results[next_prodigal_id] = ProdigalResult(prodigal, next_prodigal_id)
        next_prodigal_id += 1

    return prodigal_results, winners, losers, meta_hierarchy, limbo_list, eput, next_prodigal_id

def generate_permutations_on_demand_hypothetical(current_sequence, kmer, n, k):
    """Generates candidate permutations for hypothetical prodigals."""
    valid_permutations = set()
    all_perms = generate_permutations(n)
    for perm in all_perms:
        perm_str = "".join(str(x) for x in perm)
        if kmer == perm_str[:k] or kmer == perm_str[-k:]:
           valid_permutations.add(hash_permutation(perm))

    filtered_permutations = set()
    for perm_hash in valid_permutations:
        perm_str = "".join(str(x) for x in unhash_permutation(perm_hash, n))
        is_in_limbo = False

        # Basic Loser check (can be expanded)
        for i in range(len(perm_str) - (n-1) + 1):
            kmer7 = perm_str[i:i+(n-1)]
            if kmer7 in losers and losers[kmer7] > 5:  # Threshold for "Loser"
                is_in_limbo = True
                break
        for i in range(len(perm_str) - (n-2) + 1):
            kmer6 = perm_str[i:i+(n-2)]
            if kmer6 in losers and losers[kmer6] > 5:
                is_in_limbo = True;
                break

        if not is_in_limbo:
            filtered_permutations.add(perm_hash)

    return filtered_permutations

def generate_hypothetical_prodigals(prodigal_results, winners, losers, n, num_to_generate=50, min_length=10, max_length=100):
    """Generates hypothetical prodigal results based on existing data.
    Uses De Bruijn graphs, winners, losers
    """
    hypothetical_prodigals = {}
    next_hypothetical_id = 0

    # 1. Build De Bruijn graphs (k=n-1 and k=n-2)
    combined_prodigal_sequence = "".join([p.sequence for p in prodigal_results.values()])
    graph_k6 = analysis_scripts.build_debruijn_graph(n, 6, superpermutation=combined_prodigal_sequence) #n-1
    graph_k5 = analysis_scripts.build_debruijn_graph(n, 5, superpermutation=combined_prodigal_sequence) #n-2
    analysis_scripts.add_weights_to_debruijn(graph_k6, winners, losers)
    analysis_scripts.add_weights_to_debruijn(graph_k5, winners, losers)

    #Create set of all current prodigal permutations.
    current_prodigals = set()
    for p in prodigal_results:
        current_prodigals.update(prodigal_results[p].permutations)

    for _ in range(num_to_generate):
        # 2. Choose a starting point (preferentially a cycle or high-weight path)
        start_kmer = None
        if random.random() < 0.7:  # 70% chance to start from a cycle in larger k graph
            if graph_k6 and graph_k6.edges:
                cycles = list(nx.simple_cycles(graph_k6))
                if (cycles):
                    cycles.sort(key=lambda x: sum(winners.get("".join(str(y) for y in x[i:i+n-1]),0) for i in range(len(x)-n+2)), reverse = True) #Sort based on winners
                    cycle = random.choice(cycles[:5]) if len(cycles) > 5 else random.choice(cycles) #Choose from top cycles
                    start_kmer = cycle[0] #Just take the first node.

        if not start_kmer: #try from smaller k graph
            if graph_k5 and graph_k5.edges:
                cycles = list(nx.simple_cycles(graph_k5))
                if cycles:
                    cycles.sort(key=lambda x: sum(winners.get("".join(str(y) for y in x[i:i+n-2]),0) for i in range(len(x)-n+3)), reverse = True)
                    cycle = random.choice(cycles[:5]) if len(cycles) > 5 else random.choice(cycles)
                    start_kmer = cycle[0] #Just take the first node.

        if not start_kmer: # Fallback to random kmer from winners.
            if winners:
              top_winners = heapq.nlargest(10, winners.items(), key=lambda item: item[1])
              start_kmer = random.choice(top_winners)[0]
            else:
                continue #Skip if we have no data at all.
        
        # 3. Extend the sequence
        current_sequence = start_kmer
        attempts = 0
        while len(current_sequence) < n * max_length and attempts < 100: # Limit length and attempts
            attempts += 1
            
            #Prioritize Overlap n-1
            candidates = generate_permutations_on_demand_hypothetical(current_sequence, "",  n, n-1)  # Use n-1 mers
            if not candidates:
                candidates = generate_permutations_on_demand_hypothetical(current_sequence, "", n, n-2) # Try with n-2
            if not candidates:
                break
            
            #Choose a random candidate
            best_candidate = unhash_permutation(random.choice(list(candidates)), n)
            overlap = calculate_overlap(current_sequence, "".join(str(x) for x in best_candidate))
            if overlap > 0:
                current_sequence += "".join(str(x) for x in best_candidate)[overlap:]
            else: #Should never happen, due to generate_permutations_on_demand_hypothetical
                break


        # 4. Check against criteria and add if valid
        perms_in_sequence = set()
        for i in range(len(current_sequence) - n + 1):
            perm = tuple(int(x) for x in current_sequence[i:i+n])
            if is_valid_permutation(perm, n):
                perms_in_sequence.add(hash_permutation(perm))
        
        if analysis_scripts.is_prodigal(current_sequence, [unhash_permutation(x,n) for x in perms_in_sequence], n, min_length=min_length, overlap_threshold=HYPOTHETICAL_PRODIGAL_OVERLAP_THRESHOLD) and len(perms_in_sequence) > 0:
            hypothetical_prodigals[next_hypothetical_id] = ProdigalResult(current_sequence, next_hypothetical_id)
            next_hypothetical_id += 1

    return hypothetical_prodigals

def generate_permutations_on_demand(prefix: str, suffix: str, prodigal_results: dict, winners: dict, losers: dict,
                                   n: int, eput: dict, limbo_list: set, min_overlap: int,
                                   hypothetical_prodigals: dict = None) -> set[int]:
    """Generates permutations on demand, extending a given prefix or suffix.
       Prioritizes "Prodigal" extensions, uses "Winners" and "Losers," and
       avoids already-used permutations and the "Limbo List."

    Args:
        prefix (str): The prefix of the current superpermutation.
        suffix (str): The suffix of the current superpermutation.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        n (int): The value of n.
        eput (dict): The Enhanced Permutation Universe Tracker.
        limbo_list (set): The set of permutation hashes to avoid.
        min_overlap (int):  The minimum required overlap.
        hypothetical_prodigals (dict): Optional dictionary of Hypothetical Prodigals

    Returns:
        set[int]: A set of *permutation hashes* that are potential extensions.
    """
    valid_permutations = set()

    # Prioritize Hypothetical Prodigal extensions
    if hypothetical_prodigals:
        for prodigal_id, prodigal in hypothetical_prodigals.items():
            if prefix and prodigal.sequence.startswith(prefix[-min_overlap:]):
                for i in range(len(prodigal.sequence) - (n - 1)):
                    perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                    if is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                        valid_permutations.add(hash_permutation(perm))
            if suffix and prodigal.sequence.endswith(suffix[:min_overlap]):
                for i in range(len(prodigal.sequence) - (n - 1)):
                    perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                    if is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                        valid_permutations.add(hash_permutation(perm))

    # Prioritize Prodigal extensions
    for prodigal_id, prodigal in prodigal_results.items():
        if prefix and prodigal.sequence.startswith(prefix[-min_overlap:]):
            for i in range(len(prodigal.sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                if is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                    valid_permutations.add(hash_permutation(perm))
        if suffix and prodigal.sequence.endswith(suffix[:min_overlap]):
            for i in range(len(prodigal.sequence) - (n - 1)):
                perm = tuple(int(x) for x in prodigal.sequence[i:i + n])
                if is_valid_permutation(perm, n) and hash_permutation(perm) not in eput:
                    valid_permutations.add(hash_permutation(perm))

    # Filter based on Limbo List and create final set of hashes
    filtered_permutations = set()
    for perm_hash in valid_permutations:
        perm_str = "".join(str(x) for x in unhash_permutation(perm_hash, n))
        is_in_limbo = False

        # Basic Loser check (using 6-mers and 5-mers for n=7)
        for k in [n - 1, n - 2]:  # Check n-1-mers and n-2-mers
            for i in range(len(perm_str) - k + 1):
                kmer = perm_str[i:i+k]
                if kmer in limbo_list:
                    is_in_limbo = True
                    break
            if is_in_limbo:
                break

        if not is_in_limbo:
            filtered_permutations.add(perm_hash)

    return filtered_permutations
    
    # START SECTION: Scoring and Construction

def calculate_score(current_superpermutation: str, permutation_hash: int, prodigal_results: dict,
                    winners: dict, losers: dict, layout_memory: LayoutMemory, n: int,
                    golden_ratio_points: list[int], hypothetical_prodigals: dict) -> float:
    """Calculates the score for adding a permutation to the current superpermutation (n=7 version).

    Args:
        current_superpermutation (str): The current superpermutation string.
        permutation_hash (int): The hash of the candidate permutation.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        layout_memory (LayoutMemory): The LayoutMemory object.
        n (int): The value of n (should be 7).
        golden_ratio_points (list): List of golden ratio points.
        hypothetical_prodigals (dict): Dictionary of Hypothetical Prodigals

    Returns:
        float: The score for the candidate permutation. Higher is better.
    """
    permutation = unhash_permutation(permutation_hash, n)
    permutation_string = "".join(str(x) for x in permutation)
    overlap = calculate_overlap(current_superpermutation, permutation_string)
    score = overlap * 5  # Base score based on overlap

    # Prodigal Result Bonus (very high)
    prodigal_bonus = 0
    for prodigal_id, prodigal in prodigal_results.items():
        if permutation_string in prodigal.sequence:
            prodigal_bonus += prodigal.length * 100  # Large bonus
            break  # Only check if contained, not full extension
            
    # Hypothetical prodigal bonus
    hypothetical_bonus = 0
    if hypothetical_prodigals:
        for h_prodigal_id, h_prodigal in hypothetical_prodigals.items():
            if permutation_string in h_prodigal.sequence:
                hypothetical_bonus += h_prodigal.length * 25 #Smaller bonus
                break

    # Winner and Loser Bonus/Penalty (using Layout Memory, reduced influence)
    k_values = [n - 1, n - 2]
    layout_bonus = 0
    for k in k_values:
        if len(current_superpermutation) >= k:
            kmer_end = current_superpermutation[-k:]
            kmer_start = permutation_string[:k]
            layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, 1)

    # Golden Ratio Bonus (small, dynamic)
    golden_ratio_bonus = 0
    insertion_point = len(current_superpermutation)
    for point in golden_ratio_points:
        distance = abs(insertion_point - point)
        golden_ratio_bonus += math.exp(-distance / (len(current_superpermutation)/20))  # Smaller divisor = tighter

    # Loser Penalty (Veto)
    loser_penalty = 0
    for k in [6, 5]:  # Check 6-mers and 5-mers for n=7
        for i in range(len(permutation_string) - k + 1):
            kmer = permutation_string[i:i+k]
            loser_penalty += losers.get(kmer, 0) * 5

    score += prodigal_bonus + layout_bonus + golden_ratio_bonus + hypothetical_bonus - loser_penalty

    return score

def construct_superpermutation(initial_permutations: list, prodigal_results: dict, winners: dict, losers: dict,
                              layout_memory: LayoutMemory, meta_hierarchy: dict, limbo_list: set, n: int,
                              hypothetical_prodigals: dict) -> tuple[str, set[int]]:
    """Constructs a superpermutation using the dynamic prodigal approach (n=7 version).

    Args:
        initial_permutations (list):  Empty list, will start with longest prodigal.
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers and their weights.
        losers (dict): Dictionary of Loser k-mers and their weights.
        layout_memory (LayoutMemory): The LayoutMemory Object.
        meta_hierarchy (dict): Dictionary for tracking strategy effectiveness.
        limbo_list (set): Set of permutation hashes to avoid.
        n (int): The value of n.
        hypothetical_prodigals (dict): "Hypothetical Prodigals" to use.

    Returns:
        tuple: (superpermutation string, set of used permutation hashes)
    """

    superpermutation = ""
    used_permutations = set()

    # Initialize with the longest "Prodigal Result"
    best_prodigal_key = max(prodigal_results, key=lambda k: prodigal_results[k].length)
    superpermutation = prodigal_results[best_prodigal_key].sequence
    used_permutations.update(prodigal_results[best_prodigal_key].permutations)

    golden_ratio_points = calculate_golden_ratio_points(len(superpermutation), levels=3)

    while True:  # Continue until no more additions can be made
        best_candidate = None
        best_score = -float('inf')

        # Find frontier k-mers
        prefix = superpermutation[:n - 1]
        suffix = superpermutation[-(n - 1):]

        # Generate candidates (very small set, focused on the frontier)
        candidates = generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, used_permutations, limbo_list, n - 1, hypothetical_prodigals)
        if not candidates:
            candidates = generate_permutations_on_demand(prefix, suffix, prodigal_results, winners, losers, n, used_permutations, limbo_list, n - 2, hypothetical_prodigals)
        if not candidates:
            # print("No candidates found. Stopping.") # For Debugging
            break  # No more candidates can be added

        #Deterministic selection from candidates:
        scored_candidates = []
        for candidate_hash in candidates:
            score = calculate_score(superpermutation, candidate_hash, prodigal_results, winners, losers, layout_memory, n, golden_ratio_points, hypothetical_prodigals)
            scored_candidates.append((score, candidate_hash))
        
        best_candidate = None
        if scored_candidates:
            scored_candidates.sort(reverse=True) #Sort by score
            best_candidate = scored_candidates[0][1] #Take top result.

        if best_candidate is not None:
            best_candidate_perm = unhash_permutation(best_candidate, n)
            overlap = calculate_overlap(superpermutation, "".join(str(x) for x in best_candidate_perm))
            superpermutation += "".join(str(x) for x in best_candidate_perm)[overlap:]  # Add to superpermutation
            used_permutations.add(best_candidate)

            # Update golden ratio points
            golden_ratio_points = calculate_golden_ratio_points(len(superpermutation))

            # Prodigal Result Check
            new_prodigals = analysis_scripts.find_prodigal_results(superpermutation, n, min_length=PRODIGAL_MIN_LENGTH, overlap_threshold=PRODIGAL_OVERLAP_THRESHOLD)
            for prodigal_seq in new_prodigals:
                is_new = True
                for existing_prodigal_id, existing_prodigal in prodigal_results.items():
                    if prodigal_seq in existing_prodigal.sequence:
                        is_new = False
                        break
                if is_new:
                    new_id = len(prodigal_results) + 1
                    prodigal_results[new_id] = ProdigalResult(prodigal_seq, new_id)
                    # print(f"New Prodigal Result found: {prodigal_seq}") # For Debugging

            #Update ePUT
            perm_hash = best_candidate
            if perm_hash not in eput: #Should now always be the case
                eput[perm_hash] = PermutationData(best_candidate_perm, in_sample=False, creation_method="dynamic_generation") # All are now dynamically generated
            eput[perm_hash].used_count += 1
            eput[perm_hash].used_in_final = True
            #Update neighbors in ePUT
            perm_string = "".join(str(x) for x in best_candidate_perm)
            for k in [n-1, n-2]:
                prefix = superpermutation[:k]
                suffix = superpermutation[-k:]
                prefix_perms = set()
                suffix_perms = set()
                for i in range(len(prefix) - n + 1):
                    p = tuple(int(x) for x in prefix[i:i+n])
                    if is_valid_permutation(p,n):
                        prefix_perms.add(hash_permutation(p))
                for i in range(len(suffix) - n + 1):
                    p = tuple(int(x) for x in suffix[i:i+n])
                    if is_valid_permutation(p,n):
                        suffix_perms.add(hash_permutation(p))
                for other_perm_hash in prefix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        kmer1 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[-k:])
                        kmer2 = perm_string[:k]
                        layout_memory.update_distances(kmer1,kmer2, len(superpermutation) - i - len(prefix), "n7_dynamic")
                for other_perm_hash in suffix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        kmer1 = perm_string[-k:]
                        kmer2 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[:k])
                        layout_memory.update_distances(kmer1, kmer2, 1, "n7_dynamic")

        else:
            break  # If we get here, we are stuck

    return superpermutation, used_permutations

# END SECTION: Superpermutation Construction

# START SECTION: Main Function and Distinctness Check
def is_cyclically_distinct(s1: str, s2: str) -> bool:
    """Checks if two strings are cyclically distinct.
       Returns True if they are distinct, and False if one is a cyclic shift of the other.
    """
    if len(s1) != len(s2):
        return True  # Different lengths, so they must be distinct

    s1s1 = s1 + s1  # Concatenate s1 with itself
    return s2 not in s1s1

def main():
    """
    Main function to execute the Dynamic Prodigal Assembly algorithm for n=7.
    Generates multiple distinct 5906 superpermutations.
    """
    n = 7  # Set n=7
    num_iterations = 1000  # Set a high number; it will likely stop much earlier

    # --- File Paths (IMPORTANT: Adjust these paths as needed) ---
    initial_winners_losers_n7_file = "initial_winners_losers_n7.txt"
    prodigal_results_n7_file = "prodigal_results_n7.txt"  # Will contain the initial 5906 string
    distinct_superpermutations_file = "distinct_superpermutations_n7.txt" # Output file
    layout_memory_file = "layout_memory_n7.pkl"


    # --- Load Initial Data ---
    initial_winners, initial_losers = {}, {}
    try:
        with open(initial_winners_losers_n7_file, "r") as f:
            for line in f:
                kmer, w_type, weight = line.strip().split(",")
                if w_type == "winner":
                    initial_winners[kmer] = int(weight)
                else:
                    initial_losers[kmer] = int(weight)
    except FileNotFoundError:
        print(f"Initial Winners/Losers file ({initial_winners_losers_n7_file}) not found. Starting with empty.")


    initial_n7_prodigals = []
    try:
        with open(prodigal_results_n7_file, "r") as f:
            initial_n7_prodigals = [line.strip() for line in f]
    except FileNotFoundError:
        print(f"Initial n=7 Prodigal Results file ({prodigal_results_n7_file}) not found.  Starting with empty.")
        #In this case, we will create an empty file
        with open(prodigal_results_n7_file, "w") as f:
            pass


    # --- Initialize Data Structures ---
    prodigal_results, winners, losers, meta_hierarchy, limbo_list, eput, next_prodigal_id = initialize_data(
        "", initial_n7_prodigals, initial_winners, initial_losers
    )  #  Empty string, as we *build* the superpermutation from scratch
    
    #Create Initial Laminate
    laminates = []
    for prodigal in initial_n7_prodigals:
        laminates.append(analysis_scripts.create_laminate(prodigal, n, n-1))
        laminates.append(analysis_scripts.create_laminate(prodigal, n, n-2))
    
    #Load layout memory
    layout_memory = LayoutMemory()
    try:
        layout_memory.load_from_file(layout_memory_file)
        print("Loaded LayoutMemory from file.")
    except FileNotFoundError:
        print("No existing LayoutMemory file found. Starting with a new one.")

    # Load existing distinct superpermutations
    existing_superpermutations = set()
    try:
        with open(distinct_superpermutations_file, "r") as f:
            for line in f:
                existing_superpermutations.add(line.strip())
    except FileNotFoundError:
        print(f"No existing distinct superpermutations file found.")

    distinct_count = 0
    
    for iteration in range(num_iterations):
        print(f"Starting iteration {iteration + 1}...")
        start_time = time.time()

        # 1. Generate Hypothetical Prodigals (now done *before* construction)
        hypothetical_prodigals = analysis_scripts.generate_hypothetical_prodigals(prodigal_results, winners, losers, n)
        print(f"  Generated {len(hypothetical_prodigals)} hypothetical prodigals.")

        # 2. Construct Superpermutation (using the dynamic approach)
        superpermutation, used_permutations = construct_superpermutation([], prodigal_results, winners, losers, layout_memory, meta_hierarchy, limbo_list, n, hypothetical_prodigals)
        print(f"  Superpermutation length: {len(superpermutation)}")

        # 3. Update Data
        analysis_results = analysis_scripts.analyze_superpermutation(superpermutation, n)  # Use analysis script
        print(f"  Valid: {analysis_results['validity']}")
        print(f"  Overlap Distribution: {analysis_results['overlap_distribution']}")

        # Check for 5906 length and distinctness
        if analysis_results['validity'] and len(superpermutation) == 5906:
            is_distinct = True
            for existing_sp in existing_superpermutations:
                if is_cyclically_distinct(superpermutation, existing_sp) == False:
                    is_distinct = False
                    break

            if is_distinct:
                print("  Found a *distinct* 5906 superpermutation!")
                existing_superpermutations.add(superpermutation)
                distinct_count += 1
                with open(distinct_superpermutations_file, "a") as f:
                    f.write(superpermutation + "\n")

                #Create and add new laminate
                new_lam_1 = analysis_scripts.create_laminate(superpermutation, n, n-1)
                new_lam_2 = analysis_scripts.create_laminate(superpermutation, n, n-2)
                laminates.append(new_lam_1)
                laminates.append(new_lam_2)
            else:
                print("  Found a 5906 superpermutation, but it's a duplicate.")
        else:
            print(" Run did not produce a valid minimal superpermutation.")

        # Find and add new prodigal results. Stricter criteria.
        new_prodigals = analysis_scripts.find_prodigal_results(superpermutation, n, min_length=PRODIGAL_MIN_LENGTH, overlap_threshold=PRODIGAL_OVERLAP_THRESHOLD)
        for prodigal_seq in new_prodigals:
            is_new = True
            for existing_prodigal_id, existing_prodigal in prodigal_results.items():
                if prodigal_seq in existing_prodigal.sequence:
                    is_new = False
                    break
            if is_new:
                prodigal_results[next_prodigal_id] = ProdigalResult(prodigal_seq, next_prodigal_id)
                next_prodigal_id += 1

        #Update ePUT
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - n + 1):
            perm = s_tuple[i:i+n]
            if is_valid_permutation(perm, n):
                perm_hash = hash_permutation(perm)
                if perm_hash not in eput:
                    eput[perm_hash] = PermutationData(perm, in_sample=False, creation_method="dynamic_generation")
                eput[perm_hash].used_count += 1
                eput[perm_hash].used_in_final = True # All are used.
                #Update neighbors
                if i > 0:
                    prev_perm = s_tuple[i-1:i-1+n]
                    if is_valid_permutation(prev_perm, n):
                        eput[perm_hash].neighbors.add(hash_permutation(prev_perm))
                if i < len(s_tuple) - n:
                    next_perm = s_tuple[i+1:i+1+n]
                    if is_valid_permutation(next_perm, n):
                        eput[perm_hash].neighbors.add(hash_permutation(next_perm))

        # Update "Winners" and "Losers" (using the new superpermutation, and k=6 and k=7)
        new_winners6, new_losers6 = analysis_scripts.calculate_winners_losers([superpermutation], n, k=6)
        new_winners7, new_losers7 = analysis_scripts.calculate_winners_losers([superpermutation], n, k=7)

        for kmer, weight in new_winners6.items():
            winners[kmer] = winners.get(kmer, 0) + weight
        for kmer, weight in new_losers6.items():
            losers[kmer] = losers.get(kmer, 0) + weight
            limbo_list.add(kmer)  # Add to limbo list
        for kmer, weight in new_winners7.items():
            winners[kmer] = winners.get(kmer, 0) + weight
        for kmer, weight in new_losers7.items():
            losers[kmer] = losers.get(kmer, 0) + weight
            limbo_list.add(kmer)
        
        # Update Layout Memory
        layout_memory.add_sequence(superpermutation, n, 6, f"run_{iteration}")
        layout_memory.add_sequence(superpermutation, n, 5, f"run_{iteration}")

        # Update "Meta-Hierarchy" (simplified for this example)
        meta_hierarchy.setdefault("run_lengths", []).append(len(superpermutation))
        meta_hierarchy.setdefault("prodigal_counts", []).append(len(prodigal_results))

        end_time = time.time()
        print(f"  Iteration {iteration + 1} completed in {end_time - start_time:.2f} seconds.")
        print(f"  Distinct 5906 superpermutations found so far: {distinct_count}")

        # Check stopping criteria
        if len(superpermutation) == 5906:
            # Check for early stopping based on lack of new distinct solutions
            is_new_solution = True
            for existing_sp in existing_superpermutations:
                if not is_cyclically_distinct(superpermutation, existing_sp):
                    is_new_solution = False
                    break

            if not is_new_solution:
                no_new_solutions_count = meta_hierarchy.get("no_new_solutions_count", 0) + 1
                meta_hierarchy["no_new_solutions_count"] = no_new_solutions_count
                if no_new_solutions_count >= 20:
                    print("No new distinct 5906 solutions found in 20 iterations. Stopping.")
                    break
            else:
                meta_hierarchy["no_new_solutions_count"] = 0  # Reset counter

if __name__ == "__main__":
    random.seed(RANDOM_SEED)  # Set the random seed for reproducibility
    main()

```