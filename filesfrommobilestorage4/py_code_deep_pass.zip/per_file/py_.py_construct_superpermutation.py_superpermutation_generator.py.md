# File: py/.py/construct_superpermutation.py_superpermutation_generator.py

**Extension:** .py

**Lines:** 236 | **Words:** 1090

## Keyword Hits

- SFBB: 0

- superperm: 36

- superpermutation: 36

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 52

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: json, logging, random

- From-imports: analysis_scripts_final, construct_superpermutation, layout_memory, utils

- Classes (0): (none)

- Functions (4): construct_superpermutation, generate_candidates, calculate_score, main


---


## Full Source


```text

# construct_superpermutation.py
import random
import logging
import json
from utils import calculate_overlap, hash_permutation, unhash_permutation, kmer_to_int, int_to_kmer, is_valid_permutation
from layout_memory import LayoutMemory
from analysis_scripts_final import is_prodigal, generate_hypothetical_prodigals, generate_permutations

DATA_FILENAME = "superpermutation_data.json"

def construct_superpermutation(n, initial_sequence="", prodigal_results=None, winners=None, losers=None, layout_memory=None, limbo_list=None, eput=None):
    """Constructs a superpermutation using a dynamic prodigal approach.

    This function implements the core logic for building the superpermutation.  It manages the search process,
    candidate generation, scoring, and data persistence.
    """

    if layout_memory is None:
        layout_memory = LayoutMemory()
    if limbo_list is None:
        limbo_list = set()
    if prodigal_results is None:
        prodigal_results = {}
    if winners is None:
        winners = {}
    if losers is None:
        losers = {}
    if eput is None:
        eput = {}

    superpermutation = list(initial_sequence)  # Start with the initial sequence (if provided)

    try:
        with open(DATA_FILENAME, 'r') as f:
            data = json.load(f)
            prodigal_results = data.get("prodigal_results", {})
            winners = data.get("winners", {})
            losers = data.get("losers", {})
            limbo_list = set(data.get("limbo_list", []))  # Load as a list, then convert to set
            layout_memory.memory = data.get("layout_memory", {})
            eput = data.get("eput", {})
    except FileNotFoundError:
        data = {}  # Create a new data dictionary if the file doesn't exist

    all_permutations = generate_permutations(n)  # Generate all permutations once and store them
    missing_permutations = set(hash_permutation(p) for p in all_permutations) - set(eput.keys())  # Initialize missing permutations

    while missing_permutations:  # Continue until all permutations are covered
        best_candidate = None
        best_score = -float('inf')  # Initialize best score to negative infinity

        candidates = generate_candidates(superpermutation, missing_permutations, prodigal_results, winners, losers, layout_memory, n, eput, limbo_list)

        for candidate_hash in candidates:
            candidate_perm = unhash_permutation(candidate_hash, n)  # Convert hash back to permutation tuple
            candidate_str = "".join(str(x) for x in candidate_perm)  # Convert permutation to string

            for i in range(len(superpermutation) + 1):  # Iterate through possible insertion points
                overlap = calculate_overlap("".join(superpermutation[max(0, i - (n - 1)):i]), candidate_str)  # Calculate overlap
                score = calculate_score("".join(superpermutation), candidate_hash, prodigal_results, winners, losers, layout_memory, n, missing_permutations, eput)  # Calculate score

                if score > best_score:  # Update best candidate if current score is better
                    best_score = score
                    best_candidate = candidate_str
                    best_insertion_point = i

        if best_candidate:  # If a best candidate was found
            superpermutation = superpermutation[:best_insertion_point] + list(best_candidate) + superpermutation[best_insertion_point:]  # Insert the best candidate

            # Update ePUT, layout memory, missing_permutations
            candidate_perm = tuple(int(x) for x in best_candidate)
            candidate_hash = hash_permutation(candidate_perm)
            if candidate_hash not in eput: # Check if it is already initialized before initializing
                eput[candidate_hash] = {"used_count": 0, "used_in_final": False, "neighbors": set()} #Initialize properly
            eput[candidate_hash]["used_count"] += 1
            eput[candidate_hash]["used_in_final"] = True

            # ... (Neighbor updating, as in your original code) ...

            layout_memory.add_sequence("".join(superpermutation), n, n-1, "main_loop")  # Add the updated superpermutation to layout memory

            missing_permutations.discard(candidate_hash)  # Remove the covered permutation from missing permutations

            # Prodigal and hypothetical prodigal handling
            if is_prodigal(candidate_perm, all_permutations, n):
                prodigal_results[hash_permutation(candidate_perm)] = True  # Add to prodigal results

            hypothetical_prodigals = generate_hypothetical_prodigals(prodigal_results, winners, losers, n)
            # ... (Use hypothetical_prodigals in candidate generation)

            # Save data after each iteration
            data["prodigal_results"] = prodigal_results
            data["winners"] = winners
            data["losers"] = losers
            data["limbo_list"] = list(limbo_list)  # Convert set to list for JSON serialization
            data["layout_memory"] = layout_memory.memory
            data["eput"] = eput
            with open(DATA_FILENAME, 'w') as f:
                json.dump(data, f)  # Save the data to the JSON file

        else:
            break  # If no suitable candidate is found, exit the loop

    return "".join(superpermutation)
	
	#This part of construct_superpermutation.py contains the main loop of the superpermutation generation algorithm. It handles data loading and saving, iterates through missing permutations, selects the best candidate, updates data structures, and manages prodigal sequences.  It interacts with the generate_candidates and calculate_score functions (which are defined in the next chunk) to perform the core search and evaluation.  It also uses the utility functions from utils.py and the LayoutMemory class.
    
    # construct_superpermutation.py (Continued)

def generate_candidates(superpermutation, missing_permutations, prodigal_results, winners, losers, layout_memory, n, eput, limbo_list):
    """Generates candidate permutations.

    This function combines several strategies to generate promising candidates:
    1. Candidates from missing permutations (prioritized).
    2. Candidates extending known prodigal results.
    3. Candidates connecting to "winners" (good sequences).
    """

    candidates = set()
    k = n - 1  # k-mer length

    # 1. Candidates from missing permutations (prioritized)
    for missing_perm_hash in missing_permutations:
        missing_perm = unhash_permutation(missing_perm_hash, n)

        # Generate candidates by extending missing permutations
        for i in range(1, n + 1):  # Try adding each digit at the end
            candidate_perm = missing_perm + (i,)
            if is_valid_permutation(candidate_perm, n):
                candidate_hash = hash_permutation(candidate_perm)
                if candidate_hash not in eput and candidate_hash not in limbo_list:
                    candidates.add(candidate_hash)

        # Generate candidates by prepending to missing permutations
        for i in range(1, n + 1):  # Try adding each digit at the beginning
            candidate_perm = (i,) + missing_perm
            if is_valid_permutation(candidate_perm, n):
                candidate_hash = hash_permutation(candidate_perm)
                if candidate_hash not in eput and candidate_hash not in limbo_list:
                    candidates.add(candidate_hash)

        #Generate candidates by combining with existing superpermutation
        if superpermutation:
            last_k_minus_1 = tuple(int(digit) for digit in superpermutation[-(k):]) # Last k-1 digits
            for i in range(1, n + 1):
                candidate_perm = last_k_minus_1 + (i,)
                if is_valid_permutation(candidate_perm, n):
                    candidate_hash = hash_permutation(candidate_perm)
                    if candidate_hash not in eput and candidate_hash not in limbo_list:
                        candidates.add(candidate_hash)

    # 2. Candidates extending known prodigal results
    for prodigal_hash in prodigal_results:
        prodigal = unhash_permutation(prodigal_hash, n)
        for i in range(1, n + 1):
            candidate_perm = prodigal + (i,)
            if is_valid_permutation(candidate_perm, n):
                candidate_hash = hash_permutation(candidate_perm)
                if candidate_hash not in eput and candidate_hash not in limbo_list:
                    candidates.add(candidate_hash)


    # 3. Candidates connecting to "winners" (good sequences)
    for winner_hash in winners:
        winner = unhash_permutation(winner_hash, n)
        # ... (Add logic here to generate candidates connecting to winners)

    return candidates


def calculate_score(current_superpermutation, permutation_hash, prodigal_results, winners, losers, layout_memory, n, missing_permutations, eput):
    """Calculates the score for adding a permutation.

    The score combines several factors:
    1. Overlap with the current superpermutation.
    2. Bonus for covering a missing permutation.
    3. Layout score (from LayoutMemory).
    4. Prodigal bonus.
    5. Winner/loser bonus/penalty.
    """

    permutation = unhash_permutation(permutation_hash, n)
    permutation_string = "".join(str(x) for x in permutation)
    overlap = calculate_overlap(current_superpermutation, permutation_string)

    score = overlap * 5  # Base score (adjust weight)

    if permutation_hash in missing_permutations:
        score += 1000  # Bonus for covering missing permutation (adjust weight)

    # Layout score
    k = n - 1
    if current_superpermutation: # Make sure it is not empty
        last_k_minus_1 = tuple(int(digit) for digit in current_superpermutation[-k:])
        kmer2 = tuple(int(digit) for digit in permutation_string[:k])
        score += layout_memory.get_layout_score(last_k_minus_1, kmer2) * 2  # Adjust weight

    # Prodigal bonus (if applicable)
    if permutation_hash in prodigal_results:
        score += 500  # Adjust weight

    # Winner/loser bonus/penalty (if applicable)
    if permutation_hash in winners:
        score += 200 # Adjust weight
    elif permutation_hash in losers:
        score -= 100 # Adjust weight

    return score


# superpermutation_generator.py
import logging
from utils import setup_logging, normalize_sequence, compute_checksum
from construct_superpermutation import construct_superpermutation
from analysis_scripts_final import generate_permutations  # Import generate_permutations
from layout_memory import LayoutMemory

def main():
    setup_logging()
    n = 7  # or 8
    seed = 42
    layout_memory = LayoutMemory()

    all_permutations = generate_permutations(n)  # Generate all permutations ONCE and store them. This is more efficient.

    superpermutation = construct_superpermutation(n, initial_sequence="", prodigal_results={}, winners={}, losers={}, layout_memory=layout_memory, limbo_list=set(), eput={})

    if superpermutation:
        normalized_sequence = normalize_sequence(superpermutation)
        # ... (Verification and output - will be added later)

    else:
        print("Superpermutation generation failed.")

if __name__ == "__main__":
    main()

```