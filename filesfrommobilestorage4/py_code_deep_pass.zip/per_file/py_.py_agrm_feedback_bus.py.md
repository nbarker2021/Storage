# File: py/.py/agrm_feedback_bus.py

**Extension:** .py

**Lines:** 32 | **Words:** 104

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: collections

- Classes (1): AGRMFeedbackBus

- Functions (7): __init__, broadcast, collect_all, log_failure, get_memory_map, get_most_failed_nodes, print_summary


---


## Full Source


```text


from collections import defaultdict

class AGRMFeedbackBus:
    def __init__(self):
        self.buffer = []
        self.memory = defaultdict(int)

    def broadcast(self, signal: str, payload: dict = None):
        entry = {"signal": signal, "payload": payload or {}}
        self.buffer.append(entry)

    def collect_all(self):
        all_signals = self.buffer[:]
        self.buffer.clear()
        return all_signals

    def log_failure(self, node_id: int):
        self.memory[node_id] += 1

    def get_memory_map(self):
        return dict(self.memory)

    def get_most_failed_nodes(self, threshold: int = 3):
        return [nid for nid, count in self.memory.items() if count >= threshold]

    def print_summary(self):
        print("[FeedbackBus] Summary of memory map:")
        for nid, count in self.memory.items():
            if count > 0:
                print(f"  Node {nid} failed {count} times")


```