# File: py/.py/result_analyzer.py

**Extension:** .py

**Lines:** 71 | **Words:** 300

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 1

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: json, os

- From-imports: core.cmplx_logger

- Classes (1): ResultAnalyzerAgent

- Functions (6): __init__, load_ledger, record_run, save_ledger, get_summary, export_summary_markdown


---


## Full Source


```text

import os
import json
from core.cmplx_logger import log

class ResultAnalyzerAgent:
    def __init__(self, ledger_path="results/logbook.json"):
        self.ledger_path = ledger_path
        self.ledger = self.load_ledger()

    def load_ledger(self):
        if os.path.exists(self.ledger_path):
            with open(self.ledger_path, 'r') as f:
                return json.load(f)
        return {}

    def record_run(self, dataset_name, plan, audit):
        dataset_key = os.path.basename(dataset_name)
        plan_str = json.dumps(plan, sort_keys=True)

        if dataset_key not in self.ledger:
            self.ledger[dataset_key] = []

        self.ledger[dataset_key].append({
            "plan": plan,
            "status": audit.get("final_status", "unknown"),
            "entropy": audit.get("entropy", 0.5),
            "stalls": audit.get("merge_stall_events", 0),
            "errors": audit.get("error_log", []),
        })

        self.save_ledger()

        if len(self.ledger[dataset_key]) > 1:
            prev = self.ledger[dataset_key][-2]
            if prev["status"] == "complete" and audit.get("final_status") != "complete":
                return "regression"
        return "ok"

    def save_ledger(self):
        os.makedirs(os.path.dirname(self.ledger_path), exist_ok=True)
        with open(self.ledger_path, "w") as f:
            json.dump(self.ledger, f, indent=2)

    def get_summary(self, dataset_name):
        key = os.path.basename(dataset_name)
        if key not in self.ledger:
            return {}
        return {
            "total_runs": len(self.ledger[key]),
            "complete": sum(1 for x in self.ledger[key] if x["status"] == "complete"),
            "incomplete": sum(1 for x in self.ledger[key] if x["status"] != "complete"),
            "last_result": self.ledger[key][-1] if self.ledger[key] else None,
            "last_plan": self.ledger[key][-1].get("plan") if self.ledger[key] else None,
        }

    def export_summary_markdown(self, dataset_name, path="results/summary.md"):
        summary = self.get_summary(dataset_name)
        lines = [
            f"# Summary for {dataset_name}",
            f"- Total runs: {summary.get('total_runs', 0)}",
            f"- Completed: {summary.get('complete', 0)}",
            f"- Incomplete: {summary.get('incomplete', 0)}",
        ]
        if summary.get("last_result"):
            lines.append("\n## Last Run:")
            for k, v in summary["last_result"].items():
                lines.append(f"- {k}: {v}")
        with open(path, "w") as f:
            f.write("\n".join(lines))
        log(f"Summary written to {path}", agent="ResultAnalyzer", phase="Export")


```