# File: py/.py/sequence_generation.py

**Extension:** .py

**Lines:** 198 | **Words:** 1041

## Keyword Hits

- SFBB: 0

- superperm: 45

- superpermutation: 45

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 2

- beam: 0

- orchestrator: 0

- hash: 21

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: itertools, math, random

- From-imports: analysis_scripts_final, graph_utils, laminate_utils, layout_memory, prodigal_manager, utils

- Classes (0): (none)

- Functions (2): generate_n_minus_1_superpermutation, generate_distinct_n7_superpermutations


---


## Full Source


```text

# sequence_generation.py
import itertools
import random
import math
from utils import is_valid_permutation, calculate_overlap, hash_permutation, unhash_permutation, setup_logging, normalize_sequence, compute_checksum
#from analysis_scripts_final import find_prodigal_results #Removed, as we can use the main file.
#from construct_superpermutation import construct_superpermutation, generate_candidates, calculate_score, complete_from_partial
#from analysis_scripts_final import is_prodigal, find_prodigal_results, calculate_winners_losers, identify_anti_prodigals, calculate_sequence_winners_losers
from analysis_scripts_final import is_prodigal, find_prodigal_results, calculate_winners_losers, identify_anti_prodigals, calculate_sequence_winners_losers, calculate_segment_efficiency, approximate_derivative, calculate_discrepancy, identify_mega_winners, identify_mega_losers
from laminate_utils import create_laminate, is_compatible, create_anti_laminate, analyze_laminate_density, analyze_laminate_connectivity, update_laminate, merge_laminates, create_n7_constraint_laminate
from layout_memory import LayoutMemory
from graph_utils import build_de_bruijn_graph, add_weights_to_debruijn, find_high_weight_paths, analyze_debruijn_graph
from prodigal_manager import ProdigalManager

def generate_n_minus_1_superpermutation(n, seed):
    """Generates a distinct superpermutation for n-1.
    """
    #We will use our modified n-1 code.

    # --- Constants for n-1 ---
    prodigal_overlap_threshold = 0.98
    prodigal_min_length = 5 #Reduced for testing
    if n-1 > 6:
      prodigal_min_length = int(0.75 * math.factorial(n-1))
    hypothetical_prodigal_overlap_threshold = 0.90
    hypothetical_prodigal_min_length = 4
    hypothetical_prodigal_generation_count = 50  # n-1 is fast
    num_iterations = 1000 #Should be enough.
    layout_k_values = [n - 2, n - 3]

    if seed is not None:
        random.seed(seed)

    # Initialize data structures
    prodigal_manager = ProdigalManager(n-1) # Using prodigal manager

    # Load initial data, if not supplied, it starts with default values.
    winners = {}
    losers = {}

    meta_hierarchy = {}  # Track strategy effectiveness
    limbo_list = set()  # Set of permutation hashes.
    eput = {}  # The Enhanced Permutation Universe Tracker

    # Add initial n-1 prodigals, which in this case is ALWAYS the original 5906
    next_prodigal_id = 0
    

    #Create Initial Laminate, using all available n-7s
    laminates = []
    anti_laminates = []

    layout_memory = LayoutMemory() #Create a layout memory
    superpermutation = ""
    # --- Main Iterative Loop ---
    #for iteration in range(num_iterations): #Now stops when complete, or stuck, or iteration limit.
    iteration = 0
    while len(superpermutation) < sum(math.factorial(i) for i in range(1,n)) and iteration < num_iterations:
        iteration += 1
        #print(f"Starting iteration {iteration}...") #Removed for n=8 use.
        start_time = time.time()

        # 1. Generate Hypothetical Prodigals
        hypothetical_prodigals = generate_hypothetical_prodigals(prodigal_results, winners, losers, n-1, num_to_generate=hypothetical_prodigal_generation_count, min_length=hypothetical_prodigal_min_length, max_length=(n-1)*15) #Longer length limit, due to n=7 speed
        #print(f"  Generated {len(hypothetical_prodigals)} hypothetical prodigals.")

        #Add to the prodigals list
        for h_id, h_prodigal in hypothetical_prodigals.items():
            prodigal_manager.add_prodigal(h_prodigal['sequence'], n-1, "hypothetical") ##########Needs to add all data, not just sequence.
            next_prodigal_id += 1
            # Create and add a laminate for the new prodigal
            laminates.append(create_laminate(h_prodigal.sequence, n-1, n-2))
            laminates.append(create_laminate(h_prodigal.sequence, n-1, n-3))

        #Find best prodigals
        best_prodigals = prodigal_manager.get_best_prodigals(n=n-1, task="generation", context={})
        # 2. Construct Superpermutation (using the dynamic approach, starting from EMPTY)
        superpermutation, used_permutations = construct_superpermutation([], best_prodigals, winners, losers, layout_memory, meta_hierarchy, limbo_list, n-1, hypothetical_prodigals, laminates)
        #print(f"  Superpermutation length: {len(superpermutation)}")

        # 3. Update Data
        analysis_results = analyze_superpermutation(superpermutation, n-1)
        #print(f"  Valid: {analysis_results['validity']}")
        #print(f"  Overlap Distribution: {analysis_results['overlap_distribution']}")

        # Check for  length and distinctness
        if analysis_results['validity'] and len(superpermutation) == sum(math.factorial(i) for i in range(1,n)):
            return superpermutation

        # Find and add new prodigal results. Stricter criteria.
        new_prodigals = find_prodigal_results(superpermutation, n-1, overlap_threshold=prodigal_overlap_threshold,  min_length=prodigal_min_length)
        for prodigal_seq in new_prodigals:
            prodigal_manager.add_prodigal(prodigal_seq, n-1, "dynamic_generation")

        # Update "Winners" and "Losers" (using the new superpermutation, and k=6 and k=5)
        new_winners6, new_losers6 = calculate_winners_losers([superpermutation], n-1, k=n-2)
        new_winners5, new_losers5 = calculate_winners_losers([superpermutation], n-1, k=n-3)

        for kmer, weight in new_winners6.items():
            winners[kmer] = winners.get(kmer, 0) + weight
        for kmer, weight in new_losers6.items():
            losers[kmer] = losers.get(kmer, 0) + weight
            limbo_list.add(kmer) # Add to limbo list
        for kmer, weight in new_winners5.items():
            winners[kmer] = winners.get(kmer, 0) + weight
        for kmer, weight in new_losers5.items():
            losers[kmer] = losers.get(kmer, 0) + weight
            limbo_list.add(kmer)

        #Higher Order Winners/Losers
        new_seq_winners, new_seq_losers = calculate_sequence_winners_losers([superpermutation],n-1)
        for seq_hash, weight in new_seq_winners.items():
            if seq_hash in winners:
                winners[seq_hash] += weight
            else:
                winners[seq_hash] = weight
        for seq_hash, weight in new_seq_losers.items():
            if seq_hash in losers:
                losers[seq_hash] += weight
            else:
                losers[seq_hash] = weight

        # Update ePUT (add all *used* permutations)
        s_tuple = tuple(int(x) for x in superpermutation)
        for i in range(len(s_tuple) - (n-1) + 1):
            perm = s_tuple[i:i+(n-1)]
            if is_valid_permutation(perm, n-1):
                perm_hash = hash_permutation(perm)
                if perm_hash not in eput:
                    eput[perm_hash] = PermutationData(perm, in_sample=False, creation_method="dynamic_generation")
                eput[perm_hash].used_count += 1
                eput[perm_hash].used_in_final = True
                # Update neighbors in ePUT (using consistent k values)
                if i > 0:
                    prev_perm = s_tuple[i-1:i-1+(n-1)]
                    if is_valid_permutation(prev_perm, n-1):
                        eput[perm_hash].neighbors.add(hash_permutation(prev_perm))
                if i < len(s_tuple) - (n-1):
                    next_perm = s_tuple[i+1:i+1+(n-1)]
                    if is_valid_permutation(next_perm, n-1):
                        eput[perm_hash].neighbors.add(hash_permutation(next_perm))

        # Update Layout Memory
        layout_memory.add_sequence(superpermutation, n-1, n-2, f"run_{seed}")  # Add the new superpermutation
        layout_memory.add_sequence(superpermutation, n-1, n-3, f"run_{seed}")

        # Update "Meta-Hierarchy" (simplified for this example)
        meta_hierarchy.setdefault("run_lengths", []).append(len(superpermutation))
        meta_hierarchy.setdefault("prodigal_counts", []).append(len(prodigal_results))
        total_hypotheticals = len(hypothetical_prodigals)
        successful_hypotheticals = 0
        for h_id, h_prodigal in hypothetical_prodigals.items():
            if h_prodigal.sequence in superpermutation:
                successful_hypotheticals += 1
        success_rate = (successful_hypotheticals / total_hypotheticals) if total_hypotheticals > 0 else 0.0

        meta_hierarchy.setdefault("hypothetical_success_rate",[]).append(success_rate)
        # --- Dynamic Parameter Adjustments (Example) ---
        if len(meta_hierarchy["prodigal_counts"]) > 2 and meta_hierarchy["prodigal_counts"][-1] <= meta_hierarchy["prodigal_counts"][-2]:
            # Prodigal discovery rate is slowing down
            prodigal_overlap_threshold = max(0.90, prodigal_overlap_threshold - 0.01)  # Decrease threshold, but not below 0.90
            prodigal_min_length = max(7, prodigal_min_length - 2) # Reduce Min Length, not below 7.
            #print(f"  Adjusted Prodigal Criteria: Overlap Threshold = {prodigal_overlap_threshold}, Min Length = {prodigal_min_length}") # For Debugging

        #Stopping condition for n-1
        if len(superpermutation) == sum(math.factorial(i) for i in range(1,n)):
            return superpermutation

    return None  # Failed to find a  superpermutation within the iteration limit

def generate_distinct_n7_superpermutations(num_distinct, output_file, initial_seed=42):
    """Generates multiple distinct minimal superpermutations for n=7 and saves them to a file."""

    distinct_superpermutations = set()
    seed = initial_seed
    attempts = 0

    while len(distinct_superpermutations) < num_distinct and attempts < 1000:  # Added attempt limit
        attempts += 1
        superpermutation = generate_n_minus_1_superpermutation(8, seed)  # Generate for n=7 (8-1)

        if superpermutation:  # Check if generation was successful
            if len(superpermutation) == 5906:
                normalized_sp = normalize_sequence(superpermutation)
                checksum = compute_checksum(normalized_sp)
                if checksum not in distinct_superpermutations:
                    distinct_superpermutations.add(checksum)
                    with open(output_file, "a") as f:  # Append to file
                        f.write(normalized_sp + "\n")
                    print(f"Found distinct superpermutation (seed {seed}): {normalized_sp[:50]}... (length: {len(normalized_sp)})")
                #else: # Keep for debugging, but not needed for final runs.
                    #print(f"Duplicate superpermutation found (seed {seed}).")
        #else: # Keep for debugging, not needed for final runs.
            #print(f"Superpermutation generation failed (seed {seed}).")

        seed += 1  # Increment seed

    print(f"Generated {len(distinct_superpermutations)} distinct n=7 superpermutations.")

```