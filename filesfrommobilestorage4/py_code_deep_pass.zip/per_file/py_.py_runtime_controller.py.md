# File: py/.py/runtime_controller.py

**Extension:** .py

**Lines:** 72 | **Words:** 222

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 1

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: core.cmplx_logger

- Classes (1): AGRMRuntimeController

- Functions (7): __init__, set_max_cycles, inject_agent_manager, run_cycle, terminate, get_state, is_terminated


---


## Full Source


```text

from core.cmplx_logger import log

class AGRMRuntimeController:
    def __init__(self, nodes, agent_manager=None):
        self.nodes = nodes
        self.agent_manager = agent_manager
        self.state = {
            "cycle": 0,
            "terminated": False,
            "nodes": nodes,
            "history": [],
            "logs": [],
            "metrics": {},
            "flags": {},
            "audit": {}
        }
        self.max_cycles = None

    def set_max_cycles(self, n):
        if isinstance(n, int) and n > 0:
            self.max_cycles = n
        else:
            raise ValueError("max_cycles must be a positive integer")

    def inject_agent_manager(self, manager):
        if hasattr(manager, "step_all"):
            self.agent_manager = manager
        else:
            raise TypeError("Injected manager must implement 'step_all(state)'")

    def run_cycle(self):
        if self.state["terminated"]:
            log("Cycle attempted after termination", agent="Runtime", phase="Error")
            return True

        log(f"Cycle {self.state['cycle']} start", agent="Runtime", phase="Cycle")

        if not self.agent_manager:
            log("No agent manager bound to runtime", agent="Runtime", phase="Error")
            return True

        try:
            self.agent_manager.step_all(self.state)
        except Exception as e:
            log(f"Agent manager error: {e}", agent="Runtime", phase="Crash")
            self.terminate()
            return True

        self.state["cycle"] += 1

        if self.state.get("flags", {}).get("early_stop"):
            log("Early stop flag detected", agent="Runtime", phase="Cycle")
            self.terminate()
            return True

        if self.max_cycles and self.state["cycle"] >= self.max_cycles:
            log("Reached max cycles", agent="Runtime", phase="Control")
            self.terminate()
            return True

        return False

    def terminate(self):
        self.state["terminated"] = True
        log("Runtime terminated", agent="Runtime", phase="Terminate")

    def get_state(self):
        return self.state

    def is_terminated(self):
        return self.state["terminated"]


```