# File: py/.py/teacher_fallback_enabled.py

**Extension:** .py

**Lines:** 58 | **Words:** 227

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 4

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: yaml

- From-imports: agents.testlab, cli.cmplx_run, core.cmplx_logger, core.result_analyzer

- Classes (1): TeacherAgent

- Functions (3): __init__, step, run_fallback_plan


---


## Full Source


```text

from core.cmplx_logger import log
from agents.testlab import TestLabAgent
from core.result_analyzer import ResultAnalyzerAgent

class TeacherAgent:
    def __init__(self, runtime_settings):
        self.max_recovery_depth = runtime_settings["limits"]["max_recovery_depth"]

    def step(self, state):
        state.setdefault("_recovery_depth", 0)

        audit = state.get("audit", {})
        dataset = state.get("dataset", "")
        last_plan = state.get("plan_used", {})

        if audit.get("final_status") != "complete":
            if state["_recovery_depth"] >= self.max_recovery_depth:
                log("Maximum recovery attempts reached. Initiating fallback recovery strategy.", agent="Teacher", phase="Failover")
                self.run_fallback_plan(state)
                return

            log("Poor performance detected, invoking TestLabAgent...", agent="Teacher", phase="Recovery")
            state["_recovery_depth"] += 1

            current_depth = state["_recovery_depth"]
            testlab = TestLabAgent(planner=None, dataset_path=dataset, current_depth=current_depth)
            fix_found, plan = testlab.run_variant_tests(last_plan)

            if fix_found:
                log("New improved plan found. Overwriting plan file...", agent="Teacher", phase="Learned")
                path = "presets/conservative_entropy.yaml"
                import yaml
                with open(path, "w") as f:
                    yaml.safe_dump(plan, f)
                log(f"Updated strategy saved to {path}", agent="Teacher", phase="Persist")
                state["_recovery_depth"] = 0
            else:
                log("No better plan found. Attempting fallback plan.", agent="Teacher", phase="Failover")
                self.run_fallback_plan(state)

    def run_fallback_plan(self, state):
        from cli.cmplx_run import run_cmplx_cli

        fallback_plan = {
            "builder": {"max_merge_stall": 10},
            "modulator": {"entropy_collapse_threshold": 0.25},
            "controller": {"max_cycles": 50}
        }

        fallback_path = "plans/tmp/fallback_plan.yaml"
        import yaml, os
        os.makedirs(os.path.dirname(fallback_path), exist_ok=True)
        with open(fallback_path, "w") as f:
            yaml.safe_dump(fallback_plan, f)

        run_cmplx_cli(state["dataset"], plan_mode=fallback_path, save_audit=True, recovery_depth=state["_recovery_depth"] + 1)
        log("Fallback recovery executed.", agent="Teacher", phase="FallbackComplete")


```