# File: py/.py/benchmark_suite (1).py

**Extension:** .py

**Lines:** 35 | **Words:** 123

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 6

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 5

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: time

- From-imports: mdhg_hash

- Classes (0): (none)

- Functions (1): run_benchmark


---


## Full Source


```text

# benchmark_suite.py
# Benchmark runner for MDHGHashTable vs. native dict

import time, random
from mdhg_hash import MDHGHashTable

def run_benchmark(n_ops=10000):
    table = MDHGHashTable(capacity=n_ops * 2)
    native = {}

    keys = [random.randint(0, n_ops * 10) for _ in range(n_ops)]
    vals = [f"v{i}" for i in range(n_ops)]

    print("Benchmarking MDHGHashTable...")
    t0 = time.time()
    for k, v in zip(keys, vals):
        table.put(k, v)
    for k in keys:
        table.get(k)
    t1 = time.time()

    print("Benchmarking native dict...")
    t2 = time.time()
    for k, v in zip(keys, vals):
        native[k] = v
    for k in keys:
        native.get(k)
    t3 = time.time()

    print(f"MDHG total time: {t1 - t0:.4f}s")
    print(f"Dict total time: {t3 - t2:.4f}s")

if __name__ == "__main__":
    run_benchmark(10000)


```