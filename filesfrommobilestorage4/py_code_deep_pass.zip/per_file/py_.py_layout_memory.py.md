# File: py/.py/layout_memory.py

**Extension:** .py

**Lines:** 66 | **Words:** 367

## Keyword Hits

- SFBB: 0

- superperm: 3

- superpermutation: 3

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: logging, pickle

- From-imports: (none)

- Classes (1): LayoutMemory

- Functions (5): __init__, add_sequence, get_layout_score, save_to_file, load_from_file


---


## Full Source


```text

layout_memory.py

# layout_memory.py
import pickle
import logging

class LayoutMemory:
    """Manages relationships and distances between k-mers in sequences."""

    def __init__(self):
        """Initializes the LayoutMemory.  The `memory` dictionary stores the k-mer transition data."""
        self.memory = {}  # {(kmer1, kmer2): {"count": int, "sources": set, "distances": list}}

    def add_sequence(self, superpermutation: str, n: int, k: int, source: str):
        """Adds k-mer relationships from a given sequence to the memory.

        Args:
            superpermutation: The sequence string.
            n: The value of n (used for permutation validation).
            k: The k-mer length.
            source: A string identifying the source of the sequence (e.g., "main_loop", "prodigal").
        """
        s_tuple = tuple(int(x) for x in superpermutation)  # Convert sequence to tuple of integers
        for i in range(k, len(s_tuple) - n + 1):
            perm = s_tuple[i:i + n]  # Extract a permutation of length n
            if is_valid_permutation(perm, n): # Make sure is_valid_permutation is defined
                kmer1 = tuple(s_tuple[i - k:i])  # Extract the first k-mer
                kmer2 = tuple(s_tuple[i - k + 1:i + 1])  # Extract the second k-mer
                key = (kmer1, kmer2)  # The key is the tuple of the two k-mers
                if key not in self.memory:
                    self.memory[key] = {"count": 0, "sources": set(), "distances": []}  # Initialize if not seen before
                data = self.memory[key]
                data["count"] += 1  # Increment the count of this transition
                data["sources"].add(source)  # Add the source of this observation
                data["distances"].append(1)  # Default distance, can be adjusted

    def get_layout_score(self, kmer1: tuple, kmer2: tuple) -> float:
        """Calculates a layout score for a given pair of k-mers.

        The score is based on how frequently this transition has been observed.

        Args:
            kmer1: The first k-mer.
            kmer2: The second k-mer.

        Returns:
            The layout score (a float).
        """
        key = (kmer1, kmer2)
        if key not in self.memory:
            return 0.0  # Return 0 if this transition hasn't been observed
        data = self.memory[key]
        score = data["count"]
        return score

    def save_to_file(self, filename: str):
        """Saves the LayoutMemory to a file using pickle."""
        with open(filename, 'wb') as f:
            pickle.dump(self.memory, f)
        logging.debug(f"LayoutMemory saved to {filename}.")

    def load_from_file(self, filename: str):
        """Loads the LayoutMemory from a file."""
        with open(filename, 'rb') as f:
            self.memory = pickle.load(f)
        logging.debug(f"LayoutMemory loaded from {filename}.")

```