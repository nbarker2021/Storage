# File: py/.py/graph_utils.py

**Extension:** .py

**Lines:** 43 | **Words:** 162

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 4

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: logging, networkx

- From-imports: utils

- Classes (0): (none)

- Functions (2): build_de_bruijn_graph, find_eulerian_path


---


## Full Source


```text

graph_utils.py

# graph_utils.py
import networkx as nx
import logging
from utils import calculate_overlap

def build_de_bruijn_graph(kmers):
    """
    Builds a De Bruijn graph from a list of k-mers.

    Args:
        kmers (list of str): The list of k-mers.

    Returns:
        networkx.DiGraph: The constructed De Bruijn graph.
    """
    graph = nx.DiGraph()
    for kmer in kmers:
        prefix = kmer[:-1]
        suffix = kmer[1:]
        graph.add_edge(prefix, suffix)
    logging.debug(f"De Bruijn graph constructed with {graph.number_of_nodes()} nodes and {graph.number_of_edges()} edges.")
    return graph

def find_eulerian_path(graph: nx.DiGraph):
    """
    Finds an Eulerian path in the given graph.

    Args:
        graph (networkx.DiGraph): The De Bruijn graph.

    Returns:
        list of str: The nodes in the Eulerian path, or an empty list if no path is found.
    """
    try:
        path = list(nx.eulerian_path(graph))
        eulerian_path = [u for u, v in path] + [path[-1][1]]
        logging.debug(f"Eulerian path found with length {len(eulerian_path)}.")
        return eulerian_path
    except nx.NetworkXError as e:
        logging.error(f"No Eulerian path found: {e}")
        return []

```