# File: py/.py/superpermutation_generator.py

**Extension:** .py

**Lines:** 404 | **Words:** 1858

## Keyword Hits

- SFBB: 0

- superperm: 71

- superpermutation: 64

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 19

- golden: 1

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

superpermutation_generator

# superpermutation_generator.py
import random
import logging
import json
import multiprocessing
import time
from utils import setup_logging, normalize_sequence, compute_checksum, generate_permutations, is_valid_permutation, calculate_overlap, hash_permutation, unhash_permutation
from layout_memory import LayoutMemory
from analysis_scripts_final import is_prodigal, generate_hypothetical_prodigals, calculate_winners_losers, identify_anti_prodigals
from laminate_utils import create_laminate, is_compatible, create_anti_laminate
from sequence_generation import generate_n_minus_1_superpermutation

# Constants
DATA_FILENAME = "superpermutation_data.json"
N = 7  # Target n value.  Change as needed.
GRID_DIMENSIONS = (2,) * N  #  Dimensions of the Bouncing Batch grid (2^N cells)
NUM_VARIATIONS = 5 # Number of DTT variations.  Adjust as needed.
INITIAL_SEED = 42

def generate_hypothetical_superpermutation(n, strategy, prodigal_results, winners, losers, layout_memory, best_known_length, seed):
    """Generates a *complete* hypothetical superpermutation.

    Args:
        n: The value of n.
        strategy: The generation strategy ("n-1_seeding", "prodigal_combination", "random_constrained").
        prodigal_results: Dictionary of best prodigal results.
        winners: Dictionary of winner k-mers/sequences and their weights.
        losers: Dictionary of loser k-mers/sequences and their weights.
        layout_memory: The LayoutMemory instance.
        best_known_length: The current best known superpermutation length for n.
        seed: random seed

    Returns:
        A string representing the hypothetical superpermutation, or None if generation fails.
    """
    random.seed(seed) #Ensure all strategies are using the *same* seed.

    if strategy == "n-1_seeding":
        # Use the n-1 superpermutation as a base and try to complete it.
        n_minus_1_sp = generate_n_minus_1_superpermutation(n - 1, seed)
        if n_minus_1_sp:
            #  Try to extend this to a full n superpermutation.  Use generate_candidates and calculate_score
            #  as a simplified completion process.
            all_permutations = generate_permutations(n)
            missing_permutations = set(hash_permutation(p) for p in all_permutations if not "".join(map(str,p)) in n_minus_1_sp)
            eput = {hash_permutation(p):True for p in all_permutations if "".join(map(str,p)) in n_minus_1_sp} # Initialize a basic eput.

            return complete_from_partial(n_minus_1_sp, n, missing_permutations, prodigal_results, winners, losers, layout_memory, set(), eput, best_known_length)
        else:
            return None


    elif strategy == "prodigal_combination":
      #Combine best prodigals using Mega-Hypothetical logic, then complete
        num_prodigals_to_combine = random.randint(2, min(4, len(prodigal_results))) # Combine 2-4 Prodigals, limit by how many exist.
        if num_prodigals_to_combine == 0:
            return None #If there aren't any prodigals, we can't use this.

        #Select prodigals, but with a bias towards those with higher overlap and greater length
        prodigal_weights = [prodigal_results[p]['overlap_rate'] * prodigal_results[p]['length'] for p in prodigal_results]
        selected_prodigal_ids = random.choices(list(prodigal_results.keys()), weights=prodigal_weights, k=num_prodigals_to_combine)
        selected_prodigals = [prodigal_results[pid]['sequence'] for pid in selected_prodigal_ids]

        # Sort by length, in any order.
        selected_prodigals.sort(key=lambda p: len(p))

        #Use golden ratio for lengths.
        phi = (1 + math.sqrt(5)) / 2
        total_target_length = best_known_length #Target the BEST KNOWN LENGTH
        target_lengths = []

        remaining_length = total_target_length
        for i in range(len(selected_prodigals)-1):
            segment_length = int(remaining_length / (phi**(i+1)))
            target_lengths.append(segment_length)
            remaining_length -= segment_length
        target_lengths.append(remaining_length) # Add the final length.

        combined_sequence = ""
        
        #Randomize starting location.
        start_location = random.randint(0,len(selected_prodigals)-1)
        prodigal_order = []
        for i in range(len(selected_prodigals)):
            prodigal_order.append(selected_prodigals[(start_location + i) % len(selected_prodigals)])

        for i in range(len(prodigal_order)):
            prodigal = prodigal_order[i]
            target_length = target_lengths[i]

            # Get a random section of the prodigal, unless it is too short.
            start_index = random.randint(0, max(0, len(prodigal) - target_length))  # Ensure valid start
            current_sequence = prodigal[start_index : start_index + target_length]

            # Connect to previous
            if combined_sequence != "":
                overlap = calculate_overlap(combined_sequence, current_sequence)
                if overlap == 0: #Need to use the combiner
                    prefix = combined_sequence[-(n-1):]
                    suffix = current_sequence[:n-1]
                    candidates = generate_completion_candidates("".join(prefix), "".join(suffix), prodigal_results, winners, losers, n, {}, set(), 1)
                    if candidates:
                        # Choose the best candidate based on winners/losers (simplified scoring)
                        best_candidate = None
                        best_score = -float('inf')
                        for cand_hash in candidates:
                            cand_perm = unhash_permutation(cand_hash, n)
                            cand_str = "".join(str(x) for x in cand_perm)
                            score = 0
                            for k in [n - 1, n - 2]: # Using values for n=8
                                for j in range(len(cand_str) - k + 1):
                                    kmer = cand_str[j:j+k]
                                    score += winners.get(kmer, 0)
                                    score -= losers.get(kmer, 0)

                            if score > best_score:
                                best_score = score
                                best_candidate = cand_str

                        overlap = calculate_overlap(combined_sequence, best_candidate)
                        combined_sequence += best_candidate[overlap:]
                    else:
                        return None #Skip if we cannot connect.

                else: #Overlap exists
                    combined_sequence += current_sequence[overlap:]
            else:
                combined_sequence = current_sequence
        
        # Now, try to complete the combined_sequence to a full superpermutation
        all_permutations = generate_permutations(n)
        missing_permutations = set(hash_permutation(p) for p in all_permutations if not "".join(map(str,p)) in combined_sequence)
        eput = {hash_permutation(p):True for p in all_permutations if "".join(map(str,p)) in combined_sequence}
        
        return complete_from_partial(combined_sequence, n, missing_permutations, prodigal_results, winners, losers, layout_memory, set(), eput, best_known_length)

    elif strategy == "random_constrained":
        # Generate a random permutation sequence, but ensure it's the correct length
        superperm_list = []
        all_permutations = generate_permutations(n)
        random.shuffle(all_permutations)
        superperm_list.append(list(all_permutations[0]))
        overlap = n-1
        
        for perm in all_permutations[1:]:
            perm_str = "".join(map(str, perm))
            overlap = calculate_overlap("".join(map(str,superperm_list[-1])), perm_str)
            superperm_list.append(list(perm_str[overlap:]))
        
        
        return "".join(map(str, superperm_list))

    else:
        logging.error(f"Unknown superpermutation generation strategy: {strategy}")
        return None

def complete_from_partial(partial_superpermutation, n, missing_permutations, prodigal_results, winners, losers, layout_memory, limbo_list, eput, best_known_length):
    """
    Attempts to complete a partial superpermutation to the target length.
    Uses a simplified, greedy approach.  Returns None if it cannot complete
    to the target length.
    """
    working_superpermutation = list(partial_superpermutation)
    attempts = 0
    max_attempts = 1000  # Limit attempts to avoid infinite loops

    while missing_permutations and len("".join(working_superpermutation)) < best_known_length and attempts < max_attempts:
        candidates = generate_completion_candidates("".join(working_superpermutation), missing_permutations, prodigal_results, winners, losers, n, eput, limbo_list)
        best_candidate = None
        best_score = -float('inf')

        for candidate_hash in candidates:
            score = calculate_score("".join(working_superpermutation), candidate_hash, prodigal_results, winners, losers, layout_memory, n, missing_permutations, eput)
            if score > best_score:
                best_score = score
                best_candidate = unhash_permutation(candidate_hash, n)

        if best_candidate:
            overlap = calculate_overlap("".join(working_superpermutation), "".join(map(str, best_candidate)))
            working_superpermutation.extend(list(str(x) for x in best_candidate[overlap:]))
            missing_permutations.discard(hash_permutation(best_candidate))
            #  Basic eput update
            eput[hash_permutation(best_candidate)] = True
        else:
            # If no candidate found. We are returning none.
            return None
        attempts += 1

    if len("".join(working_superpermutation)) > best_known_length:
        return None #Too long.
    if missing_permutations:
        return None #Couldn't fill it.

    return "".join(working_superpermutation)

def assign_permutation_to_cell(permutation, n, grid_dimensions):
    """Assigns a permutation to a cell in the Bouncing Batch grid."""
    cell = []
    for i in range(n):
        cell.append(permutation[i] % 2)  # Even or odd
    return tuple(cell)


def calculate_cell_winners_losers(hypothetical_superpermutation, cell_permutations, n, k=None):
    """Calculates winners and losers based on a superpermutation and a cell's permutations."""
    if k is None:
        k = n - 1

    winners = {}
    losers = {}

    # Convert hypothetical superpermutation to a list of integers
    s_list = [int(x) for x in hypothetical_superpermutation]

    for i in range(len(s_list) - n + 1):
        perm = tuple(s_list[i:i+n])
        if is_valid_permutation(perm, n):
            # Check if this permutation belongs to the current cell
            if hash_permutation(perm) in cell_permutations:  # Use efficient hash lookup
                if i >= k:
                    kmer = tuple(s_list[i-k:i])
                    kmer_str = "".join(map(str,kmer))
                    # Simplified: Just count occurrences
                    winners[kmer_str] = winners.get(kmer_str, 0) + 1
                    # Could add more sophisticated weighting here,

    return winners, losers

def bouncing_batch_test(hypothetical_superpermutation, n, grid_dimensions, prodigal_results, layout_memory, anti_laminates):
    """Performs the Bouncing Batch test for a single hypothetical superpermutation."""

    all_permutations = generate_permutations(n)
    cell_permutations = {}  # {cell_coords: set(permutation_hashes)}
    for perm in all_permutations:
        cell = assign_permutation_to_cell(perm, n, grid_dimensions)
        if cell not in cell_permutations:
            cell_permutations[cell] = set()
        cell_permutations[cell].add(hash_permutation(perm))

    # Initialize global winners, losers (could be loaded from previous runs)
    winners = {}
    losers = {}

    # Iterate through cells
    for cell_coords in cell_permutations:
        #logging.info(f"Processing cell: {cell_coords}")
        cell_winners, cell_losers = calculate_cell_winners_losers(hypothetical_superpermutation, cell_permutations[cell_coords], n)

        # Update global winners and losers (simple merging - could be more sophisticated)
        for kmer, count in cell_winners.items():
            winners[kmer] = winners.get(kmer, 0) + count
        for kmer, count in cell_losers.items():
            losers[kmer] = losers.get(kmer, 0) - count # Losers are NEGATIVE

        # Update layout memory (add the hypothetical superpermutation)
        layout_memory.add_sequence(hypothetical_superpermutation, n, n - 1, "bouncing_batch")
        layout_memory.add_sequence(hypothetical_superpermutation, n, n - 2, "bouncing_batch")

    # Basic validity check (using existing function)
    is_valid = verify_permutation_coverage(hypothetical_superpermutation, n)
    length = len(hypothetical_superpermutation)

    return is_valid, length, winners, losers, layout_memory

def worker_task(args):
    """
    Multiprocessing worker task.  This function will
    handle the Bouncing Batch testing for a *single* hypothetical
    superpermutation.

    Args:
        args: A tuple containing the arguments:
            - hypothetical_superpermutation (str): The superpermutation to test.
            - n (int): The value of n.
            - grid_dimensions (tuple): Dimensions of the Bouncing Batch grid.
            - prodigal_results (dict): The dictionary of best prodigals.
            - layout_memory_filename (str): File to load/save LayoutMemory
            - anti_laminates (list): list of antilaminates

    Returns:
        A tuple: (is_valid, length, winners, losers, layout_memory_filename) - the results of the test.
        The layout_memory is returned as a *filename* to avoid issues with object sharing.
    """
    hypothetical_superpermutation, n, grid_dimensions, prodigal_results, layout_memory_filename, anti_laminates = args

    # Load the layout memory from the specified file.  Each worker has its own copy.
    layout_memory = LayoutMemory()
    try:
        layout_memory.load_from_file(layout_memory_filename)
    except FileNotFoundError:
        logging.warning(f"LayoutMemory file not found: {layout_memory_filename}.  Using a new LayoutMemory.")


    # Perform the bouncing batch test, updating winners, losers, and layout memory
    is_valid, length, winners, losers, layout_memory = bouncing_batch_test(
        hypothetical_superpermutation, n, grid_dimensions, prodigal_results, layout_memory, anti_laminates
    )

    # Save the updated layout memory to the file.
    layout_memory.save_to_file(layout_memory_filename)

    return is_valid, length, winners, losers, layout_memory_filename

def main():
    setup_logging()
    n = 7  # Set the target n value
    seed = INITIAL_SEED
    random.seed(seed)
    grid_dimensions = (2,) * n  # Example: n-dimensional grid for n=7
    num_variations = NUM_VARIATIONS # Number of variations for DTT.

    # --- Load Initial Data ---
    layout_memory = LayoutMemory()
    layout_memory_filename = "layout_memory.pkl" # Use a consistent filename
    try:
        layout_memory.load_from_file(layout_memory_filename)
        logging.info(f"Loaded LayoutMemory from {layout_memory_filename}")
    except FileNotFoundError:
        logging.info("No existing LayoutMemory found. Starting with a new one.")

    # Load existing data (best known superpermutation, prodigal results, etc. - adjust paths as needed)
    # best_known_superpermutation = load_best_superpermutation("best_superpermutation_n7.txt") #TODO: Implement Loading.
    best_known_length = 5906 #float('inf')  # Initialize with a large value, or known value.
    try:
        with open("best_superpermutation_n7.txt", 'r') as f:
            best_known_superpermutation = f.read()
            best_known_length = len(best_known_superpermutation)
            logging.info(f"Loaded best known superpermutation (length {best_known_length}).")
    except FileNotFoundError:
        logging.info("No existing best superpermutation found, starting fresh.")
        best_known_superpermutation = "" # Start Empty.


    prodigal_results = {} #load_prodigal_results("prodigal_results_n7.txt") #TODO: Implement loading/saving.
    winners = {} #load_winners_losers("winners_losers_data_n7.txt") # Combined winners/losers #TODO
    losers = {}
    anti_laminates = [] #TODO Implement loading.

    # --- Main DTT Loop ---
    for iteration in range(100):  # Outer loop for multiple DTT iterations
        logging.info(f"Starting DTT iteration: {iteration}")
        iteration_start_time = time.time()

        # 1. Generate Hypothetical Superpermutations (Multiple Variations)
        hypothetical_superpermutations = []
        for i in range(num_variations):
            # Example: Use different strategies and random seeds
            if i % 3 == 0:
                strategy = "n-1_seeding"
            elif i % 3 == 1:
                strategy = "prodigal_combination"
            else:
                strategy = "random_constrained"
            
            seed = INITIAL_SEED + iteration * num_variations + i #Unique seeds

            seq = generate_hypothetical_superpermutation(n, strategy, prodigal_results, winners, losers, layout_memory, best_known_length, seed)
            if seq: # Only add if generation was successful
                hypothetical_superpermutations.append(seq)

        # 2. Bouncing Batch Testing (Parallel - using multiprocessing)
        if hypothetical_superpermutations: # Only if we have any.
            with multiprocessing.Pool() as pool:
                args_list = [(h_superperm, n, grid_dimensions, prodigal_results, layout_memory_filename, anti_laminates) for h_superperm in hypothetical_superpermutations]
                results = pool.map(worker_task, args_list)
        else:
            results = [] # Empty results.

        # 3. Evaluation and Selection
        best_result = None
        for is_valid, length, new_winners, new_losers, new_layout_memory_filename in results:
            if is_valid and length < best_known_length:
                best_known_length = length
                best_result = (is_valid, length, new_winners, new_losers, new_layout_memory_filename)
                logging.info(f"New best superpermutation found! Length: {best_known_length}")
                with open("best_superpermutation_n7.txt", "w") as f:
                    f.write(hypothetical_superpermutations[results.index( (is_valid, length, new_winners, new_losers, new_layout_memory_filename) )]) #Save it.

            # --- Update Global Data (Winners/Losers) ---
            for kmer, count in new_winners.items():
                winners[kmer] = winners.get(kmer, 0) + count
            for kmer, count in new_losers.items():
                losers[kmer] = losers.get(kmer, 0) + count  # Losers are *negative*

        if best_result:
            
            pass #Currently, we are replacing, and saving best.  No need to reload best.
            # best_known_superpermutation = ... # Load from file, using best_result info.
            # ... (Save the new best superpermutation) ...
        else:
            logging.info("No shorter superpermutation found in this iteration.")

        # 4. Refinement (Based on results - could involve adjusting strategy weights, parameters, etc.)
        # ... (Implementation for refining strategies - based on "winners", "losers", and "layout_memory") ...
        # Example:  Adjust weights in calculate_score, modify probabilities in generate_hypothetical_superpermutation,
        #           update criteria for "best prodigals", change anti-laminate generation rules.

        iteration_end_time = time.time()
        logging.info(f"DTT iteration {iteration} completed in {iteration_end_time - iteration_start_time:.2f} seconds.")

if __name__ == "__main__":
    main()

```