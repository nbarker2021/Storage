# File: py/.py/janitor.py

**Extension:** .py

**Lines:** 23 | **Words:** 85

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 1

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: os, shutil

- From-imports: core.cmplx_logger

- Classes (1): JanitorAgent

- Functions (3): __init__, step, clean_tmp_files


---


## Full Source


```text

# janitor.py
from core.cmplx_logger import log
import os
import shutil

class JanitorAgent:
    def __init__(self, config):
        self.clean_tmp_dir = config['janitor'].get('clean_tmp_dir', True)
        self.tmp_dir = config['janitor'].get('tmp_dir', 'presets/plans/tmp')

    def step(self, state):
        if self.clean_tmp_dir:
            self.clean_tmp_files()

    def clean_tmp_files(self):
        if os.path.exists(self.tmp_dir):
            try:
                shutil.rmtree(self.tmp_dir)
                os.makedirs(self.tmp_dir)
                log("Temporary files cleaned", agent="Janitor", phase="Cleanup")
            except Exception as e:
                log(f"Janitor failed to clean tmp directory: {e}", agent="Janitor", phase="Error")


```