# File: py/.py/testlab.py

**Extension:** .py

**Lines:** 45 | **Words:** 163

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 4

- E8: 0

- LSDT: 0

- TSP: 1

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: uuid

- From-imports: cli.cmplx_run, core.cmplx_logger

- Classes (1): TestLabAgent

- Functions (4): __init__, run_variant_tests, run_single_test, _create_temp_plan


---


## Full Source


```text

# testlab.py
import uuid
from core.cmplx_logger import log
from cli.cmplx_run import run_cmplx_cli

class TestLabAgent:
    def __init__(self, config):
        self.dataset_path = config['testlab'].get('dataset_path', 'data/tsp_10k.csv')
        self.max_recursion_depth = config['testlab'].get('max_recovery_depth', 2)

    def run_variant_tests(self, plan, current_depth=0):
        if current_depth > self.max_recursion_depth:
            log("Maximum recursion depth exceeded", agent="CLI", phase="RecursionGuard")
            return False, None

        temp_plan = self._create_temp_plan(plan)
        score = self.run_single_test(temp_plan, current_depth=current_depth)

        if score:
            log("Improved plan found by test lab", agent="TestLab", phase="Pass")
            return True, temp_plan

        log("No improvement from test variant", agent="TestLab", phase="Fail")
        return False, None

    def run_single_test(self, temp_plan, current_depth=0):
        try:
            run_cmplx_cli(
                dataset_path=self.dataset_path,
                plan_mode=temp_plan,
                save_audit=True,
                recovery_depth=current_depth + 1
            )
            return True
        except Exception as e:
            log(f"Test run failed with exception: {e}", agent="TestLab", phase="Crash")
            return False

    def _create_temp_plan(self, plan):
        test_id = str(uuid.uuid4())[:8]
        temp_plan_path = f"presets/plans/tmp/testlab_plan_{test_id}.yaml"
        with open(temp_plan_path, "w") as f:
            f.write(plan)
        return temp_plan_path


```