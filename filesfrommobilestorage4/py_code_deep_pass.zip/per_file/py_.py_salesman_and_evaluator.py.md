# File: py/.py/salesman_and_evaluator.py

**Extension:** .py

**Lines:** 56 | **Words:** 189

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (2): Salesman, AGRMEvaluator

- Functions (9): __init__, scan_path, _compute_total_distance, get_total_distance, collect_feedback, __init__, ingest_feedback, apply_modulation_if_needed, reset_required


---


## Full Source


```text


import math
from typing import List, Dict, Tuple

class Salesman:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.last_distance = 0.0
        self.last_feedback = []

    def scan_path(self, path: List[int]):
        print("[Salesman] Scanning tour...")
        self.last_distance = self._compute_total_distance(path)

    def _compute_total_distance(self, path: List[int]) -> float:
        total = 0.0
        for i in range(len(path)):
            a = self.nodes[path[i]]
            b = self.nodes[path[(i + 1) % len(path)]]
            total += math.dist(a, b)
        return round(total, 3)

    def get_total_distance(self) -> float:
        return self.last_distance

    def collect_feedback(self) -> List[Dict]:
        print("[Salesman] Evaluating route strain...")
        feedback = []
        if self.last_distance > 100000:  # placeholder threshold
            feedback.append({'type': 'reroute_proposal', 'strain': 0.85})
        self.last_feedback = feedback
        return feedback


class AGRMEvaluator:
    def __init__(self):
        self.feedback_cache: List[Dict] = []
        self.override_flag = False
        self.history = []

    def ingest_feedback(self, feedback_batch: List[Dict]):
        self.feedback_cache.extend(feedback_batch)

    def apply_modulation_if_needed(self):
        for signal in self.feedback_cache:
            if signal.get('type') == 'reroute_proposal' and signal.get('strain', 0) > 0.6:
                self.override_flag = True
                print("[Evaluator] Modulation triggered: override set.")
        self.feedback_cache.clear()

    def reset_required(self) -> bool:
        if self.override_flag:
            self.override_flag = False  # consume it
            return True
        return False


```