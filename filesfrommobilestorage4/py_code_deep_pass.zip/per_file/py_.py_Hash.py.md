# File: py/.py/Hash.py

**Extension:** .py

**Lines:** 1727 | **Words:** 5955

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 2

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 125

- golden: 14

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (0): 


---


## Full Source


```text

import math
import time
import random
from collections import deque, Counter, defaultdict
from typing import Any, Dict, List, Tuple, Set, Optional, Union

class MDHGHashTable:
    """
    Multi-Dimensional Hamiltonian Golden Ratio Hash Table.
    
    A hash table implementation that uses multi-dimensional organization,
    Hamiltonian paths for navigation, and golden ratio-based sizing to
    achieve optimal performance for structured access patterns.
    """
    
    def __init__(self, capacity: int = 1024, dimensions: int = 3, load_factor_threshold: float = 0.75):
        """
        Initialize the hash table.
        
        Args:
            capacity: Initial capacity of the hash table
            dimensions: Number of dimensions for the hash space
            load_factor_threshold: When to resize the table
        """
        self.PHI = (1 + math.sqrt(5)) / 2  # Golden ratio
        
        # Core configuration
        self.capacity = capacity
        self.dimensions = dimensions
        self.load_factor_threshold = load_factor_threshold
        self.size = 0
        
        # Multi-dimensional organization
        self.buildings = self._initialize_buildings()
        self.location_map = {}  # Maps keys to their current location
        
        # Navigation components
        self.hamiltonian_paths = {}  # Pre-computed paths
        self.path_cache = {}  # Cache of paths between points
        self.shortcuts = {}  # Direct connections between regions
        
        # Access pattern tracking
        self.access_history = deque(maxlen=100)
        self.access_frequency = Counter()
        self.co_access_matrix = defaultdict(Counter)
        self.path_usage = Counter()
        
        # Statistics
        self.stats = {
            'puts': 0,
            'gets': 0,
            'hits': 0,
            'misses': 0,
            'collisions': 0,
            'probes_total': 0,
            'max_probes': 0,
            'reorganizations': 0
        }
        
        # Optimization timing
        self.last_minor_optimization = time.time()
        self.last_major_optimization = time.time()
        self.operations_since_optimization = 0
        
        # Initialize the structure
        self._initialize_structure()
    
    def _initialize_buildings(self) -> Dict:
        """
        Initialize the building structure based on golden ratio proportions.
        
        Returns:
            Dictionary of buildings with their parameters
        """
        building_count = max(1, int(math.log(self.capacity, self.PHI)))
        buildings = {}
        
        # Total capacity divided among buildings
        capacity_per_building = self.capacity // building_count
        
        for b in range(building_count):
            building_id = f"B{b}"
            
            # Calculate regions using golden ratio
            velocity_region_size = int(capacity_per_building / (self.PHI ** 2))
            core_region_size = int(velocity_region_size * self.PHI)
            conflict_region_size = capacity_per_building - velocity_region_size - core_region_size
            
            # Initialize building storage
            buildings[building_id] = {
                'velocity_region': [None] * max(1, velocity_region_size),
                'dimensional_core': {},
                'conflict_structures': {},
                'dimension_sizes': self._calculate_dimension_sizes(core_region_size),
                'hot_keys': set(),
                'access_count': 0
            }
        
        return buildings
    
    def _calculate_dimension_sizes(self, total_size: int) -> List[int]:
        """
        Calculate sizes for each dimension using golden ratio proportions.
        
        Args:
            total_size: Total size to distribute across dimensions
            
        Returns:
            List of dimension sizes
        """
        # Base size is the nth root of total size
        base_size = max(2, int((total_size / self.dimensions) ** (1/self.dimensions)))
        
        # Size each dimension using golden ratio scaling
        sizes = []
        for i in range(self.dimensions):
            # Each dimension scaled by phi relative to previous
            size = max(2, int(base_size / (self.PHI ** (i/(self.dimensions-1 or 1)))))
            sizes.append(size)
        
        return sizes
    
    def _initialize_structure(self):
        """Initialize the hash table structure with navigation components."""
        # Pre-compute critical Hamiltonian paths
        for building_id, building in self.buildings.items():
            self._initialize_building_paths(building_id, building)
        
        # Initialize shortcuts between buildings
        self._initialize_building_shortcuts()
    
    def _initialize_building_paths(self, building_id: str, building: Dict):
        """
        Initialize Hamiltonian paths for a building.
        
        Args:
            building_id: ID of the building
            building: Building data structure
        """
        # Only initialize critical paths for efficiency
        dimension_sizes = building['dimension_sizes']
        
        # Generate corner points for path starting positions
        critical_points = []
        
        # Add corner points
        corners = self._generate_corner_points(dimension_sizes)
        critical_points.extend(corners)
        
        # Add center point
        center = tuple(d // 2 for d in dimension_sizes)
        critical_points.append(center)
        
        # Add points at golden ratio positions along each dimension
        for d in range(self.dimensions):
            golden_point = [dimension_sizes[i] // 2 for i in range(self.dimensions)]
            golden_point[d] = int(dimension_sizes[d] / self.PHI)
            critical_points.append(tuple(golden_point))
        
        # Generate paths for these points
        for point in critical_points:
            path_key = (building_id, point)
            self.hamiltonian_paths[path_key] = self._compute_hamiltonian_path(building_id, point)
    
    def _generate_corner_points(self, dimension_sizes: List[int]) -> List[Tuple]:
        """
        Generate corner points for a multi-dimensional space.
        
        Args:
            dimension_sizes: Size of each dimension
            
        Returns:
            List of corner point coordinates
        """
        corners = []
        
        # Generate all combinations of min/max values for each dimension
        for i in range(2 ** self.dimensions):
            corner = []
            for d in range(self.dimensions):
                # Use bit masking to determine if this dimension should be min or max
                if (i & (1 << d)):
                    corner.append(dimension_sizes[d] - 1)
                else:
                    corner.append(0)
            corners.append(tuple(corner))
        
        return corners
    
    def _initialize_building_shortcuts(self):
        """Initialize shortcuts between buildings."""
        building_ids = list(self.buildings.keys())
        
        for i, b1 in enumerate(building_ids):
            for j, b2 in enumerate(building_ids):
                if i != j:
                    # Create bidirectional shortcuts
                    self._create_building_shortcut(b1, b2)
    
    def _create_building_shortcut(self, building1: str, building2: str):
        """
        Create a shortcut between two buildings.
        
        Args:
            building1: First building ID
            building2: Second building ID
        """
        # Find optimal entry/exit points between buildings
        building1_data = self.buildings[building1]
        building2_data = self.buildings[building2]
        
        # Use center points as default connection points
        center1 = tuple(d // 2 for d in building1_data['dimension_sizes'])
        center2 = tuple(d // 2 for d in building2_data['dimension_sizes'])
        
        # Create shortcut with connection cost
        shortcut_key = (building1, building2)
        self.shortcuts[shortcut_key] = {
            'entry_point': center1,
            'exit_point': center2,
            'cost': 1.0 / self.PHI,  # Lower cost than regular traversal
            'usage_count': 0
        }
    
    def _compute_hamiltonian_path(self, building_id: str, start_coords: Tuple) -> List[Tuple]:
        """
        Compute a Hamiltonian path starting from given coordinates.
        
        Args:
            building_id: Building ID
            start_coords: Starting coordinates
            
        Returns:
            List of coordinates forming a Hamiltonian path
        """
        building = self.buildings[building_id]
        dimension_sizes = building['dimension_sizes']
        
        path = [start_coords]
        current = list(start_coords)
        visited = {start_coords}
        
        # Generate path of reasonable length for efficient traversal
        path_length = sum(dimension_sizes) // 2
        
        for step in range(1, path_length):
            # Choose dimension based on golden ratio for optimal distribution
            dim = int((step * self.PHI) % self.dimensions)
            
            # Calculate step size and direction using golden ratio
            frac = (step * self.PHI * self.PHI) % 1.0
            step_size = 1 if frac < 0.5 else -1
            
            # Try the calculated move
            original = current[dim]
            current[dim] = (current[dim] + step_size) % dimension_sizes[dim]
            current_tuple = tuple(current)
            
            # If already visited, try alternative moves
            if current_tuple in visited:
                # Try other dimensions
                found_new = False
                
                for alt_dim in range(self.dimensions):
                    if alt_dim == dim:
                        continue
                    
                    # Restore original position
                    current[dim] = original
                    
                    # Try move in alternative dimension
                    current[alt_dim] = (current[alt_dim] + step_size) % dimension_sizes[alt_dim]
                    alt_tuple = tuple(current)
                    
                    if alt_tuple not in visited:
                        found_new = True
                        break
                
                if not found_new:
                    # If still no valid move, try opposite direction
                    current[dim] = original
                    current[dim] = (current[dim] - step_size) % dimension_sizes[dim]
                    current_tuple = tuple(current)
                    
                    if current_tuple in visited:
                        # If all options exhausted, skip this step
                        continue
            
            # Add new position to path and visited set
            path.append(current_tuple)
            visited.add(current_tuple)
            
        return path
    
    def put(self, key: Any, value: Any) -> None:
        """
        Insert a key-value pair into the hash table.
        
        Args:
            key: The key to insert
            value: The value to associate with the key
        """
        self.stats['puts'] += 1
        self.operations_since_optimization += 1
        
        # Determine which building should contain this key
        building_id = self._hash_to_building(key)
        building = self.buildings[building_id]
        
        # Track building access
        building['access_count'] += 1
        
        # Strategy 1: Try velocity region first
        velocity_idx = self._hash_to_velocity_index(key, building_id)
        
        velocity_entry = building['velocity_region'][velocity_idx]
        if velocity_entry is None:
            building['velocity_region'][velocity_idx] = (key, value)
            self.location_map[key] = (building_id, 'velocity', velocity_idx)
            self.size += 1
            self._update_access_patterns(key)
            return
        elif velocity_entry[0] == key:
            # Update existing key
            building['velocity_region'][velocity_idx] = (key, value)
            self._update_access_patterns(key)
            return
        
        # Strategy 2: Try dimensional core
        coords = self._hash_to_coords(key, building_id)
        
        if coords not in building['dimensional_core']:
            building['dimensional_core'][coords] = (key, value)
            self.location_map[key] = (building_id, 'dimensional', coords)
            self.size += 1
            self._update_access_patterns(key)
            return
        elif building['dimensional_core'][coords][0] == key:
            # Update existing key
            building['dimensional_core'][coords] = (key, value)
            self._update_access_patterns(key)
            return
        
        # Collision detected
        self.stats['collisions'] += 1
        
        # Strategy 3: Follow Hamiltonian path to find empty slot
        new_coords, probes = self._follow_hamiltonian_path(building_id, coords)
        self.stats['probes_total'] += probes
        self.stats['max_probes'] = max(self.stats['max_probes'], probes)
        
        if new_coords:
            building['dimensional_core'][new_coords] = (key, value)
            self.location_map[key] = (building_id, 'dimensional', new_coords)
            self.size += 1
            self._update_access_patterns(key)
            return
        
        # Strategy 4: Create conflict structure
        conflict_key = self._hash_to_conflict_key(key, coords)
        
        if conflict_key not in building['conflict_structures']:
            building['conflict_structures'][conflict_key] = {}
        
        building['conflict_structures'][conflict_key][key] = value
        self.location_map[key] = (building_id, 'conflict', conflict_key)
        self.size += 1
        self._update_access_patterns(key)
        
        # Check if optimization is needed
        self._check_optimization_needed()
    
    def get(self, key: Any) -> Any:
        """
        Retrieve a value by key.
        
        Args:
            key: The key to look up
            
        Returns:
            The associated value or None if key not found
        """
        self.stats['gets'] += 1
        self.operations_since_optimization += 1
        
        # Check if we know the location
        if key in self.location_map:
            building_id, region_type, location = self.location_map[key]
            building = self.buildings[building_id]
            
            # Track building access
            building['access_count'] += 1
            
            # Retrieve based on region type
            if region_type == 'velocity':
                entry = building['velocity_region'][location]
                if entry and entry[0] == key:
                    self.stats['hits'] += 1
                    self._update_access_patterns(key)
                    return entry[1]
            elif region_type == 'dimensional':
                if location in building['dimensional_core']:
                    entry = building['dimensional_core'][location]
                    if entry[0] == key:
                        self.stats['hits'] += 1
                        self._update_access_patterns(key)
                        return entry[1]
            elif region_type == 'conflict':
                if location in building['conflict_structures'] and key in building['conflict_structures'][location]:
                    self.stats['hits'] += 1
                    self._update_access_patterns(key)
                    return building['conflict_structures'][location][key]
            
            # Location map is outdated, fall back to full search
        
        # We don't know location or it was invalid, do full search
        # Start with most likely building based on hash
        primary_building_id = self._hash_to_building(key)
        result = self._search_building(primary_building_id, key)
        
        if result is not None:
            return result
        
        # If not found in primary building, check others
        for building_id in self.buildings:
            if building_id != primary_building_id:
                result = self._search_building(building_id, key)
                if result is not None:
                    return result
        
        # Key not found
        self.stats['misses'] += 1
        return None
    
    def _search_building(self, building_id: str, key: Any) -> Any:
        """
        Search for a key within a specific building.
        
        Args:
            building_id: Building ID to search
            key: Key to look for
            
        Returns:
            Value if found, None otherwise
        """
        building = self.buildings[building_id]
        
        # Track building access
        building['access_count'] += 1
        
        # Check velocity region
        velocity_idx = self._hash_to_velocity_index(key, building_id)
        entry = building['velocity_region'][velocity_idx]
        if entry and entry[0] == key:
            self.stats['hits'] += 1
            self._update_access_patterns(key)
            self.location_map[key] = (building_id, 'velocity', velocity_idx)
            return entry[1]
        
        # Check dimensional core at calculated coordinates
        coords = self._hash_to_coords(key, building_id)
        if coords in building['dimensional_core']:
            entry = building['dimensional_core'][coords]
            if entry[0] == key:
                self.stats['hits'] += 1
                self._update_access_patterns(key)
                self.location_map[key] = (building_id, 'dimensional', coords)
                return entry[1]
        
        # Check conflict structures
        conflict_key = self._hash_to_conflict_key(key, coords)
        if conflict_key in building['conflict_structures'] and key in building['conflict_structures'][conflict_key]:
            self.stats['hits'] += 1
            self._update_access_patterns(key)
            self.location_map[key] = (building_id, 'conflict', conflict_key)
            return building['conflict_structures'][conflict_key][key]
        
        # Follow Hamiltonian path to search for the key
        max_probes = 20
        path = self._find_nearest_path(building_id, coords)
        
        # Find starting position in path
        start_idx = self._find_path_start_index(path, coords)
        
        # Bidirectional search along the path
        forward_steps = 0
        backward_steps = 0
        probes = 0
        
        while forward_steps + backward_steps < max_probes:
            # Try forward direction
            if forward_steps <= backward_steps:
                forward_steps += 1
                idx = (start_idx + forward_steps) % len(path)
                check_coords = path[idx]
                probes += 1
                
                if check_coords in building['dimensional_core']:
                    entry = building['dimensional_core'][check_coords]
                    if entry[0] == key:
                        self.stats['hits'] += 1
                        self.stats['probes_total'] += probes
                        self.stats['max_probes'] = max(self.stats['max_probes'], probes)
                        self._update_access_patterns(key)
                        self.location_map[key] = (building_id, 'dimensional', check_coords)
                        return entry[1]
            # Try backward direction
            else:
                backward_steps += 1
                idx = (start_idx - backward_steps) % len(path)
                check_coords = path[idx]
                probes += 1
                
                if check_coords in building['dimensional_core']:
                    entry = building['dimensional_core'][check_coords]
                    if entry[0] == key:
                        self.stats['hits'] += 1
                        self.stats['probes_total'] += probes
                        self.stats['max_probes'] = max(self.stats['max_probes'], probes)
                        self._update_access_patterns(key)
                        self.location_map[key] = (building_id, 'dimensional', check_coords)
                        return entry[1]
        
        # Key not found in this building
        self.stats['probes_total'] += probes
        return None
    
    def get_multiple(self, keys: List[Any]) -> Dict[Any, Any]:
        """
        Retrieve multiple values by keys, optimizing for related access.
        
        Args:
            keys: List of keys to retrieve
            
        Returns:
            Dictionary mapping keys to values
        """
        # Check for cached path for this key set
        keys_set = frozenset(keys)
        keys_set_hash = hash(keys_set)
        
        # Check if we have a path for this exact set
        if keys_set_hash in self.path_cache:
            path_info = self.path_cache[keys_set_hash]
            self.path_usage[keys_set_hash] += 1
            return self._retrieve_using_path(path_info, keys)
        
        # Group keys by building for efficiency
        by_building = defaultdict(list)
        for key in keys:
            # Determine which building should contain this key
            building_id = self._hash_to_building(key)
            by_building[building_id].append(key)
        
        # Retrieve from each building efficiently
        results = {}
        for building_id, building_keys in by_building.items():
            # Get all items from this building
            building_results = self._get_multiple_from_building(building_id, building_keys)
            results.update(building_results)
        
        # Record this access pattern for future optimization
        if len(keys) > 1:
            keys_tuple = tuple(sorted(keys))
            path_info = self._create_retrieval_path(keys)
            self.path_cache[keys_set_hash] = path_info
        
        # Update co-access patterns
        for i, key1 in enumerate(keys):
            for j in range(i+1, len(keys)):
                key2 = keys[j]
                if key1 in results and key2 in results:
                    self.co_access_matrix[key1][key2] += 1
                    self.co_access_matrix[key2][key1] += 1
        
        return results
    
    def _get_multiple_from_building(self, building_id: str, keys: List[Any]) -> Dict[Any, Any]:
        """
        Retrieve multiple keys from a specific building efficiently.
        
        Args:
            building_id: Building ID
            keys: List of keys to retrieve
            
        Returns:
            Dictionary mapping keys to values
        """
        building = self.buildings[building_id]
        
        # Track building access
        building['access_count'] += len(keys)
        
        results = {}
        
        # Organize keys by region for efficient access
        # First check velocity region
        velocity_keys = {}
        for key in keys:
            velocity_idx = self._hash_to_velocity_index(key, building_id)
            if velocity_idx not in velocity_keys:
                velocity_keys[velocity_idx] = []
            velocity_keys[velocity_idx].append(key)
        
        # Check velocity region keys
        for idx, idx_keys in velocity_keys.items():
            entry = building['velocity_region'][idx]
            if entry:
                key = entry[0]
                if key in idx_keys:
                    results[key] = entry[1]
                    self.stats['hits'] += 1
                    self._update_access_patterns(key)
        
        # Group remaining keys by coordinates for dimensional core
        remaining = [k for k in keys if k not in results]
        coord_keys = defaultdict(list)
        
        for key in remaining:
            coords = self._hash_to_coords(key, building_id)
            coord_keys[coords].append(key)
        
        # Check dimensional core
        for coords, coord_set in coord_keys.items():
            if coords in building['dimensional_core']:
                entry = building['dimensional_core'][coords]
                key = entry[0]
                if key in coord_set:
                    results[key] = entry[1]
                    self.stats['hits'] += 1
                    self._update_access_patterns(key)
        
        # Group by conflict key for remaining keys
        remaining = [k for k in remaining if k not in results]
        conflict_groups = defaultdict(list)
        
        for key in remaining:
            coords = self._hash_to_coords(key, building_id)
            conflict_key = self._hash_to_conflict_key(key, coords)
            conflict_groups[conflict_key].append(key)
        
        # Check conflict structures
        for conflict_key, conflict_keys in conflict_groups.items():
            if conflict_key in building['conflict_structures']:
                for key in conflict_keys:
                    if key in building['conflict_structures'][conflict_key]:
                        results[key] = building['conflict_structures'][conflict_key][key]
                        self.stats['hits'] += 1
                        self._update_access_patterns(key)
        
        # Handle any keys not found through direct lookups
        remaining = [k for k in remaining if k not in results]
        
        # For remaining keys, follow Hamiltonian paths
        # Group by nearest path for efficiency
        path_groups = defaultdict(list)
        
        for key in remaining:
            coords = self._hash_to_coords(key, building_id)
            path_key = self._find_nearest_path_key(building_id, coords)
            path_groups[path_key].append((key, coords))
        
        # Search along each path
        for path_key, key_coords in path_groups.items():
            path = self.hamiltonian_paths[path_key]
            
            # Search the path for each key
            for key, coords in key_coords:
                # Find start index in path
                start_idx = self._find_path_start_index(path, coords)
                
                # Search bidirectionally
                value = self._search_path(building_id, path, start_idx, key)
                if value is not None:
                    results[key] = value
                    self.stats['hits'] += 1
                else:
                    self.stats['misses'] += 1
        
        return results
    
    def _search_path(self, building_id: str, path: List[Tuple], start_idx: int, key: Any) -> Any:
        """
        Search for a key along a Hamiltonian path.
        
        Args:
            building_id: Building ID
            path: Hamiltonian path to search
            start_idx: Starting index in the path
            key: Key to search for
            
        Returns:
            Value if found, None otherwise
        """
        building = self.buildings[building_id]
        max_probes = 20
        probes = 0
        
        # Bidirectional search
        forward_steps = 0
        backward_steps = 0
        
        while forward_steps + backward_steps < max_probes:
            # Try forward direction
            if forward_steps <= backward_steps:
                forward_steps += 1
                idx = (start_idx + forward_steps) % len(path)
                check_coords = path[idx]
                probes += 1
                
                if check_coords in building['dimensional_core']:
                    entry = building['dimensional_core'][check_coords]
                    if entry[0] == key:
                        self.stats['probes_total'] += probes
                        self.stats['max_probes'] = max(self.stats['max_probes'], probes)
                        self._update_access_patterns(key)
                        self.location_map[key] = (building_id, 'dimensional', check_coords)
                        return entry[1]
            # Try backward direction
            else:
                backward_steps += 1
                idx = (start_idx - backward_steps) % len(path)
                check_coords = path[idx]
                probes += 1
                
                if check_coords in building['dimensional_core']:
                    entry = building['dimensional_core'][check_coords]
                    if entry[0] == key:
                        self.stats['probes_total'] += probes
                        self.stats['max_probes'] = max(self.stats['max_probes'], probes)
                        self._update_access_patterns(key)
                        self.location_map[key] = (building_id, 'dimensional', check_coords)
                        return entry[1]
        
        # Key not found along this path
        self.stats['probes_total'] += probes
        return None
    
    def _create_retrieval_path(self, keys: List[Any]) -> Dict:
        """
        Create an optimized retrieval path for a set of keys.
        
        Args:
            keys: List of keys
            
        Returns:
            Path information dictionary
        """
        # Get locations for all keys
        locations = []
        for key in keys:
            # Use known location if available
            if key in self.location_map:
                locations.append((key, self.location_map[key]))
            else:
                # Otherwise compute likely location
                building_id = self._hash_to_building(key)
                velocity_idx = self._hash_to_velocity_index(key, building_id)
                coords = self._hash_to_coords(key, building_id)
                conflict_key = self._hash_to_conflict_key(key, coords)
                
                # Check which region it's most likely to be in
                building = self.buildings[building_id]
                if building['velocity_region'][velocity_idx] and building['velocity_region'][velocity_idx][0] == key:
                    location = (building_id, 'velocity', velocity_idx)
                elif coords in building['dimensional_core'] and building['dimensional_core'][coords][0] == key:
                    location = (building_id, 'dimensional', coords)
                elif conflict_key in building['conflict_structures'] and key in building['conflict_structures'][conflict_key]:
                    location = (building_id, 'conflict', conflict_key)
                else:
                    # Default to dimensional core location
                    location = (building_id, 'dimensional', coords)
                
                locations.append((key, location))
        
        # Create path information
        return {
            'keys': set(keys),
            'locations': dict(locations),
            'created': time.time()
        }
    
    def _retrieve_using_path(self, path_info: Dict, keys: List[Any]) -> Dict[Any, Any]:
        """
        Retrieve values using a pre-computed path.
        
        Args:
            path_info: Path information dictionary
            keys: Keys to retrieve
            
        Returns:
            Dictionary mapping keys to values
        """
        results = {}
        locations = path_info['locations']
        
        # Get values for each key using known locations
        for key in keys:
            if key in locations:
                building_id, region_type, location = locations[key]
                building = self.buildings[building_id]
                
                # Track building access
                building['access_count'] += 1
                
                # Retrieve based on region type
                if region_type == 'velocity':
                    entry = building['velocity_region'][location]
                    if entry and entry[0] == key:
                        results[key] = entry[1]
                        self.stats['hits'] += 1
                        self._update_access_patterns(key)
                        continue
                elif region_type == 'dimensional':
                    if location in building['dimensional_core']:
                        entry = building['dimensional_core'][location]
                        if entry[0] == key:
                            results[key] = entry[1]
                            self.stats['hits'] += 1
                            self._update_access_patterns(key)
                            continue
                elif region_type == 'conflict':
                    if location in building['conflict_structures'] and key in building['conflict_structures'][location]:
                        results[key] = building['conflict_structures'][location][key]
                        self.stats['hits'] += 1
                        self._update_access_patterns(key)
                        continue
            
            # If location is invalid or key not in path, fall back to standard get
            value = self.get(key)
            if value is not None:
                results[key] = value
                # Stats already updated in get()
        
        return results
    
def remove(self, key: Any) -> bool:
       """
       Remove a key-value pair from the hash table.
       
       Args:
           key: The key to remove
           
       Returns:
           True if the key was found and removed, False otherwise
       """
       # Check if we know the location
       if key in self.location_map:
           building_id, region_type, location = self.location_map[key]
           building = self.buildings[building_id]
           
           # Remove based on region type
           if region_type == 'velocity':
               entry = building['velocity_region'][location]
               if entry and entry[0] == key:
                   building['velocity_region'][location] = None
                   del self.location_map[key]
                   self.size -= 1
                   return True
           elif region_type == 'dimensional':
               if location in building['dimensional_core']:
                   entry = building['dimensional_core'][location]
                   if entry[0] == key:
                       del building['dimensional_core'][location]
                       del self.location_map[key]
                       self.size -= 1
                       return True
           elif region_type == 'conflict':
               if location in building['conflict_structures'] and key in building['conflict_structures'][location]:
                   del building['conflict_structures'][location][key]
                   
                   # Remove conflict structure if empty
                   if not building['conflict_structures'][location]:
                       del building['conflict_structures'][location]
                   
                   del self.location_map[key]
                   self.size -= 1
                   return True
       
       # Location unknown or invalid, search all buildings
       for building_id, building in self.buildings.items():
           # Check velocity region
           velocity_idx = self._hash_to_velocity_index(key, building_id)
           entry = building['velocity_region'][velocity_idx]
           if entry and entry[0] == key:
               building['velocity_region'][velocity_idx] = None
               if key in self.location_map:
                   del self.location_map[key]
               self.size -= 1
               return True
           
           # Check dimensional core
           coords = self._hash_to_coords(key, building_id)
           if coords in building['dimensional_core']:
               entry = building['dimensional_core'][coords]
               if entry[0] == key:
                   del building['dimensional_core'][coords]
                   if key in self.location_map:
                       del self.location_map[key]
                   self.size -= 1
                   return True
           
           # Check conflict structures
           conflict_key = self._hash_to_conflict_key(key, coords)
           if conflict_key in building['conflict_structures'] and key in building['conflict_structures'][conflict_key]:
               del building['conflict_structures'][conflict_key][key]
               
               # Remove conflict structure if empty
               if not building['conflict_structures'][conflict_key]:
                   del building['conflict_structures'][conflict_key]
               
               if key in self.location_map:
                   del self.location_map[key]
               self.size -= 1
               return True
       
       # Key not found
       return False
   
   def clear(self) -> None:
       """Clear all entries from the hash table."""
       # Reinitialize all structures
       self.buildings = self._initialize_buildings()
       self.location_map = {}
       self.path_cache = {}
       self.access_history.clear()
       self.access_frequency.clear()
       self.co_access_matrix.clear()
       self.path_usage.clear()
       self.size = 0
       
       # Reset statistics
       for key in self.stats:
           self.stats[key] = 0
   
   def get_stats(self) -> Dict:
       """
       Get statistics about the hash table.
       
       Returns:
           Dictionary of statistics
       """
       load_factor = self.size / self.capacity if self.capacity > 0 else 0
       avg_probes = self.stats['probes_total'] / max(1, self.stats['gets']) 
       
       stats = {
           'size': self.size,
           'capacity': self.capacity,
           'load_factor': load_factor,
           'dimensions': self.dimensions,
           'puts': self.stats['puts'],
           'gets': self.stats['gets'],
           'hits': self.stats['hits'],
           'misses': self.stats['misses'],
           'hit_ratio': self.stats['hits'] / max(1, self.stats['gets']),
           'collisions': self.stats['collisions'],
           'avg_probes': avg_probes,
           'max_probes': self.stats['max_probes'],
           'buildings': len(self.buildings),
           'reorganizations': self.stats['reorganizations'],
           'path_cache_size': len(self.path_cache),
           'hot_keys': sum(len(b['hot_keys']) for b in self.buildings.values())
       }
       
       return stats
   
   # Hash functions and lookup helpers
   
   def _hash_to_building(self, key: Any) -> str:
       """
       Determine which building should contain a key.
       
       Args:
           key: The key to hash
           
       Returns:
           Building ID
       """
       hash_value = self._murmur_hash(key)
       building_idx = hash_value % len(self.buildings)
       return f"B{building_idx}"
   
   def _hash_to_velocity_index(self, key: Any, building_id: str) -> int:
       """
       Calculate velocity region index for a key.
       
       Args:
           key: The key to hash
           building_id: Building ID
           
       Returns:
           Index in velocity region
       """
       building = self.buildings[building_id]
       velocity_size = len(building['velocity_region'])
       
       # Use FNV-1a hash for this region
       hash_value = self._fnv_hash(key)
       return hash_value % velocity_size
   
   def _hash_to_coords(self, key: Any, building_id: str) -> Tuple:
       """
       Calculate multi-dimensional coordinates for a key.
       
       Args:
           key: The key to hash
           building_id: Building ID
           
       Returns:
           Tuple of coordinates
       """
       building = self.buildings[building_id]
       dimension_sizes = building['dimension_sizes']
       
       # Generate coordinates using different hash functions for each dimension
       coords = []
       hash_value = hash(key)
       
       for i in range(self.dimensions):
           # Use different hash functions for each dimension
           if i == 0:
               dim_hash = self._murmur_hash(key)
           elif i == 1:
               dim_hash = self._fnv_hash(key)
           else:
               # Mix the hash value differently for each dimension
               dim_hash = hash_value
               for j in range(i):
                   dim_hash = (dim_hash * 31 + i) ^ (dim_hash >> i)
           
           # Make sure it's positive and in range
           coords.append(abs(dim_hash) % dimension_sizes[i])
       
       return tuple(coords)
   
   def _hash_to_conflict_key(self, key: Any, coords: Tuple) -> int:
       """
       Create a conflict key for the conflict resolution structures.
       
       Args:
           key: The key to hash
           coords: Coordinates in the dimensional core
           
       Returns:
           Conflict key (hash value)
       """
       # Combine key hash and coordinates for a unique conflict key
       key_hash = hash(key)
       coords_hash = hash(coords)
       return (key_hash ^ coords_hash) & 0x7FFFFFFF  # Ensure positive
   
   def _murmur_hash(self, key: Any) -> int:
       """
       MurmurHash implementation for the primary hash function.
       
       Args:
           key: The key to hash
           
       Returns:
           32-bit hash value
       """
       # Convert key to string and then to bytes
       key_str = str(key)
       data = key_str.encode()
       length = len(data)
       
       # MurmurHash3 constants
       c1 = 0xcc9e2d51
       c2 = 0x1b873593
       r1 = 15
       r2 = 13
       m = 5
       n = 0xe6546b64
       
       # Initialize hash with seed
       seed = 0x9747b28c  # Random seed
       hash_value = seed
       
       # Process 4 bytes at a time
       nblocks = length // 4
       for i in range(nblocks):
           k = (data[i*4] |
                (data[i*4 + 1] << 8) |
                (data[i*4 + 2] << 16) |
                (data[i*4 + 3] << 24))
           
           k = (k * c1) & 0xFFFFFFFF
           k = ((k << r1) | (k >> (32 - r1))) & 0xFFFFFFFF
           k = (k * c2) & 0xFFFFFFFF
           
           hash_value ^= k
           hash_value = ((hash_value << r2) | (hash_value >> (32 - r2))) & 0xFFFFFFFF
           hash_value = ((hash_value * m) + n) & 0xFFFFFFFF
       
       # Process remaining bytes
       remaining = length % 4
       if remaining > 0:
           k = 0
           for i in range(remaining):
               k |= data[nblocks*4 + i] << (i * 8)
           
           k = (k * c1) & 0xFFFFFFFF
           k = ((k << r1) | (k >> (32 - r1))) & 0xFFFFFFFF
           k = (k * c2) & 0xFFFFFFFF
           
           hash_value ^= k
       
       # Finalization
       hash_value ^= length
       hash_value ^= (hash_value >> 16)
       hash_value = (hash_value * 0x85ebca6b) & 0xFFFFFFFF
       hash_value ^= (hash_value >> 13)
       hash_value = (hash_value * 0xc2b2ae35) & 0xFFFFFFFF
       hash_value ^= (hash_value >> 16)
       
       return hash_value & 0x7FFFFFFF  # Ensure positive
   
   def _fnv_hash(self, key: Any) -> int:
       """
       FNV-1a hash implementation for secondary hash function.
       
       Args:
           key: The key to hash
           
       Returns:
           32-bit hash value
       """
       # Convert key to string and then to bytes
       key_str = str(key)
       data = key_str.encode()
       
       # FNV-1a constants
       fnv_prime = 16777619
       fnv_offset_basis = 2166136261
       
       # FNV-1a algorithm
       hash_value = fnv_offset_basis
       for byte in data:
           hash_value ^= byte
           hash_value = (hash_value * fnv_prime) & 0xFFFFFFFF
       
       return hash_value & 0x7FFFFFFF  # Ensure positive
   
   # Hamiltonian path navigation
   
   def _find_nearest_path(self, building_id: str, coords: Tuple) -> List[Tuple]:
       """
       Find the nearest pre-computed Hamiltonian path to the given coordinates.
       
       Args:
           building_id: Building ID
           coords: Coordinates to start from
           
       Returns:
           Hamiltonian path as list of coordinates
       """
       path_key = self._find_nearest_path_key(building_id, coords)
       return self.hamiltonian_paths[path_key]
   
   def _find_nearest_path_key(self, building_id: str, coords: Tuple) -> Tuple:
       """
       Find the key of the nearest pre-computed Hamiltonian path.
       
       Args:
           building_id: Building ID
           coords: Coordinates to start from
           
       Returns:
           Path key (building_id, start_coords)
       """
       min_distance = float('inf')
       nearest_key = None
       
       # Find closest path starting point
       for key in self.hamiltonian_paths:
           if key[0] != building_id:
               continue
               
           path_coords = key[1]
           
           # Calculate Manhattan distance for efficiency
           distance = sum(abs(a - b) for a, b in zip(coords, path_coords))
           
           if distance < min_distance:
               min_distance = distance
               nearest_key = key
       
       return nearest_key
   
   def _find_path_start_index(self, path: List[Tuple], coords: Tuple) -> int:
       """
       Find the starting index in a Hamiltonian path closest to given coordinates.
       
       Args:
           path: Hamiltonian path
           coords: Coordinates to find
           
       Returns:
           Index in the path
       """
       min_distance = float('inf')
       best_idx = 0
       
       for i, path_coords in enumerate(path):
           # Manhattan distance for efficiency
           distance = sum(abs(a - b) for a, b in zip(coords, path_coords))
           
           if distance < min_distance:
               min_distance = distance
               best_idx = i
       
       return best_idx
   
   def _follow_hamiltonian_path(self, building_id: str, start_coords: Tuple) -> Tuple[Optional[Tuple], int]:
       """
       Follow a Hamiltonian path to find an empty slot.
       
       Args:
           building_id: Building ID
           start_coords: Starting coordinates
           
       Returns:
           Tuple of (coordinates found or None, probes used)
       """
       building = self.buildings[building_id]
       path = self._find_nearest_path(building_id, start_coords)
       
       # Find starting position in path
       start_idx = self._find_path_start_index(path, start_coords)
       
       # Follow the path to find an empty slot
       path_length = len(path)
       max_probes = min(20, path_length - 1)  # Limit probes
       
       # Bidirectional search
       forward_steps = 0
       backward_steps = 0
       probes = 0
       
       while forward_steps + backward_steps < max_probes:
           # Try forward direction
           if forward_steps <= backward_steps:
               forward_steps += 1
               idx = (start_idx + forward_steps) % path_length
               coords = path[idx]
               probes += 1
               
               if coords not in building['dimensional_core']:
                   return coords, probes
           # Try backward direction
           else:
               backward_steps += 1
               idx = (start_idx - backward_steps) % path_length
               coords = path[idx]
               probes += 1
               
               if coords not in building['dimensional_core']:
                   return coords, probes
       
       # If we couldn't find an empty slot, return None
       return None, probes
   
   # Access pattern tracking and optimization
   
   def _update_access_patterns(self, key: Any) -> None:
       """
       Update access pattern tracking for a key.
       
       Args:
           key: The key that was accessed
       """
       # Update access history
       self.access_history.append(key)
       
       # Update access frequency
       self.access_frequency[key] += 1
       
       # Update co-access matrix for recently accessed keys
       if len(self.access_history) > 1:
           for prev_key in list(self.access_history)[:-1]:
               if prev_key != key:
                   self.co_access_matrix[prev_key][key] += 1
                   self.co_access_matrix[key][prev_key] += 1
       
       # Check if this key should be promoted to hot keys
       if key in self.location_map:
           building_id = self.location_map[key][0]
           building = self.buildings[building_id]
           
           if self.access_frequency[key] > 10 and key not in building['hot_keys']:
               building['hot_keys'].add(key)
               
               # Consider promoting to velocity region
               self._consider_velocity_promotion(key, building_id)
   
   def _consider_velocity_promotion(self, key: Any, building_id: str) -> None:
       """
       Consider promoting a key to the velocity region.
       
       Args:
           key: The key to consider promoting
           building_id: Building ID
       """
       building = self.buildings[building_id]
       
       # Only promote if not already in velocity region
       if key in self.location_map:
           location = self.location_map[key]
           if location[0] == building_id and location[1] == 'velocity':
               return  # Already in velocity region
       
       # Calculate ideal velocity index
       velocity_idx = self._hash_to_velocity_index(key, building_id)
       current_entry = building['velocity_region'][velocity_idx]
       
       # Check if slot is empty or current key has lower frequency
       if current_entry is None:
           # Get value from current location
           value = self.get(key)
           if value is not None:
               # Move to velocity region
               building['velocity_region'][velocity_idx] = (key, value)
               
               # Remove from current location
               self._remove_from_current_location(key)
               
               # Update location map
               self.location_map[key] = (building_id, 'velocity', velocity_idx)
       elif key != current_entry[0]:
           # Compare frequencies
           current_key = current_entry[0]
           if (current_key not in self.access_frequency or 
               self.access_frequency[key] > self.access_frequency[current_key] * self.PHI):
               
               # Get value from current location
               value = self.get(key)
               if value is not None:
                   # Move current entry out if it's still valuable
                   if current_key in self.access_frequency and self.access_frequency[current_key] > 5:
                       self._relocate_from_velocity(current_key, current_entry[1], building_id)
                   
                   # Move new key to velocity region
                   building['velocity_region'][velocity_idx] = (key, value)
                   
                   # Remove from current location
                   self._remove_from_current_location(key)
                   
                   # Update location map
                   self.location_map[key] = (building_id, 'velocity', velocity_idx)
   
   def _relocate_from_velocity(self, key: Any, value: Any, building_id: str) -> None:
       """
       Relocate a key from the velocity region to dimensional core.
       
       Args:
           key: The key to relocate
           value: The value associated with the key
           building_id: Building ID
       """
       building = self.buildings[building_id]
       
       # Calculate dimensional coordinates
       coords = self._hash_to_coords(key, building_id)
       
       # Check if coordinates are available
       if coords not in building['dimensional_core']:
           building['dimensional_core'][coords] = (key, value)
           
           # Update location map
           self.location_map[key] = (building_id, 'dimensional', coords)
       else:
           # Handle collision by finding alternative location
           new_coords, _ = self._follow_hamiltonian_path(building_id, coords)
           
           if new_coords:
               building['dimensional_core'][new_coords] = (key, value)
               
               # Update location map
               self.location_map[key] = (building_id, 'dimensional', new_coords)
           else:
               # Last resort: use conflict structure
               conflict_key = self._hash_to_conflict_key(key, coords)
               
               if conflict_key not in building['conflict_structures']:
                   building['conflict_structures'][conflict_key] = {}
               
               building['conflict_structures'][conflict_key][key] = value
               
               # Update location map
               self.location_map[key] = (building_id, 'conflict', conflict_key)
   
   def _remove_from_current_location(self, key: Any) -> None:
       """
       Remove a key from its current location.
       
       Args:
           key: The key to remove
       """
       if key in self.location_map:
           building_id, region_type, location = self.location_map[key]
           building = self.buildings[building_id]
           
           if region_type == 'velocity':
               entry = building['velocity_region'][location]
               if entry and entry[0] == key:
                   building['velocity_region'][location] = None
           elif region_type == 'dimensional':
               if location in building['dimensional_core']:
                   entry = building['dimensional_core'][location]
                   if entry[0] == key:
                       del building['dimensional_core'][location]
           elif region_type == 'conflict':
               if location in building['conflict_structures'] and key in building['conflict_structures'][location]:
                   del building['conflict_structures'][location][key]
                   
                   # Remove conflict structure if empty
                   if not building['conflict_structures'][location]:
                       del building['conflict_structures'][location]
   
   def _check_optimization_needed(self) -> None:
       """Check if the hash table needs optimization."""
       current_time = time.time()
       
       # Check for minor optimization (relocating hot keys)
       if (self.operations_since_optimization >= 100 or
           current_time - self.last_minor_optimization >= 1.0):
           self._perform_minor_optimization()
           self.last_minor_optimization = current_time
       
       # Check for major optimization (reorganizing structure)
       if (self.operations_since_optimization >= 1000 or
           current_time - self.last_major_optimization >= 5.0):
           self._perform_major_optimization()
           self.last_major_optimization = current_time
           self.operations_since_optimization = 0
       
       # Check if resize is needed
       if self.size > self.capacity * self.load_factor_threshold:
           self._resize()
   
   def _perform_minor_optimization(self) -> None:
       """Perform minor optimization by relocating hot keys."""
       # Promote frequently accessed keys to velocity region
       hot_keys = self.access_frequency.most_common(100)
       
       for key, freq in hot_keys:
           if freq < 5:
               break  # Stop if frequency too low
               
           if key in self.location_map:
               building_id = self.location_map[key][0]
               self._consider_velocity_promotion(key, building_id)
   
   def _perform_major_optimization(self) -> None:
       """Perform major optimization by reorganizing the hash table structure."""
       self.stats['reorganizations'] += 1
       
       # Update shortcuts based on usage patterns
       self._update_shortcuts()
       
       # Identify hot key clusters
       self._identify_and_relocate_key_clusters()
       
       # Prune path cache to keep only frequently used paths
       self._prune_path_cache()
   
   def _update_shortcuts(self) -> None:
       """Update shortcuts based on observed usage patterns."""
       # Find high-traffic building pairs
       building_traffic = defaultdict(int)
       
       for key in self.access_history:
           if key in self.location_map:
               building_id = self.location_map[key][0]
               building_traffic[building_id] += 1
       
       # Update building shortcuts based on traffic
       for i, b1 in enumerate(self.buildings):
           for j, b2 in enumerate(self.buildings):
               if i != j:
                   shortcut_key = (b1, b2)
                   if shortcut_key in self.shortcuts:
                       # Update shortcut based on traffic
                       b1_traffic = building_traffic.get(b1, 0)
                       b2_traffic = building_traffic.get(b2, 0)
                       
                       # If both buildings have traffic, optimize the shortcut
                       if b1_traffic > 0 and b2_traffic > 0:
                           # Find better connection points based on hot keys
                           entry_point = self._find_better_entry_point(b1, b2)
                           exit_point = self._find_better_exit_point(b1, b2)
                           
                           if entry_point and exit_point:
                               self.shortcuts[shortcut_key]['entry_point'] = entry_point
                               self.shortcuts[shortcut_key]['exit_point'] = exit_point
                               self.shortcuts[shortcut_key]['cost'] = 0.8 / self.PHI  # Lower cost for optimized shortcut
   
   def _find_better_entry_point(self, from_building: str, to_building: str) -> Optional[Tuple]:
       """
       Find a better entry point for a shortcut between buildings.
       
       Args:
           from_building: Source building ID
           to_building: Destination building ID
           
       Returns:
           Better entry point coordinates or None
       """
       building = self.buildings[from_building]
       
       # Find hot keys in the source building
       hot_key_coords = []
       for key in building['hot_keys']:
           if key in self.location_map:
               location = self.location_map[key]
               if location[0] == from_building and location[1] == 'dimensional':
                   hot_key_coords.append(location[2])
       
       if hot_key_coords:
           # Find centroid of hot key coordinates
           centroid = tuple(sum(c[i] for c in hot_key_coords) // len(hot_key_coords) 
                          for i in range(self.dimensions))
           return centroid
       
       return None
   
   def _find_better_exit_point(self, from_building: str, to_building: str) -> Optional[Tuple]:
       """
       Find a better exit point for a shortcut between buildings.
       
       Args:
           from_building: Source building ID
           to_building: Destination building ID
           
       Returns:
           Better exit point coordinates or None
       """
       building = self.buildings[to_building]
       
       # Find hot keys in the destination building
       hot_key_coords = []
       for key in building['hot_keys']:
           if key in self.location_map:
               location = self.location_map[key]
               if location[0] == to_building and location[1] == 'dimensional':
                   hot_key_coords.append(location[2])
       
       if hot_key_coords:
           # Find centroid of hot key coordinates
           centroid = tuple(sum(c[i] for c in hot_key_coords) // len(hot_key_coords) 
                          for i in range(self.dimensions))
           return centroid
       
       return None
   
   def _identify_and_relocate_key_clusters(self) -> None:
       """Identify and relocate clusters of related keys."""
       # Build graph of related keys
       graph = defaultdict(set)
       threshold = 3  # Minimum co-access count to consider keys related
       
       for key1, related in self.co_access_matrix.items():
           for key2, count in related.items():
               if count >= threshold:
                   graph[key1].add(key2)
                   graph[key2].add(key1)
       
       # Find connected components (clusters)
       visited = set()
       clusters = []
       
       for key in graph:
           if key not in visited:
               cluster = set()
               queue = [key]
               visited.add(key)
               
               while queue:
                   current = queue.pop(0)
                   cluster.add(current)
                   
                   for neighbor in graph[current]:
                       if neighbor not in visited:
                           visited.add(neighbor)
                           queue.append(neighbor)
               
               if len(cluster) > 1:
                   clusters.append(cluster)
       
       # Relocate clusters to be close together
       for cluster in clusters:
           # Only process if cluster has at least 3 keys
           if len(cluster) < 3:
               continue
               
           # Count buildings for these keys
           building_counts = Counter()
           for key in cluster:
               if key in self.location_map:
                   building_counts[self.location_map[key][0]] += 1
           
           # Find dominant building
           if not building_counts:
               continue
               
           dominant_building = building_counts.most_common(1)[0][0]
           building = self.buildings[dominant_building]
           
           # Find coordinates for all keys in the cluster
           key_coords = {}
           for key in cluster:
               if key in self.location_map:
                   location = self.location_map[key]
                   if location[1] == 'dimensional':
                       key_coords[key] = location[2]
                   else:
                       # Calculate hypothetical coordinates
                       key_coords[key] = self._hash_to_coords(key, dominant_building)
           
           # Find centroid of existing coordinates
           if not key_coords:
               continue
               
           centroid = [0] * self.dimensions
           for coords in key_coords.values():
               for i in range(self.dimensions):
                   centroid[i] += coords[i]
           
           centroid = tuple(c // len(key_coords) for c in centroid)
           
           # Find available coordinates near centroid
           available_coords = set()
           path = self._compute_hamiltonian_path(dominant_building, centroid)
           
           for coords in path[:min(len(path), len(cluster) * 2)]:
               if coords not in building['dimensional_core']:
                   available_coords.add(coords)
           
           # Relocate keys to available coordinates
           available_coords = list(available_coords)
           if not available_coords:
               continue
               
           for i, key in enumerate(cluster):
               if i >= len(available_coords):
                   break
                   
               # Get current value
               value = self.get(key)
               if value is None:
                   continue
                   
               # Move to new location
               new_coords = available_coords[i]
               
               # Remove from current location
               self._remove_from_current_location(key)
               
               # Add to new location
               building['dimensional_core'][new_coords] = (key, value)
               self.location_map[key] = (dominant_building, 'dimensional', new_coords)
   
   def _prune_path_cache(self) -> None:
       """Prune the path cache to keep only frequently used paths."""
       # Keep only the most frequently used paths
       if len(self.path_cache) > 100:
           # Sort by usage count
           sorted_paths = sorted(self.path_usage.items(), key=lambda x: x[1], reverse=True)
           
           # Keep top 50% of paths
           keep_count = len(sorted_paths) // 2
           keep_keys = set(key for key, _ in sorted_paths[:keep_count])
           
           # Prune cache
           self.path_cache = {k: v for k, v in self.path_cache.items() if k in keep_keys}
           self.path_usage = {k: v for k, v in self.path_usage.items() if k in keep_keys}
   
def _resize(self) -> None:
       """Resize the hash table when it exceeds the load factor threshold."""
       # Calculate new capacity using golden ratio
       new_capacity = int(self.capacity * self.PHI)
       
       # Create new hash table with larger capacity
       new_table = MDHGHashTable(capacity=new_capacity, dimensions=self.dimensions)
       
       # Copy all entries to the new table
       for building_id, building in self.buildings.items():
           # Copy from velocity region
           for i, entry in enumerate(building['velocity_region']):
               if entry:
                   key, value = entry
                   new_table.put(key, value)
           
           # Copy from dimensional core
           for coords, entry in building['dimensional_core'].items():
               key, value = entry
               new_table.put(key, value)
           
           # Copy from conflict structures
           for conflict_key, entries in building['conflict_structures'].items():
               for key, value in entries.items():
                   new_table.put(key, value)
       
       # Transfer metadata and statistics
       new_table.access_history = self.access_history.copy()
       new_table.access_frequency = Counter(self.access_frequency)
       new_table.co_access_matrix = defaultdict(Counter)
       for key, counter in self.co_access_matrix.items():
           new_table.co_access_matrix[key] = Counter(counter)
       
       new_table.stats['puts'] = self.stats['puts']
       new_table.stats['gets'] = self.stats['gets']
       new_table.stats['hits'] = self.stats['hits']
       new_table.stats['misses'] = self.stats['misses']
       new_table.stats['collisions'] = self.stats['collisions']
       new_table.stats['probes_total'] = self.stats['probes_total']
       new_table.stats['max_probes'] = self.stats['max_probes']
       new_table.stats['reorganizations'] = self.stats['reorganizations']
       
       # Replace this hash table with the new one
       self.buildings = new_table.buildings
       self.capacity = new_table.capacity
       self.size = new_table.size
       self.location_map = new_table.location_map
       self.hamiltonian_paths = new_table.hamiltonian_paths
       self.path_cache = new_table.path_cache
       self.shortcuts = new_table.shortcuts

```