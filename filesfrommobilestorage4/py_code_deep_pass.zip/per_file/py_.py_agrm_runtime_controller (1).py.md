# File: py/.py/agrm_runtime_controller (1).py

**Extension:** .py

**Lines:** 68 | **Words:** 208

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 6

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: navigator_and_builder, salesman_and_evaluator

- Classes (2): FeedbackBus, AGRMRuntimeController

- Functions (5): __init__, broadcast, collect_all, __init__, run_cycle


---


## Full Source


```text


from navigator_and_builder import NavigatorGR, BuilderAgent
from salesman_and_evaluator import Salesman, AGRMEvaluator

class FeedbackBus:
    def __init__(self):
        self.queue = []

    def broadcast(self, batch):
        self.queue.extend(batch)

    def collect_all(self):
        batch = self.queue[:]
        self.queue.clear()
        return batch


class AGRMRuntimeController:
    def __init__(self, nodes):
        self.nodes = nodes
        self.navigator = NavigatorGR()
        self.builder_fwd = BuilderAgent()
        self.builder_rev = BuilderAgent()
        self.evaluator = AGRMEvaluator()
        self.salesman = Salesman(nodes)
        self.feedback_bus = FeedbackBus()
        self.state = 'sweep'
        self.loop_counter = 0
        self.max_loops = 100
        self.current_path = []

    def run_cycle(self):
        print(f"[AGRM] Cycle {self.loop_counter + 1} | State: {self.state}")
        if self.state == 'sweep':
            self.navigator.run_sweep(self.nodes)
            self.state = 'build'
        elif self.state == 'build':
            sweep_path = self.navigator.get_sweep_path()
            path_fwd = self.builder_fwd.build_path(sweep_path)
            # Optionally add: reverse build comparison here
            self.current_path = path_fwd
            self.state = 'validate'
        elif self.state == 'validate':
            self.salesman.scan_path(self.current_path)
            self.state = 'feedback'
        elif self.state == 'feedback':
            batch = self.salesman.collect_feedback()
            self.feedback_bus.broadcast(batch)
            self.state = 'evaluator'
        elif self.state == 'evaluator':
            incoming = self.feedback_bus.collect_all()
            self.evaluator.ingest_feedback(incoming)
            self.evaluator.apply_modulation_if_needed()
            if self.evaluator.reset_required():
                self.builder_fwd.trigger_reroute()
                self.state = 'sweep'
            else:
                self.state = 'complete'
        elif self.state == 'complete':
            print("[AGRM] ✓ Cycle complete.")
            return True

        self.loop_counter += 1
        if self.loop_counter >= self.max_loops:
            print("[AGRM] ⚠ Max cycles exceeded.")
            return True
        return False


```