# File: py/.py/agrm_cli_launcher (2).py

**Extension:** .py

**Lines:** 130 | **Words:** 451

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 19

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 19

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: argparse, os, requests, subprocess

- From-imports: agrm_profiler_diagnostics, agrm_results_export, agrm_runtime_controller, tsp_node_loader

- Classes (1): FeedbackBus

- Functions (7): download_tsplib_file, run_agrm, run_all_tests, main, __init__, broadcast, collect_all


---


## Full Source


```text


import argparse
import os
import subprocess

try:
    import requests
except ImportError:
    subprocess.check_call(["python", "-m", "pip", "install", "requests"])
    import requests

from agrm_profiler_diagnostics import AGRMProfiler, AGRMDiagnosticController
from agrm_runtime_controller import AGRMRuntimeController, BuilderAgent, AGRMEvaluator, NavigatorGR
from tsp_node_loader import select_tsp_dataset, TSPLIB_DATASETS
from agrm_results_export import export_results_to_csv, export_results_to_json, plot_comparison_graph

def download_tsplib_file(filename: str, folder: str):
    url_base = "https://people.sc.fsu.edu/~jburkardt/datasets/tsp/"
    full_url = url_base + filename
    local_path = os.path.join(folder, filename)
    if not os.path.exists(local_path):
        print(f"[DOWNLOADING] {filename}...")
        r = requests.get(full_url)
        if r.status_code == 200:
            with open(local_path, 'wb') as f:
                f.write(r.content)
        else:
            print(f"[ERROR] Could not download {filename}: Status {r.status_code}")
    return local_path

def run_agrm(loader, config_overrides, dataset_name="custom"):
    print(f"\n[RUNNING AGRM TEST] Dataset: {dataset_name}")
    diag = AGRMDiagnosticController()
    for k, v in config_overrides.items():
        diag.set_param(k, v)

    profiler = AGRMProfiler()
    profiler.start_timer()

    navigator = NavigatorGR()
    builder_fwd = BuilderAgent()
    builder_rev = BuilderAgent()
    evaluator = AGRMEvaluator()
    salesman = type('Salesman', (), {
        'scan_path': lambda self: print("[Salesman] Scanning path..."),
        'collect_feedback': lambda self: [{'type': 'reroute_proposal', 'node': 15, 'strain': 0.75}]
    })()

    class FeedbackBus:
        def __init__(self):
            self.queue = []
        def broadcast(self, batch):
            self.queue.extend(batch)
        def collect_all(self):
            batch = self.queue[:]
            self.queue.clear()
            return batch

    feedback_bus = FeedbackBus()

    runtime = AGRMRuntimeController(
        navigator, builder_fwd, builder_rev, evaluator, salesman, feedback_bus
    )

    while True:
        profiler.mark('cycles')
        if runtime.run_cycle():
            break

    profiler.stop_timer()
    print("\n--- AGRM Summary ---")
    profiler.print_report()
    return profiler.report()

def run_all_tests():
    all_results = {}
    for name in TSPLIB_DATASETS.keys():
        tsp_path, opt_path = TSPLIB_DATASETS[name]
        os.makedirs("datasets", exist_ok=True)
        download_tsplib_file(os.path.basename(tsp_path), "datasets")
        download_tsplib_file(os.path.basename(opt_path), "datasets")
        loader, config, _ = select_tsp_dataset(name)
        report = run_agrm(loader, config, dataset_name=name)
        all_results[name] = report
    print("\n[ALL AGRM TESTS COMPLETE]")
    return all_results

greedy_baseline_dict = {
    'pcb442': 18000, 'pr2392': 140000, 'rl5915': 360000,
    'rl11849': 700000, 'usa13509': 820000, 'brd14051': 860000,
    'd15112': 920000, 'pla33810': 2000000, 'pla85900': 5000000
}

optimal_baseline_dict = {
    'pcb442': 50778, 'pr2392': 378032, 'rl5915': 565530,
    'rl11849': 923288, 'usa13509': 19982859, 'brd14051': 469385,
    'd15112': 736468, 'pla33810': 660489, 'pla85900': 14238241
}

def main():
    parser = argparse.ArgumentParser(description="Launch AGRM Runtime with Diagnostics")
    parser.add_argument('--dataset', type=str, help='Name of TSP dataset')
    parser.add_argument('--run_all', action='store_true', help='Run all benchmark tests')
    parser.add_argument('--export', action='store_true', help='Export results to CSV and JSON')
    parser.add_argument('--compare', action='store_true', help='Plot AGRM vs Greedy vs Optimal graph')
    args = parser.parse_args()

    if args.run_all:
        results = run_all_tests()
        if args.export:
            export_results_to_csv(results)
            export_results_to_json(results)
        if args.compare:
            plot_comparison_graph(results, greedy_baseline_dict, optimal_baseline_dict)
    elif args.dataset:
        tsp_path, opt_path = TSPLIB_DATASETS[args.dataset]
        os.makedirs("datasets", exist_ok=True)
        download_tsplib_file(os.path.basename(tsp_path), "datasets")
        download_tsplib_file(os.path.basename(opt_path), "datasets")
        loader, config, _ = select_tsp_dataset(args.dataset)
        result = run_agrm(loader, config, dataset_name=args.dataset)
        if args.export:
            export_results_to_csv({args.dataset: result})
            export_results_to_json({args.dataset: result})
    else:
        print("[ERROR] Please specify --dataset <name> or --run_all")

if __name__ == '__main__':
    main()


```