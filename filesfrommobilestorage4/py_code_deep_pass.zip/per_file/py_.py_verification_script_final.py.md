# File: py/.py/verification_script_final.py

**Extension:** .py

**Lines:** 53 | **Words:** 206

## Keyword Hits

- SFBB: 0

- superperm: 13

- superpermutation: 13

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: itertools, sys

- From-imports: (none)

- Classes (0): (none)

- Functions (1): verify_superpermutation


---


## Full Source


```text

import itertools
import sys

def verify_superpermutation(superpermutation, n):
    """
    Verifies if a given string is a valid superpermutation for n symbols.

    Args:
        superpermutation: The string to verify.
        n: The number of symbols (1 to n).

    Returns:
        True if the string is a valid superpermutation, False otherwise.
        Prints informative messages to the console.
    """
    permutations = set(itertools.permutations(range(1, n + 1)))
    found_permutations = set()
    s_tuple = tuple(int(x) for x in superpermutation)

    for i in range(len(s_tuple) - n + 1):
        perm = s_tuple[i:i + n]
        if len(set(perm)) == n and min(perm) == 1 and max(perm) == n:
            found_permutations.add(perm)

    missing_permutations = permutations - found_permutations

    if not missing_permutations:
        print(f"Verification successful: The string is a valid superpermutation for n={n}.")
        print(f"Length: {len(superpermutation)}")
        return True
    else:
        print(f"Verification failed: The string is NOT a valid superpermutation for n={n}.")
        print(f"Missing permutations ({len(missing_permutations)}):")
        for perm in missing_permutations:
            print(perm)
        return False

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python verification_script.py <superpermutation_file> <n>")
        sys.exit(1)

    filename = sys.argv[1]
    n = int(sys.argv[2])

    try:
        with open(filename, "r") as f:
            superpermutation_string = f.read().strip()
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        sys.exit(1)

    verify_superpermutation(superpermutation_string, n)

```