# File: py/.py/agrm_dynamic_midpoint.py

**Extension:** .py

**Lines:** 29 | **Words:** 137

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMDynamicMidpointDetector

- Functions (4): __init__, _compute_center, detect, _distance


---


## Full Source


```text


from typing import Tuple, Dict, List
import math

class AGRMDynamicMidpointDetector:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def detect(self, path: List[int], limit_shell_radius: float = 0.6) -> int:
        distances = [
            (node, self._distance(self.nodes[node], self.center))
            for node in path
        ]
        shell_cutoff = sorted(distances, key=lambda x: x[1])[int(len(distances) * limit_shell_radius)][1]

        # Return index of node that passes back inside cutoff radius
        for i, (node, dist) in enumerate(distances):
            if dist <= shell_cutoff:
                return i
        return len(path) // 2  # fallback to center index

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])


```