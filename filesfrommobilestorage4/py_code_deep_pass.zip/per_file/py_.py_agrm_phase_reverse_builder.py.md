# File: py/.py/agrm_phase_reverse_builder.py

**Extension:** .py

**Lines:** 59 | **Words:** 235

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMPhaseAwareReverseBuilder

- Functions (5): __init__, _compute_center, _map_quadrants, build_reverse, _dist


---


## Full Source


```text


from typing import List, Tuple, Dict
import math

class AGRMPhaseAwareReverseBuilder:
    def __init__(self, nodes: Dict[int, Tuple[float, float]], sweep_path: List[int]):
        self.nodes = nodes
        self.sweep_path = sweep_path
        self.center = self._compute_center()
        self.quadrants = self._map_quadrants()

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def _map_quadrants(self) -> Dict[int, int]:
        qmap = {}
        for nid, (x, y) in self.nodes.items():
            dx, dy = x - self.center[0], y - self.center[1]
            if dx >= 0 and dy >= 0:
                q = 0
            elif dx < 0 and dy >= 0:
                q = 1
            elif dx < 0 and dy < 0:
                q = 2
            else:
                q = 3
            qmap[nid] = q
        return qmap

    def build_reverse(self) -> List[int]:
        print("[PhaseReverse] Building reverse path with quadrant memory...")
        quadrant_order = [self.quadrants[nid] for nid in self.sweep_path]
        reversed_path = list(reversed(self.sweep_path))

        # Sort reverse path so quadrant transitions are minimized
        stable_path = [reversed_path[0]]
        used = set(stable_path)

        for _ in range(1, len(reversed_path)):
            last_q = self.quadrants[stable_path[-1]]
            candidates = [
                nid for nid in reversed_path
                if nid not in used and abs(self.quadrants[nid] - last_q) <= 1
            ]
            if not candidates:
                break
            next_nid = min(
                candidates,
                key=lambda n: self._dist(self.nodes[stable_path[-1]], self.nodes[n])
            )
            stable_path.append(next_nid)
            used.add(next_nid)

        return stable_path

    def _dist(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])


```