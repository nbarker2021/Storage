# File: py/.py/config.py

**Extension:** .py

**Lines:** 145 | **Words:** 591

## Keyword Hits

- SFBB: 0

- superperm: 1

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 1

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: json, math, os, psutil

- From-imports: typing

- Classes (1): ConfigManager

- Functions (7): __init__, load_settings, get_setting, set_setting, save_settings, auto_adjust_settings, get_system_specs


---


## Full Source


```text

import json
from typing import Dict, Any
import math
import os
import psutil

class ConfigManager:
    def __init__(self, config_file: str = 'config.json'):
        self.settings: Dict[str, Any] = {
            'n': 7,  # Target n-value
            'auto_loop': False, # Whether to automatically loop through n values
            'strategy': 'bouncing_batch',
            'evaluation_metric': 'comprehensive',
            'length_weight': 1.0,
            'imperfection_weight': 10000000.0,
            'winner_loser_weight': 4.5,
            'layout_memory_weight': 0.35,
            'imbalance_weight': 0.02,
            'connectivity_weight': 1.4,
            'symmetry_weight': 0.0,
            'extensibility_weight': 2.0,
            'grid_dimensions': [3, 3, 3],
            'bouncing_batch_size': 7,
            'bouncing_batch_iterations': 150,
            "store_full_permutations": False, # Correct for n=7
            "k_mer_size": 6,
            'data_file' : 'superperm_data.json',
            'strategy_thresholds': {'small': 5, 'medium': 7},
            'auto_adjust': True,  # Re-enable auto-adjust
            'auto_adjust_params': {
                "max_n_factor": 1000,
                "max_n_base": 2.718,
                "local_search_iterations_base": 100,
                "local_search_iterations_factor": 50,
                "sandbox_timeout_base": 10,
                "sandbox_timeout_exponent": 2.5,
                "sandbox_timeout_factor": 2,
                "sandbox_memory_limit_percentage": 0.5,
                "sandbox_max_memory_limit_mb": 4096,
                "sandbox_max_processes": 4
            },
             'model_file': "model.pkl", #back in use
            'train_models': False,    #Set to true to train
            "sp_formulas": {
                "sp_v14": { "phi": 1.618033988749895 }
            },
            "c_formulas": {
                "c_n_debruijn": {"a": 1.0, "b": 2.0, "c": 3.0}
            },
            "i_formulas": {
                "i_n_factorial_diff": {"a": 0.5, "b": 4.6, "c": 5, "d": 5.5, "scc_weight": 150.0},
                "i_n_exponential": {"c0": 1.0, "k": 0.175}
            }
        }
        self.config_file: str = config_file
        self.load_settings(self.config_file)
        if self.get_setting('auto_adjust', True):
            self.auto_adjust_settings()


    def load_settings(self, file_path: str) -> None:
        try:
            with open(file_path, 'r') as f:
                loaded_settings: Dict[str, Any] = json.load(f)
                self.settings.update(loaded_settings)
        except FileNotFoundError:
            print(f"Config file {file_path} not found. Using default settings.")
            # No user input needed
        except json.JSONDecodeError:
            print(f"Error parsing {file_path}. Using default settings.")


    def get_setting(self, key: str, default: Any = None) -> Any:
        return self.settings.get(key, default)

    def set_setting(self, key: str, value: Any) -> None:
        self.settings[key] = value
        self.save_settings(self.config_file)

    def save_settings(self, file_path: str) -> None:
        try:
            with open(file_path, 'w') as f:
                json.dump(self.settings, f, indent=4)
            print(f"Settings saved to {file_path}")
        except IOError as e:
            print(f"Error saving settings to {file_path}: {e}")

    def auto_adjust_settings(self):
        """Automatically adjusts settings based on system specifications."""
        specs = self.get_system_specs()
        params = self.settings['auto_adjust_params']

        # Adjust 'n' based on available memory (simplified example):
        try:
            max_n = int(math.log(specs['available_memory_gb'] * params["max_n_factor"], params["max_n_base"]))
            self.settings['n'] = min(max_n, self.settings['n']) #Bounded by memory
        except (ValueError, TypeError) as e:
            print(f"Error during auto-adjustment of n: {e}")

        # Adjust strategy based on n (example)
        strategy_thresholds = self.get_setting('strategy_thresholds', {'small': 5, 'medium': 7})
        if self.settings['n'] <= strategy_thresholds['small']:
            self.settings['strategy'] = 'n_minus_1_shell'
        elif self.settings['n'] <= strategy_thresholds['medium']:
            self.settings['strategy'] = 'prodigal_combination'
        else:
            self.settings['strategy'] = 'bouncing_batch'  # Example default for larger n

        # Adjust local_search_iterations based on CPU count:
        try:
             self.settings['local_search_iterations'] = int(params["local_search_iterations_base"] + specs['cpu_count'] * params["local_search_iterations_factor"])
        except (ValueError, TypeError) as e:
             print (f"Error during auto adjustment of local search iterations: {e}")
        # Adjust sandbox_timeout based on n:
        try:
            self.settings['sandbox_timeout'] = int(params["sandbox_timeout_base"] + (self.settings['n'] ** params["sandbox_timeout_exponent"]) * params["sandbox_timeout_factor"])
        except (ValueError, TypeError) as e:
             print (f"Error during auto adjustment of sandbox timeout: {e}")

        #Adjust Sandbox memory limit
        try:
          self.settings['sandbox_memory_limit_mb'] = int(min(specs['total_memory_gb'] * 1024 * params["sandbox_memory_limit_percentage"], params["sandbox_max_memory_limit_mb"] ))
        except (ValueError, TypeError) as e:
             print (f"Error during auto adjustment of sandbox memory: {e}")

        #Adjust number of processes:
        try:
            self.settings['sandbox_num_processes'] = min(specs['cpu_count'], params["sandbox_max_processes"])
        except(ValueError, TypeError) as e:
            print (f"Error during auto adjustment of sandbox processes: {e}")

        print("Settings auto-adjusted based on system specifications.")
        self.save_settings(self.config_file) #Save changes.


    def get_system_specs(self):
        """Gets System Specs"""
        return {
            'cpu_count': psutil.cpu_count(logical=False),
            'logical_cpu_count': psutil.cpu_count(logical=True),
            'total_memory_gb': psutil.virtual_memory().total / (1024**3),
            'available_memory_gb': psutil.virtual_memory().available / (1024**3),
            'platform': psutil.platform(),
            'os': os.name,
        }

```