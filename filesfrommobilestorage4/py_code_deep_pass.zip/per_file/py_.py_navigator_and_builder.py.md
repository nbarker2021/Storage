# File: py/.py/navigator_and_builder.py

**Extension:** .py

**Lines:** 57 | **Words:** 185

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 2

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math, random

- From-imports: typing

- Classes (2): NavigatorGR, BuilderAgent

- Functions (10): __init__, run_sweep, _spiral_sort_key, get_sweep_path, trigger_reseed, __init__, build_path, _smart_shuffle, trigger_reroute, get_last_path


---


## Full Source


```text


import math
from typing import List, Dict, Tuple
import random

class NavigatorGR:
    def __init__(self):
        self.sweep_path: List[int] = []
        self.reseed_triggered = False

    def run_sweep(self, nodes: Dict[int, Tuple[float, float]]):
        print("[NavigatorGR] Running golden ratio spiral sweep...")
        sorted_nodes = sorted(nodes.items(), key=lambda item: self._spiral_sort_key(item[1]))
        self.sweep_path = [node_id for node_id, _ in sorted_nodes]

    def _spiral_sort_key(self, coord: Tuple[float, float]) -> float:
        x, y = coord
        r = math.hypot(x, y)
        theta = math.atan2(y, x)
        phi = (1 + math.sqrt(5)) / 2  # golden ratio
        return r - phi * theta

    def get_sweep_path(self) -> List[int]:
        return self.sweep_path

    def trigger_reseed(self):
        self.reseed_triggered = True


class BuilderAgent:
    def __init__(self):
        self.reroute_flag = False
        self.last_path = []

    def build_path(self, node_ids: List[int]) -> List[int]:
        path = node_ids[:]
        if self.reroute_flag:
            print("[Builder] Performing reroute shuffle...")
            self._smart_shuffle(path)
        else:
            print("[Builder] Building direct path from spiral sweep...")
        self.last_path = path
        self.reroute_flag = False
        return path

    def _smart_shuffle(self, path: List[int]):
        if len(path) > 10:
            section = path[5:-5]
            random.shuffle(section)
            path[5:-5] = section

    def trigger_reroute(self):
        self.reroute_flag = True

    def get_last_path(self):
        return self.last_path


```