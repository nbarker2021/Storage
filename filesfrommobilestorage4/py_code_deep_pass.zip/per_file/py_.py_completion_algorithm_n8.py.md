# File: py/.py/completion_algorithm_n8.py

**Extension:** .py

**Lines:** 250 | **Words:** 1214

## Keyword Hits

- SFBB: 0

- superperm: 45

- superpermutation: 44

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 50

- golden: 7

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: (none)

- Classes (0): (none)

- Functions (1): complete_superpermutation


---


## Full Source


```text

def complete_superpermutation(superpermutation: str, n: int, all_permutations: list[tuple[int, ...]],
                              prodigal_results: dict, winners: dict, losers: dict,
                              layout_memory: LayoutMemory, limbo_list: set) -> str:
    """Adds missing permutations to a near-complete superpermutation.

    Args:
        superpermutation (str): The initial (incomplete) superpermutation.
        n (int): The value of n.
        all_permutations (list): A list of *all* n! permutations (as tuples).
        prodigal_results (dict): Dictionary of ProdigalResult objects.
        winners (dict): Dictionary of Winner k-mers.
        losers (dict): Dictionary of Loser k-mers.
        layout_memory (LayoutMemory): The LayoutMemory object.
        limbo_list (set): The Limbo List.

    Returns:
        str: The completed superpermutation.
    """
    missing_permutations = set()
    s_tuple = tuple(int(x) for x in superpermutation)

    for p in all_permutations:
        found = False
        for i in range(len(s_tuple) - n + 1):
            if s_tuple[i:i+n] == p:
                found = True
                break
        if not found:
            missing_permutations.add(hash_permutation(p))  # Store as hashes

    working_superpermutation = list(superpermutation)  # Convert to list for mutability
    eput = {} #Local ePUT

    #Populate ePUT with current superpermutation data:
    s_tuple = tuple(int(x) for x in superpermutation)
    for i in range(len(s_tuple) - n + 1):
        perm = s_tuple[i:i+n]
        if is_valid_permutation(perm, n):
            perm_hash = hash_permutation(perm)
            if perm_hash not in eput:
              eput[perm_hash] = PermutationData(perm, in_sample = False, creation_method="prodigal") # These are from previous runs
            eput[perm_hash].used_count += 1
            eput[perm_hash].used_in_final = True
            #Update neighbors
            if i > 0:
                prev_perm = s_tuple[i-1:i-1+n]
                if is_valid_permutation(prev_perm, n):
                     eput[perm_hash].neighbors.add(hash_permutation(prev_perm))
            if i < len(s_tuple) - n:
                next_perm = s_tuple[i+1:i+1+n]
                if is_valid_permutation(next_perm, n):
                    eput[perm_hash].neighbors.add(hash_permutation(next_perm))
    
    # --- Main Completion Loop ---
    num_added = 0
    total_missing = len(missing_permutations)
    
    #Create initial hypothetical prodigals
    hypothetical_prodigals = analysis_scripts.generate_hypothetical_prodigals(prodigal_results, winners, losers, n)
    
    while missing_permutations: # Continue until all permutations are added
        
        #Randomly select missing permutation
        missing_perm_hash = random.choice(list(missing_permutations))
        missing_perm = unhash_permutation(missing_perm_hash, n)
        best_insertion_point = -1
        best_score = -float('inf')

        # 1. Generate Targeted Candidates (using the modified function)
        candidates = generate_completion_candidates(
            "".join(str(x) for x in working_superpermutation),  # Current superperm
            missing_permutations,  # Remaining missing perms
            prodigal_results,       # Prodigal results
            winners,               # Winners
            losers,                # Losers
            n,                     # n
            eput,                  # ePUT
            limbo_list             # Limbo list
        )

        # 2. Evaluate Candidates and Insert (using the enhanced scoring function)
        golden_ratio_points = calculate_golden_ratio_points(len(working_superpermutation), levels=3)
        for candidate_hash in candidates:
            candidate_perm = unhash_permutation(candidate_hash, n)
            candidate_string = "".join(str(x) for x in candidate_perm)

            for i in range(len(working_superpermutation) + 1):
                # Calculate overlap if inserted here.
                overlap_start = calculate_overlap("".join(str(x) for x in working_superpermutation[max(0,i-(n-1)):i]), candidate_string)
                overlap_end = calculate_overlap(candidate_string, "".join(str(x) for x in working_superpermutation[i:i+(n-1)]))
                overlap = max(overlap_start, overlap_end)

                # "Prodigal Disruption":
                prodigal_disruption = 0
                for prodigal_id, prodigal in prodigal_results.items():
                    if prodigal.sequence in "".join(str(x) for x in working_superpermutation):
                        # Check if insertion breaks it.
                        if not (prodigal.sequence in "".join(str(x) for x in working_superpermutation[:i + (n - 1)]) and \
                                prodigal.sequence in "".join(str(x) for x in working_superpermutation[i - (n - 1):])):
                            prodigal_disruption += prodigal.length  # Penalty

                # Golden Ratio Bonus
                golden_ratio_bonus = 0
                for point in golden_ratio_points:
                    distance = abs(i - point)
                    golden_ratio_bonus += math.exp(-distance / (len(working_superpermutation) / 20))

                # Winner/Loser Bonus/Penalty (using Layout Memory)
                k_values = [n - 1, n - 2]
                layout_bonus = 0
                for k in k_values:
                    if i >= k:
                        kmer_end = "".join(str(x) for x in working_superpermutation[i-k:i])
                        kmer_start = candidate_string[:k]
                        layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, (len(working_superpermutation)-i) if overlap == 0 else 1)  # Use correct distance
                    kmer_end = candidate_string[-k:]
                    kmer_start = "".join(str(x) for x in working_superpermutation[i:i+k])
                    layout_bonus += layout_memory.get_layout_score(kmer_end, kmer_start, 1)

                # --- Prodigal Bonus ---
                prodigal_bonus = 0
                for p_id, p_data in prodigal_results.items():
                    if candidate_string in p_data.sequence:
                        prodigal_bonus = p_data.length * 200
                        break

                # --- Loser Penalty (Veto) ---
                loser_penalty = 0
                for k in [7, 6]:  # Check 7-mers and 6-mers
                    for j in range(len(candidate_string) - k + 1):
                        kmer = candidate_string[j:j+k]
                        loser_penalty += losers.get(kmer, 0) * 5

                # --- Missing Permutation Bonus (CRUCIAL) ---
                missing_bonus = 0
                if candidate_hash in missing_permutations:
                    missing_bonus = 10000 # Very Large bonus.

                 # Higher-Order Winners/Losers
                higher_order_bonus = 0
                for seq_length in [2, 3]:  # Check sequences of length 2 and 3
                  if len(current_superpermutation) >= (n * seq_length):
                    prev_seq = current_superpermutation[-(n*seq_length):]
                    prev_perms = []
                    for i in range(len(prev_seq) - n + 1):
                        pp = tuple(int(x) for x in prev_seq[i:i+n])
                        if is_valid_permutation(pp, n):
                            prev_perms.append(hash_permutation(pp))
                    if len(prev_perms) >= (seq_length -1):
                        current_seq = tuple(prev_perms[-(seq_length - 1):] + [permutation_hash])
                        current_seq_hash = hash(current_seq)
                        higher_order_bonus += winners.get(current_seq_hash, 0) * 5
                        loser_penalty += losers.get(current_seq_hash, 0) * 5

                score = (overlap * 5) + layout_bonus + golden_ratio_bonus + missing_bonus + prodigal_bonus - loser_penalty - prodigal_disruption + higher_order_bonus

                if score > best_score:
                    best_score = score
                    best_insertion_point = i

        # --- Insertion ---
        if best_insertion_point != -1: #Should always find a spot
            #print(f"Inserting permutation: {unhash_permutation(missing_perm_hash, n)} at position {best_insertion_point}")
            working_superpermutation = working_superpermutation[:best_insertion_point] + list(str(x) for x in missing_perm) + working_superpermutation[best_insertion_point:]
            num_added += 1

            # --- Local Optimization (Swapping) ---
            for j in range(max(0, best_insertion_point - 10), min(len(working_superpermutation) - n, best_insertion_point + n + 10)):
                original_perm = tuple(int(x) for x in working_superpermutation[j:j + n])
                if not is_valid_permutation(original_perm,n):
                    continue
                for k in range(j + 1, min(len(working_superpermutation) - n, best_insertion_point + n * 2 + 10)):
                    compare_perm = tuple(int(x) for x in working_superpermutation[k:k + n])
                    if not is_valid_permutation(compare_perm,n):
                        continue
                    # Calculate overlap before and after swap
                    overlap_before = calculate_overlap("".join(str(x) for x in working_superpermutation[j - n:j]),
                                                     "".join(str(x) for x in original_perm)) + \
                                     calculate_overlap("".join(str(x) for x in original_perm),
                                                     "".join(str(x) for x in working_superpermutation[j + n:j + 2 * n]))

                    overlap_after = calculate_overlap("".join(str(x) for x in working_superpermutation[j - n:j]),
                                                    "".join(str(x) for x in compare_perm)) + \
                                    calculate_overlap("".join(str(x) for x in compare_perm),
                                                    "".join(str(x) for x in working_superpermutation[j + n:j + 2 * n]))

                    if overlap_after > overlap_before:
                        # Perform Swap
                        temp = working_superpermutation[j:j + n]
                        working_superpermutation[j:j + n] = working_superpermutation[k:k + n]
                        working_superpermutation[k:k + n] = temp

            #Update ePUT
            perm_hash = missing_perm_hash
            if perm_hash not in eput: #Should now always be the case.
               eput[perm_hash] = PermutationData(missing_perm, in_sample = False, creation_method="completion")
            eput[perm_hash].used_count = 1
            eput[perm_hash].used_in_final = True
            #Update neighbors in ePUT.  Less important here.
            perm_string = "".join(str(x) for x in missing_perm)
            for k in [n-1, n-2]:
                prefix = "".join(str(x) for x in working_superpermutation[:best_insertion_point + k])
                suffix = "".join(str(x) for x in working_superpermutation[best_insertion_point + len(perm_string)-k:])

                prefix_perms = set()
                suffix_perms = set()
                for i in range(len(prefix) - n + 1):
                    p = tuple(int(x) for x in prefix[i:i+n])
                    if is_valid_permutation(p,n):
                        prefix_perms.add(hash_permutation(p))
                for i in range(len(suffix) - n + 1):
                    p = tuple(int(x) for x in suffix[i:i+n])
                    if is_valid_permutation(p,n):
                        suffix_perms.add(hash_permutation(p))

                for other_perm_hash in prefix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        #Add to layout memory:
                        kmer1 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[-k:])
                        kmer2 = perm_string[:k]
                        layout_memory.update_distances(kmer1,kmer2, len(prefix) - i - k, "n8_completion")
                for other_perm_hash in suffix_perms:
                    if other_perm_hash != perm_hash:
                        eput[perm_hash].neighbors.add(other_perm_hash)
                        kmer1 = perm_string[-k:]
                        kmer2 = "".join(str(x) for x in unhash_permutation(other_perm_hash, n)[:k])
                        layout_memory.update_distances(kmer1, kmer2, 1, "n8_completion")
            #Update Prodigals:
            new_prodigals = analysis_scripts.find_prodigal_results("".join(working_superpermutation), n, min_length=PRODIGAL_MIN_LENGTH, overlap_threshold=PRODIGAL_OVERLAP_THRESHOLD)
            for prodigal_seq in new_prodigals:
                is_new = True
                for existing_prodigal_id, existing_prodigal in prodigal_results.items():
                    if prodigal_seq in existing_prodigal.sequence:
                        is_new = False
                        break
                if is_new:
                    new_id = len(prodigal_results) + 1
                    prodigal_results[new_id] = ProdigalResult(prodigal_seq, new_id)
                    #print(f"New Prodigal Result found in completion: {prodigal_seq}")

        #Remove from missing
        missing_permutations.remove(missing_perm_hash)

        #Adjust Overlap Threshold and Length Threshold - Dynamic Adjustment
        missing_count = len(missing_permutations)
        if (missing_count % 500 == 0):
            print(f"Missing {missing_count} permutations")

    return "".join(working_superpermutation)

```