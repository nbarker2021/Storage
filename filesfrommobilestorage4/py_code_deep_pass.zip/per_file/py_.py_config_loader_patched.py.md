# File: py/.py/config_loader_patched.py

**Extension:** .py

**Lines:** 44 | **Words:** 133

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 1

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: os, yaml

- From-imports: core.cmplx_logger

- Classes (0): (none)

- Functions (1): load_config


---


## Full Source


```text

import os
import yaml
from core.cmplx_logger import log

def load_config(dataset_path=None):
    fallback_path = "configs/default.yaml"
    settings_path = "configs/runtime_settings.yaml"

    # Load primary default config
    config_path = fallback_path
    if dataset_path:
        potential = f"configs/{os.path.basename(dataset_path).replace('.csv', '')}.yaml"
        if os.path.exists(potential):
            config_path = potential

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    log(f"Loaded config from {config_path}: {config}", agent="ConfigLoader", phase="Init")

    # Load runtime settings
    if os.path.exists(settings_path):
        with open(settings_path, "r") as f:
            settings = yaml.safe_load(f)
        config["runtime_settings"] = settings
        log(f"Runtime settings loaded: {settings}", agent="ConfigLoader", phase="Init")
    else:
        config["runtime_settings"] = {
            "paths": {
                "default_config": fallback_path,
                "preset_dir": "presets/",
                "ledger_path": "results/logbook.json",
                "summary_md": "results/summary.md"
            },
            "limits": {
                "max_recovery_depth": 2,
                "max_merge_stall": 3,
                "max_cycles": 100
            }
        }
        log("Default runtime settings used (fallback)", agent="ConfigLoader", phase="Init")

    return config


```