# File: py/.py/sweep_scanner.py

**Extension:** .py

**Lines:** 46 | **Words:** 223

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 1

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math, numpy

- From-imports: typing

- Classes (1): SweepScanner

- Functions (5): __init__, _compute_center, _spiral_score, scan, get_ranked_nodes


---


## Full Source


```text

# sweep_scanner.py
# Golden Ratio inspired scanning engine (non-connecting)

import math
from typing import List, Tuple
import numpy as np

class SweepScanner:
    def __init__(self, cities: List[Tuple[float, float]], passes: int = 4):
        self.cities = cities
        self.n = len(cities)
        self.passes = passes
        self.center = self._compute_center()
        self.phi = (1 + math.sqrt(5)) / 2

    def _compute_center(self) -> Tuple[float, float]:
        x = [c[0] for c in self.cities]
        y = [c[1] for c in self.cities]
        return (sum(x) / self.n, sum(y) / self.n)

    def _spiral_score(self, origin: Tuple[float, float], node: Tuple[float, float], rotation: float) -> float:
        dx, dy = node[0] - origin[0], node[1] - origin[1]
        r = math.hypot(dx, dy)
        angle = math.atan2(dy, dx)
        spiral_angle = r * self.phi
        return abs(angle - (spiral_angle + rotation))

    def scan(self) -> List[Tuple[int, float]]:
        node_scores = [0.0] * self.n
        rotations = [i * (math.pi / self.passes) for i in range(self.passes)]

        for rot in rotations:
            for i, city in enumerate(self.cities):
                score = self._spiral_score(self.center, city, rot)
                node_scores[i] += score

        indexed_scores = list(enumerate(node_scores))
        ranked = sorted(indexed_scores, key=lambda x: x[1])
        return ranked  # Lower score means better fit to GR spiral

    def get_ranked_nodes(self, top_n: int = None) -> List[int]:
        ranked = self.scan()
        if top_n:
            return [i for i, _ in ranked[:top_n]]
        return [i for i, _ in ranked]


```