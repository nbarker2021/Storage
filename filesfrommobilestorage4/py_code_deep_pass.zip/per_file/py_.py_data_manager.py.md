# File: py/.py/data_manager.py

**Extension:** .py

**Lines:** 147 | **Words:** 652

## Keyword Hits

- SFBB: 0

- superperm: 14

- superpermutation: 14

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: csv, json, pickle

- From-imports: (none)

- Classes (0): (none)

- Functions (12): load_known_sp_lengths, save_known_sp_lengths, load_prodigal_data, save_prodigal_data, load_winner_loser_data, save_winner_loser_data, load_layout_memory_data, save_layout_memory_data, save_superpermutation, load_superpermutation, save_anti_laminates, load_anti_laminates


---


## Full Source


```text

# data_manager.py
import csv
import json
import pickle

def load_known_sp_lengths(filename="known_lengths.txt"):
    """Loads known minimal superpermutation lengths from a file.

    Args:
        filename (str): The name of the file to load from.

    Returns:
        dict: A dictionary mapping n values to lengths.
    """
    known_lengths = {}
    try:
        with open(filename, 'r') as f:
            for line in f:
                n, length = map(int, line.strip().split(","))
                known_lengths[n] = length
    except FileNotFoundError:
        print(f"Warning: Known SP lengths file not found: {filename}")
    return known_lengths

def save_known_sp_lengths(known_lengths, filename="known_lengths.txt"):
    """Saves known minimal superpermutation lengths to a file."""
    with open(filename, 'w') as f:
        for n, length in known_lengths.items():
            f.write(f"{n},{length}\n")

def load_prodigal_data(n, filename_prefix="prodigal_results"):
    """Loads prodigal data for a given n from a file.

    Args:
        n: The value of n.
        filename_prefix: The prefix of the filename.

    Returns:
        dict: The prodigal results dictionary.
    """
    filename = f"{filename_prefix}_n{n}.json"  # Use JSON for consistency
    try:
        with open(filename, 'r') as f:
            prodigal_results = json.load(f)
            # Convert keys to integers (JSON stores keys as strings)
            prodigal_results = {int(k): v for k, v in prodigal_results.items()}
            return prodigal_results
    except FileNotFoundError:
        print(f"Warning: Prodigal data file not found: {filename}")
        return {}  # Return an empty dictionary if not found

def save_prodigal_data(prodigal_results, n, filename_prefix="prodigal_results"):
    """Saves prodigal data for a given n to a file."""
    filename = f"{filename_prefix}_n{n}.json"
    with open(filename, 'w') as f:
        # Convert keys to strings before saving (JSON requires string keys)
        prodigal_results_str_keys = {str(k): v for k, v in prodigal_results.items()}
        json.dump(prodigal_results_str_keys, f, indent=4)



def load_winner_loser_data(n, filename_prefix="winners_losers_data"):
    """Loads winner/loser data for a given n from a file."""
    filename = f"{filename_prefix}_n{n}.txt"
    winners_losers = {}
    try:
        with open(filename, 'r') as f:
            for line in f:
                kmer, weight = line.strip().split(",")
                winners_losers[kmer] = float(weight)
    except FileNotFoundError:
        print(f"Warning: Winner/Loser data file not found: {filename}")
    return winners_losers  # Return a single dictionary

def save_winner_loser_data(winners_losers, n, filename_prefix="winners_losers_data"):
    """Saves winner/loser data for a given n to a file."""
    filename = f"{filename_prefix}_n{n}.txt"
    with open(filename, 'w') as f:
        for kmer, weight in winners_losers.items():
            f.write(f"{kmer},{weight}\n")


def load_layout_memory_data(n, filename_prefix="layout_memory"):
    """Loads layout memory data for a given n from a file."""
    filename = f"{filename_prefix}_n{n}.pkl"  # Assuming pickle format
    layout_memory = LayoutMemory()  # Create an instance
    try:
        layout_memory.load_from_file(filename)
    except FileNotFoundError:
        print(f"Warning: Layout memory file not found: {filename}")
        # Return a *new* LayoutMemory object if the file is not found.
    return layout_memory


def save_layout_memory_data(layout_memory, n, filename_prefix="layout_memory"):
    """Saves layout memory data for a given n to a file."""
    filename = f"{filename_prefix}_n{n}.pkl"
    layout_memory.save_to_file(filename)

def save_superpermutation(superpermutation, n, filename_prefix="best_superpermutation"):
    """
    Saves a superpermutation string to a file.

    Args:
        superpermutation (str): superpermutation
        n (int): n value superpermutation is for
        filename_prefix (str): The prefix of the filename.
    """
    filename = f"{filename_prefix}_n{n}.txt"
    with open(filename, "w") as f:
        f.write(superpermutation)

def load_superpermutation(n, filename_prefix="best_superpermutation"):
    """
    Loads the superpermutation string.
    """
    filename = f"{filename_prefix}_n{n}.txt"
    try:
        with open(filename, "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        print("Error: Could not find superpermutation file")
        return ""

#Functions to save and load anti-laminates
def save_anti_laminates(anti_laminates, filename):
    """Saves a list of anti-laminates to a file using pickle."""
    try:
        with open(filename, 'wb') as f:
            pickle.dump(anti_laminates, f)
        logging.debug(f"Anti-laminates saved to {filename}.")
    except Exception as e:
        logging.error(f"Error saving anti-laminates to {filename}: {e}")

def load_anti_laminates(filename):
    """Loads a list of anti-laminates from a file using pickle."""
    try:
        with open(filename, 'rb') as f:
            anti_laminates = pickle.load(f)
        logging.debug(f"Anti-laminates loaded from {filename}.")
        return anti_laminates
    except FileNotFoundError:
        logging.warning(f"Anti-laminates file not found: {filename}.")
        return []  # Return an empty list if the file doesn't exist
    except Exception as e:
        logging.error(f"Error loading anti-laminates from {filename}: {e}")
        return []

```