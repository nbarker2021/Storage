# File: py/.py/agrm_distance_cap.py

**Extension:** .py

**Lines:** 38 | **Words:** 187

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMDistanceCapByShell

- Functions (6): __init__, _compute_center, _compute_shell_thresholds, shell_index, is_within_cap, _dist


---


## Full Source


```text


from typing import Tuple, Dict, List
import math

class AGRMDistanceCapByShell:
    def __init__(self, nodes: Dict[int, Tuple[float, float]], num_shells: int = 5):
        self.nodes = nodes
        self.num_shells = num_shells
        self.center = self._compute_center()
        self.shell_thresholds = self._compute_shell_thresholds()

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def _compute_shell_thresholds(self) -> List[float]:
        distances = [self._dist(self.center, coord) for coord in self.nodes.values()]
        max_d = max(distances)
        return [(i + 1) / self.num_shells * max_d for i in range(self.num_shells)]

    def shell_index(self, node_id: int) -> int:
        dist = self._dist(self.center, self.nodes[node_id])
        for i, threshold in enumerate(self.shell_thresholds):
            if dist <= threshold:
                return i
        return self.num_shells - 1

    def is_within_cap(self, a: int, b: int, multiplier: float = 1.5) -> bool:
        sa = self.shell_index(a)
        sb = self.shell_index(b)
        r = (sa + sb + 2) / (2 * self.num_shells)
        cap = multiplier * r * self.shell_thresholds[-1]
        actual = self._dist(self.nodes[a], self.nodes[b])
        return actual <= cap

    def _dist(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])


```