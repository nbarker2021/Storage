# File: py/.py/cmplx_spiral_retention.py

**Extension:** .py

**Lines:** 27 | **Words:** 135

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMTopXRetainer

- Functions (4): __init__, _compute_center, retain_top_x, _distance


---


## Full Source


```text


from typing import List, Tuple, Dict
import math

class AGRMTopXRetainer:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def retain_top_x(self, path: List[int], x_percent: float = 0.5) -> List[int]:
        if not path:
            return []

        distances = [(node, self._distance(self.nodes[node], self.center)) for node in path]
        distances.sort(key=lambda x: x[1])
        keep_count = max(1, int(len(distances) * x_percent))
        retained_nodes = [node for node, _ in distances[:keep_count]]
        print(f"[TopXRetainer] Retaining top {keep_count}/{len(path)} nodes (closest to center)")
        return retained_nodes

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])


```