# File: py/.py/agrm_complexity_modulator.py

**Extension:** .py

**Lines:** 42 | **Words:** 227

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMComplexityWeightedModulator

- Functions (9): __init__, compute_weights, _angle_between, _normalize, get_high_complexity_nodes, print_summary, vec, dot, mag


---


## Full Source


```text


from typing import Dict, List, Tuple
import math

class AGRMComplexityWeightedModulator:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.weights: Dict[int, float] = {}

    def compute_weights(self, path: List[int]):
        print("[Modulator] Calculating complexity weights per node...")
        self.weights.clear()
        for i in range(1, len(path) - 1):
            a, b, c = self.nodes[path[i - 1]], self.nodes[path[i]], self.nodes[path[i + 1]]
            angle = self._angle_between(a, b, c)
            strain = abs(angle - math.pi)
            self.weights[path[i]] = strain
        self._normalize()

    def _angle_between(self, a: Tuple[float, float], b: Tuple[float, float], c: Tuple[float, float]) -> float:
        def vec(p1, p2): return (p2[0] - p1[0], p2[1] - p1[1])
        def dot(u, v): return u[0]*v[0] + u[1]*v[1]
        def mag(v): return math.hypot(v[0], v[1])

        ba = vec(b, a)
        bc = vec(b, c)
        cosine = dot(ba, bc) / (mag(ba) * mag(bc) + 1e-9)
        return math.acos(max(-1.0, min(1.0, cosine)))

    def _normalize(self):
        max_val = max(self.weights.values(), default=1e-9)
        for k in self.weights:
            self.weights[k] /= max_val

    def get_high_complexity_nodes(self, threshold: float = 0.6) -> List[int]:
        return [nid for nid, w in self.weights.items() if w >= threshold]

    def print_summary(self):
        count = len(self.weights)
        high = len(self.get_high_complexity_nodes())
        print(f"[Modulator] {high}/{count} nodes above complexity threshold.")


```