# File: py/.py/meta_evaluator.py

**Extension:** .py

**Lines:** 65 | **Words:** 286

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: numpy

- From-imports: collections, typing

- Classes (1): MetaEvaluator

- Functions (8): __init__, _compute_center, _assign_quadrants, _classify_density, get_zone, get_quadrant, get_hemisphere, summary


---


## Full Source


```text

# meta_evaluator.py
# Pre-processing logic for AGRM path engine: density zones, quadrants, hemispheres

from typing import List, Tuple, Dict
import numpy as np

class MetaEvaluator:
    def __init__(self, cities: List[Tuple[float, float]]):
        self.cities = cities
        self.n = len(cities)
        self.center = self._compute_center()
        self.grid = self._assign_quadrants()
        self.zones = self._classify_density()

    def _compute_center(self) -> Tuple[float, float]:
        x = [c[0] for c in self.cities]
        y = [c[1] for c in self.cities]
        return (sum(x) / len(x), sum(y) / len(y))

    def _assign_quadrants(self) -> Dict[int, str]:
        cx, cy = self.center
        qmap = {}
        for i, (x, y) in enumerate(self.cities):
            if x >= cx and y >= cy:
                qmap[i] = 'Q1'
            elif x < cx and y >= cy:
                qmap[i] = 'Q2'
            elif x < cx and y < cy:
                qmap[i] = 'Q3'
            else:
                qmap[i] = 'Q4'
        return qmap

    def _classify_density(self) -> Dict[int, str]:
        dist_matrix = np.zeros((self.n, self.n))
        for i in range(self.n):
            for j in range(i+1, self.n):
                d = np.linalg.norm(np.array(self.cities[i]) - np.array(self.cities[j]))
                dist_matrix[i][j] = dist_matrix[j][i] = d

        zone_map = {}
        for i in range(self.n):
            nearest = sorted(dist_matrix[i][j] for j in range(self.n) if j != i)[:6]
            avg = sum(nearest) / len(nearest)
            if avg < 20:
                zone_map[i] = 'dense'
            elif avg < 100:
                zone_map[i] = 'mid'
            else:
                zone_map[i] = 'sparse'
        return zone_map

    def get_zone(self, index: int) -> str:
        return self.zones.get(index, 'unknown')

    def get_quadrant(self, index: int) -> str:
        return self.grid.get(index, 'unknown')

    def get_hemisphere(self, index: int) -> str:
        return 'North' if self.cities[index][1] >= self.center[1] else 'South'

    def summary(self) -> Dict[str, int]:
        from collections import Counter
        return dict(Counter(self.zones.values()))


```