# File: py/.py/config_loader.py

**Extension:** .py

**Lines:** 21 | **Words:** 107

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 1

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: os, yaml

- From-imports: core.cmplx_logger

- Classes (0): (none)

- Functions (1): load_config


---


## Full Source


```text

import os
import yaml
from core.cmplx_logger import log

def load_config(dataset_name, config_dir="configs"):
    basename = os.path.basename(dataset_name).lower()
    if not os.path.exists(config_dir):
        raise FileNotFoundError(f"Config directory '{config_dir}' not found")
    config_files = [f for f in os.listdir(config_dir) if f.endswith(".yaml") or f.endswith(".yml")]
    matched = None
    for f in config_files:
        if any(x in basename for x in f.lower().split(".")):
            matched = os.path.join(config_dir, f)
            break
    if not matched:
        matched = os.path.join(config_dir, "default.yaml")
    with open(matched, 'r') as file:
        config = yaml.safe_load(file)
    log(f"Loaded config from {matched}: {config}", agent="ConfigLoader", phase="Init")
    return config


```