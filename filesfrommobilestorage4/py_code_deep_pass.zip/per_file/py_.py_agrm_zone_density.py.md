# File: py/.py/agrm_zone_density.py

**Extension:** .py

**Lines:** 46 | **Words:** 218

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 1

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: math

- From-imports: typing

- Classes (1): AGRMZoneDensityClassifier

- Functions (6): __init__, _compute_center, _distance, _classify_nodes, shell_density, shell_members


---


## Full Source


```text


from typing import Dict, Tuple, List
import math

class AGRMZoneDensityClassifier:
    def __init__(self, nodes: Dict[int, Tuple[float, float]], num_shells: int = 5):
        self.nodes = nodes
        self.center = self._compute_center()
        self.num_shells = num_shells
        self.shells: List[List[int]] = [[] for _ in range(num_shells)]
        self.shell_stats: List[Dict] = [{} for _ in range(num_shells)]
        self._classify_nodes()

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])

    def _classify_nodes(self):
        distances = [(nid, self._distance(coord, self.center)) for nid, coord in self.nodes.items()]
        max_d = max(d for _, d in distances) + 1e-9

        for nid, dist in distances:
            shell_idx = min(int((dist / max_d) * self.num_shells), self.num_shells - 1)
            self.shells[shell_idx].append(nid)

        for i, shell in enumerate(self.shells):
            self.shell_stats[i] = {
                "count": len(shell),
                "saturation": len(shell) / len(self.nodes),
                "radius_min": 0 if i == 0 else (i / self.num_shells) * max_d,
                "radius_max": ((i + 1) / self.num_shells) * max_d
            }

    def shell_density(self, shell_index: int) -> float:
        if 0 <= shell_index < self.num_shells:
            return self.shell_stats[shell_index].get("saturation", 0.0)
        return 0.0

    def shell_members(self, shell_index: int) -> List[int]:
        if 0 <= shell_index < self.num_shells:
            return self.shells[shell_index]
        return []


```