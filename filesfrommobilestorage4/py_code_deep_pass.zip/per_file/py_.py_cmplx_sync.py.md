# File: py/.py/cmplx_sync.py

**Extension:** .py

**Lines:** 55 | **Words:** 175

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 3

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: argparse, os, shutil

- From-imports: pathlib

- Classes (0): (none)

- Functions (2): infer_target_subdir, main


---


## Full Source


```text


import os
import shutil
from pathlib import Path

# CONFIGURATION
SOURCE_DIR = Path(r"D:\dls\gptdownloads")
TARGET_DIR = Path(r"D:\Git\CMPLX\cmplx-core")

# Mapping of file name patterns to subdirectories
ROUTE_MAP = {
    "cli": "cli",
    "core": "core",
    "plans": "plans",
    "agents": "agents",
    "audit": "audit",
    "backups": "backups",
    "guidance": "guidance",
    "reflexes": "reflexes",
    "GTG": "guidance/GTG",
    "meta": "meta_docs"
}

def infer_target_subdir(filename):
    for key, subdir in ROUTE_MAP.items():
        if key.lower() in filename.lower():
            return TARGET_DIR / subdir
    return TARGET_DIR / "misc"

def main(dry_run=True):
    print(f"{'DRY RUN' if dry_run else 'EXECUTING'} SYNC FROM:")
    print(f"  Source: {SOURCE_DIR}")
    print(f"  Target: {TARGET_DIR}")
    print("-" * 40)

    for file in SOURCE_DIR.glob("*"):
        if file.is_file():
            target_subdir = infer_target_subdir(file.name)
            target_subdir.mkdir(parents=True, exist_ok=True)
            destination = target_subdir / file.name

            print(f"{'[DRY]' if dry_run else '[MOVE]'} {file.name} → {destination}")
            if not dry_run:
                shutil.copy2(file, destination)

    print("-" * 40)
    print("Sync complete.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="CMPLX File Sync Utility")
    parser.add_argument("--commit", action="store_true", help="Actually move the files (otherwise dry run)")
    args = parser.parse_args()
    main(dry_run=not args.commit)


```