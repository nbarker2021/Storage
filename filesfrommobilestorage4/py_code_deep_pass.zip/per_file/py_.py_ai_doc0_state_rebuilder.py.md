# File: py/.py/ai_doc0_state_rebuilder.py

**Extension:** .py

**Lines:** 56 | **Words:** 194

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: argparse, datetime, json

- From-imports: pathlib

- Classes (0): (none)

- Functions (2): load_json, main


---


## Full Source


```text


import argparse
import json
from pathlib import Path
import datetime

# CONFIG
RAC_FILE = Path("reflexes/rac_doc_0.json")
SNAP_FILE = Path("snapshots/snaps/snap_doc_0.json")
SONG_FILE = Path("snapshots/songs/song_doc_0.json")
MOVIE_FILE = Path("snapshots/movies/movie_doc_0.json")
OUTPUT_LOG = Path("logs/ai_state_rebuild_log.txt")

def load_json(path):
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def main(verbose=False):
    timestamp = datetime.datetime.now().isoformat()
    rac = load_json(RAC_FILE)
    snap = load_json(SNAP_FILE)
    song = load_json(SONG_FILE)
    movie = load_json(MOVIE_FILE)

    print(f"🧪 Rebuilding internal state from doc_0...")
    if verbose:
        print(f"⏱ Timestamp: {timestamp}")
        print(f"📁 RAC loaded: {bool(rac)}")
        print(f"📸 Snap loaded: {bool(snap)}")
        print(f"🎵 Song loaded: {bool(song)}")
        print(f"🎬 Movie loaded: {bool(movie)}")

    log = {
        "timestamp": timestamp,
        "rac_state_loaded": bool(rac),
        "snap_state_loaded": bool(snap),
        "song_trace_loaded": bool(song),
        "movie_replay_loaded": bool(movie),
        "status": "success" if rac and snap else "partial or incomplete"
    }

    OUTPUT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_LOG, 'a') as log_file:
        log_file.write(json.dumps(log) + '\n')

    print("✅ Internal AI state rebuild test complete.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI System Rebuilder from doc_0")
    parser.add_argument('--verbose', action='store_true', help="Print full load report")
    args = parser.parse_args()
    main(verbose=args.verbose)


```