# File: py/.py/cmplx_cli_all.py

**Extension:** .py

**Lines:** 27 | **Words:** 113

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 2

- MDHG: 0

- CMPLX: 3

- E8: 0

- LSDT: 0

- TSP: 1

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: os, pandas

- From-imports: core.cmplx_logger, core.cmplx_runtime_controller, systems.top_layer_controller

- Classes (0): (none)

- Functions (1): run_all_tests


---


## Full Source


```text

import os
import pandas as pd
from systems.top_layer_controller import register_agents
from core.cmplx_runtime_controller import AGRMRuntimeController
from core.cmplx_logger import log

def run_all_tests(dataset_root="datasets"):
    controller = register_agents()

    for dirpath, _, filenames in os.walk(dataset_root):
        for file in filenames:
            if file.endswith(".tsp") or file.endswith(".csv"):
                fpath = os.path.join(dirpath, file)
                log(f"Running CMPLX test on {file}", agent="CLI", phase="Batch")
                try:
                    df = pd.read_csv(fpath)
                    nodes = {int(row['id']): (row['x'], row['y']) for _, row in df.iterrows()}

                    runtime = AGRMRuntimeController(nodes)
                    for _ in range(100):
                        if runtime.run_cycle():
                            break
                except Exception as e:
                    log(f"FAILED on {file}: {e}", agent="CLI", phase="Error")

if __name__ == "__main__":
    run_all_tests()

```