# File: py/.py/register_agents.py

**Extension:** .py

**Lines:** 58 | **Words:** 193

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: agents.audit, agents.builder, agents.clerk, agents.foreman, agents.janitor, agents.teacher, agents.validator, core.patch_engine, patch_strategies.default_patch, patch_strategies.vector_prune

- Classes (1): AgentManager

- Functions (7): register_agents, __init__, register, inject_agent, get_agent, step_all, replace_from_strategy


---


## Full Source


```text

from agents.builder import BuilderAgent
from agents.validator import ValidatorAgent
from agents.audit import AuditAgent
from agents.foreman import ForemanAgent
from agents.teacher import TeacherAgent
from agents.clerk import ClerkAgent
from agents.janitor import JanitorAgent

class AgentManager:
    def __init__(self):
        self.agents = {}
        self.execution_order = []

    def register(self, name, agent):
        self.agents[name] = agent
        self.execution_order.append(name)

    def inject_agent(self, name, agent):
        self.agents[name] = agent
        if name not in self.execution_order:
            self.execution_order.append(name)

    def get_agent(self, name):
        return self.agents.get(name, None)

    def step_all(self, state):
        for name in self.execution_order:
            agent = self.agents.get(name)
            if agent and hasattr(agent, 'step'):
                agent.step(state)

    def replace_from_strategy(self, agent_map):
        from agents.validator import RobustValidator
        from core.patch_engine import PatchEngine
        from patch_strategies.default_patch import DefaultPatchStrategy
        from patch_strategies.vector_prune import VectorPrunePatchStrategy

        strategy_map = {
            "robust_validator": RobustValidator,
            "default_patch": lambda: PatchEngine(DefaultPatchStrategy()),
            "vector_prune": lambda: PatchEngine(VectorPrunePatchStrategy())
        }

        for name, key in agent_map.items():
            if key in strategy_map:
                self.inject_agent(name, strategy_map[key]())

def register_agents():
    mgr = AgentManager()
    mgr.register("builder", BuilderAgent())
    mgr.register("validator", ValidatorAgent())
    mgr.register("audit", AuditAgent())
    mgr.register("foreman", ForemanAgent())
    mgr.register("teacher", TeacherAgent())
    mgr.register("clerk", ClerkAgent())
    mgr.register("janitor", JanitorAgent())
    return mgr


```