# File: py/.py/testlab_safe.py

**Extension:** .py

**Lines:** 58 | **Words:** 217

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 0

- MDHG: 0

- CMPLX: 4

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: json, os, random, yaml

- From-imports: cli.cmplx_run, core.cmplx_logger

- Classes (1): TestLabAgent

- Functions (4): __init__, score_result, run_variant_tests, run_single_test


---


## Full Source


```text

import os
import json
import yaml
import random
from core.cmplx_logger import log

class TestLabAgent:
    def __init__(self, planner, dataset_path):
        self.planner = planner
        self.dataset_path = dataset_path
        self.attempts_log = []

    def score_result(self, audit):
        score = 0
        if audit.get("final_status") == "complete":
            score += 100
        score -= audit.get("merge_stall_events", 0) * 2
        score -= int(audit.get("entropy", 0.5) * 100)
        return score

    def run_variant_tests(self, base_plan, sweep_count=5):
        variants = []
        for _ in range(sweep_count):
            entropy = max(0.3, round(base_plan["modulator"]["entropy_collapse_threshold"] + random.uniform(-0.05, 0.05), 2))
            stall = max(1, min(6, base_plan["builder"]["max_merge_stall"] + random.randint(-1, 1)))
            cycles = max(50, min(200, base_plan["controller"]["max_cycles"] + random.randint(-10, 10)))

            plan = {
                "builder": {"max_merge_stall": stall},
                "modulator": {"entropy_collapse_threshold": entropy},
                "controller": {"max_cycles": cycles}
            }

            score = self.run_single_test(plan, current_depth=0)
            variants.append((score, plan))

        variants.sort(reverse=True, key=lambda x: x[0])
        best_score, best_plan = variants[0]
        self.attempts_log = variants
        return best_score >= 50, best_plan

    def run_single_test(self, plan, current_depth=0):
        from cli.cmplx_run import run_cmplx_cli

        temp_plan = "plans/tmp/testlab_plan.yaml"
        os.makedirs(os.path.dirname(temp_plan), exist_ok=True)
        with open(temp_plan, "w") as f:
            yaml.safe_dump(plan, f)

        run_cmplx_cli(self.dataset_path, plan_mode=temp_plan, save_audit=True, recovery_depth=current_depth + 1)

        temp_audit = "results/audit_result.json"
        if os.path.exists(temp_audit):
            with open(temp_audit, "r") as f:
                audit = json.load(f)
                return self.score_result(audit)
        return -100


```