# File: py/.py/formula_evaluator.py

**Extension:** .py

**Lines:** 142 | **Words:** 605

## Keyword Hits

- SFBB: 0

- superperm: 8

- superpermutation: 6

- AGRM: 0

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: True

- Module docstring (first 600 chars): 

- Imports: formulas, math

- From-imports: analysis_scripts_final, utils

- Classes (0): (none)

- Functions (4): evaluate_sp_formula, evaluate_segment_formula, evaluate_action_formula, compare_formulas


---


## Full Source


```text

# formula_evaluator.py

import formulas
import math
from utils import generate_permutations, is_valid_permutation, calculate_overlap
from analysis_scripts_final import find_prodigal_results
# Assuming you have a way to load known minimal superpermutation lengths, e.g.:
#KNOWN_MINIMAL_LENGTHS = {1: 1, 2: 3, 3: 9, 4: 33, 5: 153, 6: 872, 7: 5906}  # Update as needed
KNOWN_MINIMAL_LENGTHS = {1: 1, 2: 3, 3: 9, 4: 33, 5: 153, 6: 872, 7: 5906} #Updated with knowns.
def evaluate_sp_formula(formula_name, n_values, known_values):
    """Evaluates a superpermutation length formula.

    Args:
        formula_name (str): The name of the formula function in formulas.py.
        n_values (list): A list of n values to test.
        known_values (dict): A dictionary mapping n values to known minimal lengths.

    Returns:
        dict: A dictionary containing the results: predicted lengths, actual lengths, and errors.
    """

    results = {"predicted": [], "actual": [], "errors": [], "mse": 0, "mae": 0}
    formula_func = getattr(formulas, formula_name) # Get function from formulas.py
    total_squared_error = 0
    total_absolute_error = 0
    num_values = 0

    for n in n_values:
        if n not in known_values:
          continue #If no known value, skip.
        
        #Handle the different numbers of arguments for different formulas.
        if formula_name.startswith("sp_"): # Superpermutation length formula
          if formula_name in ['sp_lower_bound']:
            predicted = formula_func(n) # Lower bound takes only n
          elif formula_name in ['sp_v14', 'sp_additive', 'sp_v15']:
            if n-1 not in known_values:
              continue #Cant use it yet
            predicted = formula_func(n, known_values[n-1]) #Need previous value and n.
          else: #Unknown formula
            continue #Skip

        elif formula_name.startswith("c_n"):
          predicted = formula_func(n) #Should take just n
        elif formula_name.startswith("segment_length"):
          predicted = formula_func(n) #Likely just uses n.
        #Add other formula types here, like action functions.
        else:
          continue #unknown, skip

        actual = known_values[n]
        error = predicted - actual


        results["predicted"].append(predicted)
        results["actual"].append(actual)
        results["errors"].append(error)

        total_squared_error += error**2
        total_absolute_error += abs(error)
        num_values += 1

    if num_values > 0:
        results["mse"] = total_squared_error / num_values
        results["mae"] = total_absolute_error / num_values
    else:
        results["mse"] = None
        results["mae"] = None

    return results

def evaluate_segment_formula(formula_name, n_values, prodigal_data):
    """Evaluates a segment length formula.
    prodigal_data format:  {n: [list_of_prodigal_lengths]}
    """
    results = {"predicted": [], "actual_avg": [], "actual_median": [], "errors_avg": [], "errors_median": []}
    formula_func = getattr(formulas, formula_name)

    for n in n_values:
        if n not in prodigal_data:
            continue

        predicted = formula_func(n) #Call the function.
        results["predicted"].append(predicted)

        actual_lengths = prodigal_data[n]
        if len(actual_lengths) > 0:
          avg_length = sum(actual_lengths) / len(actual_lengths)
          median_length = sorted(actual_lengths)[len(actual_lengths) // 2]
          results["actual_avg"].append(avg_length)
          results["actual_median"].append(median_length)
          results["errors_avg"].append(predicted - avg_length)
          results["errors_median"].append(predicted - median_length)
        else:
          results["actual_avg"].append(None)
          results["actual_median"].append(None)
          results["errors_avg"].append(None)
          results["errors_median"].append(None)

    return results

def evaluate_action_formula(formula_name, superpermutations, n):
    """Evaluates an action function formula."""
    results = {"actions": []}
    formula_func = getattr(formulas, formula_name)
    for superperm in superpermutations:
        action = formula_func(superperm, n) # Call with superpermutation
        results["actions"].append(action)
    return results
    # Add more analysis as needed (average action, etc.)

def compare_formulas(formula_names, n_values, known_values, prodigal_data):
    """Compares multiple formulas based on different metrics."""
    results = {}
    for formula_name in formula_names:
        if formula_name.startswith("sp_"):
            results[formula_name] = evaluate_sp_formula(formula_name, n_values, known_values)
        elif formula_name.startswith("segment_length"):
            results[formula_name] = evaluate_segment_formula(formula_name, n_values, prodigal_data)
        # Add other formula types here
    return results

# Example Usage (within formula_evaluator.py or a separate script)
if __name__ == '__main__':
  #This is where we would run tests.
  #Example data (replace with actual data loading)
  known_lengths = {1: 1, 2: 3, 3: 9, 4: 33, 5: 153, 6: 872, 7: 5906}
  prodigal_lengths = {
    5: [10, 12, 11, 13, 10],  # Example prodigal lengths for n=5
    6: [25, 28, 22, 26, 30, 25, 27],  # Example for n=6
    7: [45, 52, 48, 55, 49, 51, 47]  # Example for n=7
  }
  #Example test
  sp_formula_results = evaluate_sp_formula("sp_v14", [5, 6, 7], known_lengths)
  print("SP Formula Evaluation (sp_v14):", sp_formula_results)

  segment_formula_results = evaluate_segment_formula("segment_length_v5", [5,6,7], prodigal_lengths)
  print("Segment Formula Evaluation (segment_length_v5):", segment_formula_results)

  #Example comparison:
  comparison_results = compare_formulas(["sp_lower_bound", "sp_v14", "sp_additive"], [5, 6, 7], known_lengths, {})
  print("Formula Comparison:", comparison_results)

```