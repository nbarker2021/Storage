# File: py/.py/cmplx_core_loop.py

**Extension:** .py

**Lines:** 56 | **Words:** 235

## Keyword Hits

- SFBB: 0

- superperm: 0

- superpermutation: 0

- AGRM: 20

- MDHG: 0

- CMPLX: 0

- E8: 0

- LSDT: 0

- TSP: 0

- de bruijn: 0

- debruijn: 0

- beam: 0

- orchestrator: 0

- hash: 0

- golden: 0

- glyph: 0

- lattice: 0

## Python Analysis

- __main__ present: False

- Module docstring (first 600 chars): 

- Imports: (none)

- From-imports: agrm_modulation_and_legalgraph, agrm_pathbuilder_dual, agrm_salesman_patch, agrm_spiral_reentry, typing

- Classes (1): AGRMCoreLoopController

- Functions (4): __init__, evaluate_path, _dist, run


---


## Full Source


```text


from typing import Dict, Tuple, List
from agrm_modulation_and_legalgraph import AGRMLegalGraph, AGRMModulationController
from agrm_pathbuilder_dual import AGRMPathBuilderDual
from agrm_spiral_reentry import AGRMSpiralReentryEngine
from agrm_salesman_patch import AGRMSalesmanPatchEngine

class AGRMCoreLoopController:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.legal = AGRMLegalGraph(nodes)
        self.mod = AGRMModulationController(nodes)
        self.builder = AGRMPathBuilderDual(nodes)
        self.reentry = AGRMSpiralReentryEngine(nodes)
        self.patcher = AGRMSalesmanPatchEngine(nodes)
        self.history: List[List[int]] = []
        self.best_path: List[int] = []
        self.best_cost: float = float("inf")

    def evaluate_path(self, path: List[int]) -> float:
        return sum(
            self._dist(self.nodes[a], self.nodes[b])
            for a, b in zip(path, path[1:] + [path[0]])
        )

    def _dist(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return ((a[0] - b[0])**2 + (a[1] - b[1])**2) ** 0.5

    def run(self, cycles: int = 100):
        for i in range(cycles):
            print(f"\n[AGRM CoreLoop] Cycle {i+1}")
            path = self.builder.build_path(forward=(i % 2 == 0))

            entropy = self.mod.analyze_entropy(path)
            print(f"[AGRM] Entropy: {entropy:.4f}")
            if entropy > 0.3:
                self.mod.mark_shell_failure()

            cost = self.evaluate_path(path)
            if cost < self.best_cost:
                self.best_cost = cost
                self.best_path = path
                print(f"[AGRM] New best path! Length: {cost:.3f}")

            if self.mod.dynamic_unlock_trigger:
                print("[AGRM] Triggering fallback reentry strategy...")
                reentry_path = self.reentry.generate_fallback_path(path[0])
                cost = self.evaluate_path(reentry_path)
                if cost < self.best_cost:
                    self.best_path = reentry_path
                    self.best_cost = cost
                    print("[AGRM] Reentry path accepted.")

            self.history.append(path)
        return self.best_path, self.best_cost


```