# py.zip — Code Deep Pass (Full-Content)

_Each source summarized with metrics and Python symbols. Full source texts in per_file/._


---
## py/.py/AGRM.py
- Ext: **.py** | Lines: **2559** | Words: **13005**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 51
- MDHG: 77
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 4
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 144
- golden: 12
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 9
- Functions: 95
- Imports: math, numpy, random, time
- From-imports: collections, sklearn.neighbors, typing

---
## py/.py/CMPLX.py
- Ext: **.py** | Lines: **2558** | Words: **13029**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 54
- MDHG: 77
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 4
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 144
- golden: 12
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/Candidate Generation and Scoring.py
- Ext: **.py** | Lines: **111** | Words: **473**
### Keyword hits
- SFBB: 0
- superperm: 10
- superpermutation: 10
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 38
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 2
- Imports: json, logging, random
- From-imports: analysis_scripts_final, layout_memory, utils

---
## py/.py/Experiment_Specific_Script.py
- Ext: **.py** | Lines: **68** | Words: **209**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: pandas
- From-imports: (none)

---
## py/.py/Hash.py
- Ext: **.py** | Lines: **1727** | Words: **5955**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 2
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 125
- golden: 14
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/Hash_testsuite.py
- Ext: **.py** | Lines: **472** | Words: **1601**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 13
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 103
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 1
- Functions: 14
- Imports: matplotlib.pyplot, numpy, random, time
- From-imports: typing

---
## py/.py/Layout Memory and Data Persistence.py
- Ext: **.py** | Lines: **191** | Words: **686**
### Keyword hits
- SFBB: 0
- superperm: 23
- superpermutation: 23
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 5
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_adaptive_builder.py
- Ext: **.py** | Lines: **48** | Words: **174**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: agrm_modulation_and_legalgraph, typing

---
## py/.py/agrm_cli_allrun (1).py
- Ext: **.py** | Lines: **68** | Words: **215**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 14
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 5
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 3
- Imports: argparse, os, subprocess
- From-imports: agrm_profiler_diagnostics, agrm_results_export, agrm_runtime_controller, tsp_node_loader

---
## py/.py/agrm_cli_allrun.py
- Ext: **.py** | Lines: **115** | Words: **366**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 17
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 12
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 1
- Functions: 7
- Imports: argparse, os, requests, subprocess
- From-imports: agrm_profiler_diagnostics, agrm_results_export, agrm_runtime_controller, tsp_node_loader

---
## py/.py/agrm_cli_launcher (1).py
- Ext: **.py** | Lines: **3** | Words: **22**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_cli_launcher (2).py
- Ext: **.py** | Lines: **130** | Words: **451**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 19
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 19
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 1
- Functions: 7
- Imports: argparse, os, requests, subprocess
- From-imports: agrm_profiler_diagnostics, agrm_results_export, agrm_runtime_controller, tsp_node_loader

---
## py/.py/agrm_cli_launcher (3).py
- Ext: **.py** | Lines: **51** | Words: **177**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 9
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 4
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 1
- Imports: argparse, json, os
- From-imports: agrm_results_export, agrm_runtime_controller, tsp_node_loader

---
## py/.py/agrm_cli_launcher.py
- Ext: **.py** | Lines: **3** | Words: **22**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_complexity_modulator.py
- Ext: **.py** | Lines: **42** | Words: **227**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 9
- Imports: math
- From-imports: typing

---
## py/.py/agrm_core_loop.py
- Ext: **.py** | Lines: **56** | Words: **235**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 20
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: (none)
- From-imports: agrm_modulation_and_legalgraph, agrm_pathbuilder_dual, agrm_salesman_patch, agrm_spiral_reentry, typing

---
## py/.py/agrm_diagnostics (1).py
- Ext: **.py** | Lines: **70** | Words: **246**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_diagnostics.py
- Ext: **.py** | Lines: **58** | Words: **199**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 8
- Imports: time
- From-imports: collections

---
## py/.py/agrm_distance_cap.py
- Ext: **.py** | Lines: **38** | Words: **187**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: math
- From-imports: typing

---
## py/.py/agrm_dynamic_midpoint.py
- Ext: **.py** | Lines: **29** | Words: **137**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/agrm_feedback_bus.py
- Ext: **.py** | Lines: **32** | Words: **104**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: (none)
- From-imports: collections

---
## py/.py/agrm_modulation_and_legalgraph (1).py
- Ext: **.py** | Lines: **70** | Words: **337**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 14
- Imports: math
- From-imports: typing

---
## py/.py/agrm_modulation_and_legalgraph.py
- Ext: **.py** | Lines: **63** | Words: **311**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 14
- Imports: math
- From-imports: typing

---
## py/.py/agrm_modulation_brain (1).py
- Ext: **.py** | Lines: **80** | Words: **385**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_modulation_brain.py
- Ext: **.py** | Lines: **75** | Words: **356**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 11
- Imports: math
- From-imports: typing

---
## py/.py/agrm_path_engine.py
- Ext: **.py** | Lines: **83** | Words: **331**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: math, random
- From-imports: typing

---
## py/.py/agrm_pathbuilder_dual (1).py
- Ext: **.py** | Lines: **49** | Words: **178**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: random
- From-imports: agrm_modulation_and_legalgraph, typing

---
## py/.py/agrm_pathbuilder_dual.py
- Ext: **.py** | Lines: **43** | Words: **159**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: random
- From-imports: agrm_modulation_and_legalgraph, typing

---
## py/.py/agrm_phase_reverse_builder.py
- Ext: **.py** | Lines: **59** | Words: **235**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: math
- From-imports: typing

---
## py/.py/agrm_profiler_diagnostics (1).py
- Ext: **.py** | Lines: **63** | Words: **174**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 10
- Imports: time
- From-imports: typing

---
## py/.py/agrm_profiler_diagnostics.py
- Ext: **.py** | Lines: **62** | Words: **174**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 10
- Imports: time
- From-imports: typing

---
## py/.py/agrm_quadrant_legality.py
- Ext: **.py** | Lines: **33** | Words: **148**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: (none)
- From-imports: typing

---
## py/.py/agrm_results_export (1).py
- Ext: **.py** | Lines: **44** | Words: **219**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 6
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: csv, json, matplotlib.pyplot
- From-imports: typing

---
## py/.py/agrm_results_export.py
- Ext: **.py** | Lines: **43** | Words: **219**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 6
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: csv, json, matplotlib.pyplot
- From-imports: typing

---
## py/.py/agrm_runtime_controller (1).py
- Ext: **.py** | Lines: **68** | Words: **208**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 6
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 5
- Imports: (none)
- From-imports: navigator_and_builder, salesman_and_evaluator

---
## py/.py/agrm_runtime_controller (2).py
- Ext: **.py** | Lines: **91** | Words: **307**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 30
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: (none)
- From-imports: agrm_complexity_modulator, agrm_diagnostics, agrm_dynamic_midpoint, agrm_modulation_and_legalgraph, agrm_pathbuilder_dual, agrm_salesman_patch, agrm_spiral_reentry, agrm_spiral_retention, agrm_zone_collapse

---
## py/.py/agrm_runtime_controller (3).py
- Ext: **.py** | Lines: **92** | Words: **310**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 31
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: (none)
- From-imports: agrm_complexity_modulator, agrm_diagnostics, agrm_dynamic_midpoint, agrm_modulation_and_legalgraph, agrm_pathbuilder_dual, agrm_salesman_patch, agrm_spiral_reentry, agrm_spiral_retention, agrm_zone_collapse

---
## py/.py/agrm_runtime_controller (4).py
- Ext: **.py** | Lines: **92** | Words: **316**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 31
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: (none)
- From-imports: agrm_adaptive_builder, agrm_complexity_modulator, agrm_diagnostics, agrm_dynamic_midpoint, agrm_modulation_and_legalgraph, agrm_salesman_patch, agrm_spiral_reentry, agrm_spiral_retention, agrm_zone_collapse

---
## py/.py/agrm_runtime_controller.py
- Ext: **.py** | Lines: **81** | Words: **269**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 5
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 4
- Functions: 12
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_salesman_patch (1).py
- Ext: **.py** | Lines: **49** | Words: **196**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/agrm_salesman_patch.py
- Ext: **.py** | Lines: **35** | Words: **144**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/agrm_spiral_reentry.py
- Ext: **.py** | Lines: **27** | Words: **120**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/agrm_spiral_retention.py
- Ext: **.py** | Lines: **27** | Words: **135**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/agrm_zone_collapse.py
- Ext: **.py** | Lines: **41** | Words: **199**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: math
- From-imports: typing

---
## py/.py/agrm_zone_density.py
- Ext: **.py** | Lines: **46** | Words: **218**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: math
- From-imports: typing

---
## py/.py/ai_doc0_state_rebuilder.py
- Ext: **.py** | Lines: **56** | Words: **194**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 2
- Imports: argparse, datetime, json
- From-imports: pathlib

---
## py/.py/analysis_scripts.py
- Ext: **.py** | Lines: **568** | Words: **2797**
### Keyword hits
- SFBB: 0
- superperm: 64
- superpermutation: 56
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 6
- debruijn: 6
- beam: 0
- orchestrator: 0
- hash: 33
- golden: 3
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/analysis_scripts_2.0.py
- Ext: **.py** | Lines: **681** | Words: **3035**
### Keyword hits
- SFBB: 0
- superperm: 76
- superpermutation: 56
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 8
- debruijn: 2
- beam: 0
- orchestrator: 0
- hash: 46
- golden: 4
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/analysis_scripts_final.py
- Ext: **.py** | Lines: **657** | Words: **3014**
### Keyword hits
- SFBB: 0
- superperm: 67
- superpermutation: 59
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 8
- debruijn: 2
- beam: 0
- orchestrator: 0
- hash: 43
- golden: 4
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 22
- Imports: heapq, itertools, math, networkx, random
- From-imports: collections

---
## py/.py/audit_output.py
- Ext: **.py** | Lines: **16** | Words: **73**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: json, os
- From-imports: core.cmplx_logger

---
## py/.py/benchmark_suite (1).py
- Ext: **.py** | Lines: **35** | Words: **123**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 6
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 5
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 1
- Imports: time
- From-imports: mdhg_hash

---
## py/.py/benchmark_suite.py
- Ext: **.py** | Lines: **9** | Words: **40**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 1
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 2
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/cmplx_adaptive_builder.py
- Ext: **.py** | Lines: **48** | Words: **174**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: agrm_modulation_and_legalgraph, typing

---
## py/.py/cmplx_anchor_reset.py
- Ext: **.py** | Lines: **34** | Words: **141**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 3
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_cli_all.py
- Ext: **.py** | Lines: **27** | Words: **113**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 3
- E8: 0
- LSDT: 0
- TSP: 1
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 1
- Imports: os, pandas
- From-imports: core.cmplx_logger, core.cmplx_runtime_controller, systems.top_layer_controller

---
## py/.py/cmplx_cli_allrun.py
- Ext: **.py** | Lines: **68** | Words: **215**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 14
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 5
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 3
- Imports: argparse, os, subprocess
- From-imports: agrm_profiler_diagnostics, agrm_results_export, agrm_runtime_controller, tsp_node_loader

---
## py/.py/cmplx_cli_launcher.py
- Ext: **.py** | Lines: **51** | Words: **177**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 9
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 4
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 1
- Imports: argparse, json, os
- From-imports: agrm_results_export, agrm_runtime_controller, tsp_node_loader

---
## py/.py/cmplx_cli_selective.py
- Ext: **.py** | Lines: **39** | Words: **149**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 3
- E8: 0
- LSDT: 0
- TSP: 5
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 2
- Imports: os, pandas
- From-imports: core.cmplx_logger, core.cmplx_runtime_controller, systems.top_layer_controller

---
## py/.py/cmplx_complexity_modulator.py
- Ext: **.py** | Lines: **42** | Words: **227**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 9
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_core.py
- Ext: **.py** | Lines: **51** | Words: **162**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_core_loop.py
- Ext: **.py** | Lines: **56** | Words: **235**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 20
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: (none)
- From-imports: agrm_modulation_and_legalgraph, agrm_pathbuilder_dual, agrm_salesman_patch, agrm_spiral_reentry, typing

---
## py/.py/cmplx_diagnostics.py
- Ext: **.py** | Lines: **72** | Words: **257**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/cmplx_distance_cap.py
- Ext: **.py** | Lines: **38** | Words: **187**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_dynamic_midpoint.py
- Ext: **.py** | Lines: **29** | Words: **137**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_feedback_bus.py
- Ext: **.py** | Lines: **32** | Words: **104**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: (none)
- From-imports: collections

---
## py/.py/cmplx_logger.py
- Ext: **.py** | Lines: **14** | Words: **50**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: datetime, os
- From-imports: (none)

---
## py/.py/cmplx_modulation_and_legalgraph.py
- Ext: **.py** | Lines: **70** | Words: **337**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 14
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_modulation_brain.py
- Ext: **.py** | Lines: **80** | Words: **385**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 12
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_path_engine.py
- Ext: **.py** | Lines: **83** | Words: **331**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 3
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: math, random
- From-imports: typing

---
## py/.py/cmplx_pathbuilder_dual.py
- Ext: **.py** | Lines: **63** | Words: **219**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 6
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 7
- Imports: random
- From-imports: agrm_logger, agrm_modulation_and_legalgraph, typing

---
## py/.py/cmplx_phase_reverse_builder.py
- Ext: **.py** | Lines: **59** | Words: **235**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_profiler_diagnostics.py
- Ext: **.py** | Lines: **63** | Words: **174**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 10
- Imports: time
- From-imports: typing

---
## py/.py/cmplx_quadrant_legality.py
- Ext: **.py** | Lines: **33** | Words: **148**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: (none)
- From-imports: typing

---
## py/.py/cmplx_results_export.py
- Ext: **.py** | Lines: **44** | Words: **219**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 6
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: csv, json, matplotlib.pyplot
- From-imports: typing

---
## py/.py/cmplx_run.py
- Ext: **.py** | Lines: **46** | Words: **168**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 2
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, pandas, yaml
- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

---
## py/.py/cmplx_run_final (1).py
- Ext: **.py** | Lines: **51** | Words: **191**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 2
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, pandas, yaml
- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

---
## py/.py/cmplx_run_final.py
- Ext: **.py** | Lines: **51** | Words: **191**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 2
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, pandas, yaml
- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

---
## py/.py/cmplx_run_post_teach.py
- Ext: **.py** | Lines: **59** | Words: **217**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 2
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, pandas, yaml
- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

---
## py/.py/cmplx_run_runtime_patched.py
- Ext: **.py** | Lines: **54** | Words: **202**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 2
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, pandas, yaml
- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

---
## py/.py/cmplx_run_safe.py
- Ext: **.py** | Lines: **52** | Words: **197**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 2
- MDHG: 0
- CMPLX: 2
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, pandas, yaml
- From-imports: agents.register_agents, core.audit_output, core.cmplx_logger, core.config_loader, core.runtime_controller, plans.learning_plan_manager

---
## py/.py/cmplx_runtime_controller.py
- Ext: **.py** | Lines: **92** | Words: **316**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 31
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: (none)
- From-imports: agrm_adaptive_builder, agrm_complexity_modulator, agrm_diagnostics, agrm_dynamic_midpoint, agrm_modulation_and_legalgraph, agrm_salesman_patch, agrm_spiral_reentry, agrm_spiral_retention, agrm_zone_collapse

---
## py/.py/cmplx_salesman_patch.py
- Ext: **.py** | Lines: **67** | Words: **257**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 4
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/cmplx_spiral_reentry.py
- Ext: **.py** | Lines: **27** | Words: **120**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_spiral_retention.py
- Ext: **.py** | Lines: **27** | Words: **135**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_sync.py
- Ext: **.py** | Lines: **55** | Words: **175**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 3
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 2
- Imports: argparse, os, shutil
- From-imports: pathlib

---
## py/.py/cmplx_zone_collapse.py
- Ext: **.py** | Lines: **41** | Words: **199**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: math
- From-imports: typing

---
## py/.py/cmplx_zone_density.py
- Ext: **.py** | Lines: **46** | Words: **218**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: math
- From-imports: typing

---
## py/.py/code_library.py
- Ext: **.py** | Lines: **42** | Words: **108**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: (none)
- From-imports: (none)

---
## py/.py/completion_algorithm_n8.py
- Ext: **.py** | Lines: **250** | Words: **1214**
### Keyword hits
- SFBB: 0
- superperm: 45
- superpermutation: 44
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 50
- golden: 7
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: (none)
- From-imports: (none)

---
## py/.py/completion_algorithm_n8_final.py
- Ext: **.py** | Lines: **928** | Words: **4488**
### Keyword hits
- SFBB: 0
- superperm: 98
- superpermutation: 97
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 114
- golden: 18
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/config.py
- Ext: **.py** | Lines: **145** | Words: **591**
### Keyword hits
- SFBB: 0
- superperm: 1
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 1
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: json, math, os, psutil
- From-imports: typing

---
## py/.py/config_loader.py
- Ext: **.py** | Lines: **21** | Words: **107**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, yaml
- From-imports: core.cmplx_logger

---
## py/.py/config_loader_patched.py
- Ext: **.py** | Lines: **44** | Words: **133**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 1
- Imports: os, yaml
- From-imports: core.cmplx_logger

---
## py/.py/construct_superpermutation.py
- Ext: **.py** | Lines: **195** | Words: **981**
### Keyword hits
- SFBB: 0
- superperm: 15
- superpermutation: 15
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 26
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: json, logging, random
- From-imports: analysis_scripts_final, laminate_utils, utils

---
## py/.py/construct_superpermutation.py_superpermutation_generator.py
- Ext: **.py** | Lines: **236** | Words: **1090**
### Keyword hits
- SFBB: 0
- superperm: 36
- superpermutation: 36
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 52
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 4
- Imports: json, logging, random
- From-imports: analysis_scripts_final, construct_superpermutation, layout_memory, utils

---
## py/.py/data_manager.py
- Ext: **.py** | Lines: **147** | Words: **652**
### Keyword hits
- SFBB: 0
- superperm: 14
- superpermutation: 14
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 12
- Imports: csv, json, pickle
- From-imports: (none)

---
## py/.py/fixed_testlab.py
- Ext: **.py** | Lines: **57** | Words: **210**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 4
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: json, os, random, yaml
- From-imports: cli.cmplx_run, core.cmplx_logger

---
## py/.py/foreman.py
- Ext: **.py** | Lines: **19** | Words: **79**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 2
- Imports: (none)
- From-imports: core.cmplx_logger

---
## py/.py/formula_evaluator.py
- Ext: **.py** | Lines: **142** | Words: **605**
### Keyword hits
- SFBB: 0
- superperm: 8
- superpermutation: 6
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 4
- Imports: formulas, math
- From-imports: analysis_scripts_final, utils

---
## py/.py/formulas.py
- Ext: **.py** | Lines: **90** | Words: **409**
### Keyword hits
- SFBB: 0
- superperm: 5
- superpermutation: 5
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 1
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 10
- Imports: math, networkx
- From-imports: collections, utils

---
## py/.py/generation_code_n7_dynamic.py
- Ext: **.py** | Lines: **869** | Words: **4251**
### Keyword hits
- SFBB: 0
- superperm: 82
- superpermutation: 82
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 7
- debruijn: 6
- beam: 0
- orchestrator: 0
- hash: 81
- golden: 16
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 2
- Functions: 30
- Imports: heapq, itertools, math, networkx, random, time
- From-imports: collections

---
## py/.py/generation_code_n7_dynamic_2.0.py
- Ext: **.py** | Lines: **741** | Words: **3488**
### Keyword hits
- SFBB: 0
- superperm: 78
- superpermutation: 78
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 88
- golden: 17
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 2
- Functions: 22
- Imports: analysis_scripts, heapq, itertools, math, networkx, random, time
- From-imports: collections, layout_memory

---
## py/.py/generation_code_n7_dynamic_final.py
- Ext: **.py** | Lines: **690** | Words: **3223**
### Keyword hits
- SFBB: 0
- superperm: 76
- superpermutation: 76
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 1
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 85
- golden: 14
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 2
- Functions: 21
- Imports: analysis_scripts, heapq, itertools, math, networkx, random, time
- From-imports: collections, layout_memory

---
## py/.py/generation_code_n8_dynamic._3.0.py
- Ext: **.py** | Lines: **655** | Words: **3143**
### Keyword hits
- SFBB: 0
- superperm: 86
- superpermutation: 86
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 1
- debruijn: 1
- beam: 0
- orchestrator: 0
- hash: 25
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/generation_code_n8_dynamic.py
- Ext: **.py** | Lines: **712** | Words: **3545**
### Keyword hits
- SFBB: 0
- superperm: 79
- superpermutation: 79
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 1
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 87
- golden: 17
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 2
- Functions: 21
- Imports: heapq, itertools, math, networkx, random, time
- From-imports: collections

---
## py/.py/generation_code_n8_dynamic_3.0.py
- Ext: **.py** | Lines: **1** | Words: **0**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/generation_code_n8_dynamic_final.py
- Ext: **.py** | Lines: **1018** | Words: **4765**
### Keyword hits
- SFBB: 0
- superperm: 133
- superpermutation: 133
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 1
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 95
- golden: 18
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/graph_utils.py
- Ext: **.py** | Lines: **43** | Words: **162**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 4
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 2
- Imports: logging, networkx
- From-imports: utils

---
## py/.py/grid_utils.py
- Ext: **.py** | Lines: **72** | Words: **322**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 1
- Functions: 6
- Imports: itertools
- From-imports: (none)

---
## py/.py/idea_tracker.py
- Ext: **.py** | Lines: **119** | Words: **459**
### Keyword hits
- SFBB: 0
- superperm: 10
- superpermutation: 10
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 1
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 2
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 2
- Imports: (none)
- From-imports: (none)

---
## py/.py/janitor.py
- Ext: **.py** | Lines: **23** | Words: **85**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 3
- Imports: os, shutil
- From-imports: core.cmplx_logger

---
## py/.py/laminate_utils.py
- Ext: **.py** | Lines: **64** | Words: **314**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 2
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: networkx
- From-imports: utils

---
## py/.py/layout copilot.py
- Ext: **.py** | Lines: **116** | Words: **697**
### Keyword hits
- SFBB: 0
- superperm: 5
- superpermutation: 5
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: math, pickle
- From-imports: (none)

---
## py/.py/layout_memor_finaly.py
- Ext: **.py** | Lines: **116** | Words: **697**
### Keyword hits
- SFBB: 0
- superperm: 5
- superpermutation: 5
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: math, pickle
- From-imports: (none)

---
## py/.py/layout_memory.py
- Ext: **.py** | Lines: **66** | Words: **367**
### Keyword hits
- SFBB: 0
- superperm: 3
- superpermutation: 3
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: logging, pickle
- From-imports: (none)

---
## py/.py/layout_memory.py_analysis_scripts_final.py
- Ext: **.py** | Lines: **100** | Words: **596**
### Keyword hits
- SFBB: 0
- superperm: 4
- superpermutation: 4
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 9
- Imports: itertools, logging, pickle
- From-imports: (none)

---
## py/.py/layout_memory_final.py
- Ext: **.py** | Lines: **116** | Words: **697**
### Keyword hits
- SFBB: 0
- superperm: 5
- superpermutation: 5
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: math, pickle
- From-imports: (none)

---
## py/.py/mdhg_hash (1).py
- Ext: **.py** | Lines: **65** | Words: **261**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 2
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 9
- golden: 1
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 8
- Imports: math
- From-imports: collections, typing

---
## py/.py/mdhg_hash.py
- Ext: **.py** | Lines: **7** | Words: **43**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 1
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 3
- golden: 1
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/meta_evaluator.py
- Ext: **.py** | Lines: **65** | Words: **286**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 8
- Imports: numpy
- From-imports: collections, typing

---
## py/.py/multiprocessing_example.py
- Ext: **.py** | Lines: **62** | Words: **252**
### Keyword hits
- SFBB: 0
- superperm: 8
- superpermutation: 8
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 1
- Imports: multiprocessing
- From-imports: (none)

---
## py/.py/n6_searcher.py
- Ext: **.py** | Lines: **280** | Words: **1241**
### Keyword hits
- SFBB: 0
- superperm: 22
- superpermutation: 19
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 6
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 9
- Imports: itertools, logging, multiprocessing, random, time
- From-imports: analysis_scripts_final, laminate_utils, utils

---
## py/.py/navigator_and_builder.py
- Ext: **.py** | Lines: **57** | Words: **185**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 2
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 10
- Imports: math, random
- From-imports: typing

---
## py/.py/prodigal_manager.py
- Ext: **.py** | Lines: **170** | Words: **739**
### Keyword hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 3
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 8
- Imports: json, logging
- From-imports: analysis_scripts_final, utils

---
## py/.py/reconfigurator.py
- Ext: **.py** | Lines: **179** | Words: **851**
### Keyword hits
- SFBB: 0
- superperm: 69
- superpermutation: 69
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 6
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 8
- Imports: logging, random
- From-imports: analysis_scripts_final, utils

---
## py/.py/register_agents.py
- Ext: **.py** | Lines: **58** | Words: **193**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: (none)
- From-imports: agents.audit, agents.builder, agents.clerk, agents.foreman, agents.janitor, agents.teacher, agents.validator, core.patch_engine, patch_strategies.default_patch, patch_strategies.vector_prune

---
## py/.py/register_agents_runtime_patched.py
- Ext: **.py** | Lines: **59** | Words: **203**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: (none)
- From-imports: agents.audit, agents.builder, agents.clerk, agents.foreman, agents.janitor, agents.teacher, agents.validator, core.patch_engine, patch_strategies.default_patch, patch_strategies.vector_prune

---
## py/.py/result_analyzer.py
- Ext: **.py** | Lines: **71** | Words: **300**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: json, os
- From-imports: core.cmplx_logger

---
## py/.py/runtime_controller.py
- Ext: **.py** | Lines: **72** | Words: **222**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 7
- Imports: (none)
- From-imports: core.cmplx_logger

---
## py/.py/salesman_and_evaluator.py
- Ext: **.py** | Lines: **56** | Words: **189**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 1
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 2
- Functions: 9
- Imports: math
- From-imports: typing

---
## py/.py/sequence_analysis.py
- Ext: **.py** | Lines: **58** | Words: **207**
### Keyword hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 3
- Imports: logging
- From-imports: collections, utils

---
## py/.py/sequence_generation.py
- Ext: **.py** | Lines: **198** | Words: **1041**
### Keyword hits
- SFBB: 0
- superperm: 45
- superpermutation: 45
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 2
- beam: 0
- orchestrator: 0
- hash: 21
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 2
- Imports: itertools, math, random
- From-imports: analysis_scripts_final, graph_utils, laminate_utils, layout_memory, prodigal_manager, utils

---
## py/.py/superpermutation_generator.py
- Ext: **.py** | Lines: **404** | Words: **1858**
### Keyword hits
- SFBB: 0
- superperm: 71
- superpermutation: 64
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 19
- golden: 1
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/sweep_scanner.py
- Ext: **.py** | Lines: **46** | Words: **223**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 1
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 5
- Imports: math, numpy
- From-imports: typing

---
## py/.py/teacher.py
- Ext: **.py** | Lines: **35** | Words: **145**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 2
- Imports: yaml
- From-imports: agents.testlab, core.cmplx_logger, core.result_analyzer

---
## py/.py/teacher_fallback_enabled.py
- Ext: **.py** | Lines: **58** | Words: **227**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 4
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 3
- Imports: yaml
- From-imports: agents.testlab, cli.cmplx_run, core.cmplx_logger, core.result_analyzer

---
## py/.py/teacher_runtime_patched.py
- Ext: **.py** | Lines: **38** | Words: **154**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 2
- Imports: yaml
- From-imports: agents.testlab, core.cmplx_logger, core.result_analyzer

---
## py/.py/teacher_safe.py
- Ext: **.py** | Lines: **37** | Words: **146**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 1
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 2
- Imports: yaml
- From-imports: agents.testlab, core.cmplx_logger, core.result_analyzer

---
## py/.py/testlab.py
- Ext: **.py** | Lines: **45** | Words: **163**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 4
- E8: 0
- LSDT: 0
- TSP: 1
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: uuid
- From-imports: cli.cmplx_run, core.cmplx_logger

---
## py/.py/testlab_runtime_patched.py
- Ext: **.py** | Lines: **60** | Words: **228**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 4
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: json, os, random, yaml
- From-imports: cli.cmplx_run, core.cmplx_logger

---
## py/.py/testlab_safe.py
- Ext: **.py** | Lines: **58** | Words: **217**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 4
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: json, os, random, yaml
- From-imports: cli.cmplx_run, core.cmplx_logger

---
## py/.py/tsp_node_loader (1).py
- Ext: **.py** | Lines: **100** | Words: **366**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 21
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: os, re
- From-imports: typing

---
## py/.py/tsp_node_loader (2).py
- Ext: **.py** | Lines: **101** | Words: **391**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 22
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 6
- Imports: os, re
- From-imports: typing

---
## py/.py/tsp_node_loader.py
- Ext: **.py** | Lines: **56** | Words: **201**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 3
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 4
- Imports: os, re
- From-imports: typing

---
## py/.py/unpack_tsplib_gz.py
- Ext: **.py** | Lines: **33** | Words: **122**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 3
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 2
- Imports: gzip, os, shutil
- From-imports: (none)

---
## py/.py/utility.py
- Ext: **.py** | Lines: **272** | Words: **1232**
### Keyword hits
- SFBB: 0
- superperm: 0
- superpermutation: 0
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 9
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 0
- Imports: (none)
- From-imports: (none)

---
## py/.py/utils.py
- Ext: **.py** | Lines: **69** | Words: **287**
### Keyword hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 11
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 10
- Imports: hashlib, itertools, logging
- From-imports: (none)

---
## py/.py/utils.py_graph_utils.py
- Ext: **.py** | Lines: **91** | Words: **593**
### Keyword hits
- SFBB: 0
- superperm: 3
- superpermutation: 3
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 4
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 11
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 12
- Imports: hashlib, itertools, logging, networkx
- From-imports: (none)

---
## py/.py/utils_graph_utils.py
- Ext: **.py** | Lines: **89** | Words: **366**
### Keyword hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 2
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 11
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 12
- Imports: hashlib, itertools, logging, networkx
- From-imports: (none)

---
## py/.py/verification_script_final.py
- Ext: **.py** | Lines: **53** | Words: **206**
### Keyword hits
- SFBB: 0
- superperm: 13
- superpermutation: 13
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 1
- Imports: itertools, sys
- From-imports: (none)