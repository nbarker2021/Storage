from snaplat.morsr.enrich import enrich
def test_morsr_enrich_has_keep():
    rec = {"metrics":{"coverage":0.8,"drift":0.1}, "glyph_dl":0.4}
    out = enrich(rec)
    assert "keep" in out and "coverage" in out["keep"]
