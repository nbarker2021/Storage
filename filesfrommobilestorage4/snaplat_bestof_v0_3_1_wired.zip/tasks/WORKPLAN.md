# WORKPLAN

## P0 — Wire core adapters
- [ ] E8Adapter: neighbors/project/* → PlanAdapter
- [ ] DTTAdapter: evaluation → PlanAdapter
- [ ] AssemblyAdapter: barymix, glyph_dl → PlanAdapter
- [ ] NavAdapter: sector kNN + CPP/TSP → PlanAdapter

## P1 — Planner loop + configs
- [ ] sap.loop orchestrator; load `config/default.yaml`
- [ ] MORSR keeplist: ensure every tick includes required fields

## P2 — Detensor & RAG
- [ ] Detensor budgets integrated into SAP complexity gate
- [ ] RAG detector: wire corpus coverage & index drift

## P3 — Docs & DX
- [ ] mkdocs site; hook module index
- [ ] richer CI (lint/format, artifact upload)
