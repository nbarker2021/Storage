from typing import Dict, Any, Iterable

DEFAULT_KEEPLIST = [
    "coverage","drift","leakage","consensus","diversity",
    "glyph_dl","neighbors_count","frontier_width","distinct_cells",
    "tac","boundary"
]

def enrich(record: Dict[str, Any], keeplist: Iterable[str] = DEFAULT_KEEPLIST) -> Dict[str, Any]:
    r = dict(record)
    r.setdefault("metrics", {})
    keep = {k: record.get(k, r["metrics"].get(k)) for k in keeplist if (record.get(k) is not None or r["metrics"].get(k) is not None)}
    if keep:
        r["keep"] = {k: v for k,v in keep.items() if v is not None}
    return r
