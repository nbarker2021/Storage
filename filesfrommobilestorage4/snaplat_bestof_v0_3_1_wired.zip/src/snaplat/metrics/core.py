def coverage_ratio(touched: int, total: int) -> float:
    if total <= 0: return 0.0
    return max(0.0, min(1.0, float(touched)/float(total)))
