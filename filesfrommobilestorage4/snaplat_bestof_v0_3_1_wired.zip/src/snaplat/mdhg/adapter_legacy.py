
try:
    from vendor.mdhg.agrmmdhg import MDHGHashTable as _VendorMDHG  # type: ignore
except Exception:
    _VendorMDHG = None
from .core import MDHG as _SimpleMDHG
from ..types.protocols import MDHGProto
class MDHG:  # implements MDHGProto
    def __init__(self, use_vendor: bool = True):
        if use_vendor and _VendorMDHG is not None:
            self.backend = _VendorMDHG(); self.vendor = True
        else:
            self.backend = _SimpleMDHG(); self.vendor = False
    def put(self, k, v): return self.backend.put(k, v)
    def get(self, k, default=None): return self.backend.get(k) if hasattr(self.backend, 'get') else default
    def has(self, k) -> bool: return getattr(self.backend, 'has', lambda kk: kk in getattr(self.backend, 'kv', {}))(k)
    def hotmap(self):
        if hasattr(self.backend, 'hotmap'): return self.backend.hotmap()
        return getattr(self.backend, 'access', {})
