from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..mdhg.bus import MDHGBus

# Use existing DTT harness if available
try:
    from ..dtt.harness import DTT, DTTConfig
    from ..superperm.c8 import produce_c8, C8Config
except Exception:
    DTT = None
    produce_c8 = None

@dataclass
class DTTAdapter(PlanAdapterProto):
    mdhg: MDHGBus
    seed: int = 42

    def actions(self) -> Dict[str, Action]:
        return {
            "produce": Action(op="produce", tag="E", m=1.0),
            "evaluate": Action(op="evaluate", tag="C", m=0.5),
        }

    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        if DTT is None or produce_c8 is None:
            # fallback: emit a stable pseudo metric
            cov = 0.5; drift = 0.05
            self.mdhg.put("dtt:last", {"seed": self.seed}, score=cov, notes={"drift": drift})
            return Trail(metrics={"coverage": cov, "drift": drift}, artifacts={}, notes={"fallback": True})
        cands = produce_c8(C8Config(seed=self.seed))
        ev = DTT(DTTConfig(seed=self.seed)).run(cands)
        # coverage: fraction of utilities >= 0.5
        utils = [e.metrics.get("utility", 0.0) for e in ev]  # type: ignore
        good = sum(1 for u in utils if u >= 0.5)
        coverage = good / float(len(utils) or 1)
        drift = abs(sum(utils)/len(utils) - 0.5)
        self.mdhg.put("dtt:last_utils", utils, score=coverage, notes={"drift": drift})
        return Trail(metrics={"coverage": coverage, "drift": drift}, artifacts={"utils": utils}, notes={})

    def learn(self, trace: Trail) -> None:
        return None
