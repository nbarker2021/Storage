from __future__ import annotations
from typing import Dict, Any, List
from dataclasses import dataclass
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..metrics.core import coverage_ratio
from ..metrics.splus import leakage_from_metrics
from ..mdhg.bus import MDHGBus

@dataclass
class RAGAdapter(PlanAdapterProto):
    mdhg: MDHGBus

    def actions(self) -> Dict[str, Action]:
        return {
            "index_sample": Action(op="index_sample", tag="E", m=2.0, est_cost=1.0),
            "query_probe": Action(op="query_probe", tag="E", m=2.0, est_cost=1.0),
            "consolidate": Action(op="consolidate", tag="C", m=0.5, est_cost=0.5),
        }

    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        total_docs = int(state.get("docs_total", 1000))
        touched = int(state.get("docs_touched", 120))
        coverage = coverage_ratio(touched, total_docs)
        drift = float(state.get("index_drift", 0.08))
        tac = float(state.get("tac", 0.95))
        boundary = float(state.get("policy_boundary", 0.9))
        leak = leakage_from_metrics({"tac":tac, "boundary":boundary, "drift":drift})
        self.mdhg.put("rag:corpus", f"docs:{touched}", score=coverage, notes={"drift": drift})
        return Trail(metrics={"coverage": coverage, "drift": drift, "leakage": leak}, artifacts={}, notes={"docs_touched": touched})

    def learn(self, trace: Trail) -> None:
        return None
