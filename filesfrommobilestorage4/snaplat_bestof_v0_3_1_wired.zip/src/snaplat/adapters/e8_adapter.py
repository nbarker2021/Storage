from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..mdhg.bus import MDHGBus

# Import E8 helpers if available; else provide light fallbacks
try:
    from ..e8.core import nearest, edges, coxeter_plane
except Exception:
    def nearest(v): return ([0.0]*8, 0.0)
    def edges(x): return [[0.0]*8 for _ in range(240)]
    def coxeter_plane(x): return (0.0, 0.0)

def slice_id_for(vec: List[float]) -> str:
    p, _ = nearest(vec)
    return "cell:" + ",".join(str(int(round(x*2))) for x in p)

@dataclass
class E8Adapter(PlanAdapterProto):
    mdhg: MDHGBus
    base_point: List[float]

    def actions(self) -> Dict[str, Action]:
        return {
            "neighbors": Action(op="neighbors", tag="E", m=1.0),
            "reflect": Action(op="reflect", tag="E", m=1.0),
            "project2d": Action(op="project2d", tag="C", m=0.2),
        }

    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        # Determine lattice cell and neighbors
        p, _ = nearest(self.base_point or [0.0]*8)
        nbrs = edges(p)
        distinct_cells = len(nbrs)
        # Simple coverage metric: neighbors / 240 (root shell size)
        coverage = min(1.0, distinct_cells / 240.0)
        # Drift: change in projection from cached (simulate from state if present)
        u, v = coxeter_plane(p)
        prev = self.mdhg.get("e8:last_proj", {"u": u, "v": v})
        du = abs(prev["u"] - u); dv = abs(prev["v"] - v)
        drift = min(1.0, (du + dv) / 10.0)
        self.mdhg.put("e8:last_proj", {"u": u, "v": v}, score=coverage, notes={"drift": drift})
        self.mdhg.put("e8:last_cell", slice_id_for(self.base_point or [0.0]*8), score=coverage, notes={})
        return Trail(metrics={"coverage": coverage, "drift": drift}, artifacts={"neighbors": distinct_cells}, notes={"u": u, "v": v})

    def learn(self, trace: Trail) -> None:
        return None
