from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Dict, Any, List

@dataclass
class Action:
    op: str
    tag: str
    m: float
    est_cost: float = 1.0

@dataclass
class Trail:
    metrics: Dict[str, Any]
    artifacts: Dict[str, Any]
    notes: Dict[str, Any]

class PlanAdapterProto(Protocol):
    def actions(self) -> Dict[str, Action]: ...
    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail: ...
    def learn(self, trace: Trail) -> None: ...
