from __future__ import annotations
from dataclasses import dataclass

@dataclass
class GateOutcome:
    ok: bool
    reason: str

@dataclass
class ComplexityCfg:
    max_frontier: int = 2000
    max_glyph_dl: float = 5.0
    max_phi_rise_ticks: int = 5

@dataclass
class DetectorCfg:
    min_N: int = 2
    min_diversity: float = 0.5

def leakage_gate(leakage_avg: float, eps: float=0.05) -> GateOutcome:
    return GateOutcome(ok=leakage_avg <= eps, reason="leakage<=eps" if leakage_avg <= eps else "Leakage≤ε failed")

def complexity_gate(sc: dict, cfg: ComplexityCfg) -> GateOutcome:
    if sc.get("frontier_width", 0) > cfg.max_frontier: return GateOutcome(False, "frontier too wide")
    if sc.get("glyph_dl", 0.0) > cfg.max_glyph_dl: return GateOutcome(False, "glyph_dl too large")
    return GateOutcome(True, "OK")

def detector_gate(fusion: dict, stats: dict, cfg: DetectorCfg) -> GateOutcome:
    if fusion.get("N",0) < cfg.min_N: return GateOutcome(False, "insufficient detectors")
    if fusion.get("diversity",0.0) < cfg.min_diversity: return GateOutcome(False, "insufficient diversity")
    return GateOutcome(True, "OK")
