# Unified reason codes for policy gates (SAFE-cube, Finalize, LawPacks)
SAFE = {
  "EVIDENCE_EDGES_LOW": "safecube.edges.below_threshold",
  "NEIGHBORS_LOW": "safecube.neighbors.below_threshold",
  "OCTANTS_LOW": "safecube.octants.below_threshold",
  "EGO_NODES_LOW": "safecube.ego.nodes.below_min",
  "EGO_EDGES_LOW": "safecube.ego.edges.below_min",
  "EGO_DEGREE_LOW": "safecube.ego.degree.below_min",
  "LAWPACK_BLOCK": "safecube.lawpack.block",
}
FINALIZE = {
  "NODES_LOW": "finalize.nodes.below_threshold",
  "EDGES_LOW": "finalize.edges.below_threshold",
  "STABILITY_LOW": "finalize.stability.below_min",
}
LAW = {
  "CONSENT_MISSING": "law.consent.missing",
  "PII_UNSANITIZED": "law.pii.unsanitized",
  "PHI_UNSANITIZED": "law.phi.unsanitized",
  "PCI_VIOLATION": "law.pci.violation",
  "FERPA_VIOLATION": "law.ferpa.violation",
}
