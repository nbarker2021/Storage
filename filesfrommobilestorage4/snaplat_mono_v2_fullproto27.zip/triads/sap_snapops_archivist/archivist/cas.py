import json, hashlib, pathlib, time
from utils.fs import atomic_write
from kernel.authz import guard_write
from kernel.telemetry import emit
from triads.sap_snapops_archivist.archivist.schemas import validate as _schema_validate

ROOT = pathlib.Path("outputs/cas")
JOURNAL = pathlib.Path("outputs/cas_journal/ops.log")
ROOT.mkdir(parents=True, exist_ok=True)
JOURNAL.parent.mkdir(parents=True, exist_ok=True)

def _hash(obj: dict) -> str:
    blob = json.dumps(obj, sort_keys=True, separators=(",",":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()

def _journal(op: str, hash_id: str):
    ts = int(time.time()*1000)
    line = json.dumps({"t": ts, "op": op, "hash": hash_id}) + "\n"
    atomic_write(JOURNAL, (JOURNAL.read_bytes() if JOURNAL.exists() else b"") + line.encode("utf-8"))

def put(obj: dict) -> str:
    if not guard_write(context={"fn":"cas.put", "kind": obj.get("kind")}):
        emit("rbac.deny.write", "cas", {"fn":"put", "kind": obj.get("kind")})
        return ""
    ok, reasons = _schema_validate(obj)
    if not ok:
        emit('cas.schema.denied','cas',{'kind': obj.get('kind'), 'reasons': reasons}); return ''
    h = _hash(obj)
    p = ROOT / h[0:2] / h[2:]
    if p.exists():
        return h
    p.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(p, json.dumps(obj, sort_keys=True, indent=None, separators=(",",":")).encode("utf-8"))
    _journal("put", h)
    emit("cas.put", "cas", {"hash": h, "kind": obj.get("kind")})
    return h

def get(hash_id: str) -> dict|None:
    p = ROOT / hash_id[0:2] / hash_id[2:]
    if not p.exists():
        return None
    try:
        raw = p.read_text(encoding="utf-8")
        return json.loads(raw)
    except Exception:
        return None

def exists(hash_id: str) -> bool:
    p = ROOT / hash_id[0:2] / hash_id[2:]
    return p.exists()
