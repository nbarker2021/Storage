from triads.thinktank_dtt_assembly.thinktank.engine import generate_8_plus_8
from triads.thinktank_dtt_assembly.dtt.invariants import validate
from triads.thinktank_dtt_assembly.assembly.publish import build_lockfile, finalize_1729
from kernel.telemetry import emit
from kernel.rmi_reads import recent_trails
from kernel.context import infer_domain_from_trails
from triads.reasoning_overlays.cto.window import _enrich_slice
from kernel.graph_metrics import evidence_for_endpoint
from policy.safecube import assess as safecube_assess


def run_pipeline(subject:str, endpoint_id:str, domain:str|None=None) -> dict:
    # Derive domain if not provided
    trails = recent_trails(limit=200)
    dom = domain or infer_domain_from_trails(trails) or 'general'
    # ThinkTank 8+8 with derived domain and CTO slice‑inferred domains
    slice_desc = _enrich_slice(trails)
    add_domains = []
    if slice_desc.get('healthcare'): add_domains.append('healthcare')
    if slice_desc.get('finance'): add_domains.append('finance')
    if slice_desc.get('education'): add_domains.append('education')
    if slice_desc.get('privacy') or slice_desc.get('legal'): add_domains.append('governance')
    if slice_desc.get('counts',{}).get('overlay_checks',0)>0: add_domains.append('physics')
    tt = generate_8_plus_8(subject, dom, domains=list(dict.fromkeys([dom]+add_domains)))
    ok, fails = validate(tt)
    if not ok:
        emit("assembly.blocked", "asm", {"endpoint_id": endpoint_id, "reason": "dtt_invariants", "fails": fails})
        return {"ready": False, "reason": "dtt_invariants", "fails": fails}
    # Evidence from graph
    ev = evidence_for_endpoint(endpoint_id)
    evidence_nodes = ev.get('nodes', 0)
    # Assemble endpoint payload and apply 1729 threshold
    ep = {"endpoint_id": endpoint_id, "k_routes": ["r1","r2"], "evidence_nodes": evidence_nodes, "evidence_edges": ev.get('edges',0), "domain": dom}
    ready, rs = finalize_1729(ep)
    emit("assembly.evaluate", "asm", {"endpoint_id": endpoint_id, "ready": ready, "reasons": rs, "evidence": ev, "domain": dom})
    if not ready:
        return {"ready": False, "reasons": rs, "evidence": ev}
    # SAFE‑cube policy gate prior to manifest
    ok_sc, proof = safecube_assess({"endpoint_id": endpoint_id, "evidence": ev, "domain": dom})
    if not ok_sc:
        emit("assembly.blocked", "asm", {"endpoint_id": endpoint_id, "reason": "safecube", "proof": proof})
        return {"ready": False, "reason": "safecube", "evidence": ev, "proof": proof}
    # Emit stability band for observability
    try:
        from triads.snap_agrm_mdhg.mdhg.signals import stability_band
        sb = stability_band(endpoint_id)
        emit('assembly.stability', 'asm', {'endpoint_id': endpoint_id, 'band': sb})
    except Exception:
        pass

    # Build provenance bundle
    from triads.sap_snapops_archivist.archivist.provenance import write_provenance
    # E8 glyph proof
    try:
        from triads.e8.proof import generate_proof as e8_proof
        e8 = e8_proof(endpoint_id)
    except Exception:
        e8 = {'rotation_ok': False, 'octants': [], 'missing': list(range(1,9)), 'cas_hash': ''}
    bundle = {
        'endpoint_id': endpoint_id,
        'domain': dom,
        'evidence': ev,
        'safecube': proof,
        'e8': e8,
        'thinktank': {'personas': tt.get('personas',[]), 'hypotheses': tt.get('hypotheses',[]), 'dichotomies': tt.get('dichotomies',[])},
    }
    prov_hash = write_provenance(endpoint_id, bundle)
    ep['provenance'] = prov_hash
    # Build Manifest v2
    man = build_lockfile(ep)
    # Lifecycle finalize hook (snapshot lineage)
    try:
        from triads.sap_snapops_archivist.archivist.lifecycle import on_finalize
        snap = on_finalize(endpoint_id, man.get('cas_hash',''))
    except Exception:
        snap = ''
    from triads.sap_snapops_archivist.archivist.attest import write_attestation
    att = write_attestation(endpoint_id, man.get('cas_hash',''), prov_hash, man.get('signature'))
    emit("assembly.ready", "asm", {"endpoint_id": endpoint_id, "manifest_version": man.get('version'), "domain": dom, "provenance": prov_hash, "attestation": att, "snapshot": snap})
    return {"ready": True, "manifest": man, "domain": dom, "evidence": ev, "provenance": prov_hash, "attestation": att, "snapshot": snap}
