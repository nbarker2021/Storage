import json, os, hmac, hashlib, time
from kernel.telemetry import emit
from kernel.authz import guard_write
from api.archivist import read_lockfile_checked
from triads.sap_snapops_archivist.archivist.recall import write_lockfile
import yaml, pathlib, math
from kernel.stability import stability_for_endpoint
from policy import reasons as REASONS

POLICY = pathlib.Path("policy/finalize.yaml")
DEFAULTS = { "min_evidence_nodes": 1729, "min_evidence_edges": 3, "domain_multipliers": {}, "domain_defaults": {}, "require_stability": False, "min_stability": 0.6 }

def _policy():
    cfg = DEFAULTS.copy()
    if POLICY.exists():
        try:
            y = yaml.safe_load(POLICY.read_text(encoding="utf-8")) or {}
            for k,v in (y.items() if isinstance(y, dict) else []):
        if k in ("min_evidence_nodes","min_evidence_edges"):
            try: cfg[k] = int(v)
            except Exception: pass
        if k=="domain_multipliers" and isinstance(v, dict):
            cfg[k] = v
        if k=="domain_defaults" and isinstance(v, dict):
            cfg[k] = v
        except Exception:
            pass
    return cfg

def finalize_gate(ep: dict) -> (bool, list):
    cfg = _policy()
    nodes = int(ep.get("evidence_nodes", 0))
    edges = int(ep.get("evidence_edges", ep.get("evidence", {}).get("edges", 0)))
    
dom = (ep or {}).get('domain')
dm = cfg.get('domain_multipliers') or {}
nod_thr = cfg['min_evidence_nodes']
edg_thr = cfg['min_evidence_edges']
if dom and dom in dm:
    try:
        if 'nodes' in dm[dom]: nod_thr = math.ceil(nod_thr * float(dm[dom]['nodes']))
        if 'edges' in dm[dom]: edg_thr = math.ceil(edg_thr * float(dm[dom]['edges']))
    except Exception:
        pass
ok = (nodes >= nod_thr) and (edges >= edg_thr)
    if ok and cfg.get('require_stability'):
        stab = stability_for_endpoint(ep.get('endpoint_id',''))
        ok = ok and (stab >= float(cfg.get('min_stability', 0.6)))
    rs = []
    if nodes < nod_thr:
        rs.append(f"gate.nodes:{nodes} < {cfg['min_evidence_nodes']}")
    if edges < edg_thr:
        rs.append(f"gate.edges:{edges} < {cfg['min_evidence_edges']}")
    return ok, rs

def _sign_manifest(man: dict) -> dict:
    secret = os.environ.get("SNAPLAT_SECRET", "")
    if not secret:
        return man
    blob = json.dumps(man, sort_keys=True, separators=(",",":")).encode("utf-8")
    sig = hmac.new(secret.encode("utf-8"), blob, hashlib.sha256).hexdigest()
    man["signature"] = {"alg":"HS256","sig":sig}
    return man

def build_lockfile(ep: dict) -> dict:
    if not guard_write(context={"fn":"assembly.build_lockfile","endpoint":ep.get("endpoint_id")}):
        emit("rbac.deny.write", "asm", {"fn":"assembly.build_lockfile", "endpoint": ep.get("endpoint_id")})
        return {}
    man = {
        "version": 2,
        "endpoint_id": ep.get("endpoint_id"),
        "created_at": int(time.time()*1000),
        "evidence_nodes": ep.get("evidence_nodes", 0),
        "evidence_edges": ep.get("evidence_edges", 0),
        "provenance": ep.get("provenance"),
    }
    man = _sign_manifest(man)
    h = write_lockfile(ep.get("endpoint_id",""), man)
    man["cas_hash"] = h
    return man

# Backwards compat alias (older pipeline callers may use finalize_1729)
def finalize_1729(ep: dict) -> (bool, list):
    return finalize_gate(ep)
