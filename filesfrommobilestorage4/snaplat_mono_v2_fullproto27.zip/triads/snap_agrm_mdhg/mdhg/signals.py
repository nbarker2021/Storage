import sqlite3, math, statistics, time
from kernel.telemetry import emit

DB = "rmi/snaplat.db"

def _conn():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    return con

def delta_tau(endpoint_id: str, horizon: int = 200) -> dict:
    """Compute Δ (first diff) and τ (smoothed score) across recent Top‑K entries for endpoint."""
    con = _conn(); cur = con.cursor()
    rows = cur.execute("SELECT created_at, score FROM i8_topk WHERE choice_id=? ORDER BY created_at DESC LIMIT ?", (endpoint_id, horizon)).fetchall()
    scores = [float(r['score'] or 0.0) for r in rows]
    scores = list(reversed(scores))  # chronological
    if not scores:
        return {"delta": 0.0, "tau": 0.0}
    # τ: EMA with α tuned to horizon
    alpha = 2/(min(len(scores), 20)+1)
    tau = 0.0
    for s in scores:
        tau = alpha*s + (1-alpha)*tau
    # Δ: average absolute first difference
    delta = 0.0 if len(scores)<2 else sum(abs(scores[i]-scores[i-1]) for i in range(1,len(scores)))/(len(scores)-1)
    emit('mdhg.signals', 'mdhg', {'endpoint': endpoint_id, 'delta': delta, 'tau': tau})
    return {"delta": delta, "tau": tau}

def stability_band(endpoint_id: str) -> str:
    sig = delta_tau(endpoint_id)
    tau = sig['tau']; delta = sig['delta']
    # Heuristic: high stability when tau>=0.7 and delta<=0.05; medium if moderate; else low
    if tau >= 0.7 and delta <= 0.05:
        band = 'high'
    elif tau >= 0.5 and delta <= 0.1:
        band = 'medium'
    else:
        band = 'low'
    emit('mdhg.stability_band', 'mdhg', {'endpoint': endpoint_id, 'band': band, 'tau': tau, 'delta': delta})
    return band
