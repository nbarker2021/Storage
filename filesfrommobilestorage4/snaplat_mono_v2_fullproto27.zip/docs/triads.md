# Triads — ThinkTank, DTT, Assembly

- **ThinkTank (TT)**: generates **8 hypotheses + 8 dichotomies** per subject; persona-aware (registry under `policy/personas`).
- **DTT**: validates TT outputs against invariants (non-empty, disjoint, etc.), emits Trails.
- **Assembly**: applies the **1729 gate** (evidence threshold) and builds **Manifest v2** on readiness.
- **Integration**: The SAP tick runner calls the Assembly pipeline per endpoint after overlay checks.
