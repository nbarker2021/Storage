# SAFE‑cube (enriched)

Checks applied before Manifest v2 finalize:
- **Edge diversity**: ≥ `REQUIRED_EDGES` distinct neighbors in lineage around the endpoint.
- **Octant coverage**: endpoint appears across ≥ `REQUIRED_OCTANTS` I8 octants (current or history).
- **LawPack alignment**: active LawPacks must pass on the current CTO‑enriched slice.
- **Evidence**: graph evidence edges/nodes included in Trails for audit.

Failures emit `safecube.check` and `assembly.blocked` trails with reasons.
