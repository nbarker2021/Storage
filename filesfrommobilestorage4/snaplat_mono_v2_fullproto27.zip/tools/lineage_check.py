#!/usr/bin/env python3
import sqlite3, pathlib, sys
from kernel.telemetry import emit

DB = "rmi/snaplat.db"

def check():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    errs = []
    # edges refer to nodes that exist (routes or endpoints)
    try:
        nodes = set()
        for r in cur.execute("SELECT route_id AS id FROM routes"):
            nodes.add(r["id"])
        for r in cur.execute("SELECT endpoint_id AS id FROM endpoints"):
            nodes.add(r["id"])
        for r in cur.execute("SELECT src_id, dst_id FROM lineage_edges"):
            if r["src_id"] not in nodes:
                errs.append(f"missing-node:{r['src_id']}")
            if r["dst_id"] not in nodes:
                errs.append(f"missing-node:{r['dst_id']}")
    except Exception as e:
        errs.append(f"db-error:{e}")
    ok = len(errs)==0
    emit("lineage.check", "ops", {"ok": ok, "errors": errs[:20], "total_errors": len(errs)})
    print("OK" if ok else "FAIL", len(errs))
    return ok

if __name__ == "__main__":
    sys.exit(0 if check() else 1)
