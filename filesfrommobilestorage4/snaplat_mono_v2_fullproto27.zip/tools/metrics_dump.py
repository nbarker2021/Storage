#!/usr/bin/env python3
import sqlite3, pathlib, json, time
from kernel.authz import guard_rmi_read
OUT = pathlib.Path("outputs/metrics.json")

def metric(name, value, labels=None):
    return {"name": name, "value": value, "labels": labels or {}}

def gather():
    con = sqlite3.connect("rmi/snaplat.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    m = []
    import json
    # Governance
    row = cur.execute("SELECT COUNT(1) AS c FROM trails WHERE kind LIKE 'gcr.%'").fetchone()
    m.append(metric("trails_gcr_total", row["c"]))
    # Endpoints
    row = cur.execute("SELECT COUNT(1) AS c FROM endpoints WHERE finalized=1").fetchone()
    m.append(metric("endpoints_finalized_total", row["c"]))
    # Overlays
    row = cur.execute("SELECT COUNT(1) AS c FROM overlays").fetchone()
    m.append(metric("overlays_total", row["c"]))
    # TopK rows (current)
    row = cur.execute("SELECT COUNT(1) AS c FROM v_i8_topk_current").fetchone()
    m.append(metric("i8_topk_current_total", row["c"]))
    
# Evidence & SAFE-cube (from Trails)
rows = cur.execute("SELECT payload FROM trails WHERE kind='assembly.evaluate'").fetchall()
ev_nodes = []; ev_edges = []
ready_1729 = 0
for r in rows:
    try:
        p = json.loads(r['payload']) if isinstance(r['payload'], str) else r['payload']
    except Exception:
        p = r['payload']
    if isinstance(p, dict):
        e = p.get('evidence') or {}
        ev_nodes.append(int(e.get('nodes',0))); ev_edges.append(int(e.get('edges',0)))
        if p.get('ready'): ready_1729 += 1
safeblocks = cur.execute("SELECT COUNT(1) AS c FROM trails WHERE kind='assembly.blocked' AND payload LIKE '%safecube%'" ).fetchone()['c']
def _avg(lst): return (sum(lst)/len(lst)) if lst else 0.0
m.append(metric("evidence_nodes_avg", _avg(ev_nodes)))
m.append(metric("evidence_edges_avg", _avg(ev_edges)))
m.append(metric("endpoints_ready_1729", ready_1729))
m.append(metric("safecube_blocks_total", safeblocks))

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"generated_at": int(time.time()), "metrics": m}, indent=2), encoding="utf-8")
    print(str(OUT))

if __name__ == "__main__":
    gather()
