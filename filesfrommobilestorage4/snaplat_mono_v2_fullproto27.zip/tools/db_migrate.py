#!/usr/bin/env python3
from kernel.migrations import ensure_indexes
if __name__ == "__main__":
    ok = ensure_indexes()
    print("migrations:", ok)
