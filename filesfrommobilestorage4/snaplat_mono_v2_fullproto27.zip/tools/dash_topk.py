#!/usr/bin/env python3
import sqlite3, pathlib, json, time
from kernel.authz import guard_rmi_read
from kernel.rmi_reads import topk_current
DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/topk.html")

def fetch():
    if not guard_rmi_read(context={'script':'dash_topk'}):
        return []
    return topk_current(None)

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    html = ["<html><head><meta charset='utf-8'><title>Top‑K</title><style>body{font-family:sans-serif} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style></head><body><nav style='padding:8px;background:#f0f0f0;border-bottom:1px solid #ddd'>
  <a href='topk.html'>Top‑K</a> |
  <a href='overlays.html'>Overlays</a> |
  <a href='lineage.html'>Lineage</a> |
  <a href='topk_history.html'>Top‑K History</a>
</nav>
"]
    html.append(f"<h2>Top‑K (generated {int(time.time())})</h2>")
    html.append("<table><tr><th>octant</th><th>choice_id</th><th>kind</th><th>score</th><th>created_at</th></tr>")
    for r in rows:
        html.append(f"<tr><td>{r['octant']}</td><td>{r['choice_id']}</td><td>{r['choice_kind']}</td><td>{r['score']:.3f}</td><td>{r['created_at']}</td></tr>")
    html.append("</table></body></html>")
    OUT.write_text("\n".join(html), encoding="utf-8")

if __name__ == "__main__":
    render(fetch())
