#!/usr/bin/env python3
import json, pathlib, shutil, tarfile, io, time
from tools.attestation_verify import _latest_attestation_for_endpoint, _load_cas

CAS = pathlib.Path("outputs/cas")
OUTDIR = pathlib.Path("outputs/exports/attest")

def export_latest(endpoint_id: str) -> str:
    att = _latest_attestation_for_endpoint(endpoint_id)
    if not att: raise SystemExit("no attestation index for endpoint")
    a = _load_cas(att)
    man = _load_cas(a['manifest_cas'])
    prov = _load_cas(a['provenance_cas'])
    OUTDIR.mkdir(parents=True, exist_ok=True)
    ts = a.get('created_at') or int(time.time()*1000)
    out = OUTDIR / f"{endpoint_id}-{ts}.zip"
    # write a zip archive in memory
    import zipfile
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("attestation.json", json.dumps(a, indent=2, sort_keys=True))
        z.writestr("manifest.json", json.dumps(man, indent=2, sort_keys=True))
        z.writestr("provenance.json", json.dumps(prov, indent=2, sort_keys=True))
        z.writestr("README.txt", "This bundle contains attestation.json, manifest.json, and provenance.json. Verify with tools/attestation_verify.py --endpoint <id>.")
    print(str(out))
    return str(out)

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("usage: tools/attestation_export.py <endpoint_id>")
        raise SystemExit(2)
    export_latest(sys.argv[1])
