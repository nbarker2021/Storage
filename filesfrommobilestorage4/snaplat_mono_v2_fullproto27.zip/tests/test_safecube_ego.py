import policy.safecube as sc

def test_assess_wrapper_monkey(monkeypatch):
    # Set generous thresholds and ego minima small; ensure ok
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    monkeypatch.setattr(sc, "_lawpack_ok", lambda: (True, []))
    ok, details = sc.assess({"endpoint_id":"epX","evidence":{"edges":2},"domain":"governance"})
    assert ok and details.get("ego_neighbors")==2
