from triads.thinktank_dtt_assembly.thinktank.engine import generate_8_plus_8
from kernel.tick import begin_tick

def test_persona_determinism():
    # Two runs in the same tick should yield same persona list order
    tid = begin_tick()
    a = generate_8_plus_8("subjectX", domain="finance")["personas"]
    b = generate_8_plus_8("subjectX", domain="finance")["personas"]
    assert a == b
