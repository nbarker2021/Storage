import pathlib, yaml
from triads.thinktank_dtt_assembly.assembly.publish import finalize_gate

def test_finalize_requires_stability(tmp_path, monkeypatch):
    p = pathlib.Path("policy/finalize.yaml"); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("min_evidence_nodes: 1\nmin_evidence_edges: 1\nrequire_stability: true\nmin_stability: 0.1\n", encoding="utf-8")
    ok, rs = finalize_gate({'endpoint_id':'epX','evidence_nodes': 5, 'evidence_edges': 5})
    # DB may be empty -> stability 0.0, expect fail
    assert not ok
