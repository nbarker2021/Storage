import sqlite3, math

DB = "rmi/snaplat.db"

def _conn():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def stability_for_endpoint(endpoint_id: str, horizon: int = 200) -> float:
    """Compute a coarse stability score in [0,1]:
    fraction of octants (1..8) where endpoint appears in the last `horizon` rows of i8_topk,
    weighted by average score rank. If DB absent, returns 0.0.
    """
    try:
        con = _conn(); cur = con.cursor()
        rows = cur.execute("SELECT octant, score FROM i8_topk WHERE choice_id=? ORDER BY created_at DESC LIMIT ?", (endpoint_id, horizon)).fetchall()
        if not rows:
            return 0.0
        by_oct = {}
        for r in rows:
            by_oct.setdefault(r['octant'], []).append(float(r['score'] or 0.0))
        coverage = len(by_oct) / 8.0
        avg_rank = 0.0
        for o, scores in by_oct.items():
            # normalize score into [0,1] via sigmoid-ish mapping
            s = sum(scores)/len(scores)
            avg_rank += 1/(1+math.exp(-2*(s-0.5)))
        avg_rank = avg_rank / max(1,len(by_oct))
        return max(0.0, min(1.0, 0.5*coverage + 0.5*avg_rank))
    except Exception:
        return 0.0
