from typing import Optional, List, Dict

def infer_domain_from_trails(trails: List[dict]) -> Optional[str]:
    """Heuristic domain inference from recent Trails payloads/kinds."""
    c = {"finance":0,"healthcare":0,"education":0,"governance":0,"physics":0,"systems":0}
    for t in trails[:200]:
        if not isinstance(t, dict): continue
        k = (t.get('kind') or '')
        p = (t.get('payload') or {})
        txt = (str(p) + ' ' + k).lower()
        if any(x in p for x in ('debits','credits','amount','currency')) or 'finance' in txt:
            c['finance'] += 1
        if any(x in p for x in ('patient_id','diagnosis','lab_results')) or 'healthcare' in txt:
            c['healthcare'] += 1
        if any(x in p for x in ('student_id','grades','transcript')) or 'education' in txt:
            c['education'] += 1
        if 'gcr.' in k or 'rbac.' in k or 'lawpack' in k or 'policy' in txt:
            c['governance'] += 1
        if 'overlay' in k or 'octant' in txt or 'physics' in txt:
            c['physics'] += 1
        if 'ops' in txt or 'scheduler' in txt or 'autotune' in txt:
            c['systems'] += 1
    # pick max nonzero
    best = max(c.items(), key=lambda kv: kv[1])
    return best[0] if best[1] > 0 else None
