
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from src.core.meta import SnapMeta
from src.core.trails import emit
import time, uuid

@dataclass
class TaskSpec:
    id: str
    title: str
    part: str
    source: str
    stage: str  # 'G3' | 'G6' | 'G9'
    action: str # 'wire_in' | 'review_fit'
    delta_u_score: float = 0.0
    requires_review: bool = True
    meta: Dict[str, Any] = field(default_factory=dict)

class ThinkTank(metaclass=SnapMeta):
    __role__='thinktank'; __version__='v0.1.0'
    def __init__(self):
        self.queue: List[TaskSpec] = []
    def add_tasks(self, tasks: List[TaskSpec]):
        self.queue.extend(tasks)
        emit('thinktank.add', n=len(tasks))
    def list_tasks(self) -> List[Dict[str, Any]]:
        return [asdict(t) for t in self.queue]
    def pop_next(self) -> Optional[TaskSpec]:
        if not self.queue: return None
        t = self.queue.pop(0)
        emit('thinktank.pop', id=t.id, action=t.action, stage=t.stage, part=t.part)
        return t
