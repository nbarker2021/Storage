
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional, Protocol
import math, random
from src.core.trails import emit
from src.core.meta import SnapMeta

@dataclass
class Predicate:
    name: str
    cost: float = 1.0
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Body:
    id: str
    features: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TriadRecord:
    members: Tuple[Body, Body, Body]
    predicates: List[Predicate]
    delta_u: float
    polarity_conflict: float
    witnesses: Dict[str, Any] = field(default_factory=dict)

@dataclass
class HexadInvariant:
    pos: Body
    neg: Body
    invariant: str
    margin: float
    counter_witnesses: Dict[str, Any] = field(default_factory=dict)

@dataclass
class EnneadPackage:
    facets: List[Body]
    lens_name: str
    mirror_pass: bool
    containment_c: float
    delta_u: float
    reversibility: bool
    witnesses: Dict[str, Any] = field(default_factory=dict)

class Lens(Protocol):
    name: str
    def evaluate(self, state: Dict[str, Any]) -> str: ...
    def pick_predicate(self, candidates: List[Predicate], state: Dict[str, Any]) -> Predicate: ...
    def score_reward(self, before: Dict[str, Any], after: Dict[str, Any]) -> float: ...

class BaseLens(metaclass=SnapMeta):
    __role__='lens'; __version__='v0.1.0'
    name='base'
    def evaluate(self, state): 
        if not state.get('mirror_pass', False): return 'refine'
        if state.get('polarity_conflict',1.0) > state.get('polarity_thresh',0.2): return 'refine'
        if state.get('containment_c',0.0) < state.get('c_thresh',0.7): return 'refine'
        return 'pass'
    def pick_predicate(self, candidates, state):
        def key(p): 
            du = p.meta.get('expected_du',0.0); cost = max(1e-6, p.cost)
            return -(du/cost), cost
        return sorted(candidates, key=key)[0]
    def score_reward(self, before, after):
        return (after.get('delta_u',0.0)-before.get('delta_u',0.0)) - 0.1*after.get('edbsu_growth',0.0)

class LegalityFirstLens(BaseLens):
    name='legality'; __version__='v0.1.0'
    def evaluate(self, state):
        if state.get('violates_policy', False): return 'fail'
        return super().evaluate(state)

class NoveltyFirstLens(BaseLens):
    name='novelty'; __version__='v0.1.0'
    def score_reward(self, before, after):
        return super().score_reward(before, after) + 0.2*after.get('novelty',0.0)

class SymmetryFirstLens(BaseLens):
    name='symmetry'; __version__='v0.1.0'
    def evaluate(self, state): return 'pass' if state.get('mirror_pass', False) else 'refine'

class LensBank(metaclass=SnapMeta):
    __role__='lens_bank'; __version__='v0.1.0'
    def __init__(self, lenses: List[Lens]):
        self.lenses=lenses; self.stats={L.name:{'n':0,'reward':0.0} for L in lenses}; self._t=0
    def select(self)->Lens:
        import math
        self._t += 1
        best, best_ucb = None, -1e9
        for L in self.lenses:
            s=self.stats[L.name]; n=max(1,s['n']); mean=s['reward']/n
            ucb=mean + math.sqrt(2.0*math.log(max(2,self._t))/n)
            if ucb>best_ucb: best_ucb, best = ucb, L
        return best
    def update(self, lens: Lens, reward: float):
        s=self.stats[lens.name]; s['n']+=1; s['reward']+=reward

class Gate369Engine(metaclass=SnapMeta):
    __role__='gate369'; __version__='v0.1.0'
    def __init__(self, lens_bank: LensBank, rng_seed: int=0, sop_manager=None, thinktank=None):
        self.lens_bank=lens_bank; self.rng=random.Random(rng_seed); self.sop_manager=sop_manager; self.thinktank=thinktank
    def acquisition_score(self, b: Body)->float:
        f=b.features
        return 1.0*f.get('du',0.0)+0.6*f.get('bridge',0.0)+0.5*f.get('weyl',0.0)+0.4*f.get('containment_gain',0.0)-0.2*f.get('cost',0.0)
    def gate3(self, bodies: List[Body], predicates: List[Predicate], ctx: Dict[str,Any]) -> TriadRecord:
        bodies=sorted(bodies, key=lambda b:-self.acquisition_score(b))[:8]
        triad=(bodies[0], bodies[1], bodies[2])
        lens=self.lens_bank.select()
        pred=lens.pick_predicate(predicates, ctx)
        du=sum(self.acquisition_score(b) for b in triad)*0.05
        pol=max(0.0, ctx.get('polarity_conflict',0.3)-0.05)
        rec=TriadRecord(triad, [pred], du, pol, {'lens':lens.name})
        # SOP pre/post (3-6-9 only)
        if self.sop_manager and self.thinktank:
            from src.snaplat.sop import SOPManager
            tasks = self.sop_manager.produce_tasks(stage_hint='G3')
            # strictly respect 3-6-9 filter: only auto-queue wire_in; others remain for review
            wire_in = [t for t in tasks if t.action=='wire_in']
            if wire_in:
                self.thinktank.add_tasks(wire_in)
        before=dict(ctx); after=dict(ctx, delta_u=du, polarity_conflict=pol)
        self.lens_bank.update(lens, lens.score_reward(before, after))
        emit('gate3', lens=lens.name, du=du, pol=pol, triad=[b.id for b in triad])
        return rec
    def gate6(self, triad: TriadRecord, bodies: List[Body], predicates: List[Predicate], ctx: Dict[str,Any]):\n        existing={b.id for b in triad.members}; remain=[b for b in bodies if b.id not in existing]\n        remain=sorted(remain, key=lambda b:-self.acquisition_score(b))[:6]\n        added=remain[:3]\n        pos=max(added, key=lambda b:b.features.get('variant_score',0.5))\n        neg=min(added, key=lambda b:b.features.get('variant_score',0.5))\n        inv=f\"I[{pos.id} vs {neg.id}]\"; margin=abs(pos.features.get('variant_score',0.5)-neg.features.get('variant_score',0.5))\n        emit('gate6', pos=pos.id, neg=neg.id, margin=margin)
        if self.sop_manager and self.thinktank:
            tasks = self.sop_manager.produce_tasks(stage_hint='G6')
            wire_in = [t for t in tasks if t.action=='wire_in']
            if wire_in:
                self.thinktank.add_tasks(wire_in)\n        return list(triad.members)+added, HexadInvariant(pos,neg,inv,margin,{})\n    def gate9(self, hexad: List[Body], lens: Lens, ctx: Dict[str,Any]) -> EnneadPackage:\n        added=sorted(hexad, key=lambda b:-b.features.get('weyl',0.0))[:2]\n        mirror=ctx.get('mirror_pass', True); contain=ctx.get('containment_c',0.7); du=ctx.get('delta_u',0.2); rev=True\n        pkg=EnneadPackage(facets=(hexad+added)[:8], lens_name=lens.name, mirror_pass=mirror, containment_c=contain, delta_u=du, reversibility=rev, witnesses={})\n        emit('gate9', lens=lens.name, mirror=mirror, c=contain, du=du)
        if self.sop_manager and self.thinktank:
            tasks = self.sop_manager.produce_tasks(stage_hint='G9')
            wire_in = [t for t in tasks if t.action=='wire_in']
            if wire_in:
                self.thinktank.add_tasks(wire_in)\n        return pkg\n