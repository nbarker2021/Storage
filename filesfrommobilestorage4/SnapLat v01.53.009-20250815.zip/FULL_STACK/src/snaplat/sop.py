# src/snaplat/sop.py
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Iterable, Tuple
import re, json, zipfile
from pathlib import Path
from src.core.trails import emit
from src.core.meta import SnapMeta

@dataclass
class AidCandidate:
    source: str
    part: str
    count: int
    snippets: List[str]

class AidDiscovery(metaclass=SnapMeta):
    __role__ = 'sop_aid_discovery'
    __version__ = 'v0.1.0'
    TERMS = [
        # core agents / engines
        r'\bThinkTank\b', r'\bDTT\b', r'\bAssemblyLine\b', r'\bMORSR\b', r'\bWavePool\b',
        r'\bPorter\b', r'\bMannequin\b', r'\bArchivist\b', r'\bSnap\s*Ops\s*Center\b',
        r'\bMDHG\b', r'\bAGRM\b', r'\bE-DBSU\b', r'\bSafe\s*Cube\b', r'\bGate-?3-?6-?9\b',
        # math / structure
        r'\bWeyl\b', r'\bE8\b', r'\bsuperperm(?:utation)?\b', r'\b1729\b', r'\bN=5\b',
        # review pipeline / safety
        r'\bpolarity\b', r'\bmirror\b', r'\bEcho<\w+>\b', r'\bPerspectiveShift\b',
        r'\bSnapPack\b', r'\bCSC\b', r'\bcheckpoint\s*safe\s*cube\b',
        # intake / RAG-ish
        r'\bexemplar\b', r'\bpolarity\s*annotator\b', r'\bRAG\b',
    ]

    def __init__(self, roots: List[Path]):
        self.roots = roots

    def _scan_text(self, text: str) -> Dict[str, Tuple[int, List[str]]]:
        found: Dict[str, Tuple[int, List[str]]] = {}
        for t in self.TERMS:
            for m in re.finditer(t, text, flags=re.IGNORECASE):
                key = t
                cnt, snips = found.get(key, (0, []))
                # capture a small snippet around match
                start = max(0, m.start()-60); end = min(len(text), m.end()+60)
                snips.append(text[start:end].replace('\n', ' '))
                found[key] = (cnt+1, snips[:3])  # keep up to 3 snippets
        return found

    def _yield_files(self) -> Iterable[Tuple[str, str]]:
        for root in self.roots:
            if root.is_file():
                yield (str(root), root.read_text(errors='ignore'))
            elif root.is_dir():
                for p in root.rglob("*"):
                    if p.suffix.lower() in {".txt", ".md", ".py", ".json"}:
                        try:
                            yield (str(p), p.read_text(errors='ignore'))
                        except Exception:
                            continue
                    elif p.suffix.lower() in {".zip"}:
                        try:
                            with zipfile.ZipFile(p, "r") as zf:
                                for zi in zf.infolist():
                                    if any(zi.filename.lower().endswith(ext) for ext in (".txt",".md",".json",".py")) and zi.file_size < 1_000_000:
                                        with zf.open(zi) as fh:
                                            try:
                                                text = fh.read().decode("utf-8", errors="ignore")
                                                yield (f"{p}!{zi.filename}", text)
                                            except Exception:
                                                continue
                        except Exception:
                            continue

    def scan(self) -> List[AidCandidate]:
        candidates: List[AidCandidate] = []
        for path, text in self._yield_files():
            hits = self._scan_text(text)
            for term, (cnt, snips) in hits.items():
                part = re.sub(r'\\b', '', term).strip('()')
                candidates.append(AidCandidate(source=path, part=part, count=cnt, snippets=snips))
        # emit trail summary
        emit("sop.aid_scan", total=len(candidates))
        return candidates

class SOPManager(metaclass=SnapMeta):
    __role__ = 'sop_manager'
    __version__ = 'v0.1.0'
    def __init__(self, discovery: AidDiscovery):
        self.discovery = discovery
    def pre_gate_check(self) -> List[AidCandidate]:
        cands = self.discovery.scan()
        emit("sop.pre_gate", candidates=len(cands))
        return cands
    def post_gate_check(self) -> List[AidCandidate]:
        # Could focus on newly added assets; keep simple for now
        cands = self.discovery.scan()
        emit("sop.post_gate", candidates=len(cands))
        return cands


    # 3-6-9 relevance filter & stage routing
    REL3 = (r'Gate-?3', r'\btriad\b', r'\bVariant', r'\bNeutral')
    REL6 = (r'Gate-?6', r'\bhexad\b', r'\binvariant', r'\bmax[- ]?margin')
    REL9 = (r'Gate-?9', r'\bennead\b', r'\bmirror', r'\bEcho<', r'\bWeyl', r'\bcenter', r'\blens', r'\bLens')
    ALL  = REL3 + REL6 + REL9

    def _stage_for(part: str) -> str:
        import re
        if any(re.search(p, part, flags=re.IGNORECASE) for p in REL3): return 'G3'
        if any(re.search(p, part, flags=re.IGNORECASE) for p in REL6): return 'G6'
        if any(re.search(p, part, flags=re.IGNORECASE) for p in REL9): return 'G9'
        return 'REVIEW'

    def _is_369_relevant(part: str) -> bool:
        import re
        return any(re.search(p, part, flags=re.IGNORECASE) for p in ALL)

    def _weight_delta_u(part: str, count: int) -> float:
        # heuristic weighting: mirror/Weyl/invariant higher; triad moderate
        pl = part.lower()
        base = 0.0
        if 'mirror' in pl or 'echo' in pl: base = 1.0
        elif 'weyl' in pl or 'lens' in pl: base = 0.9
        elif 'invariant' in pl: base = 0.85
        elif 'hexad' in pl: base = 0.8
        elif 'triad' in pl: base = 0.7
        elif 'gate-9' in pl: base = 0.95
        elif 'gate-6' in pl: base = 0.8
        elif 'gate-3' in pl: base = 0.7
        return round(base * (1 + 0.05*min(5, count)), 3)

    def produce_tasks(self, stage_hint: str = 'G3') -> List[TaskSpec]:
        from src.snaplat.thinktank import TaskSpec
        cands = self.pre_gate_check()
        tasks = []
        for c in cands:
            # filter to 3-6-9 relevance only
            if not _is_369_relevant(c.part):
                # create a review task but marked requires_review=True (explicitly not relevant yet)
                tasks.append(TaskSpec(
                    id=str(uuid.uuid4()), title=f"Review (non-369): {c.part}", part=c.part, source=c.source,
                    stage=stage_hint, action='review_fit', delta_u_score=0.0, requires_review=True,
                    meta={'snippets': c.snippets}
                ))
                continue
            stage = _stage_for(c.part)
            if stage == 'REVIEW':
                tasks.append(TaskSpec(
                    id=str(uuid.uuid4()), title=f"Review (unclear): {c.part}", part=c.part, source=c.source,
                    stage=stage_hint, action='review_fit', delta_u_score=0.0, requires_review=True,
                    meta={'snippets': c.snippets}
                ))
                continue
            du = _weight_delta_u(c.part, c.count)
            tasks.append(TaskSpec(
                id=str(uuid.uuid4()), title=f"Wire-in candidate: {c.part}", part=c.part, source=c.source,
                stage=stage, action='wire_in', delta_u_score=du, requires_review=False,
                meta={'snippets': c.snippets}
            ))
        emit("sop.tasks_built", total=len(tasks))
        return tasks
