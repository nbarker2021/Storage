from __future__ import annotations
import inspect, hashlib, time
class SnapMeta(type):
    _registry = {}
    _by_role = {}
    required_attrs = ('__role__','__version__')
    def __new__(mcls, name, bases, ns, **kw):
        cls = super().__new__(mcls, name, bases, ns, **kw)
        for a in mcls.required_attrs:
            if not hasattr(cls, a):
                raise TypeError(f'{name} missing {a}')
        source = inspect.getsource(cls) if hasattr(cls, '__module__') else repr(ns)
        setattr(cls, '__codehash__', hashlib.sha256(source.encode('utf-8','ignore')).hexdigest()[:16])
        setattr(cls, '__created_at__', time.time())
        key = (f"{cls.__module__}.{name}", getattr(cls,'__version__'))
        mcls._registry[key] = cls
        mcls._by_role.setdefault(getattr(cls,'__role__','generic'), {})[name] = cls
        return cls
