import hashlib, json, time
def fingerprint(payload): return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()[:24]
def class_fingerprint(cls): return fingerprint({'name':f'{cls.__module__}.{cls.__name__}','v':getattr(cls,'__version__','v0'),'h':getattr(cls,'__codehash__','NA')})
def instance_fingerprint(obj): return fingerprint({'cls':f'{obj.__class__.__module__}.{obj.__class__.__name__}','data':repr(obj.__dict__),'t':time.time()})
