_E=[]
def emit(event, **data):
    rec={'event':event, **data}
    _E.append(rec); return rec
def list_events(): return list(_E)
def clear(): _E.clear()
