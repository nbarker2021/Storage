# SOP — AidDiscovery & Pre/Post Gate Checks (v0.1)

**Purpose:** Make “look for any other system parts that could aid this task” a *built-in*, repeatable step before and after each gate (G₃/G₆/G₉) and at tick boundaries.

## Components
- `AidDiscovery`: scans configured roots (files, folders, zips) for references to system parts (ThinkTank, DTT, MORSR, WavePool, Porter, Mannequin, Archivist, MDHG, AGRM, E-DBSU, Safe Cube, Gate-3-6-9, Weyl, E8, superperm, 1729, N=5, polarity, Mirror/Echo, PerspectiveShift, SnapPack, CSC, exemplar, polarity annotator, RAG).
- `SOPManager`: runs `pre_gate_check()` and `post_gate_check()`; emits Trails.

## CLI
```
python bin/snaplat.py sop
python bin/snaplat.py sop --path /mnt/data/_repo_snaplat/src
```

## Integration
- **Pre-gate**: run AidDiscovery; if high-signal parts are found (e.g., MORSR/WavePool/Porter), route to ThinkTank to adjust plan.
- **Post-gate**: rescan to discover newly-relevant parts after changes; package findings into SnapPacks if they pass witnesses.

## Next
- Add weighting by ΔU/time contribution of each part; auto-create Tasks for ThinkTank with suggested wiring.

## Auto‑handoff to ThinkTank (3‑6‑9 only)
- `SOPManager.produce_tasks(stage_hint)` builds **TaskSpec**s from discovery **only** when the match is relevant to Gate‑3/6/9. Everything else becomes a **review_fit** task (requires explicit approval before use).
- `Gate369Engine.gate3/gate6/gate9` call SOP `produce_tasks()` and auto‑queue only **wire_in** tasks (369‑relevant) into ThinkTank; review tasks are listed but not queued.
- Weighting function estimates ΔU/time contribution (mirror/Weyl/lens > invariant > hexad > triad) and attaches it to TaskSpecs.
