# SOP→ThinkTank Auto‑handoff (3‑6‑9 only) — Tests (Stub)
- SOP produce_tasks filters non‑369 parts to `review_fit`
- Gate369Engine queues only `wire_in` tasks into ThinkTank
- ΔU weighting present and non‑negative
