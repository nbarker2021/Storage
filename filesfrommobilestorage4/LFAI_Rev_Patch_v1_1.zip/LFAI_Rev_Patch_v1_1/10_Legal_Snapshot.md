# 10 — Legal Snapshot

- **LICENSE:** see `/mnt/data/LICENSE.txt`
- **NOTICE:** see `/mnt/data/NOTICE.txt`
- **PERMISSION NOTICE TEMPLATE:** `/mnt/data/PERMISSION_NOTICE_TEMPLATE.md`
- **NDA Pack:** `/mnt/data/NDA_Pack_v1.zip`
- **Enforcement Guidance:** `/mnt/data/LICENSING_ENFORCEMENT.md`

**Recommendation:** dual‑license core spec under a permissive license with a **Field‑of‑Use Addendum** for commercial derivatives; protect branding and compliance test suite separately.
