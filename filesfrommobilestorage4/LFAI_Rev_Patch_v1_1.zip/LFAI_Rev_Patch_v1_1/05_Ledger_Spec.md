# 05 — Ledger Spec (Minimal)

Format: **NDJSON** — one JSON object per line.

Common fields:
- `t` (int): tick index
- `run_id` (str)
- `rest` (str): R2/R4/R8/R16/R64
- `phase13` (str): 13A or 13B
- `latches` (str of 8 bits)
- `epsilon` (float)
- `residues` (obj): e.g., {"m2":1,"m4":3,"m8":3,"m32":19,"m13":5}
- `crt_ok` (bool)
- `even` (bool)
- `delta_families` (array): e.g., ["M13","S(13A)"]
- `advance` (bool)
- `prev_hash` (hex)
- `hash` (hex)

**Determinism check:** re-run the same steps → recompute `hash`; must match exactly.
