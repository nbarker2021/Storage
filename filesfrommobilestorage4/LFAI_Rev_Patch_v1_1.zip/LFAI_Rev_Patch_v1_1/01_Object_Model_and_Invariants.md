# 01 — Object Model & Invariants (Unified Header)

Symbols you should use everywhere:

- **R** (Rest): mirror‑even palindromic template at the current dyadic rest (2/4/8/16/64).
- **Δ** (Delta): mirror‑odd difference layer(s); live state is **X = R ⊕ Δ**.
- **J** (Mirror involution): time‑reversal + π shift on each 2‑plane; **J² = id**; **J(R)=R**, **J(Δ) = −Δ**.
- **H = (H₁…H₈)** (Facet functionals): 8 witness faces (E₈‑style); facet i is “touched” if **Hᵢ(X) ≥ −ε**.
- **Π** (Cadence): the All‑8 gate policy—**advance** only after all 8 witnesses have latched at least once this sweep.
- **ρ = {ρ₂, ρ₄, ρ₈, ρ₃₂, ρ₁₃,…}** (Residue clocks): small‑mod congruence channels; stitched via CRT.
- **Even‑Lift (Return)**: any odd/type‑I overlay must be lifted to even/type‑II (shadow/even‑neighbor) *before* dynamics.
- **Screw identity**: order‑13 screw with frame‑shape (13A or 13B); phases consistent so replay hashes match.

Minimal legality check:
1) Type‑II (evenness) holds; 2) residue clocks are CRT‑coherent; 3) palindromic rest exists (J‑even); 4) All‑8 witnesses latch within the sweep.

**Determinism:** same inputs → same scan order → same latches → same ledger hash.  
**Replay:** rehydrate **X** from the ledger; hash must match.
