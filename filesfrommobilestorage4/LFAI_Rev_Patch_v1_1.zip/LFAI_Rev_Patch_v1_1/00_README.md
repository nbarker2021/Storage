# LFAI Revision Patch v1.1 — Reviewer Fixes

This patch adds the missing pieces flagged by peer review:

- **Unified object model & invariants** (shared vocabulary: R, Δ, J, H, Π, residue clocks, Even‑Lift).
- **Dyadic rests atlas** (2/4/8/16/64) in one place.
- **Concrete API examples** (payloads/responses) for `/rest/select`, `/delta/apply`, `/gate/scan`, `/advance`, `/anchor/match`, `/proof/state`.
- **Acceptance tests** that instantiate falsifiers **F3, F5, F6, F7, F9** (plus references to existing tests).
- **Toy demo**: a tiny, deterministic All‑8 gate cadence that emits a `ledger.ndjson` and a pixel‑free “rehydrated” proof (hash replay).
- **Tolerance guidance**: ε defaults and rationale.
- **CRT proof note**: how to prove residue coherence in logs.
- **Security/JWS stub**: where to plug the JWS addon; idempotency keys in examples.
- **Legal snapshot**: LICENSE, NOTICE references (link to your packs), plus a permissive **Permission Notice** template excerpt.

> Everything here is *spec-first*. The toy demo is intentionally simple and meant to exercise the cadence, witness latching, residue coherence, and replay hash.

**Version:** 1.1  
**Date:** 2025-09-17  
