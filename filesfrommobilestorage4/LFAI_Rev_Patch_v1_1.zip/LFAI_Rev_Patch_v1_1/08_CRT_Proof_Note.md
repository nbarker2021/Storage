# 08 — CRT Coherence Proof Note

Given residues `{m4, m8, m32}` we must have **compatibility**:

- `m8 ≡ m4 (mod 4)`
- `m32 ≡ m8 (mod 8)`

If any condition fails, set `crt_ok=false` and REJECT with `request_resync=true`.

**Logging suggestion:** include `crt_reconstruct`: the reconstructed residue (e.g., `m32*inv + …`) so an auditor can recompute.

See Acceptance **T_F6**: `{"residues":{"mod4":1,"mod8":6,"mod32":19}}` is inconsistent → REJECT.
