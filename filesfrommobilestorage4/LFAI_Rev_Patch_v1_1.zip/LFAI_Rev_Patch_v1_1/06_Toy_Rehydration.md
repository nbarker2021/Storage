# 06 — Toy Demo Rehydration

We do not render pixels in this demo; instead we assert determinism via the **ledger hash chain**.

**How to verify**
1. Read `toy_ledger.ndjson`.
2. Recompute each line’s hash from its JSON (sorted keys). It must match the stored `hash`.
3. The final hash is the **rehydration proof** for this toy.

In a full codec demo, this same cadence would drive the HTC‑13 predictor and invert back to pixels; identical inputs → identical frames → identical final hash (or identical image files).
