# 11 — Changelog (v1.1)

- Added unified object model header (R, Δ, J, H, Π, residue clocks, Even‑Lift).
- Added dyadic rests atlas page.
- Added concrete API examples (JSON).
- Added acceptance tests for F3/F5/F6/F7/F9.
- Added toy ledger + rehydration proof note.
- Added ε tolerance guidance and CRT proof note.
- Added Security/JWS stub and Legal snapshot.
