# 09 — Security & Keys (JWS Stub)

- **mTLS** between gateway and services.
- **Scoped JWTs** per overlay family (P/M/S/H/G/N); rotate via JWKS.
- **Idempotency‑Key** header on all write endpoints; examples included.
- **JWS addon hook:** plug `/mnt/data/LFAI_JWS_Addon_v1.zip` contents into the gateway; sign `ledger.ndjson` segments; attach `proof_state.signature`.

Abuse mitigations:
- Rate‑limit `/advance`.
- Refuse `/delta/apply` if `requires_even_lift=true`.
- Log `attempted_illegal_pulse=true` when a pulse lands without a witness (Acceptance **T_F9**).
