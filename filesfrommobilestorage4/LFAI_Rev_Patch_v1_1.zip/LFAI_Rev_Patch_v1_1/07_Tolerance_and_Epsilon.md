# 07 — Tolerance & ε Guidance

**Problem:** measure‑zero gating makes latches flap.  
**Fix:** use `Hᵢ(X) ≥ −ε` with a small positive ε.

- Default: **ε = 1e‑6** relative to normalized face scale.
- Rationale: avoids equality edge; robust to float noise.
- Test: Acceptance **T_F5** requires REJECT or STALL when ε=0 and a face sits at exact equality.

**Tip:** log `witness_margin[i] = Hᵢ(X)`; a persistent distribution near zero is a red flag.
