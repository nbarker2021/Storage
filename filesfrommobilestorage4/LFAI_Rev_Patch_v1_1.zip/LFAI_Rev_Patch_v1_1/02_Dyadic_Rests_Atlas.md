# 02 — Dyadic Rests Atlas (2/4/8/16/64)

**Rule:** pick the smallest rest that fits current activity (number of active 2‑planes, parity/CRT flags). 2/4 are views inside 8; 16/64 add structure without moving the center.

- **R₂** — one 2‑plane active; others suppressed; palindromic sub‑view.
- **R₄** — two 2‑planes active; k‑parity ordering enforced.
- **R₈** — full stage rest; four 2‑planes + groove + axis; primary even rest (Monster/Moonshine).
- **R₁₆** — tighten parity (doubly‑even); add binary Type‑II layer.
- **R₆₄** — dyadic + CRT refinements; 6‑bit hypercube of legal Δ‑cells around the same center.

**Atlas:** 8 legal 4‑tuple vertices around the palindromic vertex; local “best ordering” = nearest legal vertex.  
**Outside neighbors:** facet‑adjacent cells across one E₈ wall; context changes, center does not.
