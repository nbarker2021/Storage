
"""
Superpermutation SNAP Engine (v14)
- Seeds: atomic identifiers (any modality)
- Superperm index: records solved permutations (order-specific tuples of seed ids)
- Stitcher: builds new sequences from known sub-sequences; falls back to discovery
- Predictive: if a target sequence is seen, return it; else approximate via overlaps
"""
from __future__ import annotations
from typing import Dict, List, Tuple, Any
from collections import defaultdict

Seed = str
Sequence = Tuple[Seed, ...]

class SuperpermIndex:
    def __init__(self):
        # store counts & payloads for exact sequences and sub-sequences
        self.exact: Dict[Sequence, Dict[str, Any]] = {}
        self.substr: Dict[Tuple[Seed, Seed], int] = defaultdict(int)
        self.seed_meta: Dict[Seed, Dict[str, Any]] = {}

    def add_seed(self, seed: Seed, meta: Dict[str, Any] | None = None):
        self.seed_meta[seed] = dict(meta or {})

    def add_sequence(self, seq: Sequence, payload: Dict[str, Any] | None = None):
        self.exact[seq] = dict(payload or {})
        for a, b in zip(seq, seq[1:]):
            self.substr[(a, b)] += 1

    def seen(self, seq: Sequence) -> bool:
        return seq in self.exact

    def predict(self, seq: Sequence) -> Dict[str, Any] | None:
        """Return payload if exact; else suggest likely next element using bigram counts."""
        if seq in self.exact:
            return self.exact[seq]
        if not seq: 
            return None
        # next-token guess by bigram
        last = seq[-1]
        candidates = [(pair, c) for (pair, c) in self.substr.items() if pair[0] == last]
        if not candidates:
            return None
        _, _ = max(candidates, key=lambda x: x[1])
        # return a lightweight hint payload
        return {"hint": "approx", "next_seed": max(candidates, key=lambda x: x[1])[0][1]}

class Stitcher:
    def __init__(self, index: SuperpermIndex):
        self.idx = index

    def stitch(self, parts: List[Sequence]) -> Sequence:
        """Greedy overlap stitch: join sequences by maximal suffix/prefix match."""
        if not parts:
            return tuple()
        seq = list(parts[0])
        for p in parts[1:]:
            # find largest k such that seq[-k:] == p[:k]
            k = min(len(seq), len(p))
            overlap = 0
            for kk in range(k, 0, -1):
                if tuple(seq[-kk:]) == tuple(p[:kk]):
                    overlap = kk
                    break
            seq.extend(list(p[overlap:]))
        stitched = tuple(seq)
        # register stitched as a solved permutation
        self.idx.add_sequence(stitched, payload={"stitched": True, "parts": [list(x) for x in parts]})
        return stitched
