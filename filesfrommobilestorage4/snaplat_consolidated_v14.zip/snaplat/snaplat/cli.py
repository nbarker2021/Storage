
import typer, os, json
from typing import List
from .morsr.tick import tick
from .report.generate import generate
from .sap.lanes import ledger_tail, counts as lane_counts
from .repo.provenance import audit
from .repo.assumed_known import get_last_code_sid, save_snapshot, load_snapshot
from .report.diffstream import tail as difftail
from .repo.indices.hierarchy import policy_table
from .rag.superperm_rag import SuperpermRAG

app = typer.Typer(help="SNAPLAT Consolidated CLI (v14)")

def _parse_faces(face: List[str] | None):
    faces = {}
    for f in face or []:
        if "=" in f:
            k, v = f.split("=", 1)
            faces[k.strip()] = v.strip()
    return faces

@app.command(name="tick-cmd")
def tick_cmd(
    ticks: int = 1,
    face: List[str] = typer.Option(None, "--face", help="Override face as key=value, e.g., policy=amber"),
    actor: str = typer.Option("system", "--actor"),
    tool: str = typer.Option("planner", "--tool"),
    promote: str = typer.Option("", "--promote", help="Promotion hint: shadow|silver|gold"),
    tick_rate_hz: float = typer.Option(5.0, "--tick-rate-hz", help="Tick rate profile to drive compression depth"),
):
    ctx = {"force_faces": _parse_faces(face), "actor": actor, "tool": tool, "promote": promote, "tick_rate_hz": tick_rate_hz}
    last = None
    for _ in range(ticks):
        last = tick(ctx)
        typer.echo(f"Tick: decision={last['decision']}, faces={last['faces']}, lanes={last.get('lane_counts')}, tick_rate_hz={tick_rate_hz}")
    return 0

@app.command()
def report(
    face: List[str] = typer.Option(None, "--face", help="Override face key=value"),
    actor: str = typer.Option("system", "--actor"),
    tool: str = typer.Option("planner", "--tool"),
    promote: str = typer.Option("", "--promote", help="Promotion hint: shadow|silver|gold"),
    tick_rate_hz: float = typer.Option(5.0, "--tick-rate-hz"),
):
    ctx = {"force_faces": _parse_faces(face), "actor": actor, "tool": tool, "promote": promote, "tick_rate_hz": tick_rate_hz}
    summary = tick(ctx)
    doc = generate(summary)
    typer.echo(doc)

@app.command()
def ledger(tail: int = typer.Option(20, "--tail", min=1, max=100)):
    for entry in ledger_tail(tail):
        typer.echo(entry)
    typer.echo({"lanes": lane_counts()})

@app.command()
def auditlog(artifact: str = typer.Option(None, "--artifact", help="Artifact id (e.g., code:stub:0001)")):
    aid = artifact or get_last_code_sid()
    if not aid:
        typer.echo("No artifact available."); raise typer.Exit(code=1)
    for t in audit(aid): typer.echo(t)
    typer.echo(aid)

@app.command()
def snapshot_save(path: str = typer.Option("snapshots/aki.json", "--path"), key: str = typer.Option("demo-key", "--key")):
    p = save_snapshot(path, key=key); typer.echo(f"Saved snapshot to {p} and {p}.sig")

@app.command()
def snapshot_load(path: str = typer.Option("snapshots/aki.json", "--path"), key: str = typer.Option("demo-key", "--key")):
    stats = load_snapshot(path, key=key); typer.echo({"loaded": path, "stats": stats})

@app.command()
def diffs(tail: int = typer.Option(20, "--tail", min=1, max=100)):
    for d in difftail(tail): typer.echo(d)

@app.command()
def policy(show: bool = typer.Option(True, "--show", help="Show policy face→tier map")):
    if show: import json; typer.echo(json.dumps(policy_table(), indent=2))

# --- RAG commands ---
_rag = SuperpermRAG()

@app.command()
def rag_index(doc_id: str, path: str):
    with open(path, "r") as f:
        txt = f.read()
    _rag.index_doc(doc_id, txt)
    typer.echo(f"Indexed {doc_id} ({len(txt.split())} tokens)")

@app.command()
def rag_query(query: str):
    hits = _rag.retrieve(query, topk=5)
    typer.echo({"hits": hits})

@app.command()
def rag_generate(prompt: str):
    out = _rag.generate(prompt)
    typer.echo(json.dumps(out, indent=2))

if __name__ == "__main__":
    app()
