
from typing import Dict, Any
import uuid
from ..agrm.recall import decide
from ..sap.typed_leakage import evaluate, all_faces_green
from ..assembly.code_ingest import ingest_code_snippet
from ..assembly.glyph_ingest import ingest_glyph
from ..repo.assumed_known import assumed_known, stats as aki_stats, get_last_code_sid
from ..repo.provenance import stamp_artifact, audit_stats
from ..sap.lanes import promote, ledger_tail, counts as lane_counts
from ..repo.indices.hierarchy import validate_promotion
from ..repo.indices.meta_index import register as meta_register

_ORDER = {"shadow":0,"silver":1,"gold":2}

def tick(ctx: Dict[str, Any]) -> Dict[str, Any]:
    actor = ctx.get("actor", "system")
    tool = ctx.get("tool", "planner")
    tick_id = ctx.get("tick_id") or str(uuid.uuid4())
    promote_hint = (ctx.get("promote") or "").lower()
    tick_rate_hz = float(ctx.get("tick_rate_hz", 5.0))

    decision, info = decide(ctx)
    faces = evaluate({"ctx": ctx, "decision": decision})
    snap = None
    ledger = []

    def _promote_with_index(sid: str, desired: str, reason: str, watermark: dict | None = None):
        v = validate_promotion(sid, faces, desired)
        meta = meta_register(sid, v["target"], tick_rate_hz, payload={"sid": sid, "faces": faces, "reason": reason})
        return promote(sid, to=v["target"], actor=actor, reason=f"{reason}; {v['reason']}", index_id=meta["index_id"], watermark=watermark)

    if decision == "compute":
        snap = ingest_code_snippet("def hello():\n    return 'world'", doc="stub", actor=actor, tool=tool, tick_id=tick_id)
        wm = snap.dna.get("watermark")
        desired = "silver" if all_faces_green(faces) else "shadow"
        ledger.append(_promote_with_index(snap.sid, desired, "first-compute", watermark=wm))
        ingest_glyph("glyph:stub:0001")
    else:
        hit = info.get("hit")
        if isinstance(hit, dict) and "sid" in hit:
            sid = hit["sid"]
            wm = stamp_artifact(sid, actor=actor, tool=tool, tick_id=tick_id, payload=str(hit), purpose="recall", runtime_context={"faces": faces})
            desired = "gold" if all_faces_green(faces) else "silver"
            if promote_hint in ("gold","silver","shadow"):
                desired = promote_hint if _ORDER.get(promote_hint,0) <= _ORDER.get(desired,2) else desired
            ledger.append(_promote_with_index(sid, desired, f"recall-{decision}", watermark=wm))

    ak = assumed_known(ctx)
    return {
        "decision": decision,
        "faces": faces,
        "snap": snap.model_dump() if snap else None,
        "aki_stats": aki_stats(),
        "last_code_sid": get_last_code_sid(),
        "ledger": ledger_tail(10) if ledger else [],
        "lane_counts": lane_counts(),
        "audit_stats": audit_stats(),
        "tick_id": tick_id,
        "actor": actor,
        "tool": tool,
        "tick_rate_hz": tick_rate_hz,
    }
