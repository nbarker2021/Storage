
from __future__ import annotations
from typing import Dict, List, Literal, Optional
import time
from ..repo.provenance import touch
from ..report.diffstream import push as push_diff

Lane = Literal["shadow","silver","gold"]
_STATE: Dict[str, Lane] = {}
_LEDGER: List[dict] = []

def lane_of(sid: str) -> Lane: return _STATE.get(sid, "shadow")

def promote(sid: str, to: Lane, actor: str, reason: str = "", index_id: Optional[str] = None, watermark: Optional[dict] = None) -> dict:
    prev = lane_of(sid)
    order = {"shadow": 0, "silver": 1, "gold": 2}
    if order[to] < order[prev]:
        entry = {"sid": sid, "from": prev, "to": prev, "ts": int(time.time()*1000), "actor": actor, "reason": "noop-demote-blocked", "index_id": index_id}
        _LEDGER.append(entry); touch(sid, {"event":"promote_skip", **entry}); push_diff({"type":"ledger-skip", **entry})
        return entry
    entry = {"sid": sid, "from": prev, "to": to, "ts": int(time.time()*1000), "actor": actor, "reason": reason, "index_id": index_id}
    if isinstance(watermark, dict): entry["watermark"] = watermark
    _STATE[sid] = to; _LEDGER.append(entry)
    touch(sid, {"event": "promote", **entry}); push_diff({"type": "ledger", **entry})
    return entry

def ledger_tail(n: int = 10) -> List[dict]: return _LEDGER[-n:]
def counts() -> Dict[str, int]:
    c = {"shadow":0,"silver":0,"gold":0}
    for v in _STATE.values(): c[v]+=1
    return c
