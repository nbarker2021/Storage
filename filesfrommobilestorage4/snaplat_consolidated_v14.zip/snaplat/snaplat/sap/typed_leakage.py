
from typing import Dict, Literal
Color = Literal["green","amber","red"]
DEFAULT: Dict[str, Color] = {"privacy":"green","policy":"green","numeric":"green","semantic":"green"}

def evaluate(evidence: dict) -> Dict[str, Color]:
    ctx = evidence.get("ctx", {}) if isinstance(evidence, dict) else {}
    override = ctx.get("force_faces") if isinstance(ctx, dict) else None
    if isinstance(override, dict):
        faces = DEFAULT.copy()
        for k, v in override.items():
            if k in faces and v in ("green","amber","red"):
                faces[k] = v
        return faces
    return DEFAULT.copy()

def all_faces_green(faces: Dict[str, Color]) -> bool:
    return all(v == "green" for v in faces.values())
