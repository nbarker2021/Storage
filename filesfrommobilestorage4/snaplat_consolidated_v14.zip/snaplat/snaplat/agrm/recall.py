
from typing import Literal, Tuple, Dict, Any
from ..repo import assumed_known as AKI

RecallDecision = Literal["exact","symmetric","approx","compute"]

def decide(ctx: Dict[str, Any]) -> Tuple[RecallDecision, Dict[str, Any]]:
    ak = AKI.assumed_known(ctx)
    if ak.get("codeSnaps"): return "exact", {"hit": ak["codeSnaps"][0]}
    if ak.get("glyphs"): return "exact", {"hit": ak["glyphs"][0]}
    sym = AKI.query_code_symmetric(ctx)
    if sym: return "symmetric", {"hit": sym[0]}
    apx = AKI.query_code_approx(ctx)
    if apx: return "approx", {"hit": apx[0]}
    return "compute", {"reason": "no hits"}
