
"""
Superperm RAG (v14)
- Tokenizes text into seeds (simple whitespace/token stub)
- Builds superpermutation sequences per document & paragraph
- Retrieval: use seed bigrams/overlaps to rank relevant docs
- Generation: stitch known sequences to produce answers with traceability
- Shell/Glyph stubs: glyphify() groups tokens; shell() forms outer structure hints
"""
from __future__ import annotations
from typing import List, Dict, Any, Tuple
from collections import Counter, defaultdict
from ..snap.superperm import SuperpermIndex, Stitcher, Sequence

def tokenize(text: str) -> List[str]:
    # simple stub tokenizer; replace with real BPE later
    return [t for t in text.strip().split() if t]

def glyphify(tokens: List[str]) -> List[str]:
    # stub: group by lowercase stems
    return [t.lower().strip(".,!?") for t in tokens]

def shell(tokens: List[str]) -> Dict[str, Any]:
    # stub shell: length, unique, bigrams
    bigrams = list(zip(tokens, tokens[1:]))
    return {"length": len(tokens), "unique": len(set(tokens)), "bigrams": bigrams[:8]}

class SuperpermRAG:
    def __init__(self):
        self.idx = SuperpermIndex()
        self.docs: Dict[str, Dict[str, Any]] = {}
        self.doc_sequences: Dict[str, List[Sequence]] = {}

    def index_doc(self, doc_id: str, text: str):
        tokens = tokenize(text)
        glyphs = glyphify(tokens)
        sh = shell(tokens)
        # seed registration
        for g in glyphs:
            self.idx.add_seed(g)
        # sequences per sentence/paragraph (simple split by period)
        parts = [p.strip() for p in text.split(".") if p.strip()]
        seqs: List[Sequence] = []
        for p in parts:
            tt = glyphify(tokenize(p))
            if not tt: 
                continue
            seq = tuple(tt)
            seqs.append(seq)
            self.idx.add_sequence(seq, payload={"doc": doc_id, "span": p})
        self.docs[doc_id] = {"shell": sh, "glyphs": glyphs, "len": len(tokens)}
        self.doc_sequences[doc_id] = seqs

    def retrieve(self, query: str, topk: int = 3) -> List[Tuple[str, float]]:
        q = glyphify(tokenize(query))
        # score by bigram overlap against doc sequences
        q_bigrams = set(zip(q, q[1:]))
        scores: Dict[str, float] = defaultdict(float)
        for doc_id, seqs in self.doc_sequences.items():
            overlap = 0
            for s in seqs:
                s_bigrams = set(zip(s, s[1:]))
                overlap += len(q_bigrams & s_bigrams)
            scores[doc_id] = overlap
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return ranked[:topk]

    def generate(self, prompt: str) -> Dict[str, Any]:
        """Stitch top matching sequences into an answer, with traceability."""
        hits = self.retrieve(prompt, topk=3)
        parts: List[Sequence] = []
        for doc_id, _ in hits:
            parts.extend(self.doc_sequences.get(doc_id, [])[:1])
        stitched = Stitcher(self.idx).stitch(parts) if parts else tuple()
        text = " ".join(stitched)
        return {"text": text, "stitched": list(map(list, parts)), "trace": {"hits": hits}}
