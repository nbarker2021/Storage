
from pydantic import BaseModel, Field
from typing import List, Dict, Literal, Optional, Tuple

Lane = Literal["shadow","silver","gold"]
Face = Literal["privacy","policy","numeric","semantic"]

class LatticeKey(BaseModel):
    cell: str = "E8:0"
    edges: List[int] = []
    shell: int = 0
    cox2d: Tuple[float,float] = (0.0,0.0)
    anchor: str = "origin"

class Detector(BaseModel):
    name: str
    score: float = 0.0

class SAPFaces(BaseModel):
    verdict: Literal["ACCEPT","REJECT"] = "ACCEPT"
    faces: Dict[Face, Literal["green","amber","red"]] = {
        "privacy":"green","policy":"green","numeric":"green","semantic":"green"
    }

class SNAP(BaseModel):
    sid: str
    op: str
    inputs: Dict[str, List[str]] = {}
    outputs: Dict[str, str] = {}
    lk: LatticeKey = LatticeKey()
    delta_phi: float = Field(0.0, alias="deltaPhi")
    detectors: List[Detector] = []
    fusion: Dict[str, float] = {}
    sap: SAPFaces = SAPFaces()
    lane: Lane = "shadow"
    ttl: Optional[int] = None
    trust: Optional[str] = None
    dna: Dict[str, str] = {}

class CodeSNAP(SNAP):
    ast: str = ""
    source: str = ""
    signature: str = ""
    types: Dict[str, str] = {}
    doc: str = ""
    tests: List[str] = []
    contracts: List[str] = []
    effects: Dict[str, bool] = {"io": False, "net": False, "fs": False}
    perf: Dict[str, float] = {"p50": 0.0, "p95": 0.0}
    license: Dict[str, str] = {"spdx": "MIT"}
