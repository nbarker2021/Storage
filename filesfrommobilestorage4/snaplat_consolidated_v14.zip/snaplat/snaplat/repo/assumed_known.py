
"""Repo.assumed_known — v12"""
from __future__ import annotations
from typing import Dict, List, Any, Optional
import json, os, hmac, hashlib
from .schemas import LatticeKey, CodeSNAP

_AKI: Dict[str, Any] = {"code": {}, "glyphs": {}}

def reset() -> None:
    _AKI["code"].clear(); _AKI["glyphs"].clear()

def insert_code_snap(snap: CodeSNAP) -> None:
    _AKI["code"][snap.sid] = snap.model_dump()

def insert_glyph(gid: str, payload: dict | None = None) -> None:
    _AKI["glyphs"][gid] = dict(payload or {"gid": gid, "triad": ["a","b","c"], "inverse": ["c","b","a"]})

def stats() -> Dict[str, int]:
    return {"code": len(_AKI["code"]), "glyphs": len(_AKI["glyphs"])}

def get_last_code_sid() -> Optional[str]:
    if not _AKI["code"]: return None
    return list(_AKI["code"].keys())[-1]

def get_last_code_watermark() -> Optional[str]:
    sid = get_last_code_sid()
    if not sid: return None
    dna = _AKI["code"][sid].get("dna", {})
    return dna.get("watermark")

def query_code(ctx: dict) -> List[dict]: return list(_AKI["code"].values())
def query_code_symmetric(ctx: dict) -> List[dict]:
    out=[]; 
    for v in _AKI["code"].values():
        vv=dict(v); vv["_sym"]=True; out.append(vv)
    return out
def query_code_approx(ctx: dict) -> List[dict]:
    vals=list(_AKI["code"].values()); return [vals[0]] if vals else []
def query_glyphs(ctx: dict) -> List[dict]: return list(_AKI["glyphs"].values())

def assumed_known(ctx: dict) -> dict:
    return {
        "glyphs": query_glyphs(ctx),
        "codeSnaps": query_code(ctx),
        "anchors": [LatticeKey().model_dump()],
        "lk_hints": [LatticeKey().model_dump()],
        "faces": {"privacy":"green","policy":"green","numeric":"green","semantic":"green"},
        "stats": stats(),
        "last_code_sid": get_last_code_sid(),
    }

# HMAC snapshots
def _sign(data: bytes, key: bytes) -> str:
    return hmac.new(key, data, hashlib.sha256).hexdigest()

def save_snapshot(path: str, key: str = "demo-key") -> str:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    payload = json.dumps(_AKI, sort_keys=True).encode()
    sig = _sign(payload, key.encode())
    with open(path, "wb") as f: f.write(payload)
    with open(path + ".sig", "w") as f: f.write(sig)
    return path

def load_snapshot(path: str, key: str = "demo-key") -> Dict[str, int]:
    if not os.path.exists(path): return stats()
    with open(path, "rb") as f: payload = f.read()
    with open(path + ".sig", "r") as f: sig = f.read().strip()
    calc = _sign(payload, key.encode())
    if sig != calc: raise ValueError("AKI snapshot signature mismatch — refusing to load")
    data = json.loads(payload.decode())
    if isinstance(data, dict):
        _AKI["code"] = dict(data.get("code", {}))
        _AKI["glyphs"] = dict(data.get("glyphs", {}))
    return stats()
