
from __future__ import annotations
import hashlib, time
from typing import Dict, Any, List

_AUDIT: Dict[str, List[dict]] = {}

def _fingerprint(payload: str) -> str:
    return hashlib.sha3_256(payload.encode()).hexdigest()[:24]

def stamp_artifact(artifact_id: str, actor: str, tool: str, tick_id: str, payload: str,
                   purpose: str = "unspecified", runtime_context: dict | None = None) -> dict:
    wm = {
        "artifact": artifact_id,
        "actor": actor,
        "tool": tool,
        "tick": tick_id,
        "purpose": purpose,
        "runtime_context": runtime_context or {},
        "fingerprint": _fingerprint(payload),
        "ts": int(time.time() * 1000),
        "signature": "attest:set1:v11",
    }
    touch(artifact_id, {"event": "watermark", **wm})
    return wm

def touch(artifact_id: str, meta: dict) -> None:
    _AUDIT.setdefault(artifact_id, []).append(dict(meta))

def audit(artifact_id: str) -> List[dict]:
    return list(_AUDIT.get(artifact_id, []))

def audit_stats() -> Dict[str, int]:
    return { "artifacts": len(_AUDIT), "touches": sum(len(v) for v in _AUDIT.values()) }
