
from __future__ import annotations
import json, time
from typing import Tuple, Any

def decide_depth(tick_rate_hz: float) -> str:
    return "shallow" if tick_rate_hz > 10.0 else "deep"

def compress(obj: Any, depth: str) -> Tuple[bytes, dict]:
    t0 = time.time()
    if depth == "shallow":
        data = json.dumps(obj).encode()
    else:
        data = json.dumps({"_deep": True, "payload": obj}).encode()
    meta = {"depth": depth, "ms": (time.time() - t0) * 1000.0}
    return data, meta

def decompress(buf: bytes, depth: str) -> Tuple[Any, dict]:
    t0 = time.time()
    obj = json.loads(buf.decode())
    if depth == "deep" and isinstance(obj, dict) and "_deep" in obj:
        obj = obj.get("payload")
    meta = {"depth": depth, "ms": (time.time() - t0) * 1000.0}
    return obj, meta
