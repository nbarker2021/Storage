
from ..repo.assumed_known import insert_glyph
def ingest_glyph(gid: str) -> str:
    insert_glyph(gid, payload=None); return gid
