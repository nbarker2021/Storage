
from snaplat.morsr.tick import tick

def test_watermark_persists_into_meta_index_preview():
    out = tick({"actor":"ops","tool":"planner","force_faces":{"policy":"green"}, "tick_rate_hz": 2})
    preview = out.get("index_preview") or {}
    assert isinstance(preview, dict)
    selfp = preview.get("self") or {}
    assert "watermark" in selfp
