
from snaplat.snap.superperm import SuperpermIndex, Stitcher

def test_stitcher_registers_sequence():
    idx = SuperpermIndex()
    a = ("a","b","c"); b = ("c","d")
    s = Stitcher(idx).stitch([a,b])
    assert s == ("a","b","c","d")
    assert idx.seen(s) is True
