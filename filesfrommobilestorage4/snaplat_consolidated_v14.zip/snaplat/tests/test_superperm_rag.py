
from snaplat.rag.superperm_rag import SuperpermRAG

def test_rag_index_and_generate():
    rag = SuperpermRAG()
    rag.index_doc("d1", "Alpha beta. Beta gamma.")
    rag.index_doc("d2", "Gamma delta. Delta epsilon.")
    out = rag.generate("beta gamma")
    assert isinstance(out, dict)
    assert "text" in out
