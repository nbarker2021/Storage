
from snaplat.morsr.tick import tick

def test_catalog_stats_increment():
    a = tick({"actor":"ops","tool":"planner","force_faces":{"policy":"green"}})
    b = tick({"actor":"ops","tool":"planner","force_faces":{"policy":"green"}})
    stats = b.get("catalog_stats") or {}
    assert "best" in stats
