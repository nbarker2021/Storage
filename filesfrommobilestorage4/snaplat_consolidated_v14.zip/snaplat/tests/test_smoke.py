
from snaplat.morsr.tick import tick
def test_smoke():
    out = tick({"actor":"ops","tool":"planner"})
    assert 'decision' in out and 'faces' in out
