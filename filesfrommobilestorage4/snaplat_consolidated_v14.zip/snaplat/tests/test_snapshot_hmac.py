
import os, tempfile
from snaplat.repo.assumed_known import reset, insert_code_snap, save_snapshot, load_snapshot, stats
from snaplat.repo.schemas import CodeSNAP

def test_snapshot_hmac_roundtrip_and_fail_closed():
    reset()
    s = CodeSNAP(sid="code:z", op="code.ingest", source="def z(): pass")
    insert_code_snap(s)
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "aki.json")
        save_snapshot(p, key="k1")
        # ok load
        load_snapshot(p, key="k1")
        assert stats()["code"] == 1
        # tamper
        with open(p, "rb") as f: data = f.read()
        with open(p, "wb") as f: f.write(data.replace(b"pass", b"return 1"))
        try:
            load_snapshot(p, key="k1")
            assert False, "should have failed on HMAC mismatch"
        except ValueError:
            pass
