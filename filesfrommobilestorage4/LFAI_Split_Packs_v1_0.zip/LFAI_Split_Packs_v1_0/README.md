# LFAI Support Pack v1.0 — Split Edition (UTC 2025-09-16T22:56:52Z)

Three bundles tailored by audience:
- `exec/` — Executive Brief (policy, results snapshot, proofs summary, API map).
- `eng/` — Engineering Implementer Guide (algorithms, run-loop, API, example, falsifiers).
- `audit/` — Audit & Governance Dossier (contracts, NTER pins, replay recipe, reporting).
- `machine_readable/` — GAE/CEC examples, worked-example ledger NDJSON.
- `manifests/` — case-study results manifests NDJSON.

All HTML files are print-ready for PDF export.
