# LFAI Audit & Governance Dossier — v1.0 (UTC 2025-09-16T22:56:52Z)

## Contracts & States
- **GAE‑1 (Attestation):** NGD (thresholds, scale, residues, faces, witnesses, evidence?), provenance, ngd_sha256, signatures.  
- **CEC‑1 (Execution):** corridor mods, gates, falsifiers, λ, ledger.bind, evidence.required, cec_b3, signatures.  
- **States:** UNATTESTED → ATTESTED → READY → LD.GATE {OPEN | CLOSE with NTER}.

## Evidence & Pins (NTER)
Gate remains CLOSED until required pins are satisfied; use the pin catalog block on every result.


**Pin & Evidence Legend**  
- ✅ satisfied, ⏳ pending, ✖ failed  
- Example pins: `atm_density_known`, `dv_budget_known`, `pressure_gpa>=2.0`, `temperature_c>=10`  
- Dual-witness required (e.g., structural parity + timing-13)


## Replay & Audit Recipe
1) Recompute residues for all m∈𝓜; compute syndrome and pal defects.  
2) Verify Type‑II evenness + canonical coset.  
3) Check monotone ↓Φ across ledger.  
4) Stitch via CRT; confirm NF equals committed `normal_form`.  
5) Verify Merkle root + `frame_hash` + `nf_hash`.

## Scoreboard & Reporting
- legality‑rate, confluence‑hash, ECC radius, time‑to‑REST, energy/commit, undecidable/extension rate, cross‑frame rejections.  
- Publish falsifier outcomes F1–F6.

## Example Manifests
- Navigation: PROVISIONAL‑OPEN (atm_density_known⏳, dv_budget_known⏳).  
- Ice Phase: OPEN (pressure_gpa≥2.0✅, temperature_c≥10✅).  
- Codon Duplex: OPEN (symbolic).


**Prime-Arm Legend**  
- 2/4/8 → parity & palindromy  
- 13 → timing/rate arm (default ON)  
- 24 → Golay/Leech legality  
- 3/5/7/11 → optional lanes activated by glyphs


## Compliance Notes
- Cross‑frame queries are illegal; return `E_ILLEGAL_FRAME_BRIDGE`.  
- `E_UNDECIDABLE_IN_FRAME` must include machine‑readable `proposed_extension` with priced costs; require signatures to adopt.
