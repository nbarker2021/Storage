# LFAI Engineering Implementer Guide — v1.0 (UTC 2025-09-16T22:56:52Z)

## Core Data Model
- **State:** x ∈ ℤⁿ (integerized latent).  
- **Frame:** F = ⟨τ,S,𝓜,𝓕⟩ compiled from numeric glyphs; 13‑arm ON by default.  
- **CRT:** compute residues for all m∈𝓜; stitch via CRT.  
- **Violation vector:** Φ(x)=(wt(s), P₈, P₄, ρ), lex ordered.

## Legality Tests (executable)
1. Syndrome s=H(x mod 2)^T; require wt(s)=0.  
2. Evenness: ||x||² ≡ 0 (mod 2).  
3. Unimodular canonical rep in coset x+2C (lexicographic min).  
4. Palindromy: P₄≤θ₄, P₈≤θ₈ (strict default 0/0; noisy allowed).

## Executor Run‑Loop
K‑scan → compile F → residues → Con‑A lift → λ‑band smooth (λ≈0.655) → Seven‑Witness verify → ledger → reduce (strict ↓Φ) → commit once (NF).

## Deterministic API
- POST /frame → compile F (returns frame_hash)  
- POST /verify → verdict + witnesses  
- POST /reduce → {move_id, before_Φ, after_Φ, reason}  
- POST /commit → {normal_form, nf_hash, merkle_root}  
- POST /store / /retrieve → invariant‑keyed (frame,shell,coset)  
- POST /extend → minimal ΔF + cost_bits + cost_ops (signed)

## Worked Example

### Worked Example (8‑dim)
Input x = [13,7,9,2,18,5,1,12], glyphs [25,13,32,4] ⇒ τ=1/4, S=64, 𝓜={2,4,8,32,5,13,25}.  
- Projection: syndrome≠0, P₄=3, P₈=5 ⇒ ACTION, Φ=(4,5,3,ρ).  
- Reductions (commuting): idx4:2→3; idx6:5→6; idx7:1→0.  
- Re‑verify: syndrome=0; P₄=0; P₈=0 ⇒ REST; commit once; key=(frame, shell k, coset 11110000).


## Falsifiers & Benchmarks

### Falsifiers & Metrics
F1 Confluence break; F2 Mirage‑Type‑II; F3 Pal failure; F4 Invariance breach; F5 Energy regression; F6 Retrieval regression.  
**Scoreboard:** legality‑rate | confluence‑hash | ECC radius | time‑to‑REST | energy/commit | extension rate | cross‑frame rejections.


## Security & Privacy

### Security & Privacy
- Export verdicts + Φ deltas; avoid raw residues (or add DP).  
- Multi‑lane checks thwart single‑channel spoofing.  
- `extend` requires signatures; lane costs reported in bits/ops.

