
# Intake & Handoff Guide
- Install, initialize schemas, set beacons, choose stance.
- Run: name->shell resolve; stitch; report with provenance; governance approvals; archive.
- Incident response, SLOs, escalation, contacts.
