from snaplat.detensor.core import clamp, DetensorBudget
def main():
    w = [0.25,0.25,0.25,0.25] + [1e-8]*64
    rep = clamp(w, DetensorBudget(max_rank=8, max_growth=1.5))
    print(rep)
if __name__ == "__main__":
    main()
