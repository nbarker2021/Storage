
from snaplat.superperm.nav_tsp import tsp_on_root_shell
from snaplat.morsr.log import file_checksum
import json, os
if __name__ == "__main__":
    res = tsp_on_root_shell(sample=64)
    artdir = os.path.join(os.getcwd(), "artifacts")
    os.makedirs(artdir, exist_ok=True)
    out = os.path.join(artdir, "tsp_root64.json")
    with open(out, "w") as f:
        json.dump(res, f, indent=2)
    print(out)
