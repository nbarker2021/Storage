from snaplat.mdhg.bus import MDHGBus
from snaplat.adapters.rag_adapter import RAGAdapter
from snaplat.agrm.plan_adapter import Action

def main():
    bus = MDHGBus()
    rag = RAGAdapter(bus)
    schedule = [rag.actions()["index_sample"], rag.actions()["query_probe"], rag.actions()["consolidate"]]
    trail = rag.step(schedule, {"docs_total": 5000, "docs_touched": 800, "index_drift": 0.05, "tac":0.97, "policy_boundary":0.92})
    print({"metrics": trail.metrics, "notes": trail.notes})

if __name__ == "__main__":
    main()
