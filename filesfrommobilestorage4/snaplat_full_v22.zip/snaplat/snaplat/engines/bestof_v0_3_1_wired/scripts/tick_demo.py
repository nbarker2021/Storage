import json
from snaplat.mdhg.bus import MDHGBus
from snaplat.adapters.e8_adapter import E8Adapter
from snaplat.adapters.dtt_adapter import DTTAdapter
from snaplat.adapters.assembly_adapter import AssemblyAdapter
from snaplat.adapters.nav_adapter import NavAdapter
from snaplat.sap.loop import one_tick
from snaplat.morsr.ticklog import TickLogger

def main():
    bus = MDHGBus()
    adapters = [
        E8Adapter(bus, base_point=[0.0]*8),
        DTTAdapter(bus, seed=99),
        AssemblyAdapter(bus, seed=123),
        NavAdapter(bus, base_point=[0.0]*8),
    ]
    cfg = {
        "agrm": {"alpha": 0.25, "manifold_N": 3},
        "sap": {"epsilon": 0.05, "max_frontier": 2000, "max_glyph_dl": 5.0},
        "detectors": {"min_N": 2, "min_diversity": 0.5}
    }
    state = {"frontier_width": 240, "distinct_cells": 240, "word_length": 8, "glyph_dl": 1.0, "sectors": 8}
    rec = one_tick(adapters, state, cfg)
    tl = TickLogger("artifacts/morsr_ticks.jsonl")
    tl.emit(rec)
    print(json.dumps({"verdict": rec.get("verdict"), "fusion": rec.get("fusion"), "keep": rec.get("keep")}, indent=2))

if __name__ == "__main__":
    main()
