from snaplat.detensor.core import clamp, DetensorBudget
def test_detensor_clamp():
    w = [0.1]*100
    rep = clamp(w, DetensorBudget(max_rank=16, max_growth=1.2))
    assert rep.rank_after <= 16
