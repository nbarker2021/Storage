
# SnapLat Developer Runbook

## Quick start
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt  # optional
make ci  # runs tests, plot, docs stub, and writes artifact manifest
```

## Release flow
1. Bump `VERSION` and `pyproject.toml`.
2. `make ci` must be green; artifacts land in `artifacts/` with checksums in `artifacts/manifest.json`.
3. Package full zip and update `releases/RELEASES.json`.
