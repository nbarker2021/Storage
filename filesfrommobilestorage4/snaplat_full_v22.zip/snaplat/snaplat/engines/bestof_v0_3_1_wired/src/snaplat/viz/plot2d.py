
from typing import Sequence, Tuple, Optional
import os
import matplotlib.pyplot as plt

def scatter(points: Sequence[Tuple[float, float]], out_png: str, out_svg: Optional[str] = None, title: str = "") -> None:
    os.makedirs(os.path.dirname(out_png), exist_ok=True)
    x = [p[0] for p in points]; y = [p[1] for p in points]
    plt.figure()
    plt.scatter(x, y, s=8)
    if title: plt.title(title)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.savefig(out_png, dpi=160, bbox_inches='tight')
    if out_svg:
        os.makedirs(os.path.dirname(out_svg), exist_ok=True)
        plt.savefig(out_svg, bbox_inches='tight')
    plt.close()
