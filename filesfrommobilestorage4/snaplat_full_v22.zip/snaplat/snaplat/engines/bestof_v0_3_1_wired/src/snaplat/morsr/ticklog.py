import json, time, os
from typing import Dict, Any

class TickLogger:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
    def emit(self, event: Dict[str, Any]):
        ev = dict(event)
        ev["ts"] = time.time()
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(ev, sort_keys=True) + "\n")

def make_tick_record(**kwargs) -> Dict[str, Any]:
    return dict(kwargs)
