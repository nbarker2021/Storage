
from .simple import plan as simple_plan, AGRMState
def get_planner(name: str):
    name = (name or "").lower()
    if name == "cmplx":
        try:
            from .cmplx_adapter import CmplxAGRM
            return CmplxAGRM()
        except Exception:
            pass
    class _Simple:
        def plan(self, state: AGRMState):
            return simple_plan(state)
        def learn(self, trace): return None
    return _Simple()
