
from typing import List, Tuple
from ..e8.core import nearest, edges, coxeter_plane
def slice_id_for(vec) -> str:
    p, _ = nearest(vec); return "cell:" + ",".join(str(int(x*2)) for x in p)
def neighbors_for(vec, k: int = 8) -> List:
    p, _ = nearest(vec); return edges(p)[:k]
def project2d(vec) -> Tuple[float,float]:
    p, _ = nearest(vec); return coxeter_plane(p)
