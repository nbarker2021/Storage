
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
@dataclass
class SAPVerdict:
    decision: str
    reasons: List[str]
def evaluate(evidence: List[Dict[str, Any]], diversity: int, extra_notes: Optional[Dict[str, Any]] = None) -> SAPVerdict:
    reasons: List[str] = []
    if len(evidence) < diversity:
        reasons.append(f"insufficient diversity: {len(evidence)}<{diversity}")
        if extra_notes and "fastlane_reason" in extra_notes:
            reasons.append(f"fastlane: {extra_notes['fastlane_reason']}")
        return SAPVerdict(decision="HOLD", reasons=reasons)
    utils = [e["metrics"]["utility"] for e in evidence]
    avg = sum(utils)/len(utils)
    if avg >= 0.5:
        reasons.append(f"avg utility {avg:.3f} >= 0.5"); decision = "ACCEPT"
    else:
        reasons.append(f"avg utility {avg:.3f} < 0.5"); decision = "REJECT"
    if extra_notes and "fastlane_reason" in extra_notes:
        reasons.append(f"fastlane: {extra_notes['fastlane_reason']}")
    return SAPVerdict(decision=decision, reasons=reasons)
