
import os, json, random

_DEFAULT = {
    "seed": 1337,
    "alpha": 0.3,
    "n_sectors": 30,
    "k_nn": 3,
}

def get_config():
    cfg = dict(_DEFAULT)
    if "SNAPLAT_CFG" in os.environ:
        try:
            cfg.update(json.loads(os.environ["SNAPLAT_CFG"]))
        except Exception:
            pass
    # seed
    random.seed(int(cfg.get("seed", 1337)))
    return cfg
