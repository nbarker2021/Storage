from __future__ import annotations
from typing import List, Dict, Any
import json
from ..agrm.universal import UniversalPlanner, DetectCfg, BudgetCfg, Scorecard
from ..sap.gates import leakage_gate, complexity_gate, detector_gate, ComplexityCfg, DetectorCfg
from ..morsr.ticklog import TickLogger, make_tick_record
from ..morsr.enrich import enrich

def one_tick(adapters, state: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    up = UniversalPlanner()
    det_cfg = DetectCfg(manifold_N=cfg.get("agrm",{}).get("manifold_N", 2))
    budget = BudgetCfg(lambda_=cfg.get("agrm",{}).get("alpha", 0.25))
    dets = up.detect(adapters, state, det_cfg)
    fusion = up.fuse_with_diversity(dets, manifold_meta=None)

    # Scorecard (roughly filled from state and detectors)
    frontier_width = int(state.get("frontier_width", 240))
    distinct_cells = int(state.get("distinct_cells", 240))
    word_length = int(state.get("word_length", 8))
    glyph_dl = float(state.get("glyph_dl", 1.0))
    sc = Scorecard(frontier_width=frontier_width, radius=1, distinct_cells=distinct_cells, word_length=word_length, glyph_dl=glyph_dl)
    util = fusion.get("consensus", 0.0)
    phi = up.score(util, sc, budget)

    # SAP gates
    avg_leak = sum(getattr(d, "leakage", 0.0) for d in dets)/float(len(dets) or 1)
    lg = leakage_gate(avg_leak, eps=cfg.get("sap",{}).get("epsilon", 0.05))
    cg = complexity_gate({"frontier_width": frontier_width, "glyph_dl": glyph_dl}, ComplexityCfg(max_frontier=cfg.get("sap",{}).get("max_frontier",2000), max_glyph_dl=cfg.get("sap",{}).get("max_glyph_dl",5.0)))
    dg = detector_gate(fusion, {}, DetectorCfg(min_N=cfg.get("detectors",{}).get("min_N",2), min_diversity=cfg.get("detectors",{}).get("min_diversity",0.5)))

    reasons = []
    decision = "ACCEPT"
    for ok, why in [(lg.ok, lg.reason), (cg.ok, cg.reason), (dg.ok, dg.reason)]:
        if not ok:
            reasons.append(why)
    if reasons:
        if "Leakage" in " ".join(reasons): decision = "REJECT"
        else: decision = "HOLD"

    record = make_tick_record(
        schedule=[],
        scorecard={
            "frontier_width": frontier_width,
            "glyph_dl": glyph_dl,
            "phi_before": 0.0,
            "phi_after": phi,
            "neighbors_count": distinct_cells
        },
        detectors=[d.__dict__ for d in dets],
        fusion=fusion,
        braid={},
        verdict={"decision": decision, "reasons": reasons}
    )
    return enrich(record)
