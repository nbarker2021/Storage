from __future__ import annotations
from collections import defaultdict
from typing import Any, Dict

class MDHGBus:
    def __init__(self):
        self.kv: Dict[str, Any] = {}
        self.access = defaultdict(int)
    def put(self, key: str, val: Any, score: float=0.0, notes: Dict[str,Any]=None):
        self.kv[key] = {"val": val, "score": score, "notes": notes or {}}
        self.access[key] += 1
    def get(self, key: str, default=None):
        self.access[key] += 1
        return self.kv.get(key, default)
    def hotmap(self):
        return dict(self.access)
