from __future__ import annotations
from dataclasses import dataclass
from typing import Any, List, Dict
from .plan_adapter import PlanAdapterProto, Trail

@dataclass
class DetectCfg:
    manifold_N: int = 2

@dataclass
class BudgetCfg:
    lambda_: float = 0.25

@dataclass
class Scorecard:
    frontier_width: int
    radius: int
    distinct_cells: int
    word_length: int
    glyph_dl: float
    phi_before: float = 0.0
    phi_after: float = 0.0
    def phi(self, alpha: float) -> float:
        return self.frontier_width * alpha - self.glyph_dl

class UniversalPlanner:
    alpha: float = 0.25
    def detect(self, adapters: List[PlanAdapterProto], state: Dict[str, Any], cfg: DetectCfg):
        out = []
        for a in adapters:
            # minimal detector stub via calling step on empty schedule
            tr = a.step([], state)
            cov = float(tr.metrics.get("coverage", 0.0))
            drift = float(tr.metrics.get("drift", 0.0))
            leak = float(tr.metrics.get("leakage", 0.0))
            out.append(type("Det", (), {"adapter": a.__class__.__name__, "coverage": cov, "drift": drift, "leakage": leak}))
        return out
    def fuse_with_diversity(self, detectors, manifold_meta=None):
        if not detectors:
            return {"consensus": 0.0, "diversity": 0.0, "N": 0}
        covs = [d.coverage for d in detectors]
        cons = sum(covs)/len(covs)
        return {"consensus": cons, "diversity": 1.0, "N": len(detectors)}
    def score(self, util: float, sc: Any, budget: BudgetCfg) -> float:
        return util * (1.0 - budget.lambda_)
