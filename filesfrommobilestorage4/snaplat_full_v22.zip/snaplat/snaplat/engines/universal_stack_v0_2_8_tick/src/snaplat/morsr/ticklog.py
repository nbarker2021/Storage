from __future__ import annotations
from typing import List, Dict, Any
import time, json, os
class TickLogger:
    def __init__(self, path: str): self.path=path; os.makedirs(os.path.dirname(path), exist_ok=True)
    def emit(self, record: Dict[str, Any]) -> None:
        record=dict(record); record.setdefault('ts', time.time())
        with open(self.path,'a',encoding='utf-8') as f: f.write(json.dumps(record, sort_keys=True)+'\n')

def make_tick_record(tick:int, schedule: List[Dict[str,Any]], scorecard: Dict[str,float], detectors: List[Dict[str,Any]], fusion: Dict[str,Any], braid: Dict[str,Any], verdict: Dict[str,Any])->Dict[str,Any]:
    return {'event':'tick','tick':tick,'op_trace':schedule,'frontier_width':scorecard.get('frontier_width',0),'glyph_dl':scorecard.get('glyph_dl',0.0),'phi_before':scorecard.get('phi_before',0.0),'phi_after':scorecard.get('phi_after',0.0),'detectors':detectors,'fusion':fusion,'braid':braid,'verdict':verdict}
