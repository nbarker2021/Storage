from __future__ import annotations
from typing import Dict, List, Any
from dataclasses import dataclass
from ..e8.core import nearest, edges, reflect
from ..e8.roots import e8_roots
from ..bridges.mannequin_e8 import slice_id_for
from ..metrics.core import coverage_ratio, drift_jaccard
from ..metrics.splus import leakage_from_metrics
from ..mdhg.bus import MDHGBus
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
@dataclass
class E8Adapter(PlanAdapterProto):
    mdhg: MDHGBus
    def actions(self) -> Dict[str, Action]:
        return {'neighbors': Action(op='neighbors', tag='E', m=8.0, est_cost=1.0), 'reflect': Action(op='reflect', tag='E', m=1.0, est_cost=0.5, args={'r_index':0}), 'project': Action(op='project', tag='C', m=0.5, est_cost=0.5)}
    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        base = state.get('base_point', [0.0]*8); prev_ids: List[str] = state.get('prev_neighbors', []); tac=float(state.get('tac',1.0)); boundary=float(state.get('boundary',1.0))
        px, _ = nearest(base); cell_id = slice_id_for(px); self.mdhg.put('e8:cell', cell_id, score=1.0)
        curr_ids: List[str] = []; cov=0.0
        for a in schedule:
            if a.op=='neighbors':
                nbrs=edges(px); curr_ids=[slice_id_for(y) for y in nbrs]; cov=coverage_ratio(len(curr_ids),240)
                for nid in curr_ids[:32]: self.mdhg.put('e8:cell', nid, score=0.1)
            elif a.op=='reflect':
                px = reflect(px, e8_roots()[a.args.get('r_index',0)]); cell_id = slice_id_for(px); self.mdhg.put('e8:cell', cell_id, score=0.5)
            elif a.op=='project':
                px, _ = nearest(px); cell_id = slice_id_for(px)
        drift = drift_jaccard(prev_ids, curr_ids) if prev_ids else 0.0
        leak = leakage_from_metrics({'tac':tac,'boundary':boundary,'drift':drift})
        return Trail(metrics={'coverage':cov,'drift':drift,'leakage':leak}, artifacts={}, notes={'cell':cell_id, 'neighbors': curr_ids})
    def learn(self, trace: Trail) -> None: return None
