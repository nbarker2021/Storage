from __future__ import annotations
from typing import Dict, Any
import time
from .adapter_legacy import MDHG as _MDHG
class MDHGBus:
    def __init__(self, decay_half_life_sec: float = 900.0):
        self.backend = _MDHG(); self.half = float(decay_half_life_sec); self._last_decay: Dict[str,float] = {}
    def _k(self, ns: str, key: str) -> str: return f"{ns}:{key}"
    def put(self, ns: str, key: str, score: float = 1.0, notes: Dict[str, Any] | None = None) -> None:
        k=self._k(ns,key); now=time.time(); rec=self.backend.get(k) or {'score':0.0,'count':0,'last_ts':now,'notes':{}}
        rec['score']+=score; rec['count']+=1; rec['last_ts']=now; (notes and rec['notes'].update(notes))
        self.backend.put(k, rec)
    def get(self, ns: str, key: str, default=None): return self.backend.get(self._k(ns,key), default)
    def decay(self, ns: str, rate: float = 0.5) -> None:
        now=time.time(); last=self._last_decay.get(ns, now)
        if now-last < self.half: return
        if hasattr(self.backend,'kv'):
            for k, rec in list(self.backend.kv.items()):
                if not k.startswith(ns+':'): continue
                rec['score'] *= rate; self.backend.put(k, rec)
        self._last_decay[ns]=now
