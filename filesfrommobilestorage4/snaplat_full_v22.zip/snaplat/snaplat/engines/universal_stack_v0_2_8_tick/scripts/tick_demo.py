#!/usr/bin/env python3
from __future__ import annotations
from typing import List, Dict, Any
import os, json

from snaplat.mdhg.bus import MDHGBus
from snaplat.agrm.universal import UniversalPlanner, DetectCfg, Scorecard
from snaplat.agrm.plan_adapter import Action
from snaplat.adapters.e8_adapter import E8Adapter
from snaplat.adapters.dtt_adapter import DTTAdapter
from snaplat.adapters.assembly_adapter import AssemblyAdapter
from snaplat.sap.gates import leakage_gate, complexity_gate, detector_gate, ComplexityCfg, DetectorCfg
from snaplat.morsr.ticklog import TickLogger, make_tick_record

def main():
    # --- Setup ---
    bus = MDHGBus()
    e8 = E8Adapter(bus)
    dtt = DTTAdapter(mdhg=bus)
    asm = AssemblyAdapter(bus)

    planner = UniversalPlanner()

    # --- Detector pass (sidecars) ---
    state = {"tac": 0.98, "boundary": 0.95, "drift": 0.05, "base_point": [0.0]*8}
    D = planner.detect([e8, dtt, asm], state=state, cfg=DetectCfg(manifold_N=3))
    manifold_meta = [
        {"anchor":"A1","universe":"R1","seed":101},
        {"anchor":"A2","universe":"R2","seed":102},
        {"anchor":"A3","universe":"R3","seed":103},
    ]
    fusion = planner.fuse_with_diversity(D, manifold_meta)

    # --- Mainline schedules ---
    e8_schedule = [e8.actions()["neighbors"], e8.actions()["project"]]
    dtt_schedule = [dtt.actions()["micro_eval"], dtt.actions()["braid_reduce"]]
    asm_schedule = [asm.actions()["barymix"]]

    e8_trail = e8.step(e8_schedule, state)
    dtt_trail = dtt.step(dtt_schedule, state)
    asm_trail = asm.step(asm_schedule, state)

    # --- Scorecard Φ ---
    frontier_width = int(e8_trail.metrics.get("coverage",0.0) * 240)
    distinct_cells = len(set(e8_trail.notes.get("neighbors", [])))
    word_length = len(e8_schedule) + len(dtt_schedule) + len(asm_schedule)
    glyph_dl = float(asm_trail.metrics.get("glyph_dl", 0.0))
    sc = Scorecard(frontier_width=frontier_width, radius=1, distinct_cells=distinct_cells, word_length=word_length, glyph_dl=glyph_dl)
    sc.phi_before = 0.0
    sc.phi_after = sc.phi(planner.alpha)

    # --- SAP gates ---
    leakage_avg = sum(d.leakage for d in D)/float(len(D) or 1)
    gl = leakage_gate(leakage_avg, eps=0.05)
    gc = complexity_gate({"frontier_width": frontier_width, "glyph_dl": glyph_dl, "phi_rise_ticks": 0}, ComplexityCfg())
    gd = detector_gate(fusion, {"N": fusion.get("N",0), "diversity": fusion.get("diversity",0.0)}, DetectorCfg())

    # Verdict
    decision = "ACCEPT"
    reasons: List[str] = []
    if not gl.ok:
        decision = "REJECT"; reasons.append(gl.reason)
    if decision == "ACCEPT" and not gd.ok:
        decision = "HOLD"; reasons.append(gd.reason)
    if decision == "ACCEPT" and not gc.ok:
        decision = "HOLD"; reasons.append(gc.reason)
    if not reasons:
        reasons.append("OK")

    # --- MORSR tick log ---
    artifacts_dir = os.path.join("artifacts")
    os.makedirs(artifacts_dir, exist_ok=True)
    ticklog_path = os.path.join(artifacts_dir, "morsr_ticks.jsonl")
    tl = TickLogger(ticklog_path)

    op_trace: List[Dict[str,Any]] = []
    for a in e8_schedule: op_trace.append({"adapter":"e8","op":a.op,"tag":a.tag,"m":a.m})
    for a in dtt_schedule: op_trace.append({"adapter":"dtt","op":a.op,"tag":a.tag,"m":a.m})
    for a in asm_schedule: op_trace.append({"adapter":"asm","op":a.op,"tag":a.tag,"m":a.m})

    record = make_tick_record(
        tick=1,
        schedule=op_trace,
        scorecard={
            "frontier_width": frontier_width,
            "glyph_dl": glyph_dl,
            "phi_before": sc.phi_before,
            "phi_after": sc.phi_after,
        },
        detectors=[d.__dict__ for d in D],
        fusion=fusion,
        braid={},
        verdict={"decision": decision, "reasons": reasons}
    )
    tl.emit(record)

    print(json.dumps({
        "decision": decision,
        "reasons": reasons,
        "frontier_width": frontier_width,
        "glyph_dl": glyph_dl,
        "consensus": fusion.get("consensus"),
        "diversity": fusion.get("diversity"),
        "ticklog": ticklog_path
    }, indent=2))

if __name__ == "__main__":
    main()
