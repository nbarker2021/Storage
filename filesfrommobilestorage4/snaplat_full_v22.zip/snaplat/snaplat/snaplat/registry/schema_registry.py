
import json, yaml
_REG = {}
def add_schema(path: str):
    with open(path) as f:
        sch = yaml.safe_load(f) if path.endswith(('.yaml','.yml')) else json.load(f)
    tid = sch.get("type_id") or sch.get("id")
    if not tid: raise ValueError("type_id missing")
    _REG[tid] = sch; return sch
def show(type_id: str): return _REG.get(type_id, {})
def validate_instance(type_id: str, inst: dict):
    sch = _REG.get(type_id, {})
    req = (sch.get("seeds") or {}).get("required", [])
    missing = [r.split(':')[0] for r in req if r.split(':')[0] not in (inst.get("seeds") or {})]
    return {"ok": len(missing)==0, "missing": missing, "version": sch.get("version")}
