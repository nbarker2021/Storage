
import time, json, hashlib
_Q = []; _APPROVED = {}
def _gid(op): return hashlib.blake2s(json.dumps(op, sort_keys=True).encode(), digest_size=8).hexdigest()
def enqueue(op_type, params, actor):
    op={"type":op_type,"params":params,"actor":actor,"ts":int(time.time()*1000)}; op["gid"]=_gid(op); _Q.append(op); return op["gid"]
def approve(gid: str, approver: str):
    for i,op in enumerate(_Q):
        if op["gid"]==gid: op["approved_by"]=approver; _APPROVED[gid]=op; del _Q[i]; return op
    raise KeyError("gid not found")
def tail(n=20): return _Q[-n:]
def is_approved(gid: str) -> bool: return gid in _APPROVED
