
def map_faces_to_lane(faces: dict) -> str:
    vals = [faces.get(k, "amber") for k in ("privacy","policy","numeric","semantic")]
    if "red" in vals: return "shadow"
    if "amber" in vals: return "silver"
    return "gold"
