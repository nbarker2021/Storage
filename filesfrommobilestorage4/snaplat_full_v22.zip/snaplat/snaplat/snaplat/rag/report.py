
_DOCS = {}
def index(doc_id: str, text: str):
    _DOCS[doc_id] = text.split()
def retrieve(query: str, topk: int = 3):
    q = set(query.split()); scores = []
    for doc_id, toks in _DOCS.items():
        overlap = len(q & set(toks)); scores.append((doc_id, overlap))
    scores.sort(key=lambda x:x[1], reverse=True)
    return scores[:topk]
def generate_report(prompt: str):
    hits = retrieve(prompt, topk=3)
    out = []
    for doc_id, _ in hits:
        toks = _DOCS.get(doc_id, [])[:24]
        if toks: out.append(f"[[doc:{doc_id} span:0]] " + ' '.join(toks))
    return {"text": "
".join(out), "hits": str(hits)}
