
def overlap_score(a_tokens, b_tokens):
    max_olap = 0
    for k in range(1, min(len(a_tokens), len(b_tokens)) + 1):
        if a_tokens[-k:] == b_tokens[:k]:
            max_olap = k
    return max_olap
