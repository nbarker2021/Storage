
"""AGRM planner: precedence + beacon bias + budgets (stub)."""
from typing import Dict, Any
from ..governance.beacons import value as beacon_value
from ..governance.precedence import order as precedence_order
def plan(context: Dict[str, Any], mode: str = "operational") -> Dict[str, Any]:
    return {
        "precedence": precedence_order(mode),
        "budget": {"recall": 0.7, "compute": 0.3},
        "beacon_bias": {k: beacon_value(k) for k in ("safety","cost","recall","speed")},
        "waypoints": ["sense","stage","stitch","govern","feedback"]
    }
