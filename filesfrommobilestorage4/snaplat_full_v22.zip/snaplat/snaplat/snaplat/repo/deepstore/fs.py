
import os, json, time, hashlib
class FSDeepStore:
    def __init__(self, root=".deepstore"): self.root=root; os.makedirs(root, exist_ok=True)
    def _p(self, key): return os.path.join(self.root, key)
    def put(self, key, blob, meta=None):
        p=self._p(key); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p,"wb") as f: f.write(blob)
        import hashlib as _h
        digest = _h.sha256(blob).hexdigest()
        with open(p+".meta.json","w") as f: json.dump({"ts":int(time.time()*1000), "digest": digest, **(meta or {})}, f)
        return key
    def get(self, key):
        p=self._p(key); 
        with open(p,"rb") as f: b=f.read()
        meta={}
        try: 
            with open(p+".meta.json") as f: meta=json.load(f)
        except: pass
        return b, meta
    def exists(self, key): return os.path.exists(self._p(key))
