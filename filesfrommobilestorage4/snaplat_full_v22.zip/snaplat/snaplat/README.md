
# SNAPLAT — Full Monorepo (v21b)

Best-of build expanding v17–v20 with richer modules, docs, samples.
Install:
```bash
pip install -e .
python -m snaplat.cli --help
```
