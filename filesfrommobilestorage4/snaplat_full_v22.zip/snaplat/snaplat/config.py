
import json, os
_CFG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
_DEFAULT = {"engine": "reference"}
def get_config():
    if os.path.exists(_CFG_PATH):
        try:
            with open(_CFG_PATH) as f: return json.load(f)
        except Exception:
            return dict(_DEFAULT)
    return dict(_DEFAULT)
def set_engine(name: str):
    cfg = get_config(); cfg["engine"] = name
    with open(_CFG_PATH, "w") as f: json.dump(cfg, f, indent=2)
    return cfg
