# Glossary - Long Form
- Frame F: <tau,S,M,FACES> compiled from numeric glyphs.
- REST/ACTION/REJECT: normal form / reducible / illegal.
- NTER: Needs-To-Evidence-Resolve; structure OK but pins missing.
- NGD: Numeric-Glyph Descriptor (thresholds, scale, residues, faces).
- Phi(x): violation vector; lexicographically decreases.
- Invariant key: (frame, shell, coset) - retrieval namespace.
