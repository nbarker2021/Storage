# Proofs - Long Form (Sketches)
Soundness: REST implies x in Lambda (syndrome 0) with even norm and canonical coset; palindromy thresholds satisfied.
Completeness (strict): If x in Lambda with P4=P8=0, the reducer converges to the canonical rep under lex tie-breaks.
Termination: Phi(x) strictly decreases over N^4.
Confluence: Local critical pairs resolve; Newman's Lemma => unique NF.
Commit-once equivalence: Irreversible writes equal the single materialization cost at NF; ledger steps are reversible logs.
