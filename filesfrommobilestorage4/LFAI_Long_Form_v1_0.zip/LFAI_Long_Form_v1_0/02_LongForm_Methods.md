# Methods - Long Form
Run-Loop
Intake -> Integerize -> K-Scan -> Frame Compile -> CRT -> Con-A -> lambda-band -> Witness Verify -> Ledger -> Reduce (down Phi) -> Commit Once.

Reproducibility Controls
- (theta4,theta8) palindromy thresholds: strict vs noisy
- Code and H versions: pinned in GAE/CEC
- lambda profile: versioned
- Arm bundle: primes enabled by glyphs; 13 on by default
- Seeds, frame_hash, nf_hash: exported

Determinism and Replay
Randomize legal order of primitive steps; NF hash must remain invariant (confluence-hash ~ 1.000). Replay uses residues, not poses, to avoid gauge drift.
