# Ledger & Replay - Long Form
Log: seed, frame_hash, residues, step_hash, before/after Phi, reason, prev_hash; pose omitted (gauge).
Replay Steps: recompute residues -> pal defects -> syndrome -> Type-II (evenness + canonical coset) -> ensure monotone down Phi -> CRT stitch -> NF match -> verify Merkle root and hashes.

Sample ledger row: {"step":2,"move":{"idx":6,"delta":+1},"Phi_before":[2,4,2,0],"Phi_after":[1,2,1,0],"hash":"h2","prev":"h1"}.
