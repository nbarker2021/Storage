# Case Study - Navigation (Long Form)
Status: PROVISIONAL-OPEN (NTER) - structure legal; pins pending.
Frame: tau=1/4, S=64, M={2,4,8,13,5,7,11}, faces={navigation, octad, two_slice}.
Pins: atm_density_known pending, dv_budget_known pending.
Witnesses: parity=GREEN, timing=GREEN, spectral dual=GREEN.
Palindromy: P4=0, P8=0; Syndrome: 0; Type-II: True.
Decision: CLOSE gate until pins satisfied; then OPEN without re-run (deterministic replay OK).
