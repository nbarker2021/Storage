# Legality-First AI - Long-Form Specification (v1.0)
Release (UTC): 2025-09-16T23:07:50Z


1. Thesis
Legality, not similarity, is the source of truth. Inputs are integer vectors evaluated across congruence channels (mod 2/4/8/...) and accepted only when they lie in Type-II Construction-A shells and satisfy palindromic balance (mod-4/8) with zero syndrome. Illegal states deterministically reduce under a confluent rewrite system to a unique normal form (REST) or are rejected.

2. Mathematical Backbone
- State space: x in Z^n (quantized latent). Integer arithmetic makes parity/congruence first-class.
- Frame: F = <tau, S, M, FACES> compiled from numeric glyphs:
  - tau in {1/8 (representation), 1/4 (driving), 1/2, ...}, with 1/4 outranking 1/8.
  - S in {4^k}; when tau=1/4, promote 4^k -> 4^(k+1).
  - M = {2,4,8} U primes(glyphs) U specials {3,5,7,11,13,24,32,...}; 13 (timing) on by policy.
  - FACES: route preferences (octads, two-slice hub, witnesses); parity overrides.
- Parallel residues: r_m = (x mod m) for m in M; stitch via CRT.
- Construction-A legality: choose binary linear code C subset F2^n with parity matrix H. Lattice Lambda = {{z in Z^n : z mod 2 in C}}. Type-II requires evenness and unimodularity in the accepted shell.
- Palindrome-defects: with histograms h^(4), h^(8):
  - P4 = |h1 - h3|
  - P8 = sum_{k=1..3} |h_k - h_{8-k}|
  Strict profile: (theta4,theta8)=(0,0). Noisy profile: small theta with ECC repair.
- Legality test (per state):
  1) Syndrome s = H * (x mod 2)^T; require wt(s)=0.
  2) Evenness: ||x||^2 == 0 (mod 2).
  3) Unimodular/canonical coset: accept the lexicographically minimal rep in x+2C.
  4) Palindromy: P4<=theta4 and P8<=theta8.
- Violation vector and rewrite: Phi(x)=(wt(s), P8, P4, rho) in N^4 (lex order). Every ACTION step must strictly decrease Phi. Termination follows. Local confluence holds by commuting disjoint updates and resolving the single critical pair (parity vs palindromy at the same index) with a parity-first policy; by Newman's Lemma, NF_F(x) is unique.
- Control manifold: T^{f+2} torus, f residue faces (default f=8), plus (phase/rate, epoch).

3. Executor (Corridor Twin) in Detail
1) K-Scanner: removes low-utility coefficients; preserves legality-invariants.
2) Frame Compile: numeric glyphs -> NGD -> F. 13-arm ON by default.
3) CRT Projection: compute residues for m in M.
4) Construction-A Lift: check Lambda legality.
5) Alena lambda-band smoothing: de-noise to a stable pose; default lambda~0.655. Pose is gauge; residues are the truth.
6) Seven-Witness Verify: parity, palindromy (P4,P8), syndrome, residue coverage, spectral (DFT/WHT) dual-witness, corridor legality, replay hash.
7) Ledger: log reversible micro-steps with before/after Phi and step hashes.
8) Reduction: apply primitive updates that strictly decrease Phi until REST or REJECT.
9) Commit Once: materialize only NF_F(x); export nf_hash and Merkle root.
