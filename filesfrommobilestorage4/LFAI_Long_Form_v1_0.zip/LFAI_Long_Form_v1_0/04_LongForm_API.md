# API - Long Form
All endpoints accept frame_hash and emit Merkle-bound logs.

- POST /frame: compile frame from glyphs; returns frame, frame_hash.
- POST /verify: returns verdict (REST|ACTION|REJECT), syndrome, P4, P8, typeII.
- POST /reduce: perform one primitive legal update; returns move_id, before/after Phi, reason.
- POST /commit: collapse log to normal form; returns normal_form, nf_hash, merkle_root.
- POST /store | /retrieve: invariant key = (frame,shell,coset); cross-frame is illegal.
- POST /extend: propose Delta F with cost_bits/ops; requires signatures.

Errors: E_ILLEGAL_FRAME_BRIDGE, E_UNDECIDABLE_IN_FRAME (includes proposed_extension).
