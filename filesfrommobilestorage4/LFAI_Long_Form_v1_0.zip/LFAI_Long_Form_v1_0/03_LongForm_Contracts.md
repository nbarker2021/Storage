# Contracts - Long Form (GAE-1 / CEC-1)
GAE-1 (JSON+JWS)
Fields: ver, token, ngd {thresholds, scale_family, residues, faces, witnesses, evidence?}, provenance {model, seed_hash, timestamp, run_id}, ngd_sha256, kid, sig_jws.

CEC-1 (CBOR/COSE; JSON view)
Fields: hdr {ver, token_ref}, corridor {mods, allow_in, allow_io}, gates {required}, falsifiers [...], alena {lambda, flip_mask}, ledger.bind {run_id, step_id, prev_hash}, evidence.required [...], cec_b3, cose_sig.

Governance
- States: UNATTESTED -> ATTESTED -> READY -> LD.GATE {OPEN | CLOSE with NTER}.
- NTER: gate remains CLOSED pending evidence pins.
- Extend(): proposed Delta F must be signed; include cost_bits and cost_ops.
