# Security, Privacy, Threats - Long Form
- Leak control: export verdicts + Phi deltas; avoid raw residues or add DP noise.
- Adversarial palindromy spoof: require multi-lane checks (2/4/8 + specials).
- Frame creep: signed Extend() with explicit costs; ledger entries for all changes.
