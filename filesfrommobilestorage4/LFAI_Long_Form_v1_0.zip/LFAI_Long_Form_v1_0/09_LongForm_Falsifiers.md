# Falsifiers & Benchmarks - Long Form
F1 Confluence break: randomized legal orders produce different NF hashes.
F2 Mirage-Type-II: REST but fails evenness/unimodularity.
F3 Pal failure: REST with P4>theta4 or P8>theta8.
F4 Invariance breach: truth changes under allowed morphisms of F.
F5 Energy regression: commit-once writes >= per-step committing at equal accuracy.
F6 Retrieval regression: invariant-key loses to cosine on label-preserving transforms.

Scoreboard: legality-rate, confluence-hash, ECC radius, time-to-REST, energy/commit, undecidable/extension rate, cross-frame rejections.

A/B plan: cosine-RAG vs invariant-key CQE-RAG; Type-II->Type-I ablation; no-pal ablation; noise ablation for ECC radius.
