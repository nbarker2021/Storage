# Case Study - Codon Duplex (Long Form)
Status: OPEN - symbolic-only pins.
Frame: tau=1/8, S=16, M={2,4,8,13}, faces={duplex, chiral}.
Witnesses: parity=GREEN, timing=GREEN.
Palindromy: P4=0, P8=0; Syndrome: 0; Type-II: True.
Decision: OPEN; residues-only replay proves determinism.
