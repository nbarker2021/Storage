#!/usr/bin/env python3
import json, sys
from pathlib import Path
FSM_TERMINALS = {"snapops.done","edbsu.archive"}
FSM_ALLOWED = {
    "START": {"snapops.begin"},
    "snapops.begin": {"thinktank.proposed"},
    "thinktank.proposed": {"dtt.run"},
    "dtt.run": {"mdhg.to_graph"},
    "mdhg.to_graph": {"snapops.coverage_ok","snapops.consolidate_ok","snapops.coverage_gate"},
    "snapops.coverage_ok": {"mdhg.promotion_breakdown.v2"},
    "snapops.consolidate_ok": {"mdhg.promotion_breakdown.v2"},
    "snapops.coverage_gate": {"snapops.branch.edbsu"},
    "mdhg.promotion_breakdown.v2": {"snapops.branch.assembly","snapops.branch.edbsu"},
    "snapops.branch.assembly": {"assembly.stage"},
    "assembly.stage": {"snapops.done"},
    "snapops.branch.edbsu": {"edbsu.archive"}
}
def main():
    path = Path(sys.argv[1])
    evs = [json.loads(l).get("event") for l in path.read_text(encoding="utf-8").splitlines()]
    s="START"; viol=[]
    for e in evs:
        if e not in FSM_ALLOWED.get(s,set()): viol.append({"state":s,"event":e})
        s=e
    ok = (len(viol)==0) and (evs[-1] in FSM_TERMINALS if evs else False)
    print(json.dumps({"ok": ok, "violations": viol, "final": evs[-1] if evs else None}, indent=2))
    if not ok: sys.exit(2)
if __name__ == "__main__": main()
