#!/usr/bin/env python3
import json, sys
from pathlib import Path
def main():
    policy = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    beacons = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    baseline = json.loads(Path(sys.argv[3]).read_text(encoding="utf-8"))
    # inline calc (mirrors mdhg core; simplified)
    import numpy as np, json as _j
    def cosine(a,b):
        a = np.array(a, dtype=float); b = np.array(b, dtype=float)
        m = max(len(a), len(b))
        if len(a)<m: a = np.pad(a,(0,m-len(a)))
        if len(b)<m: b = np.pad(b,(0,m-len(b)))
        na = np.linalg.norm(a); nb = np.linalg.norm(b)
        if na==0 or nb==0: return 0.0
        return float(np.clip(a.dot(b)/(na*nb), -1.0, 1.0))
    n = int(policy["n_points"]); epn = int(policy["edges_per_node_max"]); total=int(policy["total_edges_max"])
    # deterministic graph math: same as builder
    max_edges = min(total, (n * min(epn, n-1))//2)
    hot = min(1.0, (epn/epn))  # bounded to 1.0 average in this deterministic structure
    pos = max(cosine([0.8,0.15,0.05,0.0], v["vec"]) for _,v in beacons.items() if not v.get("neg"))
    neg = max(cosine([0.8,0.15,0.05,0.0], v["vec"]) for _,v in beacons.items() if v.get("neg"))
    bridge=0.5; w=policy["weights"]
    score = max(0.0, min(1.0, w["w_w5h"]*pos + w["w_bridge"]*bridge + w["w_hot"]*hot - w["w_neg"]*neg))
    comp = {"w5h":pos,"neg":neg,"hot":hot,"bridge":bridge,"score":score}
    ok = all(abs(comp[k]-baseline[k])<1e-9 for k in comp)
    print(json.dumps({"ok": ok, "comp": comp, "baseline": baseline}, indent=2))
    if not ok: sys.exit(2)
if __name__ == "__main__": main()
