#!/usr/bin/env python3
import json, sys, hashlib
from pathlib import Path
def canonical_json(obj): 
    return json.dumps(obj, sort_keys=True, separators=(",",":"))
def sha256_bytes(b: bytes): 
    return hashlib.sha256(b).hexdigest()
def main():
    policy_path = Path(sys.argv[1]); pin_path = Path(sys.argv[2])
    policy = json.loads(policy_path.read_text(encoding="utf-8"))
    pin = json.loads(pin_path.read_text(encoding="utf-8"))
    current = sha256_bytes(canonical_json(policy).encode("utf-8"))
    if current != pin["sha256"] and policy.get("version")==pin.get("version"):
        print(json.dumps({"ok": False, "reason":"policy_changed_without_version_bump"}, indent=2)); sys.exit(2)
    print(json.dumps({"ok": True, "reason":"ok"}, indent=2))
if __name__ == "__main__": main()
