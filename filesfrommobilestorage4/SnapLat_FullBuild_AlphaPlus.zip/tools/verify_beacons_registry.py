#!/usr/bin/env python3
import json, sys, hashlib
from pathlib import Path
def canonical_json(obj): 
    return json.dumps(obj, sort_keys=True, separators=(",",":"))
def sha256_bytes(b: bytes): 
    return hashlib.sha256(b).hexdigest()
def main():
    policy_path = Path(sys.argv[1]); pin_path = Path(sys.argv[2])
    policy = json.loads(policy_path.read_text(encoding="utf-8"))
    beacons_path = Path(policy["beacons_path"])
    beacons = json.loads(Path(beacons_path).read_text(encoding="utf-8"))
    pin = json.loads(pin_path.read_text(encoding="utf-8"))
    current = sha256_bytes(canonical_json(beacons).encode("utf-8"))
    if current != pin["sha256"]:
        print(json.dumps({"ok": False, "reason":"beacons_hash_mismatch"}, indent=2)); sys.exit(2)
    print(json.dumps({"ok": True, "reason":"ok"}, indent=2))
if __name__ == "__main__": main()
