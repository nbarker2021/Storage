
from typing import List, Tuple

class Graph:
    __slots__ = ("n","adj","edges","quota_hit")
    def __init__(self, n:int):
        self.n = n
        self.adj: List[List[int]] = [[] for _ in range(n)]
        self.edges: List[Tuple[int,int]] = []
        self.quota_hit: bool = False

def to_points_n(n:int) -> List[int]:
    return list(range(n))

def to_graph(points: List[int], *, edges_per_node_max:int=8, total_edges_max:int=5000) -> Graph:
    n = len(points)
    g = Graph(n)
    total = 0
    for i in range(n-1):
        limit = min(n, i+1+edges_per_node_max)
        for j in range(i+1, limit):
            u, v = points[i], points[j]
            g.adj[u].append(v); g.adj[v].append(u)
            g.edges.append((u,v))
            total += 1
            if total >= total_edges_max:
                g.quota_hit = True
                return g
    return g

def csr_snapshot(g: Graph):
    indptr = [0]; indices: List[int] = []
    for u in range(g.n):
        nbrs = sorted(g.adj[u])
        indices.extend(nbrs)
        indptr.append(len(indices))
    return indptr, indices

def degree_vector(g: Graph) -> List[int]:
    return [len(g.adj[u]) for u in range(g.n)]

def degree_heat(g: Graph, cap:int) -> float:
    deg = degree_vector(g)
    if not deg: return 0.0
    vals = [min(1.0, d/max(1,cap)) for d in deg]
    return sum(vals)/len(vals)
