
import json, itertools
from pathlib import Path
from typing import Dict, Any
from mdhg.core import to_points_n, to_graph, degree_heat

def cosine(a, b):
    import numpy as np
    a = np.array(a, dtype=float); b = np.array(b, dtype=float)
    m = max(len(a), len(b))
    if len(a)<m: a = np.pad(a, (0,m-len(a)))
    if len(b)<m: b = np.pad(b, (0,m-len(b)))
    na = float((a**2).sum()**0.5); nb = float((b**2).sum()**0.5)
    if na==0 or nb==0: return 0.0
    s = float(a.dot(b)/(na*nb))
    return max(-1.0, min(1.0, s))

def score(room_vec, g, epn, weights, beacons):
    hot = degree_heat(g, cap=epn)
    pos = max(cosine(room_vec, v["vec"]) for k,v in beacons.items() if not v.get("neg"))
    neg = max(cosine(room_vec, v["vec"]) for k,v in beacons.items() if v.get("neg"))
    bridge = 0.5
    s = weights["w_w5h"]*pos + weights["w_bridge"]*bridge + weights["w_hot"]*hot - weights["w_neg"]*neg
    return max(0.0, min(1.0, float(s))), {"w5h":pos,"neg":neg,"hot":hot,"bridge":bridge}

def run(out_json: Path, out_csv: Path, policy: Dict[str,Any], beacons: Dict[str,Any]):
    n = int(policy["n_points"]); epn = int(policy["edges_per_node_max"]); total = int(policy["total_edges_max"])
    g = to_graph(to_points_n(n), edges_per_node_max=epn, total_edges_max=total)
    room = [0.8,0.15,0.05,0.0]
    grid = {
        "w_w5h": [0.3, 0.5, 0.7],
        "w_hot": [0.15, 0.25, 0.35],
        "w_neg": [0.4, 0.5, 0.6],
        "w_bridge": [0.2, 0.25, 0.3]
    }
    keys = list(grid.keys())
    rows = []
    best = None
    for vals in __import__("itertools").product(*[grid[k] for k in keys]):
        weights = dict(zip(keys, vals))
        sc, comp = score(room, g, epn, weights, beacons)
        rows.append({**weights, "score": sc, **comp})
        if (best is None) or (sc > best["score"]):
            best = {"weights": weights, "score": sc, **comp}
    import pandas as pd
    df = pd.DataFrame(rows)
    df.to_csv(out_csv, index=False)
    out_json.write_text(json.dumps({"best": best, "grid_rows": len(rows)}, indent=2), encoding="utf-8")

if __name__ == "__main__":
    import argparse, json
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", required=True)
    ap.add_argument("--beacons", required=True)
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--out-csv", required=True)
    args = ap.parse_args()
    policy = json.loads(Path(args.policy).read_text(encoding="utf-8"))
    beacons = json.loads(Path(args.beacons).read_text(encoding="utf-8"))
    run(Path(args.out_json), Path(args.out_csv), policy, beacons)
