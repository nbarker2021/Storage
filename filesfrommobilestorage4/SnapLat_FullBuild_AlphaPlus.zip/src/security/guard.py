
import fnmatch, json
from pathlib import Path
class ACL:
    def __init__(self, path: Path):
        self.cfg = json.loads(path.read_text(encoding="utf-8"))
    def allow(self, role: str, op: str) -> bool:
        r = self.cfg["roles"].get(role, {})
        for pat in r.get("deny", []):
            if fnmatch.fnmatch(op, pat): return False
        for pat in r.get("allow", []):
            if fnmatch.fnmatch(op, pat): return True
        return not self.cfg.get("default_deny", True)
