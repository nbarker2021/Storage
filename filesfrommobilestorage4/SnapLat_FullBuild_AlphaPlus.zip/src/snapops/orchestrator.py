
import json, time, hashlib
from pathlib import Path
from typing import Dict, Any, Tuple, List
from mdhg.core import to_points_n, to_graph, degree_heat

def canonical(obj): return json.dumps(obj, sort_keys=True, separators=(",",":"))
def sha256_hex(b: bytes): return hashlib.sha256(b).hexdigest()

def cosine(a,b):
    import numpy as np
    a = np.array(a, dtype=float); b = np.array(b, dtype=float)
    m = max(len(a), len(b))
    if len(a)<m: a = np.pad(a,(0,m-len(a)))
    if len(b)<m: b = np.pad(b,(0,m-len(b)))
    na = np.linalg.norm(a); nb = np.linalg.norm(b)
    if na==0 or nb==0: return 0.0
    return float(np.clip(a.dot(b)/(na*nb), -1.0, 1.0))

def coverage_ratio(n, epn, total, n_edges):
    ideal = min(total, (n * min(epn, n-1))//2)
    return float(min(1.0, n_edges/ideal)) if ideal>0 else 0.0

def score_components(room_vec, g, epn, weights, beacons):
    hot = degree_heat(g, cap=epn)
    pos = max(cosine(room_vec, v["vec"]) for _,v in beacons.items() if not v.get("neg"))
    neg = max(cosine(room_vec, v["vec"]) for _,v in beacons.items() if v.get("neg"))
    bridge=0.5
    score = max(0.0, min(1.0, weights["w_w5h"]*pos + weights["w_bridge"]*bridge + weights["w_hot"]*hot - weights["w_neg"]*neg))
    return {"w5h":pos,"neg":neg,"hot":hot,"bridge":bridge,"score":score}

def morsr_regions(step_ops: List[str]) -> Dict[str,float]:
    counts={}; total=0
    for op in step_ops:
        head = op.split(".")[0]; counts[head]=counts.get(head,0)+1; total+=1
    return {k:(v/total if total else 0.0) for k,v in counts.items()}

def wavepool_top(regions: Dict[str,float]) -> float:
    return max(regions.values()) if regions else 0.0

def run(policy_path: Path, beacons_path: Path, trails_path: Path) -> Dict[str,Any]:
    policy = json.loads(Path(policy_path).read_text(encoding="utf-8"))
    beacons = json.loads(Path(beacons_path).read_text(encoding="utf-8"))
    def trail(ev: Dict[str,Any]):
        ev.setdefault("ts", time.time())
        with open(trails_path,"a",encoding="utf-8") as f: f.write(json.dumps(ev)+"\n")
    # begin
    trail({"event":"snapops.begin","module":"snapops","policy_version": policy.get("version")})
    steps=[{"op":"mdhg.to_points"},{"op":"mdhg.to_graph"},{"op":"tpg.surgery"}]
    trail({"event":"thinktank.proposed","module":"thinktank","steps":steps})
    trail({"event":"dtt.run","module":"dtt","ok":True})
    # graph
    n = int(policy["n_points"]); epn=int(policy["edges_per_node_max"]); total=int(policy["total_edges_max"])
    g = to_graph(to_points_n(n), edges_per_node_max=epn, total_edges_max=total)
    trail({"event":"mdhg.to_graph","module":"mdhg","edges": len(g.edges), "quota_hit": g.quota_hit})
    cov = coverage_ratio(n, epn, total, len(g.edges))
    if cov >= policy["coverage_watermark"]:
        trail({"event":"snapops.coverage_ok","module":"snapops","coverage": round(cov,4)})
    elif cov >= policy["coverage_watermark"]*(1.0 - policy["approach_margin"]):
        trail({"event":"snapops.consolidate_ok","module":"snapops","coverage": round(cov,4)})
    else:
        trail({"event":"snapops.coverage_gate","module":"snapops","coverage": round(cov,4)})
        trail({"event":"snapops.branch.edbsu","module":"snapops"})
        trail({"event":"edbsu.archive","module":"edbsu","state":"DEMOTED"})
        return {"ok": False, "branch":"edbsu", "coverage": cov}
    # scoring
    comp = score_components([0.8,0.15,0.05,0.0], g, epn, policy["weights"], beacons)
    trail({"event":"mdhg.promotion_breakdown.v2","module":"mdhg", **comp, "beacons_sha256": sha256_hex(canonical(beacons).encode())})
    # region/score gate
    regions = morsr_regions([s["op"] for s in steps])
    top = wavepool_top(regions)
    if top >= policy["region_min_top"] and comp["score"] >= policy["score_min"]:
        trail({"event":"snapops.branch.assembly","module":"snapops","top": top, "score": comp["score"]})
        trail({"event":"assembly.stage","module":"assembly","ops":[s["op"] for s in steps]})
        trail({"event":"snapops.done","module":"snapops"})
        return {"ok": True, "branch":"assembly", "coverage": cov, "score": comp["score"]}
    else:
        trail({"event":"snapops.branch.edbsu","module":"snapops","top": top, "score": comp["score"]})
        trail({"event":"edbsu.archive","module":"edbsu","state":"DEMOTED"})
        return {"ok": False, "branch":"edbsu", "coverage": cov, "score": comp["score"]}
