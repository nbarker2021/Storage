
from pathlib import Path
from .orchestrator import run
def main():
    base = Path(".")
    out = base / "outputs"; out.mkdir(exist_ok=True)
    res = run(base/"policy"/"snapops_policy.json", base/"policy"/"beacons.json", out/"trails_e2e.jsonl")
    print(res)
if __name__ == "__main__":
    main()
