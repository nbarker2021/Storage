
import json, re
from pathlib import Path
HEADS = {
    "mdhg": ["graph","node","edge","lattice","weyl","e8","mdhg"],
    "snapops": ["policy","gate","coverage","consolidate","branch","assembly","edbsu"],
    "trails": ["trail","event","lineage","replay","determinism"],
    "security": ["acl","secret","encrypt","authz","policy hash"],
    "dtt": ["dry-run","validation","transcript"],
    "assembly": ["stage","workorder","module"]
}
def score_doc(text: str):
    text_l = text.lower()
    counts = {h:0 for h in HEADS}; total = 0
    for h, toks in HEADS.items():
        for t in toks:
            c = len(re.findall(r"\b"+re.escape(t)+r"\b", text_l))
            counts[h]+=c; total+=c
    return {h:(counts[h]/total if total>0 else 0.0) for h in HEADS}
def run(corpus_dir: Path, out_path: Path):
    regions = {}
    for p in Path(corpus_dir).rglob("*"):
        if p.suffix.lower() in (".txt",".md"):
            regions[str(p)] = score_doc(p.read_text(encoding="utf-8", errors="ignore"))
    Path(out_path).write_text(json.dumps(regions, indent=2), encoding="utf-8")
if __name__=="__main__":
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("--corpus", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args(); run(Path(a.corpus), Path(a.out))
