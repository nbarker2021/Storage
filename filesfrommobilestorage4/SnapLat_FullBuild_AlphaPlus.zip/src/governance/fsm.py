
import json
from pathlib import Path
from typing import List, Tuple

class NLevelFSM:
    def __init__(self, spec_path: Path):
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        self.legal = spec["legal"]; self.start = spec["start"]
    def validate(self, path: List[str]) -> Tuple[bool, List[Tuple[str,str]]]:
        prev = self.start; viol=[]
        for s in path:
            if s not in self.legal.get(prev, []): viol.append((prev,s))
            prev=s
        return (len(viol)==0), viol
