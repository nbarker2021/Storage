
import csv, json
import numpy as np
from smp import smp_delta_closure, spectral_fingerprint, label_scale_invariance, ade_check, parity_flow_gaps, hinge_VD_samples, labels

def write_csv(path, rows, header=None):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        if header: w.writerow(header)
        for r in rows: w.writerow(r)

# 1) Δ-closure (depth≤3) — adjacency & edges
A, edges = smp_delta_closure(base_reps=24, max_depth=3)
deg = sorted(A.sum(axis=1).astype(int).tolist())
spec = list(spectral_fingerprint(A))
with open("delta_closure_summary.json","w") as f:
    json.dump({"degree_multiset":deg, "eigvals":spec, "edges":edges, "labels":labels}, f, indent=2)

# 2) Label/scale invariance
inv = label_scale_invariance()
with open("label_scale_invariance.json","w") as f:
    json.dump(inv, f, indent=2)

# 3) ADE check
ade = ade_check(A)
with open("ade_check.json","w") as f:
    json.dump(ade, f, indent=2)

# 4) Parity flows with m=3,5,7 (sidecar gaps)
pf_rows = []
for m in [3,5,7]:
    sizes, gaps = parity_flow_gaps(m)
    pf_rows.append({"m":m, "bundle_sizes":sizes, "gaps":gaps})
with open("parity_flows.json","w") as f:
    json.dump(pf_rows, f, indent=2)

# 5) Hinge interferometer (V–D samples)
VD = hinge_VD_samples(steps=60)
write_csv("VD_samples.csv", VD, header=["V","D","V2_plus_D2"])

print("Wrote: delta_closure_summary.json, label_scale_invariance.json, ade_check.json, parity_flows.json, VD_samples.csv")
