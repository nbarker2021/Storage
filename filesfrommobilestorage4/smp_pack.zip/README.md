
# Single Map Protocol — Repro Pack

This bundle reproduces the invariants we measured in-session:

- **Δ-closure octet** from the n4 rest + geometry + lawful moves + guards + observation
- **Scale** and **label** invariance of the wiring and spectrum
- **Not ADE** (Cartan \(2I-A\) not positive-definite; cycles present)
- **Parity flows** on \(T^{10}\): stable composites with a **small set of gaps** ("mass sidecar")
- **Hinge interferometer**: geometry-only **V–D** tradeoff with \(V^2 + D^2 \le 1\)

## Quickstart

```bash
# From this directory:
python3 run_all.py
# Outputs:
#  - delta_closure_summary.json
#  - label_scale_invariance.json
#  - ade_check.json
#  - parity_flows.json
#  - VD_samples.csv
```

## Files

- `smp.py` — the core implementation (R+G+Δ+Γ+O) and tests
- `run_all.py` — runs the full suite, writes JSON/CSV artifacts
- `*.json`, `VD_samples.csv` — reproducible outputs you can share

No external libraries beyond NumPy are required.
