
import numpy as np
from collections import deque
from dataclasses import dataclass

# ---------- Rest blueprint (n4 palindromic) ----------
def comp_of(x): return x ^ 4  # 0<->4, 1<->5, 2<->6, 3<->7
rest_block = [0,1,2,3, 3,2,1,0]

# ---------- Geometry on 4×4 tile ----------
def lane_of_rc(r,c): return 'A' if ((r+c) % 2 == 0) else 'B'
def geom_of_rc(r,c):
    if (r,c) in [(0,0),(0,3),(3,0),(3,3)]: return "corner"
    if r in (0,3) and c in (1,2):         return "TB edge"
    if c in (0,3) and r in (1,2):         return "LR edge"
    return "center"

rep_coords = {"corner": (0,0), "TB edge": (0,1), "LR edge": (1,0), "center": (1,1)}

def realize_lane(rc, want_lane):
    r,c = rc
    if lane_of_rc(r,c) == want_lane: return (r,c)
    for dr,dc in [(0,1),(0,-1),(1,0),(-1,0)]:
        rr,cc = r+dr, c+dc
        if 0<=rr<4 and 0<=cc<4 and lane_of_rc(rr,cc)==want_lane:
            return (rr,cc)
    return (r,c)

labels = []
hinge_classes = []
for geom_label, rc in rep_coords.items():
    for want_lane in ['A','B']:
        r,c = realize_lane(rc, want_lane)
        hinge_classes.append((geom_label, want_lane, (r,c)))
        labels.append(f"{geom_label}/{want_lane}")
label_to_id = {labels[i]: i for i in range(8)}

# ---------- Guards & metrics ----------
WINDOW_HALF = 12

def window(seq, center_idx, half=WINDOW_HALF):
    a = max(0, center_idx - half)
    b = min(len(seq), center_idx + half)
    return seq[a:b], a, b

def mirror_residual(seq_window):
    rc = [comp_of(x) for x in seq_window[::-1]]
    return sum(1 for x,y in zip(seq_window, rc) if x!=y)

def guards_vector(seq_window):
    k_out = sum(1 for x in seq_window if x>=4)
    frac_rest = sum(1 for x in seq_window if x<=3)/len(seq_window)
    return np.array([k_out, frac_rest], dtype=float)

def guards_ok(gpost, gpre):  return (gpost[0] <= gpre[0]) and (gpost[1] >= gpre[1])

# ---------- Δ moves ----------
@dataclass
class DeltaOutcome:
    new_seq: list
    new_center: int
    preR: int
    postR: int
    gpre: np.ndarray
    gpost: np.ndarray
    move: str

def try_deltas_one_step(seq, center_idx):
    moves = []
    w,_,_ = window(seq, center_idx)
    preR = mirror_residual(w)
    gpre = guards_vector(w)
    # phase
    for shift in [-1,+1]:
        j = center_idx+shift
        if 0<=j<len(seq):
            t = seq.copy(); t[center_idx],t[j] = t[j],t[center_idx]
            w2,_,_ = window(t, j); R2 = mirror_residual(w2); gpost = guards_vector(w2)
            if guards_ok(gpost,gpre) and (R2 < preR):
                moves.append(DeltaOutcome(t, j, preR, R2, gpre, gpost, f"phase_{'R' if shift>0 else 'L'}"))
    # repaint
    t = seq.copy(); t[center_idx] = comp_of(t[center_idx])
    w2,_,_ = window(t, center_idx); R2 = mirror_residual(w2); gpost = guards_vector(w2)
    if guards_ok(gpost,gpre) and (R2 < preR):
        moves.append(DeltaOutcome(t, center_idx, preR, R2, gpre, gpost, "repaint"))
    # recenter
    for shift in [-1,+1]:
        cc = center_idx+shift
        if 0<=cc<len(seq):
            w2,_,_ = window(seq, cc); R2 = mirror_residual(w2)
            if R2 < preR:
                moves.append(DeltaOutcome(seq, cc, preR, R2, gpre, gpre, "recenter"))
    return moves

def idx_from_rc(r,c): return r*4 + c
def rc_from_idx(idx): return (idx//4, idx%4)

# ---------- Δ-closure ----------
def smp_delta_closure(base_reps=24, insert_symbol=5, max_depth=3):
    base_stream = rest_block * base_reps
    tile_len = 16
    tile_center = len(base_stream)//2
    tile_start = tile_center - tile_len//2
    tile_end   = tile_start + tile_len
    starts = []
    for geom,lane,(r,c) in hinge_classes:
        s = base_stream.copy()
        abs_idx = tile_start + (r*4+c)
        s[abs_idx] = insert_symbol
        starts.append((f"{geom}/{lane}", abs_idx, s))
    edges = set()
    for lab, cen, seq in starts:
        seen = set([(lab, cen)])
        q = deque([(lab, cen, seq, 0)])
        while q:
            lab0, cen0, seq0, d = q.popleft()
            if d==max_depth: continue
            for out in try_deltas_one_step(seq0, cen0):
                if not (tile_start <= out.new_center < tile_end): continue
                idx_in_tile = out.new_center - tile_start
                r2,c2 = rc_from_idx(idx_in_tile)
                new_label = f"{geom_of_rc(r2,c2)}/{lane_of_rc(r2,c2)}"
                if new_label != lab0: edges.add((lab0, new_label))
                key = (new_label, out.new_center)
                if key not in seen:
                    seen.add(key)
                    q.append((new_label, out.new_center, out.new_seq, d+1))
    A = np.zeros((8,8), dtype=int)
    for u,v in edges:
        i = label_to_id[u]; j = label_to_id[v]
        A[i,j]=1; A[j,i]=1
    return A, sorted(list(edges))

# ---------- ADE check ----------
def ade_check(A):
    n = A.shape[0]
    E = int(np.sum(A)//2)
    # components
    seen = set(); comps = 0
    for s in range(n):
        if s in seen: continue
        comps += 1
        stack=[s]; seen.add(s)
        while stack:
            u=stack.pop()
            for v in np.where(A[u]>0)[0]:
                if v not in seen:
                    seen.add(v); stack.append(v)
    cycles = E - n + comps
    C = 2*np.eye(n) - A
    lam = np.linalg.eigvalsh(C)
    return {"edges":E, "components":comps, "cycles":cycles, "cartan_min_eig":float(np.min(lam)),
            "cartan_all_pos": bool(np.all(lam>1e-9)), "cartan_eigs": np.round(lam,9).tolist()}

# ---------- Label/scale erasure ----------
def spectral_fingerprint(A):
    vals = np.linalg.eigvalsh(A)
    return tuple(np.round(sorted(vals, reverse=True), 9))

def label_scale_invariance(scales=(12,24,48)):
    rows = []
    for reps in scales:
        A,_ = smp_delta_closure(base_reps=reps, max_depth=3)
        deg = tuple(sorted(A.sum(axis=1).astype(int)))
        eig = spectral_fingerprint(A)
        rows.append({"base_reps": reps, "degree_multiset": deg, "eigvals": eig})
    return rows

# ---------- Parity flows on T^10 with sidecar gaps ----------
def parity_flow_gaps(m):
    # bundle sizes that sum to 10
    sizes = [10//m]*m
    for i in range(10 - sum(sizes)): sizes[i]+=1
    phi = (1+5**0.5)/2
    omegas = []; signs = []; base = 0.6
    idx = 0
    for b in range(m):
        k = np.arange(sizes[b])
        raw = phi**k; raw = raw/np.max(raw)
        w = base * raw
        sgn = 1 if (b%2==0) else -1
        omegas.append(sgn * w)
        signs.extend([sgn]*sizes[b])
        idx += sizes[b]
    omega = np.concatenate(omegas)
    N = 10
    K_in = 1.0
    K_cross = -0.45
    K = np.zeros((N,N))
    idx = 0; bundle_ranges = []
    for b in range(m):
        start = idx; end = idx + sizes[b]
        bundle_ranges.append((start,end))
        for i in range(start,end):
            for j in range(start,end):
                if i!=j: K[i,j] = K_in/ sizes[b]
        idx = end
    for b1 in range(m):
        for b2 in range(m):
            if b1==b2: continue
            sgn = -1 if ((b1+b2)%2==1) else 1
            s1 = slice(bundle_ranges[b1][0], bundle_ranges[b1][1])
            s2 = slice(bundle_ranges[b2][0], bundle_ranges[b2][1])
            K[s1, s2] += (K_cross*sgn)/max(1, sizes[b2])
    # integrate
    dt = 0.02; steps = int(1600/dt)
    theta = np.zeros(N)
    idx = 0
    for b in range(m):
        k = np.arange(sizes[b])
        theta[idx:idx+sizes[b]] = 2*np.pi*((phi*k) % 1.0) * (1 if signs[idx]==1 else -1)
        idx += sizes[b]
    def step(th):
        dth = omega.copy()
        for i in range(N):
            dth[i] += np.sum(K[i,:]*np.sin(th - th[i]))
        return (th + dt*dth) % (2*np.pi)
    for _ in range(steps):
        theta = step(theta)
    # linearize
    J = np.zeros((N,N))
    for i in range(N):
        for j in range(N):
            if i==j:
                J[i,i] += np.sum(K[i,:]*(-np.cos(theta - theta[i])))
            else:
                J[i,j] += K[i,j]*np.cos(theta[j]-theta[i])
    # project out neutral shift
    u = np.ones(N)/np.sqrt(N)
    P = np.eye(N) - np.outer(u,u)
    J_rel = P @ J @ P
    w = np.linalg.eigvals(J_rel)
    gaps = sorted([-np.real(z) for z in w])
    return sizes, gaps

# ---------- Hinge interferometer (V–D) ----------
def hinge_VD_samples(steps=60):
    BASE_REPS = 24
    base_stream = rest_block * BASE_REPS
    tile_len = 16; tile_center = len(base_stream)//2
    tile_start = tile_center - tile_len//2
    def rc_from_idx(idx): return (idx//4, idx%4)
    def window_only(seq, center_idx, half=18):
        a = max(0, center_idx - half)
        b = min(len(seq), center_idx + half)
        return seq[a:b], a, b
    # initial seeds: the 8 hinge classes
    seeds = []
    for (geom,lane,(r,c)) in hinge_classes:
        idx_in_tile = r*4+c
        s = base_stream.copy()
        s[tile_start + idx_in_tile] = 5
        seeds.append((s, tile_start + idx_in_tile, idx_in_tile))
    def V_of(seq_window):
        L = len(seq_window); rcw = [comp_of(x) for x in seq_window[::-1]]
        return 1.0 - sum(1 for x,y in zip(seq_window, rcw) if x!=y)/L
    def D_of(seq_window, idx_in_tile_start):
        L = len(seq_window); acc = 0.0
        for k in range(L):
            idx = (idx_in_tile_start + k) % 16
            r,c = rc_from_idx(idx)
            lane_sign = +1 if ((r+c)%2==0) else -1
            sym_sign  = +1 if seq_window[k] < 4 else -1
            acc += lane_sign * sym_sign
        return abs(acc / L)
    rng = np.random.default_rng(0)
    rows = []
    for s, c_idx, idx_in_tile in seeds:
        seq = s; center = c_idx
        for step in range(steps):
            w, a, b = window_only(seq, center)
            V = V_of(w); D = D_of(w, (center - tile_start) % 16)
            rows.append((V,D,V*V+D*D))
            # step Δ-legally
            moves = try_deltas_one_step(seq, center)
            if not moves: break
            out = moves[rng.integers(0, len(moves))]
            seq = out.new_seq; center = out.new_center
    return rows
