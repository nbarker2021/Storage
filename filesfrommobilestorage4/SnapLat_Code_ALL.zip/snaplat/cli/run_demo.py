from ..core.ids import new_id
from ..core.e8 import nearest_cell, angle
from ..agents.thinktank import propose_c8
from ..agents.dtt_agent import run_boundary_tests
from ..agents.assembly_agent import stitch_best
from ..core.safecube import green_faces
from ..core.sap import arbiter_decide
import random

def demo():
    # 1) Generate 10 random points in 8D; pick C[8]
    rng = random.Random(42)
    pts = [{"id": new_id("snap"), "vec": [rng.uniform(-2,2) for _ in range(8)]} for _ in range(10)]
    c8 = propose_c8(pts, min_angle=20.0)
    # 2) DTT between pairs
    pairs = [{"a": c8[i]["vec"], "b": c8[(i+1)%len(c8)]["vec"]} for i in range(len(c8))]
    dtt = run_boundary_tests(pairs, steps=8)
    # 3) Assembly: simple equal weights
    weights = [1.0/len(c8)]*len(c8)
    stitched = stitch_best([p["vec"] for p in c8], weights, [p["id"] for p in c8])
    # 4) Safe Cube snapshot (dummy all green)
    snapshot = {"faces": {k: {"status":"green"} for k in ("legal","technical","operational","ethical")}}
    decision = arbiter_decide({"safe_cube": snapshot})
    return {"c8_size": len(c8), "dtt_yield": dtt["yield"], "replay_ok": stitched["replay_ok"], "arbiter": decision["decision"]}

if __name__ == "__main__":
    print(demo())
