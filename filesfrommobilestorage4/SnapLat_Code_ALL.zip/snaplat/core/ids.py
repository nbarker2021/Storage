import uuid, hashlib, json
from typing import Any, Dict

def new_id(prefix: str) -> str:
    return f"{prefix}:{uuid.uuid4()}"

def decision_hash(obj: Dict[str, Any]) -> str:
    data = json.dumps(obj, sort_keys=True, separators=(",",":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()
