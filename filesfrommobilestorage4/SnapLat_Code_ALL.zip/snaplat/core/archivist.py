import json, pathlib
from typing import Any, Dict

class Archivist:
    def __init__(self, root: str):
        self.root = pathlib.Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "index.json").write_text("{}", encoding="utf-8") if not (self.root / "index.json").exists() else None

    def save(self, kind: str, obj: Dict[str, Any]) -> str:
        oid = obj.get("id")
        if not oid:
            raise ValueError("Object must have id")
        path = self.root / kind / f"{oid.replace(':','_')}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
        # Update index
        idxp = self.root / "index.json"
        idx = json.loads(idxp.read_text(encoding="utf-8"))
        idx.setdefault(kind, {})[oid] = str(path)
        idxp.write_text(json.dumps(idx, indent=2, sort_keys=True), encoding="utf-8")
        return str(path)

    def load(self, kind: str, oid: str) -> Dict[str, Any]:
        idxp = self.root / "index.json"
        idx = json.loads(idxp.read_text(encoding="utf-8"))
        path = idx.get(kind, {}).get(oid)
        if not path:
            raise KeyError(f"{kind}:{oid} not found")
        return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
