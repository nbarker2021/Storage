from typing import Dict, Any, List
import time

class WavePool:
    def __init__(self):
        self.events: List[Dict[str, Any]] = []

    def emit(self, endpoint: str, phase: str, metrics: Dict[str, float]) -> None:
        self.events.append({"ts": time.time(), "endpoint": endpoint, "phase": phase, "metrics": metrics})

    def rates(self) -> Dict[str, float]:
        return {"count": float(len(self.events))}
