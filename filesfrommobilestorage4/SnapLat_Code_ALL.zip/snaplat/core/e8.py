import math
from typing import List, Tuple

Vector = List[float]

def dot(a: Vector, b: Vector) -> float:
    return sum(x*y for x, y in zip(a, b))

def norm(a: Vector) -> float:
    return math.sqrt(dot(a, a))

def add(a: Vector, b: Vector) -> Vector:
    return [x+y for x, y in zip(a, b)]

def sub(a: Vector, b: Vector) -> Vector:
    return [x-y for x, y in zip(a, b)]

def mul(a: Vector, k: float) -> Vector:
    return [x*k for x in a]

def angle(a: Vector, b: Vector) -> float:
    na, nb = norm(a), norm(b)
    if na == 0 or nb == 0:
        return 0.0
    cosv = max(-1.0, min(1.0, dot(a, b) / (na * nb)))
    return math.degrees(math.acos(cosv))

def nearest_cell(x: Vector) -> Tuple[Tuple[int, ...], Vector]:
    """Nearest cell in a simple Z^8 lattice (pluggable basis in future).
    Returns integer coords and the projected point (rounded).
    """
    p = tuple(int(round(v)) for v in x)
    q = [float(pi) for pi in p]
    return p, q

def k_neighbors(cell: Tuple[int, ...], k: int = 12) -> List[Tuple[int, ...]]:
    """Return Manhattan neighbors within radius 1 up to k items."""
    base = list(cell)
    neigh = []
    for i in range(len(base)):
        for d in (-1, 1):
            c = base.copy(); c[i] += d
            neigh.append(tuple(c))
            if len(neigh) >= k: return neigh
    return neigh

def barymix(points: List[Vector], weights: List[float]) -> Vector:
    assert len(points) == len(weights)
    s = [0.0]*len(points[0]); wsum = 0.0
    for p, w in zip(points, weights):
        s = add(s, mul(p, w)); wsum += w
    if wsum == 0: return s
    return [v/wsum for v in s]

def coxeter_project(x: Vector, axes=(0,1)) -> Tuple[float, float]:
    """Simple 2D projection using two axes as a placeholder."""
    i, j = axes
    return float(x[i]), float(x[j])
