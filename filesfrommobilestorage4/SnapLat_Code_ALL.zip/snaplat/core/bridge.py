from typing import List, Dict, Any
from .e8 import angle

def closure_score(deficiency: List[int], surplus: List[int], incompatibility: float = 0.0) -> float:
    gain = sum(1 for d, s in zip(deficiency, surplus) if d and s)
    return max(0.0, gain - incompatibility)

def e8_coherence(a: List[float], b: List[float], min_angle: float, angle_fn=angle) -> bool:
    return angle_fn(a, b) >= min_angle
