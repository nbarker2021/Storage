import math, random, hashlib
from typing import List, Tuple, Dict
from .e8 import add, mul

PHI = (1 + 5**0.5)/2
GOLDEN_ANGLE = 2*math.pi*(1 - 1/PHI)

def rotate(x: List[float], k: int) -> List[float]:
    # Rotate in (0,1), (2,3), ... planes by angle k*GOLDEN_ANGLE
    ang = k * GOLDEN_ANGLE
    xr = x[:]
    for i in range(0, len(x), 2):
        a, b = xr[i], xr[i+1] if i+1 < len(xr) else 0.0
        xr[i]   =  a*math.cos(ang) - b*math.sin(ang)
        if i+1 < len(xr):
            xr[i+1] =  a*math.sin(ang) + b*math.cos(ang)
    return xr

def quantize(x: List[float], q: float = 1.0) -> Tuple[int, ...]:
    return tuple(int(round(v/q)) for v in x)

def golden_hash(x: List[float], m: int = 4, q: float = 1.0) -> List[Tuple[int, ...]]:
    return [ quantize(rotate(x, k), q) for k in range(m) ]

class CountMinSketch:
    def __init__(self, depth=4, width=1024, seed=0):
        self.depth = depth; self.width = width; self.tables = [[0]*width for _ in range(depth)]
        self.seed = seed

    def _hashes(self, key: str) -> List[int]:
        out = []
        for i in range(self.depth):
            h = hashlib.blake2b((str(i)+key).encode(), digest_size=8).hexdigest()
            out.append(int(h, 16) % self.width)
        return out

    def add(self, key: str, count: int = 1):
        for row, j in enumerate(self._hashes(key)):
            self.tables[row][j] += count

    def est(self, key: str) -> int:
        return min(self.tables[row][j] for row, j in enumerate(self._hashes(key)))

class HotEdgeMaps:
    def __init__(self, lam=0.9):
        self.H: Dict[str, float] = {}
        self.lam = lam

    def hit(self, bucket: str):
        prev = self.H.get(bucket, 0.0)
        self.H[bucket] = self.lam*prev + (1-self.lam)*1.0

    def score(self, bucket: str) -> float:
        return self.H.get(bucket, 0.0)
