from typing import List, Dict, Any
import random
from ..core.e8 import angle

def propose_c8(candidates: List[Dict[str, Any]], min_angle=30.0) -> List[Dict[str, Any]]:
    chosen = []
    for c in candidates:
        vec = c.get("vec",[0]*8)
        if all(angle(vec, x.get("vec",[0]*8)) >= min_angle for x in chosen):
            chosen.append(c)
        if len(chosen) == 8: break
    return chosen
