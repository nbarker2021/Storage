from dataclasses import dataclass, field
from typing import Dict, Any, List, Callable

@dataclass
class Agent:
    id: str
    endpoint: str
    posture: str = "Internal"
    tools: Dict[str, Callable] = field(default_factory=dict)

    def act(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": True, "payload": payload}
