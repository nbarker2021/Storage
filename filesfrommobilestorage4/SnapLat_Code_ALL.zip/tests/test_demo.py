from snaplat.cli.run_demo import demo

def test_demo_runs():
    out = demo()
    assert out["c8_size"] <= 8 and out["replay_ok"]
