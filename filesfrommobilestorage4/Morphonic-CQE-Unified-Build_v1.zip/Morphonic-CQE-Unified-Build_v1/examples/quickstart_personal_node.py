from morphonic_cqe_unified.apps.cqe_personal_node import main
if __name__ == "__main__":
    main()
