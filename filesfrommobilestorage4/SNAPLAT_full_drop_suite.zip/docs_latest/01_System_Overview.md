# System Overview
Seeds→SNAPs on an on-demand E8 lattice; AGRM plans; MDHG builds universes; Master Index shells/glyphs; Agents; SAP; DeepStore; RAG with provenance.
