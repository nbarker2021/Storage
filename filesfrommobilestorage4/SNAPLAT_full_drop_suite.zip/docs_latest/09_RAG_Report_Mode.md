# RAG Report Mode
Inline provenance markers; weighted stitching; audit-friendly.
