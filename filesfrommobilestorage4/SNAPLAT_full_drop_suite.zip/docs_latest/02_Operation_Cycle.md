# Operation Cycle
0 stance/tick → 1 sense/glyphify → 2 plan → 3 build → 4 stage → 5 stitch/compute → 6 govern → 7 feedback → 8 adapt.
