# Failure Catalog
Levels tick/snap/chain; taxonomy; roll-ups; repair playbooks.
