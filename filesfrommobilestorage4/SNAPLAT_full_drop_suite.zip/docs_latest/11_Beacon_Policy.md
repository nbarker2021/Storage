# Beacon Policy
Decay; SAP override; snapshots.
