# Restore Recipes
Rehydrate kernels with posture; integrity digests; fail-closed.
