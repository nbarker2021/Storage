import click, pathlib
from triads.sap_snapops_archivist.snapops.runner import run_tick
from kernel.telemetry import emit

@click.command()
@click.option("--seed", default=1729, help="Seed")
@click.option("--ticks", default=1, help="How many ticks to run")
@click.option("--bump-policy", is_flag=True, help="Simulate a governance update (GCR barrier)")
from api.governance import policy_update

def main(seed, ticks, bump_policy):
    pathlib.Path("outputs/reports").mkdir(parents=True, exist_ok=True)
    slice_desc = {"labels": {"family":"demo","type":"example"}, "glyph":{"triplet":["w1","w2","w3"], "i_class": 1}}
    env = {"gpu_mem_gb": 16, "io_mb_s": 500}
    budgets = {"gpu_mem_gb": 2, "io_mb_s": 100}
    status = []
    if bump_policy:
        policy_update('policy: demo', signer='demo-signer')
    for t in range(ticks):
        res = run_tick(t, slice_desc, env, budgets)
        status.append(res)
        emit("tick.done", "runner", {"t": t, "res": res})
    print("[tick] results:", status)
    try:
        import subprocess
        subprocess.run(["python","tools/trailview.py"], check=False)
    except Exception:
        pass

if __name__ == "__main__":
    main()
