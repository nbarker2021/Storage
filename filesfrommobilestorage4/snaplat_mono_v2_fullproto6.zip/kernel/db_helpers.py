from .db import get_conn, exec_sql, query
import json, time
from security.tenant import universe_for_user

def insert_route(route, user_id='system'):
    conn = get_conn()
    exec_sql(conn, "INSERT OR REPLACE INTO routes(route_id, universe_id, score, nodes_visited, octant_spread, created_at) VALUES(?,?,?,?,?,?)",
             (route["route_id"], route.get("universe_id", universe_for_user(user_id)), route["score"], route["nodes_visited"], route["octant_spread"], route.get("created_at", int(time.time()*1000))))

def insert_endpoint(ep, user_id='system'):
    conn = get_conn()
    exec_sql(conn, "INSERT OR REPLACE INTO endpoints(endpoint_id, universe_id, finalized, evidence_nodes, agreement, created_at) VALUES(?,?,?,?,?,?)",
             (ep["endpoint_id"], ep.get("universe_id", universe_for_user(user_id)), int(ep.get("finalized",0)), ep.get("evidence_nodes",0), ep.get("agreement",0.0), ep.get("created_at", int(time.time()*1000))))

def insert_topk_row(tick, phase, octant, choice_id, kind, score, evidence_nodes, agreement, created_at=None):
    conn = get_conn()
    created_at = created_at or int(time.time()*1000)
    exec_sql(conn, "INSERT OR REPLACE INTO i8_topk(tick,phase,octant,choice_id,choice_kind,score,evidence_nodes,agreement,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
             (tick, phase, octant, choice_id, kind, score, evidence_nodes, agreement, created_at))

def current_topk_for_octant(octant:int):
    conn = get_conn()
    rows = query(conn, "SELECT choice_id, choice_kind, score FROM v_i8_topk_current WHERE octant=?", (octant,))
    return [dict(r) for r in rows]

def evict_stale_topk(ttl_ticks:int):
    conn = get_conn()
    # a naive TTL on created_at (ms) vs now; convert ttl_ticks to ms by multiplying 1e3 arbitrarily (demo)
    cutoff = int(time.time()*1000) - ttl_ticks*1000
    exec_sql(conn, "DELETE FROM i8_topk WHERE created_at < ?", (cutoff,))

def fetch_recent_trails(limit:int=200):
    conn = get_conn()
    rows = query(conn, "SELECT trail_id,kind,thing_id,payload_json,created_at FROM trails ORDER BY created_at DESC LIMIT ?", (limit,))
    return [{"trail_id": r["trail_id"], "kind": r["kind"], "thing_id": r["thing_id"], "payload": json.loads(r["payload_json"]), "created_at": r["created_at"]} for r in rows]
