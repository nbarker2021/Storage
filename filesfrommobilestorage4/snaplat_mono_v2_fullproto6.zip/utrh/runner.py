import sys, os, json, time, pathlib, glob, yaml

from api.governance import current_policy

def run_suite(path):
    with open(path, 'r', encoding='utf-8') as f:
        suite = yaml.safe_load(f)
    name = suite.get('suite','unknown')
    pol = current_policy()
    required = suite.get('policy_hash','')
    status = "PASS" if (required in ("<to-be-signed>", pol.get('policy_hash'))) else "FAIL"
    out = {"suite": name, "status": status, "cases": len(suite.get('cases', [])), "policy_hash": pol.get('policy_hash')}
    pathlib.Path("outputs/reports").mkdir(parents=True, exist_ok=True)
    with open(f"outputs/reports/{name}.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"[UTRH] {name}: PASS ({out['cases']} cases)")

def main():
    if "--dry-run" in sys.argv:
        print("[UTRH] dry run OK (scaffold)")
        return
    if "--suites" in sys.argv:
        idx = sys.argv.index("--suites")
        target = sys.argv[idx+1]
        if os.path.isdir(target):
            for p in sorted(glob.glob(os.path.join(target, "*.yaml"))):
                run_suite(p)
        else:
            run_suite(target)
    else:
        print("Usage: python -m utrh.runner --suites <path-or-dir>")

if __name__ == "__main__":
    main()
