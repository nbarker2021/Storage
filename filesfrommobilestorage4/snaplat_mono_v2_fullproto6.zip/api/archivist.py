import json, pathlib
from triads.sap_snapops_archivist.archivist.revalidate import revalidate_all
from triads.sap_snapops_archivist.archivist.cas import get
from kernel.telemetry import emit

CAS_DIR = pathlib.Path("outputs/cas")

def _iter_lockfiles():
    for p in CAS_DIR.glob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        if obj.get("kind") == "lockfile":
            yield p, obj

def revalidate_endpoint(endpoint_id: str):
    updated = []
    for p, obj in _iter_lockfiles():
        if obj.get("payload", {}).get("endpoint_id") == endpoint_id:
            # simple: call full sweep (which rewrites in place) and report
            r = revalidate_all()
            emit("lockfile.revalidate_single", "archivist", {"endpoint": endpoint_id, "result": r})
            return r
    return {"updated": [], "invalid": [], "note": "endpoint lockfile not found"}

def get_lockfile(hash_id: str):
    obj = get(hash_id)
    emit("lockfile.get", "archivist", {"hash": hash_id, "found": obj is not None})
    return obj
