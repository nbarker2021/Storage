PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS policies (
  policy_hash TEXT PRIMARY KEY,
  name TEXT,
  version TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS trails (
  trail_id TEXT PRIMARY KEY,
  kind TEXT,
  thing_id TEXT,
  payload_json TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS routes (
  route_id TEXT PRIMARY KEY,
  universe_id TEXT,
  score REAL,
  nodes_visited INTEGER,
  octant_spread INTEGER,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS endpoints (
  endpoint_id TEXT PRIMARY KEY,
  universe_id TEXT,
  finalized INTEGER DEFAULT 0,
  evidence_nodes INTEGER,
  agreement REAL,
  created_at INTEGER
);

-- I8 rotation
CREATE TABLE IF NOT EXISTS i8_rotation_params (
  k_default INTEGER NOT NULL DEFAULT 8,
  rotation_cycle INTEGER NOT NULL DEFAULT 8,
  freshness_ttl INTEGER NOT NULL DEFAULT 16,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS i8_topk (
  tick INTEGER NOT NULL,
  phase INTEGER NOT NULL,       -- 0..7 maps to I1..I8
  octant INTEGER NOT NULL,      -- 1..8
  choice_id TEXT NOT NULL,      -- route_id or endpoint_id
  choice_kind TEXT NOT NULL,    -- 'route'|'endpoint'
  score REAL NOT NULL,
  evidence_nodes INTEGER DEFAULT 0,
  agreement REAL DEFAULT 0.0,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (tick, octant, choice_id)
);
CREATE INDEX IF NOT EXISTS idx_i8_topk_phase ON i8_topk(phase);

CREATE VIEW IF NOT EXISTS v_i8_topk_current AS
WITH last_tick AS (
  SELECT octant, MAX(tick) AS tick
  FROM i8_topk
  GROUP BY octant
)
SELECT t.*
FROM i8_topk t
JOIN last_tick l USING (octant, tick);

CREATE VIEW IF NOT EXISTS v_i8_consensus AS
SELECT e.endpoint_id,
       CASE WHEN EXISTS (
         SELECT 1 FROM i8_topk tk
         WHERE tk.choice_kind='endpoint' AND tk.choice_id=e.endpoint_id
       ) THEN 1 ELSE 0 END AS endpoint_in_topk,
       e.finalized
FROM endpoints e;


-- Overlays & Lineage
CREATE TABLE IF NOT EXISTS overlays (
  overlay_id TEXT PRIMARY KEY,
  universe_id TEXT,
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS overlay_members (
  overlay_id TEXT,
  member_id TEXT,
  role TEXT,
  PRIMARY KEY (overlay_id, member_id)
);
CREATE TABLE IF NOT EXISTS lineage_edges (
  src_id TEXT,
  dst_id TEXT,
  weight REAL DEFAULT 0.0,
  created_at INTEGER,
  PRIMARY KEY (src_id, dst_id)
);

-- Anchors / ALID / URN
CREATE TABLE IF NOT EXISTS anchors (
  anchor_id TEXT PRIMARY KEY,
  alid TEXT,
  surface_id TEXT,
  urn TEXT,
  created_at INTEGER
);

-- Crosswalks (privacy/temporal)
CREATE TABLE IF NOT EXISTS crosswalks (
  cw_id TEXT PRIMARY KEY,
  kind TEXT,                   -- privacy|temporal|rbac
  src_surface TEXT,
  dst_surface TEXT,
  policy TEXT,                 -- JSON policy snippet
  created_at INTEGER
);


CREATE VIEW IF NOT EXISTS v_taxicab_ready AS
SELECT e.endpoint_id, e.evidence_nodes, e.agreement, e.finalized
FROM endpoints e
WHERE e.evidence_nodes >= 1729 AND e.finalized=1;


-- RBAC minimal schema
CREATE TABLE IF NOT EXISTS rbac_roles (
  role_id TEXT PRIMARY KEY,
  description TEXT
);
CREATE TABLE IF NOT EXISTS rbac_users (
  user_id TEXT PRIMARY KEY,
  tenant_id TEXT
);
CREATE TABLE IF NOT EXISTS rbac_user_roles (
  user_id TEXT,
  role_id TEXT,
  PRIMARY KEY (user_id, role_id)
);
CREATE TABLE IF NOT EXISTS rbac_perms (
  role_id TEXT,
  action TEXT,
  resource TEXT,
  PRIMARY KEY (role_id, action, resource)
);
