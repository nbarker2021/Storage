from kernel.telemetry import emit
from triads.reasoning_overlays.uro.checks import run_truth_filter
from triads.reasoning_overlays.ero.estimator import capacity_ok
from triads.reasoning_overlays.cto.window import context_ok
from kernel.db_helpers import fetch_recent_trails, evict_stale_topk
from triads.thinktank_dtt_assembly.thinktank.engine import expand_8_plus_8, rank_and_report, to_cas as tt_to_cas
from triads.snap_agrm_mdhg.agrm.routes import seed_routes, consensus_k2
from triads.snap_agrm_mdhg.mdhg.overlays import check_overlay
from kernel.db_helpers import current_topk_for_octant, insert_anchor
from triads.sap_snapops_archivist.sap.schedulers import autotune_i8
from triads.thinktank_dtt_assembly.dtt.sandbox import invariants_ok, to_cas as dtt_to_cas
from triads.thinktank_dtt_assembly.assembly.publish import finalize_1729
from triads.sap_snapops_archivist.archivist.recall import write_lockfile
from security.rbac import has_perm, ensure_defaults, DEFAULT_USER
from triads.sap_snapops_archivist.archivist.cas import put as cas_put

def i8_phase(tick:int)->int: return tick % 8

from kernel.db_helpers import insert_route, insert_endpoint, insert_topk_row
from api.governance import barrier_state, clear_barrier

def run_tick(tick:int, slice_desc:dict, env:dict, budgets:dict):
    # GCR barrier check
    bs = barrier_state()
    if bs.get('engaged'):
        emit('gcr.barrier.start', 'governance', {'tick': tick})
    emit('scp.detect', 'runner', {'tick': tick})
    emit('scp.group', 'runner', {'phase': 'pre-barrier'})
    # Law-first
    ok, rs = run_truth_filter(slice_desc); emit("lawcheck.universal_pass" if ok else "lawcheck.universal_fail", "slice", {"reasons": rs})
    if not ok: return {"status":"FAIL","stage":"URO"}
    ok, rs = capacity_ok(env, budgets); emit("lawcheck.environment_pass" if ok else "lawcheck.environment_fail", "env", {"reasons": rs})
    if not ok: return {"status":"FAIL","stage":"ERO"}
    recent = fetch_recent_trails(200)
    ok, rs = context_ok(recent, None); emit("lawcheck.context_pass" if ok else "lawcheck.context_fail", "ctx", {"reasons": rs})
    if not ok: return {"status":"FAIL","stage":"CTO"}
        emit('scp.group', 'runner', {'phase': 'i8-prestage'})
    # I8 rotation
    phase = i8_phase(tick); emit("i8.rotation.phase", "phase", {"phase": phase})
        emit('scp.group', 'runner', {'phase': 'explore-adjudicate'})
    # evict stale Top-K entries by TTL heuristic
    evict_stale_topk(ttl_ticks=16)
    # ThinkTank
    seeds = ["alpha","beta","gamma"]
    # Top-K union seeding preference
    tk = current_topk_for_octant(phase+1)
    tk_route_ids = [r['choice_id'] for r in tk if r['choice_kind']=='route']
    seeds = tk_route_ids + seeds
    cands = expand_8_plus_8(seeds); emit("triad_expansion", "thinktank", cands)
    report = rank_and_report(cands); emit("thinktank_selection", "thinktank", report)
    tt_hash = tt_to_cas({"kind":"AdjudicationReport","report":report}, cas_put); emit("cas.write", "thinktank", {"hash": tt_hash})
    # AGRM
    routes = seed_routes([s for s in cands["relevant"]]); emit("route_records", "agrm", {"count": len(routes)})
    topk_ids = set(tk_route_ids)
    ep = consensus_k2(routes, topk_ids)
    if not ep.get("final"): return {"status":"FAIL","stage":"AGRM"}
    # Persist endpoint draft
    ep['created_at'] = int(__import__('time').time()*1000)
    insert_endpoint({**ep, 'finalized': 0})
    # MDHG overlay check
    r_scores = {r['route_id']: r['score'] for r in routes}
    ov_ok, ov_rs, ov_info = check_overlay(ep["k_routes"], r_scores); emit("overlay_checks", "mdhg", {"ok": ov_ok, "reasons": ov_rs, "info": ov_info})
    if not ov_ok: return {"status":"FAIL","stage":"MDHG"}
    # DTT
    workorder = {"wo_id":"wo1","required_checks":["glyph","delta_tau"],"policy_hash":"demo"}
    dtt_ok, dtt_rs = invariants_ok(workorder); emit("dtt.checks", "dtt", {"ok": dtt_ok, "reasons": dtt_rs})
    dtt_hash = dtt_to_cas({"kind":"DttReport","ok":dtt_ok,"reasons":dtt_rs,"wo":workorder}, cas_put); emit("cas.write", "dtt", {"hash": dtt_hash})
    if not dtt_ok: return {"status":"FAIL","stage":"DTT"}
    # Assembly
    if bs.get('engaged'):
        emit('gcr.freeze.finalize', 'assembly', {'tick': tick})
        return {'status':'PENDING_GCR', 'stage':'ASM', 'endpoint': ep['endpoint_id']}
    fin_ok, fin_rs = finalize_1729(ep); emit("1729_gate", "assembly", {"ok": fin_ok, "reasons": fin_rs})
    # Update endpoint as finalized
    if fin_ok:
        insert_endpoint({**ep, 'finalized': 1})
    # I8 Top-K: write entries for current octant
    phase = i8_phase(tick)
    octant = phase+1
    now = int(__import__('time').time()*1000)
    # Add endpoint
    insert_topk_row(tick, phase, octant, ep['endpoint_id'], 'endpoint', ep.get('agreement',0.0), ep.get('evidence_nodes',0), ep.get('agreement',0.0), now)
    # Add top K routes by score
    for r in sorted(routes, key=lambda x: -x['score'])[:8]:
        insert_topk_row(tick, phase, octant, r['route_id'], 'route', r['score'], 0, 0.0, now)
    if not fin_ok: return {"status":"FAIL","stage":"ASM"}
    # RBAC check for publish
    ensure_defaults()
    if not has_perm(DEFAULT_USER['user_id'], 'publish', 'lockfile'):
        return {'status':'FAIL','stage':'RBAC'}
    # Anchors: simple insert
    insert_anchor(anchor_id=f"anc_{ep['endpoint_id']}", alid="ALID:demo", surface="demo.surface", urn=f"urn:snaplat:{ep['endpoint_id']}")
    # Publish lockfile
    from triads.thinktank_dtt_assembly.assembly.publish import build_lockfile
    lf = build_lockfile({**ep, "reports": [tt_hash, dtt_hash]})
    lf_hash = write_lockfile(ep["endpoint_id"], lf); emit("asm.publish", "assembly", {"lockfile": lf_hash, "signed": True})
        if bs.get('engaged'):
        clear_barrier(tick)
        # auto-tune I8 based on consensus view
    _tune = autotune_i8()
    return {"status":"PASS","endpoint": ep["endpoint_id"], "lockfile": lf_hash, "i8_autotune": _tune}
