import hashlib, json, pathlib
CAS_DIR = pathlib.Path("outputs/cas"); CAS_DIR.mkdir(parents=True, exist_ok=True)
def put(obj) -> str:
    raw = json.dumps(obj, sort_keys=True).encode("utf-8")
    h = hashlib.blake2b(raw, digest_size=16).hexdigest()
    with open(CAS_DIR / f"{h}.json", "wb") as f: f.write(raw)
    return h
def get(h: str):
    p = CAS_DIR / f"{h}.json"
    return None if not p.exists() else json.loads(p.read_text(encoding="utf-8"))
