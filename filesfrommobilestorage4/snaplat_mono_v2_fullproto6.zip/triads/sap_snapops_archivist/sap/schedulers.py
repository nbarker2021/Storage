from kernel.db import get_conn, query, exec_sql

def autotune_i8():
    conn = get_conn()
    # heuristic: if v_i8_consensus shows many endpoints touched, keep K=8; else reduce to 4
    rows = query(conn, "SELECT COUNT(1) as c FROM v_i8_consensus WHERE endpoint_in_topk=1", ())
    c = rows[0]["c"] if rows else 0
    K = 8 if c >= 1 else 4
    TTL = 16 if c >= 1 else 8
    exec_sql(conn, "UPDATE i8_rotation_params SET k_default=?, freshness_ttl=?, updated_at=strftime('%s','now')*1000", (K, TTL))
    return {"K": K, "TTL": TTL}
