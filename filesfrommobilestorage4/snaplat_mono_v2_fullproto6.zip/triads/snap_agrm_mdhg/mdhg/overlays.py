from kernel.db_helpers import insert_overlay
from policy.helpers import get_delta_tau_threshold

def check_overlay(members: list[str], routes_with_scores: dict) -> (bool, list, dict):
    reasons = []
    info = {"delta": 0.0, "tau": 0}
    if len(set(members)) < 2:
        reasons.append("overlay.members.invalid")
        return (False, reasons, info)
    a, b = members[0], members[1]
    sa = routes_with_scores.get(a, 0.5)
    sb = routes_with_scores.get(b, 0.5)
    delta = abs(sa - sb)             # Δ := score difference (0..1)
    info["delta"] = delta
    info["tau"] = 1
    if delta > get_delta_tau_threshold():
        reasons.append("delta_tau.violation")
        return (False, reasons, info)
    insert_overlay(overlay_id=f"ov_{a}_{b}", members=members)
    return (True, reasons, info)
