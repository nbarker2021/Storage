from kernel.db import get_conn, query

def context_ok(recent_trails: list, lockfile_endpoint_id: str|None) -> (bool, list):
    reasons = []
    # trail contradiction heuristic
    for t in recent_trails[-50:]:
        if t.get("kind","").endswith(".contradiction"):
            reasons.append("trail.contradiction"); break
    # crosswalk privacy check: if a privacy crosswalk exists, deny
    conn = get_conn()
    rows = query(conn, "SELECT cw_id FROM crosswalks WHERE kind='privacy' LIMIT 1", ())
    if rows:
        reasons.append("privacy.crosswalk.boundary")
    return (len(reasons) == 0, reasons)
