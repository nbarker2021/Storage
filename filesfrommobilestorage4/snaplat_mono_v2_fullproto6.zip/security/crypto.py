import json, hashlib

# Attempt to import real Ed25519 providers; if unavailable, fall back.
_SIG_MODE = "fallback-hmac"
try:
    from cryptography.hazmat.primitives.asymmetric import ed25519 as _ed
    from cryptography.hazmat.primitives import serialization as _ser
    _CRYPTO = "cryptography"
    _SIG_MODE = "ed25519-cryptography"
except Exception:
    _CRYPTO = None

def _pem_body(text:str)->bytes:
    lines = [l for l in text.strip().splitlines() if "BEGIN" not in l and "END" not in l]
    return "".join(lines).encode("utf-8")

def load_keypair(pem_path="security/signer_demo.pem"):
    # For demo, the PEM file body is used as seed; in real mode, proper PEM is required.
    try:
        raw = open(pem_path, "r", encoding="utf-8").read()
    except FileNotFoundError:
        return {"mode": _SIG_MODE, "pub": None, "priv": None}
    seed = _pem_body(raw)
    if _CRYPTO:
        try:
            # Use seed bytes deterministically to construct a private key (not real PEM parsing).
            # WARNING: For demo only; in production load real PEM private key.
            priv = _ed.Ed25519PrivateKey.from_private_bytes((seed + b"0"*32)[:32])
            pub = priv.public_key()
            return {"mode": _SIG_MODE, "pub": pub, "priv": priv}
        except Exception:
            pass
    # fallback
    return {"mode": "fallback-hmac", "pub": hashlib.blake2b(seed, digest_size=16).hexdigest(), "priv": seed}

def sign(payload:dict, keypair=None)->str:
    keypair = keypair or load_keypair()
    msg = json.dumps(payload, sort_keys=True).encode("utf-8")
    if keypair["mode"].startswith("ed25519"):
        return keypair["priv"].sign(msg).hex()
    # fallback HMAC-like
    return hashlib.blake2b((keypair["priv"] or b"") + msg, digest_size=32).hexdigest()

def verify(payload:dict, sig:str, keypair=None)->bool:
    keypair = keypair or load_keypair()
    msg = json.dumps(payload, sort_keys=True).encode("utf-8")
    if keypair["mode"].startswith("ed25519"):
        try:
            keypair["pub"].verify(bytes.fromhex(sig), msg)
            return True
        except Exception:
            return False
    # fallback
    return hashlib.blake2b((keypair["priv"] or b"") + msg, digest_size=32).hexdigest() == sig

def pub_fingerprint(keypair=None)->str:
    keypair = keypair or load_keypair()
    if keypair["mode"].startswith("ed25519"):
        try:
            pub_bytes = keypair["pub"].public_bytes(encoding=None, format=None)
        except Exception:
            # minimal fingerprint from repr
            pub_bytes = repr(keypair["pub"]).encode("utf-8")
        return hashlib.blake2b(pub_bytes, digest_size=8).hexdigest()
    # fallback
    return str(keypair["pub"])

def mode()->str:
    return load_keypair()["mode"]
