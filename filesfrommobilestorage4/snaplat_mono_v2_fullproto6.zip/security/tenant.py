DEFAULT_TENANT = "demo"

def universe_for_user(user_id: str)->str:
    # simple mapping; extend with RMI table if needed
    return DEFAULT_TENANT
