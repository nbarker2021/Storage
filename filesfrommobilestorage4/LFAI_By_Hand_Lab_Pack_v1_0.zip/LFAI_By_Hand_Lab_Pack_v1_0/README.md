# LFAI By-Hand Lab Pack v1.0
UTC: 2025-09-16T23:13:18Z

What this pack gives you:
- Pen-and-paper checklists to run the legality test without code
- A tiny, valid parity-check matrix for the **[8,4,4] extended Hamming code** so you can test Type-II (via Construction-A -> E8) by hand
- Palindromy (mod-4/mod-8) tally sheets
- Three fully worked examples (REST, PROVISIONAL, REJECT)
- Pocket cheat cards for NGU (numeric glyphs) and E8 membership

All files are Markdown (easy to print).