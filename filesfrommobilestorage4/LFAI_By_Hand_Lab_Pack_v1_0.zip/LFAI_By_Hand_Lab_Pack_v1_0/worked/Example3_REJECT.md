# Worked Example 3 — REJECT

Pick x with stubborn pal asymmetry that cannot be resolved within arm bundle.
Suppose after several allowed primitive moves:
- s=0 but P4 remains > theta4 under all legal updates without violating other constraints.

Verdict: REJECT under current frame. Extension would need enabling an extra residue lane (Extend()), which must be priced and signed.
