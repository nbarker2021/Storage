# Worked Example 2 — PROVISIONAL (NTER)

Token: "marsLanding"  -> frame tau=1/4, S=64, mods include {2,4,8,13,5,7}.

Structure check passes (s=0; P4=P8=0). External pins required:
- atm_density_known (pending)
- dv_budget_known (pending)

Verdict: PROVISIONAL-OPEN. Gate CLOSED until pins satisfied; replay deterministic.
