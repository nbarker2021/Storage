# Worked Example 1 — REST (Open)

x = [13,7,9,2,18,5,1,12], theta4=0, theta8=0

A. Parity:
x mod 2 = [1,1,1,0,0,1,1,0]. Multiply by H -> s=0  (OK).

B. Palindromy:
mod 4 counts h^(4) = [c0,c1,c2,c3] = [?, ?, ?, ?]
- Residues: [1,3,1,2,2,1,1,0]  -> counts: c0=1, c1=4, c2=2, c3=1
- P4 = |4 - 1| = 3  (NOT OK).

mod 8 counts -> compute residues: [5,7,1,2,2,5,1,4]
- h^(8): 0:0,1:2,2:2,3:0,4:1,5:2,6:0,7:1
- P8 = |h1-h7| + |h2-h6| + |h3-h5| = |2-1| + |2-0| + |0-2| = 1+2+2=5 (NOT OK)

C. Reduction:
Primitive moves that strictly decrease Phi=(wt(s),P8,P4,rho).
- idx4: 2->3, idx6:5->6, idx7:1->0 (as in our earlier example).

Re-evaluate:
- s=0; P4=0; P8=0  -> REST.

D. Verdict: REST (OPEN). Key=(frame,shell,coset) logged; commit once.
