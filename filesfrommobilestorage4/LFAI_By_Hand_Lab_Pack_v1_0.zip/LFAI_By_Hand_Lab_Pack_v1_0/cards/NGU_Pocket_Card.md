# Pocket Card — NGU (Numeric-Glyph Unifier)

For any number n you drop, bind all four meanings:

1) Thresholds: 1/8 = representation, 1/4 = driving (1/4 outranks 1/8).
2) Scale S: snap to 4^k family; promote 16 -> 64 if 1/4 gate drives.
3) Residues: add prime factors of n to the CRT basket (plus {2,4,8}).
4) Faces: lane hints (octad, two-slice hub, E8 witnesses, etc.).

If these collide, parity wins; report the minimal patch to reconcile.
