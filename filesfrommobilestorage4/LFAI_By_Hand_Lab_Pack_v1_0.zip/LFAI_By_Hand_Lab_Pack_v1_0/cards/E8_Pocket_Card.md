# Pocket Card — E8 Membership (By Hand)

**Way A (Construction-A from [8,4,4] extended Hamming):**
- Parity-check matrix H (one valid choice):
  H = 
  [1 1 1 1 1 1 1 1
   1 1 1 1 0 0 0 0
   1 1 0 0 1 1 0 0
   1 0 1 0 1 0 1 0]

- Given x in Z^8, compute (x mod 2) as a length-8 bit vector.
- Syndrome s = H * (x mod 2)^T over F2. Require s = 0 for legality.
- Canonical coset rep: choose lexicographically minimal in x + 2C.
- Evenness: ||x||^2 is even (automatic for Construction-A E8 when s=0).

**Way B (classic E8 test):**
- Either (i) x has all integer entries and sum(x) is even;
- Or (ii) x has all half-integer entries (k+1/2) and sum(x) is even.
Both cases are equivalent to E8 membership.
