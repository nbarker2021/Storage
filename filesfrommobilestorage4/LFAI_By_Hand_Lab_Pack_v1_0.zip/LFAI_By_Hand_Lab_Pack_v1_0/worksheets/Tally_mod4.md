# Tally Sheet — mod 4
Boxes (tick marks):

0: [                                                 ]
1: [                                                 ]
2: [                                                 ]
3: [                                                 ]

P4 = |count(1) - count(3)|
