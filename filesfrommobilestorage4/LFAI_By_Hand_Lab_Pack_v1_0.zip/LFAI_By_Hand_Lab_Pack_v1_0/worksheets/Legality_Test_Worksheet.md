# Worksheet — Legality Test (By Hand)

Input: vector x in Z^8 (or R^8 you quantize), thresholds theta4,theta8 (default 0,0).

A. CRT & Parity (mod 2)
[ ] Reduce each coordinate modulo 2 -> bits b1..b8
[ ] Multiply H*b^T in F2 with H from the E8 pocket card
[ ] If syndrome s != 0: mark ACTION (needs reduction)

B. Palindromy (mod 4, mod 8)
[ ] Reduce coordinates mod 4; tally counts for 0,1,2,3 -> h^(4)
[ ] Compute P4 = |h1 - h3|; check P4 <= theta4
[ ] Reduce mod 8; tally h^(8) for 0..7
[ ] Compute P8 = |h1-h7| + |h2-h6| + |h3-h5|; check P8 <= theta8

C. Type-II shell (via E8)
[ ] If s=0 and (P4,P8 pass), accept canonical rep in x+2C
[ ] Else perform primitive reduction moves that strictly decrease Phi=(wt(s),P8,P4,rho)

D. Verdict
- REST (OPEN): s=0, P4,P8 pass, canonical rep chosen
- ACTION (PROVISIONAL-CLOSE): Phi decreased but not yet zero
- REJECT: cannot satisfy under current frame
- PROVISIONAL-OPEN (NTER): structure OK; external pins pending
