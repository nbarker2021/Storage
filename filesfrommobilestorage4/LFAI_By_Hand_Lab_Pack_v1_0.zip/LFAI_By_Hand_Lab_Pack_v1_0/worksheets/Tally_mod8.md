# Tally Sheet — mod 8
Boxes (tick marks):

0: [                               ]  4: [                               ]
1: [                               ]  5: [                               ]
2: [                               ]  6: [                               ]
3: [                               ]  7: [                               ]

P8 = |h1-h7| + |h2-h6| + |h3-h5|
