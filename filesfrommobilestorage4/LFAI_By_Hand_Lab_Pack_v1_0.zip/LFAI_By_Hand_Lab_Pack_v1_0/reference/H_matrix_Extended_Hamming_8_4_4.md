# Reference — Parity-Check Matrix H for [8,4,4] (Extended Hamming)

Use this H for by-hand syndrome checks (Construction-A -> E8):

H =
[1 1 1 1 1 1 1 1
 1 1 1 1 0 0 0 0
 1 1 0 0 1 1 0 0
 1 0 1 0 1 0 1 0]

Compute s = H * (x mod 2)^T in F2; accept only if s = 0.
