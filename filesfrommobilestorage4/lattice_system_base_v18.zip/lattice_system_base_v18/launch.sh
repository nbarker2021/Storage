
#!/usr/bin/env bash
export LATTICE_DB_PATH=${LATTICE_DB_PATH:-/mnt/data/lattice_ai_v16.db}
export LATTICE_API_KEY=${LATTICE_API_KEY:-}
export LATTICE_BUDGET_P95_MS=${LATTICE_BUDGET_P95_MS:-20}
uvicorn rest.app:app --host 0.0.0.0 --port 8000
