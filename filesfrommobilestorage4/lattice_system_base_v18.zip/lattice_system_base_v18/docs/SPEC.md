
# Lattice System SPEC (Living)
**Scope:** Safe Cube, Hashing, Shells & Policies, Per‑datum lattices, Routing, Persistence, Jobs, Metrics.

## 1. Safe Cube
- Space: R^8 with deterministic glyph→vector mapping.
- Hashing: two-tier (Tier‑1 geometric LSH; Tier‑2 trainable semantic).
- Houses: (h1,h2) buckets; neighbors and hotness maintained.

**Invariants**
- Glyph vectors are unit‑normalized.
- House hotness decays or is aged every access window.

## 2. Shells & Policies
- Shells: concentric neighbor sets around a center.
- QA metrics: size, coherence, redundancy, domain.
- Policy thresholds enforce promotion; flip‑rate monitored.
- Probes: recency, novelty, contradiction risk; recorded in promotion metrics.

**Invariants**
- Only **promoted** shells feed retrieval.
- Any contradiction risk across promoted members triggers quarantine.

## 3. Per‑datum lattices
- Local maps (template + delta), KV memory with capability tags.
- KPIs: round‑trip distortion (alerts when over threshold).

**Invariants**
- KV writes require capability.
- Distortion bound guards local map quality.

## 4. Routing
- Two‑stage: house prefilter → exact rank; optional local routing.
- Budget controller picks `k` to meet p95 latency budget (v3 has a learned linear cost model).

## 5. Persistence & Jobs
- SQLite with indices & migrations; schedules stored.
- Task queue with retries+backoff; sweeps: contradiction risk, shell re‑eval, clusters.

## 6. Metrics & Tests
- Metrics counters/gauges/histograms exposed via `/metrics`.
- Golden tests enforce recall/latency floors.

**Release Gates**
- Goldens passing.
- No task queue backlog growth.
- No shell flip‑rate spikes for configured domains.

---
**Open items**
- Learned α/β blending.
- Secure auth (JWT) and per‑tenant isolation.
- UI: fuller exploration of houses and shells, policy editor.
