
"""
Budget controller (v3) with a tiny learned cost model.
Model: latency_ms ≈ a * k + b
- Online update via simple least-squares on a rolling window.
- Fallback to heuristic if insufficient observations.
"""
from dataclasses import dataclass, field
from typing import List, Tuple
import time, numpy as np
from .router import Router
from .config import Config

@dataclass
class CostModel:
    xs: List[float] = field(default_factory=list)
    ys: List[float] = field(default_factory=list)
    max_points: int = 50
    a: float = 0.2  # slope init
    b: float = 2.0  # intercept init

    def add(self, k: int, lat_ms: float):
        self.xs.append(float(k)); self.ys.append(float(lat_ms))
        if len(self.xs) > self.max_points:
            self.xs = self.xs[-self.max_points:]
            self.ys = self.ys[-self.max_points:]
        self.fit()

    def fit(self):
        if len(self.xs) < 5:
            return
        X = np.vstack([self.xs, np.ones(len(self.xs))]).T
        y = np.array(self.ys)
        sol, *_ = np.linalg.lstsq(X, y, rcond=None)
        self.a, self.b = float(sol[0]), float(sol[1])

    def predict(self, k: int) -> float:
        return self.a * k + self.b

@dataclass
class BudgetController:
    p95_budget_ms: float = Config.BUDGET_P95_MS
    k_min: int = Config.CANDIDATE_MIN
    k_max: int = Config.CANDIDATE_MAX
    k_start: int = Config.CANDIDATE_START
    cost: CostModel = field(default_factory=CostModel)

    def _measure(self, router: Router, center_id: str, k: int, use_promoted: bool):
        t0 = time.time()
        cands = router.prefilter([center_id], k_candidates=k, use_promoted_for=center_id if use_promoted else None)
        _ = router.exact_rank(center_id, cands, top_k=min(20, len(cands))) if cands else []
        dt = (time.time()-t0)*1000.0
        self.cost.add(k, dt)
        return dt, cands

    def query(self, router: Router, center_id: str, use_promoted: bool = True, top_k: int = 10):
        # Choose k using predicted latency
        # If no model yet, start at k_start and adapt
        k = self.k_start
        if len(self.cost.xs) >= 5:
            # find k closest to budget
            k_pred = int(max(self.k_min, min(self.k_max, (self.p95_budget_ms - self.cost.b)/max(1e-6,self.cost.a))))
            k = k_pred
        lat, cands = self._measure(router, center_id, k, use_promoted)
        # If still over budget, shrink and re-measure once
        if lat > 1.2*self.p95_budget_ms and k > self.k_min:
            k2 = max(self.k_min, int(k*0.6))
            lat, cands = self._measure(router, center_id, k2, use_promoted)
            k = k2
        top = router.exact_rank(center_id, cands, top_k=top_k) if cands else []
        return {"latency_ms": lat, "k_candidates": k, "candidates": cands, "top": top}
