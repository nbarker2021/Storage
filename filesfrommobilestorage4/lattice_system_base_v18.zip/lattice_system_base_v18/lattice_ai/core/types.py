
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple
import numpy as np

@dataclass
class Glyph:
    id: str
    tags: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ShellRecord:
    glyph_id: str
    center_id: str
    shell_k: int
    payload_hash: str
    stats: Dict[str, float]
    provenance: Dict[str, str]
    members: list = field(default_factory=list)
    ttl: int = 10080
    access_policy: str = "default"

@dataclass
class House:
    h1: bytes
    h2: bytes
    items: List[str] = field(default_factory=list)
    hotness: float = 0.0
    neighbors: List[Tuple[bytes, bytes]] = field(default_factory=list)

@dataclass
class Anchor:
    id: str
    v: np.ndarray
    tags: Dict[str, Any] = field(default_factory=dict)
