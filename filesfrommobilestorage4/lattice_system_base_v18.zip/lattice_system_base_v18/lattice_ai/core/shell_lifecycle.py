
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Callable, Optional
import json, numpy as np
from .types import ShellRecord
from .shell_qa import ShellQASuite, ShellPromotionRules

@dataclass
class PromotionReport:
    center_id: str
    shell_k: int
    decision: str
    metrics: Dict[str, float]
    policy: Dict[str, float]

@dataclass
class ShellState:
    record: ShellRecord
    state: str = "candidate"  # candidate | promoted | quarantined
    metrics: Dict[str, float] = field(default_factory=dict)

@dataclass
class ShellManager:
    records: Dict[str, List[ShellState]] = field(default_factory=dict)
    reports: List[PromotionReport] = field(default_factory=list)

    def create(self, center_id: str, shells: Dict[int, List[str]], hash_fn, built_by="ShellBuilder"):
        lst = self.records.setdefault(center_id, [])
        for k, items in shells.items():
            h = hash_fn(center_id + "|" + ",".join(items))
            rec = ShellRecord(
                glyph_id="g::"+center_id, center_id=center_id, shell_k=k,
                payload_hash=h, stats={"size":float(len(items))},
                provenance={"built_by":built_by}, members=items, ttl=10080, access_policy="default",
            )
            lst.append(ShellState(record=rec, state="candidate"))

    def validate_and_promote(self, center_id: str, suite: ShellQASuite, rules: ShellPromotionRules,
                             get_vector: Callable[[str], np.ndarray], score_fn: Optional[Callable[[str], float]] = None,
                             policy_name: str = "default"):
        lst = self.records.get(center_id, [])
        flips = 0; total = 0
        for st in lst:
            ids = st.record.members
            size = len(ids)
            if size == 0:
                st.metrics = {"size":0.0,"coherence":0.0,"redundancy":0.0,"domain":0.0}
                continue
            c = get_vector(st.record.center_id)
            X = np.stack([get_vector(mid) for mid in ids], axis=0)
            metrics = suite.run(c, X, score_fn if score_fn else (lambda _:0.0), ids)
            old = st.state
            st.state = "promoted" if rules.decide(metrics) else "candidate"
            st.metrics = metrics
            self.reports.append(PromotionReport(
                center_id=center_id, shell_k=st.record.shell_k, decision=st.state,
                metrics=metrics, policy={
                    "name":policy_name, "min_size":rules.min_size, "min_coherence":rules.min_coherence,
                    "max_redundancy":rules.max_redundancy, "min_domain":rules.min_domain
                }
            ))
            if old != st.state:
                flips += 1
            total += 1
        flip_rate = (flips / max(1,total))
        return flip_rate

    def promoted_members(self, center_id: str) -> List[str]:
        out = []
        for st in self.records.get(center_id, []):
            if st.state == "promoted":
                out.extend(st.record.members)
        return list(dict.fromkeys(out))

    def save_json(self, path: str):
        data = {"records":{}, "reports":[asdict(r) for r in self.reports]}
        for cid, lst in self.records.items():
            data["records"][cid] = []
            for st in lst:
                data["records"][cid].append({"record":asdict(st.record),"state":st.state,"metrics":st.metrics})
        with open(path,"w") as f:
            json.dump(data,f,indent=2)

    def load_json(self, path: str):
        raw = json.load(open(path,"r"))
        self.reports = [PromotionReport(**r) for r in raw.get("reports",[])]
        self.records = {}
        for cid, lst in raw.get("records",{}).items():
            self.records[cid] = []
            for item in lst:
                rec = ShellRecord(**item["record"])
                self.records[cid].append(ShellState(record=rec, state=item["state"], metrics=item.get("metrics",{})))


def auto_expand_and_promote(self, center_id: str, policy, builder, suite, rules_factory, get_vector, score_fn=None):
    """
    Re-run promotion; if flip-rate exceeds policy.max_flip_rate or promotion coverage is low,
    expand shells by policy.expand_step up to policy.max_shell_k using `builder(center_id, max_k)`.
    - policy: DomainPolicy
    - builder: fn(center_id, max_k, nn) -> shells dict
    - rules_factory: fn(policy) -> ShellPromotionRules (so thresholds respect policy)
    Returns dict with flip_rate, promoted_count, max_k_used.
    """
    # Determine current max_k
    existing = self.records.get(center_id, [])
    max_k_cur = max([st.record.shell_k for st in existing], default=0)

    def promote_once():
        rules = rules_factory(policy)
        flip = self.validate_and_promote(center_id, suite, rules, get_vector, score_fn, policy_name=policy.name)
        promoted = len(self.promoted_members(center_id))
        return flip, promoted, rules

    flip, promoted, rules = promote_once()
    max_k_used = max_k_cur

    coverage_ok = promoted >= policy.min_size  # simple proxy
    if flip > policy.max_flip_rate or not coverage_ok:
        # expand shells
        new_max_k = min(policy.max_shell_k, max(1, max_k_cur) + policy.expand_step)
        if new_max_k > max_k_cur:
            shells = builder(center_id, new_max_k, nn=12)
            # Add only new shells
            have = set((st.record.shell_k, st.record.payload_hash) for st in existing)
            for k, items in shells.items():
                if k <= max_k_cur: 
                    continue
                h = str(abs(hash(center_id + "|" + ",".join(items))))
                key = (k, h)
                if key in have:
                    continue
                rec = ShellRecord(
                    glyph_id="g::"+center_id, center_id=center_id, shell_k=k,
                    payload_hash=h, stats={"size":float(len(items))},
                    provenance={"built_by":"auto_expand"}, members=items, ttl=10080, access_policy="default"
                )
                self.records.setdefault(center_id, []).append(ShellState(record=rec, state="candidate"))
            max_k_used = new_max_k
            flip, promoted, rules = promote_once()

    return {"flip_rate": flip, "promoted": promoted, "max_k_used": max_k_used}


def set_probe_hook(self, hook):
    """
    hook(center_id: str, members: List[str]) -> Dict[str,float]
    Attach extra probe metrics into shell metrics under keys 'probe_*'.
    """
    self._probe_hook = hook
