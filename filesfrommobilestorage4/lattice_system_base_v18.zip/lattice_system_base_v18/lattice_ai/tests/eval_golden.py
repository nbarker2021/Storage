
"""
Golden evaluation for recall@K under a latency budget.
- Synthetic clustered dataset.
- Uses BudgetController v3 to choose k.
- Fails (non-zero exit) if recall@10 < threshold or latency > cap.
"""
import json, sys
from lattice_ai.tests.hash_eval_suite import run_eval

def main():
    gold = json.load(open("/mnt/data/golden_override.json","r")) if False else json.load(open(__file__.replace("eval_golden.py","golden.json"), "r"))
    # Baseline (random tier-2)
    base = run_eval(weights_json=None, n_items=3000, n_clusters=12, k=10)
    # Treat reported latency as the latency to compare (proxy)
    ok1 = base["recall@10"] >= gold["recall_at_10_min"]
    ok2 = base["latency_ms"] <= gold["latency_ms_max"]
    print({"recall@10": base["recall@10"], "latency_ms": base["latency_ms"], "ok": ok1 and ok2})
    sys.exit(0 if (ok1 and ok2) else 1)

if __name__ == "__main__":
    main()
