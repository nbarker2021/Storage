
#!/usr/bin/env bash
set -euo pipefail
python -m lattice_ai.tests.eval_golden
python -m lattice_ai.tests.routing_golden
echo "ALL GOLDENS OK"
