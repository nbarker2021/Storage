
import numpy as np
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.semantic_hash import SemanticHashTrainer

def main():
    cube = SafeCube(dim=8, seed=3)
    # Synthetic clustered data
    centers = [cube.glyph_vector(f"c::{i}") for i in range(8)]
    X = []
    y_pairs = []
    for i, c in enumerate(centers):
        for k in range(30):
            x = c + 0.05*np.random.randn(8)
            x = x / (np.linalg.norm(x)+1e-9)
            X.append(x)
            if k > 0:
                y_pairs.append([len(X)-1, len(X)-2, +1])  # similar within cluster
    # cross negatives
    for i in range(0, len(X)-1, 20):
        j = (i+50) % len(X)
        y_pairs.append([i, j, -1])

    X = np.stack(X, axis=0)
    y_pairs = np.array(y_pairs, dtype=float)

    trainer = SemanticHashTrainer(dim=8, bits=64, steps=400, lr=0.05, seed=7)
    W,b = trainer.fit(X, y_pairs)
    imb = trainer.bit_imbalance(X, W, b)
    print("Bit imbalance (avg |mean|):", round(imb,4))

if __name__ == "__main__":
    main()
