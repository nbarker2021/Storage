# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import json, requests

BASE="http://localhost:8000"
def main():
    # seed config
    requests.post(f"{BASE}/config/set", json={"config":{}})
    # issue token
    tok = requests.post(f"{BASE}/perm/issue", json={"sub":"ACME","scope":"eval-only","ttl_sec":3600}).json()["token"]
    hdr = {"Authorization": f"Bearer {tok}"}
    r = requests.post(f"{BASE}/octet/run", headers=hdr, json={"lanes":[1,2,3,4,0,0,0,0],"glyphs":[2,4,8,13]})
    print("octet:", r.status_code, r.headers.get("X-Color-ID"), r.json())
    p = requests.post(f"{BASE}/nter/patch", headers=hdr, json={"lanes":[1,3,5,7,2,4,6,8]}).json()
    print("patch:", p)

if __name__=="__main__":
    main()
