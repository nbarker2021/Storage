# Short‑Form NDA (1 page)
[Purpose; term; outputs; restrictions; return/destroy; injunctive relief; law/venue; signatures.]