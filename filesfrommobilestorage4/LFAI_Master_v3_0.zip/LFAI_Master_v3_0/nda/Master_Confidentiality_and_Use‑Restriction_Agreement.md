# Master NDA (MCURA)
[Strict: outputs included; no training/benchmark; residuals disclaimed; return/destroy + attestation; injunctive relief.]