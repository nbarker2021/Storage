# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
from lfaicore.reducer import reduce_to_rest
def test_idempotent():
    x=[1,2,3,4,5,6,7,8]
    a=reduce_to_rest(x)
    b=reduce_to_rest(a)
    assert a==b
