# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
from fastapi import FastAPI, Request, Body
from fastapi.responses import JSONResponse
import time, json, hashlib

from lfaicore.config import load as cfg_load, save as cfg_save, get as cfg_get
from lfaicore.jws import sign_hs256
from lfaicore.jws_guard import jws_ok
from lfaicore.cid import compute_cid
from lfaicore.residues import crt_basket
from lfaicore.pal import pal_defects
from lfaicore.legal_e8 import legal_even
from lfaicore.gating import evaluate_faces
from lfaicore.anchors import anchor_id
from lfaicore.ledger import append as ledger_append, offload as ledger_offload
from lfaicore.reducer import reduce_to_rest
from lfaicore.patcher import patch, violation_vec

app = FastAPI(title="LFAI Master API", version="3.0.0")

@app.get("/health")
def health():
    return {"ok": True, "version": "3.0.0"}

@app.get("/config/get")
def config_get():
    return cfg_load()

@app.post("/config/set")
def config_set(data: dict = Body(...)):
    cfg = cfg_load()
    cfg.update(data.get("config", {}))
    if not cfg.get("jws_secret"):
        cfg["jws_secret"] = hashlib.sha256(str(time.time()).encode()).hexdigest()
    if not cfg.get("color_secret"):
        cfg["color_secret"] = hashlib.sha256(("color"+str(time.time())).encode()).hexdigest()
    return cfg_save(cfg)

@app.post("/perm/issue")
def perm_issue(data: dict = Body(...)):
    cfg = cfg_load()
    secret_hex = cfg.get("jws_secret","")
    try: secret = bytes.fromhex(secret_hex)
    except Exception: secret = secret_hex.encode()
    now = int(time.time())
    payload = {
        "iss": "Nick",
        "sub": data.get("sub","unknown"),
        "scope": data.get("scope","eval-only"),
        "policy_id": data.get("policy_id","EVAL"),
        "endpoints": data.get("endpoints", cfg.get("jws_endpoint_prefixes", ["/octet/","/channel/","/planner/"])),
        "anchors": data.get("anchors", []),
        "iat": now,
        "nbf": data.get("nbf", now),
        "exp": now + int(data.get("ttl_sec", 86400)),
        "jti": f"perm-{now}"
    }
    token = sign_hs256(secret, {"alg":"HS256","typ":"JWT"}, payload)
    return {"token": token, "payload": payload}

def _emit_headers(request: Request, token_payload: dict, anchor: str | None = None):
    sub = token_payload.get("sub","")
    policy_id = token_payload.get("policy_id") or token_payload.get("scope") or cfg_get("policy_defaults",{}).get("fallback_policy_id","EVAL")
    if isinstance(policy_id, list): policy_id = policy_id[0] if policy_id else "EVAL"
    jti = token_payload.get("jti","")
    prefixes = cfg_get("jws_endpoint_prefixes", ["/octet/","/channel/","/planner/"])
    ep = next((p for p in prefixes if request.url.path.startswith(p)), "/")
    # color secret
    secret_hex = cfg_get("color_secret","")
    try: secret = bytes.fromhex(secret_hex)
    except Exception: secret = secret_hex.encode()
    cid_hex, cid_tag = compute_cid(secret, sub, str(policy_id), ep)
    headers = {
        "X-Color-ID": cid_hex,
        "X-Policy-ID": str(policy_id),
        "X-Permission-JTI": jti,
        "X-Contract-Sub": sub
    }
    if anchor: headers["X-Anchor"] = anchor
    meta = {"cid": cid_hex, "cid_tag": cid_tag, "policy_id": str(policy_id), "sub": sub, "jti": jti}
    return headers, meta

def _wrap_response(request: Request, token_payload: dict, body: dict):
    try:
        hdrs, meta = _emit_headers(request, token_payload, body.get("anchor_id"))
        body = dict(body); body["_policy_meta"]=meta
        return JSONResponse(body, headers=hdrs)
    except Exception:
        return JSONResponse(body)

FACE_RULES = [
    {"type":"ge","threshold":0.0},
    {"type":"le","threshold":10.0},
    {"type":"band","lo":-0.5,"hi":0.5},
    {"type":"ge","threshold":0.0},
    {"type":"ge","threshold":0.0},
    {"type":"le","threshold":2.0},
    {"type":"band","lo":-1.0,"hi":1.0},
    {"type":"ge","threshold":1.0},
]

@app.post("/octet/run")
def octet_run(request: Request, body: dict = Body(...)):
    ok, detail = jws_ok(request)
    if not ok:
        return JSONResponse({"error":"permission token","detail":detail}, status_code=401)
    lanes = body.get("lanes",[0]*8)
    glyphs = body.get("glyphs",[2,4,8,13])
    residues = crt_basket(lanes, mods=tuple(sorted(set([2,4,8,13]+glyphs))))
    pal = pal_defects(lanes)
    legal = legal_even(lanes[:8])
    faces, latches = evaluate_faces(lanes, FACE_RULES)
    anchor = anchor_id({"lanes":lanes, "residues":residues, "pal":pal, "legal":legal, "latches":latches})
    ledger_append({"kind":"octet_run","anchor":anchor,"lanes":lanes,"res":residues,"pal":pal,"legal":legal,"latches":latches})
    resp = {"ok": True, "anchor_id": anchor, "residues": residues, "pal_defects": pal, "legal_even": legal, "faces": faces, "latches": latches}
    return _wrap_response(request, detail if isinstance(detail, dict) else {}, resp)

@app.post("/nter/patch")
def nter_patch(request: Request, body: dict = Body(...)):
    ok, detail = jws_ok(request)
    if not ok:
        return JSONResponse({"error":"permission token","detail":detail}, status_code=401)
    lanes = body.get("lanes",[0]*8)
    before_v = violation_vec(lanes, FACE_RULES)
    patched = patch(lanes)
    after_v = violation_vec(patched, FACE_RULES)
    anchor = anchor_id({"lanes":patched,"before":before_v,"after":after_v})
    ledger_append({"kind":"patch","anchor":anchor,"lanes_in":lanes,"lanes_out":patched,"before":before_v,"after":after_v})
    resp = {"ok": True, "anchor_id": anchor, "lanes_out": patched, "before": before_v, "after": after_v}
    return _wrap_response(request, detail if isinstance(detail, dict) else {}, resp)

@app.post("/ledger/offload")
def ledger_offload_ep(request: Request):
    ok, detail = jws_ok(request)
    if not ok:
        return JSONResponse({"error":"permission token","detail":detail}, status_code=401)
    path = ledger_offload()
    return JSONResponse({"ok": bool(path), "path": path or ""})
