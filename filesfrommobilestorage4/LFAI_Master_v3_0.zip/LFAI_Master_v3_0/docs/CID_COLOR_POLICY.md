# Color/Policy CID — Operational Skin (Bound to Permission)
- CID derived from server secret + token subject + policy_id + endpoint prefix.
- Headers: X-Color-ID, X-Policy-ID, X-Permission-JTI, X-Contract-Sub, X-Anchor
- Ledger stores: {cid, cid_tag, policy_id, sub, jti} via `_policy_meta` in responses.
