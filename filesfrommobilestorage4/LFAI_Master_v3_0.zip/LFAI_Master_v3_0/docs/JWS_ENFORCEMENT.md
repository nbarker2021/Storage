# JWS Permission Enforcement
- Require tokens on guarded endpoints; check signature/time/scope/endpoints.
- Issue tokens via /perm/issue (HS256). Send as Authorization: Bearer <token>.
