# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import os, json, time, gzip
from .config import get as cfg_get, load as cfg_load, save as cfg_save

def append(entry: dict):
    path = cfg_get("ledger_path","/mnt/data/lfai_ledger.jsonl")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    entry = {"ts": time.time(), **entry}
    with open(path,"a",encoding="utf-8") as f:
        f.write(json.dumps(entry, separators=(',',':')) + "\n")
    return entry

def offload():
    src = cfg_get("ledger_path","/mnt/data/lfai_ledger.jsonl")
    if not os.path.exists(src): return None
    dst = f"/mnt/data/lfai_ledger_offload_{int(time.time())}.jsonl.gz"
    with open(src,"rb") as inf, gzip.open(dst,"wb") as outf:
        outf.write(inf.read())
    return dst
