# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import os, json, time, hashlib

CFG_PATH = os.environ.get("LFAI_CONFIG","/mnt/data/lfai_config.json")
DEFAULTS = {
  "jws_required": True,
  "jws_enforce_endpoints": True,
  "jws_endpoint_prefixes": ["/octet/","/channel/","/planner/"],
  "jws_required_scope": "eval-only",
  "jws_secret": "",
  "color_secret": "",
  "policy_defaults": {"fallback_policy_id": "EVAL"},
  "ledger_path": "/mnt/data/lfai_ledger.jsonl"
}

def load():
  cfg = {}
  if os.path.exists(CFG_PATH):
    try:
      cfg = json.loads(open(CFG_PATH,"r",encoding="utf-8").read())
    except Exception:
      cfg = {}
  for k,v in DEFAULTS.items():
    cfg.setdefault(k,v)
  if not cfg.get("jws_secret"):
    cfg["jws_secret"] = hashlib.sha256(str(time.time()).encode()).hexdigest()
  if not cfg.get("color_secret"):
    cfg["color_secret"] = hashlib.sha256(("color"+str(time.time())).encode()).hexdigest()
  save(cfg)
  return cfg

def save(cfg):
  os.makedirs(os.path.dirname(CFG_PATH), exist_ok=True)
  with open(CFG_PATH,"w",encoding="utf-8") as f:
    json.dump(cfg, f, indent=2)
  return cfg

def get(key, default=None):
  return load().get(key, default)
