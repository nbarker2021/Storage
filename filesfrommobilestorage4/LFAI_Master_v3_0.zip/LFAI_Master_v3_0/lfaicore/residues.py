# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
def residues(vec, mod):
    return [((x % mod)+mod)%mod for x in vec]

def crt_basket(vec, mods=(2,4,8,13)):
    return {m: residues(vec, m) for m in mods}
