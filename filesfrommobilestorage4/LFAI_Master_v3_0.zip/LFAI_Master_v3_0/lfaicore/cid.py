# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import hmac, hashlib

def _to_hex_color(digest: bytes) -> str:
    r,g,b = digest[0], digest[1], digest[2]
    return f"#{r:02x}{g:02x}{b:02x}"

def compute_cid(secret: bytes, sub: str, policy_id: str, endpoint_prefix: str):
    msg = f"{sub}|{policy_id}|{endpoint_prefix}".encode()
    dig = hmac.new(secret, msg, hashlib.sha256).digest()
    return _to_hex_color(dig), dig.hex()
