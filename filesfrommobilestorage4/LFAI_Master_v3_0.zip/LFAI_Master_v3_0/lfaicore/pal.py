# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
def pal_defect_mod(vec, m: int):
    # simple histogram anti-symmetry score under mod-m
    from collections import Counter
    vals = [v % m for v in vec]
    c = Counter(vals)
    defect = 0
    for k in range(m):
        twin = (-k) % m
        defect += abs(c.get(k,0) - c.get(twin,0))
    return defect

def pal_defects(vec):
    return {"P4": pal_defect_mod(vec,4), "P8": pal_defect_mod(vec,8)}
