# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
# Placeholder Type-II / ConA legality proxy. Replace with real ECC checks.
def legal_even(vec8):
    # miniature "syndrome": even parity on 8-wide slice
    if len(vec8)<8: vec8 = vec8 + [0]*(8-len(vec8))
    bits = [(1 if (x & 1) else 0) for x in vec8[:8]]
    syndrome = sum(bits) % 2
    return {"legal": syndrome==0, "syndrome": syndrome, "bits": bits}
