# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
def estimate_commit_energy(num_ops:int, writes:int):
    # toy estimator; replace with real accounting
    return {"ops": num_ops, "writes": writes, "energy_units": 0.001*num_ops + 0.01*writes}
