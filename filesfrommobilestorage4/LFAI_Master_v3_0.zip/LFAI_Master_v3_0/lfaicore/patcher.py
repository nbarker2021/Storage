# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
from .pal import pal_defects
from .legal_e8 import legal_even
from .gating import evaluate_faces

def violation_vec(vec, rules):
    le = legal_even(vec[:8])
    pal = pal_defects(vec)
    faces, latches = evaluate_faces(vec, rules)
    face_fail = sum(1 for x in latches if x==0)
    return (0 if le["legal"] else 1, pal["P8"], face_fail)

def patch(vec):
    # simple heuristic: fix parity by decrementing first odd;
    # then mild center shift to help faces
    out = vec[:]
    # parity
    if sum( (x&1) for x in out[:8]) %2 == 1:
        for i in range(min(8,len(out))):
            if out[i] & 1:
                out[i]-=1; break
    # center
    mean = sum(out)/max(1,len(out))
    out = [int(round(x-0.1*(x-mean))) for x in out]
    return out
