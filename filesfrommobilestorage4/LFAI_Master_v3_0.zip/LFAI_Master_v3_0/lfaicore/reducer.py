# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
def reduce_step(vec):
    # toy: nudge odd entries toward even
    return [x-1 if x%2 else x for x in vec]

def reduce_to_rest(vec, max_steps=8):
    cur = list(vec)
    for _ in range(max_steps):
        nxt = reduce_step(cur)
        if nxt==cur: break
        cur = nxt
    return cur
