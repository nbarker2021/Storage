# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import json, hmac, hashlib, time
from .config import get as cfg_get

def sign_contract(obj: dict):
    secret = cfg_get("jws_secret","").encode()
    data = json.dumps(obj, sort_keys=True, separators=(',',':')).encode()
    sig = hmac.new(secret, data, hashlib.sha256).hexdigest()
    return {"payload": obj, "sig": sig, "ts": int(time.time())}

def verify_contract(bundle: dict):
    secret = cfg_get("jws_secret","").encode()
    data = json.dumps(bundle.get("payload",{}), sort_keys=True, separators=(',',':')).encode()
    exp = hmac.new(secret, data, hashlib.sha256).hexdigest()
    return hmac.compare_digest(exp, bundle.get("sig",""))
