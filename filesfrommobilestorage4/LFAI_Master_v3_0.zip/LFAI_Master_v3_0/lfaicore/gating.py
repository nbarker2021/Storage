# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
def faces_basic(vec):
    # placeholder: eight simple values
    # replace via faces_e8.faces for real Cartan-style faces
    import math
    s = sum(abs(x) for x in vec) + 1e-9
    feats = [sum(vec[i::8]) for i in range(8)]
    return [f/s for f in feats]

def evaluate_faces(vec, rules: list[dict]):
    vals = faces_basic(vec)
    latches = []
    for v, rule in zip(vals, rules):
        t = rule.get("type","ge")
        if t=="ge":
            latches.append(1 if v >= rule.get("threshold",0.0) else 0)
        elif t=="le":
            latches.append(1 if v <= rule.get("threshold",0.0) else 0)
        elif t=="band":
            latches.append(1 if rule.get("lo",-1e9) <= v <= rule.get("hi",1e9) else 0)
        else:
            latches.append(0)
    return vals, latches
