# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
from fastapi import Request
from .config import get as cfg_get
from .jws import verify_hs256

def _get_token(req: Request) -> str:
    auth = req.headers.get("Authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth.split(" ",1)[1].strip()
    return req.headers.get("X-Permission-Token") or ""

def _scope_ok(payload, required):
    if not required: return True
    scope = payload.get("scope")
    if isinstance(required, str): required=[required]
    if isinstance(scope, str): scope=[scope]
    if not isinstance(scope, list): return False
    return any(r in scope for r in required)

def jws_ok(request: Request):
    if not cfg_get("jws_required", False): return True, {"reason":"not-required"}
    tok = _get_token(request)
    if not tok: return False, {"err":"missing"}
    secret_hex = cfg_get("jws_secret","")
    try: secret = bytes.fromhex(secret_hex)
    except Exception: secret = secret_hex.encode()
    ok, info = verify_hs256(tok, secret)
    if not ok: return False, info
    pl = info.get("payload",{})
    if not _scope_ok(pl, cfg_get("jws_required_scope", None)):
        return False, {"err":"scope"}
    # endpoint prefix enforcement
    if cfg_get("jws_enforce_endpoints", True):
        eps = pl.get("endpoints") or cfg_get("jws_endpoint_prefixes", ["/octet/","/channel/","/planner/"])
        if not any(request.url.path.startswith(p) for p in eps):
            return False, {"err":"endpoint"}
    return True, pl
