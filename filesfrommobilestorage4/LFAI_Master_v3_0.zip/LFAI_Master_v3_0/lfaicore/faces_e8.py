# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
# Stub for true E8 faces; implement or plug your backend and point config to it.
def faces(vec):
    from .gating import faces_basic
    return faces_basic(vec)
