# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import json, time, hmac, hashlib, base64
from typing import Tuple, Dict, Any

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()

def _b64url_decode(s: str) -> bytes:
    pad = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode())

def sign_hs256(secret: bytes, header: Dict[str,Any], payload: Dict[str,Any]) -> str:
    hdr = _b64url(json.dumps(header, separators=(',',':')).encode())
    pl  = _b64url(json.dumps(payload, separators=(',',':')).encode())
    msg = f"{hdr}.{pl}".encode()
    sig = hmac.new(secret, msg, hashlib.sha256).digest()
    return f"{hdr}.{pl}.{_b64url(sig)}"

def verify_hs256(token: str, secret: bytes) -> Tuple[bool, Dict[str,Any]]:
    try:
        parts = token.split('.')
        if len(parts)!=3: return False, {"err":"format"}
        hdr_b, pl_b, sig_b64 = parts
        msg = f"{hdr_b}.{pl_b}".encode()
        sig = _b64url_decode(sig_b64)
        exp_sig = hmac.new(secret, msg, hashlib.sha256).digest()
        if not hmac.compare_digest(sig, exp_sig): return False, {"err":"sig"}
        header = json.loads(_b64url_decode(hdr_b))
        payload= json.loads(_b64url_decode(pl_b))
        now = int(time.time())
        nbf = int(payload.get("nbf", 0))
        exp = int(payload.get("exp", 0)) if "exp" in payload else None
        if now < nbf: return False, {"err":"nbf"}
        if exp is not None and now >= exp: return False, {"err":"exp"}
        return True, {"header": header, "payload": payload}
    except Exception as e:
        return False, {"err":"exc", "detail": str(e)}
