# SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1
import hashlib, json
def anchor_id(payload: dict):
    data = json.dumps(payload, sort_keys=True, separators=(',',':')).encode()
    return hashlib.sha256(data).hexdigest()
