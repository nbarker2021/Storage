# Permission Notice (for LFAI Restricted Source License v1.1)
[Fill grantee, scope, term, territory, anchors, key thumbprint; sign both sides.]
