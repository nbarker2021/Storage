# Evaluation & Access Master Use Agreement (EAMUA)
(Combined NDA + evaluation license; includes no-training/benchmarking, no reverse-engineering, residuals disclaimed, field-of-use/territory; with Schedule A and optional JWS token Annex.)
[Fillable — see previous pack; copy here for convenience.]
