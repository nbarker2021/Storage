# LFAI — Legality‑First AI (Master v3.0)

This is the **master** combined repo that unifies all prior drops:
- Corridor runtime (REST ⊕ Δ, 8‑face gating, STOP/NTER patching, commit‑once ledger)
- Permission enforcement (JWS tokens), **color/policy CID** headers + ledger binding
- Strict licensing + master Evaluation & Access agreement + NDAs
- CLI/examples/tests + Docker/Compose + CI SPDX header check

> Design stance: legality before similarity. Deterministic, audit‑ready, single‑commit.

## Quick start
```bash
# 1) Install
pip install -r requirements.txt

# 2) Run API (dev)
uvicorn server.api:app --port 8000 --reload

# 3) Seed config (generates secrets)
curl -s localhost:8000/config/set -H 'content-type: application/json' -d '{"config":{}}' | jq

# 4) Issue a permission token
TOKEN=$(curl -s localhost:8000/perm/issue -H 'content-type: application/json'   -d '{"sub":"ACME","scope":"eval-only","ttl_sec":3600}' | jq -r .token)

# 5) Call a guarded endpoint
curl -s localhost:8000/octet/run -H "Authorization: Bearer $TOKEN"   -H 'content-type: application/json' -d '{"lanes":[1,2,3,4,0,0,0,0], "glyphs":[2,4,8,13]}' | jq
```

You’ll see **X‑Color‑ID**, **X‑Policy‑ID**, **X‑Permission‑JTI**, **X‑Contract‑Sub** headers, and the response body includes residues, pal defects, face latches, an anchor id, and a ledger hash.

## What’s here
- `server/` — FastAPI app with JWS guard, CID headers, STOP/NTER patch, ledger offload
- `lfaicore/` — modular core (config, jws, cid, residues, pal, gating, legality, anchors, ledger, reducer, patcher, contracts, energy, utils)
- `docs/` — CID color policy, enforcement guides
- `legal/` — master Evaluation & Access agreement (EAMUA), strict repo license, permission templates
- `nda/` — NDA templates (master + variants)
- `examples/` — smoke test
- `tests/` — determinism & confluence sanity checks
- CI: `.github/workflows/license_check.yml` (SPDX header enforcement)

## License
Source‑available, **permission‑only**: see `legal/STRICT_SOURCE_LICENSE_v1.1.txt`. You must have a signed permission grant (EAMUA Schedule A / Permission Notice) to use.

