import json
from fastapi.openapi.utils import get_openapi
from lfaicore.api import app as core_app
from sandbox.api import app as sandbox_app

def export():
    core = get_openapi(title=core_app.title, version=core_app.version, routes=core_app.routes)
    sand = get_openapi(title=sandbox_app.title, version=sandbox_app.version, routes=sandbox_app.routes)
    bundle = {"core": core, "sandbox": sand}
    print(json.dumps(bundle, indent=2))

if __name__ == "__main__":
    export()
