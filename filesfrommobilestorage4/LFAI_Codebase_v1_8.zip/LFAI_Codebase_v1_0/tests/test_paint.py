from lfaicore.paint import paint8, palette, merge_paint, hex_to_colors

def test_paint8_determinism():
    vec=[13,7,9,2,18,5,1,12]; fh='f'*64
    p = paint8(vec, fh, space='core:test', salt='s', length=16)
    q = paint8(vec, fh, space='core:test', salt='s', length=16)
    assert p == q and len(p)==8 and all(len(x)==16 for x in p)

def test_palette_has_16():
    pal = palette()
    assert len(pal)==16 and all(k in pal for k in list("0123456789abcdef"))

def test_merge_and_colors():
    a="0123456789abcdef"; b="fedcba9876543210"
    m = merge_paint(a,b)
    cols = hex_to_colors(m[:16])
    assert len(cols)==16

def test_parity_paint_determinism_and_shift():
    vec=[13,7,9,2,18,5,1,12]; fh='a'*64
    p = parity_paint(vec, fh, length=16)
    q = parity_paint(vec, fh, length=16)
    assert p == q and set(p.keys())=={'mod2','mod4','mod8'}
    # hue shift should rotate digits (not equal unless shift==0)
    s = p['mod4'][1]
    s2 = hue_shift_hex(s, 3)
    assert s != s2 and len(s)==len(s2)
