"""Kafka connector skeleton.
Provide: write(topic, key, value), read(topic, group_id, max_records).
Use confluent-kafka in deployment; omitted here.
"""
def write(topic: str, key: bytes, value: bytes):
    raise NotImplementedError
def read(topic: str, group_id: str, max_records: int = 100):
    raise NotImplementedError
