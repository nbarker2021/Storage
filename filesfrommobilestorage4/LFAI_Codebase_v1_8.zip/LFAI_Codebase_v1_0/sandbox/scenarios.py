from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass
class Scenario:
    name: str
    data_types: List[str]
    pipeline: List[str]  # sequence of ops: ingest->verify->reduce->uplift->anchor
    notes: str = ""

BUILTINS = {
    "Nav_EDL": Scenario("Nav_EDL", data_types=["json","vec"], pipeline=["ingest","verify","uplift","anchor"], notes="Entry/Descent/Landing."),
    "Ice_Phase": Scenario("Ice_Phase", data_types=["json","vec"], pipeline=["ingest","verify","reduce","anchor"], notes="Ice VII pins then anchor."),
    "Time_Crystal": Scenario("Time_Crystal", data_types=["json"], pipeline=["ingest","verify","uplift","anchor"], notes="Stripe cadence watermark."),
}

def scenario_dict(s: Scenario) -> Dict:
    return asdict(s)
