from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass
class Persona:
    name: str
    allowed_ops: List[str]
    default_glyphs: List[int]
    notes: str = ""

# Built-ins
BUILTINS = {
    "Navigator": Persona("Navigator",
                         allowed_ops=["verify","uplift","anchor","gate","reduce"],
                         default_glyphs=[64,13,5,7,11,32],
                         notes="Route planning; timing face emphasized."),
    "Materials": Persona("Materials",
                         allowed_ops=["verify","reduce","uplift","anchor"],
                         default_glyphs=[8,16,24,32,13],
                         notes="Phase legality and density checks."),
    "BioCoder": Persona("BioCoder",
                        allowed_ops=["verify","uplift","reduce","anchor"],
                        default_glyphs=[8,16,32,13],
                        notes="Codon-like duplex views; strict palindromy."),
}

def persona_dict(p: Persona) -> Dict:
    return asdict(p)
