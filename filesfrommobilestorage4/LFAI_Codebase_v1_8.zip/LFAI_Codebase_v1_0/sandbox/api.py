from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from .rooms import Room, RoomConfig
from .registry import create_room, list_rooms, get_room
from .datatypes import ingest
from lfaicore.frame import compile_from_glyphs, Frame
from lfaicore.reducer import reduce_to_rest
from lfaicore.cona import legal_even
from lfaicore.uplift import uplift_u2

app = FastAPI(title="ScratchPad HQ Sandbox", version="1.2.0")

class NewRoom(BaseModel):
    name: str
    purpose: str = ""
    glyphs: List[int] = Field(default_factory=lambda:[8,13,32])
    faces: List[str] = Field(default_factory=lambda:['octad'])
    data_types: List[str] = Field(default_factory=lambda:['text','json','csv','vec'])
    persona: Optional[str] = None
    scenario: Optional[str] = None

class IngestBody(BaseModel):
    room_id: str
    dtype: str
    payload: Any

class VecBody(BaseModel):
    room_id: str
    vec: List[int]
    steps: Optional[int] = 1

@app.get("/rooms")
def rooms():
    return list_rooms()

@app.post("/rooms/new")
def rooms_new(body: NewRoom):
    r = create_room(body.dict())
    return r.to_json()

@app.post("/rooms/ingest")
def rooms_ingest(body: IngestBody):
    vec = ingest(body.payload, body.dtype)
    return {"vec": vec}

@app.post("/rooms/verify")
def rooms_verify(body: VecBody):
    meta = get_room(body.room_id)
    if not meta: raise HTTPException(404, "room not found")
    f = compile_from_glyphs(meta["cfg"]["glyphs"])
    legal, s = legal_even(body.vec)
    return {"legal": legal, "syndrome": s}

@app.post("/rooms/uplift")
def rooms_uplift(body: VecBody):
    meta = get_room(body.room_id)
    if not meta: raise HTTPException(404, "room not found")
    f = compile_from_glyphs(meta["cfg"]["glyphs"])
    v=list(body.vec)
    for _ in range(int(body.steps or 1)): v, f = uplift_u2(v, f)
    return {"vec": v, "rest_scale": f.rest_scale, "dyadic_depth": f.dyadic_depth, "mods": f.mods}
