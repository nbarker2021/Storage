import json, hashlib, colorsys
from typing import List, Dict, Any

# Universal 16-step gradient (hexadecimal nibbles 0..F → hue wheel)
# hue = k * 360/16; sat=1; val=1
PALETTE: Dict[str, str] = {}
for k in range(16):
    h = k / 16.0
    r,g,b = [int(255*x) for x in colorsys.hsv_to_rgb(h,1.0,1.0)]
    PALETTE["%x" % k] = f"#{r:02x}{g:02x}{b:02x}"

def palette() -> Dict[str,str]:
    return dict(PALETTE)

def _sha(s: bytes) -> str:
    return hashlib.sha256(s).hexdigest()

def paint_touch(vec: List[int], frame_hash: str, space: str, face: int, salt: str = "", length: int = 32) -> str:
    """Return a hex string 'stroke' capturing this touch.
    space: any stable identifier (e.g., 'room:<id>' or 'core:proof').
    face: 0..7 index (eight faces). length: number of hex nibbles to return.
    Deterministic and cheap: hex is the paint. """
    payload = json.dumps({"vec": vec, "frame": frame_hash, "space": space, "face": int(face), "salt": salt}, sort_keys=True).encode()
    hx = _sha(payload)
    return hx[:length]

def paint8(vec: List[int], frame_hash: str, space: str = "core:proof", salt: str = "", length: int = 32) -> List[str]:
    return [paint_touch(vec, frame_hash, space, i, salt=salt, length=length) for i in range(8)]

def hex_to_colors(hex_seq: str) -> List[str]:
    """Map hex digits to #RRGGBB using the universal palette."""
    cols = []
    for ch in hex_seq.lower():
        if ch in PALETTE:
            cols.append(PALETTE[ch])
    return cols

def merge_paint(a: str, b: str) -> str:
    """Nibble-wise XOR merge of two hex sequences (length=min)."""
    L = min(len(a), len(b))
    out = []
    for i in range(L):
        x = int(a[i], 16) ^ int(b[i], 16)
        out.append("%x" % x)
    return "".join(out)

def neon_palette(kind: str = "hex16") -> Dict[str,str]:
    """Neon palette mapping hex digits (0..f) to bright hues.
    kind can be 'hex16','mod2','mod4','mod8' to emphasize specific parity sets."""
    # Base neon from PALETTE; we reuse the same bright HSV(1,1) but expose selectors
    base = dict(PALETTE)
    if kind == "hex16":
        return base
    if kind == "mod2":
        # even -> neon lime, odd -> neon magenta, map all digits by their parity
        even = "#39ff14"  # neon lime
        odd  = "#ff00ff"  # neon magenta
        return {d:(even if int(d,16)%2==0 else odd) for d in base}
    if kind == "mod4":
        ll = ["#00fff7", "#ff00ff", "#39ff14", "#ff5f1f"]  # cyan, magenta, lime, orange
        return {d: ll[int(d,16)%4] for d in base}
    if kind == "mod8":
        hues = ["#00fff7","#8aff00","#ff00ff","#ffff00","#39ff14","#ff5f1f","#00f0ff","#b300ff"]
        return {d: hues[int(d,16)%8] for d in base}
    return base

def parity_hist(vec: List[int], m: int) -> List[int]:
    c=[0]*m
    for x in vec: c[x % m]+=1
    return c

def parity_paint(vec: List[int], frame_hash: str, space: str = "core:proof", levels = ("mod2","mod4","mod8"), length: int = 32) -> Dict[str, List[str]]:
    out={}
    for level in levels:
        m = 2 if level=="mod2" else 4 if level=="mod4" else 8
        hist = parity_hist(vec, m)
        seqs=[]
        for r in range(m):
            payload = json.dumps({"frame":frame_hash,"space":space,"parity":level,"class":r,"hist":hist}, sort_keys=True).encode()
            hx = _sha(payload)[:length]
            seqs.append(hx)
        out[level]=seqs
    return out

def hue_shift_hex(seq: str, shift: int) -> str:
    shift = int(shift) % 16
    return "".join([("%x" % ((int(ch,16)+shift) % 16)) for ch in seq.lower() if ch in PALETTE])
