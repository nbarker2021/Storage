from typing import List, Dict
def hist_mod(vec: List[int], m: int) -> List[int]:
    h=[0]*m
    for v in vec: h[v % m]+=1
    return h
def pal_defects(vec: List[int]) -> Dict[str,int]:
    h4=hist_mod(vec,4); h8=hist_mod(vec,8)
    P4=abs(h4[1]-h4[3]); P8=abs(h8[1]-h8[7])+abs(h8[2]-h8[6])+abs(h8[3]-h8[5])
    return {'P4':P4,'P8':P8,'h4':h4,'h8':h8}
