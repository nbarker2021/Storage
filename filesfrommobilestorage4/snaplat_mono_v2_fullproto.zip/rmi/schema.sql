PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS policies (
  policy_hash TEXT PRIMARY KEY,
  name TEXT,
  version TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS trails (
  trail_id TEXT PRIMARY KEY,
  kind TEXT,
  thing_id TEXT,
  payload_json TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS routes (
  route_id TEXT PRIMARY KEY,
  universe_id TEXT,
  score REAL,
  nodes_visited INTEGER,
  octant_spread INTEGER,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS endpoints (
  endpoint_id TEXT PRIMARY KEY,
  universe_id TEXT,
  finalized INTEGER DEFAULT 0,
  evidence_nodes INTEGER,
  agreement REAL,
  created_at INTEGER
);

-- I8 rotation
CREATE TABLE IF NOT EXISTS i8_rotation_params (
  k_default INTEGER NOT NULL DEFAULT 8,
  rotation_cycle INTEGER NOT NULL DEFAULT 8,
  freshness_ttl INTEGER NOT NULL DEFAULT 16,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS i8_topk (
  tick INTEGER NOT NULL,
  phase INTEGER NOT NULL,       -- 0..7 maps to I1..I8
  octant INTEGER NOT NULL,      -- 1..8
  choice_id TEXT NOT NULL,      -- route_id or endpoint_id
  choice_kind TEXT NOT NULL,    -- 'route'|'endpoint'
  score REAL NOT NULL,
  evidence_nodes INTEGER DEFAULT 0,
  agreement REAL DEFAULT 0.0,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (tick, octant, choice_id)
);
CREATE INDEX IF NOT EXISTS idx_i8_topk_phase ON i8_topk(phase);

CREATE VIEW IF NOT EXISTS v_i8_topk_current AS
WITH last_tick AS (
  SELECT octant, MAX(tick) AS tick
  FROM i8_topk
  GROUP BY octant
)
SELECT t.*
FROM i8_topk t
JOIN last_tick l USING (octant, tick);

CREATE VIEW IF NOT EXISTS v_i8_consensus AS
SELECT e.endpoint_id,
       CASE WHEN EXISTS (
         SELECT 1 FROM i8_topk tk
         WHERE tk.choice_kind='endpoint' AND tk.choice_id=e.endpoint_id
       ) THEN 1 ELSE 0 END AS endpoint_in_topk,
       e.finalized
FROM endpoints e;
