def check_overlay(members: list[str]) -> (bool, list):
    if len(set(members)) < 2: return (False, ["overlay.members.invalid"])
    return (True, [])
