def seed_routes(seeds: list[str]) -> list[dict]:
    routes = [{"route_id": f"r_{i}", "score": 0.8 - i*0.03, "nodes_visited": 10+i, "octant_spread": 4+(i%4)} for i,_ in enumerate(seeds[:8])]
    return routes

def consensus_k2(routes: list[dict]) -> dict:
    if len(routes) < 2: return {"final": False}
    top2 = sorted(routes, key=lambda r: -r["score"])[:2]
    agreement = sum(r["score"] for r in top2)/2
    return {"final": True, "endpoint_id": "ep_demo", "k_routes": [r["route_id"] for r in top2], "agreement": agreement, "evidence_nodes": 1800}
