from .cas import get, put
def recall_pack(key: str): return get(key)
def write_lockfile(endpoint_id: str, payload: dict):
    return put({"endpoint_id": endpoint_id, "payload": payload, "kind": "lockfile"})
