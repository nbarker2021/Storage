from kernel.telemetry import emit
from triads.reasoning_overlays.uro.checks import run_truth_filter
from triads.reasoning_overlays.ero.estimator import capacity_ok
from triads.reasoning_overlays.cto.window import context_ok
from triads.thinktank_dtt_assembly.thinktank.engine import expand_8_plus_8, rank_and_report
from triads.snap_agrm_mdhg.agrm.routes import seed_routes, consensus_k2
from triads.snap_agrm_mdhg.mdhg.overlays import check_overlay
from triads.thinktank_dtt_assembly.dtt.sandbox import invariants_ok
from triads.thinktank_dtt_assembly.assembly.publish import finalize_1729
from triads.sap_snapops_archivist.archivist.recall import write_lockfile

def i8_phase(tick:int)->int: return tick % 8

def run_tick(tick:int, slice_desc:dict, env:dict, budgets:dict):
    # Law-first
    ok, rs = run_truth_filter(slice_desc); emit("lawcheck.universal_pass" if ok else "lawcheck.universal_fail", "slice", {"reasons": rs})
    if not ok: return {"status":"FAIL","stage":"URO"}
    ok, rs = capacity_ok(env, budgets); emit("lawcheck.environment_pass" if ok else "lawcheck.environment_fail", "env", {"reasons": rs})
    if not ok: return {"status":"FAIL","stage":"ERO"}
    ok, rs = context_ok([], None); emit("lawcheck.context_pass" if ok else "lawcheck.context_fail", "ctx", {"reasons": rs})
    if not ok: return {"status":"FAIL","stage":"CTO"}
    # I8 rotation
    phase = i8_phase(tick); emit("i8.rotation.phase", "phase", {"phase": phase})
    # ThinkTank
    seeds = ["alpha","beta","gamma"]
    cands = expand_8_plus_8(seeds); emit("triad_expansion", "thinktank", cands)
    report = rank_and_report(cands); emit("thinktank_selection", "thinktank", report)
    # AGRM
    routes = seed_routes([s for s in cands["relevant"]]); emit("route_records", "agrm", {"count": len(routes)})
    ep = consensus_k2(routes)
    if not ep.get("final"): return {"status":"FAIL","stage":"AGRM"}
    # MDHG overlay check
    ov_ok, ov_rs = check_overlay(ep["k_routes"]); emit("overlay_checks", "mdhg", {"ok": ov_ok, "reasons": ov_rs})
    if not ov_ok: return {"status":"FAIL","stage":"MDHG"}
    # DTT
    dtt_ok, dtt_rs = invariants_ok({"wo_id":"wo1","required_checks":["glyph","delta_tau"],"policy_hash":"demo"}); emit("dtt.checks", "dtt", {"ok": dtt_ok, "reasons": dtt_rs})
    if not dtt_ok: return {"status":"FAIL","stage":"DTT"}
    # Assembly
    fin_ok, fin_rs = finalize_1729(ep); emit("1729_gate", "assembly", {"ok": fin_ok, "reasons": fin_rs})
    if not fin_ok: return {"status":"FAIL","stage":"ASM"}
    # Publish lockfile
    lf_hash = write_lockfile(ep["endpoint_id"], ep); emit("asm.publish", "assembly", {"lockfile": lf_hash})
    return {"status":"PASS","endpoint": ep["endpoint_id"], "lockfile": lf_hash}
