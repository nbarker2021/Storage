def finalize_1729(endpoint: dict) -> (bool, list):
    reasons = []
    if endpoint.get("evidence_nodes", 0) < 1729:
        reasons.append("evidence.below.1729")
    if len(endpoint.get("k_routes", [])) < 2:
        reasons.append("taxicab.k.lt.2")
    return (len(reasons)==0, reasons)
