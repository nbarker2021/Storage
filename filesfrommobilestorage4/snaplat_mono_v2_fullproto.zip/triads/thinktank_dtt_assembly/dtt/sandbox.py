def invariants_ok(workorder: dict) -> (bool, list):
    req = workorder.get("required_checks", [])
    return (len(req) >= 1, ["missing.required_checks"] if len(req) < 1 else [])
