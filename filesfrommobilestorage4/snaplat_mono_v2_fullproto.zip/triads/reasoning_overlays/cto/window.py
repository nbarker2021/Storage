def context_ok(recent_trails: list, lockfile_endpoint_id: str|None) -> (bool, list):
    reasons = []
    for t in recent_trails[-50:]:
        if t.get("kind","").endswith(".contradiction"):
            reasons.append("trail.contradiction")
            break
    return (len(reasons) == 0, reasons)
