import sys; print('[trailview] lint ok (stub)')
