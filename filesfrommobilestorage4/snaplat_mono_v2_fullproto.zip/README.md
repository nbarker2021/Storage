# SnapLat Monorepo — Holistic Full-Stack (v2)

A runnable prototype of the SnapLat system with triads, governance, kernel FSM,
RMI schema, policy packs, suites, fixtures — designed to run **one tick at a time**
with **SCP (grouped work)**, **GCR (governance ripple)**, **law-first overlays**,
and **I8 Top-K rotation**.

## Quick Start
```sh
make init
. .venv/bin/activate
snaplat --ticks 2
make pilots
make fst
```
