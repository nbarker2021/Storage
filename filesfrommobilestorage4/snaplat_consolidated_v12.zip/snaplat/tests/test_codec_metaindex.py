
from snaplat.repo.indices.codec import decide_depth
from snaplat.repo.indices.meta_index import register, link, resolve, MAX_DEPTH
def test_codec_and_metaindex():
    assert decide_depth(20.0) == "shallow"
    r1 = register("sid:1","silver", 1.0, {"p":1})
    r2 = register("sid:2","silver", 1.0, {"p":2})
    assert link(r1["index_id"], r2["index_id"]) in (True, False)
    assembled, path = resolve(r1["index_id"], 1.0, depth_limit=MAX_DEPTH)
    assert isinstance(assembled, dict) and len(path) >= 1
