
from snaplat.repo.indices.hierarchy import allowed_tier_for_faces, policy_table
def test_policy_table_and_logic():
    tbl = policy_table()
    assert 'all green' in tbl.values() or 'gold' in str(tbl)
    green = {"privacy":"green","policy":"green","numeric":"green","semantic":"green"}
    amber = {"privacy":"green","policy":"amber","numeric":"green","semantic":"green"}
    red = {"privacy":"red","policy":"green","numeric":"green","semantic":"green"}
    assert allowed_tier_for_faces(green) == "gold"
    assert allowed_tier_for_faces(amber) == "silver"
    assert allowed_tier_for_faces(red) == "shadow"
