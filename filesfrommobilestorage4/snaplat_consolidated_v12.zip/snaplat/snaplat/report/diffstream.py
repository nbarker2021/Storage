
from __future__ import annotations
from typing import List, Dict
_DIFFS: List[Dict] = []
def push(event: Dict) -> None: _DIFFS.append(dict(event))
def tail(n: int = 20) -> List[Dict]: return _DIFFS[-n:]
