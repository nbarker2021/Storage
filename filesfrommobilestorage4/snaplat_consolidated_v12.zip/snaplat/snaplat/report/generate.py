
from datetime import datetime
from ..repo.assumed_known import get_last_code_watermark
from ..repo.indices.hierarchy import policy_table

def _fmt_ledger_entry(e: dict) -> str:
    if not e: return "n/a"
    parts = [f"{e.get('sid')} {e.get('from')}→{e.get('to')} by {e.get('actor')}"]
    if e.get("index_id"): parts.append(f"idx={e['index_id']}")
    if e.get("reason"): parts.append(f"reason={e['reason']}")
    return " | ".join(parts)

def generate(summary: dict) -> str:
    lines = []
    lines.append(f"SNAPLAT Consolidated Report — {datetime.utcnow().isoformat()}Z\\n")
    lines.append(f"Decision: {summary.get('decision')}  Tick: {summary.get('tick_id')}  Actor: {summary.get('actor')}  Tool: {summary.get('tool')}  Hz: {summary.get('tick_rate_hz')}\\n")
    lines.append(f"Faces: {summary.get('faces')}\\n")
    lines.append(f"AKI: {summary.get('aki_stats')} last={summary.get('last_code_sid')}\\n")
    wm = get_last_code_watermark()
    if wm: lines.append(f"Watermark: {wm}\\n")
    lines.append("Policy Map: " + str(policy_table()) + "\\n")
    lane_counts = summary.get('lane_counts') or {}
    lines.append(f"Lanes: {lane_counts}\\n")
    audit_stats = summary.get('audit_stats') or {}
    lines.append(f"Audit: {audit_stats}\\n")
    ledger = summary.get('ledger') or []
    last = ledger[-1] if ledger else {}
    lines.append("Last Ledger: " + _fmt_ledger_entry(last) + "\\n")
    if ledger:
        lines.append("Ledger (tail):\\n")
        for l in ledger:
            lines.append(f"  - {l}\\n")
    lines.append(f"Snap: {bool(summary.get('snap'))}\\n")
    return "".join(lines)
