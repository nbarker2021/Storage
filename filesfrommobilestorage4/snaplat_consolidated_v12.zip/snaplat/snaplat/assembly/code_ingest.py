
from ..repo.schemas import CodeSNAP
from ..repo import assumed_known as AKI
from ..repo.provenance import stamp_artifact

def ingest_code_snippet(source: str, doc: str = "", actor: str = "system", tool: str = "ingest", tick_id: str = "tick:set1") -> CodeSNAP:
    snap = CodeSNAP(sid="code:stub:0001", op="code.ingest", source=source, doc=doc, outputs={"artifact": "code:stub:0001"})
    wm = stamp_artifact(snap.sid, actor=actor, tool=tool, tick_id=tick_id, payload=source, purpose="ingest")
    snap.dna.update({"watermark": str(wm)})
    AKI.insert_code_snap(snap)
    return snap
