
from __future__ import annotations
from typing import Dict, Literal
import hashlib

Tier = Literal["shadow","silver","gold"]
_ORDER = {"shadow":0,"silver":1,"gold":2}
_DEF_PRIORITY = ["privacy","policy","numeric","semantic"]

def allowed_tier_for_faces(faces: Dict[str, str]) -> Tier:
    colors = [faces.get(k, "green") for k in _DEF_PRIORITY]
    if any(c == "red" for c in colors): return "shadow"
    if any(c == "amber" for c in colors): return "silver"
    return "gold"

def index_id_for(tier: Tier, sid: str) -> str:
    base = f"{tier}:{sid}"
    return hashlib.blake2b(base.encode(), digest_size=8).hexdigest()

def validate_promotion(sid: str, faces: Dict[str, str], desired: Tier) -> Dict[str, str]:
    allowed = allowed_tier_for_faces(faces)
    target = desired if _ORDER[desired] <= _ORDER[allowed] else allowed
    idx = index_id_for(target, sid)
    reason = "faces-policy-map" if target != desired else "ok"
    return {"sid": sid, "allowed": allowed, "target": target, "desired": desired, "index_id": idx, "reason": reason}

def policy_table() -> Dict[str, str]:
    return {"any red": "shadow","any amber (no red)": "silver","all green": "gold"}
