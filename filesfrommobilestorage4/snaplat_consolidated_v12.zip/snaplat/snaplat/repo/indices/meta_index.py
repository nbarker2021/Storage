
"""Meta-Index (index-of-indices) with bounded recursion (v11/v12)."""
from __future__ import annotations
from typing import Dict, Any, List, Tuple
from .hierarchy import Tier, index_id_for
from .codec import decide_depth, compress, decompress

MAX_DEPTH = 3
_STORE: Dict[str, dict] = {}

def register(sid: str, tier: Tier, tick_rate_hz: float, payload: dict) -> dict:
    depth = decide_depth(tick_rate_hz)
    idx = index_id_for(tier, sid)
    blob, meta = compress(payload, depth)
    entry = {"sid": sid, "tier": tier, "index_id": idx, "blob": blob, "codec": meta, "children": []}
    _STORE[idx] = entry
    return {"index_id": idx, "codec": meta, "tier": tier}

def link(parent_index_id: str, child_index_id: str) -> bool:
    if parent_index_id not in _STORE or child_index_id not in _STORE: return False
    parent = _STORE[parent_index_id]
    if len(parent.get("children", [])) >= MAX_DEPTH: return False
    parent.setdefault("children", []).append(child_index_id)
    return True

def resolve(index_id: str, tick_rate_hz: float, depth_limit: int = MAX_DEPTH) -> Tuple[dict, List[str]]:
    visited: List[str] = []
    def _walk(idx: str, depth: int) -> dict:
        visited.append(idx)
        if depth <= 0 or idx not in _STORE: return {}
        entry = _STORE[idx]
        payload, _ = decompress(entry["blob"], entry["codec"]["depth"])
        children = entry.get("children", [])[:]
        assembled = {"self": payload, "children": []}
        for c in children:
            assembled["children"].append(_walk(c, depth - 1))
        return assembled
    return _walk(index_id, depth_limit), visited
