
# SNAPLAT — Consolidated Core (v12)

Quick start:
```
pip install -e .
python -m snaplat.cli tick-cmd --ticks 2 --actor ops --tool planner --tick-rate-hz 20
python -m snaplat.cli report
python -m snaplat.cli policy --show
pytest -q
```
