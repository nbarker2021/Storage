from typing import List, Dict, Any, Callable, Tuple

def select_normal_form(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    ok = [r for r in results if r.get("ok")]
    return ok[0] if ok else {"ok": False, "reason": "no_ok"}

def unfold(block: Callable, variants: List[Tuple]) -> Dict[str, Any]:
    outs = []
    for args in variants:
        try:
            outs.append(block(*args))
        except Exception as e:
            outs.append({"ok": False, "reason": f"exc:{e}"})
    best = select_normal_form(outs)
    return {"best": best, "all": outs}
