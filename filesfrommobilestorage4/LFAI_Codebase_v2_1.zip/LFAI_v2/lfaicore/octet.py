from functools import wraps
from typing import Callable, Dict, Any, Iterable
import hashlib, json
from .bitwrap import bitwrap_pi4, pal4_ok_bytes
from .cona_e8 import constructionA_E8_check

def to_bytes_lane(x) -> bytes:
    if isinstance(x, bytes): return x
    if isinstance(x, str): return x.encode('utf-8', 'ignore')
    if isinstance(x, (int, float)):
        return int(x).to_bytes(8, 'little', signed=True)
    if isinstance(x, Iterable):
        return bytes(int(v) & 0xFF for v in x)
    return json.dumps(x, sort_keys=True).encode()

def legal_e8_from_bytes(*lanes: bytes) -> bool:
    blob=b''.join(lanes)
    blob += b'\x00' * ((64 - (len(blob)%64))%64)
    ints=[blob[i] for i in range(64)]
    legal,_=constructionA_E8_check(ints[:8])
    return bool(legal)

def anchor_hash(payload: Dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

def octet(bitwrap: str = "pi4", involution: bool = True, faces: str = "GEN"):
    def deco(fn: Callable):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if len(args) != 8:
                raise ValueError("octet requires 8 lanes")
            lanes = [to_bytes_lane(a) for a in args]
            if bitwrap == "pi4":
                lanes_wrapped = [bitwrap_pi4(b) for b in lanes]
            else:
                lanes_wrapped = lanes[:]
            pal_ok = all(pal4_ok_bytes(b) for b in lanes_wrapped[:4])
            legal_e8 = legal_e8_from_bytes(*lanes_wrapped)
            if not (pal_ok and legal_e8):
                return {"ok": False, "pal4_ok": pal_ok, "legal_e8": legal_e8}
            out = fn(*args, **kwargs)
            if not (isinstance(out,(tuple,list)) and len(out)==8):
                raise ValueError("octet fn must return 8 lanes")
            pre_anchor = anchor_hash({"fn": fn.__name__, "in": str(args)})
            post_anchor = anchor_hash({"fn": fn.__name__, "out": str(out)})
            return {"ok": True, "out": out, "pal4_ok": pal_ok, "legal_e8": legal_e8,
                    "pre_anchor": pre_anchor, "post_anchor": post_anchor}
        return wrapper
    return deco
