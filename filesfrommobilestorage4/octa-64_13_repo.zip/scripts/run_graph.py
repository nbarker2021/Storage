
import argparse, os, json
from octa_vm.executor import load_graph, Executor
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("graph"); ap.add_argument("--macrocycles",type=int,default=1)
    ap.add_argument("--outdir",default="/mnt/data/outbox")
    args=ap.parse_args()
    g=load_graph(args.graph)
    ex=Executor(g, outdir=args.outdir)
    ctx={"residues":{f"H{i+1}":i%2 for i in range(8)},"margins":{f"H{i+1}":0.95 for i in range(8)}}
    ex.run_macrocycles(args.macrocycles, context_knobs=ctx)
    print("Done. Out:", args.outdir)
if __name__=="__main__": main()
