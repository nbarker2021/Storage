
from typing import List
from .pack import Pack
def encode_packs(ps: List[Pack])->bytes: return b"".join(p.to_bytes() for p in ps)
def decode_packs(blob: bytes)->List[Pack]:
    assert len(blob)%512==0
    return [Pack.from_bytes(blob[i:i+512]) for i in range(0,len(blob),512)]
