
from dataclasses import dataclass, field
from typing import Dict, Any, List
import struct, hashlib

PORTS = ["N","NE","E","SE","S","SW","W","NW"]

@dataclass
class Pack:
    pack_id: str
    version: int = 1
    lane: int = 0
    quadrant: int = 0
    arm: int = 0
    portmap: Dict[str,int] = field(default_factory=lambda: {p:0 for p in PORTS})
    effects: bytes = b"\x00"*40
    bytecode: bytes = b""
    cas_links: List[bytes] = field(default_factory=list)
    constraints: bytes = b"\x00"*32
    proof: bytes = b"\x00"*32
    ledger: bytes = b"\x00"*64
    ecc: bytes = b"\x00"*32
    spare: bytes = b"\x00"*64

    def to_bytes(self)->bytes:
        hdr = struct.pack(">BBBBB3x", self.version, self.lane, self.quadrant, self.arm, 0)
        pm = b"".join(struct.pack(">I", self.portmap.get(p,0)&0xFFFFFFFF) for p in PORTS)
        effects = (self.effects + b"\x00"*40)[:40]
        bc = (self.bytecode + b"\x00"*88)[:88]
        cl = b""
        for i in range(3):
            if i < len(self.cas_links):
                v = (self.cas_links[i] + b"\x00"*40)[:40]
            else:
                v = b"\x00"*40
            cl += v
        constraints = (self.constraints + b"\x00"*32)[:32]
        proof = (self.proof + b"\x00"*32)[:32]
        ledger = (self.ledger + b"\x00"*64)[:64]
        ecc = (self.ecc + b"\x00"*32)[:32]
        spare = (self.spare + b"\x00"*64)[:64]
        blob = hdr + pm + effects + bc + cl + constraints + proof + ledger + ecc + spare
        assert len(blob)==512
        return blob

    @staticmethod
    def from_bytes(b: bytes)->'Pack':
        assert len(b)==512
        version,lane,quad,arm,_ = struct.unpack(">BBBBB3x", b[0:8])
        off=8; portmap={}
        for p in PORTS:
            (u,) = struct.unpack(">I", b[off:off+4]); off+=4
            portmap[p]=u
        effects=b[off:off+40]; off+=40
        bytecode=b[off:off+88]; off+=88
        cas_links=[b[off+i*40:off+(i+1)*40] for i in range(3)]; off+=120
        constraints=b[off:off+32]; off+=32
        proof=b[off:off+32]; off+=32
        ledger=b[off:off+64]; off+=64
        ecc=b[off:off+32]; off+=32
        spare=b[off:off+64]; off+=64
        pid = hashlib.sha256(b).hexdigest()
        return Pack(pid,version,lane,quad,arm,portmap,effects,bytecode,cas_links,constraints,proof,ledger,ecc,spare)

    @staticmethod
    def from_json(j: Dict[str,Any])->'Pack':
        def hx(key, L): 
            s = bytes.fromhex(j.get(key,""))
            return (s + b"\x00"*L)[:L]
        return Pack(
            j.get("pack_id","demo"),
            j.get("version",1),
            j.get("lane",0),
            j.get("quadrant",0),
            j.get("arm",0),
            j.get("portmap",{}),
            hx("effects_hex",40),
            hx("bytecode_hex",88),
            [bytes.fromhex(x) for x in j.get("cas_links_hex",[])],
            hx("constraints_hex",32),
            hx("proof_hex",32),
            hx("ledger_hex",64),
            hx("ecc_hex",32),
            hx("spare_hex",64),
        )

    def to_json(self)->Dict[str,Any]:
        return {
            "pack_id": self.pack_id, "version": self.version, "lane": self.lane,
            "quadrant": self.quadrant, "arm": self.arm, "portmap": self.portmap,
            "effects_hex": self.effects.hex(), "bytecode_hex": self.bytecode.hex(),
            "cas_links_hex": [x.hex() for x in self.cas_links],
            "constraints_hex": self.constraints.hex(), "proof_hex": self.proof.hex(),
            "ledger_hex": self.ledger.hex(), "ecc_hex": self.ecc.hex(),
            "spare_hex": self.spare.hex(),
        }
