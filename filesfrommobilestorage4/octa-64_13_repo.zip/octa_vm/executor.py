
from dataclasses import dataclass, field
from typing import Dict, Any
import json, os
from .pack import Pack
from .vm import VMState, run_pack

def active_arm(q,lane,b): return (2*q + lane + 5*b) % 8

@dataclass
class Node:
    pack: Pack
    inputs: Dict[str,str] = field(default_factory=dict)
    outputs: Dict[str,list] = field(default_factory=dict)
    node_id: str = ""

@dataclass
class Graph:
    nodes: Dict[str,Node] = field(default_factory=dict)

def load_graph(path:str)->Graph:
    g = json.loads(open(path).read())
    nodes={}
    for nd in g["nodes"]:
        p = Pack.from_json(nd["pack"])
        n = Node(p, inputs=nd.get("inputs",{}), outputs=nd.get("outputs",{}), node_id=nd["id"])
        nodes[n.node_id]=n
    return Graph(nodes)

class Executor:
    def __init__(self, graph: Graph, outdir:str="/mnt/data/outbox"):
        self.graph = graph
        self.state = {nid: VMState() for nid in graph.nodes}
        self.outdir = outdir; os.makedirs(outdir, exist_ok=True)

    def tick(self, q,lane,b, ctx):
        k = active_arm(q,lane,b)
        for nid,node in self.graph.nodes.items():
            if node.pack.arm != k: continue
            vm = self.state[nid]; vm.ports = {}
            for port, src in node.inputs.items():
                if ":" in src:
                    sid,sport = src.split(":")
                    vm.ports[port] = self.state[sid].ports.get(sport, self.state[sid].ports.get("E"))
            local_ctx = {"sink": os.path.join(self.outdir, f"{nid}_emit.json"),
                         "receipt": os.path.join(self.outdir, f"{nid}_receipt.json"), **ctx}
            out = run_pack(node.pack, vm, local_ctx)
            for p,val in out.items():
                vm.ports[p]=val
                for dst in node.outputs.get(p,[]):
                    did,dport = dst.split(":")
                    self.state[did].ports[dport]=val

    def run_macrocycles(self, macrocycles=1, context_knobs=None):
        if context_knobs is None: context_knobs = {}
        for _ in range(macrocycles):
            for q in range(4):
                for lane in range(2):
                    for b in range(13):
                        self.tick(q,lane,b, context_knobs)
