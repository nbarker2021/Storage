
from dataclasses import dataclass, field
from typing import Dict, Any, List, Tuple
import json, math, os

MC = {"NOP":0,"STREAM_CONST":1,"MAP_ZSCORE":2,"FILTER_ABS_GT":3,"EMIT_FS":4,"PARTITIONS_TABLE":5,"EMIT_RECEIPT":6,"PARITY_CHECK":7}

def _bc_head(b: bytes)->Tuple[int,List[int]]:
    if not b: return (0,[])
    return (b[0], list(b[1:8]))

@dataclass
class VMState:
    ports: Dict[str, Any] = field(default_factory=dict)

def run_pack(pack, state: VMState, ctx: Dict[str,Any])->Dict[str,Any]:
    op,args = _bc_head(pack.bytecode)
    out={}
    if op==MC["STREAM_CONST"]:
        n = args[0] if args else 10
        val = args[1] if len(args)>1 else 1
        out["E"] = [val]*n
    elif op==MC["MAP_ZSCORE"]:
        w = max(3, args[0] if args else 10)
        x = state.ports.get("W",[])
        zs=[]; s=0.0; s2=0.0; buf=[]
        for xi in x:
            buf.append(float(xi)); s+=buf[-1]; s2+=buf[-1]*buf[-1]
            if len(buf)>w:
                old=buf.pop(0); s-=old; s2-=old*old
            m=s/len(buf); var=max(1e-9,s2/len(buf)-m*m)
            zs.append((buf[-1]-m)/math.sqrt(var))
        out["E"]=zs; out["NE"]={"mean":m,"sigma":math.sqrt(var)}
    elif op==MC["FILTER_ABS_GT"]:
        thr = (args[0] if args else 20)/10.0
        x = state.ports.get("W",[])
        out["E"]=[v for v in x if abs(v)>thr]
    elif op==MC["EMIT_FS"]:
        data = state.ports.get("W",[])
        path = ctx.get("sink","/mnt/data/outbox/emit.json")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path,"w") as f:
            json.dump({"data": data, "ctx": ctx}, f)
        out["S"]={"wrote":path}
    elif op==MC["PARTITIONS_TABLE"]:
        N = min(200, args[0] if args else 120)
        p=[0]*(N+1); p[0]=1
        for n in range(1,N+1):
            tot=0; k=1
            while True:
                g1=k*(3*k-1)//2; g2=k*(3*k+1)//2
                if g1>n and g2>n: break
                sgn=-1 if (k%2==0) else 1
                if g1<=n: tot += sgn*p[n-g1]
                if g2<=n: tot += sgn*p[n-g2]
                k+=1
            p[n]=tot
        def p_asym(n):
            if n<=0: return 1.0
            return (1.0/(4*n*math.sqrt(3.0)))*math.exp(math.pi*math.sqrt(2.0*n/3.0))
        rows=[]; burn=30; werr=[]
        for n in range(1,N+1):
            approx=p_asym(n); ex=p[n]
            rel=abs(approx-ex)/max(1,ex)
            rows.append({"n":n,"p":ex,"asym":approx,"rel_err":rel})
            if n>=burn: werr.append(rel)
        mono = all(werr[i+1]<=werr[i]+1e-9 for i in range(len(werr)-1))
        out["E"]=rows; out["NE"]={"burn_in":burn,"monotone_ok":mono,"max_rel_err":max(werr) if werr else None}
    elif op==MC["EMIT_RECEIPT"]:
        meta = state.ports.get("NE",{})
        path = ctx.get("receipt","/mnt/data/outbox/receipt.json")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path,"w") as f:
            json.dump({"meta":meta, "ctx":ctx}, f, indent=2)
        out["S"]={"receipt":path}
    elif op==MC["PARITY_CHECK"]:
        res=ctx.get("residues",{}); mar=ctx.get("margins",{})
        ok = len(res)==8 and all(k in mar for k in res)
        out["S"]={"all8_ok":ok}
    return out
