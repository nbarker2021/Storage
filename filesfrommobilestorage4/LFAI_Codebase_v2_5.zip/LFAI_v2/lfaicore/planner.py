import hashlib, json, math, itertools, random
from typing import List, Dict, Any
from .bitwrap import pal4_defect_bytes, bitwrap_pi4
from .buckets import load_buckets, Bucket
from .ledger_merkle import append

def _score_token(tok: str) -> float:
    bs = tok.encode("utf-8","ignore")
    wrapped = bitwrap_pi4(bs)
    d = pal4_defect_bytes(wrapped)
    # lower defect => higher score; map to [0,1]
    return 1.0 / (1.0 + d)

def _chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i+n]

def plan(tokens: List[str], buckets: List[Bucket] = None, max_iters: int = 5) -> Dict[str, Any]:
    buckets = buckets or load_buckets()
    tokens = list(dict.fromkeys(tokens))  # dedupe preserving order
    iters=[]
    unsettled = tokens[:]
    for it in range(max_iters):
        sticks = {b.name: [] for b in buckets}
        drips = []
        misses = []
        # form tuples up to size 8 deterministically
        random.seed(42+it)
        random.shuffle(unsettled)
        tuples = []
        for s in range(8,0,-1):
            tuples += list(_chunks(unsettled, s))
        # evaluate each tuple against buckets
        for tup in tuples:
            if not tup: continue
            score = sum(_score_token(t) for t in tup)/len(tup)
            placed=False
            for b in sorted(buckets, key=lambda x: x.order):
                p = b.pouches.get(len(tup))
                if not p: continue
                if score >= p.stick_threshold:
                    sticks[b.name].append(tup)
                    placed=True
                    break
                elif score >= p.drip_threshold:
                    drips.append(tup)
                    placed=True
                    break
            if not placed:
                misses.append(tup)
        iters.append({"iter": it+1, "sticks": sticks, "drips": drips, "misses": misses})
        unsettled = list(itertools.chain.from_iterable(misses + drips))
        if len(unsettled) <= 4:
            break
    append({"op":"plan","iters": len(iters), "final_unsettled": len(unsettled)})
    return {"iterations": iters, "unsettled": unsettled}
