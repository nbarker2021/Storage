from typing import List, Tuple

def _is_even_sum(v: List[int]) -> bool:
    return (sum(v) & 1) == 0

def _even_norm(v: List[int]) -> bool:
    # Surrogate: sum x^2 even
    return (sum((x*x) for x in v) & 1) == 0

def _mod8_quadratic(v: List[int]) -> bool:
    # Weak constraint: sum x^2 % 8 == 0 (often true for even unimodular slices)
    return (sum((x*x) for x in v) % 8) == 0

def constructionA_E8_check(v8: List[int]) -> Tuple[bool, List[int]]:
    """
    Surrogate legality for E8/Type-II slice (no external libs).
    Legal if:
      - sum(v) even
      - sum(x^2) even
      - sum(x^2) mod 8 == 0
    Returns (legal, syndrome_bits[4])
    """
    s1 = _is_even_sum(v8)
    s2 = _even_norm(v8)
    s3 = _mod8_quadratic(v8)
    legal = s1 and s2 and s3
    synd = [0,0,0,0]
    if not s1: synd[0] = 1
    if not s2: synd[1] = 1
    if not s3: synd[2] = 1
    return legal, synd
