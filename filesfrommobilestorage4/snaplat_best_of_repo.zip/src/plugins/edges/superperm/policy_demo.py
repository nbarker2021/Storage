
import numpy as np, hashlib
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shell_qa import ShellQASuite, ShellPromotionRules
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.persistence.sqlite_store import SQLiteStore

def main():
    cube = SafeCube(dim=8, seed=11)
    ids = [f"d::{i}" for i in range(120)]
    P = np.stack([cube.glyph_vector(i) for i in ids], axis=0)
    sb = ShellBuilder(points=P, ids=ids)
    center = ids[0]
    shells = sb.shells_for(center, max_k=3, nn=12)

    sm = ShellManager()
    sm.create(center, shells, hash_fn=lambda s: str(abs(hash(s))))
    suite = ShellQASuite(); rules = ShellPromotionRules(min_size=8, min_coherence=0.10)
    flip = sm.validate_and_promote(center, suite, rules, get_vector=lambda gid: cube.glyph_vector(gid), score_fn=lambda _:1.0)
    print("Initial flip-rate:", round(flip,3))

    # Simulate uncertainty: tighten coherence to force expansion in your app logic (demo prints only)
    store = SQLiteStore("/mnt/data/lattice_v9.db")
    store.persist_shells_and_reports(sm)
    states = store.load_shell_states(center)
    print("Promoted states:", sum(1 for s in states if s["state"]=="promoted"))

if __name__ == "__main__":
    main()
