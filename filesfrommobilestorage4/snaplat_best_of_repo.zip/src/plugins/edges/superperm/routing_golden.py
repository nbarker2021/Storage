
"""
Golden: promoted-only routing recall and budget adherence
- Build shells around a center; promote; route with BudgetController v3.
"""
import json, sys, numpy as np, time
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shell_qa import ShellQASuite, ShellPromotionRules
from lattice_ai.core.router import Router
from lattice_ai.core.budget_controller import BudgetController

def main():
    gold = json.load(open(__file__.replace("routing_golden.py","golden_routing.json")))
    cube = SafeCube(dim=8, seed=101)
    ids = [f"d::{i}" for i in range(600)]
    P = np.stack([cube.glyph_vector(i) for i in ids], axis=0)
    sb = ShellBuilder(points=P, ids=ids)
    center = ids[0]
    shells = sb.shells_for(center, max_k=3, nn=12)
    sm = ShellManager(); sm.create(center, shells, hash_fn=lambda s: str(abs(hash(s))))
    suite = ShellQASuite(); rules = ShellPromotionRules(min_size=8, min_coherence=0.1)
    sm.validate_and_promote(center, suite, rules, get_vector=lambda gid: cube.glyph_vector(gid), score_fn=lambda _:1.0)

    router = Router(cube, shell_manager=sm)
    bc = BudgetController(p95_budget_ms=gold["budget_ms_target"])

    t0 = time.time()
    res = bc.query(router, center_id=center, use_promoted=True, top_k=10)
    dt = (time.time()-t0)*1000.0

    # crude recall proxy: overlap of promoted members and candidates
    promoted = set(sm.promoted_members(center))
    cand_set = set(res["candidates"])
    overlap = len(promoted & cand_set) / max(1, min(10, len(promoted)))

    ok1 = overlap >= 0.4  # proxy threshold
    ok2 = dt <= gold["latency_ms_max"]
    print({"overlap_proxy": overlap, "latency_ms": dt, "ok": ok1 and ok2})
    sys.exit(0 if (ok1 and ok2) else 1)

if __name__ == "__main__":
    main()
