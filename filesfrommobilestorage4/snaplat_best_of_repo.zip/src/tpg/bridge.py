
import time
from typing import Dict, Any, List, Tuple

def _mk_bridge_snap(a_meta: Dict[str,Any], b_meta: Dict[str,Any], overlap: float, *, universe: str, reason: str):
    a_id = tuple(a_meta.get("id")); b_id = tuple(b_meta.get("id"))
    fam_a = a_meta.get("tags",{}).get("family"); fam_b = b_meta.get("tags",{}).get("family")
    type_a = a_meta.get("tags",{}).get("type");   type_b = b_meta.get("tags",{}).get("type")
    glyph_a= a_meta.get("tags",{}).get("glyph");  glyph_b= b_meta.get("tags",{}).get("glyph")
    return {
        "meta": {
            "snap_id": f"bridge::{universe}::{int(time.time()*1000)}::{a_id}->{b_id}",
            "family": "bridge",
            "type":   "tpg_bridge",
            "tags":   {"universe": universe, "from": a_id, "to": b_id, "overlap": float(overlap),
                       "family_pair": (fam_a, fam_b), "type_pair": (type_a, type_b)}
        },
        "content": {
            "rationale": f"Bridge justification between {a_id} and {b_id} (overlap={overlap:.3f}).",
            "from_meta": {"id": a_id, "family": fam_a, "type": type_a, "glyph": glyph_a},
            "to_meta":   {"id": b_id, "family": fam_b, "type": type_b, "glyph": glyph_b}
        }
    }

def emit_bridges(repo, um, *, universe: str, tpg_report: Dict[str,Any], imperf_threshold: float = 0.8) -> Dict[str,int]:
    metas = tpg_report.get("node_metas") or []
    edges = tpg_report.get("edges") or []
    if not metas or not edges:
        return {"emitted":0}
    # map local index -> meta
    emitted = 0
    for e in edges:
        if not bool(e.get("imperfect", False)):
            continue
        i, j = int(e["i"]), int(e["j"])
        ov = float(e.get("overlap", 0.0))
        a_meta, b_meta = metas[i], metas[j]
        rec = _mk_bridge_snap(a_meta, b_meta, ov, universe=universe, reason="low_overlap")
        repo.save(rec["meta"]["snap_id"], rec)
        emitted += 1
        try:
            u = um.get_universe(universe)
            arr = u.overlays.get("bridges", [])
            arr.append(rec["meta"]["snap_id"])
            u.overlays["bridges"] = sorted(set(arr))
            um.save_universe(u)
        except Exception:
            pass
    return {"emitted": emitted}

def emit_proposal(repo, um, *, universe: str, tpg_report: Dict[str,Any]) -> str | None:
    nodes = tpg_report.get("nodes") or []
    metas = tpg_report.get("node_metas") or []
    edges = tpg_report.get("edges") or []
    if not nodes or not metas or not edges:
        return None
    # order indices from edge list (path)
    order_ix = [edges[0]["i"]] + [e["j"] for e in edges]
    ordered = [metas[ix].get("id") for ix in order_ix]
    snap_id = f"tpg_proposal::{universe}::{int(time.time()*1000)}"
    repo.save(snap_id, {
        "meta":{"snap_id": snap_id, "family":"proposal", "type":"tpg_order", "tags":{"universe": universe}},
        "content":{"order_room_ids": ordered, "edges": edges, "cost": float(tpg_report.get("cost", 0.0)),
                   "imperfections": int(tpg_report.get("imperfections",0))}
    })
    try:
        u = um.get_universe(universe)
        arr = u.overlays.get("proposals", []); arr.append(snap_id)
        u.overlays["proposals"] = sorted(set(arr)); um.save_universe(u)
    except Exception:
        pass
    return snap_id
