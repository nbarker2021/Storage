import sys, json, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[0]))

from core.universe.universe_manager_v0_1_2025_08_13 import UniverseManager, UniverseSpec
from core.archivist.archivist_v0_1_2025_08_13 import Repository

def run():
    repo_root = "/mnt/data/repository_store_v0_1_2025_08_13"
    reg_root  = "/mnt/data/universe_registry_v0_1_2025_08_13"
    um = UniverseManager(repo_root, reg_root)

    repo = Repository(repo_root)
    if not repo.list():
        for i in range(4):
            snap_id = f"culture-creative-v0_1_demo-{int(time.time())}-{i}"
            meta = {"snap_id": snap_id, "family":"culture", "type":"creative", "version":"v0_1_demo", "created_ts": time.time(), "tags":{"score": 0.7 + 0.05*i}}
            repo.save(snap_id, {"meta": meta, "content": {"payload": f"demo-{i}"}})

        for i in range(3):
            snap_id = f"science-fact-v0_1_demo-{int(time.time())}-{i}"
            meta = {"snap_id": snap_id, "family":"science", "type":"fact", "version":"v0_1_demo", "created_ts": time.time(), "tags":{"score": 0.55 + 0.1*i}}
            repo.save(snap_id, {"meta": meta, "content": {"payload": f"demo-sci-{i}"}})

    uu = UniverseSpec(name="UserUniverse", selectors={"family":["culture"], "type":["creative"], "tags":{"score_gt":0.75}}, policies={"read_only":True})
    du = UniverseSpec(name="DocumentUniverse", selectors={"family":["science"], "type":["fact"]})
    gu = UniverseSpec(name="GovernanceUniverse", selectors={}, policies={"read_only":True, "governance":["safe_cube","porter_only"]})

    UM = um.create_universe(uu)
    DM = um.create_universe(du)
    GM = um.create_universe(gu)

    base_task = UniverseSpec(name="TaskUniverse", parent="UserUniverse", selectors={"family":["science"], "type":["fact"], "tags":{"score_gt":0.6}},
                             overlays={"add": [], "remove": []}, policies={"read_only":False, "isolated":True})
    TU = um.create_universe(base_task)

    add_id = repo.list()[0]
    T2 = um.fork_universe("TaskUniverse", "TaskUniverse_plusOne", overlays={"add":[add_id], "remove":[]})

    comp_task = um.compose("TaskUniverse")
    comp_plus = um.compose("TaskUniverse_plusOne")
    delta = um.diff("TaskUniverse", "TaskUniverse_plusOne")

    return {"universes": um.list_universes(), "task_compose": comp_task, "plus_compose": comp_plus, "diff": delta}

if __name__ == "__main__":
    out = run()
    print(json.dumps(out, indent=2))
