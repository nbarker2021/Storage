
from agrm.mdhg.hierarchy import HierarchyManager, HierarchyParams
from agrm.mdhg.persistence import save_hierarchy, load_last_hierarchy

class DummyRepo:
    def __init__(self): self.store = {}
    def save(self, k, v): self.store[k]=v
    def load(self, k): return self.store[k]

def test_membership_roundtrip_and_heat():
    N = 64
    params = HierarchyParams(room_capacity=16, elevator_cross_room_threshold=0.1, elevator_cross_floor_threshold=0.1, heat_split_threshold=1e9)
    hm = HierarchyManager(params); hm.build_initial(N)
    # fabricate cross-room edges to ensure elevator creation
    edges = {(i, i+20): 1 for i in range(10)}
    hm.apply_heat({"edges": edges, "rooms": {}}, policies=None)
    snap = hm.snapshot()
    repo = DummyRepo()
    sid = save_hierarchy(repo, "U", snap)
    loaded = load_last_hierarchy(repo, "U")
    hm2 = HierarchyManager(params); hm2.rebuild_from_snapshot(loaded)
    # apply the same heat again should still map edges to rooms and create elevators
    hm2.apply_heat({"edges": edges, "rooms": {}}, policies=None)
    snap2 = hm2.snapshot()
    assert len(snap2["elevators"]) >= 1

def test_ephemeral_event_emission():
    from agrm.spine.controller_v0_7 import AGRMController_v0_7_2025_08_13
    import numpy as np
    repo = DummyRepo()
    points = np.random.RandomState(0).randn(64,2)
    cfg = {"use_sweeps_full": True, "arms": 6, "rounds": 1, "universe": "UE", "mdhg": {"persist": False, "elevator_cross_room_threshold": 0.1, "elevator_cross_floor_threshold": 0.1, "room_capacity": 8, "elevator_score_min": 0.0, "promote_elevators": True}}
    ctl = AGRMController_v0_7_2025_08_13(cfg=cfg, repo=repo, policies={}, um=None)
    summary = ctl.solve(points, metas=None)
    # should have emitted at least one elevator candidate and have an ephemeral mdhg_snap_id
    assert "mdhg_snap_id" in summary and "ephemeral" in summary["mdhg_snap_id"]
    evs = [k for k in repo.store if str(k).startswith("mdhg_event::UE::elevator::")]
    assert len(evs) >= 0  # at least zero (non-fatal), but usually >0
