
from typing import List, Tuple
from .repo_ops import list_prefix
def list_events(repo, universe: str) -> List[str]:
    pref = f"mdhg_event::{universe}::elevator::"
    return [k for k in list_prefix(repo, pref) if k.startswith(pref)]
def list_results(repo, universe: str) -> List[str]:
    pref = f"result::elevator::{universe}::"
    return [k for k in list_prefix(repo, pref) if k.startswith(pref)]
def list_mdhg(repo, universe: str) -> List[str]:
    pref = f"mdhg::{universe}::"
    return [k for k in list_prefix(repo, pref) if k.startswith(pref)]
