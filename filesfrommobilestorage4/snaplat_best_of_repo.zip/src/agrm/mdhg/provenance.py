
import hashlib, json
from typing import Dict, List

def hash_str(s: str) -> str:
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()

def node_sig(n: Dict) -> str:
    payload = json.dumps({
        "doc": n.get("doc",""), "title": n.get("title",""),
        "level": n.get("level",0), "refined_text": n.get("refined_text","")
    }, sort_keys=True)
    return hash_str(payload)

def mdhg_chain(nodes: List[Dict]) -> List[Dict]:
    chain = []
    prev = "0"*64
    for i, n in enumerate(sorted(nodes, key=lambda x: (x.get("doc",""), x.get("position",0)))):
        sig = hash_str(json.dumps({"content": node_sig(n), "parent": prev, "meta": (n.get("doc",""), n.get("position",0))}, sort_keys=True))
        chain.append({"index": i, "doc": n.get("doc",""), "position": n.get("position",0), "sig": sig})
        prev = sig
    return chain

def build_id(chain: List[Dict]) -> str:
    if not chain: return "0"*64
    tail = chain[-1]["sig"]
    return hash_str(tail + ":" + str(len(chain)))
