
from agrm.mdhg.hierarchy import HierarchyManager, HierarchyParams

def test_initial_rooms_and_elevator_creation():
    N = 100
    params = HierarchyParams(room_capacity=10, max_rooms_per_floor=4, heat_split_threshold=1000, elevator_cross_floor_threshold=3, elevator_cross_room_threshold=3)
    hm = HierarchyManager(params)
    hm.build_initial(N)
    snap0 = hm.snapshot()
    assert sum(r['size'] for r in snap0['rooms']) == N
    # fabricate heat across different rooms to trigger elevators
    # connect indices 0..9 with 50..59 (likely different rooms)
    edges = {}
    for i in range(10):
        edges[(i, 50+i)] = 1
    hm.apply_heat({"edges": edges, "rooms": {}})
    snap1 = hm.snapshot()
    assert len(snap1['elevators']) >= 1
