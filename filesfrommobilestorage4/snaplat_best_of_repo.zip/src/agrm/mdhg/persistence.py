
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from typing import Dict, Any, Optional
import time, json

LATEST_KEY = "mdhg::{universe}::latest"

def save_hierarchy(repo, universe: str, snapshot: Dict[str,Any]) -> str:
    ts = int(time.time())
    snap_id = f"mdhg::{universe}::{ts}"
    payload = {"meta": {"snap_id": snap_id, "family": "mdhg_hierarchy", "type": "layout", "tags": {"universe": universe, "ts": ts}},
               "content": snapshot}
    repo.save(snap_id, payload)
    # update latest pointer
    pointer_id = LATEST_KEY.format(universe=universe)
    repo.save(pointer_id, {"meta":{"snap_id": pointer_id, "family":"pointer", "type":"mdhg_latest", "tags":{"universe": universe}},
                           "content":{"latest": snap_id}})
    return snap_id

def load_last_hierarchy(repo, universe: str) -> Optional[Dict[str,Any]]:
    pointer_id = LATEST_KEY.format(universe=universe)
    try:
        ptr = repo.load(pointer_id)
        latest = (ptr.get("content") or {}).get("latest")
        if not latest: return None
        data = repo.load(latest)
        return data.get("content")
    except Exception:
        return None
