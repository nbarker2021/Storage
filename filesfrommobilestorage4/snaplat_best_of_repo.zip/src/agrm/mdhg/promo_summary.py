
import time
def write_promotion_summary(repo, um, universe: str, *, iterations, delivered: bool, reason: str):
    final = iterations[-1]
    promoted = int(final["promotion"].get("promoted",0))
    rejected = int(final["promotion"].get("rejected",0))
    total = promoted + rejected
    rate = (promoted / max(1,total)) if total>0 else 0.0
    cand = int(final["summary"].get("telemetry",{}).get("candidates_emitted",0))
    rooms = len(final["summary"].get("mdhg",{}).get("rooms",[]))
    elevs = len(final["summary"].get("mdhg",{}).get("elevators",[]))
    snap_id = f"promotion_summary::{universe}::{int(time.time())}"
    payload = {"meta":{"snap_id": snap_id, "family":"report","type":"promotion_summary","tags":{"universe":universe}},
               "content":{"iterations": len(iterations), "delivered": delivered, "reason": reason,
                          "final":{"promoted": promoted,"rejected": rejected,"total": total,"promotion_rate": rate,
                                   "candidates_emitted": cand,"rooms": rooms,"elevators_found": elevs}}}
    repo.save(snap_id, payload)
    # overlay attach
    u = um.get_universe(universe)
    reports = u.overlays.get("reports", [])
    if not isinstance(reports, list): reports = []
    reports.append(snap_id)
    u.overlays["reports"] = sorted(set(reports))
    um.save_universe(u)
    return snap_id, payload
