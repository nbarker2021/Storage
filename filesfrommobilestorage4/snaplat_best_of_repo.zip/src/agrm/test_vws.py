import numpy as np
from core.agrm.vector_sketch import vector_warm_start
def test_vws_shapes_small():
    pts = np.array([[0.0,0.0],[1.0,0.0],[0.0,1.0],[1.0,1.0]])
    vws = vector_warm_start(pts, k=2, seeds=2)
    assert len(vws.knn_edges) > 0
    assert isinstance(vws.greedy_best_len, float)
    assert len(vws.angle_hist) == 16
