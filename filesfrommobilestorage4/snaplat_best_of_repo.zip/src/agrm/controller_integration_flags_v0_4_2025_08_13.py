
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
import numpy as np
from core.agrm.controller_v0_7_2025_08_13 import AGRMController_v0_7_2025_08_13 as CTRL

def run():
    rng = np.random.default_rng(21)
    pts = rng.random((3200,2))
    cfg = {
        "vws_force_grid": True, "vws_N_guard": 3000,
        "vws_grid_size": 64, "seeding_strategy": "grid",
        "use_adjacency_prefilter": True, "adj_k": 8, "adj_buckets": 64,
        "enable_sap": True, "enable_archivist": True, "enable_fastlane": True, "enable_snap_ops": True,
        "repository_root": "/mnt/data/repository_store_v0_1_2025_08_13",
        "fastlane_threshold": 0.70,
        "run_version": "v0_7_demo_int"
    }
    ctrl = CTRL(cfg=cfg)
    res = ctrl.solve(pts, max_ticks=3)
    print("RESULT:", res)
    return res

if __name__ == "__main__":
    run()
