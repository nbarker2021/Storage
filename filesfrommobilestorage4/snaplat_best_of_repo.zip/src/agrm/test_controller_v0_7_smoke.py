
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
import numpy as np
from core.agrm.controller_v0_7_2025_08_13 import AGRMController_v0_7_2025_08_13 as CTRL

def test_flags_smoke():
    pts = np.random.RandomState(0).rand(1000,2)
    ctrl = CTRL(cfg={"use_adjacency_prefilter": True, "vws_grid_size": 32, "vws_N_guard": 1000})
    res = ctrl.solve(pts, max_ticks=2)
    assert "stats" in res and "seed_picks" in res["stats"]

if __name__ == "__main__":
    test_flags_smoke()
    print("OK")
