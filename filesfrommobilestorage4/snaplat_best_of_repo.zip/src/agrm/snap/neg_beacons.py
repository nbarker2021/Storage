
NEG_BEACON_PAIRS = [("fiction","governance"), ("fiction","policy")]
DEFAULT_PENALTY = 0.08
