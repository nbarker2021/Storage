
from typing import Dict, Any, List, Optional
from pathlib import Path
import json, time, zipfile, io

from .repository import Repository
from ..universe.manager import UniverseManager

SNAP_META_FILE = "snapshot_meta.json"
SNAPS_FILE = "snaps.jsonl"
UNIVERSES_FILE = "universes.jsonl"

def create_snapshot(repo_root: str, reg_root: str, out_zip: str, label: str = None) -> str:
    repo = Repository(repo_root)
    um = UniverseManager(repo_root, reg_root)
    snaps = repo.list()
    buf = io.BytesIO()
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        # meta
        meta = {"ts": time.time(), "label": label or "snapshot", "count": len(snaps)}
        zf.writestr(SNAP_META_FILE, json.dumps(meta, indent=2))
        # snaps (jsonl)
        sio = io.StringIO()
        for sid in snaps:
            obj = repo.load(sid)
            sio.write(json.dumps({"snap_id": sid, "obj": obj}) + "\n")
        zf.writestr(SNAPS_FILE, sio.getvalue())
        # universes
        sio2 = io.StringIO()
        for name in um.list_universes():
            u = um.get_universe(name)
            sio2.write(json.dumps({"name": name, "spec": u.spec.__dict__, "overlays": u.overlays, "snaps": list(u.snaps)}) + "\n")
        zf.writestr(UNIVERSES_FILE, sio2.getvalue())
    return out_zip

def restore_snapshot(repo_root: str, reg_root: str, in_zip: str, mode: str = "merge") -> Dict[str,Any]:
    assert mode in ("merge","replace")
    repo = Repository(repo_root)
    um = UniverseManager(repo_root, reg_root)
    with zipfile.ZipFile(in_zip, "r") as zf:
        snaps = []
        universes = []
        if SNAPS_FILE in zf.namelist():
            for line in zf.read(SNAPS_FILE).decode("utf-8").splitlines():
                rec = json.loads(line)
                snaps.append(rec)
        if UNIVERSES_FILE in zf.namelist():
            for line in zf.read(UNIVERSES_FILE).decode("utf-8").splitlines():
                universes.append(json.loads(line))
        if mode == "replace":
            # Danger: wipe existing (shallow)
            for sid in list(repo.list()):
                try: repo.delete(sid)
                except Exception: pass
            for name in list(um.list_universes()):
                try: um.delete_universe(name)
                except Exception: pass
        # restore snaps
        for rec in snaps:
            repo.save(rec["snap_id"], rec["obj"])
        # restore universes
        for urec in universes:
            name = urec["name"]
            try:
                if name not in um.list_universes():
                    um.create_universe(um.UniverseSpec(name=name, selectors={}, policies={}))  # type: ignore
            except Exception:
                pass
            u = um.get_universe(name)
            u.spec.__dict__.update(urec.get("spec", {}))
            u.overlays = urec.get("overlays", {})
            u.snaps = set(urec.get("snaps", []))
            um.save_universe(u)
    return {"snaps": len(snaps), "universes": len(universes), "mode": mode}
