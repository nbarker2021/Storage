
# e8_geometry_shim.py
# Import E8 geometry from v14; fallback to older containers for compatibility.
try:
    from lattice_ai.geometry.e8_roots import E8, generate_e8_roots, standard_simple_roots  # v14 path
    from lattice_ai.geometry.e8 import E8Geometry
except Exception:  # pragma: no cover - fallback
    try:
        from lattice_system_base_v14.lattice_ai.geometry.e8_roots import E8, generate_e8_roots, standard_simple_roots
        from lattice_system_base_v14.lattice_ai.geometry.e8 import E8Geometry
    except Exception:
        # Final fallback: older lineage (v12)
        from lattice_system_base_v12.lattice_system_base_v12.lattice_ai.geometry.e8_roots import E8, generate_e8_roots, standard_simple_roots  # type: ignore
        from lattice_system_base_v12.lattice_system_base_v12.lattice_ai.geometry.e8 import E8Geometry  # type: ignore
