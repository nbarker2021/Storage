
from __future__ import annotations
from typing import Dict, Any, List, Tuple
import numpy as np, json, pathlib
from lattice_ai.tests.edge_runner import run as run_edge
from lattice_ai.snap.dna import SnapVariant, save_variant
from lattice_ai.snap.snaphash import load_latest

def matrix(snaphash_id: str = "router→shells", seeds=(99,), configs=None) -> Dict[str, Any]:
    if configs is None:
        configs = [
            {"bits":16, "mod":257, "alpha":1.0, "beta":0.25},
            {"bits":24, "mod":257, "alpha":0.8, "beta":0.4},
            {"bits":32, "mod":521, "alpha":0.8, "beta":0.4},
            {"bits":32, "mod":1021, "alpha":1.0, "beta":0.2},
        ]
    rows = []
    # run all configs and collect SNAPHASH records
    for cfg in configs:
        cfg_id = f"{snaphash_id}|b{cfg['bits']}m{cfg['mod']}a{cfg['alpha']}b{cfg['beta']}"
        for s in seeds:
            out = run_edge(cfg_id, bits=cfg["bits"], mod=cfg["mod"], alpha=cfg["alpha"], beta=cfg["beta"], seed=s)
            # read back latest snaphash for this id to get metrics
            rec = load_latest(cfg_id)["data"]
            met = rec["record"]["metrics"]["actual"] if rec.get("found") else {}
            rows.append({"snaphash_id": cfg_id, "seed": s, **cfg, **met})
    # choose champion: maximize recall, then minimize avg_cand, then minimize gdist_max
    def key(r):
        return (r.get("recall@1_nonzero", 0.0), -r.get("avg_cand", 1e9), -r.get("gdist_max", 1e9))
    champion = sorted(rows, key=key, reverse=True)[0] if rows else None
    # save champion as a SNAP variant
    if champion:
        champ_cfg = {"bits": int(champion["bits"]), "mod": int(champion["mod"]), "alpha": float(champion["alpha"]), "beta": float(champion["beta"])}
        sv = SnapVariant(name="champ_router_shells", kind="edge", version="0.2.0",
                         tags={"snaphash_root": snaphash_id, "criteria": "recall desc, avg_cand asc, gdist_max asc"},
                         payload=champ_cfg)
        save = save_variant(sv)
    else:
        save = {"data": {"file": None}}
    return {"_artifact":"snaphash_matrix", "data":{"rows": rows, "champion": champion, "snap_save": save["data"]}}
