
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple

def generate_e8_roots() -> np.ndarray:
    """
    Generate the 240 roots of E8 in R^8 with squared length 2.
    Construction: union of
      - 112 roots with entries (±1, ±1, 0^6), all permutations
      - 128 roots with entries (±1/2)^8 with an even number of minus signs
    """
    roots = []
    # Type 1: (±1, ±1, 0^6)
    e = np.eye(8)
    idx_pairs = [(i,j) for i in range(8) for j in range(i+1,8)]
    for i,j in idx_pairs:
        v = np.zeros(8)
        v[i] = 1.0; v[j] = 1.0
        roots.append(v.copy())
        v[j] = -1.0
        roots.append(v.copy())
        v[i] = -1.0; v[j] = 1.0
        roots.append(v.copy())
        v[j] = -1.0
        roots.append(v.copy())
    # Type 2: (±1/2)^8 with even number of minus signs
    for mask in range(1<<8):
        bits = [(mask>>k)&1 for k in range(8)]
        minus = sum(bits)
        if minus % 2 == 0:
            v = np.array([ -0.5 if b else 0.5 for b in bits ], dtype=float)
            roots.append(v)
    R = np.array(roots, dtype=float)
    # Remove duplicates and verify norm sqrt(2)
    # (There shouldn't be duplicates, but numeric safety)
    uniq = np.unique(np.round(R,6), axis=0)
    # Normalize to squared length 2 (already true for construction)
    return uniq

def standard_simple_roots() -> np.ndarray:
    """
    A standard choice of simple roots for E8 (Bourbaki-like convention).
    Each has squared length 2.
    """
    e = np.eye(8)
    a1 = e[0]-e[1]
    a2 = e[1]-e[2]
    a3 = e[2]-e[3]
    a4 = e[3]-e[4]
    a5 = e[4]-e[5]
    a6 = e[5]-e[6]
    a7 = e[6]-e[7]
    a8 = (-e[0]-e[1]-e[2]-e[3]-e[4]-e[5]-e[6]+e[7])/2.0
    A = np.stack([a1,a2,a3,a4,a5,a6,a7,a8], axis=0)
    # Ensure squared length ~2
    return A

@dataclass
class E8:
    roots: np.ndarray
    simple: np.ndarray

    @classmethod
    def build(cls):
        R = generate_e8_roots()
        S = standard_simple_roots()
        return cls(roots=R, simple=S)

    def reflect(self, v: np.ndarray, k: int) -> np.ndarray:
        r = self.simple[k]
        return v - 2.0 * (np.dot(v, r) / np.dot(r, r)) * r

    def neighbor_graph(self) -> Tuple[np.ndarray, List[List[int]]]:
        """
        Build adjacency by connecting roots whose inner product is +1
        (angle 60 degrees for length sqrt(2)).
        Returns (roots, neighbors)
        """
        R = self.roots
        G = R @ R.T
        # squared norms are 2 -> dot 1 means cos(theta)=1/2
        n = R.shape[0]
        nbrs: List[List[int]] = []
        for i in range(n):
            idx = np.where(np.isclose(G[i], 1.0, atol=1e-6))[0].tolist()
            nbrs.append(idx)
        return R, nbrs
