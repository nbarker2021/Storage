
from __future__ import annotations
from fastapi import APIRouter
from pydantic import BaseModel
from lattice_ai.snap.dna import SnapVariant, save_variant, load_latest

router = APIRouter(prefix="/snap", tags=["snap"])

class SnapIn(BaseModel):
    name: str
    kind: str
    version: str
    tags: dict
    payload: dict

@router.post("/save")
def save(v: SnapIn):
    sv = SnapVariant(name=v.name, kind=v.kind, version=v.version, tags=v.tags, payload=v.payload)
    return save_variant(sv)

@router.get("/load_latest")
def load(name: str, kind: str):
    return load_latest(name, kind)
