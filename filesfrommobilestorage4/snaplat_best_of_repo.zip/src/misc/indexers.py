
import math
from collections import Counter
from typing import Dict, List, Tuple
from .refiner import tokenize

def build_tfidf(docs: List[List[str]]) -> Tuple[Dict[str, float], List[Dict[str, float]]]:
    N = len(docs) or 1
    df: Counter = Counter()
    for toks in docs:
        for w in set(toks): df[w]+=1
    idf = {w: math.log((N+1)/(df[w]+1)) + 1.0 for w in df}
    vecs = []
    for toks in docs:
        tf = Counter(toks); norm=0.0; v={}
        for w,c in tf.items():
            if w in idf:
                val=(1+math.log(c))*idf[w]; v[w]=val; norm+=val*val
        norm = math.sqrt(norm) or 1.0
        for w in v: v[w]/=norm
        vecs.append(v)
    return idf, vecs

def vecize(query: str, idf: Dict[str,float]) -> Dict[str,float]:
    tf = Counter(tokenize(query))
    v={}; norm=0.0
    for w,c in tf.items():
        if w in idf:
            val=(1+math.log(c))*idf[w]; v[w]=val; norm+=val*val
    norm = math.sqrt(norm) or 1.0
    for w in v: v[w]/=norm
    return v

def cosine(qv: Dict[str,float], dv: Dict[str,float]) -> float:
    s=0.0
    for w,v in qv.items():
        if w in dv: s += v*dv[w]
    return s
