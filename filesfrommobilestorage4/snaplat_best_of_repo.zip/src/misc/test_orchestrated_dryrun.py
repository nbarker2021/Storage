
import os, json, pathlib
import pytest
from src.testlib_plus.orchestrator import Orchestrator

@pytest.mark.orchestrated
def test_dryrun_plan(tmp_path: pathlib.Path):
    code_root = os.environ.get("CODE_UNDER_TEST", "/mnt/data/ground_up_build")
    plan = os.environ.get("TEST_PLAN", str(tmp_path/"plan.yml"))
    out = os.environ.get("DRYRUN_REPORT", str(tmp_path/"report.json"))

    if not pathlib.Path(plan).exists():
        # write a tiny default plan that calls a safe lambda in stdlib
        import textwrap
        pathlib.Path(plan).write_text(textwrap.dedent("""
        steps:
          - name: 'smoke:len'
            family: 'generic'
            module: 'builtins'
            func: 'len'
            args: ['abc']
            priority: 10
        """))

    orch = Orchestrator(code_root, plan, out)
    rep = orch.run()
    assert "queue_records" in rep
    assert any(r["status"] in ("ok","skipped_denied") for r in rep["queue_records"])
