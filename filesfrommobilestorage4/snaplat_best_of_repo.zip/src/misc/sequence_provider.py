
from __future__ import annotations
from typing import Protocol, Dict, Any

class SequenceProvider(Protocol):
    def run(self, **kwargs) -> Dict[str, Any]:
        ...

def load_provider(dotted: str) -> SequenceProvider:
    # Load an object with a .run(**kwargs) method from dotted path "module:attr"
    mod_path, attr = dotted.split(":")
    import importlib
    mod = importlib.import_module(mod_path)
    return getattr(mod, attr)
