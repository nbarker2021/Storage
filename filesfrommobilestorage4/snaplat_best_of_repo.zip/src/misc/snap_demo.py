
from __future__ import annotations
from lattice_ai.snap.dna import SnapVariant, save_variant, load_latest

def demo():
    sv = SnapVariant(name="encoder_e8_v1", kind="encoder", version="0.1.0",
                     tags={"shape": "E8", "dims": 8, "banks": ["docs","blobs"]},
                     payload={"salt": "E8", "k_default": 3})
    save = save_variant(sv)
    load = load_latest("encoder_e8_v1", "encoder")
    return {"_artifact":"snap_demo", "data": {"save": save["data"], "load": load["data"]}}


from __future__ import annotations
from lattice_ai.snap.dna import SnapVariant, save_variant

def save_baseline():
    sv = SnapVariant(name="baseline_router_v1", kind="router", version="0.1.0",
                     tags={"notes":"alpha/beta + two-tier bits/mod baseline"},
                     payload={"alpha":0.8, "beta":0.4, "tier1_bits":24, "house_mod":257})
    return save_variant(sv)
