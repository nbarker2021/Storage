
import re
from typing import Dict, List, Tuple, Set
from collections import defaultdict
from .families import families_for_text, gazetteer_terms

ACRONYM = re.compile(r"\b[A-Z]{2,}(?:[\-/][A-Z]{2,})*\b")
CAP_PHRASE = re.compile(r"\b(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})\b")
INTERNAL_LINK = re.compile(r"\[([^\]]+)\]\([^\)]+\)")

def extract_entities(text: str) -> List[str]:
    ents: Set[str] = set()
    for m in ACRONYM.finditer(text or ""):
        ents.add(m.group(0))
    for m in CAP_PHRASE.finditer(text or ""):
        t = m.group(0).strip()
        if t.lower() in {"the","a","an","and","or","but","this","that"}:
            continue
        ents.add(t)
    for m in INTERNAL_LINK.finditer(text or ""):
        ents.add(m.group(1))
    # Gazetteer exact matches (family vocab) at token level
    gzs = gazetteer_terms()
    textL = (text or "").lower()
    for gz in gzs:
        if gz in textL:
            ents.add(gz)
    ents = {e.strip() for e in ents if len(e.strip())>=2}
    return sorted(ents)

def entity_family(name: str) -> List[str]:
    # classify entity by running family detection over its name
    fams = families_for_text(name)
    return fams or ["ENT"]

def build_entity_graph(nodes: List[Dict]) -> Dict:
    """
    Build an entity graph with typed entities:
      - entity nodes (ENT:<n>) + attributes {name, families}
      - edges: node -> entity (type: mentions:<FAM> or mentions)
      - edges: entity <-> entity (co-mention; type: co_entity)
    """
    entity_ids: Dict[str, str] = {}
    entity_meta: Dict[str, Dict] = {}
    ent_counter = 0
    edges: List[Dict] = []
    mentions: Dict[str, List[str]] = defaultdict(list)  # node_id -> [entity_id]

    # pass 1: extract entities
    for n in nodes:
        text = (n.get("title","") + "\n" + n.get("raw_text","") + "\n" + n.get("refined_text",""))
        ents = extract_entities(text)
        n["entities"] = ents
        for e in ents:
            key = e.lower()
            if key not in entity_ids:
                ent_counter += 1
                entity_ids[key] = f"ENT:{ent_counter:05d}"
                entity_meta[key] = {"id": entity_ids[key], "name": e, "families": entity_family(e)}
            mentions[n["id"]].append(entity_ids[key])
            fams = entity_meta[key]["families"]
            etype = "mentions:" + (fams[0] if fams else "ENT")
            edges.append({"src": n["id"], "dst": entity_ids[key], "type": etype})
    # pass 2: entity co-mention edges
    for n in nodes:
        ents = mentions.get(n["id"], [])
        for i in range(len(ents)):
            for j in range(i+1, min(i+8, len(ents))):
                edges.append({"src": ents[i], "dst": ents[j], "type": "co_entity"})
                edges.append({"src": ents[j], "dst": ents[i], "type": "co_entity"})

    return {"entities": list(entity_meta.values()), "edges": edges}
