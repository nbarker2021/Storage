
from fastapi.testclient import TestClient
from fastapi import FastAPI
from rest.query_endpoint import router as query_router
from rest.shells_endpoint import router as shells_router
import os, numpy as np

def make_app():
    app = FastAPI()
    app.include_router(query_router)
    app.include_router(shells_router)
    return app

def test_query_smoke():
    os.environ["ENABLE_DUAL_RETRIEVAL"] = "0"
    app = make_app()
    c = TestClient(app)
    body = {
        "center": [1,0,0,0,0,0,0,0],
        "candidates": np.eye(8).tolist(),
        "topk": 3
    }
    r = c.post("/query_budgeted", json=body)
    assert r.status_code == 200
    data = r.json()
    assert "indices" in data and len(data["indices"]) == 3

def test_shells_smoke():
    os.environ["ENABLE_DUAL_SHELLS"] = "0"
    app = make_app()
    c = TestClient(app)
    body = {
        "center": [1,0,0,0,0,0,0,0],
        "neighbors_v14": np.eye(8).tolist()
    }
    r = c.post("/build_shells", json=body)
    assert r.status_code == 200
    data = r.json()
    assert data["ok"] is True
