
import numpy as np
def knn(points: np.ndarray, queries: np.ndarray, k:int=8):
    try:
        import faiss  # type: ignore
        d = points.shape[1]
        index = faiss.IndexFlatL2(d)
        index.add(points.astype(np.float32))
        D,I = index.search(queries.astype(np.float32), k)
        return I, D
    except Exception:
        # fallback: brute-force
        I_list=[]; D_list=[]
        for q in queries:
            dists = np.linalg.norm(points - q, axis=1)
            idx = np.argsort(dists)[:k]
            I_list.append(idx); D_list.append(dists[idx])
        return np.stack(I_list), np.stack(D_list)
