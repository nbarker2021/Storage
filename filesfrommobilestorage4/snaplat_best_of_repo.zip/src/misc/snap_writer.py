
from __future__ import annotations
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from .validators import validate_snap
@dataclass(slots=True)
class SnapManifest:
    schema_version: str
    snap_id: str
    created_at: str
    e8: Dict[str, Any]
    axes: Dict[str, Any]
    kind: str
    parent_id: Optional[str] = None
    children: Optional[list[str]] = None
    hashes: Optional[Dict[str, str]] = None
    payload: Optional[Dict[str, Any]] = None
    provenance: Optional[Dict[str, Any]] = None
    security: Optional[Dict[str, Any]] = None
    metrics: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
def write_manifest(manifest: Dict[str, Any] | SnapManifest, path: Path) -> None:
    obj = asdict(manifest) if isinstance(manifest, SnapManifest) else manifest
    validate_snap(obj)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2))
    tmp.replace(path)
