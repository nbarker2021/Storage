
#!/usr/bin/env python3
import sys, pathlib
NEEDLE = "SnapLat — Personal-Use License"
EXTS = {'.py','.js','.ts','.tsx','.jsx','.java','.kt','.go','.rs','.c','.h','.hpp','.cpp','.cs','.swift','.rb'}
def bad_files(root: pathlib.Path):
    missing = []
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower() in EXTS:
            try:
                t = p.read_text(encoding='utf-8', errors='ignore')
                if NEEDLE not in t[:400]:
                    missing.append(str(p))
            except Exception:
                missing.append(str(p))
    return missing
def main():
    root = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
    missing = bad_files(root)
    if missing:
        print("ERROR: Missing SnapLat header in:")
        for m in missing: print(" -", m)
        sys.exit(1)
    print("All checked files have SnapLat header.")
if __name__ == '__main__':
    main()
