
from typing import List, Dict, Any

class Journal_v0_1_2025_08_13:
    def __init__(self):
        self.events: List[Dict[str,Any]] = []
    def log(self, kind:str, **payload):
        e = {"kind": kind, **payload}
        self.events.append(e)
        # For tests, also print
        print("[JOURNAL]", e)
    def dump(self) -> List[Dict[str,Any]]:
        return list(self.events)
