
from __future__ import annotations
import json
from pathlib import Path
from lattice_ai.bridge.dual_stack import load_dual, maybe_emit_snap

def main() -> None:
    v14, legacy, report = load_dual()
    print("Loaded v14:", bool(v14))
    print("Loaded legacy:", bool(legacy))
    if report:
        print(json.dumps(report, indent=2))
        axes = {"version_container": "v14", "tenant": "demo", "domain": "geometry"}
        maybe_emit_snap(report, axes)

if __name__ == "__main__":
    main()
