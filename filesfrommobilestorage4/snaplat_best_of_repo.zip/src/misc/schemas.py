
from __future__ import annotations
from pathlib import Path
import json
from typing import Any, Dict
BASE = Path(__file__).resolve().parents[3] / "schemas"
def load_e8_schema() -> Dict[str, Any]:
    return json.loads((BASE / "E8_Addressing_Schema_v0.1.json").read_text())
def load_snap_schema() -> Dict[str, Any]:
    return json.loads((BASE / "snap_manifest_v2.schema.json").read_text())
