
from fastapi import Header, HTTPException
from typing import Optional
from ..persistence.sqlite_store import SQLiteStore
from .config import Config

def get_tenant_and_key(store: SQLiteStore, x_api_key: str, x_tenant: Optional[str]) -> str:
    tenant = x_tenant or "public"
    # If API key required, validate against tenants table
    if Config.API_KEY:  # global override allows single-tenant demo
        if x_api_key != Config.API_KEY:
            raise HTTPException(status_code=401, detail="Invalid global API key")
        return tenant
    # Otherwise, check per-tenant key if tenant provided
    row = store.conn.execute("SELECT api_key FROM tenants WHERE tenant_id=?", (tenant,)).fetchone()
    if row is None or (row[0] and row[0] != x_api_key):
        raise HTTPException(status_code=401, detail="Invalid tenant key or unknown tenant")
    return tenant
