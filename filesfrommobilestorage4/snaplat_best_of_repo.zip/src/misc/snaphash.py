
from __future__ import annotations
import json, time, pathlib, os, hashlib
from dataclasses import dataclass, asdict
from typing import Dict, Any

SNAPHASH_ROOT = pathlib.Path(os.environ.get("SNAPHASH_ROOT", "/mnt/data/e8_repo/artifacts/snaphash"))
SNAPHASH_ROOT.mkdir(parents=True, exist_ok=True)

@dataclass
class SnapHash:
    snaphash_id: str
    src: Dict[str, Any]
    dst: Dict[str, Any]
    replay: Dict[str, Any]
    expect: Dict[str, Any]
    metrics: Dict[str, Any]
    artifact_ref: str | None = None
    version: str = "0.1.0"

def _digest_obj(obj: Dict[str, Any]) -> str:
    b = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    h = hashlib.blake2b(b, digest_size=16).hexdigest()
    return f"b2-128:{h}"

def save_snaphash(sh: SnapHash) -> dict:
    ts = int(time.time()*1000)
    fname = f"{sh.snaphash_id.replace(':','_')}__{ts}.json"
    path = SNAPHASH_ROOT / fname
    record = asdict(sh) | {"signature": _digest_obj({"src": sh.src, "dst": sh.dst, "expect": sh.expect})}
    path.write_text(json.dumps(record, indent=2))
    return {"_artifact": "snaphash_save", "data": {"file": str(path), "snaphash_id": sh.snaphash_id, "signature": record["signature"]}}

def load_latest(snaphash_id: str) -> dict:
    pref = snaphash_id.replace(":","_")
    files = sorted(SNAPHASH_ROOT.glob(f"{pref}__*.json"))
    if not files:
        return {"_artifact": "snaphash_load", "data": {"found": False, "snaphash_id": snaphash_id}}
    path = files[-1]
    j = json.loads(path.read_text())
    return {"_artifact": "snaphash_load", "data": {"found": True, "file": str(path), "record": j}}
