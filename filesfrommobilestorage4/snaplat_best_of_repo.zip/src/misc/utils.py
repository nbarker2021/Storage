
from __future__ import annotations
import re, hashlib
from typing import List, Dict, Any, Tuple

YOU = re.compile(r"^\s*You Said:\s*$")
AI  = re.compile(r"^\s*ChatGPT said:\s*$")
THINK = re.compile(r"^\s*Thought for\s+(\d+)\s+seconds\s*$", re.IGNORECASE)

def parse_log(text: str):
    lines = text.splitlines()
    events = []
    i = 0
    def collect_until(start_idx, stops):
        buff = []; i = start_idx + 1
        while i < len(lines):
            line = lines[i]
            if any(pat.match(line) for pat in stops): break
            buff.append(line); i += 1
        return i, "\n".join(buff)
    while i < len(lines):
        line = lines[i]
        if YOU.match(line):
            j, body = collect_until(i, [AI, YOU, THINK])
            events.append({"role":"user","content":body,"line_start":i,"line_end":j}); i=j; continue
        m = THINK.match(line)
        if m:
            sec = int(m.group(1)); events.append({"role":"assistant_thought","content":line.strip(),"thought_seconds":sec,"line_start":i,"line_end":i+1}); i+=1; continue
        if AI.match(line):
            j, body = collect_until(i, [YOU, AI, THINK])
            events.append({"role":"assistant","content":body,"line_start":i,"line_end":j}); i=j; continue
        i += 1
    return events

def tokseq(s: str) -> Tuple[int, ...]:
    """Lightweight deterministic numeric sequence for encoding text.

    Uses hashed 2-gram buckets to produce up to 32 ints.
    """
    if not s: return (0,)
    s = s.strip().lower()
    toks = s.split()
    buckets = [0]*32
    for i in range(len(toks)-1):
        big = toks[i] + " " + toks[i+1]
        h = int(hashlib.sha256(big.encode('utf-8')).hexdigest(), 16)
        buckets[h % 32] = (buckets[h % 32] + (h % 9973)) % 65535
    # include lengths
    buckets[0] = (buckets[0] + len(s)) % 65535
    buckets[1] = (buckets[1] + len(toks)) % 65535
    return tuple(buckets)

FILE_TOKEN = re.compile(r"\b[\w\-\./\\]+\.(?:py|ipynb|json|yaml|yml|ini|cfg|txt|md|toml|sh|bat|ps1|zip|whl|csv)\b", re.IGNORECASE)
def file_tokens(text: str):
    return sorted(set(m.group(0) for m in FILE_TOKEN.finditer(text or "")))
