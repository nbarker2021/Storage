
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
import numpy as np

from config.flags import ENABLE_DUAL_RETRIEVAL, SNAP_ON_COMPARE
from retrieval.scorer import ScorerConfig, rerank
from retrieval.dual_compare import compare_retrieval

router = APIRouter()

class QueryBody(BaseModel):
    center: list[float] = Field(..., min_items=8, max_items=8)
    candidates: list[list[float]]
    topk: int = 20
    alpha: float = 1.0
    beta: float = 0.0

METRICS = {
    "query_requests_total": 0,
    "query_dual_compare_total": 0,
}

@router.post("/query_budgeted")
def query_budgeted(body: QueryBody):
    METRICS["query_requests_total"] += 1
    q = np.array(body.center, dtype=float)
    docs = np.array(body.candidates, dtype=float)
    idx, scores = rerank(q, docs, ScorerConfig(alpha=body.alpha, beta=body.beta), topk=body.topk)
    result = {"indices": [int(i) for i in idx], "scores": [float(s) for s in scores]}

    if ENABLE_DUAL_RETRIEVAL:
        METRICS["query_dual_compare_total"] += 1
        rep = compare_retrieval(q, docs, topk=body.topk, axes={"version_container":"v14","tenant":"demo","domain":"retrieval"})
        result["dual_compare"] = rep
    return result
