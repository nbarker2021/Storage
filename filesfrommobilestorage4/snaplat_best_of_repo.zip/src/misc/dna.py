
from __future__ import annotations
import json, time, pathlib, os
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional

SNAP_ROOT = pathlib.Path(os.environ.get("SNAP_ROOT", "/mnt/data/e8_repo/artifacts/snap"))
SNAP_ROOT.mkdir(parents=True, exist_ok=True)

@dataclass
class SnapVariant:
    name: str
    kind: str           # e.g., 'agent', 'policy', 'encoder', 'pipeline'
    version: str        # semver-ish or timestamp
    tags: Dict[str, Any]
    payload: Dict[str, Any]

def save_variant(variant: SnapVariant) -> dict:
    ts = int(time.time()*1000)
    fname = f"{variant.kind}__{variant.name}__{variant.version}__{ts}.json"
    path = SNAP_ROOT / fname
    path.write_text(json.dumps(asdict(variant), indent=2))
    return {"_artifact": "snap_save", "data": {"file": str(path), "name": variant.name, "kind": variant.kind, "version": variant.version}}

def load_latest(name: str, kind: str) -> dict:
    files = sorted(SNAP_ROOT.glob(f"{kind}__{name}__*.json"))
    if not files:
        return {"_artifact": "snap_load", "data": {"found": False, "name": name, "kind": kind}}
    path = files[-1]
    j = json.loads(path.read_text())
    return {"_artifact": "snap_load", "data": {"found": True, "file": str(path), "record": j}}
