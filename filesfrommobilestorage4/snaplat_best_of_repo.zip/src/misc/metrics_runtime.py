
from dataclasses import dataclass, field
from typing import Dict, List
import time

@dataclass
class Counter:
    count: int = 0
    def inc(self, n: int = 1): self.count += n

@dataclass
class Gauge:
    value: float = 0.0
    def set(self, v: float): self.value = v

@dataclass
class Histogram:
    buckets: List[float] = field(default_factory=lambda: [5,10,20,50,100,200,500,1000])
    counts: List[int] = field(default_factory=lambda: [0]*8)
    def observe(self, v: float):
        for i, b in enumerate(self.buckets):
            if v <= b:
                self.counts[i] += 1
                return
        self.counts[-1] += 1

@dataclass
class Metrics:
    counters: Dict[str, Counter] = field(default_factory=dict)
    gauges: Dict[str, Gauge] = field(default_factory=dict)
    hists: Dict[str, Histogram] = field(default_factory=dict)

    def counter(self, name: str) -> Counter:
        return self.counters.setdefault(name, Counter())

    def gauge(self, name: str) -> Gauge:
        return self.gauges.setdefault(name, Gauge())

    def hist(self, name: str) -> Histogram:
        return self.hists.setdefault(name, Histogram())

    def snapshot(self) -> dict:
        return {
            "counters": {k: v.count for k,v in self.counters.items()},
            "gauges": {k: v.value for k,v in self.gauges.items()},
            "histograms": {k: {"buckets": v.buckets, "counts": v.counts} for k,v in self.hists.items()},
            "ts": time.time()
        }

GLOBAL_METRICS = Metrics()
