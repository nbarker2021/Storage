
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from dataclasses import dataclass
from typing import Dict, Any

def _allowed(fam: str, pol: Dict[str,Any]) -> bool:
    if not fam: 
        return True
    deny = set(pol.get("family_deny", []))
    allow = set(pol.get("family_allow", []))
    if fam in deny: return False
    if allow and fam not in allow: return False
    return True

@dataclass
class ElevatorDecision:
    staged: bool
    promoted: bool
    reason: str

class ElevatorFastLane:
    def __init__(self, *, threshold: float = 1.0, compat_policy: Dict[str,Any] | None = None):
        self.threshold = float(threshold)
        self.compat_policy = compat_policy or {}

    def evaluate(self, cand: Dict[str,Any]) -> ElevatorDecision:
        score = float(cand.get("score", 0.0))
        famA = (cand.get("roomA", {}).get("family"))
        famB = (cand.get("roomB", {}).get("family"))
        if score < self.threshold:
            return ElevatorDecision(False, False, "below_threshold")
        if not (_allowed(famA, self.compat_policy) and _allowed(famB, self.compat_policy)):
            return ElevatorDecision(False, False, "family_not_allowed")
        return ElevatorDecision(True, True, "ok")
