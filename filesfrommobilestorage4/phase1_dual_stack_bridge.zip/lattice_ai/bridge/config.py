
from __future__ import annotations
import os

# Dual-stack configuration via environment variables:
# E8_DUAL_MODE: "v14", "legacy", or "shadow" (shadow runs both and compares)
# E8_LEGACY_IMPORT: path hint for legacy module root if non-standard
# E8_SNAP_COMPARE: "1" to emit a SNAP manifest for comparison results (requires e8snap)
# E8_SNAP_KIND: manifest kind (default "Run")

MODE = os.getenv("E8_DUAL_MODE", "v14").lower()
LEGACY_HINT = os.getenv("E8_LEGACY_IMPORT", "").strip()
SNAP_COMPARE = os.getenv("E8_SNAP_COMPARE", "0") == "1"
SNAP_KIND = os.getenv("E8_SNAP_KIND", "Run")
