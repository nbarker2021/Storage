
# Dual-Stack Bridge (v14 + Legacy)

This package ties **v14** and **legacy (v8–v12)** E8 geometry implementations together.

- **Modes (env `E8_DUAL_MODE`)**
  - `v14` (default): use v14 APIs.
  - `legacy`: force legacy APIs.
  - `shadow`: run v14 and legacy in parallel and compare (root shapes, norms, neighbor degrees, reflection involutions).

- **Emit comparison SNAP**
  - Set `E8_SNAP_COMPARE=1` to write a SNAP v2 manifest with comparison metrics (requires `e8snap` package).
  - Output path: `snaps/reports/e8_dual_shadow.json`.

- **CLI**
  - `python -m tools.run_dual_compare` — prints comparison report; writes SNAP if enabled.

Integrate this bridge early, and incrementally port modules to v14 while keeping legacy parity checks.
