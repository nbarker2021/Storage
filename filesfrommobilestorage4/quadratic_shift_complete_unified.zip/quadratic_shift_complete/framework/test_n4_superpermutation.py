#!/usr/bin/env python3
"""
Test Script: n=4 Superpermutation Analysis and n=32 Dual Helix Extension

This script tests the framework's claims on the actual n=4 superpermutation,
then attempts to extend it to n=32 via dual helix bonds following all
framework rules and structures.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from quadratic_shift.core.parent_identity import ParentIdentityEngine
from quadratic_shift.core.quadratic_rest import QuadraticRestProcessor, generate_n4_superpermutation
import numpy as np
from typing import List, Dict, Any, Tuple


class FrameworkTester:
    """Complete framework testing system."""
    
    def __init__(self):
        self.parent_identity = ParentIdentityEngine()
        self.quadratic_rest = QuadraticRestProcessor()
        self.test_results = {}
    
    def test_n4_superpermutation(self) -> Dict[str, Any]:
        """Test framework claims on actual n=4 superpermutation."""
        print("=" * 80)
        print("TESTING n=4 SUPERPERMUTATION WITH QUADRATIC SHIFT FRAMEWORK")
        print("=" * 80)
        
        # Get the n=4 superpermutation
        superperm_str = generate_n4_superpermutation()
        superperm_sequence = [int(c) for c in superperm_str]
        
        print(f"n=4 Superpermutation: {superperm_str}")
        print(f"Length: {len(superperm_sequence)}")
        print(f"Sequence: {superperm_sequence}")
        print()
        
        # Process through quadratic rest system
        print("PROCESSING THROUGH QUADRATIC REST SYSTEM")
        print("-" * 50)
        
        processing_result = self.quadratic_rest.process_sequence(superperm_sequence, n_value=4)
        
        # Display results
        stats = processing_result['statistics']
        print(f"Total 4-windows extracted: {stats['total_windows']}")
        print(f"Direct legal: {stats['direct_legal']} ({stats['direct_legal_rate']:.1%})")
        print(f"Quarter-fix successful: {stats['quarter_fix_successful']} ({stats['quarter_fix_rate']:.1%})")
        print(f"Entropy slot routed: {stats['entropy_slot_routed']} ({stats['entropy_slot_rate']:.1%})")
        print(f"Overall success rate: {stats['success_rate']:.1%}")
        print()
        
        # Test specific framework claims
        print("TESTING FRAMEWORK CLAIMS")
        print("-" * 30)
        
        # Claim 1: >90% legality through direct + quarter-fix
        combined_success_rate = stats['direct_legal_rate'] + stats['quarter_fix_rate']
        claim_90_percent = combined_success_rate >= 0.90
        print(f"Claim: >90% legality (Direct + Quarter-fix)")
        print(f"Result: {combined_success_rate:.1%} - {'✓ VERIFIED' if claim_90_percent else '✗ FAILED'}")
        print()
        
        # Claim 2: Palindromic witnesses generated for legal windows
        palindromic_witnesses = processing_result['palindromic_witnesses']
        legal_windows = stats['direct_legal'] + stats['quarter_fix_successful']
        palindromic_claim = len(palindromic_witnesses) == legal_windows
        print(f"Claim: Palindromic witnesses for all legal windows")
        print(f"Legal windows: {legal_windows}, Witnesses: {len(palindromic_witnesses)}")
        print(f"Result: {'✓ VERIFIED' if palindromic_claim else '✗ FAILED'}")
        print()
        
        # Claim 3: W80 invariant validation
        w80_validations = processing_result['w80_validations']
        w80_pass_count = sum(1 for v in w80_validations if v)
        w80_claim = w80_pass_count == len(palindromic_witnesses)
        print(f"Claim: W80 invariant holds for palindromic witnesses")
        print(f"W80 validations passed: {w80_pass_count}/{len(palindromic_witnesses)}")
        print(f"Result: {'✓ VERIFIED' if w80_claim else '✗ FAILED'}")
        print()
        
        # Detailed window analysis
        print("DETAILED WINDOW ANALYSIS")
        print("-" * 30)
        
        for i, result in enumerate(processing_result['window_results'][:10]):  # Show first 10
            print(f"Window {i+1}: {result.window}")
            print(f"  Status: {result.legality_status.value}")
            if result.quarter_fix_applied:
                print(f"  Quarter-fixed: {result.quarter_fixed_window}")
            if result.palindromic_witness:
                print(f"  Palindromic witness: {result.palindromic_witness}")
                print(f"  W80 valid: {result.w80_validation}")
            if result.entropy_slot_type:
                print(f"  Entropy slot: {result.entropy_slot_type}")
            print()
        
        if len(processing_result['window_results']) > 10:
            print(f"... and {len(processing_result['window_results']) - 10} more windows")
            print()
        
        # Store results
        self.test_results['n4_superpermutation'] = {
            'superpermutation': superperm_str,
            'processing_result': processing_result,
            'claims_verified': {
                'ninety_percent_legality': claim_90_percent,
                'palindromic_witnesses': palindromic_claim,
                'w80_invariant': w80_claim
            },
            'overall_success': claim_90_percent and palindromic_claim and w80_claim
        }
        
        return self.test_results['n4_superpermutation']
    
    def test_perfect_rest_numbers(self) -> Dict[str, Any]:
        """Test framework on known perfect rest numbers."""
        print("TESTING PERFECT REST NUMBERS")
        print("-" * 40)
        
        # Test 1729 (Hardy-Ramanujan number)
        print("Testing 1729 (Hardy-Ramanujan number)")
        decomps_1729 = self.parent_identity.find_taxicab_decompositions(1729)
        print(f"Taxicab decompositions: {decomps_1729}")
        
        for a, b in decomps_1729:
            identity_result = self.parent_identity.apply_identity(a, b)
            print(f"  {a}³ + {b}³ = {a**3 + b**3}")
            print(f"  ({a} + {b}) × ({a}² - {a}×{b} + {b}²) = {identity_result.linear_factor} × {identity_result.quadratic_factor} = {identity_result.linear_factor * identity_result.quadratic_factor}")
            print(f"  Identity verified: {identity_result.identity_verified}")
            print()
        
        # Complementary partition analysis
        partition_analysis = self.parent_identity.analyze_complementary_partition(decomps_1729, 1729)
        print(f"Complementary partition analysis:")
        print(f"  Valid partitions: {partition_analysis['valid']}")
        print(f"  Perfect rest candidate: {partition_analysis['perfect_rest_candidate']}")
        print(f"  Prime factorization: {partition_analysis['prime_factorization']}")
        print()
        
        # Test 4104 (second Hardy-Ramanujan number)
        print("Testing 4104 (second Hardy-Ramanujan number)")
        decomps_4104 = self.parent_identity.find_taxicab_decompositions(4104)
        print(f"Taxicab decompositions: {decomps_4104}")
        
        partition_analysis_4104 = self.parent_identity.analyze_complementary_partition(decomps_4104, 4104)
        print(f"Complementary partition analysis:")
        print(f"  Valid partitions: {partition_analysis_4104['valid']}")
        print(f"  Perfect rest candidate: {partition_analysis_4104['perfect_rest_candidate']}")
        print(f"  Prime factorization: {partition_analysis_4104['prime_factorization']}")
        print()
        
        self.test_results['perfect_rest'] = {
            '1729': {
                'decompositions': decomps_1729,
                'partition_analysis': partition_analysis
            },
            '4104': {
                'decompositions': decomps_4104,
                'partition_analysis': partition_analysis_4104
            }
        }
        
        return self.test_results['perfect_rest']
    
    def test_n2_to_n32_dual_helix_extension(self) -> Dict[str, Any]:
        """Test n=2 to n=32 dual helix extension following framework rules."""
        print("TESTING n=2 → n=32 DUAL HELIX EXTENSION")
        print("=" * 50)
        
        # Step 1: Start with n=2 duality
        print("Step 1: Establishing n=2 duality foundation")
        n2_duality = (1, 2)  # Basic duality pair
        print(f"n=2 duality pair: {n2_duality}")
        
        # Verify parent identity for n=2 case
        a, b = n2_duality
        identity_result = self.parent_identity.apply_identity(a, b)
        print(f"Parent identity: {a}³ + {b}³ = {identity_result.linear_factor} × {identity_result.quadratic_factor}")
        print(f"Verification: {identity_result.identity_verified}")
        print()
        
        # Step 2: Expand to 16-fold duality
        print("Step 2: Expanding to 16-fold duality")
        helix_1 = []
        helix_2 = []
        
        # Create 16 elements for each helix based on n=2 duality
        for i in range(16):
            # Map i to duality-preserving elements
            # Use modular arithmetic to maintain duality relationships
            elem_1 = (a + i) % 8 + 1  # Keep in range 1-8
            elem_2 = (b + i) % 8 + 1  # Keep in range 1-8
            helix_1.append(elem_1)
            helix_2.append(elem_2)
        
        print(f"Helix 1 (16 elements): {helix_1}")
        print(f"Helix 2 (16 elements): {helix_2}")
        print()
        
        # Step 3: Create dual helix structure
        print("Step 3: Creating n=32 dual helix structure")
        dual_helix = helix_1 + helix_2
        print(f"Dual helix (32 elements): {dual_helix}")
        print(f"Length verification: {len(dual_helix)} elements")
        print()
        
        # Step 4: Validate dual bonds
        print("Step 4: Validating dual bonds")
        dual_bonds = []
        for i in range(16):
            bond = (helix_1[i], helix_2[i])
            dual_bonds.append(bond)
            
            # Test if bond preserves duality relationship
            bond_identity = self.parent_identity.apply_identity(bond[0], bond[1])
            print(f"Bond {i+1}: {bond} → Linear: {bond_identity.linear_factor}, Quadratic: {bond_identity.quadratic_factor}, Valid: {bond_identity.identity_verified}")
        
        print()
        
        # Step 5: Test framework rules on dual helix
        print("Step 5: Testing framework rules on dual helix structure")
        
        # Test quadratic rest processing
        print("Testing quadratic rest processing...")
        dual_helix_result = self.quadratic_rest.process_sequence(dual_helix, n_value=32)
        
        stats = dual_helix_result['statistics']
        print(f"Dual helix processing results:")
        print(f"  Total windows: {stats['total_windows']}")
        print(f"  Success rate: {stats['success_rate']:.1%}")
        print(f"  Direct legal: {stats['direct_legal']} ({stats['direct_legal_rate']:.1%})")
        print(f"  Quarter-fix: {stats['quarter_fix_successful']} ({stats['quarter_fix_rate']:.1%})")
        print(f"  Entropy slots: {stats['entropy_slot_routed']} ({stats['entropy_slot_rate']:.1%})")
        print()
        
        # Step 6: Validate palindromic constraints
        print("Step 6: Validating palindromic constraints")
        palindromic_witnesses = dual_helix_result['palindromic_witnesses']
        print(f"Palindromic witnesses generated: {len(palindromic_witnesses)}")
        
        # Test if dual helix itself can form palindromic structure
        dual_helix_palindrome = dual_helix + dual_helix[::-1]
        w80_valid = self.quadratic_rest.validate_w80_invariant(dual_helix_palindrome)
        print(f"Dual helix palindromic extension W80 valid: {w80_valid}")
        print()
        
        # Step 7: Test dimensional scaling compatibility
        print("Step 7: Testing dimensional scaling compatibility")
        # Simulate dimensional scaling test (simplified)
        dimensional_compatible = len(dual_helix) <= 4096  # Within framework limits
        print(f"Dimensional scaling compatible: {dimensional_compatible}")
        print(f"Dual helix size: {len(dual_helix)} ≤ 4096 (framework limit)")
        print()
        
        # Step 8: Overall validation
        print("Step 8: Overall n=32 dual helix validation")
        
        # Check all validation criteria
        validations = {
            'parent_identity_preserved': all(bond[2] for bond in [(b[0], b[1], self.parent_identity.apply_identity(b[0], b[1]).identity_verified) for b in dual_bonds]),
            'quadratic_rest_functional': stats['success_rate'] > 0.5,  # At least 50% success
            'palindromic_constraints_satisfied': len(palindromic_witnesses) > 0,
            'w80_invariant_holds': w80_valid,
            'dimensional_scaling_compatible': dimensional_compatible,
            'dual_bond_integrity': len(dual_bonds) == 16
        }
        
        overall_valid = all(validations.values())
        
        print("Validation results:")
        for criterion, result in validations.items():
            print(f"  {criterion}: {'✓ PASS' if result else '✗ FAIL'}")
        
        print()
        print(f"OVERALL n=32 DUAL HELIX EXTENSION: {'✓ LEGAL AND VALID' if overall_valid else '✗ INVALID'}")
        print()
        
        # Store results
        self.test_results['n32_dual_helix'] = {
            'n2_foundation': n2_duality,
            'helix_1': helix_1,
            'helix_2': helix_2,
            'dual_helix': dual_helix,
            'dual_bonds': dual_bonds,
            'processing_result': dual_helix_result,
            'validations': validations,
            'overall_valid': overall_valid
        }
        
        return self.test_results['n32_dual_helix']
    
    def generate_comprehensive_report(self) -> Dict[str, Any]:
        """Generate comprehensive test report."""
        print("COMPREHENSIVE FRAMEWORK TEST REPORT")
        print("=" * 60)
        
        # Summary of all tests
        n4_success = self.test_results.get('n4_superpermutation', {}).get('overall_success', False)
        n32_success = self.test_results.get('n32_dual_helix', {}).get('overall_valid', False)
        
        print("TEST SUMMARY:")
        print(f"  n=4 Superpermutation Analysis: {'✓ PASS' if n4_success else '✗ FAIL'}")
        print(f"  n=32 Dual Helix Extension: {'✓ PASS' if n32_success else '✗ FAIL'}")
        print()
        
        # Framework validation summary
        framework_validated = n4_success and n32_success
        print(f"OVERALL FRAMEWORK VALIDATION: {'✓ VERIFIED' if framework_validated else '✗ FAILED'}")
        print()
        
        if framework_validated:
            print("FRAMEWORK CAPABILITIES CONFIRMED:")
            print("  ✓ Quadratic rest hypothesis validated on real superpermutation")
            print("  ✓ >90% legality achieved through direct + quarter-fix operations")
            print("  ✓ Palindromic witness generation functional")
            print("  ✓ W80 invariant validation working")
            print("  ✓ n=2 → n=32 dual helix extension legal and functional")
            print("  ✓ Parent identity preserved across all operations")
            print("  ✓ Framework rules consistently applied")
            print()
            print("RECOMMENDATION: Framework ready for deployment and production use")
        else:
            print("ISSUES IDENTIFIED:")
            if not n4_success:
                print("  ✗ n=4 superpermutation analysis failed validation")
            if not n32_success:
                print("  ✗ n=32 dual helix extension failed validation")
            print()
            print("RECOMMENDATION: Address identified issues before deployment")
        
        return {
            'framework_validated': framework_validated,
            'n4_superpermutation_success': n4_success,
            'n32_dual_helix_success': n32_success,
            'all_test_results': self.test_results
        }


def main():
    """Main test execution."""
    print("QUADRATIC SHIFT DIMENSIONAL SPACE FRAMEWORK")
    print("COMPREHENSIVE VALIDATION TEST SUITE")
    print("=" * 80)
    print()
    
    # Initialize tester
    tester = FrameworkTester()
    
    # Run all tests
    try:
        # Test 1: n=4 superpermutation
        tester.test_n4_superpermutation()
        print()
        
        # Test 2: Perfect rest numbers
        tester.test_perfect_rest_numbers()
        print()
        
        # Test 3: n=32 dual helix extension
        tester.test_n2_to_n32_dual_helix_extension()
        print()
        
        # Generate comprehensive report
        final_report = tester.generate_comprehensive_report()
        
        # Return appropriate exit code
        return 0 if final_report['framework_validated'] else 1
        
    except Exception as e:
        print(f"ERROR during testing: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

