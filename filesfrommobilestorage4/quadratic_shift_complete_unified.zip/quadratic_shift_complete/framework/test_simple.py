#!/usr/bin/env python3
"""
Simplified Test Script: Direct Framework Testing

Tests the core framework components directly without complex imports.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from quadratic_shift.core.parent_identity import ParentIdentityEngine
from quadratic_shift.core.quadratic_rest import QuadraticRestProcessor, generate_n4_superpermutation


def test_framework():
    """Test the framework components directly."""
    print("QUADRATIC SHIFT FRAMEWORK - DIRECT COMPONENT TEST")
    print("=" * 60)
    
    # Initialize components
    parent_identity = ParentIdentityEngine()
    quadratic_rest = QuadraticRestProcessor()
    
    # Test 1: Parent Identity on 1729
    print("TEST 1: Parent Identity on 1729 (Hardy-Ramanujan number)")
    print("-" * 50)
    
    decomps = parent_identity.find_taxicab_decompositions(1729)
    print(f"Taxicab decompositions of 1729: {decomps}")
    
    for a, b in decomps:
        result = parent_identity.apply_identity(a, b)
        print(f"{a}³ + {b}³ = {a**3 + b**3}")
        print(f"({a} + {b}) × ({a}² - {a}×{b} + {b}²) = {result.linear_factor} × {result.quadratic_factor} = {result.linear_factor * result.quadratic_factor}")
        print(f"Identity verified: {result.identity_verified}")
        print()
    
    # Test 2: n=4 Superpermutation Processing
    print("TEST 2: n=4 Superpermutation Processing")
    print("-" * 40)
    
    superperm = generate_n4_superpermutation()
    sequence = [int(c) for c in superperm]
    
    print(f"n=4 Superpermutation: {superperm}")
    print(f"Length: {len(sequence)}")
    
    # Process through quadratic rest
    result = quadratic_rest.process_sequence(sequence, n_value=4)
    stats = result['statistics']
    
    print(f"\nProcessing Results:")
    print(f"Total windows: {stats['total_windows']}")
    print(f"Direct legal: {stats['direct_legal']} ({stats['direct_legal_rate']:.1%})")
    print(f"Quarter-fix: {stats['quarter_fix_successful']} ({stats['quarter_fix_rate']:.1%})")
    print(f"Entropy slots: {stats['entropy_slot_routed']} ({stats['entropy_slot_rate']:.1%})")
    print(f"Success rate: {stats['success_rate']:.1%}")
    
    # Check >90% claim
    combined_rate = stats['direct_legal_rate'] + stats['quarter_fix_rate']
    print(f"\nFramework Claim Test:")
    print(f"Combined success rate: {combined_rate:.1%}")
    print(f">90% legality claim: {'✓ VERIFIED' if combined_rate >= 0.90 else '✗ FAILED'}")
    
    # Test 3: Dual Helix Extension (Simplified)
    print("\nTEST 3: n=2 → n=32 Dual Helix Extension")
    print("-" * 45)
    
    # Create dual helix structure
    helix_1 = [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]  # 16 elements
    helix_2 = [2, 1, 4, 3, 2, 1, 4, 3, 2, 1, 4, 3, 2, 1, 4, 3]  # 16 complementary elements
    dual_helix = helix_1 + helix_2  # 32 elements total
    
    print(f"Dual helix structure (32 elements): {dual_helix}")
    print(f"Length verification: {len(dual_helix)}")
    
    # Test framework processing on dual helix
    dual_result = quadratic_rest.process_sequence(dual_helix, n_value=32)
    dual_stats = dual_result['statistics']
    
    print(f"\nDual Helix Processing:")
    print(f"Total windows: {dual_stats['total_windows']}")
    print(f"Success rate: {dual_stats['success_rate']:.1%}")
    print(f"Direct legal: {dual_stats['direct_legal']} ({dual_stats['direct_legal_rate']:.1%})")
    print(f"Quarter-fix: {dual_stats['quarter_fix_successful']} ({dual_stats['quarter_fix_rate']:.1%})")
    
    # Validate dual bonds
    print(f"\nDual Bond Validation:")
    valid_bonds = 0
    for i in range(16):
        bond_result = parent_identity.apply_identity(helix_1[i], helix_2[i])
        if bond_result.identity_verified:
            valid_bonds += 1
    
    print(f"Valid dual bonds: {valid_bonds}/16 ({valid_bonds/16:.1%})")
    
    # Overall Assessment
    print("\nOVERALL FRAMEWORK ASSESSMENT")
    print("=" * 40)
    
    n4_success = combined_rate >= 0.90
    dual_helix_functional = dual_stats['success_rate'] > 0.5
    bonds_valid = valid_bonds >= 12  # At least 75% of bonds valid
    
    print(f"n=4 Superpermutation (>90% legality): {'✓ PASS' if n4_success else '✗ FAIL'}")
    print(f"Dual Helix Processing (>50% success): {'✓ PASS' if dual_helix_functional else '✗ FAIL'}")
    print(f"Dual Bond Integrity (>75% valid): {'✓ PASS' if bonds_valid else '✗ FAIL'}")
    
    overall_success = n4_success and dual_helix_functional and bonds_valid
    print(f"\nFRAMEWORK VALIDATION: {'✓ SUCCESS' if overall_success else '✗ FAILED'}")
    
    if overall_success:
        print("\nFramework is ready for deployment!")
        print("Key capabilities verified:")
        print("- Quadratic rest processing functional")
        print("- Parent identity operations working")
        print("- n=32 dual helix extension viable")
        print("- Mathematical consistency maintained")
    
    return overall_success


if __name__ == "__main__":
    success = test_framework()
    sys.exit(0 if success else 1)

