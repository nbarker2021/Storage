#!/usr/bin/env python3
"""
Direct Framework Test - Bypassing Complex Imports

Tests framework components directly by importing only what we've implemented.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Direct imports of implemented components
from quadratic_shift.core.parent_identity import ParentIdentityEngine
from quadratic_shift.core.quadratic_rest import QuadraticRestProcessor, generate_n4_superpermutation


def main():
    """Main test execution."""
    print("QUADRATIC SHIFT FRAMEWORK - DIRECT VALIDATION TEST")
    print("=" * 70)
    print()
    
    # Initialize core components
    parent_engine = ParentIdentityEngine()
    quadratic_processor = QuadraticRestProcessor()
    
    print("COMPONENT INITIALIZATION: ✓ SUCCESS")
    print()
    
    # TEST 1: Validate Parent Identity on Known Cases
    print("TEST 1: PARENT IDENTITY VALIDATION")
    print("-" * 40)
    
    # Test on 1729 (Hardy-Ramanujan number)
    print("Testing 1729 (Hardy-Ramanujan number):")
    decomps_1729 = parent_engine.find_taxicab_decompositions(1729)
    print(f"Found decompositions: {decomps_1729}")
    
    identity_verified = True
    for a, b in decomps_1729:
        result = parent_engine.apply_identity(a, b)
        cube_sum = a**3 + b**3
        factored = result.linear_factor * result.quadratic_factor
        print(f"  {a}³ + {b}³ = {cube_sum}")
        print(f"  ({a}+{b}) × ({a}²-{a}×{b}+{b}²) = {result.linear_factor} × {result.quadratic_factor} = {factored}")
        print(f"  Identity verified: {result.identity_verified} (error: {result.numerical_error:.2e})")
        
        if not result.identity_verified:
            identity_verified = False
    
    print(f"\nParent Identity Test: {'✓ PASS' if identity_verified else '✗ FAIL'}")
    print()
    
    # TEST 2: n=4 Superpermutation Analysis
    print("TEST 2: n=4 SUPERPERMUTATION ANALYSIS")
    print("-" * 45)
    
    # Get the actual n=4 superpermutation
    superperm_string = generate_n4_superpermutation()
    superperm_sequence = [int(c) for c in superperm_string]
    
    print(f"n=4 Superpermutation: {superperm_string}")
    print(f"Sequence length: {len(superperm_sequence)}")
    print(f"Sequence: {superperm_sequence}")
    print()
    
    # Process through quadratic rest system
    print("Processing through Quadratic Rest System...")
    processing_result = quadratic_processor.process_sequence(superperm_sequence, n_value=4)
    
    # Extract statistics
    stats = processing_result['statistics']
    
    print(f"Processing Results:")
    print(f"  Total 4-windows extracted: {stats['total_windows']}")
    print(f"  Direct legal windows: {stats['direct_legal']} ({stats['direct_legal_rate']:.1%})")
    print(f"  Quarter-fix successful: {stats['quarter_fix_successful']} ({stats['quarter_fix_rate']:.1%})")
    print(f"  Entropy slot routed: {stats['entropy_slot_routed']} ({stats['entropy_slot_rate']:.1%})")
    print(f"  Overall success rate: {stats['success_rate']:.1%}")
    print()
    
    # Test framework claims
    combined_success = stats['direct_legal_rate'] + stats['quarter_fix_rate']
    claim_90_percent = combined_success >= 0.90
    
    print(f"Framework Claims Validation:")
    print(f"  Combined Direct+Quarter-fix rate: {combined_success:.1%}")
    print(f"  >90% legality claim: {'✓ VERIFIED' if claim_90_percent else '✗ FAILED'}")
    
    # Show some detailed window analysis
    print(f"\nDetailed Window Analysis (first 10 windows):")
    for i, window_result in enumerate(processing_result['window_results'][:10]):
        status_symbol = "✓" if window_result.legality_status.value in ['direct_legal', 'quarter_fix_legal'] else "✗"
        print(f"  Window {i+1}: {window_result.window} → {status_symbol} {window_result.legality_status.value}")
        if window_result.palindromic_witness:
            print(f"    Palindromic witness: {window_result.palindromic_witness}")
    
    print()
    
    # TEST 3: n=2 → n=32 Dual Helix Extension
    print("TEST 3: n=2 → n=32 DUAL HELIX EXTENSION")
    print("-" * 50)
    
    # Step 1: Establish n=2 foundation
    print("Step 1: n=2 Duality Foundation")
    n2_pair = (1, 2)
    n2_identity = parent_engine.apply_identity(n2_pair[0], n2_pair[1])
    print(f"  n=2 duality pair: {n2_pair}")
    print(f"  Parent identity verified: {n2_identity.identity_verified}")
    print()
    
    # Step 2: Create dual helix structure
    print("Step 2: Dual Helix Construction")
    
    # Create 16-element helices based on n=2 duality
    helix_1 = []
    helix_2 = []
    
    for i in range(16):
        # Use modular expansion to maintain duality relationships
        elem_1 = ((n2_pair[0] + i - 1) % 4) + 1  # Keep in range 1-4
        elem_2 = ((n2_pair[1] + i - 1) % 4) + 1  # Keep in range 1-4
        helix_1.append(elem_1)
        helix_2.append(elem_2)
    
    dual_helix_32 = helix_1 + helix_2
    
    print(f"  Helix 1 (16 elements): {helix_1}")
    print(f"  Helix 2 (16 elements): {helix_2}")
    print(f"  Dual helix (32 elements): {dual_helix_32}")
    print(f"  Length verification: {len(dual_helix_32)} elements")
    print()
    
    # Step 3: Validate dual bonds
    print("Step 3: Dual Bond Validation")
    valid_bonds = 0
    total_bonds = 16
    
    for i in range(total_bonds):
        bond_identity = parent_engine.apply_identity(helix_1[i], helix_2[i])
        if bond_identity.identity_verified:
            valid_bonds += 1
        print(f"  Bond {i+1}: ({helix_1[i]}, {helix_2[i]}) → {'✓' if bond_identity.identity_verified else '✗'}")
    
    bond_integrity = valid_bonds / total_bonds
    print(f"\n  Dual bond integrity: {valid_bonds}/{total_bonds} ({bond_integrity:.1%})")
    print()
    
    # Step 4: Test framework processing on dual helix
    print("Step 4: Framework Processing on Dual Helix")
    dual_helix_result = quadratic_processor.process_sequence(dual_helix_32, n_value=32)
    dual_stats = dual_helix_result['statistics']
    
    print(f"  Dual helix processing results:")
    print(f"    Total windows: {dual_stats['total_windows']}")
    print(f"    Success rate: {dual_stats['success_rate']:.1%}")
    print(f"    Direct legal: {dual_stats['direct_legal']} ({dual_stats['direct_legal_rate']:.1%})")
    print(f"    Quarter-fix: {dual_stats['quarter_fix_successful']} ({dual_stats['quarter_fix_rate']:.1%})")
    print(f"    Entropy slots: {dual_stats['entropy_slot_routed']} ({dual_stats['entropy_slot_rate']:.1%})")
    print()
    
    # Step 5: Validate palindromic constraints
    print("Step 5: Palindromic Constraint Validation")
    palindromic_witnesses = dual_helix_result['palindromic_witnesses']
    print(f"  Palindromic witnesses generated: {len(palindromic_witnesses)}")
    
    # Test dual helix palindromic extension
    dual_helix_palindrome = dual_helix_32 + dual_helix_32[::-1]
    w80_valid = quadratic_processor.validate_w80_invariant(dual_helix_palindrome)
    print(f"  Dual helix palindromic W80 validation: {'✓ PASS' if w80_valid else '✗ FAIL'}")
    print()
    
    # FINAL VALIDATION
    print("FINAL FRAMEWORK VALIDATION")
    print("=" * 40)
    
    # Validation criteria
    validations = {
        'parent_identity_functional': identity_verified,
        'n4_superpermutation_90_percent': claim_90_percent,
        'dual_helix_construction_valid': len(dual_helix_32) == 32,
        'dual_bond_integrity_sufficient': bond_integrity >= 0.75,  # At least 75%
        'dual_helix_processing_functional': dual_stats['success_rate'] > 0.5,  # At least 50%
        'palindromic_constraints_satisfied': len(palindromic_witnesses) > 0
    }
    
    print("Validation Results:")
    for criterion, result in validations.items():
        print(f"  {criterion}: {'✓ PASS' if result else '✗ FAIL'}")
    
    overall_success = all(validations.values())
    
    print()
    print(f"OVERALL FRAMEWORK VALIDATION: {'✓ SUCCESS' if overall_success else '✗ FAILED'}")
    print()
    
    if overall_success:
        print("🎉 FRAMEWORK VALIDATION SUCCESSFUL! 🎉")
        print()
        print("Key Achievements:")
        print("✓ Parent identity a³ + b³ = (a+b)(a² - ab + b²) verified")
        print("✓ n=4 superpermutation achieves >90% legality via direct + quarter-fix")
        print("✓ Quadratic rest hypothesis validated on real data")
        print("✓ n=2 → n=32 dual helix extension is mathematically legal")
        print("✓ Dual bond structure maintains parent identity relationships")
        print("✓ Framework rules consistently applied across all scales")
        print("✓ Palindromic witness generation functional")
        print()
        print("RECOMMENDATION: Framework is ready for full deployment!")
        
        # Generate deployment summary
        deployment_stats = {
            'n4_superpermutation_success_rate': stats['success_rate'],
            'n4_combined_legality_rate': combined_success,
            'dual_helix_success_rate': dual_stats['success_rate'],
            'dual_bond_integrity': bond_integrity,
            'total_windows_tested': stats['total_windows'] + dual_stats['total_windows'],
            'palindromic_witnesses_generated': len(processing_result['palindromic_witnesses']) + len(palindromic_witnesses)
        }
        
        print("\nDeployment Statistics:")
        for key, value in deployment_stats.items():
            if isinstance(value, float):
                print(f"  {key}: {value:.1%}" if value <= 1.0 else f"  {key}: {value:.2f}")
            else:
                print(f"  {key}: {value}")
    
    else:
        print("❌ FRAMEWORK VALIDATION FAILED")
        print()
        print("Issues identified:")
        for criterion, result in validations.items():
            if not result:
                print(f"✗ {criterion}")
        print()
        print("RECOMMENDATION: Address identified issues before deployment")
    
    return overall_success


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

