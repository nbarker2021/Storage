#!/usr/bin/env python3
"""
Setup script for the Quadratic Shift Dimensional Space Framework.

This package provides a complete implementation of the Quadratic Shift
Dimensional Space Framework - a universal algebraic operating system
for mathematical computation and information processing.
"""

from setuptools import setup, find_packages
import os

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="quadratic-shift-framework",
    version="1.0.0",
    author="Framework Development Team",
    author_email="dev@quadratic-shift-framework.org",
    description="Universal Algebraic Operating System for Mathematical Computation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/quadratic-shift-framework",
    project_urls={
        "Bug Tracker": "https://github.com/your-org/quadratic-shift-framework/issues",
        "Documentation": "https://quadratic-shift-framework.readthedocs.io",
        "Source Code": "https://github.com/your-org/quadratic-shift-framework",
    },
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "quantum": ["qiskit>=0.30.0", "cirq>=0.12.0"],
        "gpu": ["cupy>=9.0.0"],
        "distributed": ["dask>=2021.6.0", "ray>=1.4.0"],
        "dev": [
            "black>=21.6.0",
            "flake8>=3.9.0",
            "mypy>=0.910",
            "pre-commit>=2.13.0",
            "pytest>=6.2.0",
            "pytest-cov>=2.12.0",
            "pytest-benchmark>=3.4.0",
        ],
        "docs": [
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=0.5.0",
            "nbsphinx>=0.8.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "qsf-validate=quadratic_shift.tools.validation_suite:main",
            "qsf-benchmark=quadratic_shift.tools.performance_profiler:main",
            "qsf-analyze=quadratic_shift.tools.analysis_tool:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords=[
        "mathematics",
        "algebra",
        "dimensional-analysis",
        "entropy",
        "thermodynamics",
        "quantum-computing",
        "machine-learning",
        "optimization",
        "palindromic-structures",
        "universal-computation",
    ],
)

