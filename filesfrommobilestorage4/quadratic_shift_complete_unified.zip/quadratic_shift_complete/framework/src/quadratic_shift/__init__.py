"""
Quadratic Shift Dimensional Space Framework

A universal algebraic operating system for mathematical computation and information processing.

This package provides a complete implementation of the Quadratic Shift Dimensional Space Framework,
based on the parent identity: a³ + b³ = (a+b)(a² - ab + b²)

Key Features:
- Universal algebraic operations across all mathematical fields
- Dimensional scaling from 11D to 4096D+ with observer-dependent optimization
- Entropy management with thermodynamic consistency
- Perfect rest state identification and palindromic witness generation
- Cross-domain applicability for any data type or problem domain

Example Usage:
    >>> from quadratic_shift import QuadraticShiftFramework
    >>> framework = QuadraticShiftFramework()
    >>> result = framework.process_sequence([1, 2, 3, 4, 1, 2, 3, 4])
    >>> perfect_rest = framework.analyze_perfect_rest(1729)
"""

__version__ = "1.0.0"
__author__ = "Framework Development Team"
__email__ = "dev@quadratic-shift-framework.org"
__license__ = "MIT"

# Core imports for easy access
from .core.parent_identity import ParentIdentityEngine
from .core.quadratic_rest import QuadraticRestProcessor
from .core.perfect_rest import PerfectRestValidator

from .operations.window_processor import WindowProcessor
from .operations.quarter_fix import QuarterFixProcessor
from .operations.palindromic_mirror import PalindromicMirrorGenerator

from .gates.core_gates import CoreGateSystem
from .gates.cyclotomic_gates import CyclotomicGateSystem
from .gates.gate_coordinator import GateCoordinator

from .dimensional.rest_point_selector import RestPointSelector
from .dimensional.dimensional_transfer import DimensionalTransferSystem
from .dimensional.scaling_manager import DimensionalScalingManager

from .entropy.uvibs_entropy import UVIBSEntropySystem
from .entropy.entropy_slots import EntropySlotManager
from .entropy.manifold_manager import EntropyManifoldManager

from .implementation.niqas_core import NIQASCore
from .implementation.uvibs_system import UVIBSSystem
from .implementation.system_integrator import SystemIntegrator

# Main framework class
class QuadraticShiftFramework:
    """
    Main interface to the Quadratic Shift Dimensional Space Framework.
    
    This class provides a unified interface to all framework components,
    enabling easy access to the complete system functionality.
    
    Attributes:
        parent_identity (ParentIdentityEngine): Core algebraic relationship engine
        quadratic_rest (QuadraticRestProcessor): Quadratic rest processing
        perfect_rest (PerfectRestValidator): Perfect rest state validation
        window_processor (WindowProcessor): 4-window processing system
        quarter_fix (QuarterFixProcessor): Quarter-fix repair system
        palindromic_mirror (PalindromicMirrorGenerator): Palindromic structure generator
        gate_coordinator (GateCoordinator): Gate system coordination
        dimensional_manager (DimensionalScalingManager): Dimensional scaling management
        entropy_system (UVIBSEntropySystem): Entropy management system
        niqas_core (NIQASCore): NIQAS quadratic algebra core
        uvibs_system (UVIBSSystem): UVIBS 8-bucket architecture
        system_integrator (SystemIntegrator): System integration coordination
    
    Example:
        >>> framework = QuadraticShiftFramework()
        >>> # Process a sequence
        >>> result = framework.process_sequence([1, 2, 3, 4])
        >>> # Analyze perfect rest properties
        >>> analysis = framework.analyze_perfect_rest(1729)
        >>> # Perform dimensional scaling
        >>> scaled = framework.dimensional_transfer(data, target_dimension=64)
    """
    
    def __init__(self, config=None):
        """
        Initialize the Quadratic Shift Framework.
        
        Args:
            config (dict, optional): Configuration parameters for framework components.
                Default configuration will be used if not provided.
        """
        self.config = config or self._default_config()
        
        # Initialize core mathematical components
        self.parent_identity = ParentIdentityEngine(self.config.get('parent_identity', {}))
        self.quadratic_rest = QuadraticRestProcessor(self.config.get('quadratic_rest', {}))
        self.perfect_rest = PerfectRestValidator(self.config.get('perfect_rest', {}))
        
        # Initialize operational processing components
        self.window_processor = WindowProcessor(self.config.get('window_processor', {}))
        self.quarter_fix = QuarterFixProcessor(self.config.get('quarter_fix', {}))
        self.palindromic_mirror = PalindromicMirrorGenerator(self.config.get('palindromic_mirror', {}))
        
        # Initialize gate coordination system
        self.gate_coordinator = GateCoordinator(self.config.get('gate_coordinator', {}))
        
        # Initialize dimensional management
        self.dimensional_manager = DimensionalScalingManager(self.config.get('dimensional_manager', {}))
        
        # Initialize entropy management
        self.entropy_system = UVIBSEntropySystem(self.config.get('entropy_system', {}))
        
        # Initialize implementation systems
        self.niqas_core = NIQASCore(self.config.get('niqas_core', {}))
        self.uvibs_system = UVIBSSystem(self.config.get('uvibs_system', {}))
        
        # Initialize system integration
        self.system_integrator = SystemIntegrator(
            niqas_core=self.niqas_core,
            uvibs_system=self.uvibs_system,
            config=self.config.get('system_integrator', {})
        )
        
        # Validate system integration
        self._validate_system_integration()
    
    def _default_config(self):
        """Return default configuration for the framework."""
        return {
            'dimensional_range': {'min': 11, 'max': 4096, 'entropy_exception_max': 4100},
            'precision': {'numerical': 1e-15, 'validation': 1e-12},
            'performance': {'parallel_processing': True, 'gpu_acceleration': False},
            'validation': {'strict_mode': True, 'continuous_validation': True},
            'entropy': {'conservation_tolerance': 1e-12, 'thermodynamic_consistency': True},
        }
    
    def _validate_system_integration(self):
        """Validate that all system components are properly integrated."""
        # Perform basic integration validation
        validation_results = self.system_integrator.validate_integration()
        if not validation_results['success']:
            raise RuntimeError(f"System integration validation failed: {validation_results['errors']}")
    
    def process_sequence(self, data, context=None, work_stance=None):
        """
        Process a data sequence using the complete framework.
        
        This is the main entry point for framework processing, applying the complete
        pipeline of operations including 4-window processing, gate coordination,
        dimensional scaling, and entropy management.
        
        Args:
            data: Input data sequence (list, numpy array, or any iterable)
            context (str, optional): Observational context for rest point selection
            work_stance (str, optional): Work stance for operational optimization
        
        Returns:
            dict: Complete processing results including:
                - processed_data: Final processed sequence
                - palindromic_witnesses: Generated palindromic structures
                - entropy_analysis: Entropy management results
                - dimensional_info: Dimensional scaling information
                - validation_results: Processing validation results
        
        Example:
            >>> framework = QuadraticShiftFramework()
            >>> result = framework.process_sequence([1, 2, 3, 4, 1, 2, 3, 4])
            >>> print(result['processed_data'])
            >>> print(result['palindromic_witnesses'])
        """
        return self.system_integrator.process_sequence(
            data=data,
            context=context,
            work_stance=work_stance
        )
    
    def analyze_perfect_rest(self, number):
        """
        Analyze a number for perfect rest properties.
        
        Performs complete analysis including taxicab decomposition identification,
        factorization analysis, complementary partition validation, and single-move
        palindromic witness testing.
        
        Args:
            number (int): Number to analyze for perfect rest properties
        
        Returns:
            dict: Complete perfect rest analysis including:
                - is_perfect_rest: Boolean indicating perfect rest status
                - taxicab_decompositions: List of cube sum decompositions
                - factorization: Prime factorization analysis
                - complementary_partitions: Complementary partition structure
                - palindromic_witnesses: Single-move palindromic witnesses
                - dimensional_access: 10-dimensional navigational access validation
        
        Example:
            >>> framework = QuadraticShiftFramework()
            >>> analysis = framework.analyze_perfect_rest(1729)
            >>> print(f"Is perfect rest: {analysis['is_perfect_rest']}")
            >>> print(f"Decompositions: {analysis['taxicab_decompositions']}")
        """
        return self.perfect_rest.analyze_perfect_rest(number)
    
    def dimensional_transfer(self, data, target_dimension, preserve_structure=True):
        """
        Perform dimensional transfer with round-trip isometry preservation.
        
        Transfers data between dimensional spaces while preserving quadratic
        content and maintaining mathematical structure integrity.
        
        Args:
            data: Input data for dimensional transfer
            target_dimension (int): Target dimensional space (11-4096+)
            preserve_structure (bool): Whether to preserve mathematical structure
        
        Returns:
            dict: Dimensional transfer results including:
                - transferred_data: Data in target dimensional space
                - transfer_metadata: Information for reverse transfer
                - isometry_validation: Round-trip accuracy validation
                - quadratic_preservation: Quadratic form preservation results
        
        Example:
            >>> framework = QuadraticShiftFramework()
            >>> result = framework.dimensional_transfer(data, target_dimension=64)
            >>> transferred = result['transferred_data']
        """
        return self.dimensional_manager.dimensional_transfer(
            data=data,
            target_dimension=target_dimension,
            preserve_structure=preserve_structure
        )
    
    def entropy_analysis(self, data, operation_sequence=None):
        """
        Perform comprehensive entropy analysis using UVIBS entropy law.
        
        Analyzes entropy properties, calculates thermodynamic consistency,
        and provides entropy management recommendations.
        
        Args:
            data: Input data for entropy analysis
            operation_sequence (list, optional): Sequence of operations for analysis
        
        Returns:
            dict: Entropy analysis results including:
                - entropy_value: Calculated entropy using UVIBS law
                - thermodynamic_consistency: Crooks ratio validation
                - entropy_slots: Entropy slot classification results
                - manifold_analysis: Global entropy manifold analysis
                - conservation_validation: Entropy conservation validation
        
        Example:
            >>> framework = QuadraticShiftFramework()
            >>> entropy_result = framework.entropy_analysis(data)
            >>> print(f"Entropy: {entropy_result['entropy_value']}")
        """
        return self.entropy_system.analyze_entropy(
            data=data,
            operation_sequence=operation_sequence
        )
    
    def validate_system(self, comprehensive=False):
        """
        Validate the complete framework system.
        
        Performs system-wide validation including mathematical consistency,
        operational integrity, and performance validation.
        
        Args:
            comprehensive (bool): Whether to perform comprehensive validation
        
        Returns:
            dict: System validation results including:
                - overall_status: Overall system health status
                - component_status: Individual component validation results
                - integration_status: System integration validation
                - performance_metrics: System performance measurements
                - recommendations: System optimization recommendations
        
        Example:
            >>> framework = QuadraticShiftFramework()
            >>> validation = framework.validate_system(comprehensive=True)
            >>> print(f"System status: {validation['overall_status']}")
        """
        return self.system_integrator.validate_system(comprehensive=comprehensive)

# Convenience imports for direct access to key functionality
__all__ = [
    'QuadraticShiftFramework',
    'ParentIdentityEngine',
    'QuadraticRestProcessor',
    'PerfectRestValidator',
    'WindowProcessor',
    'QuarterFixProcessor',
    'PalindromicMirrorGenerator',
    'CoreGateSystem',
    'CyclotomicGateSystem',
    'GateCoordinator',
    'RestPointSelector',
    'DimensionalTransferSystem',
    'DimensionalScalingManager',
    'UVIBSEntropySystem',
    'EntropySlotManager',
    'EntropyManifoldManager',
    'NIQASCore',
    'UVIBSSystem',
    'SystemIntegrator',
]

