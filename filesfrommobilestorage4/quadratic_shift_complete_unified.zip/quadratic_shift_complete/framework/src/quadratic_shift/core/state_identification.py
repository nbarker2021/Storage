"""
State Identification System - WHEN vs WHAT Distinction

Implements the fundamental framework principle that the system identifies
WHEN you're in a desired state (not WHAT's in that state). This distinction
is crucial for understanding framework operations and success criteria.
"""

import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


class StateType(Enum):
    """Types of states that can be identified by the framework."""
    DIRECT_LEGAL = "direct_legal"
    QUARTER_FIX_LEGAL = "quarter_fix_legal"
    ENTROPY_SLOT_ROUTED = "entropy_slot_routed"
    PALINDROMIC_WITNESS_AVAILABLE = "palindromic_witness_available"
    PERFECT_REST_CANDIDATE = "perfect_rest_candidate"
    DIMENSIONAL_TRANSFER_READY = "dimensional_transfer_ready"
    CROSS_DOMAIN_BRIDGE_ACTIVE = "cross_domain_bridge_active"
    UNKNOWN_STATE = "unknown_state"


class StateIdentificationConfidence(Enum):
    """Confidence levels for state identification."""
    CERTAIN = "certain"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNCERTAIN = "uncertain"


@dataclass
class StateIdentification:
    """Complete state identification result."""
    state_type: StateType
    identification_time: datetime
    position: Optional[int]
    confidence: StateIdentificationConfidence
    context_dependent_properties: Dict[str, Any]
    content_independent_markers: List[str]
    framework_signatures: Dict[str, Any]
    reachability_proof: Optional[Dict[str, Any]]
    directional_access_paths: List[str]
    observer_context: str
    work_stance: str


class StateIdentificationSystem:
    """
    Core system for identifying WHEN states occur (not WHAT's in them).
    
    This system implements the fundamental framework principle that:
    1. Framework identifies WHEN you're in desired states
    2. Other systems define WHAT's in those states
    3. State identification is content-independent but context-dependent
    4. Multiple directional access paths can identify the same state
    5. Reachability proof is more important than universal success
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the State Identification System.
        
        Args:
            config: Configuration parameters including:
                - identification_sensitivity: Sensitivity for state detection (default: 0.7)
                - content_independence: Degree of content independence (default: 0.9)
                - context_dependency: Degree of context dependency (default: 0.8)
                - reachability_threshold: Threshold for reachability proof (default: 0.6)
        """
        self.config = config or {}
        self.identification_sensitivity = self.config.get('identification_sensitivity', 0.7)
        self.content_independence = self.config.get('content_independence', 0.9)
        self.context_dependency = self.config.get('context_dependency', 0.8)
        self.reachability_threshold = self.config.get('reachability_threshold', 0.6)
        
        # State identification patterns
        self.state_patterns = self._initialize_state_patterns()
        
        # Content-independent markers
        self.content_independent_markers = self._initialize_content_independent_markers()
        
        # Framework signatures for each state type
        self.framework_signatures = self._initialize_framework_signatures()
        
        # Statistics tracking
        self.stats = {
            'states_identified': 0,
            'reachability_proofs_found': 0,
            'content_independent_identifications': 0,
            'context_dependent_variations': 0,
            'directional_access_successes': 0
        }
    
    def _initialize_state_patterns(self) -> Dict[StateType, Dict[str, Any]]:
        """Initialize patterns for identifying different state types."""
        return {
            StateType.DIRECT_LEGAL: {
                'mathematical_signature': 'sum_mod_4_zero_and_parity_match',
                'identification_method': 'direct_legality_test',
                'confidence_factors': ['mathematical_consistency', 'algebraic_verification'],
                'content_independence': 0.95,
                'context_sensitivity': 0.3
            },
            StateType.QUARTER_FIX_LEGAL: {
                'mathematical_signature': 'quarter_fix_transformation_legal',
                'identification_method': 'quarter_fix_then_legality_test',
                'confidence_factors': ['transformation_success', 'post_transform_legality'],
                'content_independence': 0.9,
                'context_sensitivity': 0.4
            },
            StateType.ENTROPY_SLOT_ROUTED: {
                'mathematical_signature': 'entropy_slot_pattern_match',
                'identification_method': 'entropy_slot_classification',
                'confidence_factors': ['pattern_recognition', 'thermodynamic_consistency'],
                'content_independence': 0.8,
                'context_sensitivity': 0.7
            },
            StateType.PALINDROMIC_WITNESS_AVAILABLE: {
                'mathematical_signature': 'palindromic_extension_possible',
                'identification_method': 'palindromic_witness_generation',
                'confidence_factors': ['symmetry_potential', 'w80_validation'],
                'content_independence': 0.85,
                'context_sensitivity': 0.6
            },
            StateType.PERFECT_REST_CANDIDATE: {
                'mathematical_signature': 'taxicab_decomposition_available',
                'identification_method': 'perfect_rest_analysis',
                'confidence_factors': ['multiple_decompositions', 'complementary_partitions'],
                'content_independence': 0.99,
                'context_sensitivity': 0.2
            },
            StateType.DIMENSIONAL_TRANSFER_READY: {
                'mathematical_signature': 'dimensional_scaling_compatible',
                'identification_method': 'dimensional_transfer_test',
                'confidence_factors': ['scaling_consistency', 'isometry_preservation'],
                'content_independence': 0.75,
                'context_sensitivity': 0.8
            },
            StateType.CROSS_DOMAIN_BRIDGE_ACTIVE: {
                'mathematical_signature': 'universal_mapping_available',
                'identification_method': 'cross_domain_bridge_test',
                'confidence_factors': ['universal_consistency', 'domain_translation'],
                'content_independence': 0.7,
                'context_sensitivity': 0.9
            }
        }
    
    def _initialize_content_independent_markers(self) -> Dict[StateType, List[str]]:
        """Initialize content-independent markers for each state type."""
        return {
            StateType.DIRECT_LEGAL: [
                'mathematical_legality_achieved',
                'quadratic_rest_confirmed',
                'algebraic_consistency_verified'
            ],
            StateType.QUARTER_FIX_LEGAL: [
                'transformation_repair_successful',
                'post_repair_legality_confirmed',
                'quarter_fix_pattern_recognized'
            ],
            StateType.ENTROPY_SLOT_ROUTED: [
                'entropy_classification_successful',
                'thermodynamic_pathway_identified',
                'entropy_slot_pattern_matched'
            ],
            StateType.PALINDROMIC_WITNESS_AVAILABLE: [
                'palindromic_extension_generated',
                'symmetry_structure_identified',
                'w80_invariant_satisfied'
            ],
            StateType.PERFECT_REST_CANDIDATE: [
                'taxicab_decomposition_found',
                'complementary_partition_verified',
                'perfect_rest_signature_detected'
            ],
            StateType.DIMENSIONAL_TRANSFER_READY: [
                'dimensional_compatibility_confirmed',
                'scaling_parameters_identified',
                'transfer_readiness_verified'
            ],
            StateType.CROSS_DOMAIN_BRIDGE_ACTIVE: [
                'universal_mapping_established',
                'cross_domain_consistency_verified',
                'bridge_activation_confirmed'
            ]
        }
    
    def _initialize_framework_signatures(self) -> Dict[StateType, Dict[str, Any]]:
        """Initialize framework-specific signatures for state identification."""
        return {
            StateType.DIRECT_LEGAL: {
                'parent_identity_applicable': True,
                'quadratic_reduction_possible': True,
                'palindromic_witness_generatable': True,
                'entropy_conservation_maintained': True
            },
            StateType.QUARTER_FIX_LEGAL: {
                'transformation_preserves_structure': True,
                'post_transform_parent_identity_applicable': True,
                'repair_mechanism_functional': True,
                'legality_achievable_through_repair': True
            },
            StateType.ENTROPY_SLOT_ROUTED: {
                'entropy_slot_classification_available': True,
                'thermodynamic_consistency_maintainable': True,
                'uvibs_processing_applicable': True,
                'entropy_pathway_identified': True
            },
            StateType.PALINDROMIC_WITNESS_AVAILABLE: {
                'palindromic_mirror_generatable': True,
                'w80_invariant_testable': True,
                'symmetry_structure_identifiable': True,
                'single_move_reachability_possible': True
            },
            StateType.PERFECT_REST_CANDIDATE: {
                'taxicab_decomposition_discoverable': True,
                'complementary_partition_analyzable': True,
                'single_move_palindromic_witness_achievable': True,
                'ten_dimensional_access_available': True
            },
            StateType.DIMENSIONAL_TRANSFER_READY: {
                'dimensional_scaling_applicable': True,
                'observer_dependent_rest_point_selectable': True,
                'round_trip_isometry_preservable': True,
                'quadratic_content_maintainable': True
            },
            StateType.CROSS_DOMAIN_BRIDGE_ACTIVE: {
                'universal_token_generation_possible': True,
                'cross_domain_mapping_establishable': True,
                'field_agnostic_operations_applicable': True,
                'universal_consistency_maintainable': True
            }
        }
    
    def identify_state(self, data: Any, 
                      processing_result: Dict[str, Any],
                      observer_context: str,
                      work_stance: str,
                      position: Optional[int] = None) -> StateIdentification:
        """
        Identify WHEN a state occurs based on framework signatures.
        
        This is the core method that implements the WHEN vs WHAT distinction.
        
        Args:
            data: Input data (content - but identification is content-independent)
            processing_result: Result from framework processing
            observer_context: Observer context for identification
            work_stance: Work stance for identification
            position: Position in sequence (if applicable)
            
        Returns:
            Complete state identification with WHEN information
        """
        # Determine state type based on processing result
        state_type = self._determine_state_type(processing_result)
        
        # Calculate identification confidence
        confidence = self._calculate_identification_confidence(
            state_type, processing_result, data
        )
        
        # Extract content-independent markers
        content_independent_markers = self._extract_content_independent_markers(
            state_type, processing_result
        )
        
        # Get framework signatures
        framework_signatures = self.framework_signatures.get(state_type, {})
        
        # Generate reachability proof if applicable
        reachability_proof = self._generate_reachability_proof(
            state_type, processing_result, data
        )
        
        # Identify directional access paths
        directional_access_paths = self._identify_directional_access_paths(
            state_type, processing_result
        )
        
        # Create context-dependent properties (WHEN-focused)
        context_dependent_properties = {
            'identification_context': observer_context,
            'work_stance_influence': work_stance,
            'temporal_markers': {
                'when_identified': datetime.now(),
                'processing_phase': 'state_identification',
                'framework_operation_stage': 'post_processing'
            },
            'state_occurrence_indicators': {
                'framework_recognized_pattern': True,
                'mathematical_signature_matched': True,
                'content_independent_identification': True
            }
        }
        
        # Update statistics
        self.stats['states_identified'] += 1
        if reachability_proof:
            self.stats['reachability_proofs_found'] += 1
        if confidence in [StateIdentificationConfidence.CERTAIN, StateIdentificationConfidence.HIGH]:
            self.stats['content_independent_identifications'] += 1
        self.stats['directional_access_successes'] += len(directional_access_paths)
        
        return StateIdentification(
            state_type=state_type,
            identification_time=datetime.now(),
            position=position,
            confidence=confidence,
            context_dependent_properties=context_dependent_properties,
            content_independent_markers=content_independent_markers,
            framework_signatures=framework_signatures,
            reachability_proof=reachability_proof,
            directional_access_paths=directional_access_paths,
            observer_context=observer_context,
            work_stance=work_stance
        )
    
    def _determine_state_type(self, processing_result: Dict[str, Any]) -> StateType:
        """Determine state type from processing result."""
        
        # Check for direct legality
        if processing_result.get('direct_legal', False):
            return StateType.DIRECT_LEGAL
        
        # Check for quarter-fix legality
        if processing_result.get('quarter_fix_successful', False):
            return StateType.QUARTER_FIX_LEGAL
        
        # Check for entropy slot routing
        if processing_result.get('entropy_slot_type'):
            return StateType.ENTROPY_SLOT_ROUTED
        
        # Check for palindromic witness availability
        if processing_result.get('palindromic_witness'):
            return StateType.PALINDROMIC_WITNESS_AVAILABLE
        
        # Check for perfect rest candidate
        if processing_result.get('taxicab_decompositions'):
            return StateType.PERFECT_REST_CANDIDATE
        
        # Check for dimensional transfer readiness
        if processing_result.get('dimensional_transfer_ready', False):
            return StateType.DIMENSIONAL_TRANSFER_READY
        
        # Check for cross-domain bridge activation
        if processing_result.get('cross_domain_bridge_active', False):
            return StateType.CROSS_DOMAIN_BRIDGE_ACTIVE
        
        return StateType.UNKNOWN_STATE
    
    def _calculate_identification_confidence(self, state_type: StateType, 
                                           processing_result: Dict[str, Any],
                                           data: Any) -> StateIdentificationConfidence:
        """Calculate confidence level for state identification."""
        
        if state_type == StateType.UNKNOWN_STATE:
            return StateIdentificationConfidence.UNCERTAIN
        
        pattern = self.state_patterns.get(state_type, {})
        confidence_factors = pattern.get('confidence_factors', [])
        
        # Calculate confidence based on multiple factors
        confidence_score = 0.0
        total_factors = len(confidence_factors)
        
        for factor in confidence_factors:
            if factor == 'mathematical_consistency':
                if processing_result.get('mathematical_consistency', False):
                    confidence_score += 1.0
            elif factor == 'algebraic_verification':
                if processing_result.get('identity_verified', False):
                    confidence_score += 1.0
            elif factor == 'transformation_success':
                if processing_result.get('quarter_fix_applied', False):
                    confidence_score += 1.0
            elif factor == 'pattern_recognition':
                if processing_result.get('entropy_slot_type'):
                    confidence_score += 1.0
            elif factor == 'symmetry_potential':
                if processing_result.get('palindromic_witness'):
                    confidence_score += 1.0
            elif factor == 'w80_validation':
                if processing_result.get('w80_validation', False):
                    confidence_score += 1.0
            # Add more factor evaluations as needed
        
        # Normalize confidence score
        if total_factors > 0:
            normalized_confidence = confidence_score / total_factors
        else:
            normalized_confidence = 0.5  # Default medium confidence
        
        # Map to confidence levels
        if normalized_confidence >= 0.9:
            return StateIdentificationConfidence.CERTAIN
        elif normalized_confidence >= 0.7:
            return StateIdentificationConfidence.HIGH
        elif normalized_confidence >= 0.5:
            return StateIdentificationConfidence.MEDIUM
        elif normalized_confidence >= 0.3:
            return StateIdentificationConfidence.LOW
        else:
            return StateIdentificationConfidence.UNCERTAIN
    
    def _extract_content_independent_markers(self, state_type: StateType,
                                           processing_result: Dict[str, Any]) -> List[str]:
        """Extract content-independent markers for the identified state."""
        
        base_markers = self.content_independent_markers.get(state_type, [])
        extracted_markers = []
        
        for marker in base_markers:
            # Check if marker conditions are met in processing result
            if marker == 'mathematical_legality_achieved':
                if processing_result.get('direct_legal', False):
                    extracted_markers.append(marker)
            elif marker == 'transformation_repair_successful':
                if processing_result.get('quarter_fix_successful', False):
                    extracted_markers.append(marker)
            elif marker == 'entropy_classification_successful':
                if processing_result.get('entropy_slot_type'):
                    extracted_markers.append(marker)
            elif marker == 'palindromic_extension_generated':
                if processing_result.get('palindromic_witness'):
                    extracted_markers.append(marker)
            elif marker == 'taxicab_decomposition_found':
                if processing_result.get('taxicab_decompositions'):
                    extracted_markers.append(marker)
            # Add more marker extractions as needed
        
        return extracted_markers
    
    def _generate_reachability_proof(self, state_type: StateType,
                                   processing_result: Dict[str, Any],
                                   data: Any) -> Optional[Dict[str, Any]]:
        """
        Generate reachability proof for the identified state.
        
        This is crucial: finding ANY palindromic witness proves reachability.
        """
        
        reachability_proof = None
        
        if state_type == StateType.PALINDROMIC_WITNESS_AVAILABLE:
            witness = processing_result.get('palindromic_witness')
            if witness:
                reachability_proof = {
                    'proof_type': 'palindromic_witness_existence',
                    'witness': witness,
                    'reachability_demonstrated': True,
                    'proof_strength': 'definitive',
                    'explanation': 'Palindromic witness found - proves state is reachable'
                }
        
        elif state_type == StateType.DIRECT_LEGAL:
            reachability_proof = {
                'proof_type': 'direct_mathematical_legality',
                'legality_confirmed': True,
                'reachability_demonstrated': True,
                'proof_strength': 'strong',
                'explanation': 'Direct legality achieved - state is immediately reachable'
            }
        
        elif state_type == StateType.QUARTER_FIX_LEGAL:
            reachability_proof = {
                'proof_type': 'transformation_based_reachability',
                'transformation_successful': True,
                'reachability_demonstrated': True,
                'proof_strength': 'strong',
                'explanation': 'Quarter-fix transformation successful - state reachable via repair'
            }
        
        elif state_type == StateType.ENTROPY_SLOT_ROUTED:
            reachability_proof = {
                'proof_type': 'entropy_pathway_identification',
                'pathway_identified': True,
                'reachability_demonstrated': True,
                'proof_strength': 'medium',
                'explanation': 'Entropy slot pathway identified - state reachable via entropy routing'
            }
        
        elif state_type == StateType.PERFECT_REST_CANDIDATE:
            decomps = processing_result.get('taxicab_decompositions', [])
            if decomps:
                reachability_proof = {
                    'proof_type': 'perfect_rest_decomposition',
                    'decompositions': decomps,
                    'reachability_demonstrated': True,
                    'proof_strength': 'definitive',
                    'explanation': 'Taxicab decompositions found - perfect rest state reachable'
                }
        
        return reachability_proof
    
    def _identify_directional_access_paths(self, state_type: StateType,
                                         processing_result: Dict[str, Any]) -> List[str]:
        """Identify available directional access paths for the state."""
        
        access_paths = []
        
        # Universal access paths available for all states
        access_paths.extend([
            'observer_context_adjustment',
            'work_stance_modification',
            'framework_signature_recognition'
        ])
        
        # State-specific access paths
        if state_type == StateType.DIRECT_LEGAL:
            access_paths.extend([
                'direct_mathematical_approach',
                'algebraic_verification_path',
                'quadratic_reduction_route'
            ])
        
        elif state_type == StateType.QUARTER_FIX_LEGAL:
            access_paths.extend([
                'quarter_fix_transformation_path',
                'repair_mechanism_route',
                'post_transformation_verification'
            ])
        
        elif state_type == StateType.ENTROPY_SLOT_ROUTED:
            access_paths.extend([
                'entropy_slot_classification_path',
                'thermodynamic_consistency_route',
                'uvibs_processing_pathway'
            ])
        
        elif state_type == StateType.PALINDROMIC_WITNESS_AVAILABLE:
            access_paths.extend([
                'palindromic_mirror_generation_path',
                'symmetry_structure_route',
                'w80_validation_pathway',
                'single_move_reachability_path'
            ])
        
        elif state_type == StateType.PERFECT_REST_CANDIDATE:
            access_paths.extend([
                'taxicab_decomposition_path',
                'complementary_partition_route',
                'ten_dimensional_access_pathway',
                'single_move_palindromic_witness_path'
            ])
        
        # Add directional access paths based on processing result
        if processing_result.get('directional_access_results'):
            successful_directions = [
                direction for direction, success in 
                processing_result['directional_access_results'].items() 
                if success
            ]
            access_paths.extend(successful_directions)
        
        return list(set(access_paths))  # Remove duplicates
    
    def analyze_state_reachability(self, state_identifications: List[StateIdentification]) -> Dict[str, Any]:
        """
        Analyze overall state reachability across multiple identifications.
        
        Key insight: ANY reachability proof demonstrates framework capability.
        """
        
        total_states = len(state_identifications)
        states_with_reachability_proof = sum(
            1 for state in state_identifications 
            if state.reachability_proof is not None
        )
        
        palindromic_witnesses_found = sum(
            1 for state in state_identifications 
            if state.state_type == StateType.PALINDROMIC_WITNESS_AVAILABLE
        )
        
        # Collect all unique directional access paths
        all_access_paths = set()
        for state in state_identifications:
            all_access_paths.update(state.directional_access_paths)
        
        # Analyze context dependency
        contexts = set(state.observer_context for state in state_identifications)
        work_stances = set(state.work_stance for state in state_identifications)
        
        # Calculate reachability metrics
        reachability_rate = states_with_reachability_proof / max(1, total_states)
        palindromic_witness_rate = palindromic_witnesses_found / max(1, total_states)
        directional_access_diversity = len(all_access_paths)
        context_diversity = len(contexts)
        
        # Framework capability assessment
        framework_demonstrates_capability = (
            palindromic_witnesses_found > 0 or  # ANY palindromic witness proves capability
            states_with_reachability_proof > 0  # ANY reachability proof demonstrates function
        )
        
        return {
            'total_states_identified': total_states,
            'states_with_reachability_proof': states_with_reachability_proof,
            'palindromic_witnesses_found': palindromic_witnesses_found,
            'reachability_rate': reachability_rate,
            'palindromic_witness_rate': palindromic_witness_rate,
            'directional_access_diversity': directional_access_diversity,
            'context_diversity': context_diversity,
            'work_stance_diversity': len(work_stances),
            'framework_demonstrates_capability': framework_demonstrates_capability,
            'unique_access_paths': list(all_access_paths),
            'contexts_tested': list(contexts),
            'work_stances_tested': list(work_stances),
            'capability_proof_summary': {
                'any_palindromic_witness_found': palindromic_witnesses_found > 0,
                'any_reachability_proof_exists': states_with_reachability_proof > 0,
                'framework_functional': framework_demonstrates_capability,
                'context_dependent_operation_confirmed': context_diversity > 1
            }
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics and performance metrics."""
        return {
            'states_identified': self.stats['states_identified'],
            'reachability_proofs_found': self.stats['reachability_proofs_found'],
            'content_independent_identifications': self.stats['content_independent_identifications'],
            'context_dependent_variations': self.stats['context_dependent_variations'],
            'directional_access_successes': self.stats['directional_access_successes'],
            'reachability_proof_rate': (
                self.stats['reachability_proofs_found'] / max(1, self.stats['states_identified'])
            ),
            'content_independence_rate': (
                self.stats['content_independent_identifications'] / max(1, self.stats['states_identified'])
            ),
            'average_directional_access_per_state': (
                self.stats['directional_access_successes'] / max(1, self.stats['states_identified'])
            )
        }

