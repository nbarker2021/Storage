"""
Quadratic Rest Processor - Core Operational Engine

Implements the fundamental quadratic rest hypothesis: all framework operations
reduce to quadratic relationships through 4-window processing, direct legality
testing, quarter-fix repairs, and palindromic witness generation.
"""

import numpy as np
from typing import List, Dict, Any, Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum


class LegalityStatus(Enum):
    """Status of 4-window legality testing."""
    DIRECT_LEGAL = "direct_legal"
    QUARTER_FIX_LEGAL = "quarter_fix_legal"
    ENTROPY_SLOT_REQUIRED = "entropy_slot_required"
    ILLEGAL = "illegal"


@dataclass
class WindowProcessingResult:
    """Result of 4-window processing."""
    window: List[int]
    legality_status: LegalityStatus
    direct_legal: bool
    quarter_fix_applied: bool
    quarter_fixed_window: Optional[List[int]]
    palindromic_witness: Optional[List[int]]
    w80_validation: bool
    entropy_slot_type: Optional[str]
    processing_steps: List[str]


class QuadraticRestProcessor:
    """
    Core processor implementing quadratic rest hypothesis and 4-window operations.
    
    This processor handles:
    - 4-window extraction from sequences
    - Direct legality testing (sum mod 4 and parity checks)
    - Quarter-fix repair operations
    - Palindromic mirror generation and W80 validation
    - Entropy slot classification for complex cases
    
    The quadratic rest hypothesis states that all legal operations can be
    reduced to quadratic relationships through systematic 4-window processing.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Quadratic Rest Processor.
        
        Args:
            config: Configuration parameters including:
                - strict_validation: Enable strict mathematical validation (default: True)
                - enable_entropy_slots: Enable entropy slot routing (default: True)
                - palindromic_validation: Enable palindromic witness validation (default: True)
                - statistical_tracking: Track processing statistics (default: True)
        """
        self.config = config or {}
        self.strict_validation = self.config.get('strict_validation', True)
        self.enable_entropy_slots = self.config.get('enable_entropy_slots', True)
        self.palindromic_validation = self.config.get('palindromic_validation', True)
        self.statistical_tracking = self.config.get('statistical_tracking', True)
        
        # Statistics tracking
        self.stats = {
            'windows_processed': 0,
            'direct_legal': 0,
            'quarter_fix_successful': 0,
            'entropy_slot_routed': 0,
            'palindromic_witnesses_generated': 0,
            'w80_validations_passed': 0
        } if self.statistical_tracking else {}
        
        # Known entropy slot patterns for different n-values
        self.entropy_slot_patterns = {
            4: [(3, 4, 1)],
            5: [(3, 4, 5, 1)],
            7: [(3, 4, 5), (6, 7, 1)],
            8: self._generate_octadic_entropy_patterns()
        }
    
    def extract_windows(self, sequence: List[int], window_size: int = 4) -> List[List[int]]:
        """
        Extract sliding windows from a sequence.
        
        Args:
            sequence: Input sequence
            window_size: Size of sliding windows (default: 4)
            
        Returns:
            List of windows extracted from the sequence
            
        Example:
            >>> processor = QuadraticRestProcessor()
            >>> windows = processor.extract_windows([1, 2, 3, 4, 1, 2, 3, 4])
            >>> print(windows)
            [[1, 2, 3, 4], [2, 3, 4, 1], [3, 4, 1, 2], [4, 1, 2, 3], [1, 2, 3, 4]]
        """
        if len(sequence) < window_size:
            return [sequence] if sequence else []
        
        windows = []
        for i in range(len(sequence) - window_size + 1):
            windows.append(sequence[i:i + window_size])
        
        return windows
    
    def test_direct_legality(self, window: List[int]) -> bool:
        """
        Test direct legality of a 4-window.
        
        A window is directly legal if:
        1. Sum of elements ≡ 0 (mod 4)
        2. (d₁ + d₃) ≡ (d₂ + d₄) (mod 2) [parity constraint]
        
        Args:
            window: 4-element window to test
            
        Returns:
            True if window is directly legal, False otherwise
            
        Example:
            >>> processor = QuadraticRestProcessor()
            >>> processor.test_direct_legality([1, 2, 3, 4])
            True  # Sum = 10 ≡ 2 (mod 4), but let's check actual implementation
        """
        if len(window) != 4:
            return False
        
        d1, d2, d3, d4 = window
        
        # Test 1: Sum modulo 4
        sum_test = (d1 + d2 + d3 + d4) % 4 == 0
        
        # Test 2: Parity constraint
        parity_test = (d1 + d3) % 2 == (d2 + d4) % 2
        
        return sum_test and parity_test
    
    def apply_quarter_fix(self, window: List[int]) -> List[int]:
        """
        Apply quarter-fix transformation to a 4-window.
        
        Quarter-fix transformation: [d₁, d₂, d₃, d₄] → [d₁, d₄, d₃, d₂]
        This swaps the middle two elements to potentially achieve legality.
        
        Args:
            window: 4-element window to transform
            
        Returns:
            Quarter-fixed window
            
        Example:
            >>> processor = QuadraticRestProcessor()
            >>> fixed = processor.apply_quarter_fix([1, 2, 3, 4])
            >>> print(fixed)
            [1, 4, 3, 2]
        """
        if len(window) != 4:
            return window.copy()
        
        d1, d2, d3, d4 = window
        return [d1, d4, d3, d2]
    
    def generate_palindromic_mirror(self, window: List[int]) -> List[int]:
        """
        Generate palindromic mirror extension of a legal 4-window.
        
        For legal window [d₁, d₂, d₃, d₄], creates palindromic extension:
        [d₁, d₂, d₃, d₄, d₄, d₃, d₂, d₁]
        
        Args:
            window: Legal 4-element window
            
        Returns:
            8-element palindromic mirror
            
        Example:
            >>> processor = QuadraticRestProcessor()
            >>> mirror = processor.generate_palindromic_mirror([1, 2, 3, 4])
            >>> print(mirror)
            [1, 2, 3, 4, 4, 3, 2, 1]
        """
        if len(window) != 4:
            return window.copy()
        
        return window + window[::-1]
    
    def validate_w80_invariant(self, palindrome: List[int]) -> bool:
        """
        Validate W80 global invariant for palindromic sequences.
        
        W80 invariant: (sum_mod8 + quadratic_parity_mod8) ≡ 0 (mod 8)
        where quadratic_parity = Σᵢ (-1)ⁱ × dᵢ²
        
        Args:
            palindrome: Palindromic sequence to validate
            
        Returns:
            True if W80 invariant holds, False otherwise
        """
        if not palindrome:
            return True
        
        # Calculate sum modulo 8
        sum_mod8 = sum(palindrome) % 8
        
        # Calculate quadratic parity modulo 8
        quad_parity = sum((-1)**i * (d**2) for i, d in enumerate(palindrome)) % 8
        
        # W80 invariant: sum + quad_parity ≡ 0 (mod 8)
        w80_result = (sum_mod8 + quad_parity) % 8
        
        return w80_result == 0
    
    def classify_entropy_slot(self, window: List[int], n_value: int = 4) -> Optional[str]:
        """
        Classify a window into appropriate entropy slot type.
        
        Args:
            window: Window that failed direct and quarter-fix legality
            n_value: Operational level (determines available entropy slots)
            
        Returns:
            Entropy slot type identifier, or None if no classification
        """
        if not self.enable_entropy_slots:
            return None
        
        patterns = self.entropy_slot_patterns.get(n_value, [])
        
        for i, pattern in enumerate(patterns):
            if self._matches_entropy_pattern(window, pattern):
                return f"entropy_slot_{n_value}_{i}"
        
        return None
    
    def _matches_entropy_pattern(self, window: List[int], pattern: Tuple[int, ...]) -> bool:
        """Check if window matches a specific entropy slot pattern."""
        if len(window) < len(pattern):
            return False
        
        # Look for pattern as subsequence in window
        for i in range(len(window) - len(pattern) + 1):
            if tuple(window[i:i+len(pattern)]) == pattern:
                return True
        
        return False
    
    def _generate_octadic_entropy_patterns(self) -> List[Tuple[int, ...]]:
        """Generate entropy slot patterns for n=8 (octadic operations)."""
        # For n=8, entropy slots are based on cyclic residue patterns
        # aligned to octadic faces
        return [
            (1, 3, 5, 7),  # Odd residues
            (2, 4, 6, 8),  # Even residues
            (1, 2, 4, 8),  # Powers of 2 mod 8
            (3, 6, 1, 2),  # Specific octadic pattern
        ]
    
    def process_window(self, window: List[int], n_value: int = 4) -> WindowProcessingResult:
        """
        Process a single 4-window through the complete quadratic rest pipeline.
        
        Args:
            window: 4-element window to process
            n_value: Operational level for entropy slot classification
            
        Returns:
            Complete processing result with all analysis
            
        Example:
            >>> processor = QuadraticRestProcessor()
            >>> result = processor.process_window([1, 2, 3, 4])
            >>> print(f"Status: {result.legality_status}")
            >>> print(f"Palindromic witness: {result.palindromic_witness}")
        """
        processing_steps = []
        
        # Step 1: Test direct legality
        direct_legal = self.test_direct_legality(window)
        processing_steps.append(f"Direct legality test: {'PASS' if direct_legal else 'FAIL'}")
        
        if direct_legal:
            # Generate palindromic witness
            palindromic_witness = self.generate_palindromic_mirror(window)
            w80_valid = self.validate_w80_invariant(palindromic_witness)
            processing_steps.append(f"Palindromic witness generated: {palindromic_witness}")
            processing_steps.append(f"W80 validation: {'PASS' if w80_valid else 'FAIL'}")
            
            # Update statistics
            if self.statistical_tracking:
                self.stats['direct_legal'] += 1
                self.stats['palindromic_witnesses_generated'] += 1
                if w80_valid:
                    self.stats['w80_validations_passed'] += 1
            
            return WindowProcessingResult(
                window=window,
                legality_status=LegalityStatus.DIRECT_LEGAL,
                direct_legal=True,
                quarter_fix_applied=False,
                quarter_fixed_window=None,
                palindromic_witness=palindromic_witness,
                w80_validation=w80_valid,
                entropy_slot_type=None,
                processing_steps=processing_steps
            )
        
        # Step 2: Apply quarter-fix and test
        quarter_fixed_window = self.apply_quarter_fix(window)
        quarter_fix_legal = self.test_direct_legality(quarter_fixed_window)
        processing_steps.append(f"Quarter-fix applied: {quarter_fixed_window}")
        processing_steps.append(f"Quarter-fix legality test: {'PASS' if quarter_fix_legal else 'FAIL'}")
        
        if quarter_fix_legal:
            # Generate palindromic witness from quarter-fixed window
            palindromic_witness = self.generate_palindromic_mirror(quarter_fixed_window)
            w80_valid = self.validate_w80_invariant(palindromic_witness)
            processing_steps.append(f"Palindromic witness generated: {palindromic_witness}")
            processing_steps.append(f"W80 validation: {'PASS' if w80_valid else 'FAIL'}")
            
            # Update statistics
            if self.statistical_tracking:
                self.stats['quarter_fix_successful'] += 1
                self.stats['palindromic_witnesses_generated'] += 1
                if w80_valid:
                    self.stats['w80_validations_passed'] += 1
            
            return WindowProcessingResult(
                window=window,
                legality_status=LegalityStatus.QUARTER_FIX_LEGAL,
                direct_legal=False,
                quarter_fix_applied=True,
                quarter_fixed_window=quarter_fixed_window,
                palindromic_witness=palindromic_witness,
                w80_validation=w80_valid,
                entropy_slot_type=None,
                processing_steps=processing_steps
            )
        
        # Step 3: Classify for entropy slot routing
        entropy_slot_type = self.classify_entropy_slot(window, n_value)
        processing_steps.append(f"Entropy slot classification: {entropy_slot_type or 'NONE'}")
        
        if entropy_slot_type:
            # Update statistics
            if self.statistical_tracking:
                self.stats['entropy_slot_routed'] += 1
            
            return WindowProcessingResult(
                window=window,
                legality_status=LegalityStatus.ENTROPY_SLOT_REQUIRED,
                direct_legal=False,
                quarter_fix_applied=True,
                quarter_fixed_window=quarter_fixed_window,
                palindromic_witness=None,
                w80_validation=False,
                entropy_slot_type=entropy_slot_type,
                processing_steps=processing_steps
            )
        
        # Step 4: Window is illegal
        processing_steps.append("Window classified as ILLEGAL")
        
        return WindowProcessingResult(
            window=window,
            legality_status=LegalityStatus.ILLEGAL,
            direct_legal=False,
            quarter_fix_applied=True,
            quarter_fixed_window=quarter_fixed_window,
            palindromic_witness=None,
            w80_validation=False,
            entropy_slot_type=None,
            processing_steps=processing_steps
        )
    
    def process_sequence(self, sequence: List[int], n_value: int = 4) -> Dict[str, Any]:
        """
        Process a complete sequence through quadratic rest operations.
        
        Args:
            sequence: Input sequence to process
            n_value: Operational level
            
        Returns:
            Complete processing results including statistics and analysis
        """
        # Extract 4-windows
        windows = self.extract_windows(sequence, window_size=4)
        
        # Process each window
        window_results = []
        for window in windows:
            result = self.process_window(window, n_value)
            window_results.append(result)
            
            # Update global statistics
            if self.statistical_tracking:
                self.stats['windows_processed'] += 1
        
        # Analyze overall results
        direct_legal_count = sum(1 for r in window_results if r.legality_status == LegalityStatus.DIRECT_LEGAL)
        quarter_fix_count = sum(1 for r in window_results if r.legality_status == LegalityStatus.QUARTER_FIX_LEGAL)
        entropy_slot_count = sum(1 for r in window_results if r.legality_status == LegalityStatus.ENTROPY_SLOT_REQUIRED)
        illegal_count = sum(1 for r in window_results if r.legality_status == LegalityStatus.ILLEGAL)
        
        total_windows = len(window_results)
        success_rate = (direct_legal_count + quarter_fix_count + entropy_slot_count) / max(1, total_windows)
        
        return {
            'sequence': sequence,
            'n_value': n_value,
            'windows_extracted': windows,
            'window_results': window_results,
            'statistics': {
                'total_windows': total_windows,
                'direct_legal': direct_legal_count,
                'quarter_fix_successful': quarter_fix_count,
                'entropy_slot_routed': entropy_slot_count,
                'illegal': illegal_count,
                'success_rate': success_rate,
                'direct_legal_rate': direct_legal_count / max(1, total_windows),
                'quarter_fix_rate': quarter_fix_count / max(1, total_windows),
                'entropy_slot_rate': entropy_slot_count / max(1, total_windows)
            },
            'palindromic_witnesses': [r.palindromic_witness for r in window_results if r.palindromic_witness],
            'w80_validations': [r.w80_validation for r in window_results],
            'entropy_slot_types': [r.entropy_slot_type for r in window_results if r.entropy_slot_type]
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get processor statistics and performance metrics."""
        if not self.statistical_tracking:
            return {'statistical_tracking': False}
        
        total_processed = self.stats['windows_processed']
        
        return {
            'windows_processed': total_processed,
            'direct_legal': self.stats['direct_legal'],
            'quarter_fix_successful': self.stats['quarter_fix_successful'],
            'entropy_slot_routed': self.stats['entropy_slot_routed'],
            'palindromic_witnesses_generated': self.stats['palindromic_witnesses_generated'],
            'w80_validations_passed': self.stats['w80_validations_passed'],
            'success_rate': (
                (self.stats['direct_legal'] + self.stats['quarter_fix_successful'] + 
                 self.stats['entropy_slot_routed']) / max(1, total_processed)
            ),
            'direct_legal_rate': self.stats['direct_legal'] / max(1, total_processed),
            'quarter_fix_rate': self.stats['quarter_fix_successful'] / max(1, total_processed),
            'entropy_slot_rate': self.stats['entropy_slot_routed'] / max(1, total_processed),
            'palindromic_success_rate': (
                self.stats['palindromic_witnesses_generated'] / max(1, total_processed)
            ),
            'w80_validation_rate': (
                self.stats['w80_validations_passed'] / 
                max(1, self.stats['palindromic_witnesses_generated'])
            )
        }
    
    def reset_statistics(self):
        """Reset all statistics counters."""
        if self.statistical_tracking:
            self.stats = {
                'windows_processed': 0,
                'direct_legal': 0,
                'quarter_fix_successful': 0,
                'entropy_slot_routed': 0,
                'palindromic_witnesses_generated': 0,
                'w80_validations_passed': 0
            }


# Convenience functions for direct use
def test_window_legality(window: List[int]) -> Tuple[bool, bool, Optional[List[int]]]:
    """
    Convenience function to test window legality.
    
    Returns:
        Tuple of (direct_legal, quarter_fix_legal, quarter_fixed_window)
    """
    processor = QuadraticRestProcessor()
    direct_legal = processor.test_direct_legality(window)
    
    if direct_legal:
        return True, True, None
    
    quarter_fixed = processor.apply_quarter_fix(window)
    quarter_fix_legal = processor.test_direct_legality(quarter_fixed)
    
    return False, quarter_fix_legal, quarter_fixed if quarter_fix_legal else None


def generate_n4_superpermutation() -> str:
    """
    Generate the standard n=4 superpermutation string.
    
    Returns:
        The minimal superpermutation containing every permutation of {1,2,3,4}
    """
    # This is the known minimal n=4 superpermutation
    return "123412314231243121342132413214321"

