"""
Parent Identity Engine - Core Mathematical Foundation

Implements the fundamental parent identity: a³ + b³ = (a+b)(a² - ab + b²)
This identity drives all framework operations and provides the universal
algebraic relationship that enables cross-domain applicability.
"""

import numpy as np
from typing import Tuple, List, Dict, Any, Optional
import math
from dataclasses import dataclass


@dataclass
class ParentIdentityResult:
    """Result of parent identity application."""
    linear_factor: float
    quadratic_factor: float
    identity_verified: bool
    numerical_error: float
    complementary_partition: Optional[Dict[str, Any]] = None


class ParentIdentityEngine:
    """
    Core engine implementing the parent identity a³ + b³ = (a+b)(a² - ab + b²).
    
    This engine provides the fundamental algebraic relationship that underlies
    all framework operations. It handles:
    - Direct identity application and verification
    - Complementary partition analysis for perfect rest states
    - Taxicab number decomposition and analysis
    - Cross-field identity application (real, complex, finite fields)
    
    The parent identity is the mathematical foundation that enables:
    - Universal algebraic operations across all fields
    - Perfect rest state identification and validation
    - Complementary partition structure for palindromic witnesses
    - Cross-domain bridge construction
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Parent Identity Engine.
        
        Args:
            config: Configuration parameters including:
                - numerical_tolerance: Tolerance for numerical comparisons (default: 1e-12)
                - enable_complex: Enable complex number support (default: True)
                - enable_finite_fields: Enable finite field support (default: False)
                - cache_results: Cache identity calculations (default: True)
        """
        self.config = config or {}
        self.numerical_tolerance = self.config.get('numerical_tolerance', 1e-12)
        self.enable_complex = self.config.get('enable_complex', True)
        self.enable_finite_fields = self.config.get('enable_finite_fields', False)
        self.cache_results = self.config.get('cache_results', True)
        
        # Cache for computed results
        self._identity_cache = {} if self.cache_results else None
        
        # Statistics tracking
        self.stats = {
            'identities_computed': 0,
            'identities_verified': 0,
            'cache_hits': 0,
            'numerical_errors': []
        }
    
    def apply_identity(self, a: float, b: float) -> ParentIdentityResult:
        """
        Apply the parent identity a³ + b³ = (a+b)(a² - ab + b²).
        
        Args:
            a, b: Input values for the identity
            
        Returns:
            ParentIdentityResult containing linear factor, quadratic factor,
            verification status, and numerical error
            
        Example:
            >>> engine = ParentIdentityEngine()
            >>> result = engine.apply_identity(1, 12)  # For 1729 = 1³ + 12³
            >>> print(f"Linear: {result.linear_factor}, Quadratic: {result.quadratic_factor}")
            Linear: 13, Quadratic: 133
        """
        # Check cache first
        cache_key = (a, b) if self.cache_results else None
        if cache_key and cache_key in self._identity_cache:
            self.stats['cache_hits'] += 1
            return self._identity_cache[cache_key]
        
        # Calculate left side: a³ + b³
        left_side = a**3 + b**3
        
        # Calculate right side factors
        linear_factor = a + b
        quadratic_factor = a*a - a*b + b*b
        right_side = linear_factor * quadratic_factor
        
        # Verify identity
        numerical_error = abs(left_side - right_side)
        identity_verified = numerical_error < self.numerical_tolerance
        
        # Create result
        result = ParentIdentityResult(
            linear_factor=linear_factor,
            quadratic_factor=quadratic_factor,
            identity_verified=identity_verified,
            numerical_error=numerical_error
        )
        
        # Update statistics
        self.stats['identities_computed'] += 1
        if identity_verified:
            self.stats['identities_verified'] += 1
        self.stats['numerical_errors'].append(numerical_error)
        
        # Cache result
        if cache_key:
            self._identity_cache[cache_key] = result
            
        return result
    
    def find_taxicab_decompositions(self, number: int, max_search: int = 100) -> List[Tuple[int, int]]:
        """
        Find all taxicab decompositions of a number (ways to express as sum of two cubes).
        
        Args:
            number: Number to decompose
            max_search: Maximum value to search for cube roots
            
        Returns:
            List of (a, b) pairs where a³ + b³ = number
            
        Example:
            >>> engine = ParentIdentityEngine()
            >>> decomps = engine.find_taxicab_decompositions(1729)
            >>> print(decomps)
            [(1, 12), (9, 10)]
        """
        decompositions = []
        
        for a in range(1, max_search):
            a_cubed = a**3
            if a_cubed >= number:
                break
                
            remainder = number - a_cubed
            b = round(remainder**(1/3))
            
            if b > 0 and b**3 == remainder:
                # Verify using parent identity
                identity_result = self.apply_identity(a, b)
                if identity_result.identity_verified:
                    # Store in canonical order (smaller first)
                    pair = (min(a, b), max(a, b))
                    if pair not in decompositions:
                        decompositions.append(pair)
        
        return sorted(decompositions)
    
    def analyze_complementary_partition(self, decompositions: List[Tuple[int, int]], 
                                      number: int) -> Dict[str, Any]:
        """
        Analyze complementary partition structure for perfect rest validation.
        
        For perfect rest states, the prime factorization should partition
        complementarily between the linear and quadratic factors.
        
        Args:
            decompositions: List of taxicab decompositions
            number: Original number being analyzed
            
        Returns:
            Dictionary containing complementary partition analysis
        """
        if not decompositions:
            return {'valid': False, 'reason': 'No decompositions found'}
        
        # Get prime factorization of the number
        prime_factors = self._prime_factorization(number)
        
        # Analyze each decomposition
        partition_analysis = []
        
        for a, b in decompositions:
            identity_result = self.apply_identity(a, b)
            
            linear_factor = int(identity_result.linear_factor)
            quadratic_factor = int(identity_result.quadratic_factor)
            
            # Get prime factorizations of factors
            linear_primes = self._prime_factorization(linear_factor)
            quadratic_primes = self._prime_factorization(quadratic_factor)
            
            # Check if partition is complementary
            all_primes = set(linear_primes.keys()) | set(quadratic_primes.keys())
            is_complementary = True
            partition_details = {}
            
            for prime in all_primes:
                linear_power = linear_primes.get(prime, 0)
                quadratic_power = quadratic_primes.get(prime, 0)
                total_power = prime_factors.get(prime, 0)
                
                partition_details[prime] = {
                    'linear_power': linear_power,
                    'quadratic_power': quadratic_power,
                    'total_power': total_power,
                    'sum_matches': linear_power + quadratic_power == total_power
                }
                
                if linear_power + quadratic_power != total_power:
                    is_complementary = False
            
            partition_analysis.append({
                'decomposition': (a, b),
                'linear_factor': linear_factor,
                'quadratic_factor': quadratic_factor,
                'is_complementary': is_complementary,
                'partition_details': partition_details
            })
        
        # Overall analysis
        valid_partitions = [p for p in partition_analysis if p['is_complementary']]
        
        return {
            'valid': len(valid_partitions) > 0,
            'number': number,
            'prime_factorization': prime_factors,
            'is_square_free': all(power == 1 for power in prime_factors.values()),
            'num_prime_factors': len(prime_factors),
            'partition_analysis': partition_analysis,
            'valid_partitions': valid_partitions,
            'perfect_rest_candidate': (
                len(valid_partitions) > 0 and 
                len(prime_factors) == 3 and 
                all(power == 1 for power in prime_factors.values())
            )
        }
    
    def _prime_factorization(self, n: int) -> Dict[int, int]:
        """Get prime factorization as dictionary of prime -> power."""
        factors = {}
        d = 2
        while d * d <= n:
            while n % d == 0:
                factors[d] = factors.get(d, 0) + 1
                n //= d
            d += 1
        if n > 1:
            factors[n] = factors.get(n, 0) + 1
        return factors
    
    def validate_identity_across_fields(self, a: float, b: float, 
                                      fields: List[str] = None) -> Dict[str, bool]:
        """
        Validate parent identity across different mathematical fields.
        
        Args:
            a, b: Input values
            fields: List of fields to test ('real', 'complex', 'finite')
            
        Returns:
            Dictionary mapping field names to validation results
        """
        if fields is None:
            fields = ['real']
            if self.enable_complex:
                fields.append('complex')
            if self.enable_finite_fields:
                fields.append('finite')
        
        results = {}
        
        for field in fields:
            if field == 'real':
                result = self.apply_identity(a, b)
                results[field] = result.identity_verified
                
            elif field == 'complex' and self.enable_complex:
                # Test with complex values
                a_complex = complex(a, 0.1)  # Add small imaginary part
                b_complex = complex(b, 0.1)
                
                left = a_complex**3 + b_complex**3
                right = (a_complex + b_complex) * (a_complex**2 - a_complex*b_complex + b_complex**2)
                
                error = abs(left - right)
                results[field] = error < self.numerical_tolerance
                
            elif field == 'finite' and self.enable_finite_fields:
                # Test in finite field (mod p for some prime p)
                p = 97  # Use a moderate prime
                a_mod = int(a) % p
                b_mod = int(b) % p
                
                left = (a_mod**3 + b_mod**3) % p
                right = ((a_mod + b_mod) * (a_mod**2 - a_mod*b_mod + b_mod**2)) % p
                
                results[field] = left == right
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get engine statistics and performance metrics."""
        avg_error = np.mean(self.stats['numerical_errors']) if self.stats['numerical_errors'] else 0
        max_error = np.max(self.stats['numerical_errors']) if self.stats['numerical_errors'] else 0
        
        return {
            'identities_computed': self.stats['identities_computed'],
            'identities_verified': self.stats['identities_verified'],
            'verification_rate': (
                self.stats['identities_verified'] / max(1, self.stats['identities_computed'])
            ),
            'cache_hits': self.stats['cache_hits'],
            'cache_hit_rate': (
                self.stats['cache_hits'] / max(1, self.stats['identities_computed'])
            ) if self.cache_results else 0,
            'average_numerical_error': avg_error,
            'maximum_numerical_error': max_error,
            'numerical_tolerance': self.numerical_tolerance
        }
    
    def reset_statistics(self):
        """Reset all statistics counters."""
        self.stats = {
            'identities_computed': 0,
            'identities_verified': 0,
            'cache_hits': 0,
            'numerical_errors': []
        }
        if self.cache_results:
            self._identity_cache.clear()


# Convenience functions for direct use
def apply_parent_identity(a: float, b: float) -> Tuple[float, float, bool]:
    """
    Convenience function to apply parent identity directly.
    
    Returns:
        Tuple of (linear_factor, quadratic_factor, verified)
    """
    engine = ParentIdentityEngine()
    result = engine.apply_identity(a, b)
    return result.linear_factor, result.quadratic_factor, result.identity_verified


def find_taxicab_numbers(limit: int = 10000) -> List[Tuple[int, List[Tuple[int, int]]]]:
    """
    Find all taxicab numbers up to a given limit.
    
    Args:
        limit: Maximum number to search
        
    Returns:
        List of (number, decompositions) pairs
    """
    engine = ParentIdentityEngine()
    taxicab_numbers = []
    
    for n in range(2, limit):
        decomps = engine.find_taxicab_decompositions(n)
        if len(decomps) >= 2:  # Taxicab numbers have at least 2 decompositions
            taxicab_numbers.append((n, decomps))
    
    return taxicab_numbers

