"""
Observer-Dependent Context System - "Direct Viewed Context and Work"

Implements the fundamental observer-dependent rest point selection that enables
context-sensitive framework operations. Different observational contexts yield
different processing outcomes and state identification capabilities.
"""

import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum


class ObservationalContext(Enum):
    """Types of observational contexts for framework operations."""
    MATHEMATICAL_ANALYSIS = "mathematical_analysis"
    PALINDROMIC_SEARCH = "palindromic_search"
    ENTROPY_MANAGEMENT = "entropy_management"
    DIMENSIONAL_SCALING = "dimensional_scaling"
    PERFECT_REST_ANALYSIS = "perfect_rest_analysis"
    CROSS_DOMAIN_BRIDGE = "cross_domain_bridge"
    GENERAL_EXPLORATION = "general_exploration"


class WorkStance(Enum):
    """Work stance orientations for processing focus."""
    ALGEBRAIC_STRUCTURE = "algebraic_structure"
    PALINDROMIC_POTENTIAL = "palindromic_potential"
    ENTROPY_OPTIMIZATION = "entropy_optimization"
    DIMENSIONAL_NAVIGATION = "dimensional_navigation"
    PERFECT_REST_SEEKING = "perfect_rest_seeking"
    UNIVERSAL_BRIDGING = "universal_bridging"
    COMPREHENSIVE_ANALYSIS = "comprehensive_analysis"


@dataclass
class ContextualProcessingResult:
    """Result of context-dependent processing."""
    context: ObservationalContext
    work_stance: WorkStance
    rest_point_selection: Dict[str, Any]
    processing_outcomes: List[Dict[str, Any]]
    state_identifications: List[Dict[str, Any]]
    palindromic_witnesses: List[List[int]]
    success_indicators: List[str]
    directional_access_results: Dict[str, bool]
    context_specific_metrics: Dict[str, float]


class ObserverDependentContextSystem:
    """
    Core system implementing observer-dependent context and work stance selection.
    
    This system enables the fundamental framework capability of "direct viewed context
    and work" - where different observational contexts and work stances yield
    different rest point selections and processing outcomes.
    
    Key Principles:
    1. Observer context determines rest point bias and processing focus
    2. Work stance influences transformation preferences and success criteria
    3. State identification is context-dependent (WHEN vs WHAT distinction)
    4. Multiple directional access pathways from any location
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Observer-Dependent Context System.
        
        Args:
            config: Configuration parameters including:
                - context_sensitivity: Degree of context influence (default: 0.8)
                - work_stance_weight: Influence of work stance on processing (default: 0.6)
                - rest_point_flexibility: Flexibility in rest point selection (default: 0.7)
                - directional_access_count: Number of directional access methods (default: 10)
        """
        self.config = config or {}
        self.context_sensitivity = self.config.get('context_sensitivity', 0.8)
        self.work_stance_weight = self.config.get('work_stance_weight', 0.6)
        self.rest_point_flexibility = self.config.get('rest_point_flexibility', 0.7)
        self.directional_access_count = self.config.get('directional_access_count', 10)
        
        # Context-specific processing preferences
        self.context_preferences = self._initialize_context_preferences()
        
        # Work stance transformation methods
        self.work_stance_methods = self._initialize_work_stance_methods()
        
        # Directional access pathways
        self.directional_pathways = self._initialize_directional_pathways()
        
        # Statistics tracking
        self.stats = {
            'contexts_processed': 0,
            'successful_state_identifications': 0,
            'palindromic_witnesses_found': 0,
            'directional_access_successes': 0,
            'context_switches': 0
        }
    
    def _initialize_context_preferences(self) -> Dict[ObservationalContext, Dict[str, Any]]:
        """Initialize context-specific processing preferences."""
        return {
            ObservationalContext.MATHEMATICAL_ANALYSIS: {
                'rest_point_bias': 'algebraic_structure',
                'processing_focus': 'direct_legality',
                'success_criteria': 'mathematical_consistency',
                'transformation_preference': 'identity_preserving',
                'validation_strictness': 0.9
            },
            ObservationalContext.PALINDROMIC_SEARCH: {
                'rest_point_bias': 'palindromic_potential',
                'processing_focus': 'witness_generation',
                'success_criteria': 'palindromic_reachability',
                'transformation_preference': 'symmetry_enhancing',
                'validation_strictness': 0.6
            },
            ObservationalContext.ENTROPY_MANAGEMENT: {
                'rest_point_bias': 'entropy_optimization',
                'processing_focus': 'entropy_slots',
                'success_criteria': 'thermodynamic_consistency',
                'transformation_preference': 'entropy_conserving',
                'validation_strictness': 0.8
            },
            ObservationalContext.DIMENSIONAL_SCALING: {
                'rest_point_bias': 'dimensional_navigation',
                'processing_focus': 'scaling_optimization',
                'success_criteria': 'dimensional_consistency',
                'transformation_preference': 'dimension_preserving',
                'validation_strictness': 0.7
            },
            ObservationalContext.PERFECT_REST_ANALYSIS: {
                'rest_point_bias': 'perfect_rest_seeking',
                'processing_focus': 'taxicab_analysis',
                'success_criteria': 'perfect_rest_identification',
                'transformation_preference': 'complementary_partition',
                'validation_strictness': 0.95
            },
            ObservationalContext.CROSS_DOMAIN_BRIDGE: {
                'rest_point_bias': 'universal_bridging',
                'processing_focus': 'domain_translation',
                'success_criteria': 'cross_domain_consistency',
                'transformation_preference': 'universal_mapping',
                'validation_strictness': 0.75
            },
            ObservationalContext.GENERAL_EXPLORATION: {
                'rest_point_bias': 'comprehensive_analysis',
                'processing_focus': 'broad_spectrum',
                'success_criteria': 'general_functionality',
                'transformation_preference': 'adaptive',
                'validation_strictness': 0.5
            }
        }
    
    def _initialize_work_stance_methods(self) -> Dict[WorkStance, Dict[str, Any]]:
        """Initialize work stance-specific methods and preferences."""
        return {
            WorkStance.ALGEBRAIC_STRUCTURE: {
                'transformation_methods': ['identity', 'linear_combination', 'factorization'],
                'validation_approach': 'algebraic_consistency',
                'success_weight': 0.9,
                'preferred_operations': ['parent_identity', 'quadratic_reduction']
            },
            WorkStance.PALINDROMIC_POTENTIAL: {
                'transformation_methods': ['mirror', 'reverse', 'symmetric_extension'],
                'validation_approach': 'palindromic_structure',
                'success_weight': 0.8,
                'preferred_operations': ['palindromic_mirror', 'w80_validation']
            },
            WorkStance.ENTROPY_OPTIMIZATION: {
                'transformation_methods': ['entropy_conserving', 'thermodynamic_consistent'],
                'validation_approach': 'entropy_analysis',
                'success_weight': 0.85,
                'preferred_operations': ['entropy_slot_routing', 'uvibs_processing']
            },
            WorkStance.DIMENSIONAL_NAVIGATION: {
                'transformation_methods': ['dimensional_transfer', 'scaling_optimization'],
                'validation_approach': 'dimensional_consistency',
                'success_weight': 0.75,
                'preferred_operations': ['dimensional_scaling', 'observer_selection']
            },
            WorkStance.PERFECT_REST_SEEKING: {
                'transformation_methods': ['taxicab_decomposition', 'complementary_partition'],
                'validation_approach': 'perfect_rest_criteria',
                'success_weight': 0.95,
                'preferred_operations': ['perfect_rest_analysis', 'single_move_palindrome']
            },
            WorkStance.UNIVERSAL_BRIDGING: {
                'transformation_methods': ['cross_domain_mapping', 'universal_translation'],
                'validation_approach': 'universal_consistency',
                'success_weight': 0.7,
                'preferred_operations': ['token_generation', 'domain_bridging']
            },
            WorkStance.COMPREHENSIVE_ANALYSIS: {
                'transformation_methods': ['adaptive', 'multi_approach'],
                'validation_approach': 'comprehensive_validation',
                'success_weight': 0.6,
                'preferred_operations': ['all_available']
            }
        }
    
    def _initialize_directional_pathways(self) -> List[Dict[str, Any]]:
        """Initialize 10+ directional access pathways."""
        return [
            {
                'name': 'direct_approach',
                'method': 'direct_legality_test',
                'description': 'Direct mathematical legality testing',
                'success_weight': 1.0
            },
            {
                'name': 'quarter_fix_approach',
                'method': 'quarter_fix_transformation',
                'description': 'Quarter-fix repair transformation',
                'success_weight': 0.9
            },
            {
                'name': 'palindromic_approach',
                'method': 'palindromic_extension',
                'description': 'Palindromic mirror generation and validation',
                'success_weight': 0.8
            },
            {
                'name': 'entropy_slot_approach',
                'method': 'entropy_slot_classification',
                'description': 'Entropy slot routing and management',
                'success_weight': 0.7
            },
            {
                'name': 'reverse_approach',
                'method': 'sequence_reversal',
                'description': 'Sequence reversal and re-evaluation',
                'success_weight': 0.6
            },
            {
                'name': 'cyclic_approach',
                'method': 'cyclic_permutation',
                'description': 'Cyclic permutation exploration',
                'success_weight': 0.6
            },
            {
                'name': 'modular_approach',
                'method': 'modular_transformation',
                'description': 'Modular arithmetic transformations',
                'success_weight': 0.5
            },
            {
                'name': 'parity_approach',
                'method': 'parity_analysis',
                'description': 'Parity-based state analysis',
                'success_weight': 0.5
            },
            {
                'name': 'algebraic_approach',
                'method': 'algebraic_relationship',
                'description': 'Parent identity and algebraic relationships',
                'success_weight': 0.8
            },
            {
                'name': 'complementary_approach',
                'method': 'complementary_transformation',
                'description': 'Complementary value transformations',
                'success_weight': 0.4
            },
            {
                'name': 'dimensional_approach',
                'method': 'dimensional_projection',
                'description': 'Dimensional scaling and projection',
                'success_weight': 0.7
            },
            {
                'name': 'observer_approach',
                'method': 'observer_context_shift',
                'description': 'Observer context and rest point adjustment',
                'success_weight': 0.9
            }
        ]
    
    def select_rest_point(self, context: ObservationalContext, 
                         work_stance: WorkStance,
                         available_data: Any) -> Dict[str, Any]:
        """
        Select observer-dependent rest point based on context and work stance.
        
        This implements the core "direct viewed context and work" capability.
        Different contexts yield different rest point selections.
        
        Args:
            context: Observational context for processing
            work_stance: Work stance orientation
            available_data: Available data for rest point selection
            
        Returns:
            Rest point selection with context-dependent parameters
        """
        context_prefs = self.context_preferences[context]
        stance_methods = self.work_stance_methods[work_stance]
        
        # Context-dependent rest point bias
        rest_point_bias = context_prefs['rest_point_bias']
        
        # Work stance influence on selection
        transformation_preference = context_prefs['transformation_preference']
        validation_strictness = context_prefs['validation_strictness']
        
        # Combine context and stance influences
        combined_weight = (
            self.context_sensitivity * validation_strictness +
            self.work_stance_weight * stance_methods['success_weight']
        ) / 2
        
        rest_point_selection = {
            'context': context,
            'work_stance': work_stance,
            'rest_point_bias': rest_point_bias,
            'transformation_preference': transformation_preference,
            'validation_strictness': validation_strictness,
            'combined_weight': combined_weight,
            'processing_focus': context_prefs['processing_focus'],
            'success_criteria': context_prefs['success_criteria'],
            'preferred_operations': stance_methods['preferred_operations'],
            'transformation_methods': stance_methods['transformation_methods']
        }
        
        return rest_point_selection
    
    def process_with_context(self, data: Any, 
                           context: ObservationalContext,
                           work_stance: WorkStance,
                           processor_functions: Dict[str, callable]) -> ContextualProcessingResult:
        """
        Process data with specific observational context and work stance.
        
        This is the main entry point for context-dependent processing.
        
        Args:
            data: Input data to process
            context: Observational context
            work_stance: Work stance orientation
            processor_functions: Dictionary of available processing functions
            
        Returns:
            Complete contextual processing result
        """
        # Select rest point based on context and work stance
        rest_point_selection = self.select_rest_point(context, work_stance, data)
        
        # Initialize result containers
        processing_outcomes = []
        state_identifications = []
        palindromic_witnesses = []
        success_indicators = []
        directional_access_results = {}
        
        # Context-specific processing
        if context == ObservationalContext.PALINDROMIC_SEARCH:
            # Focus on finding palindromic witnesses and reachability
            palindromic_witnesses, success_indicators = self._process_palindromic_search(
                data, rest_point_selection, processor_functions
            )
            
        elif context == ObservationalContext.MATHEMATICAL_ANALYSIS:
            # Focus on mathematical consistency and algebraic relationships
            processing_outcomes, success_indicators = self._process_mathematical_analysis(
                data, rest_point_selection, processor_functions
            )
            
        elif context == ObservationalContext.ENTROPY_MANAGEMENT:
            # Focus on entropy slot routing and thermodynamic consistency
            processing_outcomes, success_indicators = self._process_entropy_management(
                data, rest_point_selection, processor_functions
            )
            
        elif context == ObservationalContext.DIMENSIONAL_SCALING:
            # Focus on dimensional operations and scaling
            processing_outcomes, success_indicators = self._process_dimensional_scaling(
                data, rest_point_selection, processor_functions
            )
            
        elif context == ObservationalContext.PERFECT_REST_ANALYSIS:
            # Focus on perfect rest identification
            processing_outcomes, palindromic_witnesses, success_indicators = self._process_perfect_rest_analysis(
                data, rest_point_selection, processor_functions
            )
            
        else:
            # General exploration - try multiple approaches
            processing_outcomes, palindromic_witnesses, success_indicators = self._process_general_exploration(
                data, rest_point_selection, processor_functions
            )
        
        # Test directional access capabilities
        directional_access_results = self.test_directional_access(
            data, rest_point_selection, processor_functions
        )
        
        # Identify states (WHEN vs WHAT distinction)
        state_identifications = self.identify_states(
            data, processing_outcomes, context, work_stance
        )
        
        # Calculate context-specific metrics
        context_specific_metrics = self._calculate_context_metrics(
            processing_outcomes, palindromic_witnesses, success_indicators,
            directional_access_results, state_identifications
        )
        
        # Update statistics
        self.stats['contexts_processed'] += 1
        self.stats['palindromic_witnesses_found'] += len(palindromic_witnesses)
        self.stats['successful_state_identifications'] += len(state_identifications)
        self.stats['directional_access_successes'] += sum(directional_access_results.values())
        
        return ContextualProcessingResult(
            context=context,
            work_stance=work_stance,
            rest_point_selection=rest_point_selection,
            processing_outcomes=processing_outcomes,
            state_identifications=state_identifications,
            palindromic_witnesses=palindromic_witnesses,
            success_indicators=success_indicators,
            directional_access_results=directional_access_results,
            context_specific_metrics=context_specific_metrics
        )
    
    def _process_palindromic_search(self, data, rest_point_selection, processor_functions):
        """Process with focus on palindromic witness discovery."""
        palindromic_witnesses = []
        success_indicators = []
        
        # Extract windows if data is a sequence
        if hasattr(data, '__iter__') and not isinstance(data, str):
            windows = self._extract_windows(data)
            
            for i, window in enumerate(windows):
                # Try direct palindromic generation
                if 'generate_palindromic_mirror' in processor_functions:
                    try:
                        witness = processor_functions['generate_palindromic_mirror'](window)
                        if witness and len(witness) > len(window):
                            palindromic_witnesses.append(witness)
                            success_indicators.append(f"Window {i+1}: Direct palindromic witness found")
                    except:
                        pass
                
                # Try alternative transformations for palindromic potential
                alt_witness = self._search_palindromic_potential(window, processor_functions)
                if alt_witness:
                    palindromic_witnesses.append(alt_witness)
                    success_indicators.append(f"Window {i+1}: Alternative palindromic path found")
        
        return palindromic_witnesses, success_indicators
    
    def _process_mathematical_analysis(self, data, rest_point_selection, processor_functions):
        """Process with focus on mathematical consistency."""
        processing_outcomes = []
        success_indicators = []
        
        # Test mathematical relationships
        if hasattr(data, '__iter__') and not isinstance(data, str):
            windows = self._extract_windows(data)
            
            for i, window in enumerate(windows):
                if 'test_direct_legality' in processor_functions:
                    try:
                        is_legal = processor_functions['test_direct_legality'](window)
                        if is_legal:
                            processing_outcomes.append({
                                'window': window,
                                'position': i,
                                'type': 'direct_legal',
                                'mathematical_consistency': True
                            })
                            success_indicators.append(f"Window {i+1}: Direct mathematical legality verified")
                    except:
                        pass
        
        return processing_outcomes, success_indicators
    
    def _process_entropy_management(self, data, rest_point_selection, processor_functions):
        """Process with focus on entropy slot routing."""
        processing_outcomes = []
        success_indicators = []
        
        if hasattr(data, '__iter__') and not isinstance(data, str):
            windows = self._extract_windows(data)
            
            for i, window in enumerate(windows):
                if 'classify_entropy_slot' in processor_functions:
                    try:
                        entropy_type = processor_functions['classify_entropy_slot'](window)
                        if entropy_type:
                            processing_outcomes.append({
                                'window': window,
                                'position': i,
                                'type': 'entropy_slot',
                                'entropy_classification': entropy_type
                            })
                            success_indicators.append(f"Window {i+1}: Entropy slot classified as {entropy_type}")
                            success_indicators.append(f"Window {i+1}: Valid entropy pathway identified")
                    except:
                        pass
        
        return processing_outcomes, success_indicators
    
    def _process_dimensional_scaling(self, data, rest_point_selection, processor_functions):
        """Process with focus on dimensional operations."""
        processing_outcomes = []
        success_indicators = []
        
        # Test dimensional scaling capabilities
        if 'dimensional_transfer' in processor_functions:
            try:
                # Test scaling to different dimensions
                for target_dim in [16, 32, 64]:
                    result = processor_functions['dimensional_transfer'](data, target_dim)
                    if result:
                        processing_outcomes.append({
                            'data': data,
                            'target_dimension': target_dim,
                            'type': 'dimensional_transfer',
                            'transfer_result': result
                        })
                        success_indicators.append(f"Dimensional transfer to {target_dim}D successful")
            except:
                pass
        
        return processing_outcomes, success_indicators
    
    def _process_perfect_rest_analysis(self, data, rest_point_selection, processor_functions):
        """Process with focus on perfect rest identification."""
        processing_outcomes = []
        palindromic_witnesses = []
        success_indicators = []
        
        # If data is a number, analyze for perfect rest properties
        if isinstance(data, int):
            if 'find_taxicab_decompositions' in processor_functions:
                try:
                    decomps = processor_functions['find_taxicab_decompositions'](data)
                    if decomps:
                        processing_outcomes.append({
                            'number': data,
                            'type': 'taxicab_analysis',
                            'decompositions': decomps
                        })
                        success_indicators.append(f"Taxicab decompositions found for {data}")
                        
                        # Generate palindromic witnesses from decompositions
                        for a, b in decomps:
                            test_sequence = [a, b, a, b]
                            if 'generate_palindromic_mirror' in processor_functions:
                                try:
                                    witness = processor_functions['generate_palindromic_mirror'](test_sequence)
                                    if witness:
                                        palindromic_witnesses.append(witness)
                                        success_indicators.append(f"Perfect rest palindromic witness generated")
                                except:
                                    pass
                except:
                    pass
        
        return processing_outcomes, palindromic_witnesses, success_indicators
    
    def _process_general_exploration(self, data, rest_point_selection, processor_functions):
        """Process with general exploration approach."""
        processing_outcomes = []
        palindromic_witnesses = []
        success_indicators = []
        
        # Try multiple processing approaches
        if hasattr(data, '__iter__') and not isinstance(data, str):
            windows = self._extract_windows(data)
            
            for i, window in enumerate(windows):
                # Try all available processing functions
                for func_name, func in processor_functions.items():
                    try:
                        if func_name == 'test_direct_legality':
                            if func(window):
                                processing_outcomes.append({
                                    'window': window,
                                    'position': i,
                                    'type': 'direct_legal'
                                })
                        elif func_name == 'generate_palindromic_mirror':
                            witness = func(window)
                            if witness:
                                palindromic_witnesses.append(witness)
                        elif func_name == 'classify_entropy_slot':
                            entropy_type = func(window)
                            if entropy_type:
                                processing_outcomes.append({
                                    'window': window,
                                    'position': i,
                                    'type': 'entropy_slot',
                                    'entropy_type': entropy_type
                                })
                    except:
                        continue
        
        return processing_outcomes, palindromic_witnesses, success_indicators
    
    def test_directional_access(self, data, rest_point_selection, processor_functions):
        """Test 10+ directional access pathways for state identification."""
        directional_results = {}
        
        # Test each directional pathway
        for pathway in self.directional_pathways:
            pathway_name = pathway['name']
            pathway_method = pathway['method']
            
            try:
                success = self._test_single_directional_pathway(
                    data, pathway_method, processor_functions
                )
                directional_results[pathway_name] = success
            except:
                directional_results[pathway_name] = False
        
        return directional_results
    
    def _test_single_directional_pathway(self, data, method, processor_functions):
        """Test a single directional access pathway."""
        
        if method == 'direct_legality_test':
            if hasattr(data, '__iter__') and 'test_direct_legality' in processor_functions:
                windows = self._extract_windows(data)
                return any(processor_functions['test_direct_legality'](w) for w in windows)
        
        elif method == 'quarter_fix_transformation':
            if hasattr(data, '__iter__') and 'apply_quarter_fix' in processor_functions:
                windows = self._extract_windows(data)
                for window in windows:
                    qf_window = processor_functions['apply_quarter_fix'](window)
                    if 'test_direct_legality' in processor_functions:
                        if processor_functions['test_direct_legality'](qf_window):
                            return True
        
        elif method == 'palindromic_extension':
            if hasattr(data, '__iter__') and 'generate_palindromic_mirror' in processor_functions:
                windows = self._extract_windows(data)
                for window in windows:
                    witness = processor_functions['generate_palindromic_mirror'](window)
                    if witness and len(witness) > len(window):
                        return True
        
        elif method == 'entropy_slot_classification':
            if hasattr(data, '__iter__') and 'classify_entropy_slot' in processor_functions:
                windows = self._extract_windows(data)
                return any(processor_functions['classify_entropy_slot'](w) for w in windows)
        
        elif method == 'parity_analysis':
            if hasattr(data, '__iter__'):
                windows = self._extract_windows(data)
                return any(sum(w) % 2 == 0 for w in windows)
        
        elif method == 'algebraic_relationship':
            if hasattr(data, '__iter__') and 'apply_identity' in processor_functions:
                windows = self._extract_windows(data)
                for window in windows:
                    if len(window) >= 2:
                        result = processor_functions['apply_identity'](window[0], window[1])
                        if hasattr(result, 'identity_verified') and result.identity_verified:
                            return True
        
        # Add more pathway implementations as needed
        
        return False
    
    def identify_states(self, data, processing_outcomes, context, work_stance):
        """
        Identify states (WHEN vs WHAT distinction).
        
        Framework identifies WHEN you're in desired states, not WHAT's in them.
        """
        state_identifications = []
        
        for outcome in processing_outcomes:
            state_id = {
                'position': outcome.get('position', 0),
                'state_type': outcome.get('type', 'unknown'),
                'context': context,
                'work_stance': work_stance,
                'identification_time': 'current',  # WHEN identified
                'content_independent': True,  # Framework identifies WHEN, not WHAT
                'state_properties': {
                    'identified_by_framework': True,
                    'content_agnostic': True,
                    'context_dependent': True
                }
            }
            state_identifications.append(state_id)
        
        return state_identifications
    
    def _extract_windows(self, data, window_size=4):
        """Extract sliding windows from data."""
        if len(data) < window_size:
            return [list(data)] if data else []
        
        windows = []
        for i in range(len(data) - window_size + 1):
            windows.append(list(data[i:i + window_size]))
        
        return windows
    
    def _search_palindromic_potential(self, window, processor_functions):
        """Search for palindromic potential through alternative transformations."""
        transformations = [
            lambda w: w,  # Identity
            lambda w: [w[0], w[3], w[2], w[1]],  # Quarter-fix
            lambda w: [w[1], w[0], w[3], w[2]],  # Pair swap
            lambda w: w[::-1],  # Reverse
            lambda w: [w[0], w[2], w[1], w[3]],  # Cross pattern
            lambda w: [w[1], w[3], w[0], w[2]],  # Diagonal swap
        ]
        
        for transform in transformations:
            try:
                transformed = transform(window)
                if 'test_direct_legality' in processor_functions:
                    if processor_functions['test_direct_legality'](transformed):
                        if 'generate_palindromic_mirror' in processor_functions:
                            return processor_functions['generate_palindromic_mirror'](transformed)
            except:
                continue
        
        return None
    
    def _calculate_context_metrics(self, processing_outcomes, palindromic_witnesses, 
                                 success_indicators, directional_access_results, 
                                 state_identifications):
        """Calculate context-specific performance metrics."""
        total_outcomes = len(processing_outcomes)
        total_witnesses = len(palindromic_witnesses)
        total_indicators = len(success_indicators)
        total_access_success = sum(directional_access_results.values())
        total_access_attempts = len(directional_access_results)
        total_states_identified = len(state_identifications)
        
        return {
            'processing_success_rate': total_outcomes / max(1, total_outcomes + 1),
            'palindromic_witness_rate': total_witnesses / max(1, total_outcomes + 1),
            'success_indicator_density': total_indicators / max(1, total_outcomes + 1),
            'directional_access_rate': total_access_success / max(1, total_access_attempts),
            'state_identification_rate': total_states_identified / max(1, total_outcomes + 1),
            'overall_context_effectiveness': (
                total_witnesses + total_indicators + total_access_success + total_states_identified
            ) / max(1, total_outcomes + total_access_attempts + 1)
        }
    
    def get_statistics(self):
        """Get system statistics and performance metrics."""
        return {
            'contexts_processed': self.stats['contexts_processed'],
            'successful_state_identifications': self.stats['successful_state_identifications'],
            'palindromic_witnesses_found': self.stats['palindromic_witnesses_found'],
            'directional_access_successes': self.stats['directional_access_successes'],
            'context_switches': self.stats['context_switches'],
            'average_witnesses_per_context': (
                self.stats['palindromic_witnesses_found'] / max(1, self.stats['contexts_processed'])
            ),
            'average_access_success_rate': (
                self.stats['directional_access_successes'] / 
                max(1, self.stats['contexts_processed'] * self.directional_access_count)
            )
        }

