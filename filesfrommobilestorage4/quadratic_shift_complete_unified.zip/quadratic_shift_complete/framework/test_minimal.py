#!/usr/bin/env python3
"""
Minimal Framework Test - Direct File Imports

Tests framework by importing files directly, bypassing package structure.
"""

import sys
import os

# Add source directory to path
src_path = os.path.join(os.path.dirname(__file__), 'src', 'quadratic_shift', 'core')
sys.path.insert(0, src_path)

# Direct file imports
import parent_identity
import quadratic_rest


def main():
    """Main test execution."""
    print("QUADRATIC SHIFT FRAMEWORK - MINIMAL VALIDATION TEST")
    print("=" * 70)
    print()
    
    # Initialize components
    parent_engine = parent_identity.ParentIdentityEngine()
    quadratic_processor = quadratic_rest.QuadraticRestProcessor()
    
    print("✓ Components initialized successfully")
    print()
    
    # TEST 1: Parent Identity Validation
    print("TEST 1: PARENT IDENTITY VALIDATION")
    print("-" * 40)
    
    # Test 1729 (Hardy-Ramanujan number)
    print("Testing 1729 (Hardy-Ramanujan number):")
    decomps = parent_engine.find_taxicab_decompositions(1729)
    print(f"Taxicab decompositions: {decomps}")
    
    all_verified = True
    for a, b in decomps:
        result = parent_engine.apply_identity(a, b)
        cube_sum = a**3 + b**3
        factored_result = result.linear_factor * result.quadratic_factor
        
        print(f"  {a}³ + {b}³ = {cube_sum}")
        print(f"  ({a}+{b}) × ({a}²-{a}×{b}+{b}²) = {result.linear_factor} × {result.quadratic_factor} = {factored_result}")
        print(f"  Verified: {result.identity_verified} (error: {result.numerical_error:.2e})")
        
        if not result.identity_verified:
            all_verified = False
    
    print(f"\nParent Identity Test: {'✓ PASS' if all_verified else '✗ FAIL'}")
    print()
    
    # TEST 2: n=4 Superpermutation Processing
    print("TEST 2: n=4 SUPERPERMUTATION PROCESSING")
    print("-" * 45)
    
    # Generate n=4 superpermutation
    superperm = quadratic_rest.generate_n4_superpermutation()
    sequence = [int(c) for c in superperm]
    
    print(f"n=4 Superpermutation: {superperm}")
    print(f"Length: {len(sequence)} characters")
    print(f"Sequence: {sequence}")
    print()
    
    # Process through quadratic rest system
    print("Processing through Quadratic Rest System...")
    result = quadratic_processor.process_sequence(sequence, n_value=4)
    stats = result['statistics']
    
    print(f"Results:")
    print(f"  Total 4-windows: {stats['total_windows']}")
    print(f"  Direct legal: {stats['direct_legal']} ({stats['direct_legal_rate']:.1%})")
    print(f"  Quarter-fix successful: {stats['quarter_fix_successful']} ({stats['quarter_fix_rate']:.1%})")
    print(f"  Entropy slot routed: {stats['entropy_slot_routed']} ({stats['entropy_slot_rate']:.1%})")
    print(f"  Overall success rate: {stats['success_rate']:.1%}")
    
    # Test >90% claim
    combined_rate = stats['direct_legal_rate'] + stats['quarter_fix_rate']
    ninety_percent_claim = combined_rate >= 0.90
    
    print(f"\nFramework Claim Validation:")
    print(f"  Combined Direct+Quarter-fix: {combined_rate:.1%}")
    print(f"  >90% legality claim: {'✓ VERIFIED' if ninety_percent_claim else '✗ FAILED'}")
    
    # Show detailed analysis of first few windows
    print(f"\nWindow Analysis (first 8 windows):")
    for i, window_result in enumerate(result['window_results'][:8]):
        window = window_result.window
        status = window_result.legality_status.value
        symbol = "✓" if status in ['direct_legal', 'quarter_fix_legal'] else "✗"
        
        print(f"  {i+1:2d}. {window} → {symbol} {status}")
        
        if window_result.quarter_fix_applied and window_result.quarter_fixed_window:
            print(f"      Quarter-fixed: {window_result.quarter_fixed_window}")
        
        if window_result.palindromic_witness:
            witness = window_result.palindromic_witness
            print(f"      Palindromic witness: {witness}")
            print(f"      W80 valid: {window_result.w80_validation}")
    
    print()
    
    # TEST 3: n=32 Dual Helix Extension
    print("TEST 3: n=2 → n=32 DUAL HELIX EXTENSION")
    print("-" * 50)
    
    # Create dual helix based on n=2 duality
    print("Creating dual helix structure...")
    
    # Base n=2 duality
    base_a, base_b = 1, 2
    
    # Create 16-element helices
    helix_1 = []
    helix_2 = []
    
    for i in range(16):
        # Cycle through 1,2,3,4 to maintain structure
        elem_1 = ((base_a + i - 1) % 4) + 1
        elem_2 = ((base_b + i - 1) % 4) + 1
        helix_1.append(elem_1)
        helix_2.append(elem_2)
    
    # Combine into 32-element dual helix
    dual_helix = helix_1 + helix_2
    
    print(f"Helix 1: {helix_1}")
    print(f"Helix 2: {helix_2}")
    print(f"Dual helix (32 elements): {dual_helix}")
    print(f"Length: {len(dual_helix)}")
    print()
    
    # Validate dual bonds
    print("Validating dual bonds...")
    valid_bonds = 0
    for i in range(16):
        bond_result = parent_engine.apply_identity(helix_1[i], helix_2[i])
        if bond_result.identity_verified:
            valid_bonds += 1
        
        if i < 5:  # Show first 5 bonds
            print(f"  Bond {i+1}: ({helix_1[i]}, {helix_2[i]}) → {'✓' if bond_result.identity_verified else '✗'}")
    
    if len(helix_1) > 5:
        print(f"  ... and {len(helix_1) - 5} more bonds")
    
    bond_rate = valid_bonds / 16
    print(f"\nDual bond integrity: {valid_bonds}/16 ({bond_rate:.1%})")
    print()
    
    # Process dual helix through framework
    print("Processing dual helix through framework...")
    dual_result = quadratic_processor.process_sequence(dual_helix, n_value=32)
    dual_stats = dual_result['statistics']
    
    print(f"Dual helix processing:")
    print(f"  Total windows: {dual_stats['total_windows']}")
    print(f"  Success rate: {dual_stats['success_rate']:.1%}")
    print(f"  Direct legal: {dual_stats['direct_legal']} ({dual_stats['direct_legal_rate']:.1%})")
    print(f"  Quarter-fix: {dual_stats['quarter_fix_successful']} ({dual_stats['quarter_fix_rate']:.1%})")
    
    # Test palindromic extension
    dual_palindrome = dual_helix + dual_helix[::-1]
    w80_valid = quadratic_processor.validate_w80_invariant(dual_palindrome)
    print(f"  Palindromic W80 validation: {'✓ PASS' if w80_valid else '✗ FAIL'}")
    print()
    
    # FINAL VALIDATION
    print("FINAL FRAMEWORK VALIDATION")
    print("=" * 40)
    
    # Define validation criteria
    validations = {
        'parent_identity_works': all_verified,
        'n4_superperm_90_percent': ninety_percent_claim,
        'dual_helix_constructed': len(dual_helix) == 32,
        'dual_bonds_functional': bond_rate >= 0.5,  # At least 50% bonds work
        'dual_helix_processes': dual_stats['success_rate'] > 0.3,  # At least 30% success
        'palindromic_extension_valid': w80_valid
    }
    
    print("Validation Results:")
    for criterion, passed in validations.items():
        print(f"  {criterion}: {'✓ PASS' if passed else '✗ FAIL'}")
    
    overall_success = all(validations.values())
    
    print()
    print(f"OVERALL RESULT: {'✓ FRAMEWORK VALIDATED' if overall_success else '✗ VALIDATION FAILED'}")
    print()
    
    if overall_success:
        print("🎉 SUCCESS! Framework validation complete!")
        print()
        print("Verified Capabilities:")
        print("✓ Parent identity a³ + b³ = (a+b)(a² - ab + b²) works correctly")
        print("✓ n=4 superpermutation achieves >90% legality through framework")
        print("✓ Quadratic rest hypothesis validated on real superpermutation data")
        print("✓ n=2 → n=32 dual helix extension is mathematically legal")
        print("✓ Dual bond structure preserves parent identity relationships")
        print("✓ Framework processing scales from n=4 to n=32")
        print("✓ Palindromic constraints and W80 invariant functional")
        print()
        print("DEPLOYMENT RECOMMENDATION: ✅ APPROVED")
        print("Framework is mathematically sound and ready for production use.")
        
        # Summary statistics
        print(f"\nDeployment Statistics:")
        print(f"  n=4 superpermutation success rate: {stats['success_rate']:.1%}")
        print(f"  n=4 combined legality rate: {combined_rate:.1%}")
        print(f"  n=32 dual helix success rate: {dual_stats['success_rate']:.1%}")
        print(f"  Dual bond integrity: {bond_rate:.1%}")
        print(f"  Total windows tested: {stats['total_windows'] + dual_stats['total_windows']}")
        
    else:
        print("❌ Validation failed. Issues found:")
        for criterion, passed in validations.items():
            if not passed:
                print(f"  ✗ {criterion}")
        print()
        print("DEPLOYMENT RECOMMENDATION: ❌ NOT APPROVED")
        print("Address validation failures before deployment.")
    
    return overall_success


if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

