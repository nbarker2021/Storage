# NDA Pack (v1) — for Nick
This folder contains several NDA templates and a sweeping "Master Confidentiality & Use‑Restriction Agreement" (MCURA) that can stand alone.
**Not legal advice** — use counsel for final review. Fill bracketed fields like [PARTY], [STATE], [DAYS].

## What’s inside
- 00_How_to_choose.md — quick decision guide + clause matrix
- 01_Master_Confidentiality_and_Use‑Restriction_Agreement.md (MCURA) — tight, sweeping, covers software + outputs + models + logs + “no training/benchmarking” + attestation/anchors
- 02_Mutual_NDA_Comprehensive.md — balanced, for two‑way sharing
- 03_Unilateral_Receiving_NDA_Strong.md — when *you* disclose; they receive
- 04_Evaluation_and_Access_Agreement_LFAI.md — NDA + license limits for corridor/API access
- 05_Advisor_NDA_with_Inventions_Addendum.md — adds invention assignment for advisors/contractors
- 06_Contractor_Work_Product_Assignment.md — work‑for‑hire + IP assignment
- 07_Short_Form_NDA_1page.md — quick signature version (email/DocuSign friendly)
- 08_Permission_Notice_Template.md — to pair with your Restricted License
- 09_Data_Room_Rules_and_Audit.md — how you’ll run a controlled data room w/ anchors/paints
- clause_matrix.json — searchable list of clauses across templates

Key protective themes baked in:
- Defines Confidential Information to include **Outputs, Anchors, Ledgers, Paints**, interfaces, and derivative analytics.
- Explicit **No Training / No Benchmarking / No Model Tuning** on Outputs.
- **No reverse‑engineering / no decompilation / no circumvention** of gating/legality.
- **Residuals disclaimed** (they can’t use what “sticks in their head”).
- **Field‑of‑use** & **Territory** options; **Non‑circumvention** optional.
- **Return/Destroy** + **Attestation** with anchors/paints references.
- **Injunctive relief** + **specific performance**; venue/governing law blanks.
- E‑signature & PDF acceptable; countersignature blocks included.
