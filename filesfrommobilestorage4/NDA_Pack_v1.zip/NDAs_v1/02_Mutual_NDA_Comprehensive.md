# Mutual Non‑Disclosure Agreement (Comprehensive)
[...similar structure to MCURA but mutual obligations, with bilateral disclosures, and explicit carve‑ins for Outputs, No Training/Benchmark, No Reverse Engineering, Residuals disclaimed, Return/Destroy + Attestation, Injunctive Relief, Term/Survival, Law/Venue...]
Fill [PARTY A]/[PARTY B], [STATE], [COURTS], [TERM].
