# Unilateral Receiving NDA (Strong)
Discloser: Nick  |  Recipient: [COUNTERPARTY]
Purpose: Internal evaluation.
Key points: Outputs included as Confidential; No Training/Benchmark; No Reverse‑Engineering; Residuals disclaimed; Return/Destroy + Attestation; Injunctive Relief.
(Full text mirrors MCURA obligations on Recipient only.)
