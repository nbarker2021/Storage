# Permission Notice Template (for LFAI Restricted License)
(Use with your repository license. Fill Scope, Term, Territory, Anchors, Keys.)
