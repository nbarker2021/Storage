# How to Choose (fast)
- **One doc to rule them all?** Use **01_Master_Confidentiality_and_Use‑Restriction_Agreement.md (MCURA)**.
- **Two‑way talks with partners?** 02_Mutual_NDA_Comprehensive.md
- **You disclose only?** 03_Unilateral_Receiving_NDA_Strong.md
- **Granting sandbox/API access?** 04_Evaluation_and_Access_Agreement_LFAI.md (NDA + license limits)
- **Advisor/contractor involvement?** 05_Advisor_NDA_with_Inventions_Addendum.md + 06_Contractor_Work_Product_Assignment.md
- **Quick email signature?** 07_Short_Form_NDA_1page.md

## Clause toggles you can adjust
- **Term**: typical 2–5 years; trade secrets survive as long as they remain secret.
- **Return/Destroy**: within [DAYS]; include **Attestation**.
- **Field‑of‑Use/Territory**: lock to “internal evaluation only” in [TERRITORY].
- **Audit**: light (attest + anchors) or heavier (on‑site review).
- **Residuals**: this pack **disallows** residuals by default.
- **Publicity**: barred unless you approve in writing.
- **Governing Law/Venue**: fill [STATE]/[COURTS].
