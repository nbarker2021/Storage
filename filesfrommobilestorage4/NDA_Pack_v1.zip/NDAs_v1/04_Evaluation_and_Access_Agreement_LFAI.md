# Evaluation & Access Agreement (LFAI)
Combines NDA + restricted license for sandbox/API access.

1) Access Grant: limited, non‑transferable, revocable; evaluation‑only; no production.
2) Use Restrictions: No Training/Benchmarking/Model Tuning; No Reverse‑Engineering/Circumvention; Field‑of‑Use/Territory; rate limits; credential hygiene.
3) Confidential & Outputs: anchors/paints/ledgers/logs included; Attestation on exit.
4) Feedback: optional, non‑exclusive license to use feedback; no obligation to use.
5) Suspension/Termination: for breach or security risk; Return/Destroy.
6) Law/Venue; Injunctive Relief; E‑signatures.
Attach your **Permission Notice** to detail Scope/Term.
