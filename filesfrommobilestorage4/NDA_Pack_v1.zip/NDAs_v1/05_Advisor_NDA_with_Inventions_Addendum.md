# Advisor NDA with Inventions Addendum
- Mutual or unilateral NDA terms (choose).
- Inventions Addendum: work product related to Discloser’s business and created during the engagement is **assigned** to Discloser (or licensed if you prefer).
- Moral rights waiver where permitted; assistance with filings; carve‑outs for prior inventions disclosed on Exhibit A.
