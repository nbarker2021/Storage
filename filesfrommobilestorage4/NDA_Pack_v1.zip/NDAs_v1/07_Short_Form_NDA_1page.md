# Short‑Form NDA (1 page)
Parties: Nick (Discloser) and [Recipient].
Purpose: Internal evaluation.
Term: [24] months; trade secrets survive.
Confidential Info includes software, docs, and **Outputs (anchors, paints, ledgers, logs)**.
Use only for the Purpose; no third‑party disclosure; protect with reasonable care.
**No Training/Benchmarking/Reverse‑Engineering/Circumvention.**
Return/Destroy within [10] days of request; provide Attestation.
Injunctive relief; [STATE LAW]/[COURTS]; e‑signatures accepted.
Signatures:
Nick: ____________  Date: ____  |  [Recipient]: ____________  Date: ____
