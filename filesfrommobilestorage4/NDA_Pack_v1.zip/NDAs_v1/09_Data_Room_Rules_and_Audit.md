# Data Room Rules & Audit
- Access via named accounts; no sharing; MFA.
- No screenshots or scraping; downloads off by default.
- All artifacts watermarked with **anchors/paints**; access logged.
- Exports (if any) enumerated and pre‑approved in writing.
- Quarterly attestation of compliance; spot checks allowed.
