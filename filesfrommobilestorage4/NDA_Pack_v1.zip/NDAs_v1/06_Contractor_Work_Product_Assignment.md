# Contractor Work‑Product & Assignment
- Confidentiality obligations.
- Work‑for‑hire to the extent permitted; otherwise **assignment** of IP to Nick.
- Delivery of source and materials; no open‑source copyleft without approval.
- Non‑solicitation (optional), Background IP license to enable use of deliverables.
