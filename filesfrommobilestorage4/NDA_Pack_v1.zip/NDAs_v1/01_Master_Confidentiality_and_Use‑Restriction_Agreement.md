# Master Confidentiality & Use‑Restriction Agreement (MCURA)
**Effective Date:** [DATE]

**Parties.** Nick (“Discloser”) and [COUNTERPARTY] (“Recipient”), each a “Party.”

## 1. Purpose & Scope
Recipient will receive access to Discloser’s confidential materials for the sole purpose of **internal evaluation** and discussions regarding a potential business relationship (“Purpose”). This Agreement governs **all disclosures and access**, including **software, services, and outputs**.

## 2. Definitions
**Confidential Information** means any non‑public information disclosed by Discloser, including without limitation: software, source code, binaries, models, datasets, keys, documentation, interfaces, API specs, **Outputs** (anchors, paints, ledgers, embeddings, logs, metrics), algorithms, designs, roadmaps, pricing, business plans, as well as the existence and terms of this Agreement. Confidential Information includes information observed through access or use, and derivatives/analytics thereof.

**Outputs** means any artifacts produced by or derived from Discloser’s software or service, including but not limited to **anchors, paints, ledgers, embeddings, model responses, metrics, and provenance**.

## 3. Use & Access Restrictions
Recipient shall: (a) use Confidential Information **solely** for the Purpose; (b) not disclose to any third party; (c) protect with at least reasonable care; (d) limit access to employees/contractors with a need‑to‑know who are bound by written obligations no less protective.

**No Training / No Benchmarking.** Recipient shall not use Confidential Information or Outputs to **train, fine‑tune, evaluate, benchmark, or compare** any models, systems, or services, nor publish any performance data, without prior written consent.

**No Reverse Engineering; No Circumvention.** Recipient shall not reverse engineer, decompile, disassemble, derive source, or circumvent gating, legality checks, or commit rules.

**Residuals Disclaimed.** Recipient agrees not to use information retained in unaided memory for any purpose other than the Purpose.

**Field‑of‑Use & Territory.** Use is limited to **internal evaluation** within [TERRITORY], for [TERM] months from Effective Date.

## 4. Exceptions
Information is not Confidential to the extent Recipient proves it: (i) is or becomes public through no breach; (ii) was rightfully known without duty of confidentiality; (iii) is independently developed without use of Confidential Information; or (iv) is disclosed under legal compulsion with prompt notice.

## 5. Return / Destroy; Attestation
Upon request or the earlier of the end of the Purpose or Term, Recipient will promptly **cease all use**, and **return or destroy** Confidential Information and **Outputs**, and deliver a signed **Attestation** reasonably describing what was returned/destroyed. Where Discloser’s systems produce **anchors/paints/ledgers**, Recipient will reference the relevant identifiers in the Attestation.

## 6. No License; Ownership
No licenses are granted by implication or otherwise. All rights not expressly granted remain with Discloser.

## 7. Non‑Circumvention (optional)
For [NC_TERM] months, Recipient will not circumvent Discloser to engage directly with Discloser’s named partners or customers identified only through Confidential Information, without written consent. (Strike if not needed.)

## 8. Injunctive Relief; Remedies
Unauthorized use or disclosure may cause irreparable harm. Discloser is entitled to seek **injunctive relief** and **specific performance**, in addition to other remedies at law.

## 9. Term; Survival
This Agreement begins on the Effective Date and continues for [TERM] months. Sections 3–8 and 10–12 survive as long as the information remains confidential or as otherwise stated.

## 10. Export; Compliance
Recipient will comply with applicable export controls and sanctions.

## 11. Governing Law; Venue
[STATE LAW] governs, excluding conflicts rules; exclusive venue in [COURTS].

## 12. Entire Agreement; Counterparts; E‑Signatures
This Agreement is the Parties’ entire agreement for the subject matter. It may be executed in counterparts and via electronic signatures, all of which are deemed originals.

**Discloser (Nick)**  

Name: __________________  Title: __________  Signature: __________  Date: ____

**Recipient ([COUNTERPARTY])**  

Name: __________________  Title: __________  Signature: __________  Date: ____
