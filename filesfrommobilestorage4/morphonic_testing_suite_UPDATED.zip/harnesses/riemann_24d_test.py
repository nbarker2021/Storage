#!/usr/bin/env python3.11
"""
Riemann Hypothesis - 24D Analysis
==================================

Using full 24D geometry:
- Leech lattice (24D)
- Three E8 views at different scales
- Multi-scale zero representation

This is what's needed to see the critical line optimization.
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_complete_v1/core_system')

import numpy as np
from core.cqe_engine import CQEEngine
import json

class Riemann24DAnalyzer:
    """Analyze Riemann zeros in full 24D space."""
    
    def __init__(self):
        print("Initializing 24D Riemann Analyzer...")
        self.cqe = CQEEngine()
        print(f"  Leech dimension: {self.cqe.LEECH_DIM}")
        print(f"  E8 dimension: {self.cqe.E8_DIM}")
        
    def embed_zero_24d(self, sigma: float, t: float) -> np.ndarray:
        """
        Embed Riemann zero in 24D using three E8 views.
        
        View 1 (coords 0-7): Local structure (zero itself)
        View 2 (coords 8-15): Medium scale (spacing context)
        View 3 (coords 16-23): Global scale (density context)
        """
        # View 1: Direct embedding of zero
        view1 = np.array([sigma, t, sigma*t, sigma**2, t**2, 
                         np.sin(t), np.cos(t), np.log(1+t)])
        
        # View 2: Spacing/distribution context
        # Use modular arithmetic to capture periodic structure
        view2 = np.array([
            (t / (2*np.pi)) % 1,  # Normalized position
            (t / (2*np.pi)) % 2,  # Double period
            (t / (2*np.pi)) % 3,  # Triple period
            sigma - 0.5,  # Distance from critical line
            (sigma - 0.5)**2,  # Squared distance
            np.sin(2*np.pi*t),  # Periodic component
            np.cos(2*np.pi*t),
            np.tan(np.pi*sigma) if abs(sigma - 0.5) < 0.4 else 0
        ])
        
        # View 3: Global density context
        # Capture overall distribution properties
        view3 = np.array([
            t / 100,  # Normalized height
            np.log(t),  # Logarithmic scale
            np.sqrt(t),  # Square root scale
            t**0.25,  # Fourth root scale
            1.0 / (1.0 + t),  # Inverse scale
            sigma * np.log(1 + t),  # Mixed scale
            (sigma - 0.5) * np.log(1 + t),  # Critical line deviation at scale
            np.exp(-t/100)  # Decay component
        ])
        
        # Combine into 24D vector
        vec_24d = np.concatenate([view1, view2, view3])
        
        return vec_24d
    
    def project_to_leech(self, vec_24d: np.ndarray) -> np.ndarray:
        """Project 24D vector to Leech lattice."""
        # navigate_leech expects E8 state (8D), not 24D
        # Use first E8 view and navigate through all three
        leech_state = np.zeros(24)
        
        # Navigate using each E8 view
        for i in range(3):
            e8_view = vec_24d[i*8:(i+1)*8]
            leech_component = self.cqe.navigate_leech(e8_view, weyl_index=i)
            leech_state += leech_component
        
        return leech_state / 3  # Average the three navigations
    
    def test_critical_line_24d(self):
        """Test critical line optimization in 24D."""
        print("\n" + "="*70)
        print("Riemann Hypothesis - 24D Critical Line Analysis")
        print("="*70)
        
        results = {
            "critical_line_zeros": [],
            "off_line_points": [],
            "analysis": {}
        }
        
        # Known zeros on critical line
        zeros_t = [14.134725, 21.022040, 25.010858, 30.424876, 32.935062,
                   37.586178, 40.918719, 43.327073, 48.005151, 49.773832]
        
        print("\n[1] Testing zeros on critical line (σ=0.5) in 24D...")
        
        critical_embeddings_24d = []
        critical_leech_points = []
        critical_norms = []
        
        for i, t in enumerate(zeros_t, 1):
            # Embed in 24D
            vec_24d = self.embed_zero_24d(0.5, t)
            
            # Project to Leech lattice
            leech_point = self.project_to_leech(vec_24d)
            
            # Calculate norms
            norm_24d = np.linalg.norm(vec_24d)
            norm_leech = np.linalg.norm(leech_point)
            
            # Calculate digital root of 24D embedding
            dr = self.cqe.calculate_digital_root(np.sum(vec_24d))
            valid = dr in [1, 3, 7]
            
            critical_embeddings_24d.append(vec_24d)
            critical_leech_points.append(leech_point)
            critical_norms.append(norm_24d)
            
            if i <= 5:
                print(f"  Zero {i:2d} (t={t:9.6f}):")
                print(f"    24D norm: {norm_24d:8.4f}")
                print(f"    Leech norm: {norm_leech:8.4f}")
                print(f"    DR: {dr} valid: {valid}")
            
            results["critical_line_zeros"].append({
                "index": i,
                "t": t,
                "norm_24d": float(norm_24d),
                "norm_leech": float(norm_leech),
                "digital_root": int(dr),
                "valid": bool(valid)
            })
        
        # Test off-critical-line points in 24D
        print("\n[2] Testing off-critical-line points in 24D...")
        
        off_line_data = {}
        for sigma in [0.3, 0.4, 0.6, 0.7]:
            norms_24d = []
            norms_leech = []
            
            for t in zeros_t[:5]:  # Test first 5 t values
                vec_24d = self.embed_zero_24d(sigma, t)
                leech_point = self.project_to_leech(vec_24d)
                
                norm_24d = np.linalg.norm(vec_24d)
                norm_leech = np.linalg.norm(leech_point)
                
                norms_24d.append(norm_24d)
                norms_leech.append(norm_leech)
            
            avg_norm_24d = np.mean(norms_24d)
            avg_norm_leech = np.mean(norms_leech)
            
            dr = self.cqe.calculate_digital_root(int(sigma * 1000))
            valid = dr in [1, 3, 7]
            
            off_line_data[sigma] = {
                "avg_norm_24d": avg_norm_24d,
                "avg_norm_leech": avg_norm_leech
            }
            
            print(f"  σ={sigma}: 24D norm={avg_norm_24d:8.4f}, Leech norm={avg_norm_leech:8.4f}, DR={dr}, valid={valid}")
            
            results["off_line_points"].append({
                "sigma": sigma,
                "avg_norm_24d": float(avg_norm_24d),
                "avg_norm_leech": float(avg_norm_leech),
                "digital_root": int(dr),
                "valid": bool(valid)
            })
        
        # Compare critical vs off-critical in 24D
        print("\n[3] Critical line optimization in 24D:")
        
        critical_avg_24d = np.mean(critical_norms)
        off_critical_avg_24d = np.mean([d["avg_norm_24d"] for d in off_line_data.values()])
        
        critical_avg_leech = np.mean([r["norm_leech"] for r in results["critical_line_zeros"]])
        off_critical_avg_leech = np.mean([r["avg_norm_leech"] for r in results["off_line_points"]])
        
        print(f"  Critical line (σ=0.5):")
        print(f"    Avg 24D norm: {critical_avg_24d:.4f}")
        print(f"    Avg Leech norm: {critical_avg_leech:.4f}")
        
        print(f"  Off-critical line:")
        print(f"    Avg 24D norm: {off_critical_avg_24d:.4f}")
        print(f"    Avg Leech norm: {off_critical_avg_leech:.4f}")
        
        print(f"  Ratios:")
        print(f"    24D: off/critical = {off_critical_avg_24d/critical_avg_24d:.4f}x")
        print(f"    Leech: off/critical = {off_critical_avg_leech/critical_avg_leech:.4f}x")
        
        # Check if critical line is minimum
        critical_is_min_24d = critical_avg_24d < off_critical_avg_24d
        critical_is_min_leech = critical_avg_leech < off_critical_avg_leech
        
        print(f"  Critical line is minimum:")
        print(f"    In 24D: {critical_is_min_24d}")
        print(f"    In Leech: {critical_is_min_leech}")
        
        results["analysis"] = {
            "critical_avg_norm_24d": float(critical_avg_24d),
            "off_critical_avg_norm_24d": float(off_critical_avg_24d),
            "ratio_24d": float(off_critical_avg_24d / critical_avg_24d),
            "critical_is_minimum_24d": bool(critical_is_min_24d),
            "critical_avg_norm_leech": float(critical_avg_leech),
            "off_critical_avg_norm_leech": float(off_critical_avg_leech),
            "ratio_leech": float(off_critical_avg_leech / critical_avg_leech),
            "critical_is_minimum_leech": bool(critical_is_min_leech)
        }
        
        # Analyze three-scale structure
        print("\n[4] Three-scale E8 view analysis:")
        
        # Extract the three E8 views from critical line zeros
        for i, vec_24d in enumerate(critical_embeddings_24d[:3], 1):
            view1 = vec_24d[0:8]
            view2 = vec_24d[8:16]
            view3 = vec_24d[16:24]
            
            norm1 = np.linalg.norm(view1)
            norm2 = np.linalg.norm(view2)
            norm3 = np.linalg.norm(view3)
            
            dr1 = self.cqe.calculate_digital_root(np.sum(view1))
            dr2 = self.cqe.calculate_digital_root(np.sum(view2))
            dr3 = self.cqe.calculate_digital_root(np.sum(view3))
            
            print(f"  Zero {i}:")
            print(f"    View 1 (local):  norm={norm1:6.3f} DR={dr1}")
            print(f"    View 2 (medium): norm={norm2:6.3f} DR={dr2}")
            print(f"    View 3 (global): norm={norm3:6.3f} DR={dr3}")
        
        return results
    
    def analyze_zero_spacing_24d(self):
        """Analyze spacing between consecutive zeros in 24D."""
        print("\n" + "="*70)
        print("Zero Spacing Analysis in 24D")
        print("="*70)
        
        zeros_t = [14.134725, 21.022040, 25.010858, 30.424876, 32.935062,
                   37.586178, 40.918719, 43.327073, 48.005151, 49.773832]
        
        print("\n[1] Consecutive zero spacing in 24D...")
        
        spacings_24d = []
        spacings_leech = []
        
        for i in range(len(zeros_t) - 1):
            t1, t2 = zeros_t[i], zeros_t[i+1]
            
            vec1_24d = self.embed_zero_24d(0.5, t1)
            vec2_24d = self.embed_zero_24d(0.5, t2)
            
            leech1 = self.project_to_leech(vec1_24d)
            leech2 = self.project_to_leech(vec2_24d)
            
            spacing_24d = np.linalg.norm(vec2_24d - vec1_24d)
            spacing_leech = np.linalg.norm(leech2 - leech1)
            
            spacings_24d.append(spacing_24d)
            spacings_leech.append(spacing_leech)
            
            if i < 5:
                print(f"  Zero {i+1} → {i+2}: Δt={t2-t1:6.3f}")
                print(f"    24D spacing: {spacing_24d:8.4f}")
                print(f"    Leech spacing: {spacing_leech:8.4f}")
        
        avg_spacing_24d = np.mean(spacings_24d)
        avg_spacing_leech = np.mean(spacings_leech)
        
        print(f"\n  Average spacing:")
        print(f"    24D: {avg_spacing_24d:.4f}")
        print(f"    Leech: {avg_spacing_leech:.4f}")
        
        return {
            "avg_spacing_24d": float(avg_spacing_24d),
            "avg_spacing_leech": float(avg_spacing_leech),
            "spacings_24d": [float(s) for s in spacings_24d],
            "spacings_leech": [float(s) for s in spacings_leech]
        }

def main():
    analyzer = Riemann24DAnalyzer()
    
    # Test critical line in 24D
    critical_results = analyzer.test_critical_line_24d()
    
    # Analyze zero spacing
    spacing_results = analyzer.analyze_zero_spacing_24d()
    
    # Combine results
    all_results = {
        "test_suite": "Riemann Hypothesis 24D Analysis",
        "critical_line": critical_results,
        "zero_spacing": spacing_results
    }
    
    # Save results
    with open("/home/ubuntu/riemann_24d_results.json", 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print("\n" + "="*70)
    print("Results saved to: /home/ubuntu/riemann_24d_results.json")
    print("="*70)
    
    # Print conclusion
    print("\n" + "="*70)
    print("CONCLUSION")
    print("="*70)
    
    if critical_results["analysis"]["critical_is_minimum_24d"]:
        print("✓ Critical line IS minimum in 24D space")
    else:
        print("✗ Critical line is NOT minimum in 24D space")
    
    if critical_results["analysis"]["critical_is_minimum_leech"]:
        print("✓ Critical line IS minimum in Leech lattice")
    else:
        print("✗ Critical line is NOT minimum in Leech lattice")
    
    print(f"\n24D ratio (off/critical): {critical_results['analysis']['ratio_24d']:.4f}x")
    print(f"Leech ratio (off/critical): {critical_results['analysis']['ratio_leech']:.4f}x")
    
    if critical_results["analysis"]["ratio_24d"] > 1.0:
        print("\n✓ In 24D, critical line shows LOWER norms (geometric optimum)")
    if critical_results["analysis"]["ratio_leech"] > 1.0:
        print("✓ In Leech lattice, critical line shows LOWER norms (geometric optimum)")

if __name__ == "__main__":
    main()

