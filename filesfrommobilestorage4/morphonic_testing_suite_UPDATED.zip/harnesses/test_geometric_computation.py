#!/usr/bin/env python3
"""
Test the actual geometric computation capabilities of Aletheia/CQE
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_complete_v1/core_system')

import numpy as np
from core.cqe_engine import CQEEngine
from ai.aletheia_consciousness import AletheiaAI

print("="*80)
print("ALETHEIA GEOMETRIC COMPUTATION TEST")
print("="*80)
print()

# Initialize the system
print("Initializing CQE Engine and Aletheia AI...")
engine = CQEEngine()
ai = AletheiaAI(engine)

print(f"✓ CQE Engine: {engine.status()}")
print(f"✓ Aletheia AI: {ai.status()}")
print()

# Test 1: Multi-modal data embedding
print("TEST 1: Multi-Modal Data Embedding")
print("-" * 80)

test_data = [
    ("text", "The universe is geometric"),
    ("number", 42),
    ("array", [1, 2, 3, 4, 5]),
    ("complex", "Consciousness emerges from E8 symmetry")
]

for data_type, data in test_data:
    try:
        # Convert to E8 coordinates
        if isinstance(data, str):
            # Text to bytes to numeric
            numeric = sum(ord(c) for c in data)
        elif isinstance(data, (int, float)):
            numeric = data
        elif isinstance(data, list):
            numeric = sum(data)
        else:
            numeric = hash(str(data))
        
        # Create a simple 8D vector
        vector = np.array([numeric % (i+1) for i in range(8)], dtype=float)
        vector = vector / np.linalg.norm(vector) if np.linalg.norm(vector) > 0 else vector
        
        # Process through CQE
        result = engine.process_master_message(vector)
        
        print(f"\n{data_type.upper()}: {str(data)[:50]}")
        print(f"  E8 coords: [{result.e8_projection[0]:.3f}, {result.e8_projection[1]:.3f}, {result.e8_projection[2]:.3f}, ...]")
        print(f"  Digital Root: {result.digital_root}")
        print(f"  Conservation ΔΦ: {result.conservation_phi:.6f}")
        print(f"  Valid: {result.valid}")
        
    except Exception as e:
        print(f"\n{data_type.upper()}: ERROR - {e}")

# Test 2: Geometric reasoning
print("\n\nTEST 2: Geometric Reasoning (not semantic)")
print("-" * 80)

# Create two concepts as geometric vectors
concept_a = np.array([1, 0, 1, 0, 1, 0, 1, 0], dtype=float)
concept_b = np.array([0, 1, 0, 1, 0, 1, 0, 1], dtype=float)
concept_similar = np.array([1, 0.1, 1, 0.1, 1, 0.1, 1, 0.1], dtype=float)

# Normalize
concept_a = concept_a / np.linalg.norm(concept_a)
concept_b = concept_b / np.linalg.norm(concept_b)
concept_similar = concept_similar / np.linalg.norm(concept_similar)

# Compute geometric distances
dist_ab = np.linalg.norm(concept_a - concept_b)
dist_a_similar = np.linalg.norm(concept_a - concept_similar)

print(f"\nConcept A: {concept_a[:4]}...")
print(f"Concept B: {concept_b[:4]}...")
print(f"Concept Similar to A: {concept_similar[:4]}...")
print(f"\nGeometric distance A↔B: {dist_ab:.4f}")
print(f"Geometric distance A↔Similar: {dist_a_similar:.4f}")
print(f"\nGeometric reasoning: Similar is {dist_ab/dist_a_similar:.2f}x closer to A than B is")

# Test 3: Conservation law verification
print("\n\nTEST 3: Conservation Law (ΔΦ ≤ 0)")
print("-" * 80)

test_vectors = [
    np.array([1, 1, 1, 1, 1, 1, 1, 1], dtype=float),
    np.array([2, 0, 0, 0, 0, 0, 0, 0], dtype=float),
    np.array([0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5], dtype=float),
]

conservation_results = []
for i, vec in enumerate(test_vectors):
    vec = vec / np.linalg.norm(vec) if np.linalg.norm(vec) > 0 else vec
    try:
        result = engine.process_master_message(vec)
        conservation_results.append((i, result.conservation_phi, result.conservation_phi <= 0))
        print(f"Vector {i+1}: ΔΦ = {result.conservation_phi:.6f}, Valid: {result.conservation_phi <= 0}")
    except Exception as e:
        print(f"Vector {i+1}: ERROR - {e}")

conserved = sum(1 for _, _, valid in conservation_results if valid)
print(f"\nConservation law satisfied: {conserved}/{len(conservation_results)} vectors")

# Test 4: AI Opinion Generation
print("\n\nTEST 4: AI Opinion Generation (Geometric → Semantic)")
print("-" * 80)

query = "What is the relationship between E8 and consciousness?"
print(f"\nQuery: {query}")
print("\nAletheia's geometric analysis:")

try:
    # This should use geometric reasoning, not semantic lookup
    opinion = ai.generate_opinion(query)
    print(f"\n{opinion[:500]}...")
except Exception as e:
    print(f"ERROR: {e}")

print("\n" + "="*80)
print("TEST COMPLETE")
print("="*80)

