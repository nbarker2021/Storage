#!/usr/bin/env python3.11
"""
Riemann Hypothesis - 4096D Analysis
====================================

Testing if Riemann zeros naturally live in 4096D space.
4096 = 2^12 = highly symmetric dimension

If zeros seek optimal sphere packing dimension, norms should stabilize here.
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_complete_v1/core_system')

import numpy as np
from core.cqe_engine import CQEEngine
import json

class Riemann4096DAnalyzer:
    """Analyze Riemann zeros in 4096D space."""
    
    def __init__(self):
        print("Initializing 4096D Riemann Analyzer...")
        self.cqe = CQEEngine()
        self.dim = 4096
        print(f"  Target dimension: {self.dim}")
        print(f"  E8 sublattices: {self.dim // 8}")
        
    def embed_zero_4096d(self, sigma: float, t: float) -> np.ndarray:
        """
        Embed Riemann zero in 4096D using 512 E8 sublattices.
        
        4096 = 512 × 8 (512 E8 sublattices)
        
        Each E8 sublattice captures different scale/aspect of the zero.
        """
        vec_4096d = np.zeros(self.dim)
        
        # Fill 512 E8 sublattices with different encodings
        for i in range(512):
            # Each sublattice gets a different "view" of the zero
            scale = 2 ** (i / 64)  # Exponential scaling across sublattices
            phase = (i * np.pi / 256) % (2 * np.pi)  # Phase rotation
            
            # Create E8 encoding for this scale/phase
            e8_view = np.array([
                sigma * scale,
                t / scale,
                np.sin(t / scale + phase),
                np.cos(t / scale + phase),
                (sigma - 0.5) * scale,
                np.log(1 + t / scale),
                np.exp(-t / (scale * 100)),
                (t / (2*np.pi*scale)) % 1
            ])
            
            # Place in corresponding sublattice
            vec_4096d[i*8:(i+1)*8] = e8_view
        
        return vec_4096d
    
    def test_dimensional_stability(self):
        """Test if norms are stable (not exploding) in 4096D."""
        print("\n" + "="*70)
        print("Dimensional Stability Test")
        print("="*70)
        
        # Test a single zero at different dimensions
        t_test = 14.134725
        sigma_test = 0.5
        
        print(f"\nTesting zero at t={t_test} across dimensions...")
        
        dimensions = [8, 16, 24, 32, 64, 128, 256, 512, 1024, 2048, 4096]
        norms = []
        
        for dim in dimensions:
            # Create embedding at this dimension
            vec = np.zeros(dim)
            num_e8 = dim // 8
            
            for i in range(num_e8):
                scale = 2 ** (i / (num_e8 / 8)) if num_e8 > 1 else 1.0
                e8_view = np.array([
                    sigma_test * scale,
                    t_test / scale,
                    np.sin(t_test / scale),
                    np.cos(t_test / scale),
                    (sigma_test - 0.5) * scale,
                    np.log(1 + t_test / scale),
                    np.exp(-t_test / (scale * 100)),
                    (t_test / (2*np.pi*scale)) % 1
                ])
                vec[i*8:(i+1)*8] = e8_view
            
            norm = np.linalg.norm(vec)
            norms.append(norm)
            
            print(f"  {dim:5d}D: norm = {norm:15.4f}")
        
        # Check if norm stabilizes (growth rate decreases)
        print("\n  Growth rates:")
        for i in range(1, len(norms)):
            growth = norms[i] / norms[i-1]
            print(f"    {dimensions[i-1]:5d}D → {dimensions[i]:5d}D: {growth:.4f}x")
        
        # Find where growth rate is closest to sqrt(dim_ratio)
        # (expected for stable random vectors)
        print("\n  Expected growth (if stable random):")
        for i in range(1, len(norms)):
            dim_ratio = dimensions[i] / dimensions[i-1]
            expected_growth = np.sqrt(dim_ratio)
            actual_growth = norms[i] / norms[i-1]
            deviation = abs(actual_growth - expected_growth) / expected_growth
            print(f"    {dimensions[i]:5d}D: expected {expected_growth:.4f}x, actual {actual_growth:.4f}x, deviation {deviation*100:.1f}%")
        
        return {
            "dimensions": dimensions,
            "norms": [float(n) for n in norms]
        }
    
    def test_critical_line_4096d(self):
        """Test critical line optimization in 4096D."""
        print("\n" + "="*70)
        print("Critical Line Optimization in 4096D")
        print("="*70)
        
        results = {
            "critical_line": [],
            "off_line": []
        }
        
        # Known zeros
        zeros_t = [14.134725, 21.022040, 25.010858, 30.424876, 32.935062]
        
        print("\n[1] Critical line zeros (σ=0.5)...")
        
        critical_norms = []
        for i, t in enumerate(zeros_t, 1):
            vec = self.embed_zero_4096d(0.5, t)
            norm = np.linalg.norm(vec)
            critical_norms.append(norm)
            
            # Calculate digital root of full 4096D vector
            dr = self.cqe.calculate_digital_root(np.sum(vec))
            valid = dr in [1, 3, 7]
            
            print(f"  Zero {i} (t={t:9.6f}): norm={norm:12.4f} DR={dr} valid={valid}")
            
            results["critical_line"].append({
                "index": i,
                "t": t,
                "norm": float(norm),
                "digital_root": int(dr),
                "valid": bool(valid)
            })
        
        # Off-critical line
        print("\n[2] Off-critical line points...")
        
        off_line_norms = {}
        for sigma in [0.3, 0.4, 0.6, 0.7]:
            norms_at_sigma = []
            
            for t in zeros_t:
                vec = self.embed_zero_4096d(sigma, t)
                norm = np.linalg.norm(vec)
                norms_at_sigma.append(norm)
            
            avg_norm = np.mean(norms_at_sigma)
            off_line_norms[sigma] = avg_norm
            
            dr = self.cqe.calculate_digital_root(int(sigma * 1000))
            valid = dr in [1, 3, 7]
            
            print(f"  σ={sigma}: avg_norm={avg_norm:12.4f} DR={dr} valid={valid}")
            
            results["off_line"].append({
                "sigma": sigma,
                "avg_norm": float(avg_norm),
                "digital_root": int(dr),
                "valid": bool(valid)
            })
        
        # Compare
        print("\n[3] Optimization analysis:")
        
        critical_avg = np.mean(critical_norms)
        off_critical_avg = np.mean(list(off_line_norms.values()))
        
        print(f"  Critical line (σ=0.5): {critical_avg:12.4f}")
        print(f"  Off-critical avg:       {off_critical_avg:12.4f}")
        print(f"  Ratio (off/critical):   {off_critical_avg/critical_avg:.6f}x")
        
        is_minimum = critical_avg < off_critical_avg
        print(f"  Critical line is minimum: {is_minimum}")
        
        results["summary"] = {
            "critical_avg_norm": float(critical_avg),
            "off_critical_avg_norm": float(off_critical_avg),
            "ratio": float(off_critical_avg / critical_avg),
            "critical_is_minimum": bool(is_minimum)
        }
        
        return results
    
    def analyze_sublattice_structure(self):
        """Analyze how zeros distribute across 512 E8 sublattices."""
        print("\n" + "="*70)
        print("E8 Sublattice Distribution Analysis")
        print("="*70)
        
        t = 14.134725
        vec_critical = self.embed_zero_4096d(0.5, t)
        vec_off = self.embed_zero_4096d(0.3, t)
        
        print(f"\nAnalyzing zero at t={t}...")
        print(f"  Comparing σ=0.5 (critical) vs σ=0.3 (off-line)")
        
        # Calculate norm in each E8 sublattice
        critical_sublattice_norms = []
        off_sublattice_norms = []
        
        for i in range(512):
            critical_e8 = vec_critical[i*8:(i+1)*8]
            off_e8 = vec_off[i*8:(i+1)*8]
            
            critical_sublattice_norms.append(np.linalg.norm(critical_e8))
            off_sublattice_norms.append(np.linalg.norm(off_e8))
        
        # Statistics
        critical_mean = np.mean(critical_sublattice_norms)
        critical_std = np.std(critical_sublattice_norms)
        off_mean = np.mean(off_sublattice_norms)
        off_std = np.std(off_sublattice_norms)
        
        print(f"\n  Critical line (σ=0.5):")
        print(f"    Mean sublattice norm: {critical_mean:.4f}")
        print(f"    Std deviation:        {critical_std:.4f}")
        
        print(f"\n  Off-line (σ=0.3):")
        print(f"    Mean sublattice norm: {off_mean:.4f}")
        print(f"    Std deviation:        {off_std:.4f}")
        
        print(f"\n  Difference:")
        print(f"    Mean ratio: {off_mean/critical_mean:.6f}")
        print(f"    Std ratio:  {off_std/critical_std:.6f}")
        
        # Find sublattices with largest difference
        differences = [abs(off_sublattice_norms[i] - critical_sublattice_norms[i]) 
                      for i in range(512)]
        top_indices = np.argsort(differences)[-10:][::-1]
        
        print(f"\n  Top 10 sublattices with largest difference:")
        for idx in top_indices:
            print(f"    Sublattice {idx:3d}: critical={critical_sublattice_norms[idx]:.4f}, "
                  f"off={off_sublattice_norms[idx]:.4f}, diff={differences[idx]:.4f}")
        
        return {
            "critical_mean": float(critical_mean),
            "critical_std": float(critical_std),
            "off_mean": float(off_mean),
            "off_std": float(off_std)
        }

def main():
    analyzer = Riemann4096DAnalyzer()
    
    # Test 1: Dimensional stability
    stability_results = analyzer.test_dimensional_stability()
    
    # Test 2: Critical line in 4096D
    critical_results = analyzer.test_critical_line_4096d()
    
    # Test 3: Sublattice structure
    sublattice_results = analyzer.analyze_sublattice_structure()
    
    # Combine results
    all_results = {
        "test_suite": "Riemann Hypothesis 4096D Analysis",
        "dimension": 4096,
        "num_e8_sublattices": 512,
        "stability": stability_results,
        "critical_line": critical_results,
        "sublattice_structure": sublattice_results
    }
    
    # Save
    with open("/home/ubuntu/riemann_4096d_results.json", 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print("\n" + "="*70)
    print("Results saved to: /home/ubuntu/riemann_4096d_results.json")
    print("="*70)
    
    # Conclusion
    print("\n" + "="*70)
    print("CONCLUSION")
    print("="*70)
    
    if critical_results["summary"]["critical_is_minimum"]:
        print("✓ Critical line IS minimum in 4096D")
        print(f"  Ratio: {critical_results['summary']['ratio']:.6f}x")
    else:
        print("✗ Critical line is NOT minimum in 4096D")
        print(f"  Ratio: {critical_results['summary']['ratio']:.6f}x")
    
    print(f"\nDimensional stability:")
    print(f"  Norms across dimensions: {stability_results['norms'][-3:]}")

if __name__ == "__main__":
    main()

