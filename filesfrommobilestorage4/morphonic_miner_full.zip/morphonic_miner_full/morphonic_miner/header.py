
from .utils import u32, from_be_hex

def header_bytes(version:int, prev_be_hex:str, merkle_be_hex:str, curtime:int, bits_u32:int, nonce:int)->bytes:
    prev_le = from_be_hex(prev_be_hex)
    merkle_le = from_be_hex(merkle_be_hex)
    return u32(version) + prev_le + merkle_le + u32(curtime) + u32(bits_u32) + u32(nonce)
