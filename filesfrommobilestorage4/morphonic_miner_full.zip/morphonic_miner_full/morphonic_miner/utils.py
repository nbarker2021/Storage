
import struct, hashlib

def u32(n): return struct.pack("<L", n)
def u64(n): return struct.pack("<Q", n)

def varint(n: int) -> bytes:
    if n < 0xfd: return bytes([n])
    if n <= 0xffff: return b"\xfd" + struct.pack("<H", n)
    if n <= 0xffffffff: return b"\xfe" + struct.pack("<I", n)
    return b"\xff" + struct.pack("<Q", n)

def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def sha256d(b: bytes) -> bytes:
    return sha256(sha256(b))

def hex_le(b: bytes) -> str:
    return b[::-1].hex()

def from_be_hex(h: str) -> bytes:
    return bytes.fromhex(h)[::-1]

def to_be_hex_lebytes(h_le: bytes) -> str:
    return h_le[::-1].hex()
