
import hashlib

def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def sha256d(b: bytes) -> bytes:
    return sha256(sha256(b))

class HeaderPrehash:
    def __init__(self, prefix76: bytes):
        assert len(prefix76) == 76
        self._h = hashlib.sha256()
        self._h.update(prefix76)

    def finalize_hash_hex(self, nonce_le4: bytes) -> str:
        h = self._h.copy(); h.update(nonce_le4)
        return hashlib.sha256(h.digest()).digest()[::-1].hex()
