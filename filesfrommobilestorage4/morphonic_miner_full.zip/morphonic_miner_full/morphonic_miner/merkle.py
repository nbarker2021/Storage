
from .utils import sha256d

def merkle_root_from_hashes_le(hashes_le_bytes):
    layer = list(hashes_le_bytes)
    if not layer:
        return bytes.fromhex("00"*32)
    while len(layer) > 1:
        if len(layer) & 1:
            layer.append(layer[-1])
        layer = [sha256d(layer[i] + layer[i+1]) for i in range(0, len(layer), 2)]
    return layer[0]
