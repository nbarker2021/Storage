
import os, secrets
from typing import List, Tuple, Dict, Any
from .utils import u32, u64, varint, sha256d, to_be_hex_lebytes, from_be_hex
from .merkle import merkle_root_from_hashes_le


def build_coinbase(height:int, payout_spk_hex:str, value_sat:int, extranonce:bytes=b"", witness_reserved:bytes=None, witness_commitment_script:bytes=None, segwit:bool=False)->Tuple[bytes,str,bytes]:
    version = u32(1)
    marker_flag = b""
    if segwit:
        marker_flag = b"\x00\x01"  # marker, flag for segwit

    # Inputs
    tx_in_count = b"\x01"
    prevout = b"\x00"*32 + b"\xff\xff\xff\xff"
    # BIP34 height push + extranonce in scriptSig
    h = height; h_bytes = b""
    while h>0: h_bytes += bytes([h & 0xff]); h >>= 8
    scriptSig = bytes([len(h_bytes)]) + h_bytes + extranonce
    if len(scriptSig) > 0xff:
        raise ValueError("coinbase scriptSig too large")
    scriptSig_len = bytes([len(scriptSig)])
    sequence = b"\xff\xff\xff\xff"

    # Outputs
    outputs = []
    # Payout
    spk = bytes.fromhex(payout_spk_hex)
    outputs.append( (value_sat, spk) )
    # Witness commitment (if segwit and provided)
    if segwit and witness_commitment_script:
        outputs.append( (0, witness_commitment_script) )

    tx_outs = b""
    for value, spk in outputs:
        tx_outs += u64(value) + bytes([len(spk)]) + spk

    # Witness (for coinbase: one stack item = witness_reserved 32B)
    witness = b""
    if segwit:
        wr = witness_reserved or b"\x00"*32
        witness = b"\x01" + bytes([len(wr)]) + wr  # 1 item, push 32 bytes

    locktime = u32(0)

    raw = version + marker_flag + tx_in_count + prevout + scriptSig_len + scriptSig + sequence + varint(len(outputs)) + tx_outs + witness + locktime
    txid = sha256d(raw if not segwit else (version + tx_in_count + prevout + scriptSig_len + scriptSig + sequence + varint(len(outputs)) + tx_outs + locktime))[::-1].hex()
    wtxid = sha256d(raw)[::-1].hex() if segwit else txid
    return raw, txid, bytes.fromhex(wtxid)

def compute_commitment(witness_reserved:bytes, wtxid_merkle_root_be_hex:str)->bytes:
    data = witness_reserved + bytes.fromhex(wtxid_merkle_root_be_hex)
    cm = sha256d(data)
    # OP_RETURN 0xaa21a9ed <32 bytes>
    return bytes.fromhex("6a24aa21a9ed") + cm

def assemble_from_template(tpl:Dict[str,Any], payout_spk_hex:str, extranonce32:bytes, use_mempool:bool=True, use_segwit:bool=True)->Tuple[str, str, str, str, str, List[str]]:
    # transactions array from GBT
    txs = tpl.get("transactions", []) if use_mempool else []
    # Collect tx hex (provided by template) and metadata
    tx_hex_list = [t["data"] for t in txs]
    txids_be = [t["txid"] for t in txs]
    wtxids_be = [t.get("hash", t["txid"]) for t in txs]  # 'hash' is wtxid if present

    # Witness commitment handling
    witness_reserved = secrets.token_bytes(32) if use_segwit else None
    default_commitment = tpl.get("default_witness_commitment")
    commitment_script = bytes.fromhex(default_commitment) if (use_segwit and default_commitment) else None

    # Coinbase value and height
    height = tpl["height"]
    coinbase_value = tpl.get("coinbasevalue", 0)

    # Build coinbase; if segwit and no commitment provided, we'll compute after building wtxid root
    coinbase_raw, coinbase_txid, coinbase_wtxid_le = build_coinbase(height, payout_spk_hex, coinbase_value, extranonce=extranonce32, witness_reserved=witness_reserved, witness_commitment_script=commitment_script, segwit=use_segwit)

    # Build merkle root of txids (coinbase first)
    txids_le = [bytes.fromhex(coinbase_txid)[::-1]] + [bytes.fromhex(h)[::-1] for h in txids_be]
    merkle_le = merkle_root_from_hashes_le(txids_le)
    merkle_be_hex = merkle_le[::-1].hex()

    # Build wtxid merkle if segwit
    wtxid_be_hex = None
    if use_segwit:
        cb_wtxid_be = coinbase_wtxid_le[::-1].hex()
        wtxids_full_be = [cb_wtxid_be] + wtxids_be
        wtxids_le = [bytes.fromhex(h)[::-1] for h in wtxids_full_be]
        wtx_merkle_le = merkle_root_from_hashes_le(wtxids_le)
        wtxid_be_hex = wtx_merkle_le[::-1].hex()
        if commitment_script is None:
            commitment_script = compute_commitment(witness_reserved, wtxid_be_hex)
            # Rebuild coinbase with commitment output now that we computed it
            coinbase_raw, coinbase_txid, coinbase_wtxid_le = build_coinbase(height, payout_spk_hex, coinbase_value, extranonce=extranonce32, witness_reserved=witness_reserved, witness_commitment_script=commitment_script, segwit=True)

    # Final tx list (coinbase first)
    tx_hex_final = [coinbase_raw.hex()] + tx_hex_list

    return coinbase_txid, merkle_be_hex, (wtxid_be_hex or ""), coinbase_raw.hex(), tx_hex_final, txids_be
