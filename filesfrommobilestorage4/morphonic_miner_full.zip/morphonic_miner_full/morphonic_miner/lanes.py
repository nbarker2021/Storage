
import random
try:
    import geometric_transformer_standalone as gts
except Exception:
    gts = None

class LaneSampler:
    def __init__(self, lane_id: str, seed: int = None):
        self.lane_id = lane_id
        self.rng = random.Random(seed or (hash(lane_id) & 0xffffffff))

    def sample_nonce_tranche(self, count: int, start: int = None):
        if gts and hasattr(gts, "project_vector"):
            nonces = []
            base = start if start is not None else self.rng.getrandbits(32)
            for i in range(count):
                v = [self.rng.random() for _ in range(8)]
                pv = gts.project_vector(v)
                n = (base + i + int(abs(sum(pv))*1e6)) & 0xffffffff
                nonces.append(n)
            return nonces
        else:
            base = start if start is not None else self.rng.getrandbits(32)
            return [ (base + i) & 0xffffffff for i in range(count) ]
