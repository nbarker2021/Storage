
try:
    from speedlight_sidecar import SpeedLight, SpeedLightDistributed
except Exception:
    SpeedLight = None
    SpeedLightDistributed = None

class CacheShim:
    def __init__(self):
        self._mem = {}
        self.sl = None
        if SpeedLightDistributed:
            try: self.sl = SpeedLightDistributed(namespace="morphonic_miner")
            except Exception: pass
        elif SpeedLight:
            try: self.sl = SpeedLight(namespace="morphonic_miner")
            except Exception: pass

    def compute_hash(self, key: str, fn, *args, **kwargs):
        if self.sl:
            return self.sl.compute_hash(key, fn, *args, **kwargs)
        if key in self._mem:
            return self._mem[key]
        v = fn(*args, **kwargs)
        self._mem[key] = v
        return v
