
import os, time
from .rpc import RPC
from .receipts import ReceiptWriter
from .speedlight_wrap import CacheShim
from .sha256mid import HeaderPrehash
from .header import header_bytes
from .assembler_segwit import assemble_from_template
from .lanes import LaneSampler

def bits_to_target(bits_u32:int)->int:
    exp = (bits_u32 >> 24) & 0xff
    mant = bits_u32 & 0x007fffff
    return mant * (1 << (8*(exp-3)))

class BackgroundMiner:
    def __init__(self, payout_spk_hex: str, nonces_per_slice=20000, sleep_between=0.25, lanes=8):
        self.rpc = RPC()
        self.receipts = ReceiptWriter()
        self.cache = CacheShim()
        self.payout_spk = payout_spk_hex
        self.nonces_per_slice = nonces_per_slice
        self.sleep_between = sleep_between
        self.lanes = [LaneSampler(f"lane-{i}") for i in range(lanes)]
        self.use_mempool = os.getenv("MM_USE_MEMPOOL", "1") != "0"
        self.use_segwit = os.getenv("MM_USE_SEGWIT", "1") != "0"

    def _template(self):
        return self.rpc.getblocktemplate()

    def run_once(self):
        try:
            tpl = self._template()
        except Exception as e:
            self.receipts.write({"event":"gblktpl_error","error":str(e)})
            time.sleep(5); return

        height = tpl["height"]
        prevhash_be = tpl["previousblockhash"]
        bits_u32 = tpl["bits"]
        version = tpl["version"]
        curtime = tpl["curtime"]

        extranonce = (int(time.time()*1000000) & 0xffffffff).to_bytes(4, "little")

        # Assemble block with coinbase, txs, merkle and (optional) witness commitment
        cb_txid, merkle_be, wtxid_be, cb_hex, tx_hex_list, txids_be = assemble_from_template(
            tpl, self.payout_spk, extranonce32=extranonce,
            use_mempool=self.use_mempool, use_segwit=self.use_segwit
        )

        # Prepare header prehash (first 76 bytes)
        hdr_prefix = header_bytes(version, prevhash_be, merkle_be, curtime, bits_u32, 0)[:76]
        pre = HeaderPrehash(hdr_prefix)
        target = bits_to_target(bits_u32)
        best = None

        # Mine nonces in lanes
        for lane in self.lanes:
            for n in lane.sample_nonce_tranche(self.nonces_per_slice):
                hhex = pre.finalize_hash_hex(n.to_bytes(4,"little"))
                hval = int(hhex,16)
                if best is None or hval < best: best = hval
                if hval <= target:
                    hdr_full = header_bytes(version, prevhash_be, merkle_be, curtime, bits_u32, n)
                    # Raw block = header + varint(tx_count) + each tx hex
                    from .utils import varint
                    block_hex = hdr_full.hex() + varint(len(tx_hex_list)).hex() + "".join(tx_hex_list)
                    self.receipts.write({
                        "event":"found_block_candidate",
                        "height":height,"prev":prevhash_be,"merkle":merkle_be,"wtxid_root":wtxid_be,
                        "bits":bits_u32,"nonce":n,"hash":hhex,"coinbase_txid":cb_txid,
                        "raw_block_len":len(block_hex)//2,"lane":lane.lane_id,"txs":len(tx_hex_list)
                    })
                    try:
                        res = self.rpc.submitblock(block_hex)
                        self.receipts.write({"event":"submitblock","result":res or "accepted","hash":hhex})
                    except Exception as e:
                        self.receipts.write({"event":"submit_error","error":str(e)})
                    return

        self.receipts.write({
            "event":"slice_done","height":height,"prev":prevhash_be,"merkle":merkle_be,
            "best_hash_bits": (256 - best.bit_length()) if best else None,
            "nonces_tried": self.nonces_per_slice * len(self.lanes),
            "txs": len(tx_hex_list)
        })

    def run_forever(self):
        while True:
            self.run_once()
            time.sleep(self.sleep_between)
