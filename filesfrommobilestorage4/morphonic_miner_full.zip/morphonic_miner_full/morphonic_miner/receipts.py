
import os, json
from datetime import datetime

class ReceiptWriter:
    def __init__(self, path=None):
        self.path = path or os.getenv("MM_RECEIPTS", "./miner_receipts.jsonl")

    def write(self, obj: dict):
        obj = dict(obj)
        obj.setdefault("ts", datetime.utcnow().isoformat()+"Z")
        with open(self.path, "a") as f:
            f.write(json.dumps(obj, sort_keys=True)+"\n")
        return obj
