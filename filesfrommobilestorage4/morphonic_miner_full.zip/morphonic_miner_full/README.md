
# Morphonic Miner — Full System (SegWit‑aware, receipts‑first, lanes, cache‑ready)

This is a complete, runnable background solo‑miner/assembler that:
- polls `getblocktemplate`, assembles **coinbase + mempool txs**,
- handles **SegWit witness commitment** (either uses GBT's `default_witness_commitment` or computes it),
- prehashes the 76‑byte header prefix for faster hashing in Python,
- explores nonces in **lanes** (8 by default; morphonic transform supported if your module is available),
- writes JSONL **receipts** for every slice and every found candidate,
- integrates with **SpeedLight** cache if `speedlight_sidecar.py` is on your PYTHONPATH (automatic fallback otherwise).

## Install & Run
1) Unzip next to this README. Ensure Python 3.10+.
2) Export env vars (example):
```
export BTC_RPC_USER=rpcuser
export BTC_RPC_PASS=rpcpass
export BTC_RPC_HOST=127.0.0.1
export BTC_RPC_PORT=8332
export PAYOUT_SCRIPT_HEX=76a914000000000000000000000000000000000000000088ac
export MM_USE_MEMPOOL=1
export MM_USE_SEGWIT=1
export NONCES_PER_SLICE=20000
export SLEEP_BETWEEN_SLICES=0.25
export MM_LANES=8
```
3) Run:
```
python -m morphonic_miner.run_miner
```

## Notes on correctness
- When `MM_USE_SEGWIT=1`, the assembler will include/compute the **witness commitment** and place it in the coinbase output (OP_RETURN). The coinbase includes a 32‑byte witness reserved value in its witness stack. The wtxid merkle root is built from the coinbase wtxid and all included tx wtxids (GBT's `transactions[].hash` when present). If the template supplies `default_witness_commitment`, we will use it directly; otherwise we compute it.
- If you prefer a minimal, fee‑less mode, set `MM_USE_MEMPOOL=0` and it will mine a coinbase‑only block (still valid, simpler).

## Receipts
Receipts go to `./miner_receipts.jsonl` (override with `MM_RECEIPTS`). Each slice records:
- template boundary conditions (height, prev, bits, curtime),
- merkle/witness roots,
- best hash observed and bits,
- lane id, nonces tried,
- tx count, coinbase txid,
- submit result if a candidate meets target.

## Service (systemd example)
Edit `systemd/morphonic-miner.service` with your paths and credentials, then:
```
mkdir -p ~/.config/systemd/user
cp systemd/morphonic-miner.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now morphonic-miner.service
journalctl --user -u morphonic-miner -f
```
