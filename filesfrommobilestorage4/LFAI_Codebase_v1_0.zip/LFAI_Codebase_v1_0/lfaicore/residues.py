from typing import List, Dict
def residues(vec: List[int], mods: List[int]) -> Dict[int, List[int]]:
    return {m:[v % m for v in vec] for m in mods}
