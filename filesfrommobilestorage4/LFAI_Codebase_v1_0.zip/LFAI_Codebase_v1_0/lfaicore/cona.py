from typing import List, Tuple
import numpy as np
H = np.array([
    [1,1,1,1,1,1,1,1],
    [1,1,1,1,0,0,0,0],
    [1,1,0,0,1,1,0,0],
    [1,0,1,0,1,0,1,0],
], dtype=int)
def syndrome(bits: List[int]) -> List[int]:
    b = np.array(bits, dtype=int) % 2
    return list(map(int, (H @ b) % 2))
def wt(v: List[int]) -> int: return sum(1 for x in v if x%2==1)
def bits_from_vec(vec: List[int]) -> List[int]: return [v & 1 for v in vec]
def legal_even(vec: List[int]) -> Tuple[bool, List[int]]:
    s = syndrome(bits_from_vec(vec)); return (wt(s)==0, s)
def even_neighbor(vec: List[int]) -> List[int]:
    return list(vec) if sum(vec)%2==0 else [vec[0]+1,*vec[1:]]
