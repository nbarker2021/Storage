from typing import List
def face_functionals(vec: List[int]) -> List[float]:
    n=len(vec); s=sum(vec) or 1
    return [
        (vec[0] if n>0 else 0)/s, (vec[1] if n>1 else 0)/s, (vec[2] if n>2 else 0)/s, (vec[3] if n>3 else 0)/s,
        (sum(vec[:4])/s), (sum(vec[4:])/s), ((max(vec)-min(vec)) if n>0 else 0)/s, (len([v for v in vec if v%2==0]) / (n or 1))
    ]
def latch_sweep(vec: List[int], eps: float=0.0) -> List[int]:
    return [1 if v>=-eps else 0 for v in face_functionals(vec)]
