See codebase; CLI usage in README delivered earlier.
