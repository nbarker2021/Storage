def test_bitwrap_involution():
    from lfaicore.bitwrap import bitwrap_pi4
    data = bytes(range(256))
    assert bitwrap_pi4(bitwrap_pi4(data)) == data

def test_octet_runs():
    from examples.moving_avg_octet import moving_avg_octet
    out = moving_avg_octet(1,2,3,4,0,0,0,0)
    assert out["ok"] and len(out["out"])==8
