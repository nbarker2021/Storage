import json, os, hashlib, time
LEDGER_PATH = "/mnt/data/lfai_ledger.jsonl"

def _last_hash():
    if not os.path.exists(LEDGER_PATH): return "GENESIS"
    last=None
    with open(LEDGER_PATH,"r",encoding="utf-8") as f:
        for line in f: 
            if line.strip(): last=json.loads(line)
    return last["hash"] if last else "GENESIS"

def append(obj: dict) -> str:
    prev=_last_hash()
    entry={"ts": time.time(), "prev": prev, "op": obj}
    h=hashlib.sha256(json.dumps(entry, sort_keys=True, default=str).encode()).hexdigest()
    entry["hash"]=h
    with open(LEDGER_PATH,"a",encoding="utf-8") as f:
        f.write(json.dumps(entry)+"\n")
    return h

def read_all(limit: int = 500):
    if not os.path.exists(LEDGER_PATH): return []
    out=[]
    with open(LEDGER_PATH,"r",encoding="utf-8") as f:
        for line in f:
            if line.strip():
                out.append(json.loads(line))
    return out[-limit:]

def verify_chain():
    prev="GENESIS"
    for e in read_all(10_000):
        expect=hashlib.sha256(json.dumps({"ts":e["ts"],"prev":e["prev"],"op":e["op"]}, sort_keys=True, default=str).encode()).hexdigest()
        if e["prev"]!=prev or expect!=e["hash"]:
            return False
        prev=e["hash"]
    return True

def append_paint(seq):
    return append({"op":"paint","seq": seq})

def get_paint_timeline(limit: int = 100):
    return [e for e in read_all(limit) if isinstance(e.get("op"), dict) and e["op"].get("op")=="paint"]
