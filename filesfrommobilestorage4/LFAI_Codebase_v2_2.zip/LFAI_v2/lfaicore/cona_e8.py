from typing import List, Tuple
def constructionA_E8_check(v8: List[int]) -> Tuple[bool, list]:
    even = sum(x & 1 for x in v8) == 0
    return (even, [0,0,0,0] if even else [1,0,1,0])
