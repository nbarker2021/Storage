import json, os, hashlib, math
from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class Pouch:
    size: int
    stick_threshold: float = 0.66
    drip_threshold: float = 0.48
    parity_pref: float = 0.50

@dataclass
class Bucket:
    name: str
    order: int = 1
    persona: str = "GEN"
    scenario: str = "Default"
    pouches: Dict[int, Pouch] = field(default_factory=dict)
    flip_drive_quarter: bool = True
    flip_repr_eighth: bool = True

def default_buckets():
    return [
        Bucket(name="NAV-Bucket", order=1, persona="NAV", scenario="Nav_EDL",
               pouches={s: Pouch(size=s) for s in range(1,9)}),
        Bucket(name="MAT-Bucket", order=2, persona="MAT", scenario="Materials",
               pouches={s: Pouch(size=s, stick_threshold=0.70) for s in range(1,8)}),
        Bucket(name="BIO-Bucket", order=3, persona="BIO", scenario="Codon",
               pouches={s: Pouch(size=s, stick_threshold=0.68) for s in range(1,9)}),
        Bucket(name="GEN-Bucket", order=4, persona="GEN", scenario="General",
               pouches={s: Pouch(size=s, stick_threshold=0.62) for s in range(1,9)}),
    ]

CFG_PATH="/mnt/data/buckets_config.json"

def load_buckets(path: str = CFG_PATH) -> List[Bucket]:
    if not os.path.exists(path):
        return default_buckets()
    cfg=json.loads(open(path,"r",encoding="utf-8").read())
    out=[]
    for b in cfg.get("buckets", []):
        pouches={int(k): Pouch(size=int(k), **v) for k,v in b.get("pouches",{}).items()}
        out.append(Bucket(name=b["name"], order=b.get("order",1), persona=b.get("persona","GEN"),
                          scenario=b.get("scenario","Default"), pouches=pouches,
                          flip_drive_quarter=bool(b.get("flip_drive_quarter", True)),
                          flip_repr_eighth=bool(b.get("flip_repr_eighth", True))))
    return out
