from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Any, Dict, Optional

from lfaicore.ingress import ingress_state
from lfaicore.octet import anchor_hash
from lfaicore.runtime import OctetExecutor
from lfaicore.unfold import unfold
from lfaicore.buckets import load_buckets, CFG_PATH, default_buckets
from lfaicore.planner import plan
from lfaicore.ledger_merkle import append, read_all, verify_chain, append_paint, get_paint_timeline

app = FastAPI(title="LFAI v2.2 API", version="2.2.0")

class IngressBody(BaseModel):
    vector: List[float]

@app.post("/ingress")
def ingress(b: IngressBody):
    return ingress_state(b.vector)

class OctetRunBody(BaseModel):
    module: str
    fn: Optional[str] = None
    lanes: List[Any]

@app.post("/octet/run")
def octet_run(b: OctetRunBody):
    import importlib
    mod = importlib.import_module(b.module)
    fn = getattr(mod, b.fn) if b.fn else getattr(mod, "moving_avg_octet")
    exe = OctetExecutor()
    if len(b.lanes)!=8:
        return JSONResponse({"error":"lanes must be 8"}, status_code=400)
    return exe.run(fn, tuple(b.lanes))

class UnfoldRunBody(BaseModel):
    module: str
    fn: Optional[str] = None
    variants: List[List[Any]]

@app.post("/unfold/run")
def unfold_run(b: UnfoldRunBody):
    import importlib
    mod = importlib.import_module(b.module)
    fn = getattr(mod, b.fn) if b.fn else getattr(mod, "moving_avg_octet")
    return unfold(fn, [tuple(v) for v in b.variants])

class PlannerRunBody(BaseModel):
    tokens: List[str]
    max_iters: Optional[int] = 5

@app.post("/planner/run")
def planner_run(b: PlannerRunBody):
    buckets = load_buckets(CFG_PATH)
    return plan(b.tokens, buckets=buckets, max_iters=b.max_iters or 5)

@app.get("/planner/config")
def planner_get():
    import os, json
    if not os.path.exists(CFG_PATH):
        return {"buckets":[{"name":bk.name,"order":bk.order,"persona":bk.persona,"scenario":bk.scenario,
                            "pouches":{str(s):{"stick_threshold":p.stick_threshold,"drip_threshold":p.drip_threshold,"parity_pref":p.parity_pref}
                                       for s,p in bk.pouches.items()}}
                           for bk in default_buckets()]}
    return json.loads(open(CFG_PATH,"r",encoding="utf-8").read())

class PlannerCfgBody(BaseModel):
    config: Dict[str, Any]

@app.put("/planner/config")
def planner_put(b: PlannerCfgBody):
    import json
    open(CFG_PATH,"w",encoding="utf-8").write(json.dumps(b.config, indent=2))
    return {"ok": True}

class CommitBody(BaseModel):
    payload: Dict[str, Any]

@app.post("/commit/atomic")
def commit_atomic(b: CommitBody):
    h = append({"op":"commit","payload": b.payload})
    return {"ok": True, "hash": h}

class ProofStateBody(BaseModel):
    vector: List[float]

@app.post("/proof/state")
def proof_state(b: ProofStateBody):
    st = ingress_state(b.vector)
    h = append({"op":"proof_state","pal4_ok": st["pal4_ok"], "legal_e8": st["legal_e8"]})
    st["chain_ok"] = verify_chain()
    st["ledger_hash"] = h
    return st

class PaintAppendBody(BaseModel):
    seq: List[str]

@app.post("/ledger/paint")
def ledger_paint_append(b: PaintAppendBody):
    h = append_paint(b.seq)
    return {"hash": h}

@app.get("/ledger/paint")
def ledger_paint_get(limit: int = 50):
    return {"events": get_paint_timeline(limit=limit)}

@app.get("/ledger/read")
def ledger_read(limit: int = 100):
    return {"entries": read_all(limit), "chain_ok": verify_chain()}
