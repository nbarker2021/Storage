import zlib
from lfaicore.octet import octet

@octet(bitwrap="pi4", involution=False, faces="GEN")
def crc32_octet(x0,x1,x2,x3,p4,p8,r,f):
    bs = bytes(int(b)&0xFF for b in [x0,x1,x2,x3])
    c = zlib.crc32(bs) & 0xFFFFFFFF
    y0 = (c >> 24) & 0xFF
    y1 = (c >> 16) & 0xFF
    y2 = (c >> 8) & 0xFF
    y3 = c & 0xFF
    return y0,y1,y2,y3, p4, p8, r, f
