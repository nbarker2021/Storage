
import time
from agrm.snap_tools.stitch import stitch
def write_promotion_summary(repo, um, universe, iterations, delivered, reason):
    sid = f"promo_summary::{universe}::{int(time.time())}"
    repo.save(sid, {"meta":{"snap_id":sid,"family":"report","type":"promotion","tags":{"universe":universe}},
                    "content":{"delivered":delivered,"reason":reason,"iters":len(iterations)}})
    stitch(repo, um, universe=universe, family="metric", type_="summary",
           content={"iters": len(iterations), "delivered": delivered})
    return sid, {}
