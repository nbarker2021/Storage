
from collections import defaultdict
from typing import Dict, Any, List

def build_index(repo) -> Dict[str,Any]:
    idx = {"by_universe": defaultdict(list), "by_family": defaultdict(list), "by_type": defaultdict(list)}
    for k in repo.keys():
        obj = repo.load(k)
        meta = obj.get("meta", {})
        uv  = (meta.get("tags") or {}).get("universe") or "Global"
        fam = meta.get("family"); typ = meta.get("type")
        idx["by_universe"][uv].append(k)
        idx["by_family"][fam].append(k)
        idx["by_type"][typ].append(k)
    # convert default dicts to normal dicts
    idx["by_universe"] = {k:v for k,v in idx["by_universe"].items()}
    idx["by_family"] = {k:v for k,v in idx["by_family"].items()}
    idx["by_type"] = {k:v for k,v in idx["by_type"].items()}
    return idx
