
import time, uuid
def begin_trail(repo, universe: str, label: str, cfg):
    tid = f"trail://{universe}/events/{int(time.time()*1000)}/{uuid.uuid4().hex[:8]}"
    repo.save(tid, {"meta":{"snap_id":tid,"family":"trail","type":"events","tags":{"universe":universe}},
                    "content":{"label":label,"cfg":cfg,"events":[]}})
    return tid
def append_event(repo, trail_id: str, event: dict):
    obj = repo.load(trail_id); obj["content"]["events"].append(event); repo.save(trail_id, obj)
def finalize(repo, um, universe: str, trail_id: str, summary: dict):
    obj = repo.load(trail_id); obj["content"]["summary"] = summary; repo.save(trail_id, obj)
