
import time, uuid, random, json
from typing import Dict, Any, Iterable
from agrm.snapcore.config import DEFAULTS
from agrm.snapcore.schema import registry

class SnapEmitter:
    def __init__(self, repo, um):
        self.repo = repo; self.um = um
        self.counters = {}  # universe -> {"events": int}
    def _budget_ok(self, universe: str) -> bool:
        c = self.counters.setdefault(universe, {"events":0})
        limit = (DEFAULTS.get("budgets") or {}).get(universe, {}).get("events_k", 1000000)
        return c["events"] < int(limit)*1000
    def _inc(self, universe: str):
        self.counters.setdefault(universe, {"events":0})
        self.counters[universe]["events"] += 1
    def _should_sample(self) -> bool:
        return random.random() < float(DEFAULTS.get("sample", 1.0))
    def _snap_id(self, universe: str, family: str, type_: str) -> str:
        return f"snap://{universe}/{family}/{type_}/{int(time.time()*1000)}/{uuid.uuid4().hex[:8]}"
    def emit(self, *, universe: str, family: str, type_: str, content: Dict[str,Any], tags: Dict[str,Any] | None=None,
             parents: Iterable[str] = (), policy_hash: str | None=None) -> str | None:
        if family in set(DEFAULTS.get("deny_families", [])): return None
        if not self._budget_ok(universe): return None
        if not self._should_sample() and DEFAULTS.get("level","digest")!="full": return None
        snap_id = self._snap_id(universe, family, type_)
        meta = {"snap_id": snap_id, "family": family, "type": type_, "tags": dict(tags or {}), "parents": list(parents),
                "policy_hash": policy_hash, "ts": int(time.time()*1000)}
        obj = {"meta": meta, "content": content}
        # Validate schema presence only (light)
        if registry.get(family, type_) is None:
            registry.register(family, type_, {"required":["meta","content"]})
        self.repo.save(snap_id, obj)
        self._inc(universe)
        return snap_id

emitter_singleton = None
def get_emitter(repo, um) -> SnapEmitter:
    global emitter_singleton
    if emitter_singleton is None:
        emitter_singleton = SnapEmitter(repo, um)
    return emitter_singleton

class trail:
    def __init__(self, repo, um, universe: str, label: str, cfg: Dict[str,Any] | None=None):
        self.repo = repo; self.um = um; self.universe = universe; self.label = label; self.cfg = cfg or {}
        self.trail_id = None
    def __enter__(self):
        em = get_emitter(self.repo, self.um)
        self.trail_id = em.emit(universe=self.universe, family="trail", type_="events",
                                content={"label": self.label, "cfg": self.cfg, "events":[]}, tags={"universe": self.universe})
        return self
    def event(self, event: Dict[str,Any]):
        obj = self.repo.load(self.trail_id); obj["content"]["events"].append(event); self.repo.save(self.trail_id, obj)
    def finalize(self, summary: Dict[str,Any]):
        obj = self.repo.load(self.trail_id); obj["content"]["summary"] = summary; self.repo.save(self.trail_id, obj)
    def __exit__(self, exc_type, exc, tb):
        if self.trail_id and exc:
            self.event({"event":"error","err": str(exc)})
        return False  # do not suppress
