
DEFAULTS = {
  "level": "digest",   # minimal | digest | full
  "sample": 0.25,      # probability in [0,1]
  "ttl_days": 30,
  "budgets": {
    "Governance": {"bytes_mb": 500, "events_k": 50},
    "Finance":    {"bytes_mb": 800, "events_k": 80}
  },
  "redact": ["pii.email", "pii.phone"],
  "deny_families": ["secrets"],
  "required_tags": ["family","type","w5h","glyph"]
}
