
from typing import Iterable, Dict, Any
from agrm.snapcore.emitter import get_emitter

def stitch(repo, um, *, universe: str, family: str, type_: str, content: Dict[str,Any], parents: Iterable[str] = ()):
    em = get_emitter(repo, um)
    return em.emit(universe=universe, family=family, type_=type_, content=content, tags={"universe": universe}, parents=parents)

def amend(repo, um, *, universe: str, prior_snap_id: str, content: Dict[str,Any]):
    em = get_emitter(repo, um)
    return em.emit(universe=universe, family="amend", type_="correction", content={"prior": prior_snap_id, "content": content}, tags={"universe": universe}, parents=[prior_snap_id])

def define_type(repo, um, *, universe: str, family: str, type_: str, schema: Dict[str,Any]):
    em = get_emitter(repo, um)
    return em.emit(universe=universe, family="schema", type_="register", content={"family": family, "type": type_, "schema": schema}, tags={"universe": universe})
