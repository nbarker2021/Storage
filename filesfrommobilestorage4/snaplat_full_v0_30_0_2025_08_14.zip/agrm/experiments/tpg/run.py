
from typing import Dict, Any
from agrm.experiments.tpg.build import build_graph
from agrm.snapcore.decorators import instrument

def _path_cost(costs, path): return sum(costs[path[i]][path[i+1]] for i in range(len(path)-1))

def _analyze(graph, path_ix):
    overlaps = graph["overlaps"]; thr = float(graph.get("imperf_threshold", 0.8)); leaks = graph.get("leak_mask")
    imperfections=0; leak_edges=0; edges=[]
    for k in range(len(path_ix)-1):
        i,j = path_ix[k], path_ix[k+1]
        ov = overlaps[i][j]
        if ov < thr: imperfections += 1
        if leaks and leaks[i][j]: leak_edges += 1
        edges.append({"i":i,"j":j,"overlap":ov,"imperfect": bool(ov<thr)})
    return imperfections, leak_edges, edges

@instrument(family="tpg", type_="run", universe_key="universe")
def run_tpg(summary: Dict[str,Any], *, cfg: Dict[str,Any], repo=None, um=None, universe: str="Global") -> Dict[str,Any]:
    g = build_graph(summary, max_nodes=int((cfg or {}).get("max_nodes",24)),
                    imperf_threshold=float((cfg or {}).get("imperf_threshold",0.8)),
                    repo=repo, um=um, universe=universe)
    # Greedy-by-heat order as a placeholder path
    metas = g["metas"]; nodes = g["nodes"]; costs = g["costs"]
    order = sorted(range(len(nodes)), key=lambda ix: -float(metas[nodes[ix]].get("heat",0.0)))
    cost = _path_cost(costs, order)
    imperfections, leak_edges, edges = _analyze(g, order)
    return {"path": order, "cost": float(cost), "imperfections": int(imperfections), "leak_edges": int(leak_edges),
            "complete": True, "nodes":[list(n) for n in nodes], "node_metas":[metas[n] for n in nodes], "edges": edges}
