
import numpy as np
from typing import Dict, Any
from agrm.snapcore.decorators import instrument

@instrument(family="controller", type_="solve", universe_key="universe")
def _solve_impl(points, metas=None, *, universe="Global", repo=None, um=None) -> Dict[str,Any]:
    N = len(points); K = min(40, max(10, N//10)); idx = np.linspace(0, N-1, K, dtype=int)
    rooms=[]; rng = np.random.default_rng(20250814)
    families = [m.get("family","misc") for m in (metas or [{}]*N)]
    types    = [m.get("type","note") for m in (metas or [{}]*N)]
    for r,i in enumerate(idx):
        floor = int(r % 5); fam = families[i]; typ = types[i]
        rooms.append({"id":[f"doc{i}", f"floor{floor}", f"room{r}"],
                      "heat": float(abs(points[i][0]) + abs(points[i][1])) + float(rng.random()*0.1),
                      "tags":{"family":fam,"type":typ,"w5h":{"who":0.15,"what":0.2,"where":0.1,"when":0.2,"why":0.2,"how":0.15},
                              "glyph": f"{fam}::{typ}"}})
    rooms_sorted = sorted(rooms, key=lambda r: -r["heat"]); elevs=[]
    for i in range(len(rooms_sorted)-1):
        a = rooms_sorted[i]["id"]; b = rooms_sorted[i+1]["id"]; score = 0.6 + 0.4*(i/len(rooms_sorted))
        elevs.append({"a": a, "b": b, "score": score})
    telemetry = {"candidates_emitted": len(rooms_sorted)}
    return {"mdhg":{"rooms": rooms, "elevators": elevs}, "telemetry": telemetry}

class AGRMController_v0_7_2025_08_13:
    def __init__(self, cfg: Dict[str,Any], repo, policies: Dict[str,Any], um):
        self.cfg = cfg; self.repo = repo; self.um = um
    def solve(self, points, metas=None) -> Dict[str,Any]:
        return _solve_impl(points, metas, universe=self.cfg.get("universe","Global"), repo=self.repo, um=self.um)
