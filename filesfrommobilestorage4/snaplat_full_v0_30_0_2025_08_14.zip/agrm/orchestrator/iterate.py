
from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import time, random
from agrm.spine.controller_v0_7 import AGRMController_v0_7_2025_08_13
from agrm.agrm.elevator_promotion import promote_elevators
from agrm.utils.promo_summary import write_promotion_summary
from agrm.snap.trails import begin_trail, append_event, finalize
from agrm.snap_tools.stitch import stitch
from agrm.experiments.tpg.run import run_tpg

@dataclass
class IterationResult:
    summary: Dict[str,Any]; promotion: Dict[str,Any]; tpg: Dict[str,Any] | None; hint_used: bool; bridge_qa_coverage: float
@dataclass
class IterativeReport:
    iterations: List[IterationResult]; delivered: bool; reason: str; summary_snap: str | None; hints: List[str]; trail_id: str | None

def run_iterations(points, metas, *, repo, um, base_cfg: Dict[str,Any], universe: str,
                   max_iters: int = 3, min_promoted: int = 1, promotion_threshold: float = None,
                   compat_policy: Dict[str,Any] = None, stability_eps: float = 0.05,
                   invariant_mode: str = "warn", geom: str = "bimodal",
                   scoring_cfg: Dict[str,Any] = None) -> IterativeReport:
    results: List[IterationResult] = []; last_rate: Optional[float] = None; delivered=False; reason="max_iters_reached"
    trail_id = begin_trail(repo, universe=universe, label="iteration", cfg={"base_cfg": base_cfg, "scoring": scoring_cfg or {}})
    tpg_cfg = (base_cfg.get("tpg") or {})
    use_tpg = bool(tpg_cfg.get("enabled", False))
    hint_canary = float(((tpg_cfg.get("hint") or {}).get("canary", 0.0)) if use_tpg else 0.0)
    if use_tpg:
        append_event(repo, trail_id, {"event":"tpg_config","cfg":tpg_cfg})
    for it in range(1, max_iters+1):
        cfg = dict(base_cfg); cfg["universe"] = universe
        ctl = AGRMController_v0_7_2025_08_13(cfg=cfg, repo=repo, policies={}, um=um)
        summary = ctl.solve(points, metas=metas)
        tpg_report = None; hint_used=False; bridge_qa_coverage=0.0
        if use_tpg:
            tpg_report = run_tpg(summary, cfg=tpg_cfg, repo=repo, um=um, universe=universe)
            append_event(repo, trail_id, {"event":"tpg","iter":it,"imperfections": tpg_report.get("imperfections",0),"cost": float(tpg_report.get("cost",0.0))})
        thr = promotion_threshold if promotion_threshold is not None else cfg.get("mdhg",{}).get("elevator_score_min", 0.5)
        prom = promote_elevators(repo, um, universe, threshold=float(thr), compat_policy=compat_policy or {}, scoring_cfg=scoring_cfg or {})
        stitch(repo, um, universe=universe, family="metric", type_="iter", content={"iter": it, "promoted": prom.get("promoted",0)})
        results.append(IterationResult(summary=summary, promotion=prom, tpg=tpg_report, hint_used=hint_used, bridge_qa_coverage=bridge_qa_coverage))
        promoted = int(prom.get("promoted", 0)); total = promoted + int(prom.get("rejected",0)); rate = (promoted / max(1,total)) if total>0 else 0.0
        if promoted >= min_promoted and abs((last_rate or 0.0) - rate) < stability_eps:
            delivered=True; reason="stable_promotion_rate"; break
        last_rate = rate
    rid = f"iter_report::{universe}::{int(time.time())}"
    repo.save(rid, {"meta":{"snap_id": rid, "family":"iterative","type":"report","tags":{"universe":universe}},
                    "content":{"delivered": delivered, "reason": reason, "iterations":[{"summary": r.summary, "promotion": r.promotion, "tpg": r.tpg, "hint_used": r.hint_used, "bridge_qa_coverage": r.bridge_qa_coverage} for r in results]}})
    summary_snap = None
    try:
        summary_snap, _ = write_promotion_summary(repo, um, universe, iterations=[{"summary": r.summary, "promotion": r.promotion} for r in results], delivered=delivered, reason=reason)
    except Exception:
        pass
    finalize(repo, um, universe=universe, trail_id=trail_id, summary={"delivered": delivered, "reason": reason})
    return IterativeReport(iterations=results, delivered=delivered, reason=reason, summary_snap=summary_snap, hints=[], trail_id=trail_id)
