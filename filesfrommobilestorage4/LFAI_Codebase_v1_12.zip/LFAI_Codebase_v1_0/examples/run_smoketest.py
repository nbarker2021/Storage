import os, csv, json, random, hashlib

from lfaicore.residues import residues as residues_for_mods
from lfaicore.pal import pal_defects
from lfaicore.gating import face_functionals, latch_sweep
from lfaicore.cona_e8 import constructionA_E8_check
from lfaicore.reducer import reduce_to_rest

def read_helix_csv(path='/mnt/data/helix10_embedding.csv'):
    if not os.path.exists(path):
        return None
    with open(path,'r',newline='') as f:
        r=csv.reader(f)
        rows=[row for row in r if row]
    for row in rows:
        try:
            vec = [int(float(x)) for x in row[:10]]
            return vec
        except Exception:
            continue
    return None

def frame_obj():
    return {"mods":[2,4,8,13], "rest_scale": 8}

def frame_hash(f):
    return hashlib.sha256(json.dumps(f, sort_keys=True).encode()).hexdigest()

def make_anchor(vec, f):
    h = hashlib.sha256(json.dumps({"vec":vec,"mods":f["mods"],"scale":f["rest_scale"]}, sort_keys=True).encode()).hexdigest()
    return h

def run():
    vec = read_helix_csv() or [random.randint(-600, 1000) for _ in range(10)]
    f = frame_obj()
    res = residues_for_mods(vec, f["mods"])
    legal, synd = constructionA_E8_check(vec[:8])
    pd = pal_defects(vec)
    faces = face_functionals(vec)
    latches = latch_sweep(vec)
    aid = make_anchor(vec, f)
    red = reduce_to_rest(vec)
    out = {
        "vec10": vec,
        "frame": f,
        "residues_mods": res,
        "legal_even_vec8": {"legal": bool(legal), "syndrome_bits": synd},
        "pal_defects_vec10": pd,
        "faces_vec10": faces,
        "latches_vec10": latches,
        "anchor_id": aid,
        "reduced": red
    }
    return out

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
