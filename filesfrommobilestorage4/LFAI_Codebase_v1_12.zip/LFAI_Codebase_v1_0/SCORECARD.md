# Build Scorecard (v1.10)
Overall: **9.1 / 10**

Upgrades:
- True **Construction-A → E8** legality check added.
- **Ledger proofs**: inclusion verification + `/replay/prove`.
- **Contract verify**: `/contracts/verify` for chainpack round-trip.
- **Domain face packs** (NAV/MAT/BIO) + bench harness.
- **Security**: HMAC Auth middleware + structured logs.

Remaining for 10/10:
- Full **Leech** slice (Golay G24) with proofs.
- Batch-roots scheduler & replay certificates in every response.
- Domain benchmark suites + ROC publication.
- Auth scopes, rate limits, server-side signatures.
