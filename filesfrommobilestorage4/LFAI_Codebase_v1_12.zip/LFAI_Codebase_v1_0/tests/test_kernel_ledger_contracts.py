def test_constructionA_E8_check():
    from lfaicore.cona_e8 import constructionA_E8_check
    # vector with even parity pattern should often pass
    legal, synd = constructionA_E8_check([0,0,0,0,0,0,0,0])
    assert legal and sum(synd)==0
    illegal, _ = constructionA_E8_check([1,0,0,0,0,0,0,0])
    assert not illegal

def test_verify_inclusion_roundtrip(tmp_path):
    from lfaicore.ledger_merkle import MerkleLedger, verify_inclusion
    p = tmp_path/"ops.log"
    led = MerkleLedger(str(p))
    h1 = led.append({"op":"verify","vec":[1,2,3,4]})
    root = led.root()
    proof = led.proof(0)
    assert verify_inclusion(root, proof["siblings"], h1, 0)

def test_contracts_verify_roundtrip():
    from lfaicore.blockchain import export_chainpack, verify_chainpack
    b = export_chainpack("a"*64, "b"*64, 8, [1,0,0,1,1,0,1,0], {"P4":0,"P8":0})
    assert verify_chainpack(b)

def test_facepacks_shapes():
    from lfaicore.facepacks import PACKS
    vec=[1,2,3,4,5,6,7,8]
    for name,fn in PACKS.items():
        out = fn(vec)
        assert len(out)==8
