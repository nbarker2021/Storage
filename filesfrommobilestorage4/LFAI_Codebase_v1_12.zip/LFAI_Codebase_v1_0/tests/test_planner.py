def test_planner_basic():
    from lfaicore.buckets import load_buckets
    from lfaicore.planner import plan
    buckets = load_buckets()
    out = plan([f"T{i}" for i in range(20)], buckets, max_iters=3)
    assert "iterations" in out and isinstance(out["iterations"], list)
    # after a few iters, we should have some sticks or <=4 unsettled
    assert any(sum(len(v) for v in it["sticks"].values()) > 0 for it in out["iterations"]) or len(out["unsettled"])<=4
