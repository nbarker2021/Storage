import sys; sys.path.insert(0, '/mnt/data/LFAI_Codebase_v1_0')
import json, random
from lfaicore.planner import plan
from lfaicore.buckets import default_buckets

def dry_run(seed=7, N=40):
    rnd = random.Random(seed)
    # synth tokens (strings); in practice these are doc ids or feature keys
    tokens = [f"TOK_{i}_{rnd.randint(0,9999)}" for i in range(N)]
    buckets = default_buckets()
    out = plan(tokens, buckets, max_iters=5)
    # Summaries
    iters = out["iterations"]
    summary = []
    for i,shot in enumerate(iters):
        sticks = {k: len(v) for k,v in shot["sticks"].items()}
        summary.append({"iter": i+1, "sticks": sticks, "drips": len(shot["drips"]), "misses": len(shot["misses"])})
    final_clusters = {k: len(v) for k,v in out["final_clusters"].items()}
    result = {"summary": summary, "unsettled_count": len(out["unsettled"]), "final_clusters": final_clusters}
    print(json.dumps(result, indent=2))
    return out, result

if __name__ == "__main__":
    dry_run()
