# Quick bench harness for faces and legality
import random, time, json
from lfaicore.facepacks import PACKS
from lfaicore.gating import face_functionals
from lfaicore.cona_e8 import constructionA_E8_check

def run(n=1000, seed=42):
    r = random.Random(seed)
    rows = []
    t0 = time.time()
    for _ in range(n):
        vec = [r.randint(0,31) for _ in range(16)]
        base = face_functionals(vec)
        scores = {name: sum(func(vec)) for name,func in PACKS.items()}
        legal,_ = constructionA_E8_check(vec[:8])
        rows.append({"legal": int(legal), "base": sum(base), **scores})
    dt = time.time()-t0
    ok = sum(x["legal"] for x in rows)
    return {"n": n, "dt_sec": dt, "legal_rate": ok/n, "avg_base": sum(x["base"] for x in rows)/n, "avg_PACKS": {k: sum(x[k] for x in rows)/n for k in PACKS}}

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
