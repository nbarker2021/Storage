import json, hashlib, binascii, time
from typing import Dict, Any, List, Tuple

def _sha256_hex(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

def merkle_root_hex(items: List[bytes]) -> str:
    if not items:
        return _sha256_hex(b'')
    layer = [bytes.fromhex(_sha256_hex(x)) for x in items]
    while len(layer) > 1:
        if len(layer) % 2 == 1:
            layer.append(layer[-1])
        nxt = []
        for i in range(0, len(layer), 2):
            nxt.append(bytes.fromhex(_sha256_hex(layer[i] + layer[i+1])))
        layer = nxt
    return layer[0].hex()

def pack_proof_bundle(anchor_id: str, frame_hash: str, rest_scale: int, latches: List[int], pal: Dict[str,int], extras: Dict[str,Any]=None) -> Dict[str,Any]:
    bundle = {
        "type":"LFAI-ProofBundle",
        "ver":"1.0",
        "ts": int(time.time()),
        "anchor_id": anchor_id,
        "frame_hash": frame_hash,
        "rest_scale": rest_scale,
        "latches": latches,
        "pal": {"P4": pal.get("P4",0), "P8": pal.get("P8",0)},
        "extras": extras or {}
    }
    raw = json.dumps(bundle, sort_keys=True).encode()
    bundle["bundle_sha256"] = _sha256_hex(raw)
    return bundle

# ---- EIP-712 typed-data (no signing) ----
def eip712_for_bundle(bundle: Dict[str,Any], chainId: int=1, verifyingContract: str="0x0000000000000000000000000000000000000000") -> Dict[str,Any]:
    types = {
        "EIP712Domain":[
            {"name":"name","type":"string"},
            {"name":"version","type":"string"},
            {"name":"chainId","type":"uint256"},
            {"name":"verifyingContract","type":"address"},
        ],
        "Proof":[
            {"name":"anchor_id","type":"bytes32"},
            {"name":"frame_hash","type":"bytes32"},
            {"name":"rest_scale","type":"uint256"},
            {"name":"latches","type":"uint8[8]"},
            {"name":"P4","type":"uint256"},
            {"name":"P8","type":"uint256"},
            {"name":"bundle_sha256","type":"bytes32"}
        ]
    }
    def as32(hx): 
        hx = hx.lower().replace("0x","")
        return "0x"+hx.zfill(64)
    message = {
        "anchor_id": as32(bundle["anchor_id"][:64]),
        "frame_hash": as32(bundle["frame_hash"][:64]),
        "rest_scale": int(bundle["rest_scale"]),
        "latches": [int(x) for x in (bundle.get("latches") or [0]*8)][:8] + [0]*max(0,8-len(bundle.get("latches",[]))),
        "P4": int(bundle["pal"]["P4"]),
        "P8": int(bundle["pal"]["P8"]),
        "bundle_sha256": as32(bundle["bundle_sha256"][:64]),
    }
    domain = {"name":"LFAI","version":"1","chainId":chainId,"verifyingContract":verifyingContract}
        raw = json.dumps(b, sort_keys=True).encode()
    cid = cid_v1_raw_b32(raw)
    return {"types": types, "primaryType":"Proof", "domain": domain, "message": message}

# ---- Bitcoin OP_RETURN (hex string) ----
def op_return_hex(bundle: Dict[str,Any], prefix: bytes=b"LFAI:") -> str:
    data = prefix + json.dumps(bundle, sort_keys=True).encode()
    # Truncate to typical 80-byte OP_RETURN payload limit; adjust as needed
    payload = data[:80]
    return binascii.hexlify(payload).decode()

# ---- Simple ABI calldata (keccak4 selector + packed fields) ----
def abi_calldata(bundle: Dict[str,Any]) -> str:
    # function record(bytes32 anchor, bytes32 frame, uint256 rest, uint8[8] l, uint256 P4, uint256 P8, bytes32 bsha)
    import hashlib
    import struct
    import itertools
    sig = b"record(bytes32,bytes32,uint256,uint8[8],uint256,uint256,bytes32)"
    selector = hashlib.sha3_256(sig).digest()[:4]  # keccak-256 in py3.11; in py3.10, this is placeholder
    def to32(hx):
        hx = hx.lower().replace("0x","")
        return bytes.fromhex(hx.zfill(64))
    enc = bytearray()
    enc += selector
    enc += to32(bundle["anchor_id"][:64])
    enc += to32(bundle["frame_hash"][:64])
    enc += int(bundle["rest_scale"]).to_bytes(32,'big')
    l = (bundle.get("latches") or [0]*8)[:8] + [0]*max(0,8-len(bundle.get("latches",[])))
    enc += bytes(l) + bytes(32-8)  # pad to 32
    enc += int(bundle["pal"]["P4"]).to_bytes(32,'big')
    enc += int(bundle["pal"]["P8"]).to_bytes(32,'big')
    enc += to32(bundle["bundle_sha256"][:64])
    return "0x"+enc.hex()

def cid_v1_raw_b32(payload: bytes) -> str:
    # multicodec raw=0x55, multihash sha2-256 code=0x12 length=32
    import base64
    def varint(n):
        out=b''
        while True:
            towrite = n & 0x7f
            n >>= 7
            if n:
                out += bytes([towrite | 0x80])
            else:
                out += bytes([towrite])
                break
        return out
    import hashlib
    mh = bytes([0x12, 32]) + hashlib.sha256(payload).digest()
    cid_bytes = varint(1) + varint(0x55) + mh
    b32 = base64.b32encode(cid_bytes).decode('utf-8').lower().rstrip('=')
    return 'b'+b32

def export_chainpack(anchor_id: str, frame_hash: str, rest_scale: int, latches: List[int], pal: Dict[str,int]) -> Dict[str,Any]:
    b = pack_proof_bundle(anchor_id, frame_hash, rest_scale, latches, pal)
        raw = json.dumps(b, sort_keys=True).encode()
    cid = cid_v1_raw_b32(raw)
    return {
        "bundle": b,
        "eip712": eip712_for_bundle(b),
        "op_return_hex": op_return_hex(b),
        "abi_calldata": abi_calldata(b),
        "merkle_root": merkle_root_hex([raw]),
        "cid_v1_raw": cid,
    }

def verify_chainpack(pack: Dict[str,Any]) -> bool:
    # Recompute bundle_sha256 and compare
    b = dict(pack.get("bundle") or {})
    if not b: return False
    calc = _sha256_hex(json.dumps({k:b[k] for k in b if k!="bundle_sha256"}, sort_keys=True).encode())
    return calc == b.get("bundle_sha256")
