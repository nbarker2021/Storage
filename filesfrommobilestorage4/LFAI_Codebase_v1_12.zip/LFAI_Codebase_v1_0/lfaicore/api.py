from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from .frame import compile_from_glyphs, Frame
from .cona import legal_even, bits_from_vec
from .pal import pal_defects
from .uplift import uplift_u2
from .gating import latch_sweep
from .reducer import reduce_to_rest
from .anchors import anchor_id
from .paint import paint8, palette, parity_paint, neon_palette, hue_shift_hex

app = FastAPI(title="LFAI Legality-First API", version="1.10.0")
from prometheus_fastapi_instrumentator import Instrumentator
Instrumentator().instrument(app).expose(app)

class FrameIn(BaseModel):
    glyphs: List[int] = Field(default_factory=lambda:[8,13,32])

class VecIn(BaseModel):
    vec: List[int]
    glyphs: Optional[List[int]] = None
    hue_shift: Optional[int] = 0
    parity_levels: Optional[List[str]] = None
    steps: Optional[int] = 1

@app.post("/frame")
def make_frame(body: FrameIn):
    f = compile_from_glyphs(body.glyphs)
    return {"frame_hash": f.hash(), "rest_scale": f.rest_scale, "dyadic_depth": f.dyadic_depth, "mods": f.mods, "faces": f.faces}

@app.post("/verify")
def verify(body: VecIn):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    legal, s = legal_even(body.vec)
    pd = pal_defects(body.vec)
    latch = latch_sweep(body.vec)
    verdict = "OPEN" if (legal and pd["P4"]==0 and pd["P8"]==0) else "PROVISIONAL_OPEN"
    return {"vec": body.vec, "bits": bits_from_vec(body.vec), "syndrome": s, "pal": pd, "latches": latch, "verdict": verdict}

@app.post("/uplift")
def uplift(body: VecIn):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    vec = list(body.vec)
    steps = int(body.steps or 1)
    for _ in range(steps):
        vec, f = uplift_u2(vec, f)
    return {"vec": vec, "rest_scale": f.rest_scale, "dyadic_depth": f.dyadic_depth, "mods": f.mods}

@app.post("/gate/scan")
def gate_scan(body: VecIn):
    latch = latch_sweep(body.vec)
    return {"latches": latch, "ready_to_advance": all(latch)}

@app.post("/advance")
def advance(body: VecIn):
    latch = latch_sweep(body.vec)
    return {"advanced": bool(all(latch)), "latches": latch}

@app.post("/anchor/match")
def anchor_match(body: VecIn):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    aid, bits = anchor_id(body.vec, f)
    return {"anchor_id": aid,
        "paint8": paint8(body.vec, f.hash()),
        "palette": palette(),
        "parity_paint": parity_paint(body.vec, f.hash(), levels=(body.parity_levels or ["mod2","mod4","mod8"])),
        "neon_palettes": {"hex16": neon_palette("hex16"), "mod2": neon_palette("mod2"), "mod4": neon_palette("mod4"), "mod8": neon_palette("mod8")},
        "channels": {"grayscale": grayscale_strip(body.vec, space='core:proof'), "groups": lie_cartan_tags(f.mods), "resonance": resonance_tags(body.vec)}, "bounds_sig": bits}

from .pal import pal_defects
from .blockchain import export_chainpack

class ConvertBody(BaseModel):
    vec: List[int]
    glyphs: Optional[List[int]] = None
    hue_shift: Optional[int] = 0
    parity_levels: Optional[List[str]] = None

@app.post("/convert/blockchain")
def convert_blockchain(body: ConvertBody):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    aid, latches = anchor_id(body.vec, f)
    pal = pal_defects(body.vec)
    return export_chainpack(aid, f.hash(), f.rest_scale, latches, pal)

class ProofBody(BaseModel):
    vec: List[int]
    glyphs: Optional[List[int]] = None
    hue_shift: Optional[int] = 0
    parity_levels: Optional[List[str]] = None

@app.post("/proof/state")
def proof_state(body: ProofBody):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    legal, s = legal_even(body.vec)
    pd = pal_defects(body.vec)
    latch = latch_sweep(body.vec)
    aid, bits = anchor_id(body.vec, f)
    return {
        "frame_hash": f.hash(),
        "rest_scale": f.rest_scale,
        "dyadic_depth": f.dyadic_depth,
        "mods": f.mods,
        "syndrome": s,
        "pal": {"P4": pd["P4"], "P8": pd["P8"]},
        "phi": [int(sum(s)), int(pd["P8"]), int(pd["P4"]), 0],
        "latches": latch,
        "anchor_id": aid,
        "paint8": paint8(body.vec, f.hash()),
        "palette": palette(),
        "parity_paint": parity_paint(body.vec, f.hash(), levels=(body.parity_levels or ["mod2","mod4","mod8"])),
        "neon_palettes": {"hex16": neon_palette("hex16"), "mod2": neon_palette("mod2"), "mod4": neon_palette("mod4"), "mod8": neon_palette("mod8")},
        "channels": {"grayscale": grayscale_strip(body.vec, space='core:proof'), "groups": lie_cartan_tags(f.mods), "resonance": resonance_tags(body.vec)},
        "bounds_sig": bits,
        "morse": morse_from_hex(aid[:16]),
        "haptic_ms": haptic_pattern(aid[:16]),
        "seismo": seismo_texture(aid[:32])
        "verdict": "OPEN" if (legal and pd["P4"]==0 and pd["P8"]==0) else "PROVISIONAL_OPEN"
    }

from .contracts import gae, cec
from .pal import pal_defects
from .blockchain import export_chainpack

@app.post("/contracts")
def contracts(body: ProofBody):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    aid, bits = anchor_id(body.vec, f)
    pd = pal_defects(body.vec)
    ngd = {"thresholds": ["repr_1_8","drive_1_4"], "scale_family": f.rest_scale, "residues": f.mods, "faces": ["octad"], "witnesses": ["pal","syndrome"]}
    G = gae("token", ngd, f.rest_scale, f.dyadic_depth, max([m for m in f.mods if m & (m-1)==0]))
    C = cec(G["ngd_sha256"], bits, {"theta4": pd["P4"], "theta8": pd["P8"]})
    chain = export_chainpack(aid, f.hash(), f.rest_scale, bits, {"P4": pd["P4"], "P8": pd["P8"]})
    chain['bundle']['extras']['paint8'] = paint8(body.vec, f.hash())
    return {"gae": G, "cec": C, "chainpack": chain}

from typing import Any
class ReplayBody(BaseModel):
    ops: List[Dict[str,Any]]
    glyphs: Optional[List[int]] = None
    hue_shift: Optional[int] = 0
    parity_levels: Optional[List[str]] = None

@app.post("/replay/verify")
def replay_verify(body: ReplayBody):
    from .ledger_merkle import replay_ops, MerkleLedger
    out = replay_ops(body.ops, glyphs=body.glyphs or [8,13,32])
    return out

from .journal import write as journal_write, summary as journal_summary
from .paint import grayscale_strip, lie_cartan_tags, resonance_tags, morse_from_hex, haptic_pattern, seismo_texture

class JournalWrite(BaseModel):
    field: str
    vec: List[int]
    glyphs: Optional[List[int]] = None
    meta: Optional[Dict[str,Any]] = None

@app.post("/journal/write")
def journal_write_api(body: JournalWrite):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    rec = journal_write(body.field, body.vec, f.hash(), {"mods": f.mods, **(body.meta or {})})
    return rec

@app.get("/journal/summary")
def journal_summary_api(field: str, limit: int = 50):
    return journal_summary(field, limit=limit)

class ReplayProveBody(BaseModel):
    ops: List[Dict[str,Any]]
    proof: Dict[str,Any]  # {root, siblings[], index, leaf_hash}
    glyphs: Optional[List[int]] = None

@app.post("/replay/prove")
def replay_prove(body: ReplayProveBody):
    from .ledger_merkle import replay_ops, verify_inclusion
    out = replay_ops(body.ops, glyphs=body.glyphs or [8,13,32])
    ok = verify_inclusion(body.proof["root"], body.proof["siblings"], body.proof["leaf_hash"], int(body.proof["index"]))
    return {"replay": out, "inclusion_ok": ok}

class ContractVerifyBody(BaseModel):
    pack: Dict[str,Any]

@app.post("/contracts/verify")
def contracts_verify(body: ContractVerifyBody):
    from .blockchain import verify_chainpack
    return {"ok": verify_chainpack(body.pack)}

from fastapi import Request
import os, hmac, hashlib, json, logging

logger = logging.getLogger("lfai")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

API_KEYS = {}
try:
    _env = os.environ.get("LFAI_API_KEYS","{}")
    API_KEYS = json.loads(_env) if _env else {}
except Exception:
    API_KEYS = {}

@app.middleware("http")
async def hmac_auth(request: Request, call_next):
    # If no keys configured, allow all.
    if not API_KEYS:
        return await call_next(request)
    key_id = request.headers.get("X-LFAI-Key")
    sig = request.headers.get("X-LFAI-Sig")
    if not key_id or not sig or key_id not in API_KEYS:
        return JSONResponse({"error":"auth required"}, status_code=401)
    body = await request.body()
    mac = hmac.new(API_KEYS[key_id].encode(), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(mac, sig):
        return JSONResponse({"error":"bad signature"}, status_code=401)
    resp = await call_next(request)
    return resp

class PlannerRunBody(BaseModel):
    tokens: List[str]
    glyphs: Optional[List[int]] = None
    config_path: Optional[str] = None
    max_iters: Optional[int] = 5

@app.post("/planner/run")
def planner_run(body: PlannerRunBody):
    from .buckets import load_buckets, default_buckets
    from .planner import plan
    cfg_path = body.config_path or "/mnt/data/buckets_config.json"
    buckets = load_buckets(cfg_path)
    out = plan(body.tokens, buckets, max_iters=int(body.max_iters or 5))
    return out

@app.get("/planner/config")
def planner_config_get():
    try:
        txt = open("/mnt/data/buckets_config.json","r",encoding="utf-8").read()
        return json.loads(txt)
    except Exception:
        from .buckets import default_buckets
        return {"note":"using defaults"}

class PlannerConfigSetBody(BaseModel):
    config: Dict[str, Any]

@app.put("/planner/config")
def planner_config_put(body: PlannerConfigSetBody):
    open("/mnt/data/buckets_config.json","w",encoding="utf-8").write(json.dumps(body.config, indent=2))
    return {"ok": True}

class PaintAppendBody(BaseModel):
    seq: List[str]

@app.post("/ledger/paint")
def ledger_paint_append(body: PaintAppendBody):
    from .ledger_merkle import append_paint
    h = append_paint(body.seq)
    return {"hash": h}

@app.get("/ledger/paint")
def ledger_paint_get(limit: int = 50):
    from .ledger_merkle import get_paint_timeline
    return {"events": get_paint_timeline(limit=limit)}
