from typing import List, Dict, Any, Tuple
from .cona_e8 import constructionA_E8_check
from .pal import pal_defects
from .gating import latch_sweep, face_functionals

def fold8(vec: List[int]) -> List[int]:
    v=[0]*8
    for i,x in enumerate(vec):
        v[i%8]+=int(x)
    return v

def reduce_to_rest(vec: List[int]) -> Dict[str,Any]:
    v8 = fold8(vec)
    legal, synd = constructionA_E8_check(v8)
    pal = pal_defects(vec)
    faces = face_functionals(vec)
    latches = latch_sweep(vec)
    steps=0
    # naive single-step "reduction": if illegal, flip the smallest-magnitude coord parity
    if not legal:
        idx = min(range(len(v8)), key=lambda i: abs(v8[i]))
        v8[idx] ^= 1  # parity tweak demo; real system uses proper rewrite
        steps += 1
        legal2, synd2 = constructionA_E8_check(v8)
    else:
        legal2, synd2 = legal, synd
    return {"v8": v8, "legal": bool(legal2), "syndrome": synd2, "pal": pal, "faces": faces, "latches": latches, "steps": steps}
