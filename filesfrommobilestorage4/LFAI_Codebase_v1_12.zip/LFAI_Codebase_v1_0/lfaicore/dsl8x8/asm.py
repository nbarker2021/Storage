import struct, base64
OPCODES={'NOP':0o00,'SET_TAU_REPR_1_8':0o01,'SET_TAU_DRIVE_1_4':0o02,'PROMOTE_SCALE':0o03,'ADD_MOD_13':0o04,'ADD_MOD_5':0o05,'ADD_MOD_7':0o06,'ADD_MOD_11':0o07,'LIFT_EVEN':0o10,'CALC_PAL':0o11,'REDUCE_STEP':0o12,'LATCH_SWEEP':0o13,'ADVANCE_IF_ALL_LATCHED':0o14,'UPLIFT_U2_K':0o15,'SET_FACE_TIMING_13':0o16,'SET_FACE_OCTAD':0o17,'EMBED_TEXT':0o20,'EMBED_BYTES':0o21,'BEGIN_BLOCK':0o22,'END_BLOCK':0o23,'PIN_REQUIRE':0o24,'PIN_SATISFY':0o25,'STORE_ANCHOR':0o30,'OUTPUT_STATE':0o31,'SET_REST_SCALE_2':0o40,'SET_REST_SCALE_4':0o41,'SET_REST_SCALE_8':0o42,'SET_REST_SCALE_16':0o43,'SET_REST_SCALE_64':0o44}
def assemble(lines):
  out=bytearray()
  for line in lines:
    line=line.strip()
    if not line or line.startswith('#'): continue
    parts=line.split(' ',1); op=parts[0]; arg=parts[1] if len(parts)>1 else ''
    if op not in OPCODES: raise ValueError(f'Unknown op {op}')
    out.append(OPCODES[op])
    if op=='UPLIFT_U2_K':
      out += int(arg.strip()).to_bytes(2,'big')
    elif op in ('EMBED_TEXT','PIN_REQUIRE','PIN_SATISFY'):
      b=arg.encode('utf-8'); out+=len(b).to_bytes(2,'big'); out+=b
    elif op=='EMBED_BYTES':
      b=base64.b64decode(arg.strip()); out+=len(b).to_bytes(2,'big'); out+=b
  return bytes(out)
def disassemble(buf: bytes):
  i=0; INV={v:k for k,v in OPCODES.items()}; out=[]
  while i<len(buf):
    op=buf[i]; i+=1; name=INV.get(op, f'UNK_{oct(op)}')
    if name=='UPLIFT_U2_K':
      k=int.from_bytes(buf[i:i+2],'big'); i+=2; out.append(f'{name} {k}')
    elif name in ('EMBED_TEXT','PIN_REQUIRE','PIN_SATISFY','EMBED_BYTES'):
      L=int.from_bytes(buf[i:i+2],'big'); i+=2; b=buf[i:i+L]; i+=L
      if name=='EMBED_BYTES':
        import base64; out.append(f'{name} {base64.b64encode(b).decode()}')
      else:
        out.append(f'{name} {b.decode("utf-8","replace")}')
    else:
      out.append(name)
  return '\n'.join(out)
