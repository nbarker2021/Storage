from .planner import Bucket, Pouch

def default_buckets():
    # NAV persona: prefers even parity ~0.6; MAT persona: stricter stick; BIO parity ~0.5
    nav = Bucket(name="NAV-Bucket", order=1, persona="NAV", scenario="Nav_EDL",
                 pouches={s: Pouch(size=s, stick_threshold=0.66, drip_threshold=0.48, parity_pref=0.60) for s in range(1,9)},
                 flip_drive_quarter=True, flip_repr_eighth=True)
    mat = Bucket(name="MAT-Bucket", order=2, persona="MAT", scenario="Materials_Phase",
                 pouches={s: Pouch(size=s, stick_threshold=0.70, drip_threshold=0.50, parity_pref=0.55) for s in range(1,9)},
                 flip_drive_quarter=True, flip_repr_eighth=True)
    bio = Bucket(name="BIO-Bucket", order=3, persona="BIO", scenario="Codon_Duplex",
                 pouches={s: Pouch(size=s, stick_threshold=0.68, drip_threshold=0.48, parity_pref=0.50) for s in range(1,9)},
                 flip_drive_quarter=False, flip_repr_eighth=True)
    gen = Bucket(name="GEN-Bucket", order=4, persona="GEN", scenario="General",
                 pouches={s: Pouch(size=s, stick_threshold=0.62, drip_threshold=0.45, parity_pref=0.50) for s in range(1,9)},
                 flip_drive_quarter=False, flip_repr_eighth=True)
    return [nav, mat, bio, gen]

import json, os
from typing import List

def load_buckets(cfg_path: str = "/mnt/data/buckets_config.json") -> List[Bucket]:
    if not os.path.exists(cfg_path):
        return default_buckets()
    cfg = json.loads(open(cfg_path,"r",encoding="utf-8").read())
    out = []
    for b in cfg.get("buckets", []):
        pouches = {int(s): Pouch(size=int(s),
                                 stick_threshold=float(p.get("stick_threshold",0.66)),
                                 drip_threshold=float(p.get("drip_threshold",0.48)),
                                 parity_pref=float(p.get("parity_pref",0.5)))
                   for s,p in b.get("pouches", {}).items()}
        out.append(Bucket(name=b["name"], order=int(b.get("order",1)), pouches=pouches,
                          flip_drive_quarter=bool(b.get("flip_drive_quarter", False)),
                          flip_repr_eighth=bool(b.get("flip_repr_eighth", True)),
                          persona=b.get("persona","GEN"), scenario=b.get("scenario","Default")))
    return out
