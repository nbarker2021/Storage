from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple
import hashlib, random

from .gating import face_functionals, latch_sweep
from .cona_e8 import constructionA_E8_check

# --- Utilities ---
def hash_to_int(s: str) -> int:
    return int(hashlib.sha256(s.encode()).hexdigest()[:8], 16)

def token_to_vec(token: str, k: int = 8) -> List[int]:
    # deterministic 8D int vector from token string
    h = hashlib.sha256(token.encode()).hexdigest()
    return [int(h[i:i+2], 16) for i in range(0, 2*k, 2)]

def force_tuples(tokens: List[str], sizes=(1,2,3,4,5,6,7,8)) -> Dict[int, List[List[str]]]:
    out = {s: [] for s in sizes}
    rnd = random.Random(42)
    pool = tokens[:]
    rnd.shuffle(pool)
    idx = 0
    for s in sizes:
        while idx + s <= len(pool):
            out[s].append(pool[idx:idx+s])
            idx += s
    # any leftover tokens are placed as singles
    if idx < len(pool):
        out[1].extend([[t] for t in pool[idx:]])
    return out

# --- Probabilistic context reviewer ---
LABELS = ["NAV", "MAT", "BIO", "FIN", "GEN"]

def context_review(tuple_tokens: List[str]) -> Dict[str, float]:
    # produce pseudo probabilities based on hash buckets
    h = hashlib.sha256(("|".join(tuple_tokens)).encode()).hexdigest()
    base = [int(h[i:i+2], 16) for i in range(0, 10, 2)]
    # softmax-like normalization over first 5 labels
    s = sum(base) + 1e-9
    probs = [b / s for b in base]
    return {lab: p for lab,p in zip(LABELS, probs)}

# --- Buckets and Pouches ---
@dataclass
class Pouch:
    size: int
    stick_threshold: float = 0.65
    drip_threshold: float = 0.45  # [drip_threshold, stick_threshold) = DRIP
    parity_pref: float = 0.5      # target fraction-even

@dataclass
class Bucket:
    name: str
    order: int
    pouches: Dict[int, Pouch] = field(default_factory=dict)
    flip_drive_quarter: bool = False
    flip_repr_eighth: bool = True
    persona: str = "GEN"
    scenario: str = "Default"

    def pouch_for(self, size: int) -> Pouch:
        return self.pouches.get(size) or self.pouches.get(8) or Pouch(size=8)

# --- Adhesion score ---
def adhesion_score(vec: List[int], pouch: Pouch) -> float:
    legal, _ = constructionA_E8_check(vec[:8])
    faces = face_functionals(vec)
    frac_even = faces[3]  # from gating: fraction-even
    latch = sum(latch_sweep(vec)) / 8.0
    parity_closeness = 1.0 - abs(frac_even - pouch.parity_pref)
    score = 0.4 * (1.0 if legal else 0.0) + 0.3 * latch + 0.3 * parity_closeness
    return score

# --- Throw operation ---
def throw(buckets: List[Bucket], tuple_map: Dict[int, List[List[str]]]) -> Dict[str, Any]:
    sticks = {b.name: [] for b in buckets}
    drips, misses = [], []
    for size, tuples in tuple_map.items():
        for tup in tuples:
            vec = token_to_vec("|".join(tup))
            # choose candidate buckets by persona-prior from context review
            prior = context_review(tup)
            # sort buckets by persona match (simple score)
            ranked = sorted(buckets, key=lambda b: prior.get(b.persona, 0.0), reverse=True)
            placed = False
            for b in ranked:
                p = b.pouch_for(size)
                s = adhesion_score(vec, p)
                if s >= p.stick_threshold:
                    sticks[b.name].append({"tuple": tup, "score": s, "size": size})
                    placed = True
                    break
                elif s >= p.drip_threshold:
                    drips.append({"tuple": tup, "score": s, "size": size})
                    placed = True
                    break
            if not placed:
                misses.append({"tuple": tup, "score": 0.0, "size": size})
    return {"sticks": sticks, "drips": drips, "misses": misses}

# --- Iterative planner loop ---
def plan(tokens: List[str], buckets: List[Bucket], max_iters: int = 4) -> Dict[str, Any]:
    unsettled = tokens[:]
    iters = []
    for it in range(max_iters):
        tmap = force_tuples(unsettled)
        shot = throw(buckets, tmap)
        iters.append(shot)
        # gather residue (drips + misses) for next round
        unsettled = ["|".join(x["tuple"]) for x in (shot["drips"] + shot["misses"])]
        if len(unsettled) <= 4:
            break
    # binary-ready clusters are the sticks from the last round
    final_clusters = iters[-1]["sticks"] if iters else {}
    return {"iterations": iters, "unsettled": unsettled, "final_clusters": final_clusters}

# --- Paint gate & residue routing & binary splitter ---
from .paint import parity_paint

def paint_gate(vec, frame_hash: str = "planner", min_len: int = 8) -> bool:
    # gate requires non-empty parity paints for mod2/mod4/mod8 of at least min_len
    pp = parity_paint(vec, frame_hash, length=min_len)
    return all(pp.get(k) and all(len(seq)>=min_len for seq in pp[k]) for k in ("mod2","mod4","mod8"))

def residue_route(tuple_tokens: List[str], prior: Dict[str,float]) -> str:
    # route residue to the next-best persona; fallback GEN
    ranked = sorted(LABELS, key=lambda k: prior.get(k,0.0), reverse=True)
    if len(ranked)>=2: return ranked[1]
    return "GEN"

def binary_split(cluster: List[List[str]]) -> Dict[str, Any]:
    # Deterministic split by mod4 class of hash nibble of first tuple
    left, right = [], []
    for tup in cluster:
        key = "|".join(tup)
        h = hashlib.sha256(key.encode()).hexdigest()[0]
        cls = int(h,16) % 4
        (left if cls < 2 else right).append(tup)
    return {"left": left, "right": right}
