import os, json, time
from typing import Dict, Any, List
from .paint import paint8, grayscale_strip, parity_paint, lie_cartan_tags

JDIR = "/tmp/lfai_journals"

def _path(field: str) -> str:
    os.makedirs(JDIR, exist_ok=True)
    return os.path.join(JDIR, f"{field}.jsonl")

def write(field: str, vec: List[int], frame_hash: str, meta: Dict[str,Any]) -> Dict[str,Any]:
    rec = {
        "ts": time.time(),
        "vec": vec,
        "frame": frame_hash,
        "paint8": paint8(vec, frame_hash, space=f"journal:{field}"),
        "gray": grayscale_strip(vec, space=f"journal:{field}", new_token=False, length=32),
        "parity": parity_paint(vec, frame_hash, space=f"journal:{field}", length=16),
        "groups": lie_cartan_tags(meta.get("mods", [])),
        "meta": meta,
    }
    with open(_path(field),"a",encoding="utf-8") as f:
        f.write(json.dumps(rec, sort_keys=True) + "\n")
    return rec

def summary(field: str, limit: int = 100) -> Dict[str,Any]:
    p = _path(field)
    if not os.path.exists(p):
        return {"field": field, "count": 0, "samples": []}
    lines = open(p,"r",encoding="utf-8").read().strip().splitlines()[-limit:]
    samples = [ json.loads(ln) for ln in lines ]
    return {"field": field, "count": len(samples), "samples": samples}
