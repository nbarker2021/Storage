from typing import List
import math

def _safe_div(a: float, b: float) -> float:
    return a / b if b != 0 else 0.0

def face_functionals(vec: List[int]) -> List[float]:
    """Permutation-invariant faces.
    f1 mean/sum, f2 variance normalized, f3 range normalized,
    f4 fraction even, f5 fraction > mean, f6 l2 norm normalized,
    f7 pal P4 norm, f8 pal P8 norm.
    """
    n = len(vec)
    if n == 0:
        return [0.0]*8
    s = float(sum(vec))
    mean = s / n
    var = sum((x-mean)**2 for x in vec) / n
    rng = (max(vec) - min(vec)) if n>0 else 0.0
    frac_even = len([v for v in vec if v % 2 == 0]) / n
    frac_gt_mean = len([v for v in vec if v > mean]) / n
    l2 = math.sqrt(sum(x*x for x in vec))
    # pal defects (local import to avoid cycles)
    try:
        from .pal import pal_defects
        pd = pal_defects(vec)
        P4 = pd.get('P4', 0)
        P8 = pd.get('P8', 0)
    except Exception:
        P4 = 0; P8 = 0
    # normalize
    f1 = _safe_div(mean, s if s!=0 else 1.0)           # in [0,1]
    f2 = _safe_div(var, (mean*mean + 1.0))             # scaled variance
    f3 = _safe_div(rng, (abs(mean) + 1.0))             # range vs mean
    f4 = float(frac_even)
    f5 = float(frac_gt_mean)
    f6 = _safe_div(l2, (abs(s) + 1.0))
    # P4/P8 normalized by n (counts scale)
    f7 = _safe_div(P4, n)
    f8 = _safe_div(P8, n)
    return [f1,f2,f3,f4,f5,f6,f7,f8]

def latch_sweep(vec: List[int], eps: float=0.0) -> List[int]:
    vals = face_functionals(vec)
    return [1 if v >= -eps else 0 for v in vals]
