from typing import List, Tuple

# Parity-check matrix for extended Hamming [8,4,4]
# H rows *must* satisfy H*c^T = 0 (mod 2) for codewords c.
H = [
    [1,1,1,1,0,0,0,0],
    [1,1,0,0,1,1,0,0],
    [1,0,1,0,1,0,1,0],
    [1,0,0,1,0,1,0,1],
]

def matmul_mod2(H, v):
    return [sum(h*vi for h,vi in zip(row, v)) % 2 for row in H]

def in_ext_hamming_8(bits: List[int]) -> bool:
    if len(bits) != 8: return False
    b = [x & 1 for x in bits]
    synd = matmul_mod2(H, b)
    return sum(synd) == 0  # zero syndrome

def constructionA_E8_check(vec8: List[int]) -> Tuple[bool, List[int]]:
    """Construction A: x in Z^8 is legal if x mod 2 ∈ Extended Hamming(8,4,4).
    Returns (legal, syndrome)."""
    if len(vec8) != 8:  # adapt by folding/summing to 8 coords
        # fold deterministically
        v = [0]*8
        for i,x in enumerate(vec8):
            v[i%8] = (v[i%8] + int(x))  # keep as int sum
        vec8 = v
    b = [x & 1 for x in vec8]
    synd = matmul_mod2(H, b)
    return (sum(synd) == 0, synd)
