from typing import List, Dict
from .gating import face_functionals

def nav_faces(vec: List[int]) -> List[float]:
    # emphasize range, variance, and fraction-even for timing stability
    f = face_functionals(vec)
    w = [0.8, 1.2, 1.4, 1.0, 0.9, 0.8, 1.0, 1.0]
    return [fi*wi for fi,wi in zip(f,w)]

def mat_faces(vec: List[int]) -> List[float]:
    # emphasize P4/P8 (palindromy) and evenness for phase legality
    f = face_functionals(vec)
    w = [0.8, 0.9, 0.9, 1.2, 0.8, 0.7, 1.6, 1.6]
    return [fi*wi for fi,wi in zip(f,w)]

def bio_faces(vec: List[int]) -> List[float]:
    # emphasize P4/P8 and >mean for duplex health
    f = face_functionals(vec)
    w = [0.7, 0.9, 0.8, 1.1, 1.3, 0.8, 1.7, 1.7]
    return [fi*wi for fi,wi in zip(f,w)]

PACKS: Dict[str, callable] = {"NAV": nav_faces, "MAT": mat_faces, "BIO": bio_faces}
