# Bucket-Graph Planner (v1.12)

Features:
- Tuple forcing (sizes 1..8)
- Context review priors (persona-biased)
- Adhesion scoring (E8 legality, latches, parity closeness)
- **Paint gate** (parity paint presence)
- **Residue routing** (send near-misses to next-best persona)
- **Binary splitter** for clusters ≤4
- **Config-driven buckets** (`/mnt/data/buckets_config.json`), with API GET/PUT
- API: `POST /planner/run`

Usage:
```
curl -X POST localhost:8000/planner/run -H 'content-type: application/json'   -d '{"tokens":["A","B","C","D","E","F","G","H","I","J"]}'
```
