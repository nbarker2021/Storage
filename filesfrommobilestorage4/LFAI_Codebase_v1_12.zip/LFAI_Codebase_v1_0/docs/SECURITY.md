# Security (v1.10)
- **HMAC Auth (optional):** set `LFAI_API_KEYS='{"key-id":"secret"}'` and sign requests with `X-LFAI-Key` and `X-LFAI-Sig = HMAC_SHA256(secret, body)`.
- **Structured logs:** JSON-ish line logs via Python logging.
- **Next:** scopes per route, rate limits, and signed server responses.
