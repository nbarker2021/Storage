# Construction-A → E8 Legality (Implemented)

We implement a **true Construction-A check for E8** using the extended Hamming [8,4,4] code:
- E8 = { x ∈ Z^8 : x (mod 2) ∈ H_8 } / √2
- We check membership via zero-syndrome under a fixed parity-check matrix H (4×8).

API surfaces will gradually migrate to use this check under a feature flag; for now, helper `constructionA_E8_check(vec8)` is available and used in benches.
