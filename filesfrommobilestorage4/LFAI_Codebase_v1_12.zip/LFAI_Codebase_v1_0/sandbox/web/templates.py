from typing import List, Optional
from html import escape
from lfaicore.paint import paint8, hex_to_colors, parity_paint, neon_palette, hue_shift_hex, grayscale_strip, grayscale_to_colors

def render_index(rooms: List[dict], vec: Optional[list]=None, verdict: str="", pal: dict=None, latch: list=None, room_id: str="", hue_shift: int=0) -> str:
    head = '''<!doctype html><html><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://unpkg.com/htmx.org@1.9.12"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <title>ScratchPad HQ</title></head><body class="bg-slate-50 text-slate-900">
    <div class="max-w-5xl mx-auto p-6">
      <h1 class="text-3xl font-bold mb-4">ScratchPad HQ — Rooms</h1>'''
    room_cards = "".join([f'<div class="p-4 rounded-2xl shadow bg-white mb-3"><div class="font-semibold">{escape(r["cfg"]["name"])}</div><div class="text-sm text-slate-600">{escape(r["cfg"].get("purpose",""))}</div><div class="text-xs text-slate-500">rest={r["frame"]["rest_scale"]} mods={r["frame"]["mods"]}</div></div>' for r in rooms])
    form_new = '''
    <form method="post" action="/new" class="flex gap-2 mt-4">
      <input name="name" placeholder="New room name" class="border rounded px-3 py-2 flex-1" />
      <input name="purpose" placeholder="Purpose" class="border rounded px-3 py-2 flex-1" />
      <button class="bg-indigo-600 text-white px-4 py-2 rounded">Create</button>
    </form>'''
    form_ingest = f'''
    <form method="post" action="/ingest" class="mt-6 p-4 border rounded-xl bg-white shadow">
      <div class="flex gap-2">
        <input name="room_id" placeholder="room id" value="{escape(room_id)}" class="border rounded px-3 py-2 w-1/3" />
        <select name="dtype" class="border rounded px-3 py-2">
          <option>text</option><option>json</option><option>csv</option><option>vec</option>
        </select>
      </div>
      <textarea name="payload" rows="4" class="border rounded px-3 py-2 mt-2 w-full" placeholder="Paste text/JSON/CSV or vec like 1,2,3,4"></textarea>
      <button class="bg-emerald-600 text-white px-4 py-2 rounded mt-2">Ingest & Verify</button>
    </form>'''
    result = ''
    if vec is not None:
        paint_rows = ''
        
        # Parity Paint (neon) rows
        parity = parity_paint(vec, rooms[0]['frame']['mods'].__str__() if rooms else 'core:proof', length=32) if vec is not None else {}
        neon2 = neon_palette('mod2'); neon4 = neon_palette('mod4'); neon8 = neon_palette('mod8')
        def row_for(label, seqs, pal):
            rows=''
            for idx,seq in enumerate(seqs):
                seq2 = hue_shift_hex(seq, 0)
                cols = [ pal.get(ch, '#000000') for ch in seq2[:32] ]
                sw=''.join([f'<span style="display:inline-block;width:8px;height:10px;background:{c}"></span>' for c in cols])
                rows += f'<div class="text-xs">Class {idx}: {sw}</div>'
            return f'<div class="mt-2"><div class="font-mono text-xs text-slate-600">{label}</div>{rows}</div>'
        parity_block = ''
        
        # Grayscale (content saturation) strip
        gray_seq = grayscale_strip(vec, space='ui') if vec is not None else ''
        gray_cols = ''.join([f'<span style="display:inline-block;width:8px;height:10px;background:{c}"></span>' for c in grayscale_to_colors(gray_seq[:32])])
        gray_block = f'<div class="mt-4"><div class="font-semibold">Grayscale (content)</div><div class="text-xs">{gray_cols}</div></div>'
    
        if parity:
            parity_block = '<div class="mt-4"><div class="font-semibold">Parity Paint (neon)</div>' + \                row_for('mod2', parity.get('mod2', []), neon2) + \                row_for('mod4', parity.get('mod4', []), neon4) + \                row_for('mod8', parity.get('mod8', []), neon8) + '</div>'
    
        if vec is not None:
            p8 = paint8(vec, rooms[0]['frame']['mods'].__str__() if rooms else 'core:proof') if rooms else ['']*8
            for i,seq in enumerate(p8):
                cols = hex_to_colors(seq[:32])
                swatches = ''.join([f'<span style="display:inline-block;width:8px;height:12px;background:{c}"></span>' for c in cols])
                paint_rows += f'<div class="text-xs mt-1">Face {i}: {swatches}</div>'
        result = f'''
        <div class="mt-6 p-4 rounded-xl bg-white shadow">
          <div class="font-semibold">Result</div>
          <div class="text-sm">vec = {escape(str(vec))}</div>
          <div class="text-sm">verdict = <span class="font-mono">{escape(verdict)}</span></div>
          <div class="text-sm">pal = {escape(str(pal or {}))}</div>
          <div class="text-sm">latches = {escape(str(latch or []))}</div>'+paint_rows + parity_block + gray_block
        </div>'''
    tail = '</div></body></html>'
    return head + room_cards + form_new + form_ingest + result + tail
