from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
import uuid, json

from lfaicore.frame import compile_from_glyphs, Frame
from lfaicore.reducer import reduce_to_rest
from lfaicore.cona import legal_even, bits_from_vec
from lfaicore.pal import pal_defects
from lfaicore.uplift import uplift_u2
from lfaicore.gating import latch_sweep
from lfaicore.anchors import anchor_id

@dataclass
class RoomConfig:
    name: str
    purpose: str = ""
    glyphs: List[int] = field(default_factory=lambda:[8,13,32])
    faces: List[str] = field(default_factory=lambda:['octad'])
    pins_required: List[str] = field(default_factory=list)
    data_types: List[str] = field(default_factory=lambda:['text','json','csv','vec'])
    persona: Optional[str] = None
    scenario: Optional[str] = None

@dataclass
class Room:
    id: str
    cfg: RoomConfig
    frame: Frame
    ledger: List[Dict[str,Any]] = field(default_factory=list)

    @staticmethod
    def create(cfg: RoomConfig) -> "Room":
        f = compile_from_glyphs(cfg.glyphs)
        return Room(id=str(uuid.uuid4()), cfg=cfg, frame=f)

    def to_json(self) -> Dict[str,Any]:
        return {"id": self.id, "cfg": asdict(self.cfg),
                "frame": {"rest_scale": self.frame.rest_scale, "dyadic_depth": self.frame.dyadic_depth, "mods": self.frame.mods, "faces": self.frame.faces},
                "ledger_len": len(self.ledger)}

    # Core actions
    def verify(self, vec: List[int]) -> Dict[str,Any]:
        legal, s = legal_even(vec); pd = pal_defects(vec); l = latch_sweep(vec)
        verdict = "OPEN" if (legal and pd["P4"]==0 and pd["P8"]==0) else "PROVISIONAL_OPEN"
        rec = {"op":"verify","vec":vec,"legal":legal,"syndrome":s,"pal":pd,"latches":l,"verdict":verdict}
        self.ledger.append(rec); return rec

    def reduce(self, vec: List[int]) -> Dict[str,Any]:
        v2 = reduce_to_rest(list(vec))
        rec = {"op":"reduce","vec_in":vec,"vec_out":v2}
        self.ledger.append(rec); return rec

    def uplift(self, vec: List[int], steps:int=1) -> Dict[str,Any]:
        v = list(vec); f = self.frame
        for _ in range(steps): v, f = uplift_u2(v, f)
        self.frame = f
        rec = {"op":"uplift","steps":steps,"vec_out":v,"rest_scale":f.rest_scale,"dyadic_depth":f.dyadic_depth,"mods":f.mods}
        self.ledger.append(rec); return rec

    def anchor(self, vec: List[int]) -> Dict[str,Any]:
        aid, bits = anchor_id(vec, self.frame)
        rec = {"op":"anchor","anchor_id":aid,"bounds_sig":bits}
        self.ledger.append(rec); return rec
