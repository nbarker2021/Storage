# Master Index Bundle

This bundle consolidates all document and code indexes from every processed archive.

## Columns
- `archive`: Name of the source archive zip.
- `file_type`: 'doc' for document pass, 'code' for code pass.
- `rel_path`: Path of the file relative to the archive's extracted root.
- `ext`: File extension.
- `lines`: Line count.
- `words`: Word count.
- `kw_*`: Keyword occurrence counts for the domain-specific terms.
- (code only) Python symbol counts and flags: `py_has_main`, `py_num_classes`, `py_num_functions`.

## Usage
Open MASTER_INDEX.csv in Excel, LibreOffice, or a data tool.
Filter by `archive` to focus on a specific archive.
Filter by `file_type` to separate docs vs code.
Search for keyword columns (e.g., `kw_E8 > 0`) to jump to relevant files.

## Tip
Combine filtering: e.g., `file_type = code` AND `kw_orchestrator > 0` to find orchestrator code implementations.
