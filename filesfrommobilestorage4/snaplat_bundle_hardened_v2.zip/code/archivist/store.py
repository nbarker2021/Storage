
"""
Archivist — JSON persistence (append-only-ish).
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any
import json, uuid, time, os

class Archivist:
    def __init__(self, base_dir: str):
        self.base = base_dir
        os.makedirs(self.base, exist_ok=True)

    def write(self, kind: str, obj: Dict[str, Any]) -> str:
        oid = obj.get("id") or f"{kind}:{uuid.uuid4()}"
        obj["id"] = oid
        path = os.path.join(self.base, f"{oid.replace(':','_')}.json")
        with open(path, "w") as f:
            json.dump(obj, f, indent=2)
        return oid
