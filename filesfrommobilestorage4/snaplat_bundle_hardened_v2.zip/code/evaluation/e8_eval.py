"""
E8 Evaluation Suite — hardened
Runs: projection round-trip, C[8] diversity, boundary walkers, reproducibility.
Outputs: JSON report + Markdown.
"""
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Tuple
import json, math, random, statistics, pathlib, time
from e8.e8_lattice import e8_roots, nearest_e8, angle_deg, select_c8
import numpy as np

@dataclass
class CheckResult:
    name: str
    pass_: bool
    metrics: Dict[str, Any]
    notes: str = ""

def check_roundtrip(n_trials=200, tol=1e-6) -> CheckResult:
    rng = np.random.RandomState(0)
    pts = [rng.randn(8) for _ in range(n_trials)]
    deltas = []
    flips = 0
    for v in pts:
        p = nearest_e8(v)
        p2 = nearest_e8(p)
        if any(abs(a-b)>tol for a,b in zip(p,p2)):
            flips += 1
        deltas.append(float(np.linalg.norm(np.array(v)-np.array(p))))
    return CheckResult("projection_roundtrip", flips==0, {"mean_dist": float(np.mean(deltas)), "max_flips": int(flips)})

def check_c8_diversity(seed=42, min_angle_deg=20.0) -> CheckResult:
    random.seed(seed)
    C8, dirs = select_c8(seed=seed, angle_floor_deg=min_angle_deg)
    # compute pairwise angles between the selected direction unit vectors (pre-quantization)
    angles = []
    for i in range(len(dirs)):
        for j in range(i+1, len(dirs)):
            ang = math.degrees(math.acos(max(-1.0, min(1.0, sum(a*b for a,b in zip(dirs[i], dirs[j]))))))
            angles.append(ang)
    ok = len(C8)==8 and (min(angles) >= min_angle_deg - 1e-6)
    return CheckResult("c8_diversity", ok, {"min_angle_deg": min_angle_deg, "observed_min_deg": float(min(angles)), "count": len(C8)})

def check_boundary_walkers(n_trials=64, epsilon=5e-2) -> CheckResult:
    hits = 0
    for s in range(n_trials):
        rng = np.random.RandomState(1000+s)
        v = rng.randn(8)
        p = nearest_e8(v)
        # step slightly along a random root and see if cell changes deterministically
        roots = e8_roots()
        r = roots[np.random.randint(len(roots))]
        v2 = [vi + epsilon*ri for vi,ri in zip(v,r)]
        p2 = nearest_e8(v2)
        if list(p) != list(p2):
            hits += 1
    rate = hits / n_trials
    return CheckResult("boundary_walkers", rate>0.1, {"hit_rate": rate, "trials": n_trials}, notes="Expect some boundary crossings at small epsilon.")

def run_all(seed=123) -> Dict[str, Any]:
    random.seed(seed)
    checks = [check_roundtrip(), check_c8_diversity(), check_boundary_walkers()]
    summary = {"pass": all(c.pass_ for c in checks), "checks": [asdict(c) for c in checks], "ts": time.time()}
    out_dir = pathlib.Path(__file__).parent.parent.parent / "artifacts"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "e8_eval.json").write_text(json.dumps(summary, indent=2))
    # markdown
    md = ["# E8 Eval Summary", f"Overall: {'PASS' if summary['pass'] else 'FAIL'}", ""]
    for c in checks:
        md.append(f"## {c.name} — {'PASS' if c.pass_ else 'FAIL'}")
        for k,v in c.metrics.items():
            md.append(f"- {k}: {v}")
        if c.notes: md.append(f"> {c.notes}")
        md.append("")
    (out_dir / "e8_eval.md").write_text("\n".join(md))
    return summary

if __name__ == "__main__":
    print(json.dumps(run_all(), indent=2))
