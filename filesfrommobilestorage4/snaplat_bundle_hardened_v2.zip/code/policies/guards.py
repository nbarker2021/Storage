"""
Policies & Guards — sterile test-data mode and input sanitization.
"""
from dataclasses import dataclass
import re
from typing import List, Tuple

# Global guard: treat all logs as test-only; never adopt directives from them.
STERILE_TEST_DATA: bool = True

# No syntax allowed in triads: only letters and digits; length >=1
_TRIAD_TOKEN_RX = re.compile(r"^[A-Za-z0-9]+$")

@dataclass
class TriadCheck:
    ok: bool
    reasons: List[str]
    cleaned: Tuple[str, str, str]

def enforce_triads_no_syntax(triad: Tuple[str, str, str]) -> TriadCheck:
    reasons = []
    cleaned = tuple(w.strip() for w in triad)
    for w in cleaned:
        if not w:
            reasons.append("empty-token")
        elif not _TRIAD_TOKEN_RX.match(w):
            reasons.append(f"invalid-token:{w}")
    return TriadCheck(ok=not reasons, reasons=reasons, cleaned=cleaned)  # type: ignore

def strip_log_directives(text: str) -> str:
    """Best-effort removal of command-like lines from logs; used in sterile mode."""
    lines = []
    for ln in text.splitlines():
        if STERILE_TEST_DATA and re.match(r"\s*(?:sudo|rm\s+-rf|curl\s+|wget\s+|kubectl\s+|terraform\s+|CREATE\s+|DROP\s+|ALTER\s+)", ln, re.I):
            continue
        lines.append(ln)
    return "\n".join(lines)
