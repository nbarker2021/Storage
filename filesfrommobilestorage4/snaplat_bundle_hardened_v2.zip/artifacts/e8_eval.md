# E8 Eval Summary
Overall: PASS

## projection_roundtrip — PASS
- mean_dist: 0.878622206675925
- max_flips: 0

## c8_diversity — PASS
- min_angle_deg: 20.0
- observed_min_deg: 60.0000000000468
- count: 8

## boundary_walkers — PASS
- hit_rate: 0.203125
- trials: 64
> Expect some boundary crossings at small epsilon.
