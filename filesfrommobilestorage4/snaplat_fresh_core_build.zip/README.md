
# SnapLat (fresh core build)

This is a from-scratch, minimal, **core-first** rebuild of the SnapLat system.
Design goals:
- Deterministic **E8** nearest-lattice projection & membership checks
- Explicit **edges** (240 roots), **reflections** across roots
- Simple 2D projection utility (`coxeter_plane()`) for visualization
- A reproducible **n=5** loop that fans out **8** distinct candidates (C[8])
- A tiny **DTT** harness (deterministic, sandboxed) producing evidence
- **Assembly** into a glyph with **DNA** (replayable)
- **SAP** governance stub (Sentinel/Arbiter/Porter)
- **MDHG** hot-map substrate & **AGRM** simple φ-rotating planner
- **MORSR** telemetry (JSON Lines)

This is intentionally compact, well-tested, and easy to extend.
