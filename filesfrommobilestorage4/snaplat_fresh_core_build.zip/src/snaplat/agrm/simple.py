
"""Simple AGRM scheduler/planner with φ rotation over heuristics.
Produces a plan dict {radius, floors, elevators, schedule}.
"""
from dataclasses import dataclass
from typing import Dict
import math

PHI = (1 + 5**0.5) / 2

@dataclass
class AGRMState:
    step: int
    tac: float  # test anchor coverage or analogous coverage metric

def plan(state: AGRMState) -> Dict:
    # rotate radius 1/2 by φ cadence; increase floors as tac falls
    r = 1 + int(math.floor((state.step / PHI) % 2))
    floors = 1 if state.tac >= 0.5 else 2
    elevators = 1
    schedule = ["neighbors", "edges", "reflect"]
    return {"radius": r, "floors": floors, "elevators": elevators, "schedule": schedule}
