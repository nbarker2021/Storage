
from dataclasses import dataclass
from typing import List, Dict, Any

@dataclass
class SAPVerdict:
    decision: str  # 'ACCEPT' | 'REJECT' | 'HOLD'
    reasons: List[str]

def evaluate(evidence: List[Dict[str, Any]], diversity: int) -> SAPVerdict:
    reasons = []
    if len(evidence) < diversity:
        reasons.append(f"insufficient diversity: {len(evidence)}<{diversity}")
        return SAPVerdict(decision="HOLD", reasons=reasons)
    # simple policy: average utility >= 0.5
    utils = [e["metrics"]["utility"] for e in evidence]
    avg = sum(utils)/len(utils)
    if avg >= 0.5:
        reasons.append(f"avg utility {avg:.3f} >= 0.5")
        return SAPVerdict(decision="ACCEPT", reasons=reasons)
    reasons.append(f"avg utility {avg:.3f} < 0.5")
    return SAPVerdict(decision="REJECT", reasons=reasons)
