
"""Deterministic test harness: simulates DTT by computing a stable score from candidate payload.
This is a sandbox; swap for real execution later.
"""
from typing import List, Dict
from dataclasses import dataclass
import hashlib, math, random

from ..snap.schema import Candidate, Evidence

def _stable_hash(s: str) -> int:
    return int(hashlib.sha256(s.encode()).hexdigest(), 16)

@dataclass
class DTTConfig:
    seed: int = 0
    perf_scale: float = 1.0

class DTT:
    def __init__(self, cfg: DTTConfig):
        self.cfg = cfg
        self._rng = random.Random(cfg.seed)

    def run(self, candidates: List[Candidate]) -> List[Evidence]:
        out: List[Evidence] = []
        for c in candidates:
            raw = f"{c.id}:{c.payload}"
            h = _stable_hash(raw)
            # deterministic metrics in [0,1]
            score = ((h % 10_000_000) / 10_000_000.0)
            stability = (((h//7) % 10_000_000) / 10_000_000.0)
            utility = 0.5*score + 0.5*stability
            metrics = {
                "score": score * self.cfg.perf_scale,
                "stability": stability,
                "utility": utility,
            }
            notes = {"dtt": "simulated", "seed": self.cfg.seed}
            out.append(Evidence(candidate_id=c.id, metrics=metrics, notes=notes))
        return out
