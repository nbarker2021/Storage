
"""Minimal E8 lattice core: membership, projection/nearest, edges, reflections,
and a simple 2D projection helper (coxeter-like fixed basis).
Reference model:
- E8 = { x in R^8 | (x in Z^8 and sum(x) even) or (x in (Z+1/2)^8 and sum(x) even) }
Nearest algorithm (classic two-coset check):
- Candidate Z: round to Z^8, then adjust one coordinate if sum is odd
- Candidate H: round to (Z+1/2)^8, then adjust one coordinate if the 'even sum' rule fails
Pick the closer of the two.
"""
from dataclasses import dataclass
from typing import List, Tuple
import math

from .roots import e8_roots

Vec = List[float]

def _round_half(x: float) -> float:
    # round to nearest half-integer
    return round(x - 0.5) + 0.5

def _parity_even_sum(vec: Vec) -> bool:
    s = sum(vec)
    # Since entries are integers or half-integers, sum is in steps of 0.5.
    # E8 requires even integer sum. For half-integers, sum is an integer + 4*(1/2) = integer+4? 
    # Practically, check parity on doubled sum.
    return int(round(2*s)) % 2 == 0

def is_member(x: Vec, tol: float = 1e-9) -> bool:
    # check that all coords are near integer or near half-integer consistently
    ints = all(abs(c - round(c)) < tol for c in x)
    halves = all(abs((c - 0.5) - round(c - 0.5)) < tol for c in x)
    if not (ints or halves):
        return False
    return _parity_even_sum(x)

def _candidate_Z(v: Vec) -> Vec:
    z = [round(c) for c in v]
    if not _parity_even_sum(z):
        # adjust the coordinate with largest fractional deviation
        diffs = [abs(vc - zc) for vc, zc in zip(v, z)]
        j = max(range(8), key=lambda i: diffs[i])
        # move z_j toward v_j by +1 or -1 to flip parity
        step = 1 if v[j] > z[j] else -1
        z[j] += step
        # After one step, parity flips
    return [float(c) for c in z]

def _candidate_H(v: Vec) -> Vec:
    y = [_round_half(c) for c in v]
    # ensure parity rule
    if not _parity_even_sum(y):
        diffs = [abs(vc - yc) for vc, yc in zip(v, y)]
        j = max(range(8), key=lambda i: diffs[i])
        step = 1 if v[j] > y[j] else -1
        y[j] += step  # still half-integer after +/-1
    return [float(c) for c in y]

def nearest(v: Vec) -> Tuple[Vec, float]:
    z = _candidate_Z(v)
    y = _candidate_H(v)
    dz = sum((vc - zc)**2 for vc, zc in zip(v, z))
    dy = sum((vc - yc)**2 for vc, yc in zip(v, y))
    best = z if dz <= dy else y
    dist2 = min(dz, dy)
    assert is_member(best), "Nearest candidate is not an E8 member by parity check."
    return best, dist2

def project(v: Vec) -> Vec:
    return nearest(v)[0]

# Edges: neighbors at root distance (add each root)
_ROOTS = None
def roots() -> List[Vec]:
    global _ROOTS
    if _ROOTS is None:
        _ROOTS = e8_roots()
    return _ROOTS

def edges(x: Vec) -> List[Vec]:
    assert is_member(x), "x must be E8 lattice member"
    nbrs = []
    for r in roots():
        y = [xi + ri for xi, ri in zip(x, r)]
        # y should still be an E8 member
        if is_member(y):
            nbrs.append(y)
    # Typically 240; assert non-empty
    assert len(nbrs) > 0
    return nbrs

def reflect(x: Vec, r: Vec) -> Vec:
    # reflection across hyperplane orthogonal to r (||r||^2 = 2)
    dot = sum(xi*ri for xi, ri in zip(x, r))
    return [xi - (dot)*ri for xi, ri in zip(x, r)]

# Simple fixed 2D projection (coxeter-like placeholder):
# Use two orthonormal 8D vectors; this is not a true Coxeter-plane eigenbasis, but deterministic.
_B1 = [1,1,1,1, -1,-1,-1,-1]
norm = math.sqrt(sum(c*c for c in _B1))
_B1 = [c/norm for c in _B1]
_B2 = [1,-1,1,-1, 1,-1,1,-1]
# Gram-Schmidt for B2 against B1
dot12 = sum(a*b for a,b in zip(_B1,_B2))
_B2 = [b - dot12*a for a,b in zip(_B1,_B2)]
norm2 = math.sqrt(sum(c*c for c in _B2))
_B2 = [c/norm2 for c in _B2]

def coxeter_plane(x: Vec) -> Tuple[float, float]:
    return (sum(a*b for a,b in zip(_B1, x)), sum(a*b for a,b in zip(_B2, x)))
