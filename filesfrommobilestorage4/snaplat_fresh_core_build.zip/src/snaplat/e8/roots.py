
"""E8 root system (240 roots) and helpers.
We generate the 240 roots of norm^2 = 2 using the standard construction:
- 112 roots of type A: permutations of (±1, ±1, 0, ..., 0) with an even number of minus signs
- 128 roots of type B: vectors (±1/2, ..., ±1/2) with an even number of minus signs
"""
from itertools import permutations, combinations
import math

def _unique(seq):
    seen = set()
    out = []
    for x in seq:
        t = tuple(x)
        if t not in seen:
            seen.add(t)
            out.append(list(t))
    return out

def e8_roots():
    roots = []
    # Type A: choose 2 positions to place ±1
    for i, j in combinations(range(8), 2):
        for s1 in (+1, -1):
            for s2 in (+1, -1):
                vec = [0]*8
                vec[i] = s1
                vec[j] = s2
                # even number of negative signs among nonzeros
                if (int(s1<0)+int(s2<0)) % 2 == 0:
                    roots.append(vec)
    # Type B: all 8 positions are ±1/2, even number of negatives
    for mask in range(1<<8):
        bits = [(mask>>k)&1 for k in range(8)]
        negs = sum(bits)
        if negs % 2 == 0:
            vec = [(-0.5 if b else 0.5) for b in bits]
            roots.append(vec)
    assert len(roots) == 240, f"Expected 240 roots, got {len(roots)}"
    # sanity: all have norm^2 = 2
    for r in roots:
        n2 = sum(x*x for x in r)
        assert abs(n2 - 2.0) < 1e-9
    return roots
