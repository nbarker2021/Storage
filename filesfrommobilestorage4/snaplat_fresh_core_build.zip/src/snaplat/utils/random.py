
from dataclasses import dataclass
import random

@dataclass
class RNG:
    seed: int
    def __post_init__(self):
        self._rng = random.Random(self.seed)
    def randint(self, a, b): return self._rng.randint(a, b)
    def random(self): return self._rng.random()
    def choice(self, seq): return self._rng.choice(seq)
    def shuffle(self, seq): self._rng.shuffle(seq)
