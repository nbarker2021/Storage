
from dataclasses import dataclass, asdict
from typing import Any, Dict, List
import json, hashlib

@dataclass(frozen=True)
class Candidate:
    id: str
    payload: Any
    meta: Dict[str, Any]

@dataclass(frozen=True)
class Evidence:
    candidate_id: str
    metrics: Dict[str, float]
    notes: Dict[str, Any]

@dataclass(frozen=True)
class DNA:
    weights: List[float]
    candidates: List[str]
    checksum: str

def dna_from(weights: List[float], candidates: List[Candidate]) -> DNA:
    assert len(weights) == len(candidates) and len(candidates) > 0
    s = json.dumps({
        "w": [round(w, 8) for w in weights],
        "c": [c.id for c in candidates]
    }, sort_keys=True)
    h = hashlib.sha256(s.encode()).hexdigest()
    return DNA(weights=list(weights), candidates=[c.id for c in candidates], checksum=h)
