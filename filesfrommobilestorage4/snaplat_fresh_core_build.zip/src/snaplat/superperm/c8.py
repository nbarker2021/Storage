
"""Produce 8 distinct candidates (C[8]) for n=5 using a seed; deterministic.
We generate permutations by seeded shuffles and enforce uniqueness.
"""
from typing import List, Dict, Any
from dataclasses import dataclass
import hashlib, random

from ..snap.schema import Candidate

def _id_for(payload: Any) -> str:
    return hashlib.sha256(str(payload).encode()).hexdigest()[:16]

@dataclass
class C8Config:
    seed: int = 0

def produce_c8(cfg: C8Config) -> List[Candidate]:
    rng = random.Random(cfg.seed)
    base = [0,1,2,3,4]
    seen = set()
    out: List[Candidate] = []
    tries = 0
    while len(out) < 8 and tries < 1000:
        arr = base[:]
        rng.shuffle(arr)
        tup = tuple(arr)
        if tup in seen:
            tries += 1
            continue
        seen.add(tup)
        payload = {"n": 5, "perm": arr}
        cid = _id_for(payload)
        out.append(Candidate(id=cid, payload=payload, meta={"seed": cfg.seed, "index": len(out)}))
        tries += 1
    assert len(out) == 8, "Failed to produce 8 unique candidates"
    return out
