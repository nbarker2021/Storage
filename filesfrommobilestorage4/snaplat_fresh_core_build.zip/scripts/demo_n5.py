
#!/usr/bin/env python3
"""Run the n=5 loop:
- produce 8 candidates
- run DTT
- assemble
- evaluate SAP
- print a short report
"""
from snaplat.superperm.c8 import produce_c8, C8Config
from snaplat.dtt.harness import DTT, DTTConfig
from snaplat.assembly.core import stitch
from snaplat.sap.core import evaluate
from snaplat.agrm.simple import plan, AGRMState

def main():
    cands = produce_c8(C8Config(seed=123))
    dtt = DTT(DTTConfig(seed=99))
    ev = dtt.run(cands)
    out = stitch(cands, ev)
    verdict = evaluate([e.__dict__ for e in ev], diversity=8)
    pl = plan(AGRMState(step=1, tac=0.6))
    print("Produced candidates:", len(cands))
    print("DNA checksum:", out["DNA"].checksum)
    print("SAP:", verdict.decision, "|", ", ".join(verdict.reasons))
    print("Plan:", pl)

if __name__ == "__main__":
    main()
