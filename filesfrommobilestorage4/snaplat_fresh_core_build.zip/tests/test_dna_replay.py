
from snaplat.superperm.c8 import produce_c8, C8Config
from snaplat.dtt.harness import DTT, DTTConfig
from snaplat.assembly.core import stitch, replay

def test_dna_roundtrip():
    cands = produce_c8(C8Config(seed=42))
    dtt = DTT(DTTConfig(seed=7, perf_scale=1.0))
    ev = dtt.run(cands)
    out = stitch(cands, ev)
    dna = out["DNA"]
    lookup = {c.id: c.payload for c in cands}
    replayed = replay(dna, lookup)
    assert out["glyph"] == replayed["glyph"]
    assert dna == replayed["DNA"]
