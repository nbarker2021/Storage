
# Lattice System Base v9 — Semantic Hash + Shell Governance

This drop focuses on two priorities:
1) **Trainable Tier-2 semantic hash** (balanced bits, supervised pairs, exportable weights)
2) **Shell governance polish** (promotion reports, policy thresholds, persistence)

## Quick run

```bash
python -m lattice_ai.tests.hash_eval      # trains small semantic hash, prints bit imbalance
python -m lattice_ai.tests.policy_demo    # builds shells, promotes, persists to SQLite
```

## What to look at

- `core/semantic_hash.py`: tiny trainer with losses (balance, decorrelation, pairwise).
- `core/hash_system.py`: supports injecting Tier-2 weights via `set_tier2_weights(W,b)`.
- `core/shell_lifecycle.py`: emits `PromotionReport`s; saves/loads JSON; SQLite persistence via `persistence/sqlite_store.py`.
- `core/shell_policy.py`: policy dataclass for thresholds (hook for domain-specific configs).

## Next

- Hook the trainer into `HashSystem` for live rehash/migration tests.
- Add domain probe registry (multiple QA suites) and uncertainty-triggered shell expansion.
- Router budget controller (p95 latency target) with adaptive blend.


## v10 — WP‑A: Semantic Hash end‑to‑end
This version wires a **trainable Tier‑2** into a simple CLI trainer, an eval harness (recall@K, latency, occupancy), and a migration churn report.

### Train weights
```bash
python -m lattice_ai.tests.hash_train --steps 400 --out /mnt/data/weights.json
```

### Evaluate (baseline vs. trained)
```bash
# Baseline (random Tier‑2)
python -m lattice_ai.tests.hash_eval_suite

# With trained weights
python -m lattice_ai.tests.hash_eval_suite --weights /mnt/data/weights.json
```

### Migration churn
```bash
python -m lattice_ai.tests.migration_test --weights /mnt/data/weights.json
```


## v11 — WP‑B & WP‑C
- **Policy registry + auto‑expand:** `core/policy_registry.py`, `ShellManager.auto_expand_and_promote`, `core/rules_factory.py`.
  Demo: `python -m lattice_ai.tests.policy_auto_expand_demo`
- **Budget controller:** `core/budget_controller.py` chooses K/params to meet a latency budget (heuristic first pass).
  Demo: `python -m lattice_ai.tests.router_budget_demo`


## v12 — Sprint A (Ops & Guardrails)
**What’s in:**
- DB indices + simple migrations (`persistence/migrations.py`), auto-run on startup.
- Background jobs scaffold (`jobs/job_runner.py`) + `/jobs/run_once` endpoint.
- Runtime metrics collector with `/metrics` endpoint.
- Hash migration CLI: `python -m cli.hash_migrate --new /path/to/weights.json` → churn & occupancy report.

**Run the service:**
```
uvicorn rest.app:app --host 0.0.0.0 --port 8000
```

**Kick the tires:**
```
# 1) Build shells and promote
curl -X POST "http://localhost:8000/build_shells/root::0"

# 2) Query (promoted-only candidates)
curl "http://localhost:8000/query?center_id=root::0"

# 3) Run background jobs once
curl -X POST "http://localhost:8000/jobs/run_once"

# 4) Metrics snapshot
curl "http://localhost:8000/metrics"
```

**Migrate Tier‑2 weights safely:**
```
python -m cli.hash_migrate --new /mnt/data/weights.json
```


## v13 (clean) — Sprint B Essentials
- Probe registry (`core/probes.py`) with recency/novelty/contradiction risk hooks.
- Promotion reports API: `GET /reports/{center_id}`.
- Per‑datum: distortion KPI, template init, KV capability policy.


## v14 — Probe‑aware promotion & Budget Controller v2
- REST now sets a `ts` tag on glyphs (used by **recency** probe).
- Shell promotions aggregate **recency** and **novelty** via a probe hook; results are persisted and visible through `/reports/{center_id}`.
- Budget controller v2 measures real costs and iteratively tunes `k_candidates` to meet the p95 budget.

### Try it
```bash
uvicorn rest.app:app --host 0.0.0.0 --port 8000

# Add a few glyphs with timestamps (auto-added)
curl -X POST "http://localhost:8000/glyphs" -H "Content-Type: application/json" -d '{"id":"root::0"}'
curl -X POST "http://localhost:8000/glyphs" -H "Content-Type: application/json" -d '{"id":"root::1"}'

# Build shells (recency/novelty will be computed)
curl -X POST "http://localhost:8000/build_shells/root::0"

# Inspect promotion reports (look for probe_recency and probe_novelty)
curl "http://localhost:8000/reports/root::0"

# Query (budget-controlled)
curl "http://localhost:8000/query?center_id=root::0"
```


## v15 — Policy REST, Claims + Contradiction Probe, UI, and Notations
- **Policy REST**: `GET/PUT /policy/{domain}` to view/update thresholds and probe selections.
- **Claims**: `POST /claims` to add (subject, predicate, value, source). Promotion now computes **contradiction_risk** using claims from current shell members.
- **Houses snapshot**: `GET /houses` for counts and hot zones.
- **UI**: static dashboard at `/ui` with Metrics, Houses, and Promotion Reports panels.
- **Rigorous notations** added to core modules to clarify metrics, losses, and controller logic.

### Try it
```bash
uvicorn rest.app:app --host 0.0.0.0 --port 8000

# Set a policy for 'docs'
curl -X PUT "http://localhost:8000/policy/docs" -H "Content-Type: application/json" -d '{"name":"docs","min_size":6,"min_coherence":0.12,"probes":["recency","novelty","contradiction_risk"]}'

# Add some glyphs (auto ts)
curl -X POST "http://localhost:8000/glyphs" -H "Content-Type: application/json" -d '{"id":"root::0"}'
curl -X POST "http://localhost:8000/glyphs" -H "Content-Type: application/json" -d '{"id":"root::1"}'

# Add conflicting claims for demo risk
curl -X POST "http://localhost:8000/claims?subject=S1&predicate=p&value=A&source=root::0"
curl -X POST "http://localhost:8000/claims?subject=S1&predicate=p&value=B&source=root::1"

# Build shells and inspect reports (look for probe_recency/probe_novelty/probe_contradiction_risk)
curl -X POST "http://localhost:8000/build_shells/root::0"
curl "http://localhost:8000/reports/root::0"

# Open UI
open http://localhost:8000/ui
```


## v16 — Run-ready bundle
- **Auth**: API key required for writes (`LATTICE_API_KEY`).
- **Config** via env (DB path, budget, candidate caps).
- **Scheduler**: background jobs run at intervals (contradictions, clusters, shell re-eval).
- **Budget v3**: tiny learned cost model (online) predicts latency vs. k.
- **UI**: policy controls and budget test panel.
- **Docker**: `docker build -t lattice-ai . && docker run -p 8000:8000 -e LATTICE_API_KEY=secret lattice-ai`

### Smoke test (separate shell while service runs)
```
bash lattice_ai/tests/smoke.sh
```


## v17 — Task queue, contradiction sweeps (real), and golden eval
- **TaskQueue**: enqueue background work (`/enqueue?name=contradiction_sweep&center_id=root::0`), inspect via `/tasks`.
- **Contradiction sweep v2**: aggregates claims across promoted members; quarantines shells on conflict.
- **Golden eval tests**: `tests/golden.json` thresholds + `tests/run_golden.sh` to catch regressions (recall@10 vs latency cap).

### Try
```
# Enqueue a contradiction sweep
curl -X POST "http://localhost:8000/enqueue?name=contradiction_sweep&center_id=root::0"
curl "http://localhost:8000/tasks"
curl "http://localhost:8000/task/1"
# Golden check
bash lattice_ai/tests/run_golden.sh
```


## v18 — Retries, Schedules, Goldens++, SPEC
- TaskQueue retries/backoff & retention
- Schedules in SQLite + REST
- Golden tests for promoted routing & budget
- Living SPEC at docs/SPEC.md
- Run all goldens: `bash lattice_ai/tests/run_all_goldens.sh`


## v19 — Multi-tenant security & partitions
- Migrations add `tenant_id` to all tables + indices.
- Tenant registry with per-tenant API keys (`POST /tenants`).
- All REST writes/reads are tenant-scoped; metrics are tagged per tenant.
- Backward-compatible: set `LATTICE_API_KEY` for single-tenant demo.

### Quick start (multi-tenant)
```bash
uvicorn rest.app:app --host 0.0.0.0 --port 8000

# Create a tenant and key
curl -X POST "http://localhost:8000/tenants?tenant_id=acme&api_key=acme-secret"

# Use tenant + key on writes
curl -X POST "http://localhost:8000/glyphs" -H "Content-Type: application/json" -H "X-API-Key: acme-secret" -H "X-Tenant: acme" -d '{"id":"root::0"}'
curl -X POST "http://localhost:8000/build_shells/root::0" -H "X-API-Key: acme-secret" -H "X-Tenant: acme"

# Tenant-scoped reads
curl "http://localhost:8000/reports/root::0" -H "X-Tenant: acme"
curl "http://localhost:8000/schedules" -H "X-Tenant: acme"
curl "http://localhost:8000/metrics"   # counters include 'acme:*'
```
