#!/usr/bin/env python3.11
"""
Experiment 1: Morphonic Lock-In Validation

Objective: Validate that repeated solves converge to stable embeddings

Method:
1. Select 3 recurring contexts
2. Run 30 solves per context with morphon wrapper
3. Log: cache hit, ΔΦ sectors, JS distance to atlas mode, ECC repairs

Success Criteria:
- Cache hit rate ↑ monotonically
- JS distance ↓ geometrically (measure λ)
- Idempotence holds: M(M(s)) = M(s)
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_complete_v1/core_system')
sys.path.insert(0, '/home/ubuntu')

import numpy as np
import json
from pathlib import Path
from typing import Dict, List, Tuple
import time
from scipy.spatial.distance import jensenshannon
from scipy.stats import linregress

# Import our components
from geometric_transformer_1M import GeometricTransformer, TransformType
from aletheia_token_system import AletheiaAgent, Channel

# ============================================================================
# MORPHON ATLAS (Simple Implementation)
# ============================================================================

class MorphonAtlas:
    """
    Atlas of stable morphonic embeddings.
    
    Maps context → stable embedding (RCE = Receipt-Carrying Embedding)
    """
    
    def __init__(self):
        self.atlas: Dict[str, np.ndarray] = {}
        self.hit_count: Dict[str, int] = {}
        self.miss_count: Dict[str, int] = {}
    
    def lookup(self, context: str) -> Tuple[bool, np.ndarray]:
        """
        Lookup context in atlas.
        
        Returns:
            (hit: bool, embedding: ndarray)
        """
        if context in self.atlas:
            self.hit_count[context] = self.hit_count.get(context, 0) + 1
            return True, self.atlas[context]
        else:
            self.miss_count[context] = self.miss_count.get(context, 0) + 1
            return False, None
    
    def store(self, context: str, embedding: np.ndarray):
        """Store embedding in atlas."""
        self.atlas[context] = embedding.copy()
    
    def get_hit_rate(self, context: str) -> float:
        """Get cache hit rate for context."""
        hits = self.hit_count.get(context, 0)
        misses = self.miss_count.get(context, 0)
        total = hits + misses
        return hits / total if total > 0 else 0.0

# ============================================================================
# MORPHONIC WRAPPER
# ============================================================================

class MorphonicWrapper:
    """
    Morphonic wrapper M: s → e ∈ E
    
    Properties:
    - Extensive: M(s) ⊇ s
    - Monotone: s₁ ⊆ s₂ ⇒ M(s₁) ⊆ M(s₂)
    - Idempotent: M(M(s)) = M(s)
    """
    
    def __init__(
        self,
        transformer: GeometricTransformer,
        token_agent: AletheiaAgent,
        atlas: MorphonAtlas
    ):
        self.transformer = transformer
        self.token_agent = token_agent
        self.atlas = atlas
    
    def wrap(self, context: str, state: np.ndarray) -> Tuple[np.ndarray, Dict]:
        """
        Apply morphonic wrapper to state.
        
        Returns:
            (embedding, metadata)
        """
        # Check atlas first
        hit, cached_embedding = self.atlas.lookup(context)
        
        if hit:
            # Cache hit - return cached embedding
            metadata = {
                'cache_hit': True,
                'delta_phi': 0.0,  # No computation needed
                'idempotent': True
            }
            return cached_embedding, metadata
        
        # Cache miss - compute new embedding
        # Transform through geometric transformer
        output, receipts = self.transformer.forward(state.reshape(1, -1, state.shape[-1]))
        
        # Extract embedding (mean over sequence)
        embedding = output.mean(axis=1).flatten()
        
        # Compute ΔΦ
        delta_phi = sum(r.delta_phi for r in receipts)
        
        # Store in atlas
        self.atlas.store(context, embedding)
        
        metadata = {
            'cache_hit': False,
            'delta_phi': delta_phi,
            'idempotent': False,  # First wrap
            'num_receipts': len(receipts)
        }
        
        return embedding, metadata
    
    def test_idempotence(self, context: str, state: np.ndarray) -> bool:
        """
        Test idempotence: M(M(s)) = M(s)
        
        Returns:
            True if idempotent
        """
        # First wrap
        e1, _ = self.wrap(context, state)
        
        # Second wrap (should be identical)
        e2, _ = self.wrap(context, state)
        
        # Check equality (within numerical tolerance)
        return np.allclose(e1, e2, rtol=1e-9, atol=1e-9)

# ============================================================================
# EXPERIMENT RUNNER
# ============================================================================

class MorphonicLockInExperiment:
    """Run the morphonic lock-in experiment."""
    
    def __init__(self):
        print("Initializing Morphonic Lock-In Experiment...")
        
        # Initialize components
        self.transformer = GeometricTransformer(
            base_dim=1024,  # Smaller for faster testing
            num_heads=16,
            num_layers=4
        )
        
        self.token_agent = AletheiaAgent(embedding_dim=1024)
        self.atlas = MorphonAtlas()
        self.wrapper = MorphonicWrapper(
            self.transformer,
            self.token_agent,
            self.atlas
        )
        
        # Test contexts
        self.contexts = [
            "orbital_transfer",
            "ocr_invoice_parse",
            "code_search"
        ]
        
        # Results storage
        self.results = {ctx: [] for ctx in self.contexts}
    
    def generate_state(self, context: str, iteration: int) -> np.ndarray:
        """
        Generate state for context.
        
        Add small noise to simulate slight variations in input.
        """
        # Base state from context hash
        np.random.seed(hash(context) % (2**32))
        base = np.random.randn(10, 1024) * 0.02
        
        # Add small iteration-dependent noise
        noise = np.random.randn(10, 1024) * 0.001 * (1.0 / (iteration + 1))
        
        return base + noise
    
    def run_solve(self, context: str, iteration: int) -> Dict:
        """Run one solve for context."""
        # Generate state
        state = self.generate_state(context, iteration)
        
        # Apply morphonic wrapper
        embedding, metadata = self.wrapper.wrap(context, state)
        
        # Compute JS distance to atlas mode (if exists)
        hit, atlas_embedding = self.atlas.lookup(context)
        if hit and atlas_embedding is not None:
            # Normalize to probability distributions for JS divergence
            p = np.abs(embedding) / np.abs(embedding).sum()
            q = np.abs(atlas_embedding) / np.abs(atlas_embedding).sum()
            js_distance = jensenshannon(p, q)
        else:
            js_distance = 1.0  # Max distance on first solve
        
        # Get cache hit rate
        hit_rate = self.atlas.get_hit_rate(context)
        
        return {
            'iteration': iteration,
            'context': context,
            'cache_hit': metadata['cache_hit'],
            'hit_rate': hit_rate,
            'delta_phi': metadata['delta_phi'],
            'js_distance': js_distance,
            'embedding_norm': np.linalg.norm(embedding)
        }
    
    def run_context(self, context: str, num_solves: int = 30):
        """Run experiment for one context."""
        print(f"\n{'='*70}")
        print(f"Testing context: {context}")
        print(f"{'='*70}")
        
        for i in range(num_solves):
            result = self.run_solve(context, i)
            self.results[context].append(result)
            
            if i % 5 == 0:
                print(f"  Solve {i:2d}: hit_rate={result['hit_rate']:.3f}, "
                      f"js_dist={result['js_distance']:.6f}, "
                      f"ΔΦ={result['delta_phi']:.6f}")
        
        # Test idempotence
        state = self.generate_state(context, 0)
        is_idempotent = self.wrapper.test_idempotence(context, state)
        print(f"\n  Idempotence test: {'✓ PASS' if is_idempotent else '✗ FAIL'}")
    
    def analyze_results(self):
        """Analyze results and compute metrics."""
        print(f"\n{'='*70}")
        print("ANALYSIS")
        print(f"{'='*70}")
        
        analysis = {}
        
        for context in self.contexts:
            results = self.results[context]
            
            # Extract time series
            iterations = [r['iteration'] for r in results]
            hit_rates = [r['hit_rate'] for r in results]
            js_distances = [r['js_distance'] for r in results]
            
            # Compute decay rate λ for JS distance
            # Fit exponential: js_t = js_0 * λ^t
            # log(js_t) = log(js_0) + t * log(λ)
            
            # Filter out zeros (log undefined)
            valid_points = [(i, js) for i, js in zip(iterations, js_distances) if js > 1e-10]
            
            if len(valid_points) > 5:
                iters, jss = zip(*valid_points)
                log_jss = np.log(jss)
                slope, intercept, r_value, p_value, std_err = linregress(iters, log_jss)
                lambda_est = np.exp(slope)
            else:
                lambda_est = None
            
            # Final hit rate
            final_hit_rate = hit_rates[-1] if hit_rates else 0.0
            
            # Monotonic increase in hit rate?
            hit_rate_increases = sum(
                1 for i in range(1, len(hit_rates))
                if hit_rates[i] >= hit_rates[i-1]
            )
            hit_rate_monotonic = hit_rate_increases / max(len(hit_rates) - 1, 1)
            
            analysis[context] = {
                'final_hit_rate': final_hit_rate,
                'hit_rate_monotonic_ratio': hit_rate_monotonic,
                'lambda_estimate': lambda_est,
                'final_js_distance': js_distances[-1] if js_distances else 1.0
            }
            
            print(f"\nContext: {context}")
            print(f"  Final hit rate: {final_hit_rate:.3f}")
            print(f"  Hit rate monotonic: {hit_rate_monotonic:.1%}")
            if lambda_est is not None:
                print(f"  Decay constant λ: {lambda_est:.6f}")
                print(f"    (λ < 1 means geometric decay: {'✓' if lambda_est < 1 else '✗'})")
            print(f"  Final JS distance: {js_distances[-1]:.6f}")
        
        return analysis
    
    def check_success_criteria(self, analysis: Dict) -> bool:
        """Check if experiment met success criteria."""
        print(f"\n{'='*70}")
        print("SUCCESS CRITERIA")
        print(f"{'='*70}")
        
        all_pass = True
        
        for context, metrics in analysis.items():
            print(f"\nContext: {context}")
            
            # Criterion 1: Hit rate increases monotonically
            hit_rate_ok = metrics['hit_rate_monotonic_ratio'] > 0.8
            print(f"  1. Hit rate ↑ monotonically: {'✓ PASS' if hit_rate_ok else '✗ FAIL'}")
            print(f"     (ratio: {metrics['hit_rate_monotonic_ratio']:.1%})")
            
            # Criterion 2: JS distance decreases geometrically (λ < 1)
            lambda_est = metrics['lambda_estimate']
            if lambda_est is not None:
                js_decay_ok = lambda_est < 1.0
                print(f"  2. JS distance ↓ geometrically: {'✓ PASS' if js_decay_ok else '✗ FAIL'}")
                print(f"     (λ = {lambda_est:.6f})")
            else:
                js_decay_ok = False
                print(f"  2. JS distance ↓ geometrically: ✗ FAIL (insufficient data)")
            
            # Criterion 3: Final hit rate > 0.8
            final_hit_ok = metrics['final_hit_rate'] > 0.8
            print(f"  3. Final hit rate > 0.8: {'✓ PASS' if final_hit_ok else '✗ FAIL'}")
            print(f"     (rate: {metrics['final_hit_rate']:.3f})")
            
            context_pass = hit_rate_ok and js_decay_ok and final_hit_ok
            all_pass = all_pass and context_pass
        
        print(f"\n{'='*70}")
        print(f"OVERALL: {'✓ ALL CRITERIA PASSED' if all_pass else '✗ SOME CRITERIA FAILED'}")
        print(f"{'='*70}")
        
        return all_pass
    
    def save_results(self, output_dir: str = "/home/ubuntu/experiment_1_results"):
        """Save results to JSON."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save raw results
        with open(output_path / "raw_results.json", 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\nResults saved to {output_dir}")
    
    def run(self):
        """Run complete experiment."""
        print("\n" + "="*70)
        print("EXPERIMENT 1: MORPHONIC LOCK-IN VALIDATION")
        print("="*70)
        
        # Run for each context
        for context in self.contexts:
            self.run_context(context, num_solves=30)
        
        # Analyze results
        analysis = self.analyze_results()
        
        # Check success criteria
        success = self.check_success_criteria(analysis)
        
        # Save results
        self.save_results()
        
        return success, analysis

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    experiment = MorphonicLockInExperiment()
    success, analysis = experiment.run()
    
    print("\n" + "="*70)
    print("EXPERIMENT COMPLETE")
    print("="*70)
    print(f"Success: {success}")

