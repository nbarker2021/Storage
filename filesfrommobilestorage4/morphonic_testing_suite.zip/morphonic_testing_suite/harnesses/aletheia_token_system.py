#!/usr/bin/env python3.11
"""
Aletheia Token Object System
=============================

Complete token-as-memory-fabric system with:
- Token Objects (TOs) with full geometric metadata
- RAG card graph with relationship tracking
- Aletheia CQE integration for embeddings
- Lambda calculus IR extraction
- Multi-view rendering (text/lambda/overlay/facts)
- Agent deployment package

This is the handout for all internal workers.
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_complete_v1/core_system')

import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Set
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json
import time
from pathlib import Path
from core.cqe_engine import CQEEngine

# ============================================================================
# TOKEN OBJECT STRUCTURE
# ============================================================================

class Channel(Enum):
    """Token channels."""
    TEXT = "text"
    CODE = "code"
    MATH = "math"
    GLYPH = "glyph"
    SCENE = "scene"
    AUDIO = "audio"
    RECEIPT = "receipt"
    CONTROL = "control"

class Role(Enum):
    """Token roles."""
    LEX = "lex"           # Lexical token
    OP = "op"             # Operator
    NUM = "num"           # Number
    SYM = "sym"           # Symbol
    DELIM = "delim"       # Delimiter
    FRAME = "frame"       # Frame marker
    META = "meta"         # Metadata
    ANCHOR = "anchor"     # Anchor point

class RelationType(Enum):
    """RAG relationship types."""
    BUCKET = "bucket"           # AGRM/MDHG bucket membership
    FRAME = "frame"             # Scene8/Worldforge frame
    BEAT = "beat"               # Temporal beat
    ISOMORPHIC = "isomorphic"   # Λ⊗TGA isomorphism
    COREF = "coref"             # Coreference
    DISAGREES = "disagrees"     # Conflicting interpretations
    DERIVES = "derives"         # Derivation relationship
    CONTAINS = "contains"       # Containment
    PRECEDES = "precedes"       # Temporal precedence

@dataclass
class TokenGeometry:
    """Geometric properties of a token."""
    parity: str  # "even" or "odd"
    dihedral: Dict[str, Any]  # {"N": int, "k": int, "reflect": bool}
    slice: str  # O|R|G|B|Y|N|A|V|M|C|K
    pos: Dict[str, Any]  # {"t": int, "rope": str}

@dataclass
class TokenEmbedding:
    """Embedding information for a token."""
    key: str  # Pointer to embedding store
    ladder: Dict[str, int]  # {"forward": dim, "reverse": dim}
    D: int  # Total dimension
    checksum: str  # SHA256 of embedding

@dataclass
class TokenMeta:
    """Metadata for a token."""
    types: List[str]  # Syndrome types
    lambda_ir: Optional[str]  # Lambda calculus IR
    constraints: List[str]  # Constraints
    safety: Dict[str, Any]  # Safety flags
    provenance: Dict[str, str]  # Source provenance

@dataclass
class TokenMemory:
    """Memory pointers for a token."""
    facts: List[str]  # Knowledge fact hashes
    rag_node: str  # RAG node ID
    overlays: List[str]  # ThinkTank/Worldforge overlays
    buckets: List[str]  # AGRM/MDHG buckets

@dataclass
class TokenReceipt:
    """Receipt for token creation/modification."""
    timestamp: float
    delta_phi: float  # Conservation law
    anchors: Dict[str, str]  # {"fwd": hash, "mir": hash}
    signature: str  # Cryptographic signature

@dataclass
class TokenObject:
    """
    Complete Token Object - a memory cell with identity, geometry, and provenance.
    
    This is the fundamental unit of the Aletheia token system.
    """
    id: str  # Stable content hash (tok:sha256:...)
    surface: Optional[str]  # Printable view
    channel: Channel
    role: Role
    geom: TokenGeometry
    emb: TokenEmbedding
    meta: TokenMeta
    mem: TokenMemory
    receipts: List[TokenReceipt]
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "surface": self.surface,
            "channel": self.channel.value,
            "role": self.role.value,
            "geom": {
                "parity": self.geom.parity,
                "dihedral": self.geom.dihedral,
                "slice": self.geom.slice,
                "pos": self.geom.pos
            },
            "emb": {
                "key": self.emb.key,
                "ladder": self.emb.ladder,
                "D": self.emb.D,
                "checksum": self.emb.checksum
            },
            "meta": {
                "types": self.meta.types,
                "lambda": self.meta.lambda_ir,
                "constraints": self.meta.constraints,
                "safety": self.meta.safety,
                "provenance": self.meta.provenance
            },
            "mem": {
                "facts": self.mem.facts,
                "rag": self.mem.rag_node,
                "overlays": self.mem.overlays,
                "buckets": self.mem.buckets
            },
            "receipts": [
                {
                    "t": r.timestamp,
                    "Δφ": r.delta_phi,
                    "anchors": r.anchors,
                    "sig": r.signature
                }
                for r in self.receipts
            ]
        }

# ============================================================================
# RAG CARD GRAPH
# ============================================================================

@dataclass
class RAGNode:
    """Node in the RAG card graph."""
    node_id: str  # Unique node ID
    token_id: str  # Associated token ID
    embedding_key: str  # Pointer to embedding
    metadata: Dict[str, Any]  # Additional metadata
    created: float  # Creation timestamp
    modified: float  # Last modification timestamp

@dataclass
class RAGEdge:
    """Edge in the RAG card graph."""
    edge_id: str  # Unique edge ID
    source_node: str  # Source node ID
    target_node: str  # Target node ID
    relation_type: RelationType
    weight: float  # Edge weight (0-1)
    metadata: Dict[str, Any]  # Additional metadata
    created: float  # Creation timestamp

class RAGCardGraph:
    """
    RAG card graph for tracking relationships between tokens.
    
    This is the knowledge graph that connects all Token Objects.
    """
    
    def __init__(self):
        self.nodes: Dict[str, RAGNode] = {}
        self.edges: Dict[str, RAGEdge] = {}
        self.node_edges: Dict[str, Set[str]] = {}  # node_id -> set of edge_ids
        
    def add_node(self, node: RAGNode):
        """Add a node to the graph."""
        self.nodes[node.node_id] = node
        if node.node_id not in self.node_edges:
            self.node_edges[node.node_id] = set()
    
    def add_edge(self, edge: RAGEdge):
        """Add an edge to the graph."""
        self.edges[edge.edge_id] = edge
        
        # Update node edge sets
        if edge.source_node not in self.node_edges:
            self.node_edges[edge.source_node] = set()
        if edge.target_node not in self.node_edges:
            self.node_edges[edge.target_node] = set()
        
        self.node_edges[edge.source_node].add(edge.edge_id)
        self.node_edges[edge.target_node].add(edge.edge_id)
    
    def get_neighbors(self, node_id: str, relation_type: Optional[RelationType] = None) -> List[str]:
        """Get neighbor node IDs for a given node."""
        if node_id not in self.node_edges:
            return []
        
        neighbors = []
        for edge_id in self.node_edges[node_id]:
            edge = self.edges[edge_id]
            
            # Filter by relation type if specified
            if relation_type and edge.relation_type != relation_type:
                continue
            
            # Add the other node
            if edge.source_node == node_id:
                neighbors.append(edge.target_node)
            else:
                neighbors.append(edge.source_node)
        
        return neighbors
    
    def get_path(self, source_id: str, target_id: str, max_depth: int = 5) -> Optional[List[str]]:
        """Find shortest path between two nodes (BFS)."""
        if source_id not in self.nodes or target_id not in self.nodes:
            return None
        
        if source_id == target_id:
            return [source_id]
        
        visited = {source_id}
        queue = [(source_id, [source_id])]
        
        while queue:
            current, path = queue.pop(0)
            
            if len(path) > max_depth:
                continue
            
            for neighbor in self.get_neighbors(current):
                if neighbor in visited:
                    continue
                
                new_path = path + [neighbor]
                
                if neighbor == target_id:
                    return new_path
                
                visited.add(neighbor)
                queue.append((neighbor, new_path))
        
        return None
    
    def export_graph(self, filepath: str):
        """Export graph to JSON."""
        data = {
            "nodes": [
                {
                    "node_id": n.node_id,
                    "token_id": n.token_id,
                    "embedding_key": n.embedding_key,
                    "metadata": n.metadata,
                    "created": n.created,
                    "modified": n.modified
                }
                for n in self.nodes.values()
            ],
            "edges": [
                {
                    "edge_id": e.edge_id,
                    "source": e.source_node,
                    "target": e.target_node,
                    "relation": e.relation_type.value,
                    "weight": e.weight,
                    "metadata": e.metadata,
                    "created": e.created
                }
                for e in self.edges.values()
            ]
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"Exported RAG graph: {len(self.nodes)} nodes, {len(self.edges)} edges")

# ============================================================================
# ALETHEIA TOKEN SYSTEM
# ============================================================================

class AletheiaTokenSystem:
    """
    Complete Aletheia token system integrating:
    - Token Object creation and management
    - CQE geometric embeddings
    - RAG card graph
    - Lambda calculus IR
    - Multi-view rendering
    """
    
    def __init__(self, embedding_dim: int = 320_000):
        """Initialize the token system."""
        self.cqe = CQEEngine()
        self.embedding_dim = embedding_dim
        self.tokens: Dict[str, TokenObject] = {}
        self.rag_graph = RAGCardGraph()
        self.embedding_store = {}  # key -> embedding vector
        
        print(f"Initialized Aletheia Token System:")
        print(f"  Embedding dimension: {embedding_dim:,}D")
        print(f"  E8 sublattices: {embedding_dim // 8:,}")
    
    def emit(
        self,
        surface: str,
        channel: Channel,
        role: Role,
        context: Optional[Dict] = None
    ) -> TokenObject:
        """
        Emit a new Token Object.
        
        Args:
            surface: Printable surface text
            channel: Token channel
            role: Token role
            context: Optional context for embedding
            
        Returns:
            TokenObject with full metadata
        """
        # Generate token ID (content hash)
        content = f"{surface}:{channel.value}:{role.value}"
        token_id = f"tok:sha256:{hashlib.sha256(content.encode()).hexdigest()[:16]}"
        
        # Compute geometric embedding via CQE
        embedding = self._compute_embedding(surface, context)
        embedding_key = f"vec:{hashlib.sha256(embedding.tobytes()).hexdigest()[:16]}"
        
        # Store embedding
        self.embedding_store[embedding_key] = embedding
        
        # Compute geometric properties
        geom = self._compute_geometry(embedding)
        
        # Extract lambda IR (if applicable)
        lambda_ir = self._extract_lambda_ir(surface, role)
        
        # Create Token Object
        token = TokenObject(
            id=token_id,
            surface=surface,
            channel=channel,
            role=role,
            geom=geom,
            emb=TokenEmbedding(
                key=embedding_key,
                ladder={"forward": 160_000, "reverse": 500_000},
                D=self.embedding_dim,
                checksum=hashlib.sha256(embedding.tobytes()).hexdigest()
            ),
            meta=TokenMeta(
                types=self._infer_types(surface, role),
                lambda_ir=lambda_ir,
                constraints=[],
                safety={"pii": False, "license": "internal", "policy": ["E1", "E4"]},
                provenance={"source": "emit", "version": hashlib.sha256(content.encode()).hexdigest()[:8]}
            ),
            mem=TokenMemory(
                facts=[],
                rag_node=f"node:{token_id}",
                overlays=[],
                buckets=[]
            ),
            receipts=[
                TokenReceipt(
                    timestamp=time.time(),
                    delta_phi=-0.001,  # Conservation law
                    anchors={
                        "fwd": hashlib.sha256(f"fwd:{token_id}".encode()).hexdigest()[:16],
                        "mir": hashlib.sha256(f"mir:{token_id}".encode()).hexdigest()[:16]
                    },
                    signature=hashlib.sha256(f"sig:{token_id}".encode()).hexdigest()
                )
            ]
        )
        
        # Store token
        self.tokens[token_id] = token
        
        # Add to RAG graph
        rag_node = RAGNode(
            node_id=token.mem.rag_node,
            token_id=token_id,
            embedding_key=embedding_key,
            metadata={"surface": surface, "channel": channel.value, "role": role.value},
            created=time.time(),
            modified=time.time()
        )
        self.rag_graph.add_node(rag_node)
        
        return token
    
    def connect(
        self,
        source_token_id: str,
        target_token_id: str,
        relation_type: RelationType,
        weight: float = 1.0,
        metadata: Optional[Dict] = None
    ):
        """Create a relationship between two tokens in the RAG graph."""
        if source_token_id not in self.tokens or target_token_id not in self.tokens:
            raise ValueError("Both tokens must exist")
        
        source_node = self.tokens[source_token_id].mem.rag_node
        target_node = self.tokens[target_token_id].mem.rag_node
        
        edge_id = f"edge:{hashlib.sha256(f'{source_node}:{target_node}:{relation_type.value}'.encode()).hexdigest()[:16]}"
        
        edge = RAGEdge(
            edge_id=edge_id,
            source_node=source_node,
            target_node=target_node,
            relation_type=relation_type,
            weight=weight,
            metadata=metadata or {},
            created=time.time()
        )
        
        self.rag_graph.add_edge(edge)
    
    def view_as_text(self, token_id: str) -> str:
        """Render token as text."""
        if token_id not in self.tokens:
            return ""
        return self.tokens[token_id].surface or ""
    
    def view_as_lambda(self, token_id: str) -> str:
        """Render token as lambda IR."""
        if token_id not in self.tokens:
            return "λ x. x"
        return self.tokens[token_id].meta.lambda_ir or "λ x. x"
    
    def view_as_overlay(self, token_id: str) -> Dict:
        """Render token as geometric overlay."""
        if token_id not in self.tokens:
            return {}
        
        token = self.tokens[token_id]
        return {
            "color_slice": token.geom.slice,
            "parity": token.geom.parity,
            "dihedral": token.geom.dihedral,
            "e8_sublattice": token.geom.pos.get("t", 0) % (self.embedding_dim // 8)
        }
    
    def view_as_facts(self, token_id: str) -> List[str]:
        """Render token as knowledge facts."""
        if token_id not in self.tokens:
            return []
        return self.tokens[token_id].mem.facts
    
    def view_as_embedding(self, token_id: str) -> Optional[np.ndarray]:
        """Get token embedding vector."""
        if token_id not in self.tokens:
            return None
        
        emb_key = self.tokens[token_id].emb.key
        return self.embedding_store.get(emb_key)
    
    def get_neighbors(self, token_id: str, relation_type: Optional[RelationType] = None) -> List[TokenObject]:
        """Get neighboring tokens in RAG graph."""
        if token_id not in self.tokens:
            return []
        
        rag_node = self.tokens[token_id].mem.rag_node
        neighbor_nodes = self.rag_graph.get_neighbors(rag_node, relation_type)
        
        # Convert node IDs to token IDs and retrieve tokens
        neighbor_tokens = []
        for node_id in neighbor_nodes:
            # Find token with this RAG node
            for tid, tok in self.tokens.items():
                if tok.mem.rag_node == node_id:
                    neighbor_tokens.append(tok)
                    break
        
        return neighbor_tokens
    
    def export_tokens(self, filepath: str):
        """Export all tokens to JSON."""
        tokens_data = [tok.to_dict() for tok in self.tokens.values()]
        
        with open(filepath, 'w') as f:
            json.dump(tokens_data, f, indent=2)
        
        print(f"Exported {len(tokens_data)} tokens to {filepath}")
    
    def export_rag_graph(self, filepath: str):
        """Export RAG graph to JSON."""
        self.rag_graph.export_graph(filepath)
    
    # Helper methods
    
    def _compute_embedding(self, surface: str, context: Optional[Dict]) -> np.ndarray:
        """Compute geometric embedding via CQE."""
        # Use CQE to embed the surface text
        # For now, create a deterministic embedding based on content
        seed = int(hashlib.sha256(surface.encode()).hexdigest()[:8], 16) % (2**31)
        rng = np.random.RandomState(seed)
        
        # Generate embedding in target dimension
        embedding = rng.randn(self.embedding_dim) * 0.02
        
        return embedding
    
    def _compute_geometry(self, embedding: np.ndarray) -> TokenGeometry:
        """Compute geometric properties from embedding."""
        # Parity
        parity = "even" if np.sum(embedding) % 2 < 1 else "odd"
        
        # Digital root
        dr = self.cqe.calculate_digital_root(np.sum(np.abs(embedding)))
        
        # Dihedral
        norm = np.linalg.norm(embedding)
        N = int(norm * 100 % 24) + 1
        k = int(np.sum(embedding) * 100 % N)
        reflect = bool(np.any(embedding < 0))
        
        dihedral = {"N": N, "k": k, "reflect": reflect}
        
        # Color slice
        slice_map = {
            (1, "even"): "O", (1, "odd"): "R",
            (3, "even"): "G", (3, "odd"): "B",
            (7, "even"): "Y", (7, "odd"): "N",
            (2, "even"): "A", (2, "odd"): "V",
            (4, "even"): "M", (4, "odd"): "C",
        }
        slice_color = slice_map.get((dr, parity), "K")
        
        # Position
        pos = {"t": int(norm * 1000) % 10000, "rope": f"d{dr}"}
        
        return TokenGeometry(
            parity=parity,
            dihedral=dihedral,
            slice=slice_color,
            pos=pos
        )
    
    def _extract_lambda_ir(self, surface: str, role: Role) -> Optional[str]:
        """Extract lambda IR from surface text."""
        # Simple pattern matching for common constructs
        if role == Role.OP:
            if surface in ['+', 'add']:
                return "λ x. λ y. (add x y)"
            elif surface in ['*', 'mul']:
                return "λ x. λ y. (mul x y)"
            elif surface in ['/', 'div']:
                return "λ x. λ y. (div x y)"
            elif surface == 'map':
                return "λ f. λ xs. (map f xs)"
            elif surface == 'filter':
                return "λ p. λ xs. (filter p xs)"
            elif surface == 'fold':
                return "λ f. λ acc. λ xs. (fold f acc xs)"
        
        elif role == Role.LEX:
            if surface in ['for', 'while', 'if']:
                return f"λ body. ({surface} body)"
        
        return None
    
    def _infer_types(self, surface: str, role: Role) -> List[str]:
        """Infer syndrome types from surface and role."""
        types = []
        
        if role == Role.OP:
            types.append("syntax:operator")
        elif role == Role.LEX:
            if surface in ['for', 'while']:
                types.append("syntax:loop")
            elif surface in ['if', 'else']:
                types.append("syntax:conditional")
            elif surface in ['def', 'class', 'function']:
                types.append("syntax:definition")
        elif role == Role.DELIM:
            if surface in ['{', '(', '[']:
                types.append("flow:scope:open")
            elif surface in ['}', ')', ']']:
                types.append("flow:scope:close")
        
        return types


# ============================================================================
# AGENT DEPLOYMENT PACKAGE
# ============================================================================

class AletheiaAgent:
    """
    Agent deployment package for internal workers.
    
    Provides high-level interface to the token system.
    """
    
    def __init__(self, embedding_dim: int = 320_000):
        """Initialize agent with token system."""
        self.token_system = AletheiaTokenSystem(embedding_dim)
        self.session_tokens: List[str] = []
    
    def tokenize(self, text: str, channel: Channel = Channel.TEXT) -> List[TokenObject]:
        """
        Tokenize text into Token Objects.
        
        Args:
            text: Input text
            channel: Token channel
            
        Returns:
            List of Token Objects
        """
        # Simple whitespace tokenization for demo
        # In production, use proper tokenizer
        words = text.split()
        
        tokens = []
        for word in words:
            # Infer role
            if word in ['+', '-', '*', '/', '=', '==', '!=']:
                role = Role.OP
            elif word.isdigit():
                role = Role.NUM
            elif word in ['{', '}', '(', ')', '[', ']', ',', ';']:
                role = Role.DELIM
            else:
                role = Role.LEX
            
            token = self.token_system.emit(word, channel, role)
            tokens.append(token)
            self.session_tokens.append(token.id)
        
        # Connect tokens sequentially
        for i in range(len(tokens) - 1):
            self.token_system.connect(
                tokens[i].id,
                tokens[i+1].id,
                RelationType.PRECEDES,
                weight=1.0
            )
        
        return tokens
    
    def query_rag(self, token_id: str, relation_type: Optional[RelationType] = None) -> List[TokenObject]:
        """Query RAG graph for related tokens."""
        return self.token_system.get_neighbors(token_id, relation_type)
    
    def render(self, token_id: str, view: str = "text") -> Any:
        """Render token in specified view."""
        if view == "text":
            return self.token_system.view_as_text(token_id)
        elif view == "lambda":
            return self.token_system.view_as_lambda(token_id)
        elif view == "overlay":
            return self.token_system.view_as_overlay(token_id)
        elif view == "facts":
            return self.token_system.view_as_facts(token_id)
        elif view == "embedding":
            return self.token_system.view_as_embedding(token_id)
        else:
            raise ValueError(f"Unknown view: {view}")
    
    def export_session(self, output_dir: str):
        """Export session data (tokens + RAG graph)."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        self.token_system.export_tokens(str(output_path / "tokens.json"))
        self.token_system.export_rag_graph(str(output_path / "rag_graph.json"))
        
        print(f"Session exported to {output_dir}")


# ============================================================================
# DEMO
# ============================================================================

def demo_token_system():
    """Demonstrate the complete Aletheia token system."""
    print("="*70)
    print("ALETHEIA TOKEN OBJECT SYSTEM DEMO")
    print("="*70)
    
    # Initialize agent
    agent = AletheiaAgent(embedding_dim=320_000)
    
    # Tokenize some code
    code = "for x in range 10 { print x }"
    print(f"\nTokenizing: {code}")
    
    tokens = agent.tokenize(code, Channel.CODE)
    
    print(f"\nGenerated {len(tokens)} Token Objects:")
    for i, tok in enumerate(tokens, 1):
        print(f"\n[{i}] {tok.surface}")
        print(f"  ID: {tok.id}")
        print(f"  Channel: {tok.channel.value}")
        print(f"  Role: {tok.role.value}")
        print(f"  Parity: {tok.geom.parity}")
        print(f"  Color slice: {tok.geom.slice}")
        print(f"  Dihedral: N={tok.geom.dihedral['N']}, k={tok.geom.dihedral['k']}")
        print(f"  Lambda IR: {tok.meta.lambda_ir or 'None'}")
        print(f"  RAG node: {tok.mem.rag_node}")
    
    # Query RAG graph
    print("\n" + "="*70)
    print("RAG GRAPH QUERIES")
    print("="*70)
    
    first_token_id = tokens[0].id
    print(f"\nNeighbors of '{tokens[0].surface}' (PRECEDES relation):")
    neighbors = agent.query_rag(first_token_id, RelationType.PRECEDES)
    for neighbor in neighbors:
        print(f"  → {neighbor.surface}")
    
    # Multi-view rendering
    print("\n" + "="*70)
    print("MULTI-VIEW RENDERING")
    print("="*70)
    
    test_token_id = tokens[0].id
    print(f"\nToken: {tokens[0].surface}")
    print(f"  Text view: {agent.render(test_token_id, 'text')}")
    print(f"  Lambda view: {agent.render(test_token_id, 'lambda')}")
    print(f"  Overlay view: {agent.render(test_token_id, 'overlay')}")
    
    # Export session
    agent.export_session("/home/ubuntu/aletheia_session")
    
    print("\n" + "="*70)
    print("DEMO COMPLETE")
    print("="*70)


if __name__ == "__main__":
    demo_token_system()

