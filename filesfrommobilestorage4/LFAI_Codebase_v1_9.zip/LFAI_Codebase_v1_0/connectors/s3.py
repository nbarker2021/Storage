"""S3 connector skeleton.
Provide: load_json(bucket, key) -> dict, list_objects(prefix) -> list[str].
Implementation intentionally omitted; fill with boto3 in deployment.
"""
def load_json(bucket: str, key: str):
    raise NotImplementedError

def list_objects(prefix: str):
    raise NotImplementedError
