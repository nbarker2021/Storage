# Provenance Channels (v1.9)

We extend painting into **multi-channel provenance**:

- **Color**: hex-16 gradient + neon parity (mod2/mod4/mod8) + Lie/Cartan tags (invented colors).
- **Grayscale**: content saturation; white=full, gray=hash-derived content level, black=brand-new token.
- **Resonance**: N → Hz; tags for detuning vs reference tones (110/220/440/880 Hz).
- **Haptic/Morse/Seismology**: hex → taps (ms), Morse code, ASCII seismo strips.

**Journals** tie fields to colors: write entries with `/journal/write` and view summaries with `/journal/summary`.
