from dataclasses import dataclass
from sandbox.rooms import Room

# Example of a custom room via plugin (no special powers; just a named binding).
@dataclass
class ExampleRoom(Room):
    pass

def register_plugin(reg):
    reg["ExampleRoom"] = ExampleRoom
