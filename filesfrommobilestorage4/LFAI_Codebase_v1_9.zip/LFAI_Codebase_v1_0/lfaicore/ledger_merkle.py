import json, hashlib, os, time
from typing import Any, Dict, List, Tuple

def _h(x: bytes) -> bytes:
    return hashlib.sha256(x).digest()

def _hx(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

class MerkleLedger:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(path):
            with open(path, "w") as f: pass

    def append(self, rec: Dict[str, Any]) -> str:
        payload = {"ts": time.time(), "rec": rec}
        line = json.dumps(payload, sort_keys=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        return hashlib.sha256(line.encode()).hexdigest()

    def _lines(self) -> List[str]:
        if not os.path.exists(self.path):
            return []
        return [ln.rstrip("\n") for ln in open(self.path, "r", encoding="utf-8")]

    def root(self) -> str:
        items = [ln.encode() for ln in self._lines()]
        if not items:
            return _hx(b"")
        layer = [ _h(x) for x in items ]
        while len(layer) > 1:
            if len(layer) % 2 == 1:
                layer.append(layer[-1])
            nxt = []
            for i in range(0, len(layer), 2):
                nxt.append(_h(layer[i] + layer[i+1]))
            layer = nxt
        return layer[0].hex()

    def proof(self, index: int) -> Dict[str, Any]:
        items = [ln.encode() for ln in self._lines()]
        n = len(items)
        if index < 0 or index >= n:
            raise IndexError("bad index")
        # build tree while recording siblings
        layer = [ _h(x) for x in items ]
        idx = index
        siblings = []
        while len(layer) > 1:
            if len(layer) % 2 == 1:
                layer.append(layer[-1])
            sib = idx ^ 1
            siblings.append(layer[sib].hex())
            idx = idx // 2
            nxt = []
            for i in range(0, len(layer), 2):
                nxt.append(_h(layer[i] + layer[i+1]))
            layer = nxt
        return {"index": index, "siblings": siblings, "root": layer[0].hex()}

# Simple replay for vec/frame ops: verify->reduce->uplift->anchor in order
from .frame import compile_from_glyphs
from .cona import legal_even, bits_from_vec
from .pal import pal_defects
from .uplift import uplift_u2
from .anchors import anchor_id

def replay_ops(ops: List[Dict[str,Any]], glyphs=None) -> Dict[str,Any]:
    f = compile_from_glyphs(glyphs or [8,13,32])
    state = {}
    for op in ops:
        name = op.get("op")
        if name == "verify":
            vec = op["vec"]
            legal, s = legal_even(vec); pd = pal_defects(vec)
            state["verify"] = {"legal": legal, "syndrome": s, "pal": pd}
        elif name == "reduce":
            # here we recompute defects post-reduce; full reducer in core can be used by caller
            vec = op["vec"]
            legal, s = legal_even(vec); pd = pal_defects(vec)
            state["reduce"] = {"post_legal": legal, "pal": pd}
        elif name == "uplift":
            vec = op["vec"]; steps = int(op.get("steps",1))
            v=list(vec)
            for _ in range(steps):
                v,f = uplift_u2(v, f)
            state["uplift"] = {"vec_out": v, "rest_scale": f.rest_scale, "mods": f.mods}
        elif name == "anchor":
            vec = op["vec"]
            aid,bits = anchor_id(vec, f); state["anchor"] = {"anchor_id": aid, "bounds_sig": bits}
    return {"frame":{"rest_scale": f.rest_scale, "mods": f.mods}, "state": state}
