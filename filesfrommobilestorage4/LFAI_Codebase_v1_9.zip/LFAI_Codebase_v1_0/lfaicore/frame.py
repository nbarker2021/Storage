from dataclasses import dataclass, field
from typing import List, Dict, Any
import math, hashlib, json
@dataclass
class Frame:
    tau: Dict[str,bool] = field(default_factory=lambda: {'repr_1_8': True, 'drive_1_4': False})
    dyadic_depth: int = 3
    mods: List[int] = field(default_factory=lambda: [2,4,8,13])
    faces: List[str] = field(default_factory=lambda: ['octad'])
    rest_scale: int = 8
    extras: Dict[str,Any] = field(default_factory=dict)
    def hash(self) -> str:
        return hashlib.sha256(json.dumps({'tau': self.tau,'dyadic_depth': self.dyadic_depth,'mods': self.mods,'faces': self.faces,'rest_scale': self.rest_scale,'extras': self.extras}, sort_keys=True).encode()).hexdigest()
def compile_from_glyphs(glyphs: List[int]) -> 'Frame':
    f = Frame()
    for g in glyphs:
        if g in (4,16,64):
            f.tau['drive_1_4']=True; f.rest_scale=max(f.rest_scale, 64 if g==64 else 16 if g==16 else 4); f.dyadic_depth=int(math.log2(f.rest_scale))
        if g in (8,32): f.tau['repr_1_8']=True; 
        for p in [2,3,5,7,11,13]:
            if g % p == 0 and p not in f.mods: f.mods.append(p)
        if g==13 and 'timing' not in f.faces: f.faces.append('timing')
    f.mods=sorted(set(f.mods))
    return f
