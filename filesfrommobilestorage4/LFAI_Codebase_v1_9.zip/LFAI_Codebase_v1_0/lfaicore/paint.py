import json, hashlib, colorsys
from typing import List, Dict, Any

# Universal 16-step gradient (hexadecimal nibbles 0..F → hue wheel)
# hue = k * 360/16; sat=1; val=1
PALETTE: Dict[str, str] = {}
for k in range(16):
    h = k / 16.0
    r,g,b = [int(255*x) for x in colorsys.hsv_to_rgb(h,1.0,1.0)]
    PALETTE["%x" % k] = f"#{r:02x}{g:02x}{b:02x}"

def palette() -> Dict[str,str]:
    return dict(PALETTE)

def _sha(s: bytes) -> str:
    return hashlib.sha256(s).hexdigest()

def paint_touch(vec: List[int], frame_hash: str, space: str, face: int, salt: str = "", length: int = 32) -> str:
    """Return a hex string 'stroke' capturing this touch.
    space: any stable identifier (e.g., 'room:<id>' or 'core:proof').
    face: 0..7 index (eight faces). length: number of hex nibbles to return.
    Deterministic and cheap: hex is the paint. """
    payload = json.dumps({"vec": vec, "frame": frame_hash, "space": space, "face": int(face), "salt": salt}, sort_keys=True).encode()
    hx = _sha(payload)
    return hx[:length]

def paint8(vec: List[int], frame_hash: str, space: str = "core:proof", salt: str = "", length: int = 32) -> List[str]:
    return [paint_touch(vec, frame_hash, space, i, salt=salt, length=length) for i in range(8)]

def hex_to_colors(hex_seq: str) -> List[str]:
    """Map hex digits to #RRGGBB using the universal palette."""
    cols = []
    for ch in hex_seq.lower():
        if ch in PALETTE:
            cols.append(PALETTE[ch])
    return cols

def merge_paint(a: str, b: str) -> str:
    """Nibble-wise XOR merge of two hex sequences (length=min)."""
    L = min(len(a), len(b))
    out = []
    for i in range(L):
        x = int(a[i], 16) ^ int(b[i], 16)
        out.append("%x" % x)
    return "".join(out)

def neon_palette(kind: str = "hex16") -> Dict[str,str]:
    """Neon palette mapping hex digits (0..f) to bright hues.
    kind can be 'hex16','mod2','mod4','mod8' to emphasize specific parity sets."""
    # Base neon from PALETTE; we reuse the same bright HSV(1,1) but expose selectors
    base = dict(PALETTE)
    if kind == "hex16":
        return base
    if kind == "mod2":
        # even -> neon lime, odd -> neon magenta, map all digits by their parity
        even = "#39ff14"  # neon lime
        odd  = "#ff00ff"  # neon magenta
        return {d:(even if int(d,16)%2==0 else odd) for d in base}
    if kind == "mod4":
        ll = ["#00fff7", "#ff00ff", "#39ff14", "#ff5f1f"]  # cyan, magenta, lime, orange
        return {d: ll[int(d,16)%4] for d in base}
    if kind == "mod8":
        hues = ["#00fff7","#8aff00","#ff00ff","#ffff00","#39ff14","#ff5f1f","#00f0ff","#b300ff"]
        return {d: hues[int(d,16)%8] for d in base}
    return base

def parity_hist(vec: List[int], m: int) -> List[int]:
    c=[0]*m
    for x in vec: c[x % m]+=1
    return c

def parity_paint(vec: List[int], frame_hash: str, space: str = "core:proof", levels = ("mod2","mod4","mod8"), length: int = 32) -> Dict[str, List[str]]:
    out={}
    for level in levels:
        m = 2 if level=="mod2" else 4 if level=="mod4" else 8
        hist = parity_hist(vec, m)
        seqs=[]
        for r in range(m):
            payload = json.dumps({"frame":frame_hash,"space":space,"parity":level,"class":r,"hist":hist}, sort_keys=True).encode()
            hx = _sha(payload)[:length]
            seqs.append(hx)
        out[level]=seqs
    return out

def hue_shift_hex(seq: str, shift: int) -> str:
    shift = int(shift) % 16
    return "".join([("%x" % ((int(ch,16)+shift) % 16)) for ch in seq.lower() if ch in PALETTE])

# ---- Grayscale (saturation / content levels) ----
def grayscale_strip(vec: List[int], space: str = "core:proof", new_token: bool = False, length: int = 32) -> str:
    """White = fully saturated (max content); gray shades = content (hash-derived);
    black = unsaturated (brand-new tokens). Returns hex nibble string where each
    nibble maps to a gray value (#vvvvvv)."""
    if new_token:
        return "0"*length  # maps to black in UI
    h = _sha(json.dumps({"vec":vec,"space":space}, sort_keys=True).encode())
    return h[:length]

def gray_color_for_nibble(ch: str) -> str:
    """Map nibble to a gray color; '0' black, 'f' white."""
    v = int(ch,16)
    g = int(255 * (v/15.0))
    return f"#{g:02x}{g:02x}{g:02x}"

def grayscale_to_colors(seq: str) -> List[str]:
    return [gray_color_for_nibble(ch) for ch in seq.lower() if ch in PALETTE]

# ---- Lie/Cartan group color tags (heuristic mapping) ----
_LIE_COLORS = {
    "E8": "#ff1493",   # deep pink (invented 'E8 neon')
    "E7": "#ff6ec7",
    "E6": "#ff85d8",
    "F4": "#ff5f1f",
    "G2": "#39ff14",
    "SO(10)": "#00fff7",
    "SU(3)": "#ffff00",
    "SU(2)": "#b300ff",
    "U(1)": "#ffffff",
}

def lie_cartan_tags(mods: List[int]) -> List[dict]:
    """Heuristic: map presence of residues to group tags; invented colors."""
    tags=[]
    if 8 in mods: tags.append({"group":"E8","color":_LIE_COLORS["E8"]})
    if 4 in mods and 2 in mods: tags.append({"group":"SU(2)","color":_LIE_COLORS["SU(2)"]})
    if 3 in mods: tags.append({"group":"SU(3)","color":_LIE_COLORS["SU(3)"]})
    if 5 in mods: tags.append({"group":"SO(10)","color":_LIE_COLORS["SO(10)"]})
    if 7 in mods: tags.append({"group":"G2","color":_LIE_COLORS["G2"]})
    if 24 in mods: tags.append({"group":"F4","color":_LIE_COLORS["F4"]})
    if not tags: tags.append({"group":"U(1)","color":_LIE_COLORS["U(1)"]})
    return tags

# ---- Color conflict resolver ----
def resolve_palette_conflict(colors: List[str], mode: str = "priority") -> str:
    """Return a single color from a set by rule.
    priority: pick the first non-white, non-black; blend: average RGB; xor: nibble XOR of hex."""
    if not colors: return "#000000"
    if mode=="priority":
        for c in colors:
            if c.lower() not in ("#000000","#ffffff"):
                return c
        return colors[0]
    if mode=="blend":
        def rgb(c):
            return int(c[1:3],16), int(c[3:5],16), int(c[5:7],16)
        rs,gs,bs=0,0,0
        for c in colors:
            r,g,b = rgb(c); rs+=r; gs+=g; bs+=b
        n=len(colors)
        return f"#{rs//n:02x}{gs//n:02x}{bs//n:02x}"
    # xor
    acc = 0
    for c in colors:
        acc ^= int(c[1:],16)
    return f"#{acc:06x}"

# ---- Resonance tags ----
def resonance_tags(vec: List[int], refs: List[int] = [110, 220, 440, 880]) -> List[dict]:
    """Map integers to Hz, compute detuning vs reference tones; return tags sorted by closeness."""
    tags=[]
    for x in vec:
        if x<=0: continue
        for r in refs:
            delta = abs(x - r)
            rel = delta / r
            if rel <= 0.1:  # within 10%
                tags.append({"N": x, "ref": r, "detune": rel})
    tags.sort(key=lambda t: t["detune"])
    return tags[:8]

# ---- Haptic/Morse/Seismo textures ----
_MORSE = { '0':"-----",'1':".----",'2':"..---",'3':"...--",'4':"....-",'5':".....",
           '6':"-....",'7':"--...",'8':"---..",'9':"----.",'a':".-",'b':"-...",
           'c':"-.-.",'d':"-..",'e':".",'f':"..-." }

def morse_from_hex(seq: str) -> str:
    return " ".join(_MORSE.get(ch,"") for ch in seq.lower())

def haptic_pattern(seq: str) -> List[int]:
    """Map hex to taps (ms): 0..f -> 0..300ms; zeros produce small gaps."""
    return [ int(int(ch,16) * (300/15.0)) for ch in seq.lower() if ch in PALETTE ]

def seismo_texture(seq: str, width: int = 32, height: int = 8) -> List[str]:
    """ASCII strip; map hex to vertical positions."""
    rows = [ [" "] * width for _ in range(height) ]
    for i,ch in enumerate(seq[:width]):
        v = int(ch,16) / 15.0
        y = height-1 - int(v * (height-1))
        rows[y][i] = "█"
    return ["".join(r) for r in rows]
