from typing import List, Dict, Any
from ..frame import Frame
from ..pal import pal_defects
from ..gating import latch_sweep
from ..uplift import uplift_u2
def run(buf: bytes, vec: List[int], frame: Frame) -> Dict[str,Any]:
    i=0; latches=[0]*8; payloads=[]; pins_req=set(); pins_sat=set()
    while i<len(buf):
        op=buf[i]; i+=1
        if op==0o00: pass
        elif op==0o01: frame.tau['repr_1_8']=True
        elif op==0o02: frame.tau['drive_1_4']=True
        elif op==0o03: vec, frame = uplift_u2(vec, frame)
        elif op==0o04:
            if 13 not in frame.mods: frame.mods.append(13); frame.mods.sort()
        elif op==0o05:
            if 5 not in frame.mods: frame.mods.append(5); frame.mods.sort()
        elif op==0o06:
            if 7 not in frame.mods: frame.mods.append(7); frame.mods.sort()
        elif op==0o07:
            if 11 not in frame.mods: frame.mods.append(11); frame.mods.sort()
        elif op==0o10: pass
        elif op==0o11: _=pal_defects(vec)
        elif op==0o12:
            idx=min(range(len(vec)), key=lambda k: abs(vec[k])); vec[idx]+=1
        elif op==0o13:
            latches=latch_sweep(vec)
        elif op==0o14:
            if all(latches): pass
        elif op==0o15:
            k=int.from_bytes(buf[i:i+2],'big'); i+=2
            for _ in range(k): vec, frame = uplift_u2(vec, frame)
        elif op==0o16:
            if 'timing' not in frame.faces: frame.faces.append('timing')
        elif op==0o17:
            if 'octad' not in frame.faces: frame.faces.append('octad')
        elif op in (0o20,0o21,0o24,0o25):
            L=int.from_bytes(buf[i:i+2],'big'); i+=2; b=buf[i:i+L]; i+=L
            if op in (0o20,0o21): payloads.append(b)
            elif op==0o24: pins_req.add(b.decode('utf-8','replace'))
            else: pins_sat.add(b.decode('utf-8','replace'))
        elif 0o40<=op<=0o44:
            mapping={0o40:2,0o41:4,0o42:8,0o43:16,0o44:64}
            frame.rest_scale=mapping[op]; frame.dyadic_depth={2:1,4:2,8:3,16:4,64:6}[frame.rest_scale]
        else: pass
    return {'vec':vec,'frame':frame,'latches':latches,'payloads_count':len(payloads),'pins_required':sorted(list(pins_req)),'pins_satisfied':sorted(list(pins_sat))}
