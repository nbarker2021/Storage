def test_journal_write_and_summary():
    from lfaicore.journal import write, summary
    vec=[1,2,3,4,5,6,7,8]
    rec = write("demo", vec, "f"*64, {"mods":[2,4,8]})
    s = summary("demo", limit=1)
    assert s["count"]>=1 and "paint8" in s["samples"][0]

def test_channels_outputs():
    from lfaicore.paint import grayscale_strip, lie_cartan_tags, resonance_tags, morse_from_hex, haptic_pattern, seismo_texture
    vec=[110,220,7,8,9,440,880,13]
    g = grayscale_strip(vec)
    assert isinstance(g, str) and len(g)>=16
    tags = lie_cartan_tags([2,4,8,7])
    assert any(t["group"]=="E8" for t in tags)
    res = resonance_tags(vec)
    assert any(t["ref"]==440 for t in res)
    m = morse_from_hex("deadbeef")
    h = haptic_pattern("cafe")
    s = seismo_texture("0123456789abcdef")
    assert isinstance(m,str) and isinstance(h,list) and isinstance(s,list) and len(s)>0
