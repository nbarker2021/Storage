// Minimal Go SDK (handshake + channels). Not a full module file; drop into your project.
package lfai

import (
  "bytes"
  "crypto/hmac"
  "crypto/sha256"
  "encoding/hex"
  "encoding/json"
  "net/http"
  "time"
)

type Client struct {
  Base string
  SID  string
  Key  []byte
}

func New(base string) *Client { return &Client{Base: base} }

func (c *Client) post(path string, body interface{}, out interface{}) error {
  b, _ := json.Marshal(body)
  req, _ := http.NewRequest("POST", c.Base+path, bytes.NewReader(b))
  req.Header.Set("content-type","application/json")
  resp, err := http.DefaultClient.Do(req)
  if err != nil { return err }
  defer resp.Body.Close()
  return json.NewDecoder(resp.Body).Decode(out)
}

func (c *Client) Start(info map[string]interface{}) error {
  var out struct{ Sid, Hmac_key string `json:"sid","hmac_key"` }
  if err := c.post("/handshake/start", map[string]interface{}{"client":info}, &out); err != nil { return err }
  c.SID = out.Sid
  key, _ := hex.DecodeString(out.Hmac_key)
  c.Key = key
  return nil
}

func (c *Client) sig(payload map[string]interface{}) string {
  b,_ := json.Marshal(payload)
  mac := hmac.New(sha256.New, c.Key)
  mac.Write(b)
  return hex.EncodeToString(mac.Sum(nil))
}

func (c *Client) Prefire(quad []interface{}, control map[string]interface{}) (map[string]interface{}, error) {
  pay := map[string]interface{}{"sid": c.SID, "payload_quad": quad, "ts": time.Now().Unix()}
  sig := c.sig(pay)
  var out map[string]interface{}
  err := c.post("/channel/prefire", map[string]interface{}{"sid":c.SID, "payload_quad": quad, "control": control, "sig": sig}, &out)
  return out, err
}

func (c *Client) Post(lanes []interface{}) (map[string]interface{}, error) {
  pay := map[string]interface{}{"sid": c.SID, "out_lanes": lanes, "ts": time.Now().Unix()}
  sig := c.sig(pay)
  var out map[string]interface{}
  err := c.post("/channel/post", map[string]interface{}{"sid":c.SID, "out_lanes": lanes, "sig": sig}, &out)
  return out, err
}

func (c *Client) Finish(commit map[string]interface{}) (map[string]interface{}, error) {
  var out map[string]interface{}
  err := c.post("/channel/finish", map[string]interface{}{"sid":c.SID, "commit_payload": commit}, &out)
  return out, err
}
