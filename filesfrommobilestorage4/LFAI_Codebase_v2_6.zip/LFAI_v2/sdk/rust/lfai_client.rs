// Minimal Rust stub (requires reqwest, serde_json, hmac, sha2 crates in your Cargo.toml)
use std::collections::HashMap;
use hmac::{Hmac, Mac};
use sha2::Sha256;

pub struct Client {
    pub base: String,
    pub sid: Option<String>,
    pub key: Option<Vec<u8>>,
}

impl Client {
    pub fn new(base: &str) -> Self { Self{ base: base.to_string(), sid: None, key: None } }

    pub async fn start(&mut self, info: serde_json::Value) -> anyhow::Result<serde_json::Value> {
        let body = serde_json::json!({"client": info});
        let resp = reqwest::Client::new().post(format!("{}/handshake/start", self.base)).json(&body).send().await?;
        let v: serde_json::Value = resp.json().await?;
        self.sid = v.get("sid").and_then(|x| x.as_str()).map(|s| s.to_string());
        self.key = v.get("hmac_key").and_then(|x| x.as_str()).map(|hex| hex::decode(hex).ok()).flatten();
        Ok(v)
    }

    fn sig(&self, payload: &serde_json::Value) -> anyhow::Result<String> {
        let key = self.key.as_ref().ok_or_else(|| anyhow::anyhow!("no key"))?;
        let mut mac = Hmac::<Sha256>::new_from_slice(key)?;
        mac.update(serde_json::to_string(payload)?.as_bytes());
        Ok(hex::encode(mac.finalize().into_bytes()))
    }
}
