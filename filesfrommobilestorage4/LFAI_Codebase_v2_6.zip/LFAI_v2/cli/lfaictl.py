#!/usr/bin/env python3
import sys, json, argparse, importlib, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from lfaicore.ingress import ingress_state
from lfaicore.runtime import OctetExecutor

def cmd_ingress(args):
    vec = json.loads(args.vector)
    print(json.dumps(ingress_state(vec), indent=2))

def cmd_run(args):
    mod_name, fn_name = args.fn.rsplit(":",1) if ":" in args.fn else (args.fn, None)
    mod = importlib.import_module(mod_name)
    block = getattr(mod, fn_name) if fn_name else getattr(mod, "moving_avg_octet")
    lanes = json.loads(args.lanes)
    exe = OctetExecutor()
    out = exe.run(block, tuple(lanes))
    print(json.dumps(out, indent=2))

def main():
    ap = argparse.ArgumentParser(prog="lfaictl")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("ingress"); p1.add_argument("--vector", required=True); p1.set_defaults(func=cmd_ingress)
    p2 = sub.add_parser("run"); p2.add_argument("--fn", required=True); p2.add_argument("--lanes", required=True); p2.set_defaults(func=cmd_run)
    args = ap.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
