# Handshake & Channels (v2.3)

**Goal:** Other code stays in its native runtime. It only handshakes; we do prepose/wrap/legality/ledger. They compute; we verify/commit.

## Flow
1. **/handshake/start** → returns `{sid, hmac_key, nonce}`.
2. **/channel/prefire** (client → us): send payload quad `x0..x3`, we return lanes `[x0..x3,p4,p8,r,f]`, `pre_anchor`, and gate status.
3. Client runs its function locally on those lanes.
4. **/channel/post** (client → us): send out lanes `[y0..y3,p4',p8',r',f']`, we verify pal-4 + E8 + anchors, write to ledger.
5. **/channel/finish** → close + optional commit payload.

All messages can be HMAC-signed with the per-session key.

## Minimal Python client
```python
from sdk.python.lfai_client import LFAIClient
cli=LFAIClient("http://localhost:8000")
cli.start({"lang":"python","lib":"numpy","fn":"my_kernel"})
pref=cli.prefire([1,2,3,4])           # we prepose + gate
lanes=pref["lanes"]
# ... run local compute using lanes ...
out = [1.5,2.5,3.5,2.5, lanes[4],lanes[5],lanes[6],lanes[7]]
post=cli.post(out)                     # we verify + ledger
cli.finish({"note":"demo commit"})
```

## Notes
- We never execute foreign code. We execute **the corridor**: prepose, Π4 wrap, legality, faces, ledger.
- If `pal4_ok` or `legal_e8` is false at either step, you get a **STOP/NTER**-style fail with precise flags.
- Replace the E8 stub with your real kernel for production.

## Planner finish
- `POST /planner/finish` {tokens[]} → deterministic mod-4 split when unsettled ≤ 4.

## Ledger paints
- `/octet/run` and `/channel/post` now record compact paint signatures (`in_paint`, `out_paint`) alongside anchors.
