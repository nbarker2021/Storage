# Config & Backends

File: `/mnt/data/lfai_config.json`

```json
{
  "legality_backend": "surrogate",
  "faces_backend": "builtin",
  "face_thresholds": [0,0,0,0,0,0,0,0]
}
```

- `legality_backend`: `"surrogate"` (default) or `"module:function"` that accepts `List[int]` (len 8) and returns `(bool, List[int])`.
- `faces_backend`: `"builtin"` or `"module:function"` that accepts `List[int]` and returns `List[float]` length 8.
- `face_thresholds`: per-face thresholds for pass/fail (demo rule).

API:
- `GET /config/get` → current config
- `POST /config/set` {config} → update & persist
