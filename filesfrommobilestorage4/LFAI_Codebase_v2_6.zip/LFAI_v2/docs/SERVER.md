# LFAI v2.2 API Server

Start:
```
uvicorn api_server:app --reload
```

Endpoints:
- POST `/ingress` {vector[]} → Defined Spaces checks
- POST `/octet/run` {module, fn?, lanes[8]} → run λ8 block with Π4 + legality + certs
- POST `/unfold/run` {module, fn?, variants[[8],...]} → fan-out, pick normal form
- POST `/planner/run` {tokens[], max_iters?}
- GET  `/planner/config` / PUT `/planner/config` {config}
- POST `/commit/atomic` {payload} → append to ledger (hash chain)
- POST `/proof/state` {vector[]} → ingress + ledger entry + chain check
- POST `/ledger/paint` {seq[]} / GET `/ledger/paint` → paint timeline
- GET  `/ledger/read` → recent entries + chain_ok
