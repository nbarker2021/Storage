from lfaicore.octet import octet

@octet(bitwrap="pi4", involution=True, faces="GEN")
def moving_avg_octet(x0,x1,x2,x3,p4,p8,r,f):
    try:
        a,b,c,d = int(x0), int(x1), int(x2), int(x3)
    except Exception:
        a=b=c=d=0
    y0=(a+b)/2; y1=(b+c)/2; y2=(c+d)/2; y3=(d+a)/2
    return y0,y1,y2,y3, p4, p8, r, f

if __name__ == "__main__":
    print(moving_avg_octet(1,2,3,4,0,0,0,0))
