import os, json

CFG_PATH = "/mnt/data/lfai_config.json"
DEFAULT = {
  "legality_backend": "surrogate",     # or "module:function" (e.g., "my_e8:check")
  "faces_backend": "builtin",          # or "module:function"
  "face_thresholds": [0.0]*8           # optional per-face thresholds
}

def load() -> dict:
  if os.path.exists(CFG_PATH):
    try:
      return json.loads(open(CFG_PATH,"r",encoding="utf-8").read())
    except Exception:
      return DEFAULT.copy()
  return DEFAULT.copy()

def save(cfg: dict):
  data = load(); data.update(cfg or {})
  open(CFG_PATH,"w",encoding="utf-8").write(json.dumps(data, indent=2))
  return data

def get(key: str, default=None):
  return load().get(key, default)
