from typing import List, Dict, Any, Callable
import importlib
from .config import get as cfgget

def builtin_faces(vec: List[int]) -> List[float]:
    if not vec: return [0.0]*8
    n=len(vec); s=sum(vec); a=s/n
    absmean=sum(abs(x) for x in vec)/n
    return [min(vec), max(vec), a, 0.5, 0.5, absmean, 0.1, float(n)]

def _load_faces_backend() -> Callable[[List[int]], List[float]]:
    spec = cfgget("faces_backend", "builtin")
    if spec == "builtin" or not spec:
        return builtin_faces
    try:
        mod_name, fn_name = spec.split(":")
        mod = importlib.import_module(mod_name)
        return getattr(mod, fn_name)
    except Exception:
        return builtin_faces

_BACKEND=None

def face_functionals(vec: List[int]) -> List[float]:
    global _BACKEND
    if _BACKEND is None:
        _BACKEND=_load_faces_backend()
    return _BACKEND(vec)

def evaluate_faces(vec: List[int], thresholds: List[float] = None) -> Dict[str, Any]:
    f = face_functionals(vec)
    th = thresholds or cfgget("face_thresholds", [0.0]*8)
    # Simple rule: face passes if f[i] >= th[i] (demo; real faces will have per-face inequalities)
    passes = [(fi >= (th[i] if i < len(th) else 0.0)) for i,fi in enumerate(f)]
    fail_idx = [i for i,p in enumerate(passes) if not p]
    return {"f": f, "thresholds": th, "passes": passes, "fail_idx": fail_idx}
