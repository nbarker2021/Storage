from functools import wraps
from typing import Callable, Dict, Any, Iterable, Tuple
import hashlib, json, inspect
from .bitwrap import bitwrap_pi4, pal4_ok_bytes, pal4_defect_bytes
from .cona_e8 import constructionA_E8_check
from .gating import evaluate_faces

def to_bytes_lane(x) -> bytes:
    if isinstance(x, bytes): return x
    if isinstance(x, str): return x.encode('utf-8', 'ignore')
    if isinstance(x, (int, float)):
        return int(x).to_bytes(8, 'little', signed=True)
    if isinstance(x, Iterable):
        return bytes(int(v) & 0xFF for v in x)
    return json.dumps(x, sort_keys=True).encode()

def _legal_from_bytes(*lanes: bytes) -> Tuple[bool, list]:
    blob=b''.join(lanes)
    blob += b'\x00' * ((64 - (len(blob)%64))%64)
    ints=[blob[i] for i in range(64)]
    legal, synd = constructionA_E8_check(ints[:8])
    return bool(legal), synd

def anchor_hash(payload: Dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

def _suggest_patches(pal_ok, legal_ok, faces):
    fixes=[]
    if not pal_ok: fixes.append("flip p4 (repack quads) or re-pack inputs")
    if not legal_ok: fixes.append("toggle p8 / adjust residue r to meet parity")
    if faces and not all(faces.get('passes', [])):
        idx=faces.get('fail_idx', [])
        if 2 in idx: fixes.append("raise mean via x-lanes or lower f2 threshold")
        if 0 in idx: fixes.append("increase min via clamp or pose shift")
        if 1 in idx: fixes.append("reduce max via normalization")
    return fixes

def octet(bitwrap: str = "pi4", involution: bool = True, faces: str = "GEN"):
    def deco(fn: Callable):
        sig = inspect.signature(fn)
        nparams = len([p for p in sig.parameters.values() if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])

        @wraps(fn)
        def wrapper(*args, **kwargs):
            if len(args) != 8:
                raise ValueError("octet requires 8 lanes")
            # lanes → bytes
            lanes = [to_bytes_lane(a) for a in args]
            if bitwrap == "pi4":
                lanes_wrapped = [bitwrap_pi4(b) for b in lanes]
            else:
                lanes_wrapped = lanes[:]
            # pal-4 on payload lanes (0..3)
            pal_ok = all(pal4_ok_bytes(b) for b in lanes_wrapped[:4])
            pal_defects = [pal4_defect_bytes(b) for b in lanes_wrapped[:4]]
            legal_e8, synd = _legal_from_bytes(*lanes_wrapped)
            # crude int vec from bytes for faces
            ints = [b[0] if isinstance(b, (bytes,bytearray)) and len(b)>0 else 0 for b in lanes_wrapped]
            faces = evaluate_faces(ints)

            pre_anchor = anchor_hash({"fn": fn.__name__, "in": str(args)})
            if not (pal_ok and legal_e8 and all(faces['passes'])):
                return {"ok": False, "pal4_ok": pal_ok, "pal4_defects": pal_defects,
                        "legal_e8": legal_e8, "syndrome": synd, "stop": True,
                        "nter": [
                            {"kind":"pal4","lanes":[i for i,d in enumerate(pal_defects) if d>0]} if not pal_ok else {},
                            {"kind":"legal","syndrome": synd} if not legal_e8 else {},
                            {"kind":"faces","fail_idx": faces.get('fail_idx', [])} if not all(faces.get('passes', [])) else {}
                        ],
                        "faces": faces,
                        "suggest": _suggest_patches(pal_ok, legal_e8, faces),
                        "pre_anchor": pre_anchor

            # Role inference: pass 4 or 8 args to fn depending on signature
            x0,x1,x2,x3,p4,p8,r,f = args
            if nparams >= 8:
                out = fn(x0,x1,x2,x3,p4,p8,r,f)
            elif nparams == 4:
                out = fn(x0,x1,x2,x3)
                if not (isinstance(out,(tuple,list)) and len(out)==4):
                    raise ValueError("4-arg octet fn must return 4 payload lanes")
                out = (*out, p4,p8,r,f)
            else:
                # fallback: try positional mapping up to 8
                out = fn(*args, **kwargs)

            if not (isinstance(out,(tuple,list)) and len(out)==8):
                raise ValueError("octet fn must return 8 lanes")

            post_anchor = anchor_hash({"fn": fn.__name__, "out": str(out)})
            return {"ok": True, "out": out, "pal4_ok": pal_ok, "pal4_defects": pal_defects,
                    "legal_e8": legal_e8, "syndrome": synd,
                    "pre_anchor": pre_anchor, "post_anchor": post_anchor}
        return wrapper
    return deco
