from typing import Any, Dict, Tuple, Callable, Optional
import hashlib, json

from .bitwrap import bitwrap_pi4, pal4_ok_bytes
from .octet import to_bytes_lane, anchor_hash, legal_e8_from_bytes

def prepose_defaults() -> Tuple[int,int,int,int]:
    return (0, 0, 0, 0)

def reverse_hash(payload: Dict[str, Any]) -> str:
    return hashlib.blake2s(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

class OctetExecutor:
    def __init__(self, bitwrap: str = "pi4"):
        self.bitwrap = bitwrap

    def _wrap(self, b: bytes) -> bytes:
        return bitwrap_pi4(b) if self.bitwrap == "pi4" else b

    def run(self, block: Callable, args: Tuple[Any,Any,Any,Any,Any,Any,Any,Any],
            prepose: Optional[Tuple[Any,Any,Any,Any]] = None) -> Dict[str, Any]:
        if prepose is None:
            p4,p8,r,f = prepose_defaults()
        else:
            p4,p8,r,f = prepose
        x0,x1,x2,x3, _p4,_p8,_r,_f = args
        lanes = [to_bytes_lane(a) for a in (x0,x1,x2,x3,p4,p8,r,f)]
        wrapped = [self._wrap(b) for b in lanes]
        pal_ok = all(pal4_ok_bytes(b) for b in wrapped[:4])
        legal_e8 = legal_e8_from_bytes(*wrapped)
        pre_anchor = anchor_hash({"block": getattr(block,"__name__",str(block)), "in": str(args)})
        if not (pal_ok and legal_e8):
            return {"ok": False, "pal4_ok": pal_ok, "legal_e8": legal_e8, "pre_anchor": pre_anchor}
        out = block(x0,x1,x2,x3,p4,p8,r,f)
        if not (isinstance(out,(tuple,list)) and len(out)==8):
            return {"ok": False, "reason":"bad_arity", "pre_anchor": pre_anchor}
        rev = reverse_hash({"in": args, "out": tuple(out)})
        post_anchor = anchor_hash({"block": getattr(block,"__name__",str(block)), "out": str(out)})
        return {
            "ok": True, "out": list(out),
            "pal4_ok": pal_ok, "legal_e8": legal_e8,
            "pre_anchor": pre_anchor, "post_anchor": post_anchor, "rev_hash": rev
        }
