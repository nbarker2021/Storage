from typing import List, Tuple, Callable
import importlib
from .config import get as cfgget

# --- Surrogate checks ---
def _is_even_sum(v: List[int]) -> bool:
    return (sum(v) & 1) == 0

def _even_norm(v: List[int]) -> bool:
    return (sum((x*x) for x in v) & 1) == 0

def _mod8_quadratic(v: List[int]) -> bool:
    return (sum((x*x) for x in v) % 8) == 0

def surrogate_check(v8: List[int]) -> Tuple[bool, List[int]]:
    s1 = _is_even_sum(v8)
    s2 = _even_norm(v8)
    s3 = _mod8_quadratic(v8)
    legal = s1 and s2 and s3
    synd = [0,0,0,0]
    if not s1: synd[0] = 1
    if not s2: synd[1] = 1
    if not s3: synd[2] = 1
    return legal, synd

# --- Plugin loader ---
def _load_plugin() -> Callable[[List[int]], Tuple[bool, List[int]]]:
    spec = cfgget("legality_backend", "surrogate")
    if spec == "surrogate" or not spec:
        return surrogate_check
    try:
        mod_name, fn_name = spec.split(":")
        mod = importlib.import_module(mod_name)
        fn = getattr(mod, fn_name)
        return fn
    except Exception:
        return surrogate_check

_PLUGIN = None

def constructionA_E8_check(v8: List[int]) -> Tuple[bool, List[int]]:
    global _PLUGIN
    if _PLUGIN is None:
        _PLUGIN = _load_plugin()
    try:
        return _PLUGIN(v8)
    except Exception:
        return surrogate_check(v8)
