
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Iterable, Tuple
import numpy as np

class Geodesic(Protocol):
    def distance(self, a: np.ndarray, b: np.ndarray) -> float: ...

@dataclass(slots=True)
class ScorerConfig:
    alpha: float = 1.0  # cosine weight
    beta: float = 0.0   # geodesic weight

class PlaceholderGeodesic:
    def distance(self, a: np.ndarray, b: np.ndarray) -> float:
        # TODO: replace with true E8 geodesic (Coxeter/shortest path)
        # proxy: 1 - cosine similarity on normalized vectors
        na = a / (np.linalg.norm(a) + 1e-12)
        nb = b / (np.linalg.norm(b) + 1e-12)
        cos = float(np.dot(na, nb))
        return 1.0 - max(min(cos, 1.0), -1.0)

def blended_score(q: np.ndarray, docs: np.ndarray, cfg: ScorerConfig, g: Geodesic | None = None) -> np.ndarray:
    qn = q / (np.linalg.norm(q) + 1e-12)
    dn = docs / (np.linalg.norm(docs, axis=1, keepdims=True) + 1e-12)
    cos = dn @ qn
    if cfg.beta == 0.0:
        return cfg.alpha * cos
    if g is None:
        g = PlaceholderGeodesic()
    # gscore = 1/(1+d), where d is a distance; clip to [0,1]
    dists = np.array([g.distance(q, d) for d in docs], dtype=float)
    gscore = 1.0 / (1.0 + dists)
    return cfg.alpha * cos + cfg.beta * gscore

def rerank(q: np.ndarray, docs: np.ndarray, cfg: ScorerConfig, topk: int = 50, g: Geodesic | None = None) -> Tuple[np.ndarray, np.ndarray]:
    scores = blended_score(q, docs, cfg, g)
    idx = np.argsort(-scores)[:topk]
    return idx, scores[idx]
