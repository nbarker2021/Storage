
from __future__ import annotations
from typing import Dict, Any
import numpy as np
from lattice_ai.bridge.dual_stack import load_dual, maybe_emit_snap

def shell_metrics(center: np.ndarray, shell: np.ndarray) -> Dict[str, float]:
    # cosine coherence and redundancy
    c = center / (np.linalg.norm(center) + 1e-12)
    S = shell / (np.linalg.norm(shell, axis=1, keepdims=True) + 1e-12)
    coherence = float(np.mean(S @ c))
    # redundancy: average pairwise cosine
    if len(S) <= 1:
        redundancy = 0.0
    else:
        sims = S @ S.T
        n = sims.shape[0]
        redundancy = float((np.sum(sims) - n) / (n*(n-1)))
    return {"coherence": coherence, "redundancy": redundancy}

def compare_shells(center: np.ndarray, neighbors_v14: np.ndarray, neighbors_leg: np.ndarray | None, axes: Dict[str, Any] | None = None) -> Dict[str, Any]:
    m14 = shell_metrics(center, neighbors_v14)
    if neighbors_leg is None:
        rep = {"v14": m14, "legacy": None}
    else:
        mL = shell_metrics(center, neighbors_leg)
        rep = {"v14": m14, "legacy": mL, "delta": {"coherence": m14["coherence"]-mL["coherence"], "redundancy": m14["redundancy"]-mL["redundancy"]}}
    if axes is None:
        axes = {"version_container":"v14","tenant":"demo","domain":"shelling"}
    maybe_emit_snap(rep, axes)
    return rep
