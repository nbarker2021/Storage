# snapops API stub
