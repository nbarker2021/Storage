import json, pathlib, time
from kernel.telemetry import emit

POLICY_DIR = pathlib.Path("policy")

def policy_update(name: str, signer: str):
    POLICY_DIR.mkdir(parents=True, exist_ok=True)
    path = POLICY_DIR / f"{int(time.time()*1000)}_{name.replace(' ', '_')}.json"
    obj = {"name": name, "signer": signer, "ts": int(time.time()*1000)}
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    emit("policy.update", "governance", obj)
    return obj
