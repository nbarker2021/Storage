import json, pathlib, time
from triads.sap_snapops_archivist.archivist.revalidate import revalidate_all
from triads.sap_snapops_archivist.archivist.cas import get, put
from security.sign import verify_signature, sign_payload
from api.governance import current_policy
from kernel.telemetry import emit
from security.rbac import has_perm, ensure_defaults, DEFAULT_USER

CAS_DIR = pathlib.Path("outputs/cas")

def _iter_lockfiles():
    for p in CAS_DIR.glob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        if obj.get("kind") == "lockfile":
            yield p, obj

def revalidate_endpoint(endpoint_id: str):
    ensure_defaults()
    updated = []
    invalid = []
    for p, obj in _iter_lockfiles():
        if obj.get("payload", {}).get("endpoint_id") == endpoint_id:
            # full sweep (rewrites in place)
            r = revalidate_all()
            emit("lockfile.revalidate_single", "archivist", {"endpoint": endpoint_id, "result": r})
            return r
    return {"updated": [], "invalid": [], "note": "endpoint lockfile not found"}

def get_lockfile(hash_id: str):
    ensure_defaults()
    if not has_perm(DEFAULT_USER['user_id'], 'read', 'cas'):
        emit("rbac.deny", "archivist", {"action":"read","resource":"cas"})
        return None
    obj = get(hash_id)
    emit("lockfile.get", "archivist", {"hash": hash_id, "found": obj is not None})
    return obj

def read_lockfile_checked(ref: str):
    """ref: CAS hash or endpoint_id; verify signature & policy hash and auto-revalidate if needed."""
    ensure_defaults()
    pol = current_policy()
    # attempt by hash first
    obj = None
    ppath = None
    for p, candidate in _iter_lockfiles():
        if p.name.startswith(ref) or candidate.get("payload",{}).get("endpoint_id")==ref:
            obj = candidate; ppath = p; break
    if not obj:
        emit("lockfile.read.miss", "archivist", {"ref": ref})
        return None
    manifest = obj.get("payload", {})
    sig = manifest.get("signature","")
    if not verify_signature({k:v for k,v in manifest.items() if k!='signature'}, sig):
        emit("lockfile.invalid_signature", "archivist", {"ref": ref})
        return None
    if manifest.get("policy_hash") != pol.get("policy_hash"):
        manifest["policy_hash"] = pol.get("policy_hash")
        manifest["created_at"] = int(time.time()*1000)
        manifest["signature"] = sign_payload({k:v for k,v in manifest.items() if k != "signature"})
        obj["payload"] = manifest
        ppath.write_text(json.dumps(obj, sort_keys=True), encoding="utf-8")
        emit("lockfile.revalidated", "archivist", {"ref": ref, "policy_hash": pol.get("policy_hash")})
    emit("lockfile.read", "archivist", {"ref": ref})
    return obj
