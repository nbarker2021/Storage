#!/usr/bin/env python3
import os, pathlib, secrets
pem_path = pathlib.Path("security/signer_demo.pem")
mode = os.getenv("SNAPLAT_CRYPTO","").strip().lower()
try:
    from cryptography.hazmat.primitives.asymmetric import ed25519 as _ed
    from cryptography.hazmat.primitives import serialization as _ser
    HAVE = True
except Exception:
    HAVE = False

if HAVE and mode in ("ed25519","ed","crypto"):
    priv = _ed.Ed25519PrivateKey.generate()
    pem = priv.private_bytes(encoding=_ser.Encoding.PEM, format=_ser.PrivateFormat.PKCS8, encryption_algorithm=_ser.NoEncryption())
    pem_path.write_bytes(pem)
    print("[rotate] generated Ed25519 PEM")
else:
    secret = secrets.token_hex(64).encode("utf-8")
    pem_path.write_bytes(b"-----BEGIN PRIVATE KEY-----\n"+secret+b"\n-----END PRIVATE KEY-----\n")
    print("[rotate] rotated fallback secret")
