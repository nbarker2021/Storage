from kernel.db import get_conn, query

DEFAULT_USER = {"user_id":"system", "tenant_id":"demo"}

def has_perm(user_id:str, action:str, resource:str)->bool:
    conn = get_conn()
    rows = query(conn, "SELECT 1 FROM rbac_user_roles ur JOIN rbac_perms p USING(role_id) WHERE ur.user_id=? AND p.action=? AND p.resource=? LIMIT 1",
                 (user_id, action, resource))
    return bool(rows)

def ensure_defaults():
    conn = get_conn()
    conn.execute("INSERT OR IGNORE INTO rbac_users(user_id, tenant_id) VALUES(?,?)", (DEFAULT_USER["user_id"], DEFAULT_USER["tenant_id"]))
    conn.execute("INSERT OR IGNORE INTO rbac_roles(role_id, description) VALUES(?,?)", ("publisher","can publish artifacts"))
    conn.execute("INSERT OR IGNORE INTO rbac_roles(role_id, description) VALUES(?,?)", ("reader","can read trails/rmi/cas"))
    conn.execute("INSERT OR IGNORE INTO rbac_user_roles(user_id, role_id) VALUES(?,?)", (DEFAULT_USER["user_id"], "publisher"))
    conn.execute("INSERT OR IGNORE INTO rbac_user_roles(user_id, role_id) VALUES(?,?)", (DEFAULT_USER["user_id"], "reader"))
    conn.execute("INSERT OR IGNORE INTO rbac_perms(role_id, action, resource) VALUES(?,?,?)", ("publisher","publish","lockfile"))
    conn.execute("INSERT OR IGNORE INTO rbac_perms(role_id, action, resource) VALUES(?,?,?)", ("reader","read","trails"))
    conn.execute("INSERT OR IGNORE INTO rbac_perms(role_id, action, resource) VALUES(?,?,?)", ("reader","read","rmi"))
    conn.execute("INSERT OR IGNORE INTO rbac_perms(role_id, action, resource) VALUES(?,?,?)", ("reader","read","cas"))
    conn.commit()
