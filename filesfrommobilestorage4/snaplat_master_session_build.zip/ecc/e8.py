from dataclasses import dataclass
import math, random
_DIM = 8

@dataclass
class Code:
    cell: tuple[int, ...]

def _proj8(vec: list[float]) -> list[float]:
    if len(vec) <= _DIM:
        return vec + [0.0]*(_DIM-len(vec))
    return vec[:_DIM]

def encode(vec: list[float], seed: int|None=None) -> Code:
    rnd = random.Random(seed)
    v = _proj8(vec)
    cell = tuple(int(math.floor(x*1000)) for x in v)
    cell = tuple(c + rnd.randint(-1,1) for c in cell)
    return Code(cell=cell)

def decode(code: Code) -> list[float]:
    return [c/1000.0 for c in code.cell]

def cell_id(code: Code) -> str:
    return ":".join(map(str, code.cell))
