import argparse, pathlib, re, json
from collections import defaultdict
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from ecc import e8

def read_docs(root: pathlib.Path):
    docs = []
    for p in root.rglob("*.md"):
        text = p.read_text(encoding="utf-8", errors="ignore")
        docs.append({"id": p.as_posix(), "text": text})
    for p in root.rglob("*.txt"):
        text = p.read_text(encoding="utf-8", errors="ignore")
        docs.append({"id": p.as_posix(), "text": text})
    return docs

def _tf(text):
    toks = re.findall(r"[a-z0-9]+", text.lower())
    d = defaultdict(int)
    for t in toks: d[t]+=1
    return d

def baseline_rank(docs, query, k):
    qf = _tf(query)
    scores=[]
    for d in docs:
        tf = _tf(d["text"])
        s = sum(min(tf.get(t,0), qf[t]) for t in qf)
        if s>0: scores.append((s, d["id"]))
    scores.sort(reverse=True)
    return [doc_id for _,doc_id in scores[:k]]

def _toy_vec(text):
    toks = re.findall(r"[a-z0-9]+", text.lower())[:32]
    return [float(len(t)) for t in toks]

def e8_rank(docs, query, k, seed=0):
    qvec = _toy_vec(query)
    qcode = e8.encode(qvec, seed=seed)
    qid = e8.cell_id(qcode)
    buckets = defaultdict(list)
    for d in docs:
        code = e8.encode(_toy_vec(d["text"]), seed=seed)
        buckets[e8.cell_id(code)].append(d["id"])
    cand = list(buckets.get(qid, []))
    if len(cand) < k:
        parts = list(map(int, qid.split(":")))
        for i in range(len(parts)):
            for delta in (-1,1):
                n = parts.copy(); n[i]+=delta
                cand.extend(buckets.get(":".join(map(str,n)), []))
                if len(cand)>=k: break
            if len(cand)>=k: break
    return cand[:k]

def load_bench(path: pathlib.Path):
    bench = []
    if path.suffix == ".json":
        bench = json.loads(path.read_text(encoding="utf-8"))
    else:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.strip().startswith("#"):
                continue
            q, ids = line.split(":",1)
            bench.append({"query": q.strip(), "relevant": [i.strip() for i in ids.split(",") if i.strip()]})
    return bench

def score(run, relevant):
    k = len(run)
    relset = set(relevant)
    hit = [1 if d in relset else 0 for d in run]
    p_at_k = sum(hit)/max(1,k)
    r_at_k = sum(hit)/max(1,len(relset)) if relset else 0.0
    return {"P@k": round(p_at_k,3), "R@k": round(r_at_k,3)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", required=True)
    ap.add_argument("--queries", required=True)
    ap.add_argument("--method", choices=["baseline","e8"], required=True)
    ap.add_argument("--k", type=int, default=5)
    args = ap.parse_args()

    docs = read_docs(pathlib.Path(args.docs))
    bench = load_bench(pathlib.Path(args.queries))

    method = baseline_rank if args.method=="baseline" else e8_rank
    out = []
    for case in bench:
        run = method(docs, case["query"], args.k)
        out.append({"query": case["query"], "run": run, "score": score(run, case.get("relevant", []))})
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
