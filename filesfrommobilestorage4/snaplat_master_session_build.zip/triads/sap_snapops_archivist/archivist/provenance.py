import json, pathlib, time
from .cas import put
from utils.fs import atomic_write

def write_provenance(endpoint_id: str, bundle: dict) -> str:
    rec = {
        "kind": "provenance",
        "endpoint_id": endpoint_id,
        "created_at": int(time.time()*1000),
        "payload": bundle,
    }
    h = put(rec)
    # index pointer for quick lookup
    idx = pathlib.Path('outputs/index/provenance') / f"{endpoint_id}-{rec['created_at']}.json"
    idx.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(idx, json.dumps({"cas_hash": h, "endpoint_id": endpoint_id, "created_at": rec['created_at']}, sort_keys=True).encode('utf-8'))
    return h
