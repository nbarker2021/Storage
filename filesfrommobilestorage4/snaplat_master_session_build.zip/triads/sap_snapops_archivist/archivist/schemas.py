SCHEMAS = {
  "agent":       {"required": ["kind","agent_id","roles"]},
  "failure":     {"required": ["kind","at","component","reason"]},
  "conversation":{"required": ["kind","thread_id","messages"]},
  "dataset":     {"required": ["kind","dataset_id","format"]},
  "overlay":     {"required": ["kind","overlay_id"]},
  "route":       {"required": ["kind","route_id","universe_id"]},
  "endpoint":    {"required": ["kind","endpoint_id","universe_id"]},
  "test":        {"required": ["kind","name","result"]},
  "policy":      {"required": ["kind","policy_id","version"]},
  "persona":     {"required": ["kind","name","domains"]},
}

def validate(obj: dict) -> tuple[bool, list]:
  kind = obj.get("kind")
  if not kind: return False, ["schema.kind.missing"]
  base = SCHEMAS.get(kind)
  if not base: return True, []  # unknown kinds pass for now
  missing = [k for k in base["required"] if k not in obj]
  return (len(missing)==0, [f"schema.missing.{m}" for m in missing])
