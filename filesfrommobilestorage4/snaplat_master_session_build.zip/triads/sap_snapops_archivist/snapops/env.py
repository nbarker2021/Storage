from dataclasses import dataclass

@dataclass
class Env:
    seed: int
    tick: int
    caps: dict

def build(t: int, seed: int):
    return Env(seed=seed, tick=t, caps={})
