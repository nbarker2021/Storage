from kernel.db import get_conn, query, exec_sql

def autotune_i8():
    conn = get_conn()
    # heuristic: if v_i8_consensus shows many endpoints touched, keep K=8; else reduce to 4
    rows = query(conn, "SELECT successes,total,avg_agreement FROM octant_stats", ())
    succ = sum(r['successes'] for r in rows) if rows else 0
    tot  = sum(r['total'] for r in rows) if rows else 0
    avgA = (sum(r['avg_agreement'] for r in rows)/len(rows)) if rows else 0.0
    # CI proxy: lower bound ~ succ/tot minus variance
    lcb = (succ/max(tot,1)) - (0.5/math.sqrt(max(tot,1)))
    if lcb < 0: lcb = 0.0
    # Decide K/TTL
    if lcb >= 0.6 and avgA >= 0.5:
        K, TTL = 8, 24
    elif lcb >= 0.3:
        K, TTL = 8, 16
    else:
        K, TTL = 6, 8
    exec_sql(conn, "UPDATE i8_rotation_params SET k_default=?, freshness_ttl=?, updated_at=strftime('%s','now')*1000", (K, TTL))
    return {"K": K, "TTL": TTL, "lcb": lcb, "avgA": avgA}
