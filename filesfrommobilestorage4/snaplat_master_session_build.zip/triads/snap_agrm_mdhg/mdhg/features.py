from kernel.db import get_conn, query
import math

def _safe(v, lo=0.0, hi=1.0):
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return 0.0

def compute_features_for_routes(routes: list[dict], octant:int) -> dict:
    """Return mapping route_id -> feature vector [score, nodes_norm, octant_bias]."""
    # Pull octant stats for bias
    conn = get_conn()
    rows = query(conn, "SELECT successes,total,avg_agreement FROM octant_stats WHERE octant=?", (octant,))
    succ_rate = (rows[0]["successes"]/max(rows[0]["total"],1)) if rows else 0.0
    avg_agree = rows[0]["avg_agreement"] if rows else 0.0
    octant_bias = _safe(0.5*succ_rate + 0.5*avg_agree)  # simple blend
    feats = {}
    for r in routes:
        nodes_norm = _safe(r.get("nodes_visited", 0)/200.0)  # cap ~0.1 from prior logic; normalize 0..1
        feats[r["route_id"]] = [ _safe(r.get("score",0.0)), nodes_norm, _safe(octant_bias) ]
    return feats

def l2_delta(vec_a, vec_b):
    if len(vec_a) != len(vec_b):  # pad shorter
        n = max(len(vec_a), len(vec_b))
        vec_a = (vec_a + [0.0]*n)[:n]
        vec_b = (vec_b + [0.0]*n)[:n]
    return math.sqrt(sum((a-b)**2 for a,b in zip(vec_a, vec_b)))
