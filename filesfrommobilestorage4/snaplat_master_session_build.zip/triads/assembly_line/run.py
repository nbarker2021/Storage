
from .stages import stage_intake, stage_evaluate, stage_recombine, stage_finalize
def run(job: dict) -> dict:
    ctx = stage_intake(job)
    if 'wave' in job: ctx['wave'] = job['wave']
    ev = stage_evaluate(ctx); ctx.update(ev)
    rc = stage_recombine(ctx); ctx.update(rc)
    fn = stage_finalize(ctx); ctx.update(fn)
    return ctx
