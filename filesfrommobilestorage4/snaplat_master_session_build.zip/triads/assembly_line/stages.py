
from kernel.telemetry import emit
from triads.sap_snapops_archivist.snapdna_v2 import encode_v2
from triads.sap_snapops_archivist.archivist.cas import put

def stage_intake(job: dict) -> dict:
    emit('assembly.stage','asm',{'stage':'intake','kind': job.get('kind')})
    payload = job.get('payload',{})
    dna = None
    if isinstance(payload, dict) and payload.get('kind'):
        dna = encode_v2(payload)
    return {'ok': True, 'dna': dna, 'payload': payload, 'wave': job.get('wave',{})}

def stage_evaluate(ctx: dict) -> dict:
    emit('assembly.stage','asm',{'stage':'evaluate'})
    payload = ctx.get('payload',{})
    score = 0.0
    if ctx.get('dna'): score += 0.3
    score += min(0.3, len((payload or {}).keys())/20.0)
    comp = ctx.get('wave',{}).get('signals',{})
    score += float(comp.get('score',0.0))*0.4
    return {'ok': True, 'score': max(0.0, min(1.0, score))}

def stage_recombine(ctx: dict) -> dict:
    emit('assembly.stage','asm',{'stage':'recombine'})
    dna = ctx.get('dna') or {}
    note = f"stitched({ctx.get('wave',{}).get('wave_type','refine')})"
    rec = {'kind':'recombination','dna': dna.get('dna',''), 'note': note}
    cas = put(rec)
    return {'ok': True, 'recomb_cas': cas}

def stage_finalize(ctx: dict) -> dict:
    emit('assembly.stage','asm',{'stage':'finalize'})
    return {'ok': True}
