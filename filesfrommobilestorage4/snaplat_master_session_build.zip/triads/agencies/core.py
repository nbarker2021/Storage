
from dataclasses import dataclass
from typing import Optional, Dict

@dataclass
class Job:
    kind: str
    payload: dict
    created_at: int

class Agency:
    name: str = "agency"
    def run(self, job: Job) -> dict:
        raise NotImplementedError

_REGISTRY: Dict[str, Agency] = {}
def register(agency: Agency):
    _REGISTRY[agency.name] = agency
def get(name: str) -> Optional[Agency]:
    return _REGISTRY.get(name)
def all_names():
    return sorted(list(_REGISTRY.keys()))
