#!/usr/bin/env python3
import json, pathlib, sys

def main():
    path = pathlib.Path("outputs/trails/trails.jsonl")
    out = pathlib.Path("outputs/trails/index.html")
    q = sys.argv[1].lower() if len(sys.argv) > 1 else None
    rows = []
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                obj = json.loads(line)
                if q and q not in json.dumps(obj).lower():
                    continue
                rows.append(obj)
            except Exception:
                pass
    html = [
        "<html><head><meta charset='utf-8'><title>Trails</title>",
        "<style>body{font-family:ui-sans-serif;margin:24px} pre{background:#f6f6f6;padding:8px;border-radius:8px}</style>",
        "</head><body>",
        f"<h1>Trails ({len(rows)})</h1>",
        "<p>Filter: <code>python tools/trailview.py \"search-term\"</code></p>",
    ]
    for r in rows[-1000:]:
        html.append(f"<h3>{r.get('created_at')} — {r.get('kind')} — {r.get('thing')}</h3>")
        html.append("<pre>" + json.dumps(r, indent=2) + "</pre>")
    html.append("</body></html>")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(html), encoding="utf-8")
    print("wrote", out)

if __name__ == "__main__":
    main()
