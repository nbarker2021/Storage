#!/usr/bin/env python3
import time, json, pathlib, subprocess, statistics

OUT = pathlib.Path("outputs/bench"); OUT.mkdir(parents=True, exist_ok=True)

def run_many(n=50):
    t0 = time.perf_counter()
    passes = 0; fails = 0
    for i in range(n):
        ep = f"epS{i%50}"
        try:
            out = subprocess.check_output(['python','-c', f'from triads.thinktank_dtt_assembly.assembly.pipeline import run_pipeline; import json; print(json.dumps(run_pipeline(subject="bench", endpoint_id="{ep}", domain="governance")))'], timeout=20)
            res = json.loads(out.decode())
            if res.get('ready'): passes += 1
            else: fails += 1
        except Exception:
            fails += 1
    dt = time.perf_counter() - t0
    return {'n': n, 'passes': passes, 'fails': fails, 'seconds': dt, 'eps': n/max(0.001,dt)}

def main():
    report = run_many(100)
    OUT.joinpath('report.json').write_text(json.dumps(report, indent=2, sort_keys=True), encoding='utf-8')
    OUT.joinpath('report.txt').write_text(f"runs={report['n']} passes={report['passes']} fails={report['fails']} seconds={report['seconds']:.3f} eps={report['eps']:.2f}\n", encoding='utf-8')
    html = f"""<html><body><h3>Scale Benchmark</h3>
    <p>Runs: {report['n']}, Passes: {report['passes']}, Fails: {report['fails']}, Seconds: {report['seconds']:.3f}, EPS: {report['eps']:.2f}</p>
    </body></html>"""
    OUT.joinpath('report.html').write_text(html, encoding='utf-8')
    print(json.dumps(report))

if __name__ == "__main__":
    main()
