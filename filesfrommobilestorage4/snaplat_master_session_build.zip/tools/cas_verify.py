#!/usr/bin/env python3
import json, hashlib, pathlib, sys
from kernel.telemetry import emit

ROOT = pathlib.Path("outputs/cas")
JOURNAL = pathlib.Path("outputs/cas_journal/ops.log")

def _recompute_hash(obj: dict) -> str:
    blob = json.dumps(obj, sort_keys=True, separators=(",",":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()

def scan():
    mismatches, orphans = [], []
    seen = set()
    if JOURNAL.exists():
        for line in JOURNAL.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
                seen.add(rec.get("hash",""))
            except Exception:
                continue
    if not ROOT.exists():
        print("no CAS dir"); return True
    for d in ROOT.iterdir():
        if not d.is_dir(): continue
        for f in d.iterdir():
            try:
                obj = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                mismatches.append((str(f), "json_error"))
                continue
            h = _recompute_hash(obj)
            path_hash = d.name + f.name
            if h != path_hash:
                mismatches.append((str(f), "hash_mismatch"))
            if h not in seen:
                orphans.append(str(f))
    ok = (not mismatches) and (not orphans)
    emit("cas.verify", "ops", {"ok": ok, "mismatches": len(mismatches), "orphans": len(orphans)})
    print("OK" if ok else "ISSUES", len(mismatches), "mismatch,", len(orphans), "orphan")
    if mismatches:
        print("mismatches:"); [print(" -", m[0], m[1]) for m in mismatches]
    if orphans:
        print("orphans:"); [print(" -", p) for p in orphans]
    return ok

if __name__ == "__main__":
    raise SystemExit(0 if scan() else 2)
