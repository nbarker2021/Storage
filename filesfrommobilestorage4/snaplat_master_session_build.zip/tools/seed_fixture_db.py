#!/usr/bin/env python3
import sqlite3, pathlib, json, time, random

DB = pathlib.Path("rmi/snaplat.db")
DB.parent.mkdir(parents=True, exist_ok=True)

def main():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    # Basic tables
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS trails(created_at INTEGER, kind TEXT, actor TEXT, payload TEXT);
    CREATE TABLE IF NOT EXISTS endpoints(endpoint_id TEXT PRIMARY KEY, universe_id TEXT);
    CREATE TABLE IF NOT EXISTS routes(route_id TEXT PRIMARY KEY, universe_id TEXT);
    CREATE TABLE IF NOT EXISTS lineage_edges(src_id TEXT, dst_id TEXT, weight REAL);
    CREATE TABLE IF NOT EXISTS i8_topk(octant INTEGER, choice_id TEXT, choice_kind TEXT, score REAL, created_at INTEGER);
    CREATE TABLE IF NOT EXISTS overlays(overlay_id TEXT PRIMARY KEY);
    CREATE TABLE IF NOT EXISTS overlay_members(overlay_id TEXT, member_id TEXT);
    CREATE TABLE IF NOT EXISTS overlay_meta(overlay_id TEXT, tau REAL);
    """)
    # View for current topk: pick latest per octant
    cur.executescript("""
    DROP VIEW IF EXISTS v_i8_topk_current;
    CREATE VIEW v_i8_topk_current AS
    SELECT t.octant, t.choice_id, t.choice_kind, t.score, MAX(t.created_at) AS created_at
    FROM i8_topk t GROUP BY t.octant;
    """)

    # Seed endpoint and routes
    cur.execute("INSERT OR REPLACE INTO endpoints(endpoint_id, universe_id) VALUES(?, ?)", ("ep-demo", "u1"))
    for i in range(1, 6):
        cur.execute("INSERT OR REPLACE INTO routes(route_id, universe_id) VALUES(?, ?)", (f"r{i}", "u1"))
        # lineage edges to endpoint
        cur.execute("INSERT INTO lineage_edges(src_id, dst_id, weight) VALUES(?,?,?)", (f"r{i}", "ep-demo", 1.0))
    # Seed topk history across octants for coverage
    now = int(time.time()*1000)
    for o in range(1,9):
        cur.execute("INSERT INTO i8_topk(octant, choice_id, choice_kind, score, created_at) VALUES(?,?,?,?,?)", (o, "ep-demo", "endpoint", 0.5+0.05*o, now-1000+o))
    # Seed overlays
    cur.execute("INSERT OR REPLACE INTO overlays(overlay_id) VALUES(?)", ("ov1",))
    for i in range(1,4):
        cur.execute("INSERT INTO overlay_members(overlay_id, member_id) VALUES(?,?)", ("ov1", f"r{i}"))
    cur.execute("INSERT OR REPLACE INTO overlay_meta(overlay_id, tau) VALUES(?,?)", ("ov1", 0.42))

    # Trails: a governance slice with consent
    payload = json.dumps({"consent": true, "email": "a@b", "debits": [10], "credits": [10]})
    cur.execute("INSERT INTO trails(created_at, kind, actor, payload) VALUES(?,?,?,?)", (now, "ingest.record", "seed", payload))

    con.commit(); con.close()
    print(DB)

if __name__ == "__main__":
    main()
