#!/usr/bin/env python3
import json, pathlib, argparse
from triads.agencies.queue import enqueue

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", default="outputs/scaffold/index.json")
    ap.add_argument("--endpoint", default="ep-demo")
    ap.add_argument("--domain", default="governance")
    args = ap.parse_args()

    idx = json.loads(pathlib.Path(args.index).read_text(encoding="utf-8"))
    for s in idx:
        payload = {"kind":"scaffold_task","endpoint_id": args.endpoint, "domain": args.domain, "path": s["path"], "bucket": s["bucket"], "title": s["title"]}
        enqueue("scaffold_task", payload)
    print(json.dumps({"enqueued": len(idx)}))

if __name__ == "__main__":
    main()
