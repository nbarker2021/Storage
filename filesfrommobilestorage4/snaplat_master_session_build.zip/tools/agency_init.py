
#!/usr/bin/env python3
from triads.agencies.agencies import init
if __name__ == "__main__":
    init()
    print("ok")
