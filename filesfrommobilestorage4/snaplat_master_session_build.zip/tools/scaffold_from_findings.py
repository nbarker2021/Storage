
#!/usr/bin/env python3
import json, pathlib, re, unicodedata, argparse
BASE = pathlib.Path(".")
OUTIDX = pathlib.Path("outputs/scaffold/index.json")

def slug(s: str, maxlen=50):
    s = "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
    s = re.sub(r"[^A-Za-z0-9]+","-", s).strip("-").lower()
    if len(s) > maxlen: s = s[:maxlen].rstrip("-")
    if not s: s = "item"
    return s

def load_json(path: str):
    p = pathlib.Path(path)
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []

def scaffold_one(bucket, title, source_file, line, counter):
    bdir = {
        "Agency/Orchestration": "scaffolds/agency",
        "SNAP/DNA": "scaffolds/snap_dna",
        "Storage/Archivist": "scaffolds/archivist",
        "Governance/Policy": "scaffolds/governance",
        "MDHG/Stability": "scaffolds/mdhg",
        "E8/Lattice": "scaffolds/e8",
        "Schema/Contracts": "scaffolds/contracts",
        "Testing/Perf": "scaffolds/testing",
        "Testing/Perf/DX": "scaffolds/testing",
        "DX/Reporting": "scaffolds/dx",
        "Core/Runtime": "scaffolds/core",
    }.get(bucket, "scaffolds/core")
    name = f"{slug(title)}-{counter:04d}"
    if bucket == "Schema/Contracts":
        ext = "json5"
    else:
        ext = "py"
    fpath = BASE / bdir / f"{name}.{ext}"
    fpath.parent.mkdir(parents=True, exist_ok=True)
    if ext == "py":
        code = f'"""\nAUTO-GENERATED STUB\nBucket: {bucket}\nTitle : {title}\nSource: {source_file}:{line}\n"""\n\n\n' + \               'def plan():\n    return {"bucket": ' + repr(bucket) + ', "title": ' + repr(title) + ', "source": ' + repr(source_file) + ', "line": ' + str(line) + '}\n\n' + \               'def execute(payload=None):\n    return {"ok": True, "note": "stub executed", "payload": payload or {}}\n'
    else:
        code = '{\n  kind: "contract.stub",\n  title: ' + json.dumps(title) + ',\n  version: 0,\n  fields: []\n}\n'
    fpath.write_text(code, encoding="utf-8")
    # minimal test
    tpath = BASE / "tests" / "scaffolds" / f"test_{name}.py"
    tpath.parent.mkdir(parents=True, exist_ok=True)
    modpath = bdir.replace("/",".") + "." + name
    tcode = f'import importlib\nmod = importlib.import_module("{modpath}")\n' + \            'def test_stub_exec():\n    assert hasattr(mod, "execute")\n    assert mod.execute({})["ok"]\n'
    tpath.write_text(tcode, encoding="utf-8")
    return str(fpath)

def main():
    import re, unicodedata
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--canvas_microjobs", default="/mnt/data/canvas_scan_left_behind/microjobs.json")
    ap.add_argument("--log_gaps", default="/mnt/data/full_build_log_pass/gaps.json")
    args = ap.parse_args()

    def infer_bucket(t: str) -> str:
        t = t.lower()
        if any(x in t for x in ["policy","lawpack","governance"]): return "Governance/Policy"
        if any(x in t for x in ["schema","shape","json","contract"]): return "Schema/Contracts"
        if any(x in t for x in ["test","fixture","benchmark","ci"]): return "Testing/Perf"
        if any(x in t for x in ["queue","agency","wave","morsr","thinktank","assembly"]): return "Agency/Orchestration"
        if any(x in t for x in ["archivist","cas","storage","gc","retention"]): return "Storage/Archivist"
        if any(x in t for x in ["e8","lattice","rotation"]): return "E8/Lattice"
        if any(x in t for x in ["mdhg","stability","drift","band","cusum"]): return "MDHG/Stability"
        if any(x in t for x in ["snap","dna"]): return "SNAP/DNA"
        if any(x in t for x in ["ui","console","report","html"]): return "DX/Reporting"
        return "Core/Runtime"

    def load(path):
        p = pathlib.Path(path)
        if not p.exists(): return []
        try: return json.loads(p.read_text(encoding="utf-8"))
        except Exception: return []

    mjs = load(args.canvas_microjobs)
    gaps = load(args.log_gaps)
    synth = [{"bucket": infer_bucket(g.get("text","")), "title": g.get("text","")[:120], "source_file": "full_build_log", "line": g.get("line",0)} for g in gaps]

    seen=set(); merged=[]
    for row in (mjs + synth):
        key = (row.get("bucket","Core/Runtime"), row.get("title",""), row.get("source_file",""), int(row.get("line",0)))
        if key in seen: continue
        seen.add(key)
        merged.append({"bucket": key[0], "title": key[1] or "untitled", "source_file": key[2], "line": key[3]})

    stubs=[]
    for i,row in enumerate(merged, start=1):
        path = scaffold_one(row["bucket"], row["title"], row["source_file"], row["line"], i)
        stubs.append({"bucket": row["bucket"], "title": row["title"], "source_file": row["source_file"], "line": row["line"], "path": path})

    OUTIDX.parent.mkdir(parents=True, exist_ok=True)
    OUTIDX.write_text(json.dumps(stubs, indent=2), encoding="utf-8")
    print(json.dumps({"scaffolded": len(stubs), "index": str(OUTIDX)}, indent=2))

if __name__ == "__main__":
    main()
