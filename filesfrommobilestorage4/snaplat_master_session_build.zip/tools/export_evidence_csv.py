#!/usr/bin/env python3
import sqlite3, csv, pathlib, json
DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/exports/evidence.csv")

def fetch():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    rows = cur.execute("SELECT created_at, actor, payload FROM trails WHERE kind='assembly.evaluate' ORDER BY created_at").fetchall()
    out = []
    for r in rows:
        try:
            p = json.loads(r['payload']) if isinstance(r['payload'], str) else r['payload']
        except Exception:
            p = {}
        ep = p.get('endpoint_id', '')
        ev = p.get('evidence') or {}
        out.append({
            "created_at": r["created_at"],
            "endpoint_id": ep,
            "nodes": int(ev.get("nodes",0)),
            "edges": int(ev.get("edges",0)),
            "ready": int(bool(p.get("ready", False))),
            "domain": p.get("domain","")
        })
    return out

def export(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["created_at","endpoint_id","nodes","edges","ready","domain"])
        w.writeheader()
        for r in rows: w.writerow(r)
    print(str(OUT))

if __name__ == "__main__":
    export(fetch())
