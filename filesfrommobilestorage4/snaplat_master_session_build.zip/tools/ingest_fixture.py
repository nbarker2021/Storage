#!/usr/bin/env python3
import json, sys, time, sqlite3

DB = "rmi/snaplat.db"

def main(path):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS trails(created_at INTEGER, kind TEXT, actor TEXT, payload TEXT)")
    payload = json.loads(open(path, 'r', encoding='utf-8').read())
    cur.execute("INSERT INTO trails(created_at, kind, actor, payload) VALUES(?,?,?,?)", (int(time.time()*1000), "ingest.record", "fixture", json.dumps(payload)))
    con.commit(); con.close()
    print("ok")

if __name__ == "__main__":
    if len(sys.argv)<2: print("usage: tools/ingest_fixture.py <json>"); raise SystemExit(2)
    main(sys.argv[1])
