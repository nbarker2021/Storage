# Tick Runner
The tickrunner coordinates logical ticks and emits trails per tick.
