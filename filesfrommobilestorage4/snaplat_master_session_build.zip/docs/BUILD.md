# Build & Install (session)
- This session build avoids external deps; run modules directly with Python.
- Entry points:
  - `kernel/tick.py` for logical ticks
  - `kernel/telemetry.py` for trails
  - `triads/sap_snapops_archivist/archivist/cas.py` for CAS
  - `eval/harness.py` for retrieval eval

## Quickstart
```bash
python tools/trailview.py               # builds the HTML view (after trails exist)
python eval/harness.py --docs docs --queries eval/bench.yaml --method baseline --k 3
python eval/harness.py --docs docs --queries eval/bench.yaml --method e8 --k 3
```
