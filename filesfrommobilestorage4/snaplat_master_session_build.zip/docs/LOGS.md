# Logs & Telemetry
- File: `outputs/trails/trails.jsonl` (newline-delimited JSON)
- Rotate after ~200k lines (naive).
- View with: `python tools/trailview.py` then open `outputs/trails/index.html`.
