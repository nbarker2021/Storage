import pathlib, yaml
from triads.thinktank_dtt_assembly.assembly.publish import finalize_gate
from triads.snap_agrm_mdhg.mdhg.alerts import evaluate

def test_finalize_blocks_on_drift(monkeypatch, tmp_path):
    # Force mdhg to report drift
    monkeypatch.setattr('triads.snap_agrm_mdhg.mdhg.alerts.evaluate', lambda eid: {'summary': {'band':'high'}, 'issues': ['mdhg.drift.detected']})
    p = pathlib.Path("policy/finalize.yaml"); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("min_evidence_nodes: 1\nmin_evidence_edges: 1\nrequire_stability: true\nmin_stability: 0.1\n", encoding="utf-8")
    ok, rs = finalize_gate({'endpoint_id':'epZ','evidence_nodes': 5, 'evidence_edges': 5})
    assert not ok and any('mdhg' in r for r in rs)
