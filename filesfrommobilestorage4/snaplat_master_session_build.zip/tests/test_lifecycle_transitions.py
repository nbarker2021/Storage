from triads.sap_snapops_archivist.archivist.lifecycle import get_state, set_state, ALLOWED

def test_allowed_transitions():
    # start from draft (default)
    s = get_state('epX')
    assert s == 'draft'
    assert set_state('epX','finalized') is True
    assert get_state('epX') == 'finalized'
    # disallowed: finalized -> draft
    assert set_state('epX','draft') is False
    # allowed: finalized -> superseded -> retired
    assert set_state('epX','superseded') is True
    assert set_state('epX','retired') is True
