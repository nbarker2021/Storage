from kernel.db import get_conn, query
from kernel.authz import guard_rmi_read
from security.tenant import universe_for_user

def topk_current(octant:int|None=None, user_id:str='system'):
    if not guard_rmi_read(context={'fn':'rmi.topk_current','octant':octant}):
        return []
    conn = get_conn()
    if octant is None:
        rows = query(conn, "SELECT octant, choice_id, choice_kind, score, created_at FROM v_i8_topk_current ORDER BY octant", ())
    else:
        rows = query(conn, "SELECT octant, choice_id, choice_kind, score, created_at FROM v_i8_topk_current WHERE octant=? ORDER BY created_at DESC", (octant,))
    # tenant scope via join would be ideal; v_i8_topk_current may be materialized from routes/endpoints; fall back to filter using exists checks
    uni = universe_for_user(user_id)
    out = []
    for r in rows:
        if r["choice_kind"] == "route":
            ok = query(conn, "SELECT 1 FROM routes WHERE route_id=? AND universe_id=?", (r["choice_id"], uni))
        else:
            ok = query(conn, "SELECT 1 FROM endpoints WHERE endpoint_id=? AND universe_id=?", (r["choice_id"], uni))
        if ok:
            out.append(dict(r))
    return out

def overlays_with_tau(user_id:str='system'):
    if not guard_rmi_read(context={'fn':'rmi.overlays_with_tau'}):
        return []
    conn = get_conn()
    rows = query(conn, "SELECT o.overlay_id, COALESCE(meta.tau,0) AS tau FROM overlays o LEFT JOIN overlay_meta meta USING(overlay_id)", ())
    return [dict(r) for r in rows]

def lineage_edges(user_id:str='system'):
    if not guard_rmi_read(context={'fn':'rmi.lineage_edges'}):
        return []
    conn = get_conn()
    rows = query(conn, "SELECT src_id, dst_id, weight FROM lineage_edges", ())
    return [dict(r) for r in rows]

def recent_trails(limit:int=200, user_id:str='system'):
    if not guard_rmi_read(context={'fn':'rmi.recent_trails','limit':limit}):
        return []
    from kernel.db_helpers import fetch_recent_trails
    return fetch_recent_trails(limit=limit)


def overlays_with_counts(user_id:str='system'):
    if not guard_rmi_read(context={'fn':'rmi.overlays_with_counts'}):
        return []
    conn = get_conn()
    rows = query(conn, """
        SELECT o.overlay_id, COALESCE(meta.tau,0) AS tau, COUNT(m.member_id) AS members
        FROM overlays o
        LEFT JOIN overlay_meta meta USING(overlay_id)
        LEFT JOIN overlay_members m USING(overlay_id)
        GROUP BY o.overlay_id
        ORDER BY tau DESC, members DESC
    """, ())
    return [dict(r) for r in rows]
