import pathlib, yaml

P_DIR = pathlib.Path("policy/personas")

def load_personas():
    out = []
    if not P_DIR.exists(): return out
    for p in P_DIR.glob("*.yaml"):
        try:
            y = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            if y.get("enabled", True):
                out.append(y)
        except Exception:
            continue
    # sort by weight desc
    out.sort(key=lambda x: float(x.get("weight", 0.5)), reverse=True)
    return out

def select_for(domain:str|None=None, k:int=2):
    personas = load_personas()
    if not personas: return []
    if domain:
        scoped = [p for p in personas if domain in (p.get("domains") or [])]
        if scoped:
            personas = scoped + [p for p in personas if p not in scoped]
    return personas[:k]
