import pathlib, json

STATE = pathlib.Path("outputs/state")
STATE.mkdir(parents=True, exist_ok=True)
CLOCK = STATE / "tick.json"

def _read() -> dict:
    if CLOCK.exists():
        try:
            return json.loads(CLOCK.read_text(encoding="utf-8"))
        except Exception:
            return {"last": -1}
    return {"last": -1}

def begin_tick() -> int:
    obj = _read()
    t = int(obj.get("last", -1)) + 1
    CLOCK.write_text(json.dumps({"last": t}), encoding="utf-8")
    return t
