# Reality Craft (Minimal Baseline)

Stdlib-first baseline assembled from your spec. Optional deps: `requests`, `cryptography`.

## Layout
- `reality_craft_portal.html` – desktop portal UI (served at `/`)
- `reality_craft_server.py` – local server on port 8765
- `speedlight_sidecar_plus.py` – stdlib cache+ledger sidecar (SpeedLightV2)
- `ca_tile_generator.py` – generates 24 Niemeier tiles into `./.reality_craft/ca_tiles`
- `lattice_viewer.py` – viewer on port 8989 (reads tiles)
- `backup_pi_server.py` – backup listener for the Pi
- `secure_storage.py` – encrypted storage (Fernet if available; XOR demo fallback)

## Quickstart
```bash
# 1) (optional) create venv and install optional deps
python -m venv .venv && source .venv/bin/activate
pip install requests cryptography

# 2) run server (8765)
python src/reality_craft_server.py

# 3) generate tiles (writes .reality_craft/ca_tiles/*.json)
python src/ca_tile_generator.py

# 4) run lattice viewer (8989)
python src/lattice_viewer.py

# 5) (Pi) run backup server (8766)
python src/backup_pi_server.py
```

## Notes
- If `cryptography` is not installed, `secure_storage` uses an **INSECURE XOR demo** (placeholder only).
- `reality_craft_server` uses `requests` if present; otherwise falls back to `urllib`.
- All ledger/cache live under `./.reality_craft/` next to the server process.
