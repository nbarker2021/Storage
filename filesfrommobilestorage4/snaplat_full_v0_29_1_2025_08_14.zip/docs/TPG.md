
# Task Permutation Graph (TPG) — v0.28.1
Adds **Bridge SNAP emission** and a **TPG proposal SNAP** when tpg.enabled=true.
- Bridges: one SNAP per edge with overlap < threshold; attached to `overlays["bridges"]`.
- Proposal: ordered room-id list of the found path; attached to `overlays["proposals"]`.
**Telemetry-only:** no effect on promotions/MDHG until explicitly enabled later.
