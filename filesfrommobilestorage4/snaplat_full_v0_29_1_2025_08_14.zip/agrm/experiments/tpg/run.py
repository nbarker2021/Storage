
from typing import Dict, Any
from agrm.experiments.tpg.build import build_graph
from agrm.experiments.tpg.search import solve_path, analyze_path
from agrm.experiments.tpg.surgery import two_opt_improve

def run_tpg(summary: Dict[str,Any], *, cfg: Dict[str,Any] = None) -> Dict[str,Any]:
    cfg = cfg or {}
    g = build_graph(summary,
                    w_mdhg = cfg.get("w_mdhg", 0.5),
                    w_w5h  = cfg.get("w_w5h", 0.3),
                    w_glyph= cfg.get("w_glyph",0.2),
                    imperf_threshold=cfg.get("imperf_threshold",0.8),
                    max_nodes=cfg.get("max_nodes",24))
    res = solve_path(g, beam=cfg.get("beam", 32), start_ix=None, max_expansions=cfg.get("max_expansions", 20000))
    path = res.get("path", [])
    cost = res.get("cost", 0.0)
    complete = bool(res.get("complete", False))
    if path and cfg.get("use_two_opt", True):
        path2, cost2 = two_opt_improve(g, path, max_passes=cfg.get("two_opt_passes",2))
        if cost2 + 1e-9 < cost:
            path, cost = path2, cost2
    ana = analyze_path(g, path) if path else {"edges": [], "imperfections": 0}
    node_metas = [g["metas"][n] for n in g["nodes"]]
    return {"complete": complete, "cost": float(cost), "imperfections": int(ana.get("imperfections",0)), 
            "edges": ana.get("edges",[]), "nodes": g["nodes"], "node_metas": node_metas}
