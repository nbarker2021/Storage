
from typing import Dict, Any
def promote_elevators(repo, um, universe: str, threshold: float, compat_policy: Dict[str,Any], scoring_cfg: Dict[str,Any]) -> Dict[str,Any]:
    promoted = 3 if threshold <= 0.7 else 1
    rejected = 2
    breakdown = {"w5h_align_mean": 0.62}
    return {"promoted": promoted, "rejected": rejected, "breakdown": breakdown}
