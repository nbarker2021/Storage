
def put_beacon(repo, beacon_id, vector, context, priority, half_life_h):
    repo.save(f"beacon::{beacon_id}", {"vector":vector,"context":context,"priority":priority,"half":half_life_h})
