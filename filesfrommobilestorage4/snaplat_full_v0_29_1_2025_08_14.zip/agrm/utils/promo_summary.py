
import time
def write_promotion_summary(repo, um, universe, iterations, delivered, reason):
    sid = f"promo_summary::{universe}::{int(time.time())}"
    repo.save(sid, {"meta":{"snap_id":sid,"family":"report","type":"promotion","tags":{"universe":universe}},
                    "content":{"delivered":delivered,"reason":reason,"iters":len(iterations)}})
    return sid, {}
