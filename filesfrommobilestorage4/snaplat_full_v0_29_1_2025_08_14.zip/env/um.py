
class Universe:
    def __init__(self, name): self.name = name; self.overlays = {}; self.spec = type("Spec", (), {"policies":{}})()
class UniverseManager:
    def __init__(self): self._u = {}
    def get_universe(self, name):
        if name not in self._u: self._u[name] = Universe(name)
        return self._u[name]
    def save_universe(self, u): self._u[u.name] = u
um = UniverseManager()
