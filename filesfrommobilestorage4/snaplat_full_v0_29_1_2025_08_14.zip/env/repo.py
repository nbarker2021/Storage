
class Repo:
    def __init__(self): self.store = {}
    def save(self, k, v): self.store[k]=v
    def load(self, k): return self.store[k]
    def list(self, prefix):
        for k in self.store:
            if str(k).startswith(prefix): yield k
repo = Repo()
