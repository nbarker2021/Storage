# IRL Use Cases & Best Methods (v1.6)

This document pairs each system section with concrete real-world fits and best practices.

## Legality Kernel (Con-A / pal / CRT)
- **IRL fit:** safety gates in autonomy (DO-178C), medical AI (IEC 62304), finance pre-trade risk.
- **Best method:** treat `verify()` as a hard gate; ship proofs (`/proof/state`) with every decision.
- **Refine:** complete Con-A→Leech implementation; expose `even/unimodular` in proofs.

## Dyadic U₂ & R₂/R₄/R₈/R₁₆/R₆₄
- **IRL fit:** multires nav stacks; streaming analytics at variable resolution.
- **Best method:** promote depth under drive_1_4 only; keep representation_1_8 always on.
- **Refine:** per-domain depth policy; measure accuracy vs energy per uplift step.

## 8-Face Gating (symmetric)
- **IRL fit:** flight-readiness reviews; phased clinical decision supports; data release controls.
- **Best method:** permutation-invariant functionals; publish tolerances per domain.
- **Refine:** calibrate faces with domain benchmarks; publish latch coverage histograms.

## Anchors & Ledger
- **IRL fit:** regulated audit trails; event-sourced systems; compliance replay.
- **Best method:** append-only Merkle + `/replay/verify` + anchor hash in every response.
- **Refine:** batch roots hourly; publish proofs; include NF `phi` checkpoints.

## Contracts & Chainpacks
- **IRL fit:** public attestation, cross-org trust; notarized research claims.
- **Best method:** EIP-712 typed-data; emit CID; keep private payloads off-chain.
- **Refine:** sign via `sign-eip712`; (optional) pin CID using org IPFS node.

## Sandbox Rooms / Personas / Scenarios
- **IRL fit:** team workspaces with fixed policies; A/B templates for domains.
- **Best method:** lock glyph sets per persona; use scenarios to fix pipeline steps.
- **Refine:** plugin loader for custom rooms; connector adapters for S3/Kafka.

## DSL (ConA-64)
- **IRL fit:** sealed playbooks for critical flows; reproducible pipelines.
- **Best method:** compile to auditable bytes; never execute payloads, only store/attest.
- **Refine:** add verifier and effect system; publish opcodes 60..77.

## Ops (Docker, CI, Schemas)
- **IRL fit:** enterprise rollout; multi-team CI; infra reproducibility.
- **Best method:** Docker + CI + Prometheus metrics; JSON Schemas validated in gateway.
- **Refine:** coverage ≥90%; threat model + secrets vault; SLOs for proof latency.
