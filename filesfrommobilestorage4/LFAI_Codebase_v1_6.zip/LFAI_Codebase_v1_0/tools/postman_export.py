import json, time
from fastapi.openapi.utils import get_openapi
from lfaicore.api import app as core_app

def mk_item(pth, method, body=None):
    itm={"name": f"{method.upper()} {pth}",
         "request":{"method":method.upper(),"header":[{"key":"content-type","value":"application/json"}],
                    "url":{"raw":"{{base}}"+pth,"host":["{{base}}"],"path":pth.strip("/").split("/")}}}
    if body:
        itm["request"]["body"]={"mode":"raw","raw":json.dumps(body)}
    return itm

def export():
    pm = {"info":{"name":"LFAI API","schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
                  "_postman_id":"lfai-"+str(int(time.time()))},
          "item":[
            mk_item("/frame","post",{"glyphs":[8,13,32]}),
            mk_item("/verify","post",{"vec":[13,7,9,2,18,5,1,12]}),
            mk_item("/uplift","post",{"vec":[13,7,9,2,18,5,1,12],"steps":2}),
            mk_item("/proof/state","post",{"vec":[13,7,9,2,18,5,1,12]}),
            mk_item("/contracts","post",{"vec":[13,7,9,2,18,5,1,12]}),
            mk_item("/convert/blockchain","post",{"vec":[13,7,9,2,18,5,1,12]})
          ],
          "variable":[{"key":"base","value":"http://localhost:8000"}]}
    print(json.dumps(pm, indent=2))

if __name__ == "__main__":
    export()
