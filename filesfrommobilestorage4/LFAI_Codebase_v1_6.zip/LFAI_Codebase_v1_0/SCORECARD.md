# Build Scorecard (v1.6)
**Overall: 8.6 / 10**

Notables: F4 invariance ✅, replay verify ✅, chain CID ✅, OpenAPI/Postman, signer CLI, Docker Compose, plugins, metrics.

Next raise: Con-A→Leech proofs; calibrated faces per domain; Merkle batch proofs; full coverage CI; connectors wired.
