# SnapLat

SnapLat is a state-aware, agentic pipeline with retrieval, policy, and telemetry.

## Quick start (dev)

```bash
# editable install (outside this environment)
pip install -e .

# run from CLI
snaplat --query "alpha" --top-k 3 --strategy tfco --overlay-out overlay.txt

# or run with a manifest
snaplat --manifest manifest.json
```

## Manifest format
```json
{
  "query": "alpha",
  "top_k": 3,
  "strategy": "tfco",
  "docs": [{"id":"1","text":"alpha beta"}]
}
```

## Config format
```json
{
  "policy": {
    "denylist": ["blockedterm"],
    "rules": { "require_nonempty_query": true, "top_k_bounds": { "min": 1, "max": 50 } }
  },
  "telemetry": {
    "log_path": "/tmp/snaplat_telemetry.jsonl"
  }
}
```

## Modules
- `snaplat.agent` — routing and orchestration helpers
- `snaplat.shell` — batch sweep
- `snaplat.index` — in-memory index with ranking strategies
- `snaplat.overlay` — renderers and diffs
- `snaplat.policy` — allow/deny and simple rules
- `snaplat.telemetry` — structured logging with traces/spans
- `snaplat.ops` — CLI and config tooling
- `snaplat.repo` — snapshots

## License
MIT


## Strategies
- `tf`: term-frequency scoring
- `tfco`: TF with co-occurrence re-rank
- `vec`: cosine on token-frequency vectors
- `hybrid`: weighted sum of TF and vector

## Telemetry exporter
```python
from snaplat.telemetry import export
export.export("/path/to/telemetry.jsonl", csv_out="/path/to/telemetry.csv")
```


## RAG loaders
```python
from snaplat.repo import loaders
docs = loaders.load_jsonl("docs.jsonl", mapping={"id":"id","text":"body"})
# or
docs = loaders.load_csv("docs.csv", mapping={"id":"doc_id","text":"content"})
# or
docs = loaders.load_markdown("notes.md", split_on_h1=True)
```

## Policy dry-run
```python
from snaplat.policy import explain
report = explain.dry_run({"query":"blockedterm","top_k":2})
print(report)
```
