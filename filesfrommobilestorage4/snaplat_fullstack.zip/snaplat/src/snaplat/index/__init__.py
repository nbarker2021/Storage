"""SnapLat index — in-memory document store + bag-of-words retrieval, with export/import."""
from __future__ import annotations
from typing import Any, Dict, List, Tuple
import math, re
from collections import defaultdict
from snaplat import telemetry as _tele

_DOCS: List[Dict[str, Any]] = []
_INV: Dict[str, Dict[int, int]] = defaultdict(dict)  # term -> {doc_id: tf}
_N = 0

_TOKEN = re.compile(r"[A-Za-z0-9_]+")

def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN.findall(text or "")]

def _add_one(doc: Dict[str, Any], idx: int) -> None:
    tf = defaultdict(int)
    for tok in _tokenize(str(doc.get("text",""))):
        tf[tok]+=1
    for tok, cnt in tf.items():
        _INV[tok][idx] = cnt

def ingest(docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    with _tele.span("index.ingest", kind="internal", count=len(docs) if isinstance(docs, list) else 0):
    """Ingest docs: each doc at least {'id': str/int, 'text': str}."""
    global _DOCS, _INV, _N
    start_n = _N
            for d in docs:
        _DOCS.append(d)
        idx = len(_DOCS)-1
        _add_one(d, idx)
        _N += 1
        return {"ok": True, "added": _N - start_n, "total": _N}

def export_docs() -> List[Dict[str, Any]]:
    return list(_DOCS)

def import_docs(docs: List[Dict[str, Any]]) -> Dict[str, Any]:
    clear()
    return ingest(docs)

def _doc_len(doc_id: int) -> int:
    # approximate length as sum tf for tokens present
    s=0
    for t, posting in _INV.items():
        if doc_id in posting:
            s += posting[doc_id]
    return s or 1

def _score(query: str, doc_id: int) -> float:
    q = _tokenize(query)
    if not q: return 0.0
    score = 0.0
    for t in q:
        score += _INV.get(t, {}).get(doc_id, 0)
    return score / math.sqrt(_doc_len(doc_id))

def search(query: str, top_k: int = 5, strategy: str = 'tf') -> List[Dict[str, Any]]:
    with _tele.span("index.search", kind="internal", strategy=strategy, top_k=top_k, query=str(query)[:64]):
            scores = []
    for i in range(len(_DOCS)):
        s = _score(query, i)
        if s > 0:
            scores.append((s, i))
    scores.sort(reverse=True)
    out = []
    for s, i in scores[:top_k]:
        d = dict(_DOCS[i])
        d["_score"] = float(s)
        out.append(d)
            return out

def clear() -> None:
    global _DOCS, _INV, _N
    _DOCS = []
    _INV = defaultdict(dict)
    _N = 0

__all__ = ["ingest", "search", "clear", "export_docs", "import_docs"]


def _re_rank_cooccurrence(query: str, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Boost results that contain tokens which frequently co-occur with the query tokens."""
    q_tokens = set(_tokenize(query))
    if not q_tokens or not results:
        return results
    # Build co-occurrence counts: token -> count of docs that contain query_token & token
    from collections import defaultdict
from snaplat import telemetry as _tele
    co = defaultdict(int)
    # Precompute doc tokens
    doc_tokens = [set(_tokenize(d.get("text",""))) for d in _DOCS]
    for qt in q_tokens:
        docs_with_q = [i for i, toks in enumerate(doc_tokens) if qt in toks]
        # For each doc with q, add tokens present
        for i in docs_with_q:
            for t in doc_tokens[i]:
                if t != qt:
                    co[t] += 1
    # Score each result by sum of co-occurrence of its non-query tokens
    rescored = []
    for d in results:
        toks = set(_tokenize(d.get("text","")))
        bonus = sum(co.get(t, 0) for t in toks - q_tokens)
        d2 = dict(d)
        d2["_score_rerank"] = float(d2.get("_score", 0.0)) + 1e-6 * float(bonus)
        rescored.append(d2)
    rescored.sort(key=lambda x: x.get("_score_rerank", 0.0), reverse=True)
            return rescored


def _vector_score(query: str, doc_id: int) -> float:
    """Cosine similarity of token-frequency vectors (embedding proxy)."""
    q = _tokenize(query)
    if not q: return 0.0
    # Query tf (binary 1 per token)
    from collections import defaultdict
    tf_q = defaultdict(float)
    for t in q:
        tf_q[t] += 1.0
    # Doc tf from inverted index
    tf_d = defaultdict(float)
    for t in set(sum([_tokenize(_DOCS[doc_id].get("text",""))], [])):
        tf_d[t] = float(_INV.get(t, {}).get(doc_id, 0))
    # Dot + norms
    dot = sum(tf_q[t]*tf_d.get(t,0.0) for t in tf_q.keys())
    import math as _m
    nq = (_m.sqrt(sum(v*v for v in tf_q.values())) or 1.0)
    nd = (_m.sqrt(sum(v*v for v in tf_d.values())) or 1.0)
    return float(dot)/(nq*nd)

def _search_vec(query: str, top_k: int = 5) -> List[Dict[str, Any]]:
    scores = []
    for i in range(len(_DOCS)):
        s = _vector_score(query, i)
        if s > 0:
            scores.append((s, i))
    scores.sort(reverse=True)
    out = []
    for s, i in scores[:top_k]:
        d = dict(_DOCS[i]); d["_score"] = float(s)
        out.append(d)
    return out

def _hybrid_merge(tf_out: List[Dict[str, Any]], vec_out: List[Dict[str, Any]], alpha: float = 1.0, beta: float = 1.0) -> List[Dict[str, Any]]:
    """Combine TF score and vector cosine via weighted sum; normalize by max to keep scale reasonable."""
    import math as _m
    tf_map = {d.get("id"): float(d.get("_score", 0.0)) for d in tf_out}
    vc_map = {d.get("id"): float(d.get("_score", 0.0)) for d in vec_out}
    ids = set(tf_map.keys()) | set(vc_map.keys())
    max_tf = max([1.0]+list(tf_map.values()))
    max_vc = max([1.0]+list(vc_map.values()))
    merged = []
    for i in ids:
        s = alpha*(tf_map.get(i,0.0)/max_tf) + beta*(vc_map.get(i,0.0)/max_vc)
        # Find doc dict from either list
        d = next((x for x in tf_out if x.get("id")==i), None) or next((x for x in vec_out if x.get("id")==i), {})
        d2 = dict(d); d2["_score"] = float(s)
        merged.append(d2)
    merged.sort(key=lambda x: x.get("_score", 0.0), reverse=True)
    return merged
