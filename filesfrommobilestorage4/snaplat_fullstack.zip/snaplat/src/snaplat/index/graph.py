"""snaplat.index.graph — token and document neighborhood utilities."""
from __future__ import annotations
from typing import Any, Dict, List, Tuple
from collections import defaultdict, Counter
from . import export_docs

def cooccurrence(top_k: int = 20) -> Dict[str, List[Tuple[str,int]]]:
    """Return token co-occurrence counts across docs: token -> list[(other, count)]."""
    docs = export_docs()
    token_docs = defaultdict(set)  # token -> set(doc_id)
    for i, d in enumerate(docs):
        text = str(d.get("text","")).lower()
        toks = [t for t in text.split() if t]
        for t in set(toks):
            token_docs[t].add(i)
    pairs = defaultdict(Counter)
    tokens = list(token_docs.keys())
    for t in tokens:
        for u in tokens:
            if t == u: continue
            common = token_docs[t] & token_docs[u]
            if common:
                pairs[t][u] += len(common)
    out = {}
    for t, cnt in pairs.items():
        out[t] = cnt.most_common(top_k)
    return out

def doc_neighbors(doc_id: int, top_k: int = 5) -> List[int]:
    """Return doc ids with most shared tokens with given doc."""
    docs = export_docs()
    if doc_id < 0 or doc_id >= len(docs): return []
    base = set(str(docs[doc_id].get("text","")).lower().split())
    scores = []
    for i, d in enumerate(docs):
        if i == doc_id: continue
        s = len(base & set(str(d.get("text","")).lower().split()))
        if s > 0: scores.append((s, i))
    scores.sort(reverse=True)
    return [i for _, i in scores[:top_k]]

__all__ = ["cooccurrence", "doc_neighbors"]
