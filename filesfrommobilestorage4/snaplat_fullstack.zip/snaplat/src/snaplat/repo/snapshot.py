"""snaplat.repo.snapshot — simple JSONL snapshot for index docs."""
from __future__ import annotations
from typing import Any, Dict, List
import json, os
from snaplat import index

def save_index(path: str) -> Dict[str, Any]:
    docs = index.export_docs()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for d in docs:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    return {"ok": True, "count": len(docs), "path": path}

def load_index(path: str) -> Dict[str, Any]:
    docs: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line: continue
            docs.append(json.loads(line))
    index.import_docs(docs)
    return {"ok": True, "count": len(docs), "path": path}

__all__ = ["save_index","load_index"]
