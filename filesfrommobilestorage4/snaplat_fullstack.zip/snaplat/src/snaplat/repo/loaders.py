"""snaplat.repo.loaders — RAG data loaders (JSONL/CSV/Markdown) with field mapping."""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import os, json, csv, re
from pathlib import Path

def _apply_map(raw: Dict[str, Any], mapping: Dict[str, str]) -> Dict[str, Any]:
    # mapping keys: id,title,text; optionally meta.* → nested meta dict
    doc = {}
    meta = {}
    for k, path in (mapping or {}).items():
        val = raw
        for part in str(path).split('.'):
            if isinstance(val, dict):
                val = val.get(part)
            else:
                val = None
        if k.startswith("meta."):
            meta[k.split('.',1)[1]] = val
        else:
            doc[k] = val
    if "id" not in doc:
        # fallback to any of raw id-like fields
        for cand in ("id","uuid","pk"):
            if cand in raw: doc["id"] = raw[cand]; break
    if "text" not in doc:
        # fallback to joining string fields
        s = " ".join([str(v) for v in raw.values() if isinstance(v, (str,int,float))])
        doc["text"] = s
    if meta:
        doc["meta"] = meta
    return doc

def load_jsonl(path: str, mapping: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            raw = json.loads(line)
            doc = _apply_map(raw, mapping or {"id":"id","title":"title","text":"text"})
            out.append(doc)
    return out

def load_csv(path: str, mapping: Optional[Dict[str, str]] = None, delimiter: str = ",") -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        rdr = csv.DictReader(f, delimiter=delimiter)
        for row in rdr:
            doc = _apply_map(row, mapping or {"id":"id","title":"title","text":"text"})
            out.append(doc)
    return out

def load_markdown(path: str, split_on_h1: bool = True) -> List[Dict[str, Any]]:
    """Load a Markdown file; split on H1 headings if desired. Each chunk becomes a doc."""
    txt = Path(path).read_text(encoding="utf-8")
    docs: List[Dict[str, Any]] = []
    if split_on_h1 and "\n# " in txt:
        parts = re.split(r"\n#\s+", txt)
        head = parts[0].strip()
        if head:
            docs.append({"id": f"{Path(path).stem}:0", "title": Path(path).stem, "text": head})
        for i, chunk in enumerate(parts[1:], 1):
            # title is first line of chunk
            lines = chunk.splitlines()
            title = lines[0].strip()
            body = "\n".join(lines[1:]).strip()
            docs.append({"id": f"{Path(path).stem}:{i}", "title": title, "text": body})
    else:
        docs.append({"id": Path(path).stem, "title": Path(path).stem, "text": txt})
    return docs

__all__ = ["load_jsonl","load_csv","load_markdown"]
