"""snaplat.ops.cli — simple CLI for running orchestrator with a manifest or args."""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import argparse, json, sys, os
from snaplat.orch import runner
from snaplat.ops import config as _cfg
from snaplat import overlay

def _load_jsonl(path: str) -> List[Dict[str, Any]]:
    docs: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            docs.append(json.loads(line))
    return docs

def build_manifest(args: argparse.Namespace) -> Dict[str, Any]:
    m: Dict[str, Any] = {}
    if args.manifest:
        with open(args.manifest, "r", encoding="utf-8") as f:
            m = json.load(f)
    else:
        m = {"query": args.query, "top_k": args.top_k, "strategy": args.strategy}
        if args.docs:
            m["docs"] = _load_jsonl(args.docs)
    return m

def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="snaplat", description="Run SnapLat orchestrator")
    p.add_argument("--manifest", type=str, help="Path to JSON manifest")
        p.add_argument("--config", type=str, help="Path to JSON config (policy, rules, telemetry)")
    p.add_argument("--docs", type=str, help="Path to docs (ignored if --manifest given)")
        p.add_argument("--loader", choices=["jsonl","csv","md"], default="jsonl")
        p.add_argument("--map", dest="mapping", type=str, help="Field mapping as JSON for loaders (e.g. {\"id\":\"id\",\"text\":\"body\"})")
    p.add_argument("--query", type=str, default="index")
    p.add_argument("--top-k", dest="top_k", type=int, default=3)
    p.add_argument("--strategy", choices=["tf","tfco","vec","hybrid"], default="tf")
    p.add_argument("--overlay-out", type=str, help="Path to save overlay text output")
        p.add_argument("--dry-run", action="store_true", help="Policy/rules dry-run for the query (no execution)")
    args = p.parse_args(argv)

    if args.config:
            cfg = _cfg.load(args.config)
            _cfg.apply(cfg)
        if args.config:
            cfg = _cfg.load(args.config)
            _cfg.apply(cfg)
        man = build_manifest(args)
        if args.dry_run:
            from snaplat.policy import explain as _ex
            print(json.dumps(_ex.dry_run({"query": man.get("query",""), "top_k": man.get("top_k", 3)}), indent=2))
            return 0
    steps = runner.run(man)
    # steps[3] is overlay string already; ensure we have it
    ov = steps[3] if isinstance(steps[3], str) else overlay.render(steps[0])
    if args.overlay_out:
        os.makedirs(os.path.dirname(args.overlay_out), exist_ok=True)
        with open(args.overlay_out, "w", encoding="utf-8") as f:
            f.write(ov + "\n")
    else:
        print(ov)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
