"""SnapLat shell — sweep strategies that query the index."""
from __future__ import annotations
from typing import Any, Dict, List
from snaplat import telemetry
from snaplat import index as _index

def sweep(queries: List[str] | None = None, top_k: int = 5) -> Dict[str, Any]:
    with telemetry.span("shell.sweep", kind="internal", queries=len(queries or []), top_k=top_k):
            qs = queries or []
    out: List[Dict[str, Any]] = []
    for q in qs:
        out.append({"query": q, "hits": _index.search(q, top_k=top_k)})
    telemetry.log({"event":"shell_sweep","queries":len(qs)})
        return {"ok": True, "batches": out}

__all__ = ["sweep"]
