"""snaplat.policy.rules — named rules and detailed evaluation."""
from __future__ import annotations
from typing import Any, Callable, Dict, List, Tuple

_RULES: List[Tuple[str, Callable[[Dict[str, Any]], Tuple[bool, str]]]] = []

def add_rule(name: str, fn: Callable[[Dict[str, Any]], Tuple[bool, str]]) -> None:
    _RULES.append((name, fn))

def clear_rules() -> None:
    _RULES.clear()

def apply(task: Dict[str, Any]) -> Dict[str, Any]:
    evaluations = []
    ok_all = True
    reasons = []
    for name, fn in _RULES:
        ok, why = fn(task)
        evaluations.append({"name": name, "ok": bool(ok), "reason": why})
        if not ok:
            ok_all = False
            reasons.append(why or name)
    return {"ok": ok_all, "reasons": reasons, "evaluations": evaluations}

# defaults
def _r_nonempty_query(task: Dict[str, Any]):
    q = str((task or {}).get("query",""))
    return (len(q.strip())>0, "empty_query")

def _r_topk_bounds(task: Dict[str, Any]):
    try:
        k = int((task or {}).get("top_k", 5))
    except Exception:
        k = 5
    return (1 <= k <= 50, "top_k_out_of_bounds")

clear_rules()
add_rule("nonempty_query", _r_nonempty_query)
add_rule("topk_bounds", _r_topk_bounds)

__all__ = ["add_rule","clear_rules","apply"]
