"""snaplat.telemetry.quicktrace — timing helper built on telemetry.span."""
from __future__ import annotations
from typing import Any, Callable
import time
from . import span, log

class quicktrace:
    def __init__(self, label: str, **fields: Any):
        self.label = label
        self.fields = fields
        self.t0 = None
        self._span = None
    def __enter__(self):
        self.t0 = time.time()
        self._span = span(self.label, **self.fields)
        self._span.__enter__()
        return self
    def __exit__(self, exc_type, exc, tb):
        try:
            dur = int((time.time() - (self.t0 or time.time()))*1000)
            log({"event":"quicktrace","label":self.label,"duration_ms": dur})
        finally:
            if self._span:
                self._span.__exit__(exc_type, exc, tb)

def traced(label: str):
    def deco(fn: Callable[..., Any]):
        def wrapper(*a, **k):
            with quicktrace(label):
                return fn(*a, **k)
        return wrapper
    return deco

__all__ = ["quicktrace","traced"]
