
"""SnapLat telemetry — structured events with timestamp + trace + span/parent + span.kind."""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import json, os, time, contextvars, uuid

_EVENTS: List[Dict[str, Any]] = []
_LOG_PATH = os.environ.get("SNAPLAT_TELEMETRY_LOG", "/mnt/data/code_atlas/rebuild_workspace/telemetry.log")

_TRACE_ID: contextvars.ContextVar[str] = contextvars.ContextVar("snaplat_trace_id", default="")
_SPAN_ID:  contextvars.ContextVar[str] = contextvars.ContextVar("snaplat_span_id", default="")
_PARENT_ID:contextvars.ContextVar[str] = contextvars.ContextVar("snaplat_parent_span_id", default="")

def new_trace_id() -> str:
    return uuid.uuid4().hex

def new_span_id() -> str:
    return uuid.uuid4().hex

def set_trace_id(trace_id: str) -> None:
    _TRACE_ID.set(trace_id)

def get_trace_id() -> str:
    return _TRACE_ID.get()

def get_span_id() -> str:
    return _SPAN_ID.get()

class trace:
    """Context manager to set a trace id for nested operations."""
    def __init__(self, trace_id: Optional[str] = None):
        self.tid = trace_id or new_trace_id()
        self._token = None
    def __enter__(self):
        self._token = _TRACE_ID.set(self.tid)
        return self.tid
    def __exit__(self, exc_type, exc, tb):
        try:
            if self._token is not None:
                _TRACE_ID.reset(self._token)
        except Exception:
            pass

class span:
    """Context manager to create a span with parent linkage and duration.
    Args:
      label: operation name
      kind: 'internal'|'client'|'server' (string)
      **fields: additional attributes to attach to span_start
    """
    def __init__(self, label: str, kind: str = 'internal', **fields: Any):
        self.label = label
        self.kind = kind
        self.fields = fields
        self.sid = new_span_id()
        self._tok_sid = None
        self._tok_parent = None
        self._t0 = None
    def __enter__(self):
        import time as _t
        self._t0 = _t.time()
        parent = _SPAN_ID.get()
        self._tok_parent = _PARENT_ID.set(parent)
        self._tok_sid = _SPAN_ID.set(self.sid)
        log({"event":"span_start","label":self.label,"span":self.sid,"parent":parent,"span.kind":self.kind, **self.fields})
        return self.sid
    def __exit__(self, exc_type, exc, tb):
        import time as _t
        dur = int((_t.time() - (self._t0 or _t.time()))*1000)
        parent = _PARENT_ID.get()
        log({"event":"span_end","label":self.label,"span":self.sid,"parent":parent,"span.kind":self.kind,"duration_ms":dur,"error": (type(exc).__name__ if exc else None)})
        try:
            if self._tok_sid is not None:
                _SPAN_ID.reset(self._tok_sid)
            if self._tok_parent is not None:
                _PARENT_ID.reset(self._tok_parent)
        except Exception:
            pass

def log(event: Dict[str, Any]) -> None:
    """Append an event to memory and to a JSONL file; add ts + trace/span if absent."""
    if "ts" not in event:
        event["ts"] = int(time.time() * 1000)
    tid = event.get("trace") or get_trace_id() or new_trace_id()
    set_trace_id(tid)
    event["trace"] = tid
    if "span" not in event:
        cur_span = get_span_id()
        if cur_span:
            event["span"] = cur_span
            parent = _PARENT_ID.get()
            if parent:
                event.setdefault("parent", parent)
    _EVENTS.append(event)
    try:
        with open(_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    except Exception:
        pass

def get_events(limit: Optional[int] = None) -> List[Dict[str, Any]]:
    if limit is None or limit >= len(_EVENTS):
        return list(_EVENTS)
    return _EVENTS[-limit:]

__all__ = ["log", "get_events", "trace", "span", "new_trace_id", "new_span_id", "set_trace_id", "get_trace_id", "get_span_id"]
