"""snaplat.telemetry.export — Parquet-first exporter + summaries."""
from __future__ import annotations
from typing import Any, Dict, List, Optional
import os, json, datetime as _dt

def _load_jsonl(path: str) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            try:
                events.append(json.loads(line))
            except Exception:
                pass
    return events

def summarize(events: List[Dict[str, Any]]) -> Dict[str, Any]:
    from collections import Counter, defaultdict
    cnt = Counter(e.get("event") for e in events)
    by_trace = defaultdict(int)
    for e in events:
        t = e.get("trace") or ""
        if t: by_trace[t]+=1
    # span stats
    end = [e for e in events if e.get("event")=="span_end"]
    by_label = defaultdict(list)
    for e in end:
        by_label[e.get("label")].append(int(e.get("duration_ms",0)))
    avg = {k: (sum(v)/len(v) if v else 0.0) for k,v in by_label.items()}
    err = sum(1 for e in end if e.get("error"))
    return {
        "counts": dict(cnt),
        "avg_duration_ms": avg,
        "span_end_errors": err,
        "total_events": len(events),
        "traces": len(by_trace),
    }

def export_enriched(jsonl_path: str, out_dir: str) -> Dict[str, Any]:
    """Export events to Parquet if possible (fallback CSV), and write summary.{json,md}."""
    os.makedirs(out_dir, exist_ok=True)
    events = _load_jsonl(jsonl_path)
    summary = summarize(events)
    # Write table
    parquet_path = os.path.join(out_dir, "events.parquet")
    csv_path = os.path.join(out_dir, "events.csv")
    try:
        import pandas as pd  # type: ignore
        df = pd.DataFrame(events)
        try:
            df.to_parquet(parquet_path, index=False)
            table_path = parquet_path
        except Exception:
            df.to_csv(csv_path, index=False)
            table_path = csv_path
    except Exception:
        # minimal fallback
        open(csv_path,"w",encoding="utf-8").write("\n".join(json.dumps(e) for e in events))
        table_path = csv_path
    # Summary JSON
    sum_json = os.path.join(out_dir, "summary.json")
    with open(sum_json, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    # Summary MD
    sum_md = os.path.join(out_dir, "summary.md")
    lines = [
        f"# Telemetry Summary — {_dt.datetime.utcnow().isoformat()}Z",
        f"- Events: {summary['total_events']}",
        f"- Traces: {summary['traces']}",
        f"- Span end errors: {summary['span_end_errors']}",
        "## Event counts",
    ]
    for k,v in sorted(summary["counts"].items(), key=lambda kv: kv[0]):
        lines.append(f"- {k}: {v}")
    lines.append("## Avg durations (ms) by span")
    for k,v in sorted(summary["avg_duration_ms"].items(), key=lambda kv: kv[0]):
        lines.append(f"- {k}: {v:.2f}")
    with open(sum_md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return {"ok": True, "table": table_path, "summary_json": sum_json, "summary_md": sum_md, "events": len(events)}
