
from agrm.policy.policy_bus import check_policy, PolicyDecision
def test_family_allow_safe_cube():
    pol = {"family_allow": ["science"], "safe_cube": True}
    crit = {"family":["science"], "tags":{"x":1}}
    dec = check_policy(pol, crit)
    assert dec.allow and dec.reason == "ok"
def test_safe_cube_denies_without_tags():
    pol = {"safe_cube": True}
    crit = {"family":["science"]}
    dec = check_policy(pol, crit)
    assert not dec.allow and dec.reason == "safe_cube_requires_tags"
