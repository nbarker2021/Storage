
[![License: SnapLat Personal Use](https://img.shields.io/badge/license-SnapLat%20Personal%20Use-blue.svg)](LICENSE-SNAPLAT-PERSONAL.md)
