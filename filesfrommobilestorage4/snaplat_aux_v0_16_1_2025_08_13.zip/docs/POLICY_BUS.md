
# PolicyBus
Centralized policy checks to avoid drift between Mannequin, Controller, and Promotion.

```python
from agrm.policy.policy_bus import check_policy

policies = {"family_allow": ["science","fact"], "safe_cube": True}
criteria = {"family":["science"], "type":["fact"], "tags":{"snap_score_gt":0.6}}
dec = check_policy(policies, criteria)  # -> PolicyDecision(allow=True, reason="ok")
```
