
# Pre-commit setup
1) Install pre-commit: `pip install pre-commit`
2) Copy `.pre-commit-config.yaml` and `tools/` into repo root.
3) Run `pre-commit install`
4) Optionally apply headers now: `python tools/attach_headers.py .`

CI: run `pre-commit run --all-files` in your pipeline to enforce headers.
