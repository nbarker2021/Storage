from dataclasses import replace
from typing import List
from .cona import even_neighbor
from .frame import Frame
def uplift_u2(vec: List[int], frame: Frame):
    new_frame = replace(frame, dyadic_depth=frame.dyadic_depth+1, rest_scale=2**(frame.dyadic_depth+1))
    # extend 2-adic tower by one power of two beyond current max
    twos = [m for m in frame.mods if m & (m-1)==0]
    nxt = 2**(max([3]+[m.bit_length()-1 for m in twos])+1)
    if nxt not in new_frame.mods: new_frame.mods=sorted(set(new_frame.mods+[nxt]))
    return even_neighbor(vec), new_frame
