import hashlib
import pytest
from lfaicore.frame import compile_from_glyphs
from lfaicore.uplift import uplift_u2
from lfaicore.reducer import reduce_to_rest
from lfaicore.cona import legal_even
from lfaicore.pal import pal_defects
from lfaicore.gating import latch_sweep
from lfaicore.anchors import anchor_id

SEED_VEC = [13,7,9,2,18,5,1,12]

def nf_anchor(vec, glyphs=[8,13,32], uplift_steps=0):
    f = compile_from_glyphs(glyphs)
    v = list(vec)
    for _ in range(uplift_steps):
        v, f = uplift_u2(v, f)
    v = reduce_to_rest(v)
    aid, bits = anchor_id(v, f)
    return aid, bits, f

def test_F1_confluence_no_break():
    # Reduce then uplift vs uplift then reduce -> same anchor at same final depth
    aid1, bits1, f1 = nf_anchor(SEED_VEC, uplift_steps=3)  # (reduce->anchor) then conceptually mapped by depth
    # Do uplift then reduce
    f = compile_from_glyphs([8,13,32]); v = list(SEED_VEC)
    for _ in range(3): v, f = uplift_u2(v, f)
    v = reduce_to_rest(v); aid2, bits2 = anchor_id(v, f)
    assert aid1 == aid2

def test_F2_typeII_no_mirage():
    v = reduce_to_rest(SEED_VEC)
    legal, s = legal_even(v)
    pd = pal_defects(v)
    assert legal and pd['P4']==0 and pd['P8']==0

def test_F3_pal_zero_at_rest():
    v = reduce_to_rest(SEED_VEC)
    pd = pal_defects(v)
    assert pd['P4']==0 and pd['P8']==0

@pytest.mark.xfail(reason="Frame morphisms invariance pending calibrated face functionals (see GAP_CHECKS.md)")
def test_F4_invariance_under_allowed_morphisms():
    # Placeholder: would apply allowed morphisms and assert anchor unchanged
    aid1,_,_ = nf_anchor(SEED_VEC)
    aid2,_,_ = nf_anchor(SEED_VEC[::-1])  # naive mirror not guaranteed equal yet
    assert aid1 == aid2

def test_F7_gating_completeness():
    latch = latch_sweep(SEED_VEC)
    ready = all(latch)
    advanced = ready  # engine would only advance if all latched
    assert advanced == ready

def test_F8_depth_commutation():
    # NF(U2(Reduce*)) == NF(Reduce*(U2))
    aid1,_,_ = nf_anchor(SEED_VEC, uplift_steps=1)
    f = compile_from_glyphs([8,13,32]); v=list(SEED_VEC)
    v = reduce_to_rest(v); v,f = uplift_u2(v,f); aid2,_ = anchor_id(v,f)
    assert aid1 == aid2

def test_F9_odd_lift_no_leak():
    f = compile_from_glyphs([8,13,32]); v=list(SEED_VEC)
    v2,f2 = uplift_u2(v,f)
    # Even-neighbor preserves even parity of sum (demo property)
    assert (sum(v2) % 2) == 0

def test_F10_thresholds_scale_free():
    f = compile_from_glyphs([8,13,32]); v=list(SEED_VEC)
    v2,f2 = uplift_u2(v,f)
    assert f.tau == f2.tau
