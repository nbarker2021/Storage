from lfaicore.cid import compute_cid
from fastapi import FastAPI, Body, Request
from fastapi.responses import JSONResponse
import time, json, hashlib
from lfaicore.config import load as cfg_load, save as cfg_save, get as cfg_get
from lfaicore.jws import sign_hs256, verify_hs256

app = FastAPI(title="LFAI API Skeleton", version="2.9.0")

@app.post("/octet/run")
def octet_run(request: Request, lanes: list = Body(...)):
    return _wrap_response(request, detail if isinstance(detail, dict) else {}, {"ok": True, "lanes": lanes, "ts": time.time()})

def _emit_headers(request: Request, payload: dict, anchor: str | None = None):
    sub = payload.get("sub","")
    policy_id = payload.get("policy_id") or payload.get("scope") or cfg_get("policy_defaults",{}).get("fallback_policy_id","EVAL")
    if isinstance(policy_id, list): policy_id = policy_id[0] if policy_id else "EVAL"
    jti = payload.get("jti","")
    # pick the matched endpoint prefix
    prefixes = cfg_get("jws_endpoint_prefixes", ["/octet/","/channel/","/planner/"])
    ep = next((p for p in prefixes if request.url.path.startswith(p)), "/")
    # secret
    secret_hex = cfg_get("color_secret","")
    try:
        secret = bytes.fromhex(secret_hex)
    except Exception:
        secret = secret_hex.encode()
    cid_hex, cid_tag = compute_cid(secret, sub, str(policy_id), ep)
    headers = {
        "X-Color-ID": cid_hex,
        "X-Policy-ID": str(policy_id),
        "X-Permission-JTI": jti,
        "X-Contract-Sub": sub
    }
    if anchor: headers["X-Anchor"] = anchor
    meta = {"cid": cid_hex, "cid_tag": cid_tag, "policy_id": str(policy_id), "sub": sub, "jti": jti}
    return headers, meta

def _wrap_response(request: Request, payload: dict, body: dict):
    try:
        hdrs, meta = _emit_headers(request, payload, body.get("post_anchor") or body.get("anchor_id"))
        # attach meta to body for ledger append_compact (if present)
        if isinstance(body, dict):
            body.setdefault("_policy_meta", meta)
        return JSONResponse(body, headers=hdrs)
    except Exception:
        # fallback without headers
        return JSONResponse(body)
