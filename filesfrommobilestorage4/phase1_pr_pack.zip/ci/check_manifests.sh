
    #!/usr/bin/env bash
    set -euo pipefail
    python - <<'PY'
import json, pathlib, sys
from e8snap.validators import validate_snap
root = pathlib.Path("snaps")
if not root.exists():
    print("No snaps/ directory; skipping.")
    raise SystemExit(0)
errors = 0
for p in root.rglob("*.json"):
    try:
        validate_snap(json.loads(p.read_text()))
    except Exception as e:
        print(f"Invalid manifest: {p} -> {e}")
        errors += 1
if errors:
    sys.exit(1)
print("All manifests valid.")
PY
