
# Phase-1 PR Pack (Staged)

Contents ready to drop into your repo:

- service/snap_service_writer.py — central SNAP writer (SNAP v2 + E8-AS enforced)
- service/rest_snaps_endpoint.py — REST endpoint (FastAPI) with validation
- tests/test_e8_geometry.py — invariance tests for lifted E8 v14 geometry
- ci/check_manifests.sh — CI gate to validate all SNAP manifests
- tools/mdhg_hybrid_policy.py — decision helper for MDHG vs native hash

## Apply order
1) Copy E8 geometry files into v14 (`lattice_ai/geometry/e8*.py`) and update imports.
2) Add `service/` writer + REST endpoint (wire router include).
3) Drop `tests/test_e8_geometry.py`, run pytest.
4) Place `ci/check_manifests.sh` in CI and hook to your pipeline.
5) Use `tools/mdhg_hybrid_policy.py` at persistence boundaries.

## Post-apply checks
- pytest passes (geometry + existing tests)
- CI manifest validation passes
- New /snaps endpoint rejects missing `e8` or invalid manifests
