
# snap_service_writer.py
# Drop-in: routes all SNAP writes through schema validation (SNAP v2 + E8-AS).
from pathlib import Path
from e8snap.snap_writer import write_manifest, now_iso
from e8snap.validators import validate_snap

def new_manifest(*, snap_id: str, e8: dict, axes: dict, kind: str, payload: dict, **kw) -> dict:
    manifest = {
        "schema_version": "2.0",
        "snap_id": snap_id,
        "created_at": now_iso(),
        "e8": e8,
        "axes": axes,
        "kind": kind,
        "payload": payload,
        "provenance": kw.get("provenance", {}),
        "security": {"allow_pickle": False, **kw.get("security", {})},
        "metrics": kw.get("metrics", {}),
        "notes": kw.get("notes", ""),
        "parent_id": kw.get("parent_id"),
        "children": kw.get("children", []),
        "hashes": kw.get("hashes", {}),
    }
    return manifest

def persist_manifest(manifest: dict, path: Path) -> None:
    validate_snap(manifest)  # hard validation gate
    write_manifest(manifest, path)
