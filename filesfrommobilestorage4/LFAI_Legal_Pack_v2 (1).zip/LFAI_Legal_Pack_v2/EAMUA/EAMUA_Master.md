# Evaluation & Access Master Use Agreement (EAMUA)
**Effective Date:** 2025-09-17

**Parties.** Nick (“Licensor/Discloser”) and [COUNTERPARTY] (“Licensee/Recipient”) (each, a “Party”).

## 1. Purpose & Scope
Licensor grants Licensee limited **evaluation-only** access to software, services, documentation, and **Outputs** solely to assess a potential business relationship (the “Purpose”) under this Agreement and the attached **Permission Schedule A**.

## 2. Key Definitions
**Software**: LFAI code, components, SDKs, configs, schemas, docs, updates.  
**Service**: any hosted instance or API implementing the Software.  
**Outputs**: any artifacts produced by or derived from Software/Service (including **anchors, paints, ledgers, embeddings, logs, responses, metrics**).  
**Confidential Information**: all non‑public information disclosed or observed under this Agreement, including Software, Service, and Outputs.  
**Permission Schedule**: scope/term/territory and any technical limits (rate limits, endpoints).

## 3. Access Grant (Evaluation‑Only; No Production)
Subject to compliance, Licensor grants Licensee a revocable, non‑exclusive, non‑transferable, **non‑sublicensable** right to (a) access the Service and/or (b) internally use the Software solely for the Purpose within the **Scope/Term/Territory** in Schedule A.

## 4. Use & Restrictions (sweeping; strict)
- **No Training / No Tuning / No Benchmarking / No Publication** on or with the Outputs without prior written consent.  
- **No Reverse‑Engineering / No Circumvention** of gating, legality, commit rules, or protections.  
- **No Redistribution / No Hosting for Third Parties**; no SaaS or API exposure to third parties.  
- **No Derivatives** of Software except minimal configuration needed for deployment as provided.  
- **Field‑of‑Use/Territory**: limited to Schedule A; internal evaluation only.  
- **Credential Hygiene**: no sharing of accounts; MFA required where available.  
- **Residuals Disclaimed**: Licensee will not use information retained in unaided memory outside the Purpose.

## 5. Confidentiality; Outputs Included
All Software and **Outputs** are Confidential Information. Licensee shall protect with at least reasonable care, restrict to need‑to‑know personnel bound by written obligations, and use only for the Purpose.

## 6. Attestation; Anchors & Paints
Upon request or termination, Licensee will **cease use**, and **return or destroy** Confidential Information and Outputs, and deliver a signed **Attestation** identifying what was returned/destroyed. Where Licensor’s systems emit **anchors/paints/ledgers**, Licensee will reference those identifiers in the Attestation.

## 7. Ownership; Feedback
Licensor retains all right, title, and interest in and to the Software, Service, and Outputs. No implied licenses. Feedback is voluntary; Licensor may use without restriction.

## 8. Non‑Circumvention (optional)
For [NC_TERM] months, Licensee shall not circumvent Licensor to engage directly with partners or customers identified solely via Confidential Information.

## 9. Term; Termination
This Agreement starts on the Effective Date and continues for the **Term** in Schedule A, unless terminated earlier for breach or security risk. Sections 4–8 and 10–14 survive as stated.

## 10. Legal Compliance; Export
Licensee complies with applicable laws, including export controls and sanctions.

## 11. Warranties; Disclaimers
SOFTWARE, SERVICE, AND OUTPUTS ARE PROVIDED **“AS IS.”** LICENSOR DISCLAIMS ALL WARRANTIES, INCLUDING MERCHANTABILITY, FITNESS, NON‑INFRINGEMENT, AND ACCURACY.

## 12. Limitation of Liability
TO THE MAXIMUM EXTENT PERMITTED, LICENSOR WILL NOT BE LIABLE FOR INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR LOST PROFITS/REVENUE/DATA. TOTAL LIABILITY ≤ **US$100**.

## 13. Injunctive Relief
Unauthorized use/disclosure may cause irreparable harm. Licensor is entitled to **injunctive relief** and **specific performance** in addition to other remedies.

## 14. Governing Law; Venue
[STATE LAW] governs (excluding conflicts rules); exclusive venue in [COURTS].

## 15. Entire Agreement; E‑Signatures
This Agreement with Schedule A is the entire agreement for the Purpose. E‑signatures and counterparts are valid.

---

### Schedule A — Permission (Scope/Term/Territory)
- **Scope** (systems/endpoints/repos): _______________________________  
- **Service endpoints** (if any): ____________________________________  
- **Term** (start → end): ____________________________________________  
- **Territory**: _____________________________________________________  
- **Rate limits / data caps**: _______________________________________  
- **Authorized personnel**: __________________________________________  
- **Redistribution**: **No** (default) / Yes (describe)  
- **Benchmarking/Publication**: **No** (default) / Yes (describe)  
- **Model training/tuning from Outputs**: **No** (default) / Yes (describe)  
- **Anchors/ledger binding** (optional): ______________________________
- **Key thumbprint (JWS kid or cert)** (optional): ____________________

**Signatures**  
Licensor (Nick): __________________  Date: _______  
Licensee ([COUNTERPARTY]): ________  Date: _______

---

### Annex 1 — JWS Permission Token (Optional)
Licensor may also issue a signed JWS “Permission Token” that mirrors Schedule A for automated enforcement.

**Header (example)**:  
{"alg":"EdDSA","kid":"nick-key-2025-09"}

**Payload (example)**:  
{"iss":"Nick","sub":"[COUNTERPARTY]","scope":"eval-only","endpoints":["/octet/*","/channel/*"],"term_end":"2030-01-01","anchors":["..."],"jti":"perm-001","iat":1694822400}

**Signature**: base64url signature over header.payload.

Servers may require a valid JWS in addition to a signed Schedule A.
