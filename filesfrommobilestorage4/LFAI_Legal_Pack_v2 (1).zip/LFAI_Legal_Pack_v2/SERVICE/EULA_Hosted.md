# Hosted Service Evaluation Terms (EULA-Hosted)
Use is evaluation-only; no production or third-party reliance; outputs are confidential; same restrictions as EAMUA.
Accounts are personal; MFA required. We may suspend for breach or security risk.
