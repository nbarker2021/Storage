# Repository Policy — LFAI (Strict)
- License: **LFAI Restricted Source License v1.1** (permission-only).  
- Default Use: **prohibited** without a signed Permission (EAMUA Schedule A or Permission Notice).  
- Prohibited by default: redistribution, production/commercial use, training/tuning/benchmarking, publication, reverse‑engineering/circumvention, derivatives.
- Include the SPDX identifier at the top of each source file:
  `SPDX-License-Identifier: LicenseRef-LFAI-Restricted-1.1`
- All external access must flow through signed **EAMUA** + (optional) **JWS Permission Token**.
