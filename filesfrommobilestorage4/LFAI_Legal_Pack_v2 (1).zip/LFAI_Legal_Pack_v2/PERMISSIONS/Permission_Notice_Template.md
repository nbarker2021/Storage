# Permission Notice (for LFAI Restricted Source License v1.1)
Licensor: Nick
Grantee: _________________________
Scope (systems/endpoints/repos): _________________________
Term (start → end): _________________________
Territory: _________________________
Redistribution: No (default) / Yes (describe)
Benchmarking/Publication: No (default) / Yes (describe)
Model training/tuning from Outputs: No (default) / Yes (describe)
Anchors/ledger binding (optional): _________________________
Key thumbprint (JWS kid or cert) (optional): _________________________
Signatures:
Licensor: __________ Date: ____ | Grantee: __________ Date: ____
