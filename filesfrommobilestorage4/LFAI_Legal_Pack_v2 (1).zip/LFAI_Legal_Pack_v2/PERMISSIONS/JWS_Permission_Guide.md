# JWS Permission Token — Quick Guide
- Header: {"alg":"EdDSA","kid":"nick-key-YYYY-MM"}
- Payload fields: iss, sub, scope, endpoints[], term_end (ISO date), jti, iat (unix), anchors[] (optional)
- Signature: base64url(header).base64url(payload).base64url(sig)
- Server: require a valid JWS for API calls; compare `sub` to tenant/grantee; enforce scope/endpoints/term.
