# Contributor License & Assignment Agreement (CLA-A)
By contributing, you **assign** to Nick all right, title, and interest in your contribution (including patents, copyrights, and trade secrets).
You represent you have the right to make this assignment; contributions are original or properly licensed.
You grant Nick the right to relicense, commercialize, and enforce contributions. No compensation is due.
If your employer has rights, you represent you have their permission or will secure it before contributing.
Sign: __________________  Date: ______  Name: __________  Email: __________
