
"""MDHG kernel builder: manifest + bundle with digest (stub)."""
import json, time, hashlib
from typing import Dict, Any
def build_kernel(payload: Dict[str, Any]) -> Dict[str, Any]:
    manifest = {"created": int(time.time()*1000), "items": list(payload.keys())}
    bundle = {"objects": payload}
    digest = hashlib.blake2s(json.dumps(manifest, sort_keys=True).encode(), digest_size=8).hexdigest()
    return {"manifest": manifest, "bundle": bundle, "digest": digest}
