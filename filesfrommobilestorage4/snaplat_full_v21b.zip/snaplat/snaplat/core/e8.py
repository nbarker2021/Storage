
"""E8 lattice helpers with contracts and invariants (reference stubs)."""
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class E8Point:
    coords: Tuple[float, ...]

def nearest_cell(v: E8Point) -> str:
    rounded = tuple(int(round(x)) for x in v.coords[:8])
    return "cell:" + ",".join(map(str, rounded))

def neighbors(cell_id: str) -> List[str]:
    return [f"{cell_id}:n{i}" for i in range(240)]

def reflect(point: E8Point) -> E8Point:
    return E8Point(coords=tuple(-x for x in point.coords))

def coxeter_project(point: E8Point) -> Tuple[float,float]:
    xs = point.coords[:8]
    return (sum(xs[::2]), sum(xs[1::2]))
