
_REG = {}
def register_expertise(sid: str, exploratory: bool = True):
    _REG[sid] = {"exploratory": exploratory, "canonical": False, "evidence": None}
def validate(sid: str, evidence: dict):
    if sid not in _REG: register_expertise(sid, exploratory=True)
    _REG[sid]["canonical"] = True; _REG[sid]["exploratory"] = False; _REG[sid]["evidence"] = evidence; return _REG[sid]
def demote(sid: str, reason: str):
    if sid in _REG:
        _REG[sid]["canonical"] = False; _REG[sid]["exploratory"] = True; _REG[sid]["reason"] = reason; return _REG[sid]
    return None
def status(sid: str): return _REG.get(sid, {})
