
_CATALOG = {"best":[], "worst":[], "failures":[], "mannequins":[]}
def add_best(entry): _CATALOG["best"].append(entry)
def add_worst(entry): _CATALOG["worst"].append(entry)
def add_failure(entry): _CATALOG["failures"].append(entry)
def add_mannequin(entry): _CATALOG["mannequins"].append(entry)
def stats(): return {k: len(v) for k,v in _CATALOG.items()}
