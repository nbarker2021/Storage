
def escalate(decision: dict, level: str = "global") -> dict:
    decision["sap_level"] = level; decision["approved"] = True; return decision
