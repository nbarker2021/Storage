
_INDEX = {}
def register(sid: str, meta: dict):
    _INDEX[sid] = meta; return sid
def resolve(sid: str):
    return _INDEX.get(sid, {})
def all_ids(): return list(_INDEX.keys())
