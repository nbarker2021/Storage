
import typer, json, os
from .registry.schema_registry import add_schema, show, validate_instance
from .governance.gate_runner import run_faces, trait_lanes, composite_lane
from .governance.beacons import set_beacon, override as beacon_override, snapshot as beacon_snapshot
from .governance.precedence import order as precedence_order
from .core.naming import encode_name, decode_name
from .agents.center import onboard as a_onboard, assign as a_assign, training_gap as a_gap, deploy as a_deploy, feedback as a_feedback
from .failure.catalog import add as f_add, query as f_query, rollup as f_roll
from .repo.router import RepoRouter
from .governance.queue import tail as gov_tail, approve as gov_approve
from .repo.restore import restore_kernel
from .rag.report import index as r_index, generate_report as r_report
from .metrics.roc import resource_negative_score

app = typer.Typer(help="SNAPLAT v21b CLI")

@app.command("schema")
def schema_cmd(action: str, path_or_type: str):
    if action == "add": typer.echo({"added": add_schema(path_or_type).get("type_id")})
    elif action == "show": typer.echo(show(path_or_type))
    else: raise typer.Exit(code=1)

@app.command("validate")
def validate_cmd(type_id: str, instance_json: str):
    typer.echo(validate_instance(type_id, json.loads(instance_json)))

@app.command("gate")
def gate_cmd(faces: str = typer.Option("{}", "--faces")):
    typer.echo(run_faces(json.loads(faces)))

@app.command("traits")
def traits_cmd(faces_map: str = typer.Option("{}", "--faces-map")):
    fmap = json.loads(faces_map); lanes = trait_lanes(fmap); comp = composite_lane(lanes)
    typer.echo({"trait_lanes": lanes, "composite": comp})

@app.command("beacon")
def beacon_cmd(action: str, name: str, weight: float = 1.0, lam: float = 0.001, approver: str = "sap"):
    if action == "set": typer.echo(set_beacon(name, weight, lam))
    elif action == "override": typer.echo(beacon_override(name, weight, approver))
    elif action == "snapshot": typer.echo(beacon_snapshot())
    else: raise typer.Exit(code=1)

@app.command("precedence")
def precedence_cmd(mode: str = "operational"):
    typer.echo({"order": precedence_order(mode)})

@app.command("name")
def name_cmd(action: str, domain: str = "", family: str = "", subtype: str = "", seeds: str = "{}", context: str = "{}", v: int = 1, name: str = ""):
    if action == "encode":
        typer.echo(encode_name(domain, family, subtype, json.loads(seeds), json.loads(context), v))
    elif action == "decode":
        typer.echo(decode_name(name))
    else: raise typer.Exit(code=1)

@app.command("agent")
def agent_cmd(action: str, blueprint: str = "", faces: str = "{}", agent_id: str = "", task_sid: str = "", seeds: str = "{}", report_path: str = ""):
    if action == "onboard":
        typer.echo(a_onboard(blueprint, faces=json.loads(faces)))
    elif action == "assign":
        typer.echo(a_assign(agent_id, task_sid, json.loads(seeds)))
    elif action == "gap"):
        typer.echo(a_gap(agent_id, json.loads(seeds).get("skills", [])))
    elif action == "deploy":
        typer.echo(a_deploy(task_sid))
    elif action == "feedback"):
        rpt = {}
        if report_path and os.path.exists(report_path):
            with open(report_path) as f: rpt = json.load(f)
        typer.echo(a_feedback(task_sid, rpt))
    else:
        raise typer.Exit(code=1)

@app.command("failure")
def failure_cmd(action: str, where: str = "{}", by: str = ""):
    if action == "add": typer.echo(f_add(json.loads(where)))
    elif action == "query": typer.echo(f_query(json.loads(where)))
    elif action == "rollup": typer.echo(f_roll(by))
    else: raise typer.Exit(code=1)

@app.command("deep")
def deep_cmd(action: str, key: str, json_path: str = "", actor: str = "ops"):
    rr = RepoRouter()
    if action == "put":
        obj = {}; 
        if json_path and os.path.exists(json_path):
            with open(json_path) as f: obj = json.load(f)
        typer.echo(rr.deep_put(key, obj, actor))
    elif action == "get":
        typer.echo(rr.deep_get(key))
    elif action == "queue":
        for item in gov_tail(): typer.echo(item)
    elif action == "approve":
        typer.echo(gov_approve(key, approver=actor))
    elif action == "restore":
        typer.echo(restore_kernel(key, {"tick_rate_hz":5.0,"compression":"adaptive","safety":"balanced"}))
    else: raise typer.Exit(code=1)

@app.command("rag")
def rag_cmd(action: str, doc_id: str = "", path: str = "", prompt: str = ""):
    if action == "index":
        with open(path) as f: txt = f.read()
        r_index(doc_id, txt); typer.echo({"indexed": doc_id})
    elif action == "report":
        typer.echo(r_report(prompt))
    else: raise typer.Exit(code=1)

@app.command("metrics")
def metrics_cmd(recalled: int, computed: int, threshold: float = 0.6):
    typer.echo(resource_negative_score(recalled, computed, threshold))

if __name__ == "__main__":
    app()
