
# Morphonic Chainstack (Node + Knots + Solo Pool + Stratum V2 + Miner)

This compose stack spins up:
- **bitcoind** (Bitcoin Core) for canonical RPC and P2P
- **bitcoin-knots** (alternate client) for diversity
- **ckpool** for **solo** Stratum v1 mining (miners connect to port 3333)
- **stratumv2** server (SRI) for modern pool protocol research (port 3334)
- **morphonic-miner** sidecar (receipts-first background miner)

## Usage

1) Install Docker & docker-compose.
2) Export env creds:
```
export BTC_RPC_USER=rpcuser
export BTC_RPC_PASS=rpcpass
export PAYOUT_SCRIPT_HEX=76a914000000000000000000000000000000000000000088ac
```
3) Bring it up:
```
docker compose up -d --build
docker compose logs -f
```
- point ASICs or software miners to `stratum+tcp://<host>:3333` (CKPool solo)
- Stratum V2 server listens on `:3334` (adjust entrypoint flags as needed)

## Notes
- CKPool will build from source; if the upstream moves, update the Dockerfile repo URL.
- The Stratum V2 server entrypoint may require flags matching your topology; see the SRI docs.
- The morphonic-miner container auto-detects your SpeedLight and transformer if baked in.
