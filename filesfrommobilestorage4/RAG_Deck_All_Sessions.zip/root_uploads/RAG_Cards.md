# RAG Cards — Session 'root_uploads'

## root_uploads::RAG-00001 — LICENSE
- Token: `D0002` | Type: `generic` | pal64 step: 1 | receipt: `0000`
- Tags: generic
- Connections: D0008(adjacent-order)
- Summary: GENERIC 'LICENSE'. Ordered at pal64 step 1. Preview: LICENSE (generic)

## root_uploads::RAG-00002 — glyphs.py
- Token: `D0008` | Type: `generic` | pal64 step: 2 | receipt: `0000`
- Tags: generic
- Connections: D0002(adjacent-order), D0011(adjacent-order)
- Summary: GENERIC 'glyphs.py'. Ordered at pal64 step 2. Preview: glyphs.py (generic)

## root_uploads::RAG-00003 — sim.py
- Token: `D0011` | Type: `generic` | pal64 step: 3 | receipt: `0000`
- Tags: generic
- Connections: D0008(adjacent-order), D0004(adjacent-order)
- Summary: GENERIC 'sim.py'. Ordered at pal64 step 3. Preview: sim.py (generic)

## root_uploads::RAG-00004 — __init__.py
- Token: `D0004` | Type: `generic` | pal64 step: 4 | receipt: `0000`
- Tags: generic
- Connections: D0011(adjacent-order), D0031(adjacent-order)
- Summary: GENERIC '__init__.py'. Ordered at pal64 step 4. Preview: __init__.py (generic)

## root_uploads::RAG-00005 — run_harness.py
- Token: `D0031` | Type: `generic` | pal64 step: 5 | receipt: `0000`
- Tags: generic
- Connections: D0004(adjacent-order), D0009(adjacent-order)
- Summary: GENERIC 'run_harness.py'. Ordered at pal64 step 5. Preview: run_harness.py (generic)

## root_uploads::RAG-00006 — ledger.py
- Token: `D0009` | Type: `generic` | pal64 step: 6 | receipt: `0000`
- Tags: generic
- Connections: D0031(adjacent-order), D0033(adjacent-order)
- Summary: GENERIC 'ledger.py'. Ordered at pal64 step 6. Preview: ledger.py (generic)

## root_uploads::RAG-00007 — test_glyphs.py
- Token: `D0033` | Type: `generic` | pal64 step: 7 | receipt: `0000`
- Tags: generic
- Connections: D0009(adjacent-order), D0012(adjacent-order)
- Summary: GENERIC 'test_glyphs.py'. Ordered at pal64 step 7. Preview: test_glyphs.py (generic)

## root_uploads::RAG-00008 — utils.py
- Token: `D0012` | Type: `generic` | pal64 step: 8 | receipt: `0000`
- Tags: generic
- Connections: D0033(adjacent-order), D0005(adjacent-order)
- Summary: GENERIC 'utils.py'. Ordered at pal64 step 8. Preview: utils.py (generic)

## root_uploads::RAG-00009 — carriers.py
- Token: `D0005` | Type: `generic` | pal64 step: 9 | receipt: `0000`
- Tags: generic
- Connections: D0012(adjacent-order), D0010(adjacent-order)
- Summary: GENERIC 'carriers.py'. Ordered at pal64 step 9. Preview: carriers.py (generic)

## root_uploads::RAG-00010 — receipts.py
- Token: `D0010` | Type: `generic` | pal64 step: 10 | receipt: `0000`
- Tags: generic
- Connections: D0005(adjacent-order), D0006(adjacent-order)
- Summary: GENERIC 'receipts.py'. Ordered at pal64 step 10. Preview: receipts.py (generic)

## root_uploads::RAG-00011 — color_paint.py
- Token: `D0006` | Type: `generic` | pal64 step: 11 | receipt: `0000`
- Tags: generic
- Connections: D0010(adjacent-order), D0007(adjacent-order)
- Summary: GENERIC 'color_paint.py'. Ordered at pal64 step 11. Preview: color_paint.py (generic)

## root_uploads::RAG-00012 — deck_calculus.py
- Token: `D0007` | Type: `generic` | pal64 step: 12 | receipt: `0000`
- Tags: generic
- Connections: D0006(adjacent-order), D0032(adjacent-order)
- Summary: GENERIC 'deck_calculus.py'. Ordered at pal64 step 12. Preview: deck_calculus.py (generic)

## root_uploads::RAG-00013 — pyproject.toml
- Token: `D0032` | Type: `generic` | pal64 step: 13 | receipt: `0000`
- Tags: generic
- Connections: D0007(adjacent-order), D0017(adjacent-order)
- Summary: GENERIC 'pyproject.toml'. Ordered at pal64 step 13. Preview: pyproject.toml (generic)

## root_uploads::RAG-00014 — roadmap.md
- Token: `D0017` | Type: `text` | pal64 step: 14 | receipt: `0000`
- Tags: roadmap
- Connections: D0032(adjacent-order), D0016(adjacent-order)
- Summary: TEXT 'roadmap.md'. Ordered at pal64 step 14. Preview: # Roadmap

## root_uploads::RAG-00015 — receipts.md
- Token: `D0016` | Type: `text` | pal64 step: 15 | receipt: `0000`
- Tags: receipts
- Connections: D0017(adjacent-order), D0014(adjacent-order)
- Summary: TEXT 'receipts.md'. Ordered at pal64 step 15. Preview: # Receipts

## root_uploads::RAG-00016 — architecture.md
- Token: `D0014` | Type: `text` | pal64 step: 16 | receipt: `0000`
- Tags: architecture
- Connections: D0016(adjacent-order), D0018(adjacent-order)
- Summary: TEXT 'architecture.md'. Ordered at pal64 step 16. Preview: # Architecture

## root_uploads::RAG-00017 — sidecars.md
- Token: `D0018` | Type: `text` | pal64 step: 17 | receipt: `0000`
- Tags: sidecars
- Connections: D0014(adjacent-order), D0015(adjacent-order)
- Summary: TEXT 'sidecars.md'. Ordered at pal64 step 17. Preview: # Sidecars

## root_uploads::RAG-00018 — deck_calculus.md
- Token: `D0015` | Type: `text` | pal64 step: 18 | receipt: `0000`
- Tags: calculus, deck
- Connections: D0018(adjacent-order), D0013(adjacent-order)
- Summary: TEXT 'deck_calculus.md'. Ordered at pal64 step 18. Preview: # Deck Calculus

## root_uploads::RAG-00019 — CHANGELOG.md
- Token: `D0013` | Type: `text` | pal64 step: 19 | receipt: `0000`
- Tags: initial, skeleton
- Connections: D0015(adjacent-order), D0001(adjacent-order)
- Summary: TEXT 'CHANGELOG.md'. Ordered at pal64 step 19. Preview: ## 0.1.0

## root_uploads::RAG-00020 — Frontpage.md
- Token: `D0001` | Type: `text` | pal64 step: 20 | receipt: `0000`
- Tags: cqe, details, readme, see, unified
- Connections: D0013(adjacent-order), D0026(adjacent-order)
- Summary: TEXT 'Frontpage.md'. Ordered at pal64 step 20. Preview: # CQE‑Unified

## root_uploads::RAG-00021 — why06_sidecars.json
- Token: `D0026` | Type: `text` | pal64 step: 21 | receipt: `0000`
- Tags: sidecars, false, force, label, metric, override, prev
- Connections: D0001(adjacent-order), D0023(adjacent-order)
- Summary: TEXT 'why06_sidecars.json'. Ordered at pal64 step 21. Preview: {

## root_uploads::RAG-00022 — why03_octet_parity.json
- Token: `D0023` | Type: `text` | pal64 step: 22 | receipt: `0000`
- Tags: octet, parity, false, force, label, metric, override
- Connections: D0026(adjacent-order), D0076(adjacent-order)
- Summary: TEXT 'why03_octet_parity.json'. Ordered at pal64 step 22. Preview: {

## root_uploads::RAG-00023 — Papers explained _250919_230503.txt
- Token: `D0076` | Type: `text` | pal64 step: 23 | receipt: `0000`
- Tags: quantum, significance, can, brain, could, breakthrough, new
- Connections: D0023(adjacent-order), D0025(adjacent-order)
- Summary: TEXT 'Papers explained _250919_230503.txt'. Ordered at pal64 step 23. Preview: Recent Breakthroughs in Science and Technology

## root_uploads::RAG-00024 — why05_receipts_commit.json
- Token: `D0025` | Type: `text` | pal64 step: 24 | receipt: `0000`
- Tags: commit, receipts, force, label, metric, override, prev
- Connections: D0076(adjacent-order), D0028(adjacent-order)
- Summary: TEXT 'why05_receipts_commit.json'. Ordered at pal64 step 24. Preview: {

## root_uploads::RAG-00025 — why08_collision_alias.json
- Token: `D0028` | Type: `text` | pal64 step: 25 | receipt: `0000`
- Tags: alias, collision, false, force, label, metric, override
- Connections: D0025(adjacent-order), D0030(adjacent-order)
- Summary: TEXT 'why08_collision_alias.json'. Ordered at pal64 step 25. Preview: {

## root_uploads::RAG-00026 — why10_privacy_policy.json
- Token: `D0030` | Type: `text` | pal64 step: 26 | receipt: `0000`
- Tags: policy, privacy, false, force, label, metric, override
- Connections: D0028(adjacent-order), D0029(adjacent-order)
- Summary: TEXT 'why10_privacy_policy.json'. Ordered at pal64 step 26. Preview: {

## root_uploads::RAG-00027 — why09_cache_replay.json
- Token: `D0029` | Type: `text` | pal64 step: 27 | receipt: `0000`
- Tags: cache, replay, false, force, label, metric, override
- Connections: D0030(adjacent-order), D0024(adjacent-order)
- Summary: TEXT 'why09_cache_replay.json'. Ordered at pal64 step 27. Preview: {

## root_uploads::RAG-00028 — why04_palindromic_rest.json
- Token: `D0024` | Type: `text` | pal64 step: 28 | receipt: `0000`
- Tags: palindromic, rest, false, force, label, metric, override
- Connections: D0029(adjacent-order), D0022(adjacent-order)
- Summary: TEXT 'why04_palindromic_rest.json'. Ordered at pal64 step 28. Preview: {

## root_uploads::RAG-00029 — why02_glyph_supremacy.json
- Token: `D0022` | Type: `text` | pal64 step: 29 | receipt: `0000`
- Tags: glyph, supremacy, force, label, metric, override, prev
- Connections: D0024(adjacent-order), D0021(adjacent-order)
- Summary: TEXT 'why02_glyph_supremacy.json'. Ordered at pal64 step 29. Preview: {

## root_uploads::RAG-00030 — why01_foundations.json
- Token: `D0021` | Type: `text` | pal64 step: 30 | receipt: `0000`
- Tags: foundations, false, force, label, mapping, metric, override
- Connections: D0022(adjacent-order), D0003(adjacent-order)
- Summary: TEXT 'why01_foundations.json'. Ordered at pal64 step 30. Preview: {

## root_uploads::RAG-00031 — README.md
- Token: `D0003` | Type: `text` | pal64 step: 31 | receipt: `0000`
- Tags: harness, cqe, python, quick, repository, run, start
- Connections: D0021(adjacent-order), D0027(adjacent-order)
- Summary: TEXT 'README.md'. Ordered at pal64 step 31. Preview: # CQE‑Unified Repository

## root_uploads::RAG-00032 — why07_corridors.json
- Token: `D0027` | Type: `text` | pal64 step: 32 | receipt: `0000`
- Tags: corridors, false, force, label, metric, override, prev
- Connections: D0003(adjacent-order), D0068(adjacent-order)
- Summary: TEXT 'why07_corridors.json'. Ordered at pal64 step 32. Preview: {

## root_uploads::RAG-00033 — Worksheet_01.pdf
- Token: `D0068` | Type: `pdf` | pal64 step: 33 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0027(adjacent-order), D0071(adjacent-order)
- Summary: PDF 'Worksheet_01.pdf'. Ordered at pal64 step 33. Preview: PDF (1 pages)

## root_uploads::RAG-00034 — Worksheet_04.pdf
- Token: `D0071` | Type: `pdf` | pal64 step: 34 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0068(adjacent-order), D0073(adjacent-order)
- Summary: PDF 'Worksheet_04.pdf'. Ordered at pal64 step 34. Preview: PDF (1 pages)

## root_uploads::RAG-00035 — Worksheet_06.pdf
- Token: `D0073` | Type: `pdf` | pal64 step: 35 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0071(adjacent-order), D0072(adjacent-order)
- Summary: PDF 'Worksheet_06.pdf'. Ordered at pal64 step 35. Preview: PDF (1 pages)

## root_uploads::RAG-00036 — Worksheet_05.pdf
- Token: `D0072` | Type: `pdf` | pal64 step: 36 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0073(adjacent-order), D0069(adjacent-order)
- Summary: PDF 'Worksheet_05.pdf'. Ordered at pal64 step 36. Preview: PDF (1 pages)

## root_uploads::RAG-00037 — Worksheet_02.pdf
- Token: `D0069` | Type: `pdf` | pal64 step: 37 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0072(adjacent-order), D0070(adjacent-order)
- Summary: PDF 'Worksheet_02.pdf'. Ordered at pal64 step 37. Preview: PDF (1 pages)

## root_uploads::RAG-00038 — Worksheet_03.pdf
- Token: `D0070` | Type: `pdf` | pal64 step: 38 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0069(adjacent-order), D0044(adjacent-order)
- Summary: PDF 'Worksheet_03.pdf'. Ordered at pal64 step 38. Preview: PDF (1 pages)

## root_uploads::RAG-00039 — 09_Hypercube_Scaffold.pdf
- Token: `D0044` | Type: `pdf` | pal64 step: 39 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0070(adjacent-order), D0035(adjacent-order)
- Summary: PDF '09_Hypercube_Scaffold.pdf'. Ordered at pal64 step 39. Preview: PDF (1 pages)

## root_uploads::RAG-00040 — 00_Cover.pdf
- Token: `D0035` | Type: `pdf` | pal64 step: 40 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0044(adjacent-order), D0048(adjacent-order)
- Summary: PDF '00_Cover.pdf'. Ordered at pal64 step 40. Preview: PDF (1 pages)

## root_uploads::RAG-00041 — 13_Class_Checklist.pdf
- Token: `D0048` | Type: `pdf` | pal64 step: 41 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0035(adjacent-order), D0059(adjacent-order)
- Summary: PDF '13_Class_Checklist.pdf'. Ordered at pal64 step 41. Preview: PDF (1 pages)

## root_uploads::RAG-00042 — Scene_07.pdf
- Token: `D0059` | Type: `pdf` | pal64 step: 42 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0048(adjacent-order), D0066(adjacent-order)
- Summary: PDF 'Scene_07.pdf'. Ordered at pal64 step 42. Preview: PDF (1 pages)

## root_uploads::RAG-00043 — Scene_14.pdf
- Token: `D0066` | Type: `pdf` | pal64 step: 43 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0059(adjacent-order), D0043(adjacent-order)
- Summary: PDF 'Scene_14.pdf'. Ordered at pal64 step 43. Preview: PDF (1 pages)

## root_uploads::RAG-00044 — 08_Master_Ledger.pdf
- Token: `D0043` | Type: `pdf` | pal64 step: 44 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0066(adjacent-order), D0065(adjacent-order)
- Summary: PDF '08_Master_Ledger.pdf'. Ordered at pal64 step 44. Preview: PDF (1 pages)

## root_uploads::RAG-00045 — Scene_13.pdf
- Token: `D0065` | Type: `pdf` | pal64 step: 45 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0043(adjacent-order), D0036(adjacent-order)
- Summary: PDF 'Scene_13.pdf'. Ordered at pal64 step 45. Preview: PDF (1 pages)

## root_uploads::RAG-00046 — 01_QuickStart.pdf
- Token: `D0036` | Type: `pdf` | pal64 step: 46 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0065(adjacent-order), D0046(adjacent-order)
- Summary: PDF '01_QuickStart.pdf'. Ordered at pal64 step 46. Preview: PDF (1 pages)

## root_uploads::RAG-00047 — 11_Blank_Cards.pdf
- Token: `D0046` | Type: `pdf` | pal64 step: 47 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0036(adjacent-order), D0057(adjacent-order)
- Summary: PDF '11_Blank_Cards.pdf'. Ordered at pal64 step 47. Preview: PDF (1 pages)

## root_uploads::RAG-00048 — Scene_05.pdf
- Token: `D0057` | Type: `pdf` | pal64 step: 48 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0046(adjacent-order), D0064(adjacent-order)
- Summary: PDF 'Scene_05.pdf'. Ordered at pal64 step 48. Preview: PDF (1 pages)

## root_uploads::RAG-00049 — Scene_12.pdf
- Token: `D0064` | Type: `pdf` | pal64 step: 49 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0057(adjacent-order), D0055(adjacent-order)
- Summary: PDF 'Scene_12.pdf'. Ordered at pal64 step 49. Preview: PDF (1 pages)

## root_uploads::RAG-00050 — Scene_03.pdf
- Token: `D0055` | Type: `pdf` | pal64 step: 50 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0064(adjacent-order), D0058(adjacent-order)
- Summary: PDF 'Scene_03.pdf'. Ordered at pal64 step 50. Preview: PDF (1 pages)

## root_uploads::RAG-00051 — Scene_06.pdf
- Token: `D0058` | Type: `pdf` | pal64 step: 51 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0055(adjacent-order), D0063(adjacent-order)
- Summary: PDF 'Scene_06.pdf'. Ordered at pal64 step 51. Preview: PDF (1 pages)

## root_uploads::RAG-00052 — Scene_11.pdf
- Token: `D0063` | Type: `pdf` | pal64 step: 52 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0058(adjacent-order), D0062(adjacent-order)
- Summary: PDF 'Scene_11.pdf'. Ordered at pal64 step 52. Preview: PDF (1 pages)

## root_uploads::RAG-00053 — Scene_10.pdf
- Token: `D0062` | Type: `pdf` | pal64 step: 53 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0063(adjacent-order), D0067(adjacent-order)
- Summary: PDF 'Scene_10.pdf'. Ordered at pal64 step 53. Preview: PDF (1 pages)

## root_uploads::RAG-00054 — Scene_15.pdf
- Token: `D0067` | Type: `pdf` | pal64 step: 54 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0062(adjacent-order), D0061(adjacent-order)
- Summary: PDF 'Scene_15.pdf'. Ordered at pal64 step 54. Preview: PDF (1 pages)

## root_uploads::RAG-00055 — Scene_09.pdf
- Token: `D0061` | Type: `pdf` | pal64 step: 55 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0067(adjacent-order), D0056(adjacent-order)
- Summary: PDF 'Scene_09.pdf'. Ordered at pal64 step 55. Preview: PDF (1 pages)

## root_uploads::RAG-00056 — Scene_04.pdf
- Token: `D0056` | Type: `pdf` | pal64 step: 56 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0061(adjacent-order), D0060(adjacent-order)
- Summary: PDF 'Scene_04.pdf'. Ordered at pal64 step 56. Preview: PDF (1 pages)

## root_uploads::RAG-00057 — Scene_08.pdf
- Token: `D0060` | Type: `pdf` | pal64 step: 57 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0056(adjacent-order), D0042(adjacent-order)
- Summary: PDF 'Scene_08.pdf'. Ordered at pal64 step 57. Preview: PDF (1 pages)

## root_uploads::RAG-00058 — 07_Theorem_Cards.pdf
- Token: `D0042` | Type: `pdf` | pal64 step: 58 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0060(adjacent-order), D0054(adjacent-order)
- Summary: PDF '07_Theorem_Cards.pdf'. Ordered at pal64 step 58. Preview: PDF (1 pages)

## root_uploads::RAG-00059 — Scene_02.pdf
- Token: `D0054` | Type: `pdf` | pal64 step: 59 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0042(adjacent-order), D0037(adjacent-order)
- Summary: PDF 'Scene_02.pdf'. Ordered at pal64 step 59. Preview: PDF (1 pages)

## root_uploads::RAG-00060 — 02_Octet_DNA10.pdf
- Token: `D0037` | Type: `pdf` | pal64 step: 60 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0054(adjacent-order), D0053(adjacent-order)
- Summary: PDF '02_Octet_DNA10.pdf'. Ordered at pal64 step 60. Preview: PDF (1 pages)

## root_uploads::RAG-00061 — Scene_01.pdf
- Token: `D0053` | Type: `pdf` | pal64 step: 61 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0037(adjacent-order), D0040(adjacent-order)
- Summary: PDF 'Scene_01.pdf'. Ordered at pal64 step 61. Preview: PDF (1 pages)

## root_uploads::RAG-00062 — 05_Stations.pdf
- Token: `D0040` | Type: `pdf` | pal64 step: 62 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0053(adjacent-order), D0052(adjacent-order)
- Summary: PDF '05_Stations.pdf'. Ordered at pal64 step 62. Preview: PDF (1 pages)

## root_uploads::RAG-00063 — Scene_00.pdf
- Token: `D0052` | Type: `pdf` | pal64 step: 63 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0040(adjacent-order), D0041(adjacent-order)
- Summary: PDF 'Scene_00.pdf'. Ordered at pal64 step 63. Preview: PDF (1 pages)

## root_uploads::RAG-00064 — 06_Table_Playbook.pdf
- Token: `D0041` | Type: `pdf` | pal64 step: 64 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0052(adjacent-order), D0047(adjacent-order)
- Summary: PDF '06_Table_Playbook.pdf'. Ordered at pal64 step 64. Preview: PDF (1 pages)

## root_uploads::RAG-00065 — 12_Baseline_Packs.pdf
- Token: `D0047` | Type: `pdf` | pal64 step: 1 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0041(adjacent-order), D0050(adjacent-order)
- Summary: PDF '12_Baseline_Packs.pdf'. Ordered at pal64 step 1. Preview: PDF (1 pages)

## root_uploads::RAG-00066 — CQE_Ledger_Template.pdf
- Token: `D0050` | Type: `pdf` | pal64 step: 2 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0047(adjacent-order), D0038(adjacent-order)
- Summary: PDF 'CQE_Ledger_Template.pdf'. Ordered at pal64 step 2. Preview: PDF (1 pages)

## root_uploads::RAG-00067 — 03_Receipts_4bit.pdf
- Token: `D0038` | Type: `pdf` | pal64 step: 3 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0050(adjacent-order), D0074(adjacent-order)
- Summary: PDF '03_Receipts_4bit.pdf'. Ordered at pal64 step 3. Preview: PDF (1 pages)

## root_uploads::RAG-00068 — Deck_Calculus_Reader_Card.pdf
- Token: `D0074` | Type: `pdf` | pal64 step: 4 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0038(adjacent-order), D0045(adjacent-order)
- Summary: PDF 'Deck_Calculus_Reader_Card.pdf'. Ordered at pal64 step 4. Preview: PDF (1 pages)

## root_uploads::RAG-00069 — 10_Sticky_Sidecars.pdf
- Token: `D0045` | Type: `pdf` | pal64 step: 5 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0074(adjacent-order), D0039(adjacent-order)
- Summary: PDF '10_Sticky_Sidecars.pdf'. Ordered at pal64 step 5. Preview: PDF (1 pages)

## root_uploads::RAG-00070 — 04_Parity_Loom.pdf
- Token: `D0039` | Type: `pdf` | pal64 step: 6 | receipt: `0000`
- Tags: pdf, pages:1
- Connections: D0045(adjacent-order), D0034(adjacent-order)
- Summary: PDF '04_Parity_Loom.pdf'. Ordered at pal64 step 6. Preview: PDF (1 pages)

## root_uploads::RAG-00071 — CQE_Card_Kit_v1_2_Master.pdf
- Token: `D0034` | Type: `pdf` | pal64 step: 7 | receipt: `0000`
- Tags: pdf, pages:19
- Connections: D0039(adjacent-order), D0019(adjacent-order)
- Summary: PDF 'CQE_Card_Kit_v1_2_Master.pdf'. Ordered at pal64 step 7. Preview: PDF (19 pages)

## root_uploads::RAG-00072 — brainwaves.csv
- Token: `D0019` | Type: `csv` | pal64 step: 8 | receipt: `0000`
- Tags: col:t, col:amp
- Connections: D0034(adjacent-order), D0020(adjacent-order)
- Summary: CSV 'brainwaves.csv'. Ordered at pal64 step 8. Preview: 2 columns (preview header)

## root_uploads::RAG-00073 — sound_spectrum.csv
- Token: `D0020` | Type: `csv` | pal64 step: 9 | receipt: `0000`
- Tags: col:freq_hz, col:power
- Connections: D0019(adjacent-order), D0049(adjacent-order)
- Summary: CSV 'sound_spectrum.csv'. Ordered at pal64 step 9. Preview: 2 columns (preview header)

## root_uploads::RAG-00074 — CQE_Card_Mat.pdf
- Token: `D0049` | Type: `pdf` | pal64 step: 10 | receipt: `0000`
- Tags: pdf, pages:2
- Connections: D0020(adjacent-order), D0051(adjacent-order)
- Summary: PDF 'CQE_Card_Mat.pdf'. Ordered at pal64 step 10. Preview: PDF (2 pages)

## root_uploads::RAG-00075 — CQE_Roleplay_Scenes_v1_0_Master.pdf
- Token: `D0051` | Type: `pdf` | pal64 step: 11 | receipt: `0000`
- Tags: pdf, pages:23
- Connections: D0049(adjacent-order), D0075(adjacent-order)
- Summary: PDF 'CQE_Roleplay_Scenes_v1_0_Master.pdf'. Ordered at pal64 step 11. Preview: PDF (23 pages)

## root_uploads::RAG-00076 — Deck_Calculus_Worked_Examples.pdf
- Token: `D0075` | Type: `pdf` | pal64 step: 12 | receipt: `0000`
- Tags: pdf, pages:3
- Connections: D0051(adjacent-order)
- Summary: PDF 'Deck_Calculus_Worked_Examples.pdf'. Ordered at pal64 step 12. Preview: PDF (3 pages)
