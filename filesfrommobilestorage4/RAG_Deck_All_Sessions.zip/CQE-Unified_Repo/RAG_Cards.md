# RAG Cards — Session 'CQE-Unified_Repo'

## CQE-Unified_Repo::RAG-00001 — LICENSE
- Token: `D0002` | Type: `generic` | pal64 step: 1 | receipt: `0000`
- Tags: generic
- Connections: D0008(adjacent-order)
- Summary: GENERIC 'LICENSE'. Ordered at pal64 step 1. Preview: LICENSE (generic)

## CQE-Unified_Repo::RAG-00002 — glyphs.py
- Token: `D0008` | Type: `generic` | pal64 step: 2 | receipt: `0000`
- Tags: generic
- Connections: D0002(adjacent-order), D0011(adjacent-order)
- Summary: GENERIC 'glyphs.py'. Ordered at pal64 step 2. Preview: glyphs.py (generic)

## CQE-Unified_Repo::RAG-00003 — sim.py
- Token: `D0011` | Type: `generic` | pal64 step: 3 | receipt: `0000`
- Tags: generic
- Connections: D0008(adjacent-order), D0004(adjacent-order)
- Summary: GENERIC 'sim.py'. Ordered at pal64 step 3. Preview: sim.py (generic)

## CQE-Unified_Repo::RAG-00004 — __init__.py
- Token: `D0004` | Type: `generic` | pal64 step: 4 | receipt: `0000`
- Tags: generic
- Connections: D0011(adjacent-order), D0031(adjacent-order)
- Summary: GENERIC '__init__.py'. Ordered at pal64 step 4. Preview: __init__.py (generic)

## CQE-Unified_Repo::RAG-00005 — run_harness.py
- Token: `D0031` | Type: `generic` | pal64 step: 5 | receipt: `0000`
- Tags: generic
- Connections: D0004(adjacent-order), D0009(adjacent-order)
- Summary: GENERIC 'run_harness.py'. Ordered at pal64 step 5. Preview: run_harness.py (generic)

## CQE-Unified_Repo::RAG-00006 — ledger.py
- Token: `D0009` | Type: `generic` | pal64 step: 6 | receipt: `0000`
- Tags: generic
- Connections: D0031(adjacent-order), D0033(adjacent-order)
- Summary: GENERIC 'ledger.py'. Ordered at pal64 step 6. Preview: ledger.py (generic)

## CQE-Unified_Repo::RAG-00007 — test_glyphs.py
- Token: `D0033` | Type: `generic` | pal64 step: 7 | receipt: `0000`
- Tags: generic
- Connections: D0009(adjacent-order), D0012(adjacent-order)
- Summary: GENERIC 'test_glyphs.py'. Ordered at pal64 step 7. Preview: test_glyphs.py (generic)

## CQE-Unified_Repo::RAG-00008 — utils.py
- Token: `D0012` | Type: `generic` | pal64 step: 8 | receipt: `0000`
- Tags: generic
- Connections: D0033(adjacent-order), D0005(adjacent-order)
- Summary: GENERIC 'utils.py'. Ordered at pal64 step 8. Preview: utils.py (generic)

## CQE-Unified_Repo::RAG-00009 — carriers.py
- Token: `D0005` | Type: `generic` | pal64 step: 9 | receipt: `0000`
- Tags: generic
- Connections: D0012(adjacent-order), D0010(adjacent-order)
- Summary: GENERIC 'carriers.py'. Ordered at pal64 step 9. Preview: carriers.py (generic)

## CQE-Unified_Repo::RAG-00010 — receipts.py
- Token: `D0010` | Type: `generic` | pal64 step: 10 | receipt: `0000`
- Tags: generic
- Connections: D0005(adjacent-order), D0006(adjacent-order)
- Summary: GENERIC 'receipts.py'. Ordered at pal64 step 10. Preview: receipts.py (generic)

## CQE-Unified_Repo::RAG-00011 — color_paint.py
- Token: `D0006` | Type: `generic` | pal64 step: 11 | receipt: `0000`
- Tags: generic
- Connections: D0010(adjacent-order), D0007(adjacent-order)
- Summary: GENERIC 'color_paint.py'. Ordered at pal64 step 11. Preview: color_paint.py (generic)

## CQE-Unified_Repo::RAG-00012 — deck_calculus.py
- Token: `D0007` | Type: `generic` | pal64 step: 12 | receipt: `0000`
- Tags: generic
- Connections: D0006(adjacent-order), D0032(adjacent-order)
- Summary: GENERIC 'deck_calculus.py'. Ordered at pal64 step 12. Preview: deck_calculus.py (generic)

## CQE-Unified_Repo::RAG-00013 — pyproject.toml
- Token: `D0032` | Type: `generic` | pal64 step: 13 | receipt: `0000`
- Tags: generic
- Connections: D0007(adjacent-order), D0017(adjacent-order)
- Summary: GENERIC 'pyproject.toml'. Ordered at pal64 step 13. Preview: pyproject.toml (generic)

## CQE-Unified_Repo::RAG-00014 — roadmap.md
- Token: `D0017` | Type: `text` | pal64 step: 14 | receipt: `0000`
- Tags: roadmap
- Connections: D0032(adjacent-order), D0016(adjacent-order)
- Summary: TEXT 'roadmap.md'. Ordered at pal64 step 14. Preview: # Roadmap

## CQE-Unified_Repo::RAG-00015 — receipts.md
- Token: `D0016` | Type: `text` | pal64 step: 15 | receipt: `0000`
- Tags: receipts
- Connections: D0017(adjacent-order), D0014(adjacent-order)
- Summary: TEXT 'receipts.md'. Ordered at pal64 step 15. Preview: # Receipts

## CQE-Unified_Repo::RAG-00016 — architecture.md
- Token: `D0014` | Type: `text` | pal64 step: 16 | receipt: `0000`
- Tags: architecture
- Connections: D0016(adjacent-order), D0018(adjacent-order)
- Summary: TEXT 'architecture.md'. Ordered at pal64 step 16. Preview: # Architecture

## CQE-Unified_Repo::RAG-00017 — sidecars.md
- Token: `D0018` | Type: `text` | pal64 step: 17 | receipt: `0000`
- Tags: sidecars
- Connections: D0014(adjacent-order), D0015(adjacent-order)
- Summary: TEXT 'sidecars.md'. Ordered at pal64 step 17. Preview: # Sidecars

## CQE-Unified_Repo::RAG-00018 — deck_calculus.md
- Token: `D0015` | Type: `text` | pal64 step: 18 | receipt: `0000`
- Tags: calculus, deck
- Connections: D0018(adjacent-order), D0013(adjacent-order)
- Summary: TEXT 'deck_calculus.md'. Ordered at pal64 step 18. Preview: # Deck Calculus

## CQE-Unified_Repo::RAG-00019 — CHANGELOG.md
- Token: `D0013` | Type: `text` | pal64 step: 19 | receipt: `0000`
- Tags: initial, skeleton
- Connections: D0015(adjacent-order), D0001(adjacent-order)
- Summary: TEXT 'CHANGELOG.md'. Ordered at pal64 step 19. Preview: ## 0.1.0

## CQE-Unified_Repo::RAG-00020 — Frontpage.md
- Token: `D0001` | Type: `text` | pal64 step: 20 | receipt: `0000`
- Tags: cqe, details, readme, see, unified
- Connections: D0013(adjacent-order), D0026(adjacent-order)
- Summary: TEXT 'Frontpage.md'. Ordered at pal64 step 20. Preview: # CQE‑Unified

## CQE-Unified_Repo::RAG-00021 — why06_sidecars.json
- Token: `D0026` | Type: `text` | pal64 step: 21 | receipt: `0000`
- Tags: sidecars, false, force, label, metric, override, prev
- Connections: D0001(adjacent-order), D0023(adjacent-order)
- Summary: TEXT 'why06_sidecars.json'. Ordered at pal64 step 21. Preview: {

## CQE-Unified_Repo::RAG-00022 — why03_octet_parity.json
- Token: `D0023` | Type: `text` | pal64 step: 22 | receipt: `0000`
- Tags: octet, parity, false, force, label, metric, override
- Connections: D0026(adjacent-order), D0025(adjacent-order)
- Summary: TEXT 'why03_octet_parity.json'. Ordered at pal64 step 22. Preview: {

## CQE-Unified_Repo::RAG-00023 — why05_receipts_commit.json
- Token: `D0025` | Type: `text` | pal64 step: 23 | receipt: `0000`
- Tags: commit, receipts, force, label, metric, override, prev
- Connections: D0023(adjacent-order), D0028(adjacent-order)
- Summary: TEXT 'why05_receipts_commit.json'. Ordered at pal64 step 23. Preview: {

## CQE-Unified_Repo::RAG-00024 — why08_collision_alias.json
- Token: `D0028` | Type: `text` | pal64 step: 24 | receipt: `0000`
- Tags: alias, collision, false, force, label, metric, override
- Connections: D0025(adjacent-order), D0030(adjacent-order)
- Summary: TEXT 'why08_collision_alias.json'. Ordered at pal64 step 24. Preview: {

## CQE-Unified_Repo::RAG-00025 — why10_privacy_policy.json
- Token: `D0030` | Type: `text` | pal64 step: 25 | receipt: `0000`
- Tags: policy, privacy, false, force, label, metric, override
- Connections: D0028(adjacent-order), D0029(adjacent-order)
- Summary: TEXT 'why10_privacy_policy.json'. Ordered at pal64 step 25. Preview: {

## CQE-Unified_Repo::RAG-00026 — why09_cache_replay.json
- Token: `D0029` | Type: `text` | pal64 step: 26 | receipt: `0000`
- Tags: cache, replay, false, force, label, metric, override
- Connections: D0030(adjacent-order), D0024(adjacent-order)
- Summary: TEXT 'why09_cache_replay.json'. Ordered at pal64 step 26. Preview: {

## CQE-Unified_Repo::RAG-00027 — why04_palindromic_rest.json
- Token: `D0024` | Type: `text` | pal64 step: 27 | receipt: `0000`
- Tags: palindromic, rest, false, force, label, metric, override
- Connections: D0029(adjacent-order), D0022(adjacent-order)
- Summary: TEXT 'why04_palindromic_rest.json'. Ordered at pal64 step 27. Preview: {

## CQE-Unified_Repo::RAG-00028 — why02_glyph_supremacy.json
- Token: `D0022` | Type: `text` | pal64 step: 28 | receipt: `0000`
- Tags: glyph, supremacy, force, label, metric, override, prev
- Connections: D0024(adjacent-order), D0021(adjacent-order)
- Summary: TEXT 'why02_glyph_supremacy.json'. Ordered at pal64 step 28. Preview: {

## CQE-Unified_Repo::RAG-00029 — why01_foundations.json
- Token: `D0021` | Type: `text` | pal64 step: 29 | receipt: `0000`
- Tags: foundations, false, force, label, mapping, metric, override
- Connections: D0022(adjacent-order), D0003(adjacent-order)
- Summary: TEXT 'why01_foundations.json'. Ordered at pal64 step 29. Preview: {

## CQE-Unified_Repo::RAG-00030 — README.md
- Token: `D0003` | Type: `text` | pal64 step: 30 | receipt: `0000`
- Tags: harness, cqe, python, quick, repository, run, start
- Connections: D0021(adjacent-order), D0027(adjacent-order)
- Summary: TEXT 'README.md'. Ordered at pal64 step 30. Preview: # CQE‑Unified Repository

## CQE-Unified_Repo::RAG-00031 — why07_corridors.json
- Token: `D0027` | Type: `text` | pal64 step: 31 | receipt: `0000`
- Tags: corridors, false, force, label, metric, override, prev
- Connections: D0003(adjacent-order), D0019(adjacent-order)
- Summary: TEXT 'why07_corridors.json'. Ordered at pal64 step 31. Preview: {

## CQE-Unified_Repo::RAG-00032 — brainwaves.csv
- Token: `D0019` | Type: `csv` | pal64 step: 32 | receipt: `0000`
- Tags: col:t, col:amp
- Connections: D0027(adjacent-order), D0020(adjacent-order)
- Summary: CSV 'brainwaves.csv'. Ordered at pal64 step 32. Preview: 2 columns (preview header)

## CQE-Unified_Repo::RAG-00033 — sound_spectrum.csv
- Token: `D0020` | Type: `csv` | pal64 step: 33 | receipt: `0000`
- Tags: col:freq_hz, col:power
- Connections: D0019(adjacent-order)
- Summary: CSV 'sound_spectrum.csv'. Ordered at pal64 step 33. Preview: 2 columns (preview header)
