
#!/usr/bin/env bash
set -euo pipefail
python -m lattice_ai.tests.eval_golden
echo "GOLDEN OK"
