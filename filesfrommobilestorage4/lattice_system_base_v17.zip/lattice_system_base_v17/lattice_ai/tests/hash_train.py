
import argparse, json, numpy as np, time
from lattice_ai.core.semantic_hash import SemanticHashTrainer

def load_data(n_clusters=8, per_cluster=64, dim=8, seed=7):
    rng = np.random.default_rng(seed)
    centers = [rng.standard_normal(dim) for _ in range(n_clusters)]
    centers = [c/ (np.linalg.norm(c)+1e-9) for c in centers]
    X = []
    y_pairs = []
    idx_by_cluster = []
    for i, c in enumerate(centers):
        cluster_idx = []
        for k in range(per_cluster):
            x = c + 0.15*rng.standard_normal(dim)
            x = x / (np.linalg.norm(x)+1e-9)
            X.append(x); cluster_idx.append(len(X)-1)
            if k>0:
                y_pairs.append([len(X)-1, len(X)-2, +1])
        idx_by_cluster.append(cluster_idx)
    # negatives: cross cluster
    for a in range(n_clusters):
        for b in range(a+1, n_clusters):
            i = idx_by_cluster[a][0]; j = idx_by_cluster[b][0]
            y_pairs.append([i, j, -1])
    return np.stack(X,axis=0), np.array(y_pairs, dtype=float)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dim", type=int, default=8)
    ap.add_argument("--bits", type=int, default=64)
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--lr", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", type=str, default="/mnt/data/weights.json")
    args = ap.parse_args()

    X, pairs = load_data(dim=args.dim, seed=args.seed)
    trainer = SemanticHashTrainer(dim=args.dim, bits=args.bits, steps=args.steps, lr=args.lr, seed=args.seed)
    t0 = time.time()
    W,b = trainer.fit(X, pairs)
    dt = time.time() - t0

    imb = trainer.bit_imbalance(X, W, b)
    print("Trained in {:.2f}s | bit imbalance avg |mean| = {:.4f}".format(dt, imb))
    with open(args.out, "w") as f:
        json.dump({"W2": W.tolist(), "b2": b.tolist(), "dim": args.dim, "bits": args.bits}, f)
    print("Saved:", args.out)

if __name__ == "__main__":
    main()
