
from dataclasses import dataclass
from typing import Dict, Tuple, Optional
import numpy as np, hashlib
from .types import Glyph
from .hash_system import HashSystem

@dataclass
class SafeCube:
    dim: int = 8
    seed: int = 7

    def __post_init__(self):
        self.glyphs: Dict[str, Glyph] = {}
        self.hashes = HashSystem(dim=self.dim, seed=self.seed+33)

    def add_glyph(self, id: str, **tags):
        self.glyphs[id] = Glyph(id=id, tags=tags)

    def glyph_vector(self, id: str) -> np.ndarray:
        h = hashlib.sha256(id.encode()).digest()
        arr = np.frombuffer(h[:8*4], dtype=np.uint32).astype(np.float64)
        v = (arr % 1000) - 500.0
        v = v[:self.dim]; v = v / (np.linalg.norm(v) + 1e-9)
        return v

    def house_for_glyph(self, id: str, meta=None) -> Tuple[bytes, bytes]:
        v = self.glyph_vector(id)
        return self.hashes.house_key(v, meta)

    def store_glyph(self, id: str, meta=None):
        key = self.house_for_glyph(id, meta)
        self.hashes.add_item(key, id)
        return key
