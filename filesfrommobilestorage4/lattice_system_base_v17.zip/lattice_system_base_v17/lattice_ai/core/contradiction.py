
"""
Contradiction sweeper (v2)
Rule: for any (subject, predicate), if multiple distinct values exist across sources in the current shell members,
mark as conflict. Quarantine promoted shells for the center.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Iterable

@dataclass
class Claim:
    subject: str
    predicate: str
    value: str
    source: str  # glyph id

@dataclass
class SweepReport:
    conflicts: List[Tuple[str, str]] = field(default_factory=list)  # (subject, predicate)
    details: Dict[Tuple[str,str], Dict[str, List[str]]] = field(default_factory=dict)  # (s,p) -> value -> [sources]

class ContradictionSweeper:
    def sweep(self, claims: Iterable[Claim]) -> SweepReport:
        buckets: Dict[Tuple[str,str], Dict[str, List[str]]] = {}
        for c in claims:
            key = (c.subject, c.predicate)
            vmap = buckets.setdefault(key, {})
            vmap.setdefault(c.value, []).append(c.source)
        rep = SweepReport()
        for key, vmap in buckets.items():
            if len(vmap) > 1:
                rep.conflicts.append(key)
                rep.details[key] = vmap
        return rep
