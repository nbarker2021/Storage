
import sqlite3

MIGRATIONS = [
    # v1 -> v2: add indices
    {
        "id": 2,
        "sql": [
            "CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY);",
            "INSERT OR IGNORE INTO schema_version(version) VALUES (1);",
            "CREATE INDEX IF NOT EXISTS idx_houses_h1h2 ON houses(h1,h2);",
            "CREATE INDEX IF NOT EXISTS idx_house_items_item ON house_items(item_id);",
            "CREATE INDEX IF NOT EXISTS idx_shells_center_state ON shells(center_id,state);"
        ]
    },
    # v2 -> v3: add promotion_reports table if missing
    {
        "id": 3,
        "sql": [
            "CREATE TABLE IF NOT EXISTS promotion_reports (center_id TEXT, shell_k INTEGER, decision TEXT, metrics TEXT, policy TEXT);"
        ]
    }
]

def get_version(conn: sqlite3.Connection) -> int:
    cur = conn.cursor()
    try:
        row = cur.execute("SELECT version FROM schema_version ORDER BY version DESC LIMIT 1").fetchone()
        if row:
            return row[0]
        return 1
    except sqlite3.OperationalError:
        return 1

def migrate(conn: sqlite3.Connection):
    cur = conn.cursor()
    v = get_version(conn)
    for m in MIGRATIONS:
        if m["id"] > v:
            for stmt in m["sql"]:
                cur.execute(stmt)
            cur.execute("INSERT OR REPLACE INTO schema_version(version) VALUES (?)", (m["id"],))
            conn.commit()
