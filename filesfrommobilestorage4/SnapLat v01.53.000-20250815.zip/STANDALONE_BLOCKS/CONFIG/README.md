# CONFIG
Contains global constants; `DEFAULT_WATERMARK=1729` (Taxicab1).
