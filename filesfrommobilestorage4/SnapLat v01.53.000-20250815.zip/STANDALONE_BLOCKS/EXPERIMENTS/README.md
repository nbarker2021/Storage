# EXPERIMENTS
`coverage_empirics.py` runs corpus sweeps with plots; supports caps and polarity.
