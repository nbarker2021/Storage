# Changelog up to v01.53.000
- Pass 53: Watermark corrected to 1729 (Taxicab1). Targeted corpus search. Coverage with polarity (cap 120).
- Pass 52: Deep read (5 exemplars), targeted search plan, 1729 vs 1792 check (now deprecated).
- Pass 51: CLI wired; polarity annotator; full-corpus coverage with polarity; exemplar pack; performance guards.
- Pass 47–48: Manus zip triage; mixed corpus; LSDT reference-only guard; advisory adoption policies.
