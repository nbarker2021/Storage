# METRICS
`coverage.py` computes redundancy and polarity-aware neg_conflict with safe fallbacks for large graphs.
