# INGEST
`text.py` builds co-occurrence graphs. `polarity.py` infers heuristic edge signs from sentence-level cues.
