#!/usr/bin/env python3
from __future__ import annotations
import argparse, sys, json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ingest.indexer import build_index
from experiments.coverage_empirics import run_coverage_empirics

def cmd_index(args):
    data = build_index(args.infile)
    Path(args.out_json).write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"Wrote {args.out_json}")

def cmd_coverage(args):
    out, df = run_coverage_empirics(args.data_dir, watermark=args.watermark, window=args.window, plots_dir=args.plots_dir, with_polarity=args.with_polarity, max_files=args.max_files)
    if args.out_json: Path(args.out_json).write_text(json.dumps(out, indent=2), encoding="utf-8")
    if args.out_csv: df.to_csv(args.out_csv, index=False)
    print(json.dumps({"kstar": out["kstar"], "watermark": args.watermark, "n_docs": len(out["docs"])}, indent=2))

def main():
    ap = argparse.ArgumentParser(prog="snaplat", description="SnapLat CLI")
    sub = ap.add_subparsers(dest="cmd", required=True)
    ap_idx = sub.add_parser("index", help="Index a single log file")
    ap_idx.add_argument("--infile", required=True)
    ap_idx.add_argument("--out-json", required=True)
    ap_idx.set_defaults(func=cmd_index)
    ap_cov = sub.add_parser("coverage", help="Run coverage empirics on a directory")
    ap_cov.add_argument("--data-dir", required=True)
    ap_cov.add_argument("--watermark", type=int, default=1729)
    ap_cov.add_argument("--window", type=int, default=5)
    ap_cov.add_argument("--with-polarity", action="store_true")
    ap_cov.add_argument("--max-files", type=int, default=None)
    ap_cov.add_argument("--out-json", type=str, default=None)
    ap_cov.add_argument("--out-csv", type=str, default=None)
    ap_cov.add_argument("--plots-dir", type=str, default=None)
    ap_cov.set_defaults(func=cmd_coverage)
    args = ap.parse_args()
    return args.func(args)

if __name__ == "__main__":
    main()
