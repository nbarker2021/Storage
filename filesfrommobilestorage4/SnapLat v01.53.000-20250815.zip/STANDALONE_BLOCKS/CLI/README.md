# CLI
`snaplat.py` provides `index` and `coverage` subcommands. Use `--with-polarity` to enable signed neg-conflict.
