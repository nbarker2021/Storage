from agrm.metrics.coverage import neg_conflict
def test_neg_conflict_triangle():
    n=3; edges=[(0,1),(1,2),(0,2)]
    signs={(0,1):1,(1,2):1,(0,2):-1}  # one negative edge -> negative triangle
    val = neg_conflict(n, edges, signs=signs)
    assert 0.9 > val > 0.1  # not zero, not one, reflects conflict presence
