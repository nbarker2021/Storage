from snapops.api import run as snap_run
from trails import api as trails_api

def test_lsdt_reference_only_blocks_adoption():
    trails_api._drain()
    req = {
      'policy': {'mc_enable_auto': True, 'mc_modes': ['random_walk'], 'adopt_advisory': True, 'lsdt_reference_only': True},
      'findings': ['node:5', 'LSDT central framing here', '#2'],
      'evidence': {'neg_conflict': 0.9}
    }
    _ = snap_run(req)
    ev = trails_api._drain()
    blocked = any(e.get('op')=='policy.blocked.lsdt' for e in ev)
    adopted = any(e.get('op')=='snapops.advisory.adopted' for e in ev)
    assert blocked or not adopted
