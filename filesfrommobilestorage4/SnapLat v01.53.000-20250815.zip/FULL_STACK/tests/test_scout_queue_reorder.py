from scout.queue import reorder_by_hints, extract_node_id
def test_reorder_by_hints():
    q = ["node:5","foo","#2","bar"]
    ranking=[2,5]
    new = reorder_by_hints(q, ranking, extract_node_id)
    assert new[:2]==["#2","node:5"]
