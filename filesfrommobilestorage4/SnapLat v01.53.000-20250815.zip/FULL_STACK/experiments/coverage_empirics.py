from __future__ import annotations
import os, json
from pathlib import Path
from typing import Dict, List
import matplotlib.pyplot as plt
import pandas as pd

from ingest.text import build_graph_from_text
from agrm.metrics.coverage import redundancy_ratio, neg_conflict_proxy
from ingest.polarity import edge_signs_from_text

def analyze_doc(path: Path, window: int, with_polarity: bool=False) -> Dict:
    s = path.read_text(encoding="utf-8", errors="ignore")
    n, edges = build_graph_from_text(s, window=window)
    red = redundancy_ratio(n, edges)
    signs = edge_signs_from_text(s, window=window) if with_polarity else None
    neg = neg_conflict_proxy(n, edges, signs=signs)
    return {"doc": path.name, "k": n, "edges": len(edges), "redundancy": red, "neg_conflict_proxy": neg}

def run_coverage_empirics(data_dir: str, watermark: int = 1729, window: int = 5, plots_dir: str | None = None, with_polarity: bool=False, max_files: int | None = None):
    p = Path(data_dir)
    files = [f for f in p.rglob("*") if f.is_file() and f.suffix.lower() in {".txt",".md",".rst"}]
    if max_files is not None:
        files = files[:max_files]
    rows: List[Dict] = []
    for f in sorted(files):
        rows.append(analyze_doc(f, window=window, with_polarity=with_polarity))
    df = pd.DataFrame(rows).sort_values("k") if rows else pd.DataFrame(columns=["doc","k","edges","redundancy","neg_conflict_proxy"])
    if not df.empty:
        df["coverage_gate_triggered"] = df["k"] < watermark
        kstar = int(df.loc[df["k"]>=watermark,"k"].min()) if (df["k"]>=watermark).any() else None
    else:
        df["coverage_gate_triggered"] = []
        kstar = None
    out = {"watermark": watermark, "window": window, "kstar": kstar, "docs": rows}
    if plots_dir and not df.empty:
        Path(plots_dir).mkdir(parents=True, exist_ok=True)
        plt.figure(); plt.scatter(df["k"], df["redundancy"]); plt.xlabel("k (unique tokens)"); plt.ylabel("redundancy"); plt.title("Redundancy vs k"); plt.tight_layout(); plt.savefig(str(Path(plots_dir)/"redundancy_vs_k.png")); plt.close()
        plt.figure(); plt.scatter(df["k"], df["neg_conflict_proxy"]); plt.xlabel("k (unique tokens)"); plt.ylabel("neg_conflict_proxy"); plt.title("Neg-Conflict Proxy vs k"); plt.tight_layout(); plt.savefig(str(Path(plots_dir)/"neg_conflict_vs_k.png")); plt.close()
    return out, df

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Coverage empirics over a directory of text/markdown files")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--watermark", type=int, default=1729)
    ap.add_argument("--window", type=int, default=5)
    ap.add_argument("--out-json", type=str, default=None)
    ap.add_argument("--out-csv", type=str, default=None)
    ap.add_argument("--plots-dir", type=str, default=None)
    ap.add_argument("--with-polarity", action="store_true")
    ap.add_argument("--max-files", type=int, default=None)
    args = ap.parse_args()
    out, df = run_coverage_empirics(args.data_dir, watermark=args.watermark, window=args.window, plots_dir=args.plots_dir, with_polarity=args.with_polarity, max_files=args.max_files)
    if args.out_json: Path(args.out_json).write_text(json.dumps(out, indent=2), encoding="utf-8")
    if args.out_csv: df.to_csv(args.out_csv, index=False)
    print(json.dumps({"kstar": out["kstar"], "watermark": args.watermark, "n_docs": len(out["docs"])}, indent=2))
