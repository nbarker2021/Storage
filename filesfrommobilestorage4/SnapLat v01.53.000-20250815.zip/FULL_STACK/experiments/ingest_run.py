
from __future__ import annotations
import json, os
from pathlib import Path
import pandas as pd
from ingest.indexer import build_index

def run(paths):
    outs = []
    for p in paths:
        idx = build_index(p)
        outs.append({"path": p, "segments": len(idx["segments"]), "packages": len(idx["packages"]), "codes": len(idx["code"])})
        Path(p).with_suffix(".index.json").write_text(json.dumps(idx, indent=2), encoding="utf-8")
    return pd.DataFrame(outs)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()
    df = run(args.files)
    print(df.to_string(index=False))
