from ops.contracts.schemas import validate_transcript

# Pass 44 DTT transcript schema check
try:
    _t = locals().get('Transcript')
except Exception:
    _t = None
