from __future__ import annotations
import re
from typing import Dict, List, Tuple

NEG_WORDS = set("no not never none neither nor without despite against versus vs contradicts contradict contrary conflict fail fails failing however but although yet whereas nonetheless nevertheless".split())
POS_WORDS = set("support supports supported consistent aligns align alignment agree agrees agreed coherent strengthen strengthens proves validated validate".split())

def sentence_split(text: str) -> List[str]:
    return re.split(r'[\.!?\n]+', text or '')

def tokenize(s: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9_]+", s.lower())

def edge_signs_from_text(text: str, window: int = 5) -> Dict[Tuple[int,int], int]:
    sents = sentence_split(text)
    vocab: Dict[str, int] = {}
    def tid(tok: str) -> int:
        if tok not in vocab: vocab[tok] = len(vocab)
        return vocab[tok]
    pos = {}; neg = {}
    for sent in sents:
        toks = tokenize(sent)
        if not toks: continue
        has_neg = any(t in NEG_WORDS for t in toks)
        has_pos = any(t in POS_WORDS for t in toks)
        for i in range(len(toks)):
            a = tid(toks[i])
            for j in range(max(0,i-window), min(len(toks), i+window+1)):
                if j==i: continue
                b = tid(toks[j])
                u,v = (a,b) if a<b else (b,a)
                if has_pos: pos[(u,v)] = pos.get((u,v), 0) + 1
                if has_neg: neg[(u,v)] = neg.get((u,v), 0) + 1
    signs: Dict[Tuple[int,int], int] = {}
    keys = set(pos.keys()) | set(neg.keys())
    for k in keys:
        val = (pos.get(k,0) - neg.get(k,0))
        signs[k] = 1 if val>0 else -1 if val<0 else 1
    return signs
