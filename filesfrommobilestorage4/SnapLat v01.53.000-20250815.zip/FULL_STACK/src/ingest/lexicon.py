
from __future__ import annotations
from collections import Counter
from typing import Dict, List, Tuple

def ngrams(tokens: List[str], n: int) -> List[Tuple[str,...]]:
    return [tuple(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def grow_lexicon(pkgs: List[Dict], *, top_k: int = 50) -> Dict[str, List[str]]:
    unigrams = Counter()
    bigrams = Counter()
    trigrams = Counter()
    for p in pkgs:
        text = " ".join(i["text"] for i in p["items"]).lower()
        toks = [t for t in text.split() if t]
        for t in toks: unigrams[t]+=1
        for bg in ngrams(toks,2): bigrams[bg]+=1
        for tg in ngrams(toks,3): trigrams[tg]+=1
    def top(counter, k): 
        return [" ".join(t) if isinstance(t, tuple) else t for t,_ in counter.most_common(k)]
    return {"uni": top(unigrams, top_k), "bi": top(bigrams, top_k), "tri": top(trigrams, top_k)}
