from __future__ import annotations
import re
from typing import List, Dict, Any

# Variants/aliases
TERMS = [
    r'\bLSDT\b',\n    r'\bLayered Simulation Dimensional Theory\b',\n    r'\bLayered\s+Simulation\s+Dimensional\s+Theory\b',\n]
PAT = re.compile('|'.join(TERMS), re.I)

def tag_theories(text: str) -> List[Dict[str, Any]]:
    out = []
    for m in PAT.finditer(text or ''):
        out.append({'theory': 'LSDT', 'start': m.start(), 'end': m.end()})
    return out
