from __future__ import annotations
from typing import Tuple, List, Dict
import re

def tokenize(s: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9_]+", s.lower())

def build_graph_from_text(s: str, window: int = 5) -> Tuple[int, List[Tuple[int,int]]]:
    toks = tokenize(s or "")
    vocab: Dict[str, int] = {}
    def tid(tok: str) -> int:
        if tok not in vocab: vocab[tok] = len(vocab)
        return vocab[tok]
    ids = [tid(t) for t in toks]
    edges = set()
    n = len(vocab)
    for i in range(len(ids)):
        a = ids[i]
        lo = max(0, i-window)
        hi = min(len(ids), i+window+1)
        for j in range(lo, hi):
            if j==i: continue
            b = ids[j]
            u,v = (a,b) if a<b else (b,a)
            edges.add((u,v))
    return n, list(edges)
