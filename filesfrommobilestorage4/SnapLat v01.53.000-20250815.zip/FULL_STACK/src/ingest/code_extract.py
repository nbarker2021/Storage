
from __future__ import annotations
import re
from typing import List, Dict, Any, Optional

FENCE = re.compile(r"```(\w+)?\s*([\s\S]*?)```", re.M)

def extract_code(text: str) -> List[Dict[str,str]]:
    out = []
    for m in FENCE.finditer(text or ""):
        lang = (m.group(1) or "text").lower().strip()
        body = m.group(2)
        out.append({"lang": lang, "code": body})
    return out

def extract_all(pkgs: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    out = []
    for p in pkgs:
        codes = []
        for it in p["items"]:
            codes.extend(extract_code(it["text"]))
        if codes:
            out.append({"mini_hash": p["mini_hash"], "codes": codes})
    return out
