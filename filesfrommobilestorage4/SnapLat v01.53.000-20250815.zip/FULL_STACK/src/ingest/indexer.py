
from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, Any
from .log_segmenter import segment
from .idea_packager import package
from .lexicon import grow_lexicon
from .code_extract import extract_all
from .theories import tag_theories

def build_index(path: str) -> Dict[str, Any]:
    txt = Path(path).read_text(encoding="utf-8", errors="ignore")
    segs = segment(txt)
    pkgs = package(segs)
    lex = grow_lexicon(pkgs, top_k=80)
    code = extract_all(pkgs)
    return {"path": path, "segments": segs, "packages": pkgs, "lexicon": lex, "code": code}

if __name__ == "__main__":
    import argparse, pandas as pd
    ap = argparse.ArgumentParser(description="Build index for SnapLat logs")
    ap.add_argument("--infile", required=True)
    ap.add_argument("--out-json", required=True)
    args = ap.parse_args()
    data = build_index(args.infile)
    Path(args.out_json).write_text(json.dumps(data, indent=2), encoding="utf-8")
    # Emit a small CSV of packages
    rows = [{"mini_hash": p["mini_hash"],
             "start": p["char_range"][0],
             "end": p["char_range"][1],
             "human": p["ledger"]["human"],
             "ai": p["ledger"]["ai"]} for p in data["packages"]]
    pd.DataFrame(rows).to_csv(Path(args.out_json).with_suffix(".csv"), index=False)
    print(f"Wrote {args.out_json}")
