
from __future__ import annotations
import re, hashlib
from typing import List, Dict, Any

PIVOT = re.compile(r"\b(zip|buildfiles|google drive|new (plan|scope)|reset approvals|next topic|start review|switch to)\b", re.I)

def package(segments: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    pkgs: List[Dict[str,Any]] = []
    cur = {"start": None, "end": None, "items": []}
    for seg in segments:
        if cur["start"] is None:
            cur["start"] = seg["start"]
        cur["end"] = seg["end"]
        cur["items"].append(seg)
        # pivot if Human introduces task pivot marker
        if seg["role"]=="human" and PIVOT.search(seg["text"] or ""):
            pkgs.append(cur)
            cur = {"start": None, "end": None, "items": []}
    if cur["items"]:
        pkgs.append(cur)
    # enrich: mini-hash & role ledger
    out = []
    for p in pkgs:
        text = "".join(i["text"] for i in p["items"])
        h = hashlib.md5(text.encode("utf-8")).hexdigest()[:8]
        ledger = {"human": sum(1 for i in p["items"] if i["role"]=="human"),
                  "ai": sum(1 for i in p["items"] if i["role"]=="ai")}
        out.append({"char_range": [p["start"], p["end"]], "mini_hash": h, "ledger": ledger, "items": p["items"]})
    return out
