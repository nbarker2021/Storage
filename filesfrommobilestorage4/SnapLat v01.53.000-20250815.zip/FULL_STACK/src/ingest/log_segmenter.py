
from __future__ import annotations
import re, hashlib
from typing import List, Dict, Any
from .log_authorship import classify_header, classify_style

HEADER = re.compile(r"^\s*(You said:|ChatGPT said:|thought\s+for\s+\d+\s*(?:seconds|minutes|min)?)", re.I)

def segment(text: str) -> List[Dict[str,Any]]:
    out: List[Dict[str,Any]] = []
    i = 0
    cur = {"role":"unknown","start":0,"lines":[]}
    lines = text.splitlines()
    pos = 0
    for ln in lines:
        if HEADER.match(ln):
            # flush previous
            if cur["lines"]:
                seg_text = "\n".join(cur["lines"])
                role = cur["role"]
                if role == "unknown":
                    role = classify_style(seg_text)
                out.append({
                    "role": role,
                    "start": cur["start"],
                    "end": pos,
                    "text": seg_text
                })
            # start new
            role = classify_header(ln)
            cur = {"role": role, "start": pos, "lines":[ln]}
        else:
            cur["lines"].append(ln)
        pos += len(ln) + 1  # + newline
    if cur["lines"]:
        seg_text = "\n".join(cur["lines"])
        role = cur["role"]
        if role == "unknown":
            role = classify_style(seg_text)
        out.append({"role": role, "start": cur["start"], "end": pos, "text": seg_text})
    # add mini-hash
    for s in out:
        s["mini_hash"] = hashlib.md5(s["text"].encode("utf-8")).hexdigest()[:8]
    return out
