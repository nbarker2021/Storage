
from __future__ import annotations
import re
from typing import Literal

Role = Literal["human","ai","unknown"]

YOU_RE = re.compile(r"^\s*(You said:)", re.I)
AI_RE  = re.compile(r"^\s*(ChatGPT said:)", re.I)
THINK_RE = re.compile(r"^\s*thought\s+for\s+\d+\s*(seconds|minutes|mins)?", re.I)

# Fallback patterns if headers are absent
AI_STYLE = re.compile(r"\b(I|We)\s+(will|can|did|implemented|created|updated)\b|\bHere'?s\b|\b```", re.I)
HUMAN_STYLE = re.compile(r"\bplease\b|\bgo ahead\b|\bcontinue\b|\bapproved\b|\bthat looks good\b|\bthanks?\b", re.I)

def classify_header(line: str) -> Role:
    if YOU_RE.search(line): return "human"
    if AI_RE.search(line) or THINK_RE.search(line): return "ai"
    return "unknown"

def classify_style(text: str) -> Role:
    ai = bool(AI_STYLE.search(text))
    human = bool(HUMAN_STYLE.search(text))
    if ai and not human: return "ai"
    if human and not ai: return "human"
    return "unknown"
