from __future__ import annotations
from typing import List, Tuple, Dict

def degree_distribution(n: int, edges: List[Tuple[int,int]]):
    deg = [0]*n
    for i,j in edges:
        if 0<=i<n and 0<=j<n:
            deg[i]+=1; deg[j]+=1
    return deg

def redundancy_ratio(n: int, edges: List[Tuple[int,int]]):
    deg = degree_distribution(n, edges)
    return sum(1 for d in deg if d>=2) / max(1,n)

def neg_conflict_proxy(n: int, edges: List[Tuple[int,int]], *, signs: Dict[Tuple[int,int], int] | None = None, bridges: List[Tuple[int,int]] | None = None) -> float:
    if signs is not None or bridges is not None:
        return neg_conflict(n, edges, signs=signs, bridges=bridges)
    return 1.0 - redundancy_ratio(n, edges)

def neg_conflict(n: int, edges: List[Tuple[int,int]], *, signs: Dict[Tuple[int,int], int] | None = None, bridges: List[Tuple[int,int]] | None = None) -> float:
    PERF_CAP_N = 400
    PERF_CAP_E = 20000
    eset = set(tuple(sorted(e)) for e in edges)
    if signs and (len(eset)>PERF_CAP_E or n>PERF_CAP_N):
        return neg_conflict_proxy(n, edges)
    adj = {i:set() for i in range(n)}
    for i,j in eset:
        if 0<=i<n and 0<=j<n:
            adj[i].add(j); adj[j].add(i)
    tri_total = 0
    tri_neg = 0
    if signs:
        sgn = {tuple(sorted(k)): (1 if v>=0 else -1) for k,v in signs.items() if isinstance(v,(int,float))}
        for i in range(n):
            for j in adj[i]:
                if j<=i: continue
                cn = adj[i].intersection(adj[j])
                for k in cn:
                    if j<k and i<j:
                        tri_total += 1
                        prod = sgn.get(tuple(sorted((i,j))),1) * sgn.get(tuple(sorted((j,k))),1) * sgn.get(tuple(sorted((i,k))),1)
                        if prod < 0:
                            tri_neg += 1
        base = (tri_neg/tri_total) if tri_total>0 else 0.0
    else:
        # Fallback: approximate clustering × redundancy complement
        closed = 0; trip = 0
        for i in range(n):
            di = len(adj[i])
            if di>=2:
                nbrs = list(adj[i])
                trip += di*(di-1)/2
                inter = 0
                for a_idx in range(di):
                    a = nbrs[a_idx]
                    for b_idx in range(a_idx+1, di):
                        b = nbrs[b_idx]
                        if b in adj[a]:
                            inter += 1
                closed += inter
        clustering = (closed/trip) if trip>0 else 0.0
        base = max(0.0, 1.0 - clustering * (redundancy_ratio(n, edges)))
    if bridges:
        bset = set(tuple(sorted(e)) for e in bridges)
        incident = sum(1 for e in eset if e in bset)
        if len(eset)>0:
            w = min(0.5, incident/len(eset))
            base = min(1.0, base*(1.0 + w))
    return float(max(0.0, min(1.0, base)))
