# SnapLat global constants
WATERMARK_TAXICAB1 = 1729  # Hardy–Ramanujan number (1^3+12^3 = 9^3+10^3)
DEFAULT_WATERMARK = WATERMARK_TAXICAB1
