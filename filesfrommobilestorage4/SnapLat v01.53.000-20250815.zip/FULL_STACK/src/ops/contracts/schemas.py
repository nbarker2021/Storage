from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class Step:
    op: str
    why: Optional[str] = None
    module: Optional[str] = None
    universe_ref: Optional[str] = None
    snap_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TranscriptEntry:
    op: str
    module: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Transcript:
    ok: bool
    steps: List[TranscriptEntry]
    counts: Dict[str, int]
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class WorkOrder:
    steps: List[Step]
    snap_ids: List[str] = field(default_factory=list)

def _req(d: Dict[str, Any], key: str, typ):
    if key not in d or d[key] is None:
        raise ValueError(f"Missing required field: {key}")
    if not isinstance(d[key], typ):
        raise TypeError(f"Field {key} must be {typ}, got {type(d[key])}")
    return d[key]

def validate_step(d: Dict[str, Any]) -> Step:
    op = _req(d, "op", str)
    why = d.get("why")
    module = d.get("module")
    universe_ref = d.get("universe_ref")
    snap_id = d.get("snap_id")
    payload = d.get("payload") or {}
    if not isinstance(payload, dict):
        raise TypeError("payload must be a dict")
    return Step(op=op, why=why, module=module, universe_ref=universe_ref, snap_id=snap_id, payload=payload)

def validate_transcript(d: Dict[str, Any]) -> Transcript:
    ok = bool(_req(d, "ok", (bool, int)))
    steps = [TranscriptEntry(**e) for e in _req(d, "steps", list)]
    counts = _req(d, "counts", dict)
    meta = d.get("meta") or {}
    if not isinstance(meta, dict):
        raise TypeError("meta must be a dict")
    return Transcript(ok=bool(ok), steps=steps, counts=counts, meta=meta)

def validate_workorder(d: Dict[str, Any]) -> WorkOrder:
    steps = [validate_step(s) for s in _req(d, "steps", list)]
    snap_ids = d.get("snap_ids") or []
    if not isinstance(snap_ids, list):
        raise TypeError("snap_ids must be a list")
    return WorkOrder(steps=steps, snap_ids=snap_ids)
