from __future__ import annotations
from typing import List, Any, Callable, Dict
from trails import api as trails

def reorder_by_hints(queue: List[Any], ranking: List[int], key: Callable[[Any], int | None]) -> List[Any]:
    """Return a new list where items with ids in ranking appear first in that order; others keep relative order."""
    rank = {nid: i for i, nid in enumerate(ranking)}
    def k(item):
        nid = key(item)
        return (rank.get(nid, 10**9), )  # stable sort keeps original order for equals
    new = sorted(queue, key=k)
    if new != queue:
        trails.append_event(None, {"op":"scout.queue.reordered","module":__name__,"payload":{"moved": len(queue)}})
    return new

def extract_node_id(item) -> int | None:
    # accepts strings like 'node:12' or '#12' or dicts with 'node_id'
    if isinstance(item, dict) and 'node_id' in item:
        try: return int(item['node_id'])
        except Exception: return None
    s = str(item)
    import re
    m = re.search(r'(?:node:|#)(\d+)', s)
    return int(m.group(1)) if m else None
