import time
from typing import Any, Dict
from fastapi import Request
from .config import get as cfg_get
from .jws import verify_hs256

def path_guarded(path: str) -> bool:
    if not cfg_get("jws_required", False): return False
    prefixes = cfg_get("jws_endpoint_prefixes", ["/octet/","/channel/","/planner/"])
    return any(path.startswith(p) for p in prefixes)

def get_token_from_headers(req: Request) -> str:
    auth = req.headers.get("Authorization") or ""
    if auth.lower().startswith("bearer "):
        return auth.split(" ",1)[1].strip()
    return req.headers.get("X-Permission-Token") or ""

def scope_ok(token_payload, required):
    if not required: return True
    tsc = token_payload.get("scope")
    if isinstance(required, str): required=[required]
    if isinstance(tsc, str): tsc=[tsc]
    if not isinstance(tsc, list): return False
    return any(r in tsc for r in required)

def endpoints_ok(path: str, token_payload) -> bool:
    if not cfg_get("jws_enforce_endpoints", True): return True
    eps = token_payload.get("endpoints")
    if not eps: return True
    return any(path.startswith(p) for p in eps)

def jws_ok(request: Request) -> (bool, dict):
    if not cfg_get("jws_required", False): return True, {"reason":"not-required"}
    tok = get_token_from_headers(request)
    if not tok: return False, {"err":"missing"}
    secret_hex = cfg_get("jws_secret", "")
    if not secret_hex: return False, {"err":"server-misconfig"}
    try:
        secret = bytes.fromhex(secret_hex)
    except Exception:
        secret = secret_hex.encode()
    ok, info = verify_hs256(tok, secret)
    if not ok: return False, info
    pl = info.get("payload", {})
    if not scope_ok(pl, cfg_get("jws_required_scope", None)):
        return False, {"err":"scope"}
    if not endpoints_ok(request.url.path, pl):
        return False, {"err":"endpoint"}
    return True, pl
