import json, os

CFG_PATH = "/mnt/data/lfai_config.json"

DEFAULTS = {
  "jws_required": True,
  "jws_enforce_endpoints": True,
  "jws_endpoint_prefixes": ["/octet/","/channel/","/planner/"],
  "jws_required_scope": "eval-only",
  "jws_secret": ""
}

def load():
    if not os.path.exists(CFG_PATH):
        save(DEFAULTS)
    with open(CFG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    for k,v in DEFAULTS.items():
        cfg.setdefault(k,v)
    return cfg

def save(cfg):
    with open(CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    return cfg

def get(key, default=None):
    cfg = load()
    return cfg.get(key, default)
