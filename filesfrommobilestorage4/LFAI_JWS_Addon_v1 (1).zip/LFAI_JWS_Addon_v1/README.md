# LFAI — JWS Guard Add‑On (HS256)

This pack adds **JWS Permission Token** enforcement to your server.

## Quick start (example server)
```bash
uvicorn api_server_example:app --reload --port 8000
# seed config (creates a jws_secret)
curl -s localhost:8000/config/set -H 'content-type: application/json' -d '{"config":{}}' | jq
# issue token
curl -s localhost:8000/perm/issue -H 'content-type: application/json' -d '{"sub":"ACME","scope":"eval-only","ttl_sec":3600}' | jq -r .token > token.txt
# call a guarded endpoint
curl -s localhost:8000/octet/run -H "Authorization: Bearer $(cat token.txt)" -H 'content-type: application/json' -d '[1,2,3,4,0,0,0,0]' | jq
```

## Integrate into your repo
1. Add `lfaicore/jws.py` and `lfaicore/jws_guard.py` to your codebase.
2. Ensure your `config` module exposes `get`/`load`/`save` and stores `jws_secret`, `jws_required`, etc.
3. In your FastAPI app, import and call `jws_ok(request)` at the start of guarded endpoints.
4. Provide `/perm/issue` or mint tokens offline with the same secret.

**Token**: HS256 JWT-like JWS with `iss, sub, scope, endpoints, nbf, exp, iat, jti, anchors?`  
**Headers**: send via `Authorization: Bearer <token>` or `X-Permission-Token`.

Security note: rotate `jws_secret` periodically and scope tokens narrowly.
