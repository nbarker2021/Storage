from fastapi import FastAPI, Request, Body
from fastapi.responses import JSONResponse
import time, hashlib, json
from lfaicore.config import load as cfg_load, save as cfg_save, get as cfg_get
from lfaicore.jws_guard import jws_ok
from lfaicore.jws import sign_hs256

app = FastAPI(title="LFAI JWS-Guard Example", version="0.1.0")

@app.get("/config/get")
def config_get():
    return cfg_load()

@app.post("/config/set")
def config_set(data: dict = Body(...)):
    cfg = cfg_load()
    cfg.update(data.get("config", {}))
    if not cfg.get("jws_secret"):
        cfg["jws_secret"] = hashlib.sha256(str(time.time()).encode()).hexdigest()
    return cfg_save(cfg)

@app.post("/perm/issue")
def perm_issue(data: dict = Body(...)):
    cfg = cfg_load()
    secret_hex = cfg.get("jws_secret","")
    if not secret_hex: return JSONResponse({"error":"server-misconfig"}, status_code=500)
    try:
        secret = bytes.fromhex(secret_hex)
    except Exception:
        secret = secret_hex.encode()
    now = int(time.time())
    payload = {
        "iss": "Nick",
        "sub": data.get("sub","unknown"),
        "scope": data.get("scope","eval-only"),
        "endpoints": data.get("endpoints", cfg.get("jws_endpoint_prefixes", ["/octet/","/channel/","/planner/"])),
        "anchors": data.get("anchors", []),
        "iat": now,
        "nbf": data.get("nbf", now),
        "exp": now + int(data.get("ttl_sec", 86400)),
        "jti": f"perm-{now}"
    }
    token = sign_hs256(secret, {"alg":"HS256","typ":"JWT"}, payload)
    return {"token": token, "payload": payload}

@app.post("/octet/run")
def octet_run(request: Request, lanes: list = Body(...)):
    ok, detail = jws_ok(request)
    if not ok: return JSONResponse({"error":"permission token","detail":detail}, status_code=401)
    # Demo: echo lanes and time
    return {"ok": True, "lanes": lanes, "ts": time.time()}

@app.post("/channel/prefire")
def channel_prefire(request: Request, payload: dict = Body(...)):
    ok, detail = jws_ok(request)
    if not ok: return JSONResponse({"error":"permission token","detail":detail}, status_code=401)
    return {"ok": True, "prefire": payload}

@app.post("/planner/run")
def planner_run(request: Request, data: dict = Body(...)):
    ok, detail = jws_ok(request)
    if not ok: return JSONResponse({"error":"permission token","detail":detail}, status_code=401)
    return {"ok": True, "plan": {"steps": 1, "note": "demo"}, "req": data}
