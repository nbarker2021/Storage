import sqlite3, math, statistics, json, pathlib, yaml
from kernel.telemetry import emit

DB = "rmi/snaplat.db"

def _conn():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    return con

def _cfg():
    p = pathlib.Path("policy/mdhg.yaml")
    if p.exists():
        try: 
            return yaml.safe_load(p.read_text(encoding='utf-8')) or {}
        except Exception:
            return {}
    return {}

def _scores(endpoint_id: str, horizon: int) -> list[float]:
    con = _conn(); cur = con.cursor()
    rows = cur.execute("SELECT score FROM i8_topk WHERE choice_id=? ORDER BY created_at DESC LIMIT ?", (endpoint_id, horizon)).fetchall()
    xs = [float(r['score'] or 0.0) for r in rows]
    xs.reverse()  # chronological
    return xs

def ema(xs, alpha):
    tau = 0.0
    for x in xs:
        tau = alpha*x + (1-alpha)*tau
    return tau

def cusum(xs, k=0.02, h=0.15):
    # Page-Hinkley-like two-sided CUSUM over [0,1] scores
    gpos = 0.0; gneg = 0.0; m = statistics.fmean(xs) if xs else 0.5
    cp_score = 0.0; drift = False
    for x in xs:
        s = x - (m + k)
        gpos = max(0.0, gpos + s)
        s2 = (m - k) - x
        gneg = max(0.0, gneg + s2)
        cp_score = max(cp_score, gpos, gneg)
        if gpos > h or gneg > h:
            drift = True
    return drift, cp_score

def ci_mean(xs, alpha=0.05):
    if not xs: return (0.0, 0.0, 0.0)
    n = len(xs)
    mu = statistics.fmean(xs)
    sd = statistics.pstdev(xs) if n>1 else 0.0
    # Normal approximation CI
    import math
    z = 1.959963984540054 if alpha<=0.05 else 1.6448536269514722
    se = sd / max(1.0, math.sqrt(n))
    return mu, max(0.0, mu - z*se), min(1.0, mu + z*se)

def stability_summary(endpoint_id: str) -> dict:
    cfg = _cfg()
    horizon = int(cfg.get('horizon', 400))
    xs = _scores(endpoint_id, horizon)
    if not xs:
        emit('mdhg.v2.empty','mdhg', {'endpoint': endpoint_id})
        return {'n':0,'tau':0.0,'delta':0.0,'var':0.0,'band':'low','drift':False,'cp_score':0.0,'mu':0.0,'ci':[0.0,0.0]}
    # Δ & τ
    alpha = 2/(min(len(xs), 20)+1)
    tau = ema(xs, alpha)
    delta = 0.0 if len(xs)<2 else sum(abs(xs[i]-xs[i-1]) for i in range(1,len(xs)))/(len(xs)-1)
    var = statistics.pvariance(xs) if len(xs)>1 else 0.0
    mu, lo, hi = ci_mean(xs, cfg.get('ci_alpha', 0.05))
    # Bands
    bh_tau, bh_delta = float(cfg.get('band_high_tau',0.7)), float(cfg.get('band_high_delta',0.05))
    bm_tau, bm_delta = float(cfg.get('band_med_tau',0.5)), float(cfg.get('band_med_delta',0.10))
    if tau >= bh_tau and delta <= bh_delta:
        band = 'high'
    elif tau >= bm_tau and delta <= bm_delta:
        band = 'medium'
    else:
        band = 'low'
    # Drift (CUSUM)
    drift, cp = cusum(xs, float(cfg.get('cusum_k',0.02)), float(cfg.get('cusum_h',0.15)))
    out = {'endpoint': endpoint_id, 'n': len(xs), 'tau': tau, 'delta': delta, 'var': var, 'band': band, 'drift': drift, 'cp_score': cp, 'mu': mu, 'ci': [lo, hi]}
    emit('mdhg.v2.summary','mdhg', out)
    return out
