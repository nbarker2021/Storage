from kernel.db_helpers import insert_overlay
from policy.helpers import get_delta_threshold, get_tau_max
from triads.snap_agrm_mdhg.mdhg.tau import age_tau, get_tau
from triads.snap_agrm_mdhg.mdhg.features import l2_delta


def check_overlay(members: list[str], routes_with_features: dict) -> (bool, list, dict):
    reasons = []
    info = {"delta": 0.0, "tau": 0}
    if len(set(members)) < 2:
        reasons.append("overlay.members.invalid")
        return (False, reasons, info)
    a, b = members[0], members[1]
    sa = routes_with_scores.get(a, 0.5)
    sb = routes_with_scores.get(b, 0.5)
    delta = abs(sa - sb)             # Δ := score difference (0..1)
    info["delta"] = delta
    info["tau"] = 1
    if delta > get_delta_tau_threshold():
        reasons.append("delta_tau.violation")
        return (False, reasons, info)
    oid = f"ov_{a}_{b}"
    insert_overlay(overlay_id=oid, members=members)
    # τ aging and policy cap
    pol = load_policy()
    tau_max = pol['doc']['policy']['statements'][3]['bounds'].get('tau_max', 8) if pol else 8
    age_tau(oid, 1)
    info['tau'] = get_tau(oid)
    if info['tau'] > tau_max:
        reasons.append('tau.cap.exceeded')
        return (False, reasons, info)
    return (True, reasons, info)
