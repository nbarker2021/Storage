import pathlib, yaml
from kernel.telemetry import emit
from .signals_v2 import stability_summary

def _cfg():
    p = pathlib.Path("policy/mdhg.yaml")
    if p.exists():
        try: 
            return yaml.safe_load(p.read_text(encoding='utf-8')) or {}
        except Exception:
            return {}
    return {}

def evaluate(endpoint_id: str) -> dict:
    cfg = _cfg()
    s = stability_summary(endpoint_id)
    issues = []
    if s['drift'] and cfg.get('require_no_drift', True):
        issues.append('mdhg.drift.detected')
    min_band = (cfg.get('min_band','low') or 'low').lower()
    order = {'low':0,'medium':1,'high':2}
    if order.get(s['band'],0) < order.get(min_band,0):
        issues.append('mdhg.band.too_low')
    rep = {'endpoint': endpoint_id, 'summary': s, 'issues': issues}
    if issues:
        emit('mdhg.alert','mdhg', rep)
    else:
        emit('mdhg.ok','mdhg', rep)
    return rep
