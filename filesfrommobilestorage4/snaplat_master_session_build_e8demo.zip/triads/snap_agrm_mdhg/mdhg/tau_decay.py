from kernel.db import get_conn, exec_sql, query
import time
from policy.helpers import get_tau_decay

def decay_tau_all():
    """Apply τ decay to all overlays each tick: tau = max(0, tau - decay)."""
    conn = get_conn()
    dec = get_tau_decay()
    rows = query(conn, "SELECT overlay_id, tau FROM overlay_meta", ())
    for r in rows:
        new_tau = max(0, int(r["tau"] - dec))
        exec_sql(conn, "UPDATE overlay_meta SET tau=?, last_used=? WHERE overlay_id=?", (new_tau, int(time.time()*1000), r["overlay_id"]))
