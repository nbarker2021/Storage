
import json, pathlib, time
INBOX = pathlib.Path("outputs/queue/incoming.jsonl")
DONE = pathlib.Path("outputs/queue/processed.jsonl")
INBOX.parent.mkdir(parents=True, exist_ok=True)
if not INBOX.exists(): INBOX.write_text("", encoding="utf-8")
if not DONE.exists(): DONE.write_text("", encoding="utf-8")

def enqueue(kind: str, payload: dict) -> str:
    rec = {"kind": kind, "payload": payload, "created_at": int(time.time()*1000)}
    with INBOX.open("a", encoding="utf-8") as fp:
        fp.write(json.dumps(rec)+"\n")
    return kind

def drain(maxn: int = 50):
    lines = INBOX.read_text(encoding="utf-8").splitlines()
    if not lines: return []
    take = lines[:maxn]; rest = lines[maxn:]
    INBOX.write_text("\n".join(rest)+("\n" if rest else ""), encoding="utf-8")
    jobs = [json.loads(x) for x in take]
    return jobs

def mark_done(rec: dict):
    with DONE.open("a", encoding="utf-8") as fp:
        fp.write(json.dumps(rec)+"\n")
