from dataclasses import dataclass
from typing import List, Dict, Any
from .core import Agency, Job, register
from kernel.telemetry import emit
from triads.sap_snapops_archivist.archivist.cas import put
from ecc.snap_e8 import SnapE8

@dataclass
class E8QuantizeAgency(Agency):
    name: str = "e8_quant"
    scale: float = 1.0

    def run(self, job: Job) -> dict:
        payload = job.payload or {}
        vecs: List[List[float]] = payload.get("vectors", [])
        if not vecs:
            return {"ok": False, "error": "no vectors", "count": 0}
        q = SnapE8(scale=self.scale)
        out = q.encode_batch(vecs)
        # write CAS per vector cell_id for auditability (small)
        hashes = []
        for rec in out:
            h = put({"cell_id": rec["cell_id"], "residual": rec["residual"]})
            hashes.append(h)
        emit("e8.quantized", "agency", {"count": len(out), "scale": self.scale})
        return {"ok": True, "count": len(out), "cas": hashes}

# register on import
register(E8QuantizeAgency())
