DEFAULT = {"cpu_ms": 50, "io_ops": 100}

def for_tick(t: int):
    return DEFAULT
