from dataclasses import dataclass
from typing import Dict, Any, List
from kernel.telemetry import emit
from kernel.tick import begin_tick
from triads.sap_snapops_archivist.snapops import budgets as B, env as E
from triads.pipelines.e8_source import vectors_from_docs
import triads.agencies.e8_quant  # ensure registration
from triads.agencies.core import Job, get

@dataclass
class RunConfig:
    docs_dir: str
    batch: int = 16

def run_tick(tick_index: int, cfg: RunConfig) -> Dict[str, Any]:
    t = begin_tick()  # logical tick advance
    assert t == tick_index or t >= 0
    budget = B.for_tick(t)
    _env = E.build(t, seed=0)
    emit("tick.start", "runner_e8", {"t": t, "budget": budget})

    # Build batch of vectors
    vecs: List[List[float]] = vectors_from_docs(cfg.docs_dir, limit=cfg.batch)
    agency = get("e8_quant")
    res = agency.run(Job(kind="quantize", payload={"vectors": vecs}, created_at=0))
    emit("tick.e8", "runner_e8", {"t": t, "count": res.get("count", 0)})

    return {"t": t, "status": "OK" if res.get("ok") else "FAIL", "count": res.get("count", 0)}
