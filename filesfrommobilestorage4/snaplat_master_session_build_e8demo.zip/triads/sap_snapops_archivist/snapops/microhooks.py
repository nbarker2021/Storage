from kernel.telemetry import emit
import time

TEMPLATE = ["understand","plan","execute","critique","fix","record"]

def run_for(endpoint_id:str, label:str):
    for s in TEMPLATE:
        emit(f"microjob.{s}", "snapops", {"endpoint": endpoint_id, "label": label, "step": s, "t": int(time.time()*1000)})
