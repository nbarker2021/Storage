import json, time, pathlib
from .cas import put
from utils.fs import atomic_write
from kernel.telemetry import emit

def write_attestation(endpoint_id: str, manifest_cas: str, provenance_cas: str, signature: dict|None) -> str:
    rec = {
        "kind": "attestation",
        "endpoint_id": endpoint_id,
        "created_at": int(time.time()*1000),
        "manifest_cas": manifest_cas,
        "provenance_cas": provenance_cas,
        "signature": signature or {},
    }
    h = put(rec)
    # index pointer
    idx = pathlib.Path('outputs/index/attest') / f"{endpoint_id}-{rec['created_at']}.json"
    idx.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(idx, json.dumps({"cas_hash": h, "endpoint_id": endpoint_id, "created_at": rec['created_at']}, sort_keys=True).encode('utf-8'))
    # Trail
    emit('assembly.attest', 'asm', {"endpoint_id": endpoint_id, "manifest": manifest_cas, "provenance": provenance_cas, "attestation": h})
    return h
