import json, hashlib, pathlib
from utils.fs import atomic_write

ROOT = pathlib.Path("outputs/cas")

def _shard(h: str) -> pathlib.Path:
    return ROOT / h[:2] / h[2:4]

def put(obj: dict) -> str:
    ROOT.mkdir(parents=True, exist_ok=True)
    blob = json.dumps(obj, sort_keys=True, separators=(',',':')).encode('utf-8')
    h = hashlib.sha256(blob).hexdigest()
    shard = _shard(h)
    shard.mkdir(parents=True, exist_ok=True)
    path = shard / f"{h}.json"
    if not path.exists():
        atomic_write(path, blob)
    return h

def get(h: str) -> dict|None:
    p = _shard(h) / f"{h}.json"
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))

def exists(h: str) -> bool:
    return (_shard(h) / f"{h}.json").exists()
