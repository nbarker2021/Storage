import pathlib, re
from typing import List, Dict

def read_docs(root: pathlib.Path):
    docs = []
    for p in root.rglob("*.md"):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
            docs.append({"id": p.as_posix(), "text": text})
        except Exception:
            pass
    for p in root.rglob("*.txt"):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
            docs.append({"id": p.as_posix(), "text": text})
        except Exception:
            pass
    return docs

def toy_vec8(text: str) -> List[float]:
    toks = re.findall(r"[a-z0-9]+", text.lower())[:32]
    v = [float(len(t)) for t in toks[:8]]
    if len(v) < 8:
        v += [0.0]*(8-len(v))
    return v

def vectors_from_docs(root: str, limit: int|None=None) -> List[List[float]]:
    docs = read_docs(pathlib.Path(root))
    vecs = [toy_vec8(d["text"]) for d in docs]
    if limit is not None:
        vecs = vecs[:limit]
    return vecs
