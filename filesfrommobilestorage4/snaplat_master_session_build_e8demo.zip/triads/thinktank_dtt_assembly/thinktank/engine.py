from kernel.telemetry import emit
from kernel.personas import select_for
import time, itertools, random

def _seed_variants(seed:str, n:int=8):
    random.seed(hash(seed) % (2**32))
    return [f"{seed} :: variant_{i}_{random.randint(10,99)}" for i in range(n)]

def generate_8_plus_8(subject:str, domain:str|None=None, domains:list[str]|None=None) -> dict:
    """Produce 8 hypotheses + 8 dichotomies for a subject, tagged by personas.
    Emits trails with kind 'thinktank.hypotheses' and returns a CAS-like object.
    """
    doms = domains if domains else ([domain] if domain else ['general'])
persona_set = []
for d in doms:
    persona_set.extend(select_for(d, k=2))
# de‑dup and keep order by weight (select_for already sorts)
pnames = []
seen = set()
for p in persona_set:
    if p['name'] not in seen:
        pnames.append(p['name']); seen.add(p['name'])
    hyps = _seed_variants(subject+"/H", 8)
    dich = _seed_variants(subject+"/D", 8)
    payload = {
        "subject": subject,
        "domain": domain or "general",
        "personas": pnames,
        "hypotheses": hyps,
        "dichotomies": dich,
        "created_at": int(time.time()*1000),
    }
    emit("thinktank.hypotheses", "tt", payload)
    return payload
