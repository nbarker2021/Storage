from kernel.telemetry import emit

DEFAULT_INVARIANTS = [
  {"id":"non_empty_hypotheses","desc":"TT must produce >=8 hypotheses","check": lambda tt: len(tt.get('hypotheses',[]))>=8},
  {"id":"non_empty_dichotomies","desc":"TT must produce >=8 dichotomies","check": lambda tt: len(tt.get('dichotomies',[]))>=8},
  {"id":"distinct_sets","desc":"Hypotheses and dichotomies disjoint","check": lambda tt: set(tt.get('hypotheses',[])).isdisjoint(set(tt.get('dichotomies',[])))},
]

def validate(tt_obj:dict, invariants:list|None=None) -> (bool, list):
    invs = invariants or DEFAULT_INVARIANTS
    fails = []
    ok = True
    for inv in invs:
        try:
            if not inv["check"](tt_obj):
                ok = False; fails.append(inv["id"])
        except Exception:
            ok = False; fails.append(inv["id"])
    emit("dtt.validate", "dtt", {"ok": ok, "fails": fails})
    return ok, fails
