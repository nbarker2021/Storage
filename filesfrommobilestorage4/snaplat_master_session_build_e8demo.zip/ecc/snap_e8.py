from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List, Tuple, Dict, Any, Optional, Callable
import math

from . import e8 as e8core

def _chunk8(vec: List[float]) -> List[float]:
    # pad/truncate to 8 dims
    if len(vec) < 8:
        return vec + [0.0]*(8-len(vec))
    return vec[:8]

@dataclass
class SnapE8:
    """Portable E8 helper for on-demand work across the system.
    - scale: multiply inputs before lattice projection to trade distortion vs occupancy.
    - pre: optional preprocessing function (e.g., whitening/Hadamard). Kept pure & tick-safe.
    """
    scale: float = 1.0
    pre: Optional[Callable[[List[float]], List[float]]] = None

    # ---- Core API ----
    def nearest(self, vec: List[float]) -> e8core.E8Code:
        v = _chunk8(vec)
        if self.pre: v = self.pre(v)
        v = [x*self.scale for x in v]
        return e8core.nearest(v)

    def encode(self, vec: List[float]) -> Tuple[str, List[float]]:
        v = _chunk8(vec)
        vpre = self.pre(v) if self.pre else v
        vsc = [x*self.scale for x in vpre]
        cid, resid_sc = e8core.encode(vsc)
        # unscale residual back to original units
        resid = [r/self.scale for r in resid_sc] if self.scale != 0 else resid_sc
        return cid, resid

    def decode(self, cid: str) -> List[float]:
        vsc = e8core.decode(cid)          # scaled & preprocessed space
        # unscale
        v = [x/self.scale for x in vsc] if self.scale != 0 else vsc
        # inverse-pre if provided (user must supply a proper inverse if pre != None)
        return v

    def neighbors(self, cid: str, radius: int = 1) -> List[str]:
        return e8core.neighbors(cid, radius=radius)

    # ---- Batch helpers ----
    def encode_batch(self, vecs: Iterable[List[float]]) -> List[Dict[str, Any]]:
        out = []
        for v in vecs:
            cid, resid = self.encode(v)
            out.append({"cell_id": cid, "residual": resid})
        return out

    def bucketize(self, vecs: Iterable[List[float]]) -> Dict[str, List[int]]:
        """Return a mapping of cell_id -> list of indices (for quick grouping)."""
        buckets: Dict[str, List[int]] = {}
        for idx, v in enumerate(vecs):
            cid, _ = self.encode(v)
            buckets.setdefault(cid, []).append(idx)
        return buckets

    def search(self, vec: List[float], buckets: Dict[str, List[int]], radius: int = 1) -> List[str]:
        """Return candidate cell_ids (same cell + neighbors)."""
        cid, _ = self.encode(vec)
        cands = list(buckets.get(cid, []))
        for n in self.neighbors(cid, radius=radius):
            cands += buckets.get(n, [])
        # return as cell_ids, duplicates removed while preserving order
        seen = set(); out = []
        for idx in cands:
            key = idx
            if key not in seen:
                seen.add(key); out.append(key)
        return out
