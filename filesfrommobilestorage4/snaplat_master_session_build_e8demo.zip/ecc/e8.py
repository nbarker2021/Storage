from dataclasses import dataclass
from math import floor
from typing import List, Tuple

@dataclass(frozen=True)
class E8Code:
    # Store lattice point as ints; if half=True, these represent twice-the-value.
    y: Tuple[int, ...]
    half: bool

def _round_nearest(x: float) -> int:
    return int(floor(x + 0.5))

def _coset_candidate(x: List[float], half: bool) -> List[float]:
    # Shift by 0.5 for half-integer coset, round, enforce even parity by wrong-way rounding on least reliable coord.
    z = [xi + (0.5 if half else 0.0) for xi in x]
    f = [_round_nearest(v) for v in z]
    s = sum(f)
    if (s % 2) != 0:
        r = [z[i] - f[i] for i in range(8)]
        i = max(range(8), key=lambda k: abs(r[k]))
        f[i] += -1 if r[i] > 0 else 1
    if half:
        return [fi - 0.5 for fi in f]
    return [float(fi) for fi in f]

def _sqdist(a: List[float], b: List[float]) -> float:
    return sum((ai - bi)**2 for ai, bi in zip(a, b))

def nearest(vec8: List[float]) -> E8Code:
    assert len(vec8) == 8, "E8 requires 8D vectors"
    yI = _coset_candidate(vec8, half=False)
    yH = _coset_candidate(vec8, half=True)
    if _sqdist(vec8, yI) <= _sqdist(vec8, yH):
        return E8Code(tuple(int(round(v)) for v in yI), half=False)
    else:
        # store half-coset as doubled integers (so we remain integral)
        return E8Code(tuple(int(round(2*v)) for v in yH), half=True)

def decode_point(code: E8Code) -> List[float]:
    if code.half:
        return [v/2 for v in code.y]
    return [float(v) for v in code.y]

def cell_id(code: E8Code) -> str:
    return ("H:" if code.half else "I:") + ",".join(str(v) for v in code.y)

def parse_cell_id(cid: str) -> E8Code:
    half = cid.startswith("H:")
    nums = tuple(int(s) for s in cid.split(":",1)[1].split(","))
    return E8Code(nums, half)

def encode(vec8: List[float]) -> Tuple[str, List[float]]:
    code = nearest(vec8)
    y = decode_point(code)
    resid = [a - b for a,b in zip(vec8, y)]
    return cell_id(code), resid

def decode(cid: str) -> List[float]:
    return decode_point(parse_cell_id(cid))

def neighbors(cid: str, radius: int = 1) -> List[str]:
    code = parse_cell_id(cid)
    base = list(code.y)
    out = []
    if code.half:
        # neighbors by modifying doubled-integers by +/-2 on one coordinate
        for i in range(8):
            for d in (-2, 2):
                v = base.copy(); v[i] += d
                out.append(("H:" + ",".join(map(str, v))))
    else:
        # integer coset neighbors: +/-1 on one coordinate, then parity-fix by toggling another (+/-1)
        for i in range(8):
            for d in (-1, 1):
                v = base.copy(); v[i] += d
                # fix parity by adjusting next index (wrap)
                j = (i+1) % 8
                v[j] += 1 if d < 0 else -1
                out.append(("I:" + ",".join(map(str, v))))
    return out
