import sqlite3, json, re

DB = "rmi/snaplat.db"

PAN_RE = re.compile(r"\b(?:\d[ -]*?){13,19}\b")
CVV_KEYS = ('cvv','cvc','csc')
PHI_FIELDS = ('diagnosis','medication','mrn','icd10')
PII_EDU = ('ssn','dob','student_ssn','guardian_ssn')
PSEUDO_PREFIX = 'stu_'

def _conn():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    return con

def _latest_trails(kinds=('ingest.record',), limit=200):
    con = _conn(); cur = con.cursor()
    return cur.execute("SELECT payload FROM trails WHERE kind IN (%s) ORDER BY created_at DESC LIMIT %d" % (",".join("?"*len(kinds)), limit), kinds).fetchall()

def _latest_consent() -> bool:
    for r in _latest_trails():
        try:
            p = json.loads(r['payload'] or "{}")
            if p.get("consent", False): return True
        except Exception:
            pass
    return False

def enforce(domain: str|None, endpoint_id: str|None) -> tuple[bool, list]:
    reasons = []; ok = True
    d = (domain or '').lower()

    if d in ('healthcare','medical','health'):
        if not _latest_consent():
            ok = False; reasons.append('law.hipaa.consent.missing')
        # if PHI fields present, require phi_masked = True
        for r in _latest_trails():
            try:
                p = json.loads(r['payload'] or "{}")
                if any(k in p for k in PHI_FIELDS):
                    if not p.get('phi_masked', False):
                        ok = False; reasons.append('law.hipaa.phi.unmasked'); break
            except Exception:
                pass

    if d in ('finance','fintech'):
        balanced = False; pan_found = False; cvv_present = False
        for r in _latest_trails(limit=200):
            try:
                p = json.loads(r['payload'] or '{}')
                deb = sum(p.get('debits',[]) or [0]); cred = sum(p.get('credits',[]) or [0])
                if deb == cred and deb>0: balanced = True
                if 'pan' in p and PAN_RE.search(str(p['pan'])): pan_found = True
                if any(k in p for k in CVV_KEYS): cvv_present = True
            except Exception:
                pass
        if not balanced:
            ok = False; reasons.append('law.pci.ledger.unbalanced')
        if pan_found and not any('token' in (r or '').lower() for r in ['%s'%p]):
            ok = False; reasons.append('law.pci.pan.present')
        if cvv_present:
            ok = False; reasons.append('law.pci.cvv.present')

    if d in ('education','edtech'):
        for r in _latest_trails(limit=200):
            try:
                p = json.loads(r['payload'] or '{}')
                if any(k in p for k in PII_EDU):
                    ok = False; reasons.append('law.ferpa.pii.present'); break
                sid = p.get('student_id')
                if sid and not str(sid).startswith(PSEUDO_PREFIX):
                    ok = False; reasons.append('law.ferpa.student_id.not_pseudonymized'); break
            except Exception:
                pass

    return ok, reasons
