import click, pathlib, json
from triads.sap_snapops_archivist.snapops.runner_e8 import run_tick, RunConfig
from kernel.telemetry import emit

@click.command()
@click.option("--ticks", default=1, help="How many ticks to run")
@click.option("--docs", default="docs", help="Docs directory to vectorize")
@click.option("--batch", default=16, help="Vectors per tick")
def main(ticks, docs, batch):
    pathlib.Path("outputs/reports").mkdir(parents=True, exist_ok=True)
    cfg = RunConfig(docs_dir=docs, batch=batch)
    status = []
    for i in range(ticks):
        res = run_tick(i, cfg)
        status.append(res)
        emit("tick.done", "runner_e8", res)
    print(json.dumps(status, indent=2))
    # build trails index for convenience
    try:
        import subprocess
        subprocess.run(["python","tools/trailview.py"], check=False)
    except Exception:
        pass

if __name__ == "__main__":
    main()
