import json, time, pathlib, os

TRAILS_DIR = pathlib.Path("outputs/trails")
TRAILS_DIR.mkdir(parents=True, exist_ok=True)
TRAILS = TRAILS_DIR / "trails.jsonl"
MAX_LINES = 200000

def emit(kind: str, thing: str, payload: dict):
    rec = {
        "kind": kind,
        "thing": thing,
        "payload": payload or {},
        "created_at": int(time.time()*1000)
    }
    TRAILS.parent.mkdir(parents=True, exist_ok=True)
    with open(TRAILS, "a", encoding="utf-8") as fp:
        fp.write(json.dumps(rec) + "\n")
    try:
        if TRAILS.exists():
            # naive line-count rotation
            with open(TRAILS, "r", encoding="utf-8") as f:
                for i, _ in enumerate(f, 1):
                    if i > MAX_LINES:
                        rot = TRAILS_DIR / f"trails.{int(time.time())}.jsonl"
                        os.replace(TRAILS, rot)
                        break
    except Exception:
        pass
