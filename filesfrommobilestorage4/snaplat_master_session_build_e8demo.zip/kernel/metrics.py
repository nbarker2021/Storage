import time, json, pathlib, threading

OUTDIR = pathlib.Path("outputs/metrics")
OUTDIR.mkdir(parents=True, exist_ok=True)

_lock = threading.Lock()
_counters = {}
_durations = {}

def inc(name: str, by: int = 1, bytes: int = 0):
    with _lock:
        m = _counters.setdefault(name, {"count":0, "bytes":0})
        m["count"] += by
        m["bytes"] += bytes

def observe(name: str, seconds: float):
    with _lock:
        m = _durations.setdefault(name, {"count":0, "sum":0.0, "max":0.0})
        m["count"] += 1
        m["sum"] += float(seconds)
        if seconds > m["max"]:
            m["max"] = float(seconds)

class timer:
    def __init__(self, name: str):
        self.name = name
        self.t0 = None
    def __enter__(self):
        self.t0 = time.perf_counter(); return self
    def __exit__(self, exc_type, exc, tb):
        dt = time.perf_counter() - self.t0
        observe(self.name, dt)

def dump() -> dict:
    with _lock:
        return {"counters": dict(_counters), "durations": dict(_durations), "t": int(time.time()*1000)}

def flush_json():
    data = dump()
    p = OUTDIR / "metrics.json"
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    return str(p)
