# Retrieval Evaluation (Baseline vs E8 stub)
- Docs: Markdown/TXT under `docs/` (demo docs provided).
- Queries: `eval/bench.yaml`
- Run:
```bash
python eval/harness.py --docs docs --queries eval/bench.yaml --method baseline --k 5
python eval/harness.py --docs docs --queries eval/bench.yaml --method e8 --k 5
```
- Output: JSON with P@k and R@k for each query.
