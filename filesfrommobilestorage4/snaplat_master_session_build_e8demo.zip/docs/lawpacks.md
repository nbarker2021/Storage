# LawPacks (Configurable domain enforcement)

Location: `policy/lawpacks/*.yaml`

- `privacy.yaml`: consent-required PII fields list
- `legal.yaml`: export control toggle
- `finance.yaml`: `balance_tolerance` for double-entry checks
- `healthcare.yaml`: PHI fields with consent requirement
- `education.yaml`: FERPA-like fields with consent requirement

CTO builds an enriched slice from recent Trails and enforces the active packs. Violations emit `lawpack.evaluate` with reasons.
