# SnapE8 API (standalone E8 helper)

```python
from ecc.snap_e8 import SnapE8
q = SnapE8(scale=1.0)           # optional: supply a whitening function via pre=
cid, resid = q.encode([0.2,0.1,0.3,0.0, -0.1, 0.05, 0.4, 0.9])
point = q.decode(cid)
nbrs = q.neighbors(cid)
```

## Agency usage
```python
from triads.agencies.core import Job, get
agency = get("e8_quant")
res = agency.run(Job(kind="quantize", payload={"vectors":[[0.1]*8, [0.2]*8]}, created_at=0))
```
- Emits a trail: `e8.quantized`
- Writes compact CAS entries with `cell_id` + `residual`
