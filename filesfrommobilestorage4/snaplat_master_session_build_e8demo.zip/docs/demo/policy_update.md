# Policy Update Procedure
A governance update is recorded and emitted as a telemetry trail. Policies live under the policy/ folder.
