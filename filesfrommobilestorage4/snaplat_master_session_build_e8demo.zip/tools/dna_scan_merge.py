
#!/usr/bin/env python3
import json, pathlib
from triads.sap_snapops_archivist.snapdna_v2 import compare

CAS = pathlib.Path("outputs/cas")
OUT = pathlib.Path("outputs/dna"); OUT.mkdir(parents=True, exist_ok=True)

def load_records(kind):
    out = []
    if not CAS.exists():
        return out
    for sh in CAS.iterdir():
        if not sh.is_dir(): 
            continue
        for f in sh.iterdir():
            if not f.name.endswith(".json"): 
                continue
            try:
                obj = json.loads(f.read_text(encoding='utf-8'))
                if obj.get('kind') == kind:
                    out.append(obj)
            except Exception:
                pass
    return out

def main(threshold=0.8):
    recs = load_records('snap_dna_v2')
    dups = []
    for i in range(len(recs)):
        for j in range(i+1,len(recs)):
            s = compare(recs[i], recs[j])
            if s >= threshold:
                dups.append((recs[i].get('payload',{}).get('kind',''), recs[i].get('dna'), recs[j].get('dna'), round(s,3)))
    outp = OUT/'duplicates.json'
    outp.write_text(json.dumps(dups, indent=2), encoding='utf-8')
    print(outp)

if __name__ == "__main__":
    main()
