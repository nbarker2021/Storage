#!/usr/bin/env python3
import json, time, sys
from triads.sap_snapops_archivist.archivist.cas import put

TEMPLATES = {
  "agent":        lambda: {"kind":"agent","agent_id":"a-"+str(int(time.time()*1000)),"roles":["worker"]},
  "failure":      lambda: {"kind":"failure","at":int(time.time()*1000),"component":"pipeline","reason":"unknown"},
  "conversation": lambda: {"kind":"conversation","thread_id":"t-"+str(int(time.time()*1000)),"messages":[]},
  "dataset":      lambda: {"kind":"dataset","dataset_id":"d-"+str(int(time.time()*1000)),"format":"jsonl"},
  "overlay":      lambda: {"kind":"overlay","overlay_id":"ov-"+str(int(time.time()*1000))},
  "route":        lambda: {"kind":"route","route_id":"r-"+str(int(time.time()*1000)),"universe_id":"u1"},
  "endpoint":     lambda: {"kind":"endpoint","endpoint_id":"ep-"+str(int(time.time()*1000)),"universe_id":"u1"},
  "test":         lambda: {"kind":"test","name":"smoke","result":"pass"},
  "policy":       lambda: {"kind":"policy","policy_id":"p-"+str(int(time.time()*1000)),"version":1},
  "persona":      lambda: {"kind":"persona","name":"Researcher","domains":["education","governance"]},
}

def main(argv):
  if len(argv) < 1 or argv[0] not in TEMPLATES:
    print("usage: tools/generate_snap.py <" + "|".join(TEMPLATES.keys()) + ">"); return 2
  obj = TEMPLATES[argv[0]]()
  h = put(obj)
  print(h or "denied")
  return 0

if __name__ == "__main__":
  raise SystemExit(main(sys.argv[1:]))
