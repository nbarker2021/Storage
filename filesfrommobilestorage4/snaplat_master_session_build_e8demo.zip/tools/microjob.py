#!/usr/bin/env python3
from kernel.telemetry import emit
import time, json, sys

TEMPLATE = ["understand", "plan", "execute", "critique", "fix", "record"]

def run(job_desc:str):
    steps = []
    for s in TEMPLATE:
        steps.append({"step": s, "t": int(time.time()*1000), "status": "ok"})
        emit(f"microjob.{s}", "mj", {"job": job_desc, "step": s})
    out = {"job": job_desc, "steps": steps}
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    run(" ".join(sys.argv[1:]) or "demo micro job")
