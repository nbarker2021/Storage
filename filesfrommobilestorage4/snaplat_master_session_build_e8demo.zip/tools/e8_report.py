#!/usr/bin/env python3
import json, pathlib, math, sys
from collections import Counter

def main():
    root = pathlib.Path("outputs/cas")
    items = []
    if not root.exists():
        print("no CAS found")
        return
    for p in root.rglob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(obj, dict): continue
        if "cell_id" in obj and "residual" in obj:
            r = obj["residual"]
            dist = math.sqrt(sum(float(x)*float(x) for x in r))
            items.append((obj["cell_id"], dist))
    occ = Counter(cid for cid,_ in items)
    dists = [d for _,d in items]
    report = {
        "count": len(items),
        "top_cells": occ.most_common(20),
        "distortion": {
            "mean": round(sum(dists)/len(dists), 6) if dists else 0.0,
            "max": round(max(dists), 6) if dists else 0.0,
        }
    }
    out_json = pathlib.Path("outputs/reports/e8_metrics.json")
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(report, indent=2), encoding="utf-8")

    # simple HTML
    html = ["<html><head><meta charset='utf-8'><title>E8 Metrics</title>",
            "<style>body{font-family:ui-sans-serif;margin:24px} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style>",
            "</head><body>",
            "<h1>E8 Metrics</h1>",
            f"<p>Vectors quantified: {report['count']}</p>",
            f"<p>Mean distortion: {report['distortion']['mean']}, Max: {report['distortion']['max']}</p>",
            "<h2>Top cells</h2><table><tr><th>cell_id</th><th>count</th></tr>"]
    for cid, c in report["top_cells"]:
        html.append(f"<tr><td><code>{cid}</code></td><td>{c}</td></tr>")
    html.append("</table></body></html>")
    out_html = pathlib.Path("outputs/reports/e8_metrics.html")
    out_html.write_text("\n".join(html), encoding="utf-8")
    print("wrote", out_json, "and", out_html)

if __name__ == "__main__":
    main()
