#!/usr/bin/env python3
import json, pathlib, collections

TRAILS = pathlib.Path("outputs/trails/trails.jsonl")
OUT = pathlib.Path("outputs/dash/policy_reasons.html")

def main():
    counts = collections.Counter()
    if TRAILS.exists():
        for line in TRAILS.read_text(encoding='utf-8').splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get('kind') in ('safecube.check','assembly.blocked'):
                rs = rec.get('payload',{}).get('reasons',[]) or rec.get('payload',{}).get('proof',{}).get('reasons',[])
                for r in rs:
                    counts[r] += 1
    rows = "\n".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k,v in counts.most_common())
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(f"""
    <html><body><h3>Policy Reasons Report</h3>
    <table border='1'><tr><th>reason</th><th>count</th></tr>
    {rows}
    </table></body></html>
    """, encoding='utf-8')
    print(OUT)

if __name__ == "__main__":
    main()
