#!/usr/bin/env python3
from kernel.metrics import flush_json, dump
import json, pathlib

def main():
    path = flush_json()
    data = dump()
    # emit simple HTML
    html = pathlib.Path("outputs/metrics/report.html")
    rows = []
    for k,v in sorted(data['counters'].items()):
        rows.append(f"<tr><td>{k}</td><td>{v['count']}</td><td>{v.get('bytes',0)}</td></tr>")
    for k,v in sorted(data['durations'].items()):
        rows.append(f"<tr><td>{k}</td><td>{v['count']}</td><td>{v['sum']:.6f}s (max {v['max']:.6f})</td></tr>")
    html.write_text("""
    <html><body><h3>SnapLat Metrics</h3>
    <table border="1"><tr><th>metric</th><th>count</th><th>value</th></tr>
    %s
    </table></body></html>
    """ % "\n".join(rows), encoding='utf-8')
    print(path)

if __name__ == "__main__":
    main()
