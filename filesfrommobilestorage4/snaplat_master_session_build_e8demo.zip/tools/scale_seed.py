#!/usr/bin/env python3
import sqlite3, time, random, argparse

DB = "rmi/snaplat.db"

def seed_routes(n=1000):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS routes(route_id TEXT PRIMARY KEY, universe_id TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS endpoints(endpoint_id TEXT PRIMARY KEY, universe_id TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS lineage_edges(src_id TEXT, dst_id TEXT, weight REAL)")
    for i in range(n):
        r = f"rS{i}"; e = f"epS{i%50}"
        cur.execute("INSERT OR IGNORE INTO routes(route_id, universe_id) VALUES(?,?)", (r, "uS"))
        cur.execute("INSERT OR IGNORE INTO endpoints(endpoint_id, universe_id) VALUES(?,?)", (e, "uS"))
        cur.execute("INSERT INTO lineage_edges(src_id, dst_id, weight) VALUES(?,?,?)", (r, e, 1.0))
    con.commit(); con.close()

def seed_topk(m=8000):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS i8_topk(octant INTEGER, choice_id TEXT, choice_kind TEXT, score REAL, created_at INTEGER)")
    now = int(time.time()*1000)
    for i in range(m):
        o = (i % 8) + 1
        ep = f"epS{i%50}"
        sc = 0.4 + 0.2*random.random()
        cur.execute("INSERT INTO i8_topk(octant, choice_id, choice_kind, score, created_at) VALUES(?,?,?,?,?)", (o, ep, "endpoint", sc, now - (m-i)))
    con.commit(); con.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--routes", type=int, default=1000)
    ap.add_argument("--topk", type=int, default=8000)
    args = ap.parse_args()
    seed_routes(args.routes); seed_topk(args.topk)
    print("seeded")

if __name__ == "__main__":
    main()
