from triads.sap_snapops_archivist.archivist.provenance import write_provenance
from triads.thinktank_dtt_assembly.assembly.publish import build_lockfile

def test_provenance_in_manifest(monkeypatch):
    prov = write_provenance('epZ', {'hello':'world'})
    man = build_lockfile({'endpoint_id':'epZ','evidence_nodes':1729,'evidence_edges':3,'provenance':prov})
    assert man.get('provenance') == prov
