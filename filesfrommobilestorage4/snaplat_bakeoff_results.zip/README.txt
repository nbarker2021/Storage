SnapLat bake-off artifacts: results CSVs and score plots.
Synthetic harness; proxies only.
