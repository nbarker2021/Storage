#!/usr/bin/env python3
import json, pathlib, sys

def main():
    path = pathlib.Path("outputs/trails/trails.jsonl")
    out = pathlib.Path("outputs/trails/index.html")
    q = None
    if len(sys.argv) > 1:
        q = sys.argv[1]
    if not path.exists():
        print("[trailview] no trails yet"); return
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if q:
        rows = [r for r in rows if q in r['kind']]
    html = ["<html><head><meta charset='utf-8'><title>Trails</title><style>body{font-family:monospace} .row{margin:6px;padding:6px;border-bottom:1px solid #ccc} .meta{color:#666} a{color:#06c; text-decoration:none}</style></head><body>"]
    if q: html.append(f"<div>Filter: <b>{q}</b></div>")
    for r in rows[-500:]:
        payload = r['payload']
        # auto-link CAS hash if present
        link = ''
        for k in ('lockfile','hash'):
            h = payload.get(k)
            if isinstance(h, str) and len(h)>=8:
                link = f" <a href='../cas/{h}.json' target='_blank'>[open {k}]</a>"; break
        html.append(f"""<div class='row'><b>{r['kind']}</b> — <i>{r['thing_id']}</i> — <span class='meta'>{r['created_at']}</span>{link}<br><pre>{json.dumps(payload, indent=2)}</pre></div>""")
    html.append("</body></html>")
    out.write_text("\n".join(html), encoding="utf-8")
    print(f"[trailview] wrote {out}")

if __name__ == "__main__":
    main()
