#!/usr/bin/env python3
import sqlite3, pathlib

DB = pathlib.Path("rmi/snaplat.db")
DDL = [
    "CREATE INDEX IF NOT EXISTS idx_trails_created ON trails(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_i8_topk_octant_created ON i8_topk(octant, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_routes_universe ON routes(universe_id)",
    "CREATE INDEX IF NOT EXISTS idx_endpoints_universe_final ON endpoints(universe_id, finalized)",
    "CREATE INDEX IF NOT EXISTS idx_overlay_members ON overlay_members(overlay_id, member_id)",
    "CREATE INDEX IF NOT EXISTS idx_lineage_edges ON lineage_edges(src_id, dst_id)",
    "CREATE INDEX IF NOT EXISTS idx_octant_stats ON octant_stats(updated_at)",
]

def migrate():
    if not DB.exists():
        print("{\"status\":\"no_db\"}"); return
    con = sqlite3.connect(DB)
    cur = con.cursor()
    for stmt in DDL:
        cur.execute(stmt)
    con.commit()
    cur.execute("VACUUM"); cur.execute("ANALYZE"); con.commit()
    print("{\"status\":\"ok\"}")

if __name__ == "__main__":
    migrate()
