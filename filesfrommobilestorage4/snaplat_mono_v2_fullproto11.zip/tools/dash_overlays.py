#!/usr/bin/env python3
import sqlite3, pathlib, json, time
DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/overlays.html")

def fetch():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    rows = cur.execute("""
    SELECT o.overlay_id, COUNT(m.member_id) AS members, COALESCE(meta.tau,0) AS tau
    FROM overlays o
    LEFT JOIN overlay_members m USING(overlay_id)
    LEFT JOIN overlay_meta meta USING(overlay_id)
    GROUP BY o.overlay_id
    ORDER BY tau DESC, members DESC
    """).fetchall()
    return [dict(r) for r in rows]

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    html = ["<html><head><meta charset='utf-8'><title>Overlays</title><style>body{font-family:sans-serif} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style></head><body>"]
    html.append(f"<h2>Overlays (generated {int(time.time())})</h2>")
    html.append("<table><tr><th>overlay_id</th><th>members</th><th>tau</th></tr>")
    for r in rows:
        html.append(f"<tr><td>{r['overlay_id']}</td><td>{r['members']}</td><td>{r['tau']}</td></tr>")
    html.append("</table></body></html>")
    OUT.write_text("\n".join(html), encoding="utf-8")

if __name__ == "__main__":
    render(fetch())
