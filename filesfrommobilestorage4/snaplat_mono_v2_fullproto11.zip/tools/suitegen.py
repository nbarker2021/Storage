import sys; print('[suitegen] lint ok (stub)')
