#!/usr/bin/env python3
import sqlite3, pathlib, json, time
OUT = pathlib.Path("outputs/metrics.json")

def metric(name, value, labels=None):
    return {"name": name, "value": value, "labels": labels or {}}

def gather():
    con = sqlite3.connect("rmi/snaplat.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    m = []
    # Governance
    row = cur.execute("SELECT COUNT(1) AS c FROM trails WHERE kind LIKE 'gcr.%'").fetchone()
    m.append(metric("trails_gcr_total", row["c"]))
    # Endpoints
    row = cur.execute("SELECT COUNT(1) AS c FROM endpoints WHERE finalized=1").fetchone()
    m.append(metric("endpoints_finalized_total", row["c"]))
    # Overlays
    row = cur.execute("SELECT COUNT(1) AS c FROM overlays").fetchone()
    m.append(metric("overlays_total", row["c"]))
    # TopK rows (current)
    row = cur.execute("SELECT COUNT(1) AS c FROM v_i8_topk_current").fetchone()
    m.append(metric("i8_topk_current_total", row["c"]))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"generated_at": int(time.time()), "metrics": m}, indent=2), encoding="utf-8")
    print(str(OUT))

if __name__ == "__main__":
    gather()
