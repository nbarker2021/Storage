#!/usr/bin/env python3
import sqlite3, pathlib, json, time
DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/topk.html")

def fetch():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    rows = cur.execute("SELECT octant, choice_id, choice_kind, score, created_at FROM v_i8_topk_current ORDER BY octant").fetchall()
    return [dict(r) for r in rows]

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    html = ["<html><head><meta charset='utf-8'><title>Top‑K</title><style>body{font-family:sans-serif} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style></head><body>"]
    html.append(f"<h2>Top‑K (generated {int(time.time())})</h2>")
    html.append("<table><tr><th>octant</th><th>choice_id</th><th>kind</th><th>score</th><th>created_at</th></tr>")
    for r in rows:
        html.append(f"<tr><td>{r['octant']}</td><td>{r['choice_id']}</td><td>{r['choice_kind']}</td><td>{r['score']:.3f}</td><td>{r['created_at']}</td></tr>")
    html.append("</table></body></html>")
    OUT.write_text("\n".join(html), encoding="utf-8")

if __name__ == "__main__":
    render(fetch())
