from .crypto import sign as _sign, verify as _verify, pub_fingerprint as _fp, mode as _mode

def sign_payload(payload: dict) -> str:
    return _sign({k:v for k,v in payload.items() if k != "signature"})

def verify_signature(payload: dict, sig: str) -> bool:
    return _verify(payload, sig)

def signer_fingerprint() -> str:
    return _fp()

def signature_mode() -> str:
    return _mode()
