import json, pathlib, time
from .cas import get, put
from api.governance import barrier_state

STATE = pathlib.Path("outputs/recall_state.json")

def recall_pack(key: str):
    st = barrier_state()
    if st.get("engaged"):
        # recall blocked until revalidated
        return None
    return get(key)

def write_lockfile(endpoint_id: str, payload: dict):
    lf = {"endpoint_id": endpoint_id, "payload": payload, "kind": "lockfile", "policy_bound": True, "ts": int(time.time()*1000)}
    h = put(lf)
    return h
