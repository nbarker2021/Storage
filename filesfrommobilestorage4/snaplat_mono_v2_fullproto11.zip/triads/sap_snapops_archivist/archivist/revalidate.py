import json, pathlib, time
from .cas import get, put
from security.sign import verify_signature, sign_payload
from api.governance import current_policy
from kernel.telemetry import emit

CAS_DIR = pathlib.Path("outputs/cas")

def revalidate_all():
    pol = current_policy()
    updated = []
    invalid = []
    for p in CAS_DIR.glob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        if obj.get("kind") != "lockfile":
            continue
        manifest = obj["payload"]
        sig = manifest.get("signature")
        # verify signature
        if not verify_signature({k:v for k,v in manifest.items() if k != "signature"}, sig or ""):
            invalid.append(p.name)
            emit("lockfile.invalid_signature", "archivist", {"file": p.name})
            continue
        # check policy
        if manifest.get("policy_hash") != pol.get("policy_hash"):
            manifest["policy_hash"] = pol.get("policy_hash")
            manifest["created_at"] = int(time.time()*1000)
            manifest["signature"] = sign_payload({k:v for k,v in manifest.items() if k != "signature"})
            # rewrite CAS object in-place
            obj["payload"] = manifest
            p.write_text(json.dumps(obj, sort_keys=True), encoding="utf-8")
            updated.append(p.name)
            emit("lockfile.revalidated", "archivist", {"file": p.name, "policy_hash": pol.get("policy_hash")})
    return {"updated": updated, "invalid": invalid}
