import json, pathlib, time
from triads.sap_snapops_archivist.archivist.cas import get, put
from kernel.telemetry import emit

CAS = pathlib.Path("outputs/cas")

STATES = ["draft","finalized","revalidated","superseded","retired"]

def _load_all_lockfiles():
    for p in CAS.glob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        if obj.get("kind") == "lockfile":
            yield p, obj

def set_state(hash_id: str, state: str) -> bool:
    assert state in STATES
    obj = get(hash_id)
    if not obj or obj.get("kind") != "lockfile":
        return False
    obj["state"] = state
    obj["state_at"] = int(time.time()*1000)
    path = CAS / f"{hash_id}.json"
    path.write_text(json.dumps(obj, sort_keys=True), encoding="utf-8")
    emit("lockfile.state", "archivist", {"hash": hash_id, "state": state})
    return True

def supersede(old_hash: str, new_hash: str) -> bool:
    ok = set_state(old_hash, "superseded")
    if ok:
        emit("lockfile.superseded", "archivist", {"old": old_hash, "new": new_hash})
    return ok

def retire(hash_id: str) -> bool:
    return set_state(hash_id, "retired")

def gc(retention_days:int=30, keep_latest:int=3):
    """Remove retired/superseded older than retention; keep N latest per endpoint."""
    cutoff = int(time.time()*1000) - retention_days*24*3600*1000
    per_endpoint = {}
    removed = []
    for p, obj in _load_all_lockfiles():
        man = obj.get("payload", {})
        ep = man.get("endpoint_id", "unknown")
        per_endpoint.setdefault(ep, []).append((p, obj))
    for ep, items in per_endpoint.items():
        items.sort(key=lambda x: x[1].get("payload",{}).get("created_at",0), reverse=True)
        # keep head 'keep_latest'
        for p, obj in items[keep_latest:]:
            state = obj.get("state","finalized")
            created = obj.get("payload",{}).get("created_at",0)
            if state in ("retired","superseded") and created < cutoff:
                try:
                    p.unlink(missing_ok=True)
                    removed.append(p.name)
                except Exception:
                    pass
    emit("cas.gc", "archivist", {"removed": removed, "retention_days": retention_days, "keep_latest": keep_latest})
    return {"removed": removed, "retention_days": retention_days, "keep_latest": keep_latest}
