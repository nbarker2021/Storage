from kernel.db import get_conn, exec_sql, query
import time

def age_tau(overlay_id: str, inc:int=1):
    conn = get_conn()
    now = int(time.time()*1000)
    # upsert
    exec_sql(conn, "INSERT OR IGNORE INTO overlay_meta(overlay_id, tau, last_used) VALUES(?,?,?)", (overlay_id, 0, now))
    exec_sql(conn, "UPDATE overlay_meta SET tau = tau + ?, last_used=? WHERE overlay_id=?", (inc, now, overlay_id))

def get_tau(overlay_id: str)->int:
    conn = get_conn()
    rows = query(conn, "SELECT tau FROM overlay_meta WHERE overlay_id=?", (overlay_id,))
    return rows[0]["tau"] if rows else 0
