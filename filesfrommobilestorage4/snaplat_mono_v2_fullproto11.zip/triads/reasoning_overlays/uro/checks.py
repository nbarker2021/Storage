def run_truth_filter(slice_desc: dict) -> (bool, list):
    reasons = []
    if not slice_desc.get("labels") or not slice_desc["labels"].get("family") or not slice_desc["labels"].get("type"):
        reasons.append("missing.labels")
    glyph = slice_desc.get("glyph", {})
    trip = glyph.get("triplet", [])
    if len(trip) != 3:
        reasons.append("missing.triplet")
    return (len(reasons) == 0, reasons)
