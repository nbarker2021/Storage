
from api.governance import current_policy
from security.sign import sign_payload, signer_fingerprint, signature_mode
from security.crypto import key_id
import time

def finalize_1729(endpoint: dict) -> (bool, list):
    reasons = []
    if endpoint.get("evidence_nodes", 0) < 1729:
        reasons.append("evidence.below.1729")
    if len(endpoint.get("k_routes", [])) < 2:
        reasons.append("taxicab.k.lt.2")
    pol = current_policy()
    if pol.get("policy_hash","<none>") == "<none>":
        reasons.append("policy.hash.missing")
    return (len(reasons)==0, reasons)

def build_lockfile(endpoint: dict) -> dict:
    pol = current_policy()
    manifest = {
        "version": 2,
        "endpoint_id": endpoint["endpoint_id"],
        "k_routes": endpoint["k_routes"],
        "evidence_nodes": endpoint.get("evidence_nodes", 0),
        "policy_hash": pol.get("policy_hash","<none>"),
        "created_at": endpoint.get("created_at") or int(time.time()*1000),
        "reports": endpoint.get("reports", []),
        "sig_mode": signature_mode(),
        "signer_fp": signer_fingerprint(),
        "key_id": key_id(),
    }
    manifest["signature"] = sign_payload(manifest)
    return manifest
