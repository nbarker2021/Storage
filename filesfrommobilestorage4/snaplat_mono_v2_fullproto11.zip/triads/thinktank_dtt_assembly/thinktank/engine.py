def expand_8_plus_8(seed_words: list[str]) -> dict:
    rel = [f"rel_{i}_{seed_words[i % len(seed_words)]}" for i in range(8)]
    dich = [f"dich_{i}_{seed_words[(i+1) % len(seed_words)]}" for i in range(8)]
    return {"relevant": rel, "dichotomies": dich}

def rank_and_report(cands: dict) -> dict:
    scored = [{"cand": c, "score": 1.0 - i*0.05} for i, c in enumerate(cands["relevant"])]
    early_exit = True
    return {"ranking": scored, "early_exit": early_exit}


def to_cas(report: dict, put_fn):
    return put_fn(report)
