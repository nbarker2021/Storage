import json, pathlib, yaml
from kernel.telemetry import emit

LAW_DIR = pathlib.Path("policy/lawpacks")

def _load_packs():
    packs = {}
    if not LAW_DIR.exists():
        return packs
    for p in LAW_DIR.glob("*.yaml"):
        try:
            packs[p.stem] = yaml.safe_load(p.read_text(encoding="utf-8"))
        except Exception:
            continue
    return packs

def _check_privacy(slice_desc):
    # deny PII without consent
    pii_keys = {'email','ssn','phone','dob','address'}
    found = [k for k in pii_keys if k in slice_desc]
    if found and not slice_desc.get('consent', False):
        return False, [f"privacy.pii_without_consent:{','.join(found)}"]
    return True, []

def _check_legal(slice_desc):
    # block export-restricted content
    if slice_desc.get('export_restricted', False):
        return False, ["legal.export_control.blocked"]
    return True, []

def _check_finance(slice_desc):
    # If finance fields present, enforce double entry balance
    deb = sum(slice_desc.get('debits', []) or [0])
    cre = sum(slice_desc.get('credits', []) or [0])
    if (slice_desc.get('debits') or slice_desc.get('credits')) and deb != cre:
        return False, [f"finance.unbalanced:{deb}-{cre}"]
    return True, []

def _check_physics(slice_desc):
    # Placeholder: always pass
    return True, []

CHECKS = {
    'privacy': _check_privacy,
    'legal': _check_legal,
    'finance': _check_finance,
    'physics': _check_physics,
}

def enforce_lawpacks(slice_desc: dict) -> (bool, list):
    packs = _load_packs()
    reasons = []
    ok = True
    for name in packs.keys():
        fn = CHECKS.get(name)
        if not fn:
            continue
        passed, rs = fn(slice_desc)
        if not passed:
            ok = False
            reasons.extend(rs)
    emit("lawpack.evaluate", "cto", {"ok": ok, "reasons": reasons})
    return ok, reasons
