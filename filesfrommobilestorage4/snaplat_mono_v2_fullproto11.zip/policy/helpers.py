import yaml, pathlib, hashlib

POLICY_FILE = pathlib.Path("policy/safe-cube-pack-v1.2.yaml")

def policy_hash_text(txt:str)->str:
    return hashlib.blake2b(txt.encode('utf-8'), digest_size=16).hexdigest()

def load_policy():
    if not POLICY_FILE.exists():
        return {"policy": {"name":"safe-cube-pack-v1.2","version":"1.2.0","statements": []}, "policy_hash":"<none>"}
    txt = POLICY_FILE.read_text(encoding="utf-8")
    y = yaml.safe_load(txt)
    return {"doc": y, "text": txt, "policy_hash": policy_hash_text(txt)}

def get_delta_tau_threshold():
    pol = load_policy()
    for st in pol["doc"]["policy"]["statements"]:
        if st.get("id") == "delta-tau-envelope":
            b = st.get("bounds", {})
            return float(b.get("weight_norm_max", 1.0))
    return 1.0


def get_delta_threshold():
    try:
        return get_delta_tau_threshold()
    except Exception:
        return 1.0

def get_tau_max():
    pol = load_policy()
    try:
        for st in pol["doc"]["policy"]["statements"]:
            if st.get("id") == "delta-tau-envelope":
                b = st.get("bounds", {})
                return int(b.get("tau_max", 8))
    except Exception:
        pass
    return 8

def get_tau_decay():
    pol = load_policy()
    try:
        for st in pol["doc"]["policy"]["statements"]:
            if st.get("id") == "delta-tau-envelope":
                b = st.get("bounds", {})
                return float(b.get("tau_decay", 1.0))
    except Exception:
        pass
    return 1.0
