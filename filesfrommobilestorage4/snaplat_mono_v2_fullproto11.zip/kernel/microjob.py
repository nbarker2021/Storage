from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class MicroJob:
    id: str
    triad: str
    step: str
    inputs: Dict
    policy_hash: str
    status: str = "queued"
    advice: List[str] = field(default_factory=list)
