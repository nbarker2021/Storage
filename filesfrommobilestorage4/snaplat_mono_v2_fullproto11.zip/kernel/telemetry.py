import json, os, time, pathlib
from kernel.db import get_conn, exec_sql
def emit(trail_kind: str, thing_id: str, payload: dict):
    d = pathlib.Path("outputs/trails"); d.mkdir(parents=True, exist_ok=True)
    rec = {"trail_id": f"{int(time.time()*1000)}-{os.getpid()}", "kind": trail_kind, "thing_id": thing_id, "payload": payload, "created_at": int(time.time()*1000)}
    with open(d / "trails.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    # persist minimal trail index in RMI
    conn = get_conn()
    exec_sql(conn, "INSERT OR REPLACE INTO trails(trail_id,kind,thing_id,payload_json,created_at) VALUES(?,?,?,?,?)",
             (rec["trail_id"], rec["kind"], rec["thing_id"], json.dumps(payload), rec["created_at"]))
