from security.rbac import has_perm, ensure_defaults, DEFAULT_USER
from kernel.telemetry import emit

def guard_rmi_read(action='read', resource='rmi', context=None) -> bool:
    ensure_defaults()
    if not has_perm(DEFAULT_USER['user_id'], action, resource):
        emit('rbac.deny', resource, {'action': action, 'resource': resource, 'ctx': context or {}})
        return False
    return True
