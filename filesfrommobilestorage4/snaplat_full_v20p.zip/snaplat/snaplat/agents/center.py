
from ..failure.catalog import add as add_failure
from ..repo.index import register
from ..governance.gate_runner import run_faces as gate_run

_AGENTS = {}
_TASKS = {}

def onboard(blueprint_id: str, faces: dict = None) -> dict:
    agent_id = f"agent:{blueprint_id}"
    lane = gate_run(faces or {"privacy":"green","policy":"green","numeric":"green","semantic":"green"})["lane"]
    _AGENTS[agent_id] = {"blueprint": blueprint_id, "lane": lane, "skills": set()}
    register(agent_id, {"lane": lane, "blueprint": blueprint_id})
    return {"agent_id": agent_id, "lane": lane}

def assign(agent_id: str, task_sid: str, seeds: dict) -> dict:
    _TASKS[task_sid] = {"agent": agent_id, "seeds": seeds, "status": "assigned"}
    return {"assigned": task_sid, "agent": agent_id}

def training_gap(agent_id: str, needed_skills: list) -> dict:
    _AGENTS.setdefault(agent_id, {}).setdefault("skills", set()).update(needed_skills)
    return {"agent_id": agent_id, "skills": list(_AGENTS[agent_id]["skills"])}

def deploy(task_sid: str) -> dict:
    t=_TASKS.get(task_sid, {}); t["status"]="running"; return {"task": task_sid, "status":"running"}

def feedback(task_sid: str, report: dict) -> dict:
    label = report.get("label","ok")
    if label != "ok":
        add_failure({"level":"snap","source":report.get("source","agent"),"symptom":label,"site":report.get("site","op"),"strategy":report.get("strategy",""),"report":report})
    _TASKS[task_sid]["status"]="done"
    return {"task": task_sid, "label": label, "status":"done"}
