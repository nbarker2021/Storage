
_CATALOG = []
def add(entry: dict):
    _CATALOG.append(entry); return entry
def query(where: dict):
    res = []
    for e in _CATALOG:
        ok=True
        for k,v in (where or {}).items():
            if e.get(k)!=v: ok=False; break
        if ok: res.append(e)
    return res
def rollup(by: str):
    agg = {}
    for e in _CATALOG:
        k = e.get(by, "unk"); agg[k]=agg.get(k,0)+1
    return agg
def stats(): return {"count": len(_CATALOG)}
