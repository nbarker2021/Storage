
def recall_over_compute(recalled_ops: int, computed_ops: int) -> float:
    denom = max(1, recalled_ops + computed_ops)
    return recalled_ops / denom
def resource_negative_score(recalled_ops: int, computed_ops: int, threshold: float = 0.6) -> dict:
    roc = recall_over_compute(recalled_ops, computed_ops)
    return {"roc": roc, "resource_negative": roc >= threshold}
