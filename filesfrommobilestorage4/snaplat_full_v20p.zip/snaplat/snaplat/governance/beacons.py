
import time
_BEACONS = {}
def set_beacon(name: str, weight: float, lam: float = 0.001):
    _BEACONS[name] = {"w": weight, "lambda": lam, "ts": int(time.time()*1000), "overrides": []}
    return _BEACONS[name]
def override(name: str, weight: float, approver: str):
    if name not in _BEACONS: set_beacon(name, weight)
    _BEACONS[name]["overrides"].append({"w": weight, "by": approver, "ts": int(time.time()*1000)})
    _BEACONS[name]["w"] = weight
    return _BEACONS[name]
def value(name: str) -> float:
    if name not in _BEACONS: return 0.0
    b = _BEACONS[name]
    age = max(0, int(time.time()*1000) - b["ts"]) / 1000.0
    return b["w"] * (2.71828 ** (-b["lambda"] * age))
def snapshot(): return _BEACONS.copy()
