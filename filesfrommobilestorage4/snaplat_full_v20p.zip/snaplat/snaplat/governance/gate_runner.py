
from .faces import map_faces_to_lane
def run_faces(faces: dict) -> dict:
    lane = map_faces_to_lane(faces or {})
    reasons = [f"{k}:{v}" for k,v in (faces or {}).items() if v != "green"]
    approvals = ["family_sap"] if lane != "gold" else []
    return {"lane": lane, "reasons": reasons, "approvals": approvals}

def trait_lanes(faces_map: dict) -> dict:
    lanes = {}
    for trait, faces in (faces_map or {}).items():
        lanes[trait] = map_faces_to_lane(faces)
    return lanes

def composite_lane(trait_lane_map: dict) -> str:
    order = {"shadow":0,"silver":1,"gold":2}
    if not trait_lane_map: return "silver"
    return min(trait_lane_map.values(), key=lambda x: order[x])
