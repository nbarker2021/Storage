
def enforce_budget(trace: list, K: int = 3) -> bool:
    last_e = -999
    for i, step in enumerate(trace):
        if step == 'E':
            last_e = i
        if step == 'C' and i - last_e <= K:
            last_e = -999
    return last_e == -999
