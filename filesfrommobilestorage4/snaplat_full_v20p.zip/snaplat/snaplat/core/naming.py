
import json, hashlib
def encode_name(domain, family, subtype, seeds, context, v=1):
    sd = hashlib.blake2s(json.dumps(seeds, sort_keys=True).encode(), digest_size=4).hexdigest()
    cd = hashlib.blake2s(json.dumps(context, sort_keys=True).encode(), digest_size=4).hexdigest()
    return f"{domain}.{family}.{subtype}.{sd}.{cd}.v{v}"
def decode_name(name: str):
    parts = name.split("."); 
    if len(parts) < 6: raise ValueError("invalid name")
    domain,family,subtype,sd,cd,vv = parts[:6]
    return {"domain":domain,"family":family,"subtype":subtype,"seed_digest":sd,"ctx_digest":cd,"v":int(vv.replace('v',''))}
