
from dataclasses import dataclass

@dataclass
class E8Point:
    coords: tuple

def nearest_cell(v: E8Point) -> str:
    return "cell:0"

def neighbors(cell_id: str) -> list:
    return [f"{cell_id}:n{i}" for i in range(240)]

def reflect(point: E8Point) -> E8Point:
    return E8Point(coords=tuple(-x for x in point.coords))
