
import json, hashlib
from .deepstore.fs import FSDeepStore
def _digest(obj: dict) -> str:
    return hashlib.blake2s(json.dumps(obj, sort_keys=True).encode(), digest_size=8).hexdigest()
def restore_kernel(key: str, posture: dict, root=".deepstore") -> dict:
    ds = FSDeepStore(root=root)
    blob, meta = ds.get(key)
    payload = json.loads(blob.decode())
    ok = isinstance(payload, dict) and "manifest" in payload and "bundle" in payload
    profile = {"tick_rate_hz": posture.get("tick_rate_hz", 5.0), "compression": posture.get("compression","adaptive"), "safety": posture.get("safety","balanced")}
    return {"ok": ok, "digest": _digest(payload), "profile": profile, "meta": meta}
