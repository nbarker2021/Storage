
import json
from .deepstore.fs import FSDeepStore
from ..governance.queue import enqueue, is_approved
class RepoRouter:
    def __init__(self, root=".deepstore"): self.ds = FSDeepStore(root=root)
    def deep_put(self, key: str, obj: dict, actor: str):
        gid = enqueue("deep_put", {"key": key}, actor)
        if not is_approved(gid): return {"gid": gid, "status":"pending"}
        self.ds.put(key, json.dumps(obj).encode(), meta={"actor":actor})
        return {"gid": gid, "status":"stored"}
    def deep_get(self, key: str):
        b, meta = self.ds.get(key); return json.loads(b.decode()), meta
