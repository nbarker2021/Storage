
GRAPH = {}; META = {}
def register_graph(sid: str, children=None, meta=None):
    GRAPH[sid] = list(children or []); META[sid] = meta or {}; return sid
def reachable(roots):
    seen=set(); stack=list(roots or [])
    while stack:
        s=stack.pop()
        if s in seen: continue
        seen.add(s); stack.extend(GRAPH.get(s, []))
    return seen
