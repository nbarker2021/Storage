
def train(corpus, merges=50): return []
def encode(text, merges): return text.split()
def decode(tokens): return " ".join(tokens)
