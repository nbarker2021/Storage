
# SNAPLAT — Full Unified Repository (v20+)
**This repo merges the best from v17–v20**:
- v17: Schema Registry, Gate Runner, Naming/Glyph, ThinkTank, DeepStore/Router, Index, SNAP model, basic Agents, RAG (stubs)
- v18: Agentic Center E2E, Failure Catalog, Restore Recipes, RAG Report Mode
- v19: Cross-Modal Precedence, Beacon Policy (decay/override), Partial Trait Lanes, Perf stubs
- v20: Deep-Store GC/Compaction (reachability), Resource-Negative Metrics, Resilience tests

See `/docs` for the operational handbook and intake/handoff guide.
