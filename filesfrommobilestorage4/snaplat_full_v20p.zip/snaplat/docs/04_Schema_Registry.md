# Schema Registry
Type IDs, seeds, traits, gates, replay recipes, governance.
