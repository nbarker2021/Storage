# Intake & Handoff Guide
**Audience**: new operators, integrators.
**Contains**: glossary, quickstart (CLI), playbooks, governance, incident response, upgrade path (v17→v20+), deliverables checklist.
- Install: `pip install -e .`
- Initialize schemas; set beacons; choose stance.
- Run a task: name→shell resolve; stitch; report; governance approvals; archive.
- Review: queue dashboard, failure rollups, RoC.
- Handoff packet: schemas + policies + posture presets + contacts + SLOs.
