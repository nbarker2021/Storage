# Precedence Rules
Operational: kernel>code>tables>text; Reporting: text>tables>code>kernel.
