# Naming/Glyph Recall
Name: Domain.Family.Subtype.SeedDigest.CtxDigest.vN → reconstruct shells/pointers.
