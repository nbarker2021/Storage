# E8 & Shelling
Invariants; neighbors; reflections; n-level lifecycle; Underverse; C[8].
