# Resource-Negative Proofs
RoC metric; thresholds; dashboards; auto stance shifts.
