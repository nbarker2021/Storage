
from snaplat.governance.gate_runner import run_faces, trait_lanes, composite_lane
def test_gate_faces_amber():
    out = run_faces({"privacy":"green","policy":"amber","numeric":"green","semantic":"green"})
    assert out["lane"] == "silver"
def test_trait_lanes():
    lanes = trait_lanes({"TimeSeries":{"privacy":"green","policy":"green","numeric":"green","semantic":"green"}, "PricingSurface":{"privacy":"green","policy":"amber"}})
    comp = composite_lane(lanes)
    assert comp in ("shadow","silver","gold")
