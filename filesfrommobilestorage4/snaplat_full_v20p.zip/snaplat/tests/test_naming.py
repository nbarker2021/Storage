
from snaplat.core.naming import encode_name, decode_name
def test_name_roundtrip():
    n = encode_name("Snap","SAP","Decision", {"case":"A-42"}, {"asof":"2025-08-17"}, 1)
    meta = decode_name(n)
    assert meta["family"] == "SAP"
    assert meta["v"] == 1
