
# Morphonic Miner (Receipts‑First, Block‑Form Rehydration)

A background, low‑priority Bitcoin candidate block assembler + nonce searcher that:
- Uses prehash of the header prefix (76 bytes) for speed in Python.
- Writes JSONL receipts for every slice (`miner_receipts.jsonl` by default).
- Optionally plugs into your **SpeedLight** cache and **geometric_transformer_standalone** for “morphonic” nonce sampling.
- Submits a raw minimal block (coinbase‑only) upon success; extend to include mempool txs as desired.

## Layout
- `morphonic_miner/rpc.py` — Bitcoin Core JSON‑RPC client.
- `morphonic_miner/sha256mid.py` — SHA‑256 helpers + header prefix prehash.
- `morphonic_miner/merkle.py` — Merkle root for txids.
- `morphonic_miner/assembler.py` — Coinbase + header serialization.
- `morphonic_miner/lanes.py` — Lane sampler; imports `geometric_transformer_standalone` if available.
- `morphonic_miner/speedlight_wrap.py` — Optional SpeedLight integration (fallback in‑memory cache).
- `morphonic_miner/miner.py` — Background miner with receipts, lane slices, block‑form rehydration.
- `morphonic_miner/run_miner.py` — Entrypoint.

## Quick start
1) Ensure Bitcoin Core is running with RPC enabled and you have credentials in env:
```
export BTC_RPC_USER=rpcuser
export BTC_RPC_PASS=rpcpass
export BTC_RPC_HOST=127.0.0.1
export BTC_RPC_PORT=8332
```
2) Set your payout scriptPubKey hex (P2PKH example: `76a914<20‑byte‑hash>88ac`):
```
export PAYOUT_SCRIPT_HEX=76a914000000000000000000000000000000000000000088ac
```
3) (Optional) Tuning:
```
export NONCES_PER_SLICE=20000
export SLEEP_BETWEEN_SLICES=0.25
export MM_LANES=8
export MM_RECEIPTS=./miner_receipts.jsonl
```
4) Run:
```
python -m morphonic_miner.run_miner
```

## Notes
- This ships a **minimal** raw block (coinbase‑only). To earn fees and be fully standard with segwit, extend `miner.py` to include txs from `getblocktemplate()['transactions']` and add witness commitment per BIP‑141 (or leverage `coinbasetxn` if your node provides it).
- The code automatically uses your `speedlight_sidecar.py` if present; otherwise falls back to an in‑memory cache.
- Lane sampler integrates `geometric_transformer_standalone.py` if present; otherwise it uses simple sequential tranches seeded per lane.
- Receipts are written as JSONL and include best hash and z‑bits for adaptive weighting in later runs.

## Safety / Reality
- Solo mining on CPU is educational; for real hashrate use optimized implementations or hardware.
- This package emphasizes **auditability and reuse of block‑forms**: even “missed” candidates become reusable scaffolding and improve future search.
