
#!/usr/bin/env python3
import os, sys, time
from morphonic_miner.miner import BackgroundMiner

def main():
    payout = os.getenv("PAYOUT_SCRIPT_HEX")
    if not payout:
        print("Set PAYOUT_SCRIPT_HEX (scriptPubKey hex of your payout address)")
        sys.exit(1)
    nonces = int(os.getenv("NONCES_PER_SLICE","20000"))
    sleep = float(os.getenv("SLEEP_BETWEEN_SLICES","0.25"))
    lanes = int(os.getenv("MM_LANES","8"))
    miner = BackgroundMiner(payout, nonces_per_slice=nonces, sleep_between=sleep, lanes=lanes)
    miner.run_forever()

if __name__ == "__main__":
    main()
