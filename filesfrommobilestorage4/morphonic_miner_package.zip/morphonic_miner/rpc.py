
import os, requests

class RPC:
    def __init__(self, url=None, user=None, password=None, host=None, port=None, timeout=30):
        user = user or os.getenv("BTC_RPC_USER", "rpcuser")
        password = password or os.getenv("BTC_RPC_PASS", "rpcpass")
        host = host or os.getenv("BTC_RPC_HOST", "127.0.0.1")
        port = port or int(os.getenv("BTC_RPC_PORT", "8332"))
        self.url = url or f"http://{user}:{password}@{host}:{port}/"
        self.timeout = timeout

    def call(self, method, params=None):
        payload = {"jsonrpc":"1.0","id":"mm","method":method,"params":params or []}
        r = requests.post(self.url, json=payload, timeout=self.timeout)
        r.raise_for_status()
        data = r.json()
        if data.get("error"):
            raise RuntimeError(data["error"])
        return data["result"]

    # Convenience wrappers
    def getblocktemplate(self, params=None):
        return self.call("getblocktemplate", params or [])

    def submitblock(self, rawhex):
        return self.call("submitblock", [rawhex])

    def gettransaction(self, txid):
        return self.call("gettransaction", [txid])

    def getnewaddress(self, label="", addrtype=None):
        params = [label] if label else []
        if addrtype: params.append(addrtype)
        return self.call("getnewaddress", params)
