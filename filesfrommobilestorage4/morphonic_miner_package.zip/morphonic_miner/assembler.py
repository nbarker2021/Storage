
import struct, hashlib
from typing import List, Tuple

def int_le(n, l): return n.to_bytes(l, "little")
def u32(n): return struct.pack("<L", n)
def u64(n): return struct.pack("<Q", n)

def build_coinbase(height: int, payout_spk_hex: str, value_sat: int, extra: bytes=b"") -> Tuple[bytes, str]:
    ver = u32(1)
    tx_in_count = b"\x01"
    prevout = b"\x00"*32 + b"\xff\xff\xff\xff"
    # BIP34 height push + extra
    h = height
    h_bytes = b""
    while h > 0:
        h_bytes += bytes([h & 0xff]); h >>= 8
    script = bytes([len(h_bytes)]) + h_bytes + extra
    script_len = bytes([len(script)])
    seq = b"\xff\xff\xff\xff"
    tx_out_count = b"\x01"
    value = u64(value_sat)
    spk = bytes.fromhex(payout_spk_hex)
    spk_len = bytes([len(spk)])
    locktime = u32(0)
    raw = ver + tx_in_count + prevout + script_len + script + seq + tx_out_count + value + spk_len + spk + locktime
    txid = hashlib.sha256(hashlib.sha256(raw).digest()).digest()[::-1].hex()
    return raw, txid

def header_bytes(version:int, prev_be_hex:str, merkle_be_hex:str, curtime:int, bits_u32:int, nonce:int) -> bytes:
    prev_le = bytes.fromhex(prev_be_hex)[::-1]
    merkle_le = bytes.fromhex(merkle_be_hex)[::-1]
    return u32(version) + prev_le + merkle_le + u32(curtime) + u32(bits_u32) + u32(nonce)
