
# Optional integration with user's SpeedLight sidecar (if present in working dir/PYTHONPATH)
try:
    from speedlight_sidecar import SpeedLight, SpeedLightDistributed
except Exception:
    SpeedLight = None
    SpeedLightDistributed = None

class CacheShim:
    """Thin wrapper: if SpeedLight is available, use it; else in-memory dict."""
    def __init__(self):
        self._mem = {}
        self.sl = None
        if SpeedLightDistributed:
            try:
                self.sl = SpeedLightDistributed(namespace="morphonic_miner")
            except Exception:
                pass
        elif SpeedLight:
            try:
                self.sl = SpeedLight(namespace="morphonic_miner")
            except Exception:
                pass

    def compute_hash(self, key: str, fn, *args, **kwargs):
        if self.sl:
            return self.sl.compute_hash(key, fn, *args, **kwargs)
        # Fallback simple memo
        if key in self._mem:
            return self._mem[key]
        v = fn(*args, **kwargs)
        self._mem[key] = v
        return v
