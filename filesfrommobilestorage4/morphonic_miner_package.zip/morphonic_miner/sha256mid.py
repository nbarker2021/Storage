
# Minimal SHA-256 helpers using hashlib. We don't expose true midstate compression here,
# but we provide a fast-path prehash for the first 76 bytes (header without nonce)
# and then finalize with the 4-byte nonce. This is still Python-level but reduces repeated work.
import hashlib

def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def sha256d(b: bytes) -> bytes:
    return sha256(sha256(b))

class HeaderPrehash:
    """Prehash of the first 76 bytes of a Bitcoin header (version|prev|merkle|time|bits).
    Use .finalize(nonce_le4) to produce the full first SHA-256 digest quickly, then double-hash.
    Note: hashlib doesn't expose midstate; we hold the hashlib object.
    """
    def __init__(self, prefix76: bytes):
        assert len(prefix76) == 76, "prefix must be 76 bytes (header without nonce)"
        self._h = hashlib.sha256()
        self._h.update(prefix76)

    def finalize_first_sha(self, nonce_le4: bytes) -> bytes:
        h = self._h.copy()
        h.update(nonce_le4)
        return h.digest()

    def finalize_hash_hex(self, nonce_le4: bytes) -> str:
        first = self.finalize_first_sha(nonce_le4)
        return hashlib.sha256(first).digest()[::-1].hex()
