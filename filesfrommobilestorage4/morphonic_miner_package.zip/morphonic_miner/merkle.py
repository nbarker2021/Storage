
import hashlib

def sha256d(b: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()

def merkle_root_from_txids_be(txids_be_hex):
    """txids in big-endian hex (human). Returns merkle root in big-endian hex."""
    if not txids_be_hex:
        return "00"*32
    layer = [bytes.fromhex(h)[::-1] for h in txids_be_hex]  # convert to LE bytes
    while len(layer) > 1:
        if len(layer) & 1: layer.append(layer[-1])
        layer = [sha256d(layer[i] + layer[i+1]) for i in range(0,len(layer),2)]
    return layer[0][::-1].hex()
