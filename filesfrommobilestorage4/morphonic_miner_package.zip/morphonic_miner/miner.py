
import os, time, json, math, threading
from typing import Dict, Any, List
from .rpc import RPC
from .receipts import ReceiptWriter
from .speedlight_wrap import CacheShim
from .sha256mid import HeaderPrehash, sha256d
from .merkle import merkle_root_from_txids_be
from .assembler import build_coinbase, header_bytes
from .lanes import LaneSampler

def bits_to_target(bits_u32:int)->int:
    exp = (bits_u32 >> 24) & 0xff
    mant = bits_u32 & 0x007fffff
    return mant * (1 << (8*(exp-3)))

class BackgroundMiner:
    def __init__(self, payout_spk_hex: str, nonces_per_slice=20000, sleep_between=0.25, lanes=8):
        self.rpc = RPC()
        self.receipts = ReceiptWriter()
        self.cache = CacheShim()
        self.payout_spk = payout_spk_hex
        self.nonces_per_slice = nonces_per_slice
        self.sleep_between = sleep_between
        self.lanes = [LaneSampler(f"lane-{i}") for i in range(lanes)]

    def _template(self)->Dict[str,Any]:
        tpl = self.rpc.getblocktemplate()
        return tpl

    def run_once(self):
        try:
            tpl = self._template()
        except Exception as e:
            self.receipts.write({"event":"gblktpl_error","error":str(e)})
            time.sleep(5); return

        height = tpl["height"]
        prevhash_be = tpl["previousblockhash"]
        bits_u32 = tpl["bits"]
        version = tpl["version"]
        curtime = tpl["curtime"]
        coinbasevalue = tpl.get("coinbasevalue", 0)

        # Deterministic tx policy (minimal): coinbase only. Users can extend to tpl['transactions'] set.
        txids = []
        extranonce = int(time.time()) & 0xffffffff

        # Build coinbase and merkle root (coinbase only for minimal correctness)
        def _cb():
            raw, txid = build_coinbase(height, self.payout_spk, coinbasevalue, extra=extranonce.to_bytes(4,"little"))
            return raw.hex(), txid
        coinbase_hex, coinbase_txid = self.cache.compute_hash(f"cb:{height}:{self.payout_spk}:{extranonce}:{coinbasevalue}", _cb)
        all_txids = [coinbase_txid] + txids
        merkle_be = self.cache.compute_hash(f"mr:{hash(tuple(all_txids))}", merkle_root_from_txids_be, all_txids)

        # Prepare 76-byte header prefix
        hdr_prefix = header_bytes(version, prevhash_be, merkle_be, curtime, bits_u32, 0)[:76]
        pre = HeaderPrehash(hdr_prefix)
        target = bits_to_target(bits_u32)
        best_hash = None
        best_val = None

        # Mine nonces in sliced lanes
        for lane in self.lanes:
            nonces = lane.sample_nonce_tranche(self.nonces_per_slice)
            for n in nonces:
                hhex = pre.finalize_hash_hex(n.to_bytes(4,"little"))
                hval = int(hhex, 16)
                if (best_val is None) or (hval < best_val):
                    best_val, best_hash = hval, hhex
                if hval <= target:
                    # Found a candidate. Build raw block: header + varint count + coinbase only
                    full_hdr = header_bytes(version, prevhash_be, merkle_be, curtime, bits_u32, n)
                    raw_block = full_hdr.hex() + "01" + coinbase_hex
                    self.receipts.write({
                        "event":"found_block_candidate",
                        "height":height,"prev":prevhash_be,"merkle":merkle_be,
                        "bits":bits_u32,"nonce":n,"hash":hhex,"coinbase_txid":coinbase_txid,
                        "raw_block_len":len(raw_block)//2,"lane":lane.lane_id
                    })
                    try:
                        res = self.rpc.submitblock(raw_block)
                        self.receipts.write({"event":"submitblock","result":res or "accepted","hash":hhex})
                    except Exception as e:
                        self.receipts.write({"event":"submit_error","error":str(e)})
                    # After success, return to let new template load
                    return

        self.receipts.write({
            "event":"slice_done",
            "height":height,"prev":prevhash_be,"merkle":merkle_be,
            "best_hash":best_hash,"best_zbits": (256 - best_val.bit_length()) if best_val else None,
            "nonces_tried": self.nonces_per_slice * len(self.lanes)
        })

    def run_forever(self):
        while True:
            self.run_once()
            time.sleep(self.sleep_between)
