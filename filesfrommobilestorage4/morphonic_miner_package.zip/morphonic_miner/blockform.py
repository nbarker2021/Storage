
import json, time, hashlib
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any, Optional

@dataclass
class BlockForm:
    form_id: str
    policy: Dict[str, Any]
    txids: List[str]
    merkle_shape: str
    header_dials: Dict[str, Any]
    hash_primitives: Dict[str, Any]
    stats: Dict[str, Any] = field(default_factory=dict)
    created_ts: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

class BlockFormStore:
    def __init__(self, path="./blockforms.jsonl"):
        self.path = path

    def add(self, bf: BlockForm):
        d = bf.to_dict()
        with open(self.path, "a") as f:
            f.write(json.dumps(d, sort_keys=True)+"\n")

    def load_all(self) -> List[BlockForm]:
        out = []
        try:
            with open(self.path) as f:
                for line in f:
                    line = line.strip()
                    if not line: continue
                    obj = json.loads(line)
                    out.append(BlockForm(**obj))
        except FileNotFoundError:
            pass
        return out
