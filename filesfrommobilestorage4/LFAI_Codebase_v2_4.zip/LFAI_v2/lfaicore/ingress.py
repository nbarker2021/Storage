from typing import Dict, Any, List
from .bitwrap import bitwrap_pi4, pal4_ok_bytes, pal4_defect_bytes
from .cona_e8 import constructionA_E8_check
from .gating import face_functionals, latch_sweep

def integerize(vec: List[float]) -> List[int]:
    return [int(round(x)) for x in vec]

def fold8(vec: List[int]) -> List[int]:
    v=[0]*8
    for i,x in enumerate(vec):
        v[i%8]+=int(x)
    return v

def ingress_state(vec: List[float]) -> Dict[str, Any]:
    ints = integerize(vec)
    blob = bytes((x & 0xFF) for x in ints)
    wrapped = bitwrap_pi4(blob)
    pal_ok = pal4_ok_bytes(wrapped)
    v8 = fold8(ints)
    legal, synd = constructionA_E8_check(v8)
    faces = face_functionals(ints)
    latches = latch_sweep(ints)
    return {"ints": ints, "pal4_ok": pal_ok, "pal4_defect": pal4_defect_bytes(wrapped),
            "v8": v8, "legal_e8": bool(legal), "syndrome": synd,
            "faces": faces, "latches": latches}
