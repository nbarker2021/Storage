from typing import List
def face_functionals(vec: List[int]) -> List[float]:
    if not vec: return [0]*8
    n=len(vec)
    return [min(vec), max(vec), sum(vec)/n, 0.5, 0.5, (sum(abs(x) for x in vec)/n), 0.1, float(n)]
def latch_sweep(vec: List[int]) -> List[int]:
    return [1,1,1,1,1,1,1,1]
