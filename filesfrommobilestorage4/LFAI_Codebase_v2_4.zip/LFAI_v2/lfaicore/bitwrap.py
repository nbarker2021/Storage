from typing import Iterable

def rot4(b: int) -> int:
    return ((b << 4) | (b >> 4)) & 0xFF

def bitwrap_pi4_byte(b: int, mask: int = 0xAA) -> int:
    return rot4(b) ^ (mask & 0xFF)

def bitwrap_pi4(data: bytes, mask: int = 0xAA) -> bytes:
    return bytes(bitwrap_pi4_byte(x, mask) for x in data)

bitunwrap_pi4 = bitwrap_pi4

def pal4_defect_quad(q: Iterable[int]) -> int:
    a,b,c,d = list(q)
    return abs((a + d) - (b + c))

def pal4_defect_bytes(bs: bytes) -> int:
    if not bs: return 0
    pad = (4 - (len(bs) % 4)) % 4
    bs2 = bs + b"\x00"*pad
    s=0
    for i in range(0, len(bs2), 4):
        s += pal4_defect_quad(bs2[i:i+4])
    return s

def pal4_ok_bytes(bs: bytes, eps: int = 0) -> bool:
    return pal4_defect_bytes(bs) <= eps
