# Operations (v2.1)

## CLI
```
python -m cli.lfaictl ingress --vector "[1,2,3,4,5,6,7,8]"
python -m cli.lfaictl run --fn examples.moving_avg_octet:moving_avg_octet --lanes "[1,2,3,4,0,0,0,0]"
```

## Programmatic
```python
from lfaicore.runtime import OctetExecutor
from examples.crc32_octet import crc32_octet
exe = OctetExecutor()
res = exe.run(crc32_octet, (1,2,3,4,0,0,0,0))
print(res)
```
