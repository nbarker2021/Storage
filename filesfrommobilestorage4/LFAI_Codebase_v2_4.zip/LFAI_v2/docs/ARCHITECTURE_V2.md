# LFAI v2 — Defined Spaces + Palindromic λ8 Code
Ingress: integerize → Π4 wrap → E8 legality → paint → planner.
Compute: every function is a pal-4, reversible λ⁸ block (8 lanes).
Unfold→Prune→Commit: run variants, prune by legality/faces/pal-4, commit the normal form.
