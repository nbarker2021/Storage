import json, hashlib, colorsys
from typing import List, Dict, Any

# Universal 16-step gradient (hexadecimal nibbles 0..F → hue wheel)
# hue = k * 360/16; sat=1; val=1
PALETTE: Dict[str, str] = {}
for k in range(16):
    h = k / 16.0
    r,g,b = [int(255*x) for x in colorsys.hsv_to_rgb(h,1.0,1.0)]
    PALETTE["%x" % k] = f"#{r:02x}{g:02x}{b:02x}"

def palette() -> Dict[str,str]:
    return dict(PALETTE)

def _sha(s: bytes) -> str:
    return hashlib.sha256(s).hexdigest()

def paint_touch(vec: List[int], frame_hash: str, space: str, face: int, salt: str = "", length: int = 32) -> str:
    """Return a hex string 'stroke' capturing this touch.
    space: any stable identifier (e.g., 'room:<id>' or 'core:proof').
    face: 0..7 index (eight faces). length: number of hex nibbles to return.
    Deterministic and cheap: hex is the paint. """
    payload = json.dumps({"vec": vec, "frame": frame_hash, "space": space, "face": int(face), "salt": salt}, sort_keys=True).encode()
    hx = _sha(payload)
    return hx[:length]

def paint8(vec: List[int], frame_hash: str, space: str = "core:proof", salt: str = "", length: int = 32) -> List[str]:
    return [paint_touch(vec, frame_hash, space, i, salt=salt, length=length) for i in range(8)]

def hex_to_colors(hex_seq: str) -> List[str]:
    """Map hex digits to #RRGGBB using the universal palette."""
    cols = []
    for ch in hex_seq.lower():
        if ch in PALETTE:
            cols.append(PALETTE[ch])
    return cols

def merge_paint(a: str, b: str) -> str:
    """Nibble-wise XOR merge of two hex sequences (length=min)."""
    L = min(len(a), len(b))
    out = []
    for i in range(L):
        x = int(a[i], 16) ^ int(b[i], 16)
        out.append("%x" % x)
    return "".join(out)
