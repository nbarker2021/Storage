import hashlib, json
from typing import List
from .frame import Frame
from .gating import latch_sweep
def anchor_id(vec: List[int], frame: Frame):
    l=latch_sweep(vec)
    key={'frame':frame.hash(),'rest_scale':frame.rest_scale,'coset':'demo','latches':l}
    return hashlib.sha256(json.dumps(key, sort_keys=True).encode()).hexdigest(), l
