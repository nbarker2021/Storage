REGISTRY = {}

def register(name, cls):
    REGISTRY[name]=cls
