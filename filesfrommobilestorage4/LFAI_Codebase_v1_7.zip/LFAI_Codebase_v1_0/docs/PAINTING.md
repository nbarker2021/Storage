# Hexadecimal Painting (Provenance by Touch)

**Goal:** every time data touches a space (room/face), we stamp a cheap, universal **hex painting**:
- Gradient is fixed: 16 hues (0..F) on the color wheel.
- A **touch** = SHA‑256(vec, frame_hash, space, face, salt) → hex → first N nibbles.
- We produce **8 paintings** (one per face) for every check; sequences append over time (ledger).
- Merging is nibble‑XOR by default (diffusion); alternates: interleave or multiset.

**Why:** hex is “zero‑effort hashing,” and the color gradient is universal. The sequence is the history.
Any datum that passed through the system carries at least 8 color tracks.

**API surfaces:** `/proof/state` returns `paint8` and the `palette`. `/contracts` embeds `paint8` in chainpack extras.
**UI:** sandbox renders per‑face swatches for the last ingested vector.

**Determinism:** painting is pure; same input → same hex. Collision negligible at SHA‑256, and sequences make it vanishing. 
