from lfaicore.paint import paint8, palette, merge_paint, hex_to_colors

def test_paint8_determinism():
    vec=[13,7,9,2,18,5,1,12]; fh='f'*64
    p = paint8(vec, fh, space='core:test', salt='s', length=16)
    q = paint8(vec, fh, space='core:test', salt='s', length=16)
    assert p == q and len(p)==8 and all(len(x)==16 for x in p)

def test_palette_has_16():
    pal = palette()
    assert len(pal)==16 and all(k in pal for k in list("0123456789abcdef"))

def test_merge_and_colors():
    a="0123456789abcdef"; b="fedcba9876543210"
    m = merge_paint(a,b)
    cols = hex_to_colors(m[:16])
    assert len(cols)==16
