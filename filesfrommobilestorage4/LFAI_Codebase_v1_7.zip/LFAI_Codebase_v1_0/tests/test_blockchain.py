from lfaicore.frame import compile_from_glyphs
from lfaicore.anchors import anchor_id
from lfaicore.pal import pal_defects
from lfaicore.blockchain import export_chainpack

def test_chainpack_shapes():
    f = compile_from_glyphs([8,13,32]); vec=[13,7,9,2,18,5,1,12]
    aid, latches = anchor_id(vec, f); pal = pal_defects(vec)
    pack = export_chainpack(aid, f.hash(), f.rest_scale, latches, pal)
    assert "bundle" in pack and "eip712" in pack and "op_return_hex" in pack and "abi_calldata" in pack
