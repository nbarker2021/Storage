# SnapLat Commercial / Academic Rider (Template)
**Version 1.0 — 2025-08-13**

This Rider amends the baseline **SnapLat Personal-Use License & Patent Non-Assertion** (the “Base License”) between **[Owner Name]** (“Licensor”) and **[Licensee Name]** (“Licensee”). Capitalized terms have the meanings in the Base License unless defined here.

## 1) Purpose & Grant
Check one or more:
- ☐ **A. Evaluation License.** Non-production, internal evaluation only.
- ☐ **B. Academic Research License.** Non-commercial academic research, with limited publication rights (see §4).
- ☐ **C. Commercial License.** Production use permitted subject to fees and scope below.

Licensor grants Licensee a non-exclusive, non-transferable, worldwide license to use the **Materials** for the selected purpose(s) during the **Term**, subject to the **Restrictions**, **Fees**, and **Scope** herein.

## 2) Scope
- **Fields of Use:** [e.g., information retrieval, biology, finance; or “all fields”].
- **Deployment:** [internal only / hosted service / embedded product].
- **Seat/Instance Limits:** [N users / N instances].
- **Territory:** [worldwide or limited regions].
- **Subcontractors:** [permitted / prohibited] (must be bound by terms no less protective).

## 3) Fees
- **License Fee:** $[amount] (one-time / annual).
- **Support (optional):** $[amount] per [period] for [SLA summary].
- **Taxes:** Exclusive of taxes; Licensee responsible for applicable taxes.

## 4) Academic Publications (if B checked)
- Licensee may publish **non-confidential** research results that **do not disclose Licensor’s proprietary code or datasets**. Preprints must credit “SnapLat (licensed from [Owner Name])”. Provide **30 days’ notice** to Licensor for review of confidential information only (no editorial control).

## 5) Restrictions (all options)
- No reverse engineering except as permitted by law.
- No removal of notices; must preserve attributions.
- No use to train models released under permissive terms that would circumvent this Rider.
- No transfer, sublicense, or assignment without Licensor’s written consent.
- Compliance with **export**, **sanctions**, and **privacy** laws.

## 6) IP & Patents
- Licensor retains all IP in the Materials.
- Subject to Fees and compliance, Licensor grants a patent license coextensive with the Scope in §2 for **make, use, sell, offer to sell, and import** (Evaluation/Academic grants exclude sell/offer unless expressly permitted). Patent license terminates upon breach or if Licensee asserts patents against Licensor or SnapLat users.

## 7) Confidentiality
Each party must protect the other’s confidential information using reasonable care; exceptions apply to information that is public, independently developed, or rightfully received without duty.

## 8) Warranties & Indemnities
- Materials are provided **AS IS**. No warranty except as expressly stated here.
- Optional indemnity: ☐ Licensor provides IP indemnity for Licensed Use; cap = fees paid in the prior 12 months.

## 9) Term & Termination
- **Term:** [start date] to [end date], auto-renew ☐Yes ☐No.
- Either party may terminate for material breach after 30 days’ cure.
- On termination, Licensee ceases use and destroys copies (except archival for compliance).

## 10) Publicity & Marks
- Use of “SnapLat” or Licensor marks needs prior written consent (except academic citations as permitted in §4).

## 11) Governing Law / Venue
- [Choose law & forum].

## 12) Entire Agreement
This Rider + Base License (as modified by this Rider) are the entire agreement for the Licensed Use. Conflicts are resolved in favor of this Rider.

---
**Signatures**  
Licensor: __________________  Name/Title: __________________  Date: ____  
Licensee: __________________  Name/Title: __________________  Date: ____
