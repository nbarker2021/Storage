# SnapLat Contributor License Agreement (CLA) — Individual
**Version 1.0 — 2025-08-13**

Thank you for contributing to SnapLat. This CLA ensures we can accept your contributions and protect all users.

## 1) Definitions
“Contribution” means any code, documentation, data, or other material submitted to the SnapLat project.

## 2) Copyright License
You grant Licensor (the project owner) a perpetual, worldwide, non-exclusive, royalty-free copyright license to reproduce, prepare derivative works of, publicly display, publicly perform, sublicense, and distribute your Contributions and derivatives.

## 3) Patent License
You grant Licensor and recipients of SnapLat a perpetual, worldwide, non-exclusive, royalty-free patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer your Contributions, where such license applies only to those patent claims you own or control that are necessarily infringed by your Contribution alone or by combination of your Contribution with the project to which it was submitted.

## 4) Representations
You represent that: (a) you are legally entitled to grant the above licenses; (b) your Contribution is an original work or you have sufficient rights; (c) your Contribution is provided under the SnapLat Personal-Use License unless the Licensor specifies otherwise; and (d) you will mark any third‑party code or data included with appropriate license notices.

## 5) No Warranties; Disclaimer
Contributions are provided “AS IS.”

## 6) Identifying You
You agree that a record of your name, email, and the date of your agreement may be retained. You may add a Signed-off-by line per the Developer Certificate of Origin (DCO).

## 7) Entity Contributions
If you are contributing on behalf of an organization, have an authorized representative execute the **Entity Addendum** below.

---

# Entity Addendum (if applicable)
The entity identified below acknowledges and agrees to the SnapLat CLA for Contributions submitted by its employees or agents identified in writing to Licensor, and represents it has the authority to do so.

Entity: ___________________________  
Name/Title: _______________________  
Date: ____________
