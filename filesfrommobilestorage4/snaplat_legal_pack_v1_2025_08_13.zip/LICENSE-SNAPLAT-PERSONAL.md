# SnapLat Personal-Use License & Patent Non-Assertion
**Version 1.0 — 2025-08-13**

**Summary (non-binding):** You can use this project privately for yourself. You cannot use it commercially, at work, redistribute it, or host it publicly without my written approval. I grant a narrow patent permission for personal use only and reserve all other rights.

> **Not legal advice.** If you need enforceable terms for a business or publication, get counsel.

## 1) Definitions
- **“Project”** means the SnapLat/SnapOS concept and all associated intellectual property I created or provided, including ideas, designs, specifications, algorithms, formulae, workflows, shelling/glyph methods, AGRM/MDHG structures, code, scripts, documentation, notes, diagrams, models, datasets, metrics, and generated artifacts (collectively, **Materials**).
- **“You”** means the individual natural person who receives the Materials.
- **“Personal Use”** means use by You privately, on Your own devices and accounts, not on behalf of an employer, client, organization, or commercial venture; with no redistribution, publication, hosting, or sharing beyond Your own private possession.

## 2) Copyright License (personal use only)
Subject to these terms, I grant You a non-exclusive, worldwide, revocable, non-transferable, royalty-free copyright license **solely for Personal Use** to:
- download, view, and make private copies of the Materials;
- make private modifications and experiments; and
- keep derivative results privately.

**No other rights are granted.** In particular, **no** right to redistribute, sublicense, publish, host, deploy, offer services, or otherwise make the Materials or derivatives available to others without my prior **written** approval.

## 3) Patent Non-Assertion / Limited Patent License
To the extent any of my patents (present or future) read on the Materials, I grant You a limited, personal, royalty-free, non-transferable license to **make and use** (but not sell, offer to sell, import, or distribute) the Project **solely for Personal Use**.  
This patent license **terminates automatically** if:
- You assert any patent claim against me or any user of the Project; or
- You breach any part of this license (including the Personal Use limitation).

All patent rights not expressly granted are **reserved**.

## 4) Trade Secrets & Confidentiality
The Materials may reflect non-public know-how. You agree to keep them **confidential** and use reasonable care to prevent disclosure, except with my prior written approval.

## 5) No Commercial, Academic, or Organizational Use
Without my prior **written** approval, You may **not**:
- use the Materials in any employment, contracting, consulting, academic, or sponsored research context;
- integrate them into products, services, or research publications;
- post them to public repos, papers, datasets, model hubs, or demos; or
- use them to train or fine-tune systems that are shared or monetized.

## 6) Derivatives & Feedback
Any derivative works You create under Personal Use must remain private. If You choose to share feedback or suggestions with me, You grant me a perpetual, irrevocable right to use it with no obligation to You.

## 7) No Trademark Rights
No rights are granted to use my names, logos, or marks (including “SnapLat”, “SnapOS”) except for reasonable, private reference.

## 8) Warranty Disclaimer & Liability Cap
The Materials are provided **“AS IS”** without warranties of any kind. To the maximum extent permitted by law, I disclaim all implied warranties and **limit liability** to the greater of USD $0 or the amount You paid me (if any).

## 9) Termination
This license terminates automatically if You breach it. On termination, You must stop using the Materials and delete all copies, except one archival copy solely for legal compliance.

## 10) Permissions
Commercial, academic, or organizational uses may be granted separately. For approvals, contact me in writing and reference this license.
