    #!/usr/bin/env python3
    """Attach SnapLat header to source files (idempotent)."""
    import sys, os, io, pathlib

    HEADER = """// SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
// © [Owner Name]. All rights reserved except personal-use permissions.
// See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

"""

    EXTS = {'.py','.js','.ts','.tsx','.jsx','.java','.kt','.go','.rs','.c','.h','.hpp','.cpp','.cs','.swift','.rb'}

    def has_header(text: str) -> bool:
        return "SnapLat — Personal-Use License" in text[:400]

    def process(path: pathlib.Path):
        try:
            if path.suffix.lower() not in EXTS: 
                return
            text = path.read_text(encoding='utf-8', errors='ignore')
            if has_header(text): 
                return
            path.write_text(HEADER + text, encoding='utf-8')
            print("Header attached:", path)
        except Exception as e:
            print("Skip", path, "->", e)

    def main():
        root = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
        for p in root.rglob('*'):
            if p.is_file():
                process(p)
    if __name__ == '__main__':
        main()
