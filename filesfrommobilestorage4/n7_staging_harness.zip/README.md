
# Test Harness PLUS (orchestrated dry-run + queueing)

This adds:
- An **Orchestrator** that reads a YAML **plan** and enqueues operations.
- A **QueueRouter** (priority heap) to sequence ops.
- Governance **stubs** wrapped around each op.
- A **pytest** test to run the orchestrator as part of the suite.
- A **run_dryrun.sh** that executes the orchestrator, then pytest.

## Quick start
```bash
unzip test_harness_plus.zip -d ./e8-tests-plus
cd e8-tests-plus
python -m pip install -e .

# set your code root to the merged build
export CODE_UNDER_TEST=/path/to/your/merged_workspace/canonical_v14  # or ground_up_build
./tools/run_dryrun.sh
```

## Writing a plan
See `plans/example_plan.yml`. Each step:
- `name`: label
- `family`: for governance and metrics
- `module`: import path (must be importable from CODE_UNDER_TEST)
- `func`: attribute in module to call
- `args`/`kwargs`: optional
- `priority`: smaller runs earlier
- `policy_id`: governance policy slot (stubbed now)

Output goes to `dryrun_report.json` (queue records + governance events).
