
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple
from itertools import permutations

@dataclass
class Kernel:
    seed: int
    alphabet: List[str]
    notes: str = ""

def kernel_gen(seed: int = 42, n: int = 7, mode: str = "dry") -> Kernel:
    alphabet = [chr(ord('A') + i) for i in range(3 if mode=='dry' else n)]
    return Kernel(seed=seed, alphabet=alphabet, notes=f"mode={mode}")

def constructor(kernel: Kernel) -> Dict[str, Any]:
    alpha = kernel.alphabet
    seq = ""
    for p in permutations(alpha, len(alpha)):
        seq += ''.join(p)
    return {
        "_artifact": "superperm_candidate",
        "data": {"sequence": seq, "alphabet": alpha, "length": len(seq), "mode": kernel.notes.replace("mode=","")},
        "_optimization_points": ["consider overlap-tightening rewrites"],
        "_weak_spots": ["constructor is naive concatenation (no overlap)"]
    }

def coverage_check(seq: str, alphabet: List[str], exactly_once: bool = True) -> Dict[str, Any]:
    n = len(alphabet)
    counts: Dict[str,int] = {}
    for p in permutations(alphabet, n):
        s = ''.join(p)
        c = 0
        i = 0
        L = len(seq)
        while i <= L - n:
            if seq[i:i+n] == s:
                c += 1
            i += 1
        counts[s] = c
    ok = all(v == 1 for v in counts.values()) if exactly_once else all(v >= 1 for v in counts.values())
    cert = {"alphabet": alphabet, "n": n, "counts": counts}
    return {
        "_artifact": "coverage_cert",
        "data": cert,
        "ok": ok,
        "_weak_spots": [] if ok else ["coverage deviations detected"]
    }

def minimizer(seq: str) -> Dict[str, Any]:
    # placeholder
    return {"_optimization_points": ["implement greedy overlap tightening"], "_weak_spots": ["no minimization implemented"]}

def reproduce(kernel: Kernel, expected: Dict[str, Any]) -> Dict[str, Any]:
    seq = expected.get("data", {}).get("sequence", "")
    ok = True if not seq else (seq == ''.join(''.join(p) for p in permutations(kernel.alphabet, len(kernel.alphabet))))
    return {"reproduced": ok}
