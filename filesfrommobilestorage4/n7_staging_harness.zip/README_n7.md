
# n=7 Superpermutation Dry-Run Staging

This staging plan prepares the test harness to run a **record-match** style governance flow while keeping the execution fast (n=3 DRY alphabet). Swap in the real n=7 solver when ready.

## Files
- `config/policies.yml` — governance thresholds for n7 and 3D.
- `plans/n7_record_dry.yml` — orchestrated queue for DRY run.
- `src/testlib_plus/sequence_provider.py` — interface to plug your real solver.
- `src/testlib_plus/rolling_coverage.py` — faster Rabin–Karp coverage signal.

## Run
```bash
python -m pip install -e .
export CODE_UNDER_TEST=/mnt/data/ground_up_build      # or your source root
export TEST_PLAN=./plans/n7_record_dry.yml
export TOTAL_WALL_MS=600000
export TOTAL_RAM_MB=4096
./tools/run_dryrun.sh
```

Artifacts appear in `artifacts/` and the consolidated report in `dryrun_report.json`.

## Upgrading to real n=7
- Replace `agents.superperm.constructor` with your solver via `sequence_provider.load_provider("module:attr")` (you can add a plan step that calls the provider).
- Point `coverage_check` to the real sequence and switch to a full exactly-once verifier (or use rolling hash as a prefilter, then full verify for candidates).
- Flip governance mode in `config/policies.yml` to **record-match** (already set), so `length <= 5906` is enforced on real runs.
