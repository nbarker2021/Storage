See codebase; CLI usage in README delivered earlier.

## FastAPI server
```
pip install -r requirements.txt
uvicorn lfaicore.api:app --reload
# Try:
#   curl -X POST localhost:8000/frame -H "content-type: application/json" -d '{"glyphs":[8,13,32]}'
#   curl -X POST localhost:8000/verify -H "content-type: application/json" -d '{"vec":[13,7,9,2,18,5,1,12]}'
#   curl -X POST localhost:8000/uplift -H "content-type: application/json" -d '{"vec":[13,7,9,2,18,5,1,12], "steps":3}'
```

## Tests (pytest)
```
pip install -r requirements.txt
pytest -q
```

## ScratchPad HQ Sandbox (Rooms + Personas + Scenarios)
Servers:
```
uvicorn sandbox.api:app --reload --port 8010
uvicorn sandbox.web.server:app --reload --port 8011
```
Docs: `docs/SANDBOX_GUIDE.md`
