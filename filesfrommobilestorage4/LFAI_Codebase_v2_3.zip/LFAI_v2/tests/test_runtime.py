def test_runtime_exec():
    from lfaicore.runtime import OctetExecutor
    from examples.moving_avg_octet import moving_avg_octet
    exe = OctetExecutor()
    out = exe.run(moving_avg_octet, (1,2,3,4,0,0,0,0))
    assert out["ok"] and len(out["out"])==8 and out["pal4_ok"] and out["legal_e8"]

def test_crc32_octet():
    from examples.crc32_octet import crc32_octet
    ret = crc32_octet(1,2,3,4,0,0,0,0)
    assert ret["ok"] and len(ret["out"])==8
