import json, hmac, hashlib, time, requests

class LFAIClient:
    def __init__(self, base="http://localhost:8000"):
        self.base=base
        self.sid=None
        self.key=None

    def start(self, client_info: dict):
        r=requests.post(f"{self.base}/handshake/start", json={"client": client_info}, timeout=10)
        r.raise_for_status()
        d=r.json()
        self.sid, self.key = d["sid"], d["hmac_key"]
        return d

    def _sig(self, payload: dict):
        msg=json.dumps(payload, sort_keys=True).encode()
        return hmac.new(bytes.fromhex(self.key), msg, hashlib.sha256).hexdigest()

    def prefire(self, payload_quad, control=None):
        pay={"sid": self.sid, "payload_quad": payload_quad, "ts": int(time.time())}
        sig=self._sig(pay)
        r=requests.post(f"{self.base}/channel/prefire", json={"sid": self.sid, "payload_quad": payload_quad, "control": control or {}, "sig": sig})
        r.raise_for_status(); return r.json()

    def post(self, out_lanes):
        pay={"sid": self.sid, "out_lanes": out_lanes, "ts": int(time.time())}
        sig=self._sig(pay)
        r=requests.post(f"{self.base}/channel/post", json={"sid": self.sid, "out_lanes": out_lanes, "sig": sig})
        r.raise_for_status(); return r.json()

    def finish(self, commit_payload=None):
        r=requests.post(f"{self.base}/channel/finish", json={"sid": self.sid, "commit_payload": commit_payload or {}}, timeout=10)
        r.raise_for_status(); return r.json()
