import os, json, time, secrets, hmac, hashlib
from typing import Dict, Any, Tuple, List

SESS_PATH = "/mnt/data/lfai_handshake_sessions.json"

def _load():
    if not os.path.exists(SESS_PATH): return {}
    try:
        return json.loads(open(SESS_PATH,"r",encoding="utf-8").read())
    except Exception:
        return {}

def _save(obj):
    open(SESS_PATH,"w",encoding="utf-8").write(json.dumps(obj))

def _now(): return int(time.time())

def start_session(client: Dict[str, Any]) -> Dict[str, Any]:
    sessions=_load()
    sid = secrets.token_hex(16)
    key = secrets.token_hex(32)  # HMAC key
    nonce = secrets.token_hex(8)
    sess = {
        "sid": sid,
        "key": key,
        "nonce": nonce,
        "client": client,
        "created": _now(),
        "state": "OPEN",
        "pre_anchor": None,
        "post_anchor": None,
        "last": None,
    }
    sessions[sid]=sess
    _save(sessions)
    return {"sid": sid, "nonce": nonce, "hmac_key": key}

def sign(key_hex: str, payload: Dict[str, Any]) -> str:
    msg = json.dumps(payload, sort_keys=True, default=str).encode()
    return hmac.new(bytes.fromhex(key_hex), msg, hashlib.sha256).hexdigest()

def verify(key_hex: str, payload: Dict[str, Any], sig: str) -> bool:
    calc = sign(key_hex, payload)
    return hmac.compare_digest(calc, sig)

def get_session(sid: str) -> Dict[str, Any]:
    return _load().get(sid)

def update_session(sid: str, **kw):
    sessions=_load()
    if sid in sessions:
        sessions[sid].update(kw)
        _save(sessions)

def close_session(sid: str):
    update_session(sid, state="CLOSED")
