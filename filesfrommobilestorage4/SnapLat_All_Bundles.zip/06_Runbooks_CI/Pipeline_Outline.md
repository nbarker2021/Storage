# CI/CD Pipeline Outline
Jobs: test-e8, test-shelling, test-underverse, test-dna-replay, test-bridge, test-sap-case, sbom+sign, provenance, policy-as-code.
