# Math & Personas — E8/MDHG/AGRM
Formulas and metrics; personas with triggers & governance.
