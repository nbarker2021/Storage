from sandbox.rooms import RoomConfig, Room
from sandbox.datatypes import ingest
from lfaicore.frame import compile_from_glyphs

def test_make_room_and_ingest():
    r = Room.create(RoomConfig(name="Test Room", purpose="demo", glyphs=[8,13,32]))
    vec = ingest({"foo":1,"bar":2},"json")
    out = r.verify(vec)
    assert 'verdict' in out
    up = r.uplift(vec, steps=2)
    assert up['rest_scale'] >= 16
    a = r.anchor(vec)
    assert 'anchor_id' in a
