# ScratchPad HQ Sandbox

*Rooms* are pluggable workspaces configured by **glyphs**, **persona**, **scenario**, and **known data types**.
- Use the **API** (`sandbox.api:app`) for automation.
- Use the **UI** (`sandbox.web.server:app`) for interactive play.

## Start servers
```
pip install -r requirements.txt
uvicorn sandbox.api:app --reload --port 8010
uvicorn sandbox.web.server:app --reload --port 8011
```

## Create a room
```
curl -X POST :8010/rooms/new -H content-type:application/json -d '{"name":"Nav Room","purpose":"EDL","glyphs":[64,13,5,7,11,32]}'
```

## Ingest known types → vec
POST `/rooms/ingest` with `{room_id, dtype, payload}` where dtype ∈ {text,json,csv,vec}.

## Verify, uplift, anchor
Use `/rooms/verify`, `/rooms/uplift`, `/anchor/match` (from lfaicore.api) or dyn endpoints here.

## Build your own room type
Copy `NewRoom` schema and add your persona/scenario. Extend `sandbox/personas.py` and `sandbox/scenarios.py` to define tools and flows.
