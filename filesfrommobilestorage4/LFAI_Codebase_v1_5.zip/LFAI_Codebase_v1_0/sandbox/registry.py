import json, os
from typing import Dict
from .rooms import Room, RoomConfig
from .personas import BUILTINS as PERSONAS
from .scenarios import BUILTINS as SCENARIOS

REG_PATH = "/tmp/sandbox_registry.json"

def _load() -> Dict[str,dict]:
    if os.path.exists(REG_PATH):
        return json.load(open(REG_PATH,"r"))
    return {}

def _save(reg: Dict[str,dict]):
    os.makedirs(os.path.dirname(REG_PATH), exist_ok=True)
    json.dump(reg, open(REG_PATH,"w"), indent=2)

def list_rooms():
    reg=_load(); return list(reg.values())

def create_room(cfg: dict):
    rc = RoomConfig(**cfg); r = Room.create(rc); reg=_load(); reg[r.id]=r.to_json(); _save(reg); return r

def get_room(rid: str):
    reg=_load(); return reg.get(rid)
