# GAP CHECKS (v1.0)

1) **Con-A / Type-II rigor**: current demo uses extended Hamming [8,4,4] syndrome; port full E8/Leech legality (Construction A via Golay) for production.
2) **Even-neighbor canonicalization**: replace simple parity nudge with a provably minimal 2C lift that preserves zero syndrome.
3) **Reducer optimality**: greedy step ensures monotonicity but not minimal NF; add lexicographic proof-of-decrease and termination measure logging.
4) **Face functionals**: placeholders; replace with calibrated facet equations tied to your domain (navigation, materials, etc.).
5) **Uplift tower policy**: formalize two_adic_max evolution and prove invariants against odd-prime overlays.
6) **Ledger**: switch to a real Merkle-accumulator; add replay tool and hash-consed NF snapshotting.
7) **Contracts**: publish JSON Schemas for GAE/CEC and sign with COSE/JWS.
8) **API**: wire FastAPI (or gRPC) façade; currently CLI only.
9) **DSL VM**: expand opcodes 60..77 and add a verifier to forbid illegal state transitions.
10) **Tests**: add falsifiers F1–F10 as pytest cases with seeded vectors, plus energy/commit measurements.
