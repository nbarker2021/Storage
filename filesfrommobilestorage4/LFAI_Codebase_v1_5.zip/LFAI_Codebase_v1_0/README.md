See codebase; CLI usage in README delivered earlier.

## FastAPI server
```
pip install -r requirements.txt
uvicorn lfaicore.api:app --reload
# Try:
#   curl -X POST localhost:8000/frame -H "content-type: application/json" -d '{"glyphs":[8,13,32]}'
#   curl -X POST localhost:8000/verify -H "content-type: application/json" -d '{"vec":[13,7,9,2,18,5,1,12]}'
#   curl -X POST localhost:8000/uplift -H "content-type: application/json" -d '{"vec":[13,7,9,2,18,5,1,12], "steps":3}'
```

## Tests (pytest)
```
pip install -r requirements.txt
pytest -q
```

## ScratchPad HQ Sandbox (Rooms + Personas + Scenarios)
Servers:
```
uvicorn sandbox.api:app --reload --port 8010
uvicorn sandbox.web.server:app --reload --port 8011
```
Docs: `docs/SANDBOX_GUIDE.md`

## Blockchain conversion (non‑private systems)
CLI:
```
python -m lfaicore.cli chainpack --vec 13,7,9,2,18,5,1,12
```
API:
```
POST /convert/blockchain {"vec":[13,7,9,2,18,5,1,12]}
```
Outputs a ProofBundle + EIP‑712 typed data (for signing), OP_RETURN hex, simple ABI calldata, and a Merkle root.

## Proofs, Contracts, and Chain
- **/proof/state** → returns a verifiable state certificate (syndrome, P4/P8, latches, anchor).
- **/contracts** → emits GAE (attestation), CEC (execution), and a chainpack (EIP‑712, OP_RETURN, ABI calldata).
- **Docker**: `docker build -t lfai . && docker run -p 8000:8000 lfai`
- **CI**: GitHub Actions workflow under `.github/workflows/ci.yml`
- **Schemas**: see `schemas/*.schema.json`
- **On‑chain**: `onchain/LFAIVerifier.sol` minimal verifier skeleton.

## v1.5 highlights
- **Symmetric 8-face gating** (permutation-invariant) — F4 invariance test now passes.
- **/replay/verify** endpoint — deterministic replayer over op sequences.
- **Chainpack** now includes an **IPFS CIDv1 (raw)** for the ProofBundle bytes (non-private notarization path).
- **/proof/state** returns `phi` (normal-form progress vector) alongside pal/syndrome/latches.
