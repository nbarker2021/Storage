from typing import List, Tuple
from .cona import legal_even
from .pal import pal_defects
def phi(vec: List[int]) -> Tuple[int,int,int,int]:
    legal,s = legal_even(vec); pd = pal_defects(vec); return (sum(s), pd['P8'], pd['P4'], 0)
def reduce_step(vec: List[int]) -> List[int]:
    legal,s = legal_even(vec)
    if sum(s)>0:
        i=min(range(len(vec)), key=lambda k: abs(vec[k])); vec[i]+=1; return vec
    pd = pal_defects(vec)
    if pd['P8']>0 or pd['P4']>0:
        i=min(range(len(vec)), key=lambda k: abs(vec[k])); vec[i]+=1; return vec
    return vec
def reduce_to_rest(vec: List[int], max_steps=256) -> List[int]:
    steps=0
    while steps<max_steps:
        steps+=1
        v2 = reduce_step(list(vec))
        if v2==vec: return vec
        vec=v2
    return vec
