from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from .frame import compile_from_glyphs, Frame
from .cona import legal_even, bits_from_vec
from .pal import pal_defects
from .uplift import uplift_u2
from .gating import latch_sweep
from .reducer import reduce_to_rest
from .anchors import anchor_id

app = FastAPI(title="LFAI Legality-First API", version="1.1.0")

class FrameIn(BaseModel):
    glyphs: List[int] = Field(default_factory=lambda:[8,13,32])

class VecIn(BaseModel):
    vec: List[int]
    glyphs: Optional[List[int]] = None
    steps: Optional[int] = 1

@app.post("/frame")
def make_frame(body: FrameIn):
    f = compile_from_glyphs(body.glyphs)
    return {"frame_hash": f.hash(), "rest_scale": f.rest_scale, "dyadic_depth": f.dyadic_depth, "mods": f.mods, "faces": f.faces}

@app.post("/verify")
def verify(body: VecIn):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    legal, s = legal_even(body.vec)
    pd = pal_defects(body.vec)
    latch = latch_sweep(body.vec)
    verdict = "OPEN" if (legal and pd["P4"]==0 and pd["P8"]==0) else "PROVISIONAL_OPEN"
    return {"vec": body.vec, "bits": bits_from_vec(body.vec), "syndrome": s, "pal": pd, "latches": latch, "verdict": verdict}

@app.post("/uplift")
def uplift(body: VecIn):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    vec = list(body.vec)
    steps = int(body.steps or 1)
    for _ in range(steps):
        vec, f = uplift_u2(vec, f)
    return {"vec": vec, "rest_scale": f.rest_scale, "dyadic_depth": f.dyadic_depth, "mods": f.mods}

@app.post("/gate/scan")
def gate_scan(body: VecIn):
    latch = latch_sweep(body.vec)
    return {"latches": latch, "ready_to_advance": all(latch)}

@app.post("/advance")
def advance(body: VecIn):
    latch = latch_sweep(body.vec)
    return {"advanced": bool(all(latch)), "latches": latch}

@app.post("/anchor/match")
def anchor_match(body: VecIn):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    aid, bits = anchor_id(body.vec, f)
    return {"anchor_id": aid, "bounds_sig": bits}

from .pal import pal_defects
from .blockchain import export_chainpack

class ConvertBody(BaseModel):
    vec: List[int]
    glyphs: Optional[List[int]] = None

@app.post("/convert/blockchain")
def convert_blockchain(body: ConvertBody):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    aid, latches = anchor_id(body.vec, f)
    pal = pal_defects(body.vec)
    return export_chainpack(aid, f.hash(), f.rest_scale, latches, pal)

class ProofBody(BaseModel):
    vec: List[int]
    glyphs: Optional[List[int]] = None

@app.post("/proof/state")
def proof_state(body: ProofBody):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    legal, s = legal_even(body.vec)
    pd = pal_defects(body.vec)
    latch = latch_sweep(body.vec)
    aid, bits = anchor_id(body.vec, f)
    return {
        "frame_hash": f.hash(),
        "rest_scale": f.rest_scale,
        "dyadic_depth": f.dyadic_depth,
        "mods": f.mods,
        "syndrome": s,
        "pal": {"P4": pd["P4"], "P8": pd["P8"]},
        "phi": [int(sum(s)), int(pd["P8"]), int(pd["P4"]), 0],
        "latches": latch,
        "anchor_id": aid,
        "bounds_sig": bits,
        "verdict": "OPEN" if (legal and pd["P4"]==0 and pd["P8"]==0) else "PROVISIONAL_OPEN"
    }

from .contracts import gae, cec
from .pal import pal_defects
from .blockchain import export_chainpack

@app.post("/contracts")
def contracts(body: ProofBody):
    f = compile_from_glyphs(body.glyphs or [8,13,32])
    aid, bits = anchor_id(body.vec, f)
    pd = pal_defects(body.vec)
    ngd = {"thresholds": ["repr_1_8","drive_1_4"], "scale_family": f.rest_scale, "residues": f.mods, "faces": ["octad"], "witnesses": ["pal","syndrome"]}
    G = gae("token", ngd, f.rest_scale, f.dyadic_depth, max([m for m in f.mods if m & (m-1)==0]))
    C = cec(G["ngd_sha256"], bits, {"theta4": pd["P4"], "theta8": pd["P8"]})
    chain = export_chainpack(aid, f.hash(), f.rest_scale, bits, {"P4": pd["P4"], "P8": pd["P8"]})
    return {"gae": G, "cec": C, "chainpack": chain}

from typing import Any
class ReplayBody(BaseModel):
    ops: List[Dict[str,Any]]
    glyphs: Optional[List[int]] = None

@app.post("/replay/verify")
def replay_verify(body: ReplayBody):
    from .ledger_merkle import replay_ops, MerkleLedger
    out = replay_ops(body.ops, glyphs=body.glyphs or [8,13,32])
    return out
