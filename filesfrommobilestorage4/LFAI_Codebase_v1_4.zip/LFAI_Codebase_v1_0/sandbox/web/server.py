from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from .templates import render_index
from ..registry import create_room, list_rooms, get_room
from ..datatypes import ingest
from lfaicore.frame import compile_from_glyphs
from lfaicore.uplift import uplift_u2
from lfaicore.cona import legal_even
from lfaicore.pal import pal_defects
from lfaicore.gating import latch_sweep

app = FastAPI(title="ScratchPad UI")

app.mount("/static", StaticFiles(directory="/mnt/data/static", html=True), name="static")

@app.get("/", response_class=HTMLResponse)
def index():
    return render_index(list_rooms())

@app.post("/new", response_class=HTMLResponse)
def new_room(name: str = Form(...), purpose: str = Form("")):
    r = create_room({"name": name, "purpose": purpose, "glyphs":[8,13,32], "faces":["octad"], "data_types":["text","json","csv","vec"]})
    return RedirectResponse("/", status_code=303)

@app.post("/ingest", response_class=HTMLResponse)
def ingest_payload(room_id: str = Form(...), dtype: str = Form(...), payload: str = Form("")):
    vec = ingest(payload, dtype)
    meta = get_room(room_id); f = compile_from_glyphs(meta["cfg"]["glyphs"])
    legal, s = legal_even(vec); pd = pal_defects(vec); l = latch_sweep(vec)
    return render_index(list_rooms(), vec=vec, verdict=("OPEN" if legal and pd['P4']==0 and pd['P8']==0 else "PROVISIONAL_OPEN"), pal=pd, latch=l, room_id=room_id)
