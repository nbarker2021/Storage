from typing import Any, Dict, List
import json, csv, io

def ingest(payload: Any, dtype: str) -> List[int]:
    # Map known types to a vector (demo: simple, deterministic hashing/quantization)
    if dtype=='vec':
        assert isinstance(payload, list) and all(isinstance(x,int) for x in payload), "vec expects int list"
        return payload
    if dtype=='json':
        s=json.dumps(payload, sort_keys=True)
        return [ (sum(s.encode()) + i*7) % 29 for i in range(8) ]
    if dtype=='text':
        s=str(payload)
        return [ (sum(s.encode()) + i*11) % 31 for i in range(8) ]
    if dtype=='csv':
        if isinstance(payload, str): f=io.StringIO(payload)
        else: f=io.StringIO(payload.decode('utf-8','replace'))
        r=list(csv.reader(f)); flat=",".join([",".join(row) for row in r])
        return [ (sum(flat.encode()) + i*5) % 37 for i in range(8) ]
    raise ValueError(f"Unknown dtype {dtype}")
