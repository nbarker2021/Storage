import argparse, json
from .frame import compile_from_glyphs
from .cona import legal_even, bits_from_vec
from .pal import pal_defects
from .uplift import uplift_u2
from .gating import latch_sweep
from .reducer import reduce_to_rest, phi
from .anchors import anchor_id
from .dsl8x8.asm import assemble, disassemble
from .dsl8x8 import vm
def parse_vec(s): return [int(x) for x in s.split(',')]
def cmd_init(args):
    f = compile_from_glyphs([8,13,32]); print(json.dumps({'frame_hash': f.hash(), 'mods': f.mods, 'rest_scale': f.rest_scale}, indent=2))
def cmd_verify(args):
    vec = parse_vec(args.vec); f = compile_from_glyphs([8,13,32]); legal, s = legal_even(vec); pd = pal_defects(vec); latch = latch_sweep(vec)
    verdict = 'REST' if legal and pd['P4']==0 and pd['P8']==0 else 'ACTION'
    print(json.dumps({'vec':vec,'bits':bits_from_vec(vec),'syndrome':s,'pal':pd,'latches':latch,'verdict':verdict}, indent=2))
def cmd_reduce(args):
    vec = parse_vec(args.vec); v2 = reduce_to_rest(vec); print(json.dumps({'before':vec,'after':v2,'phi_before':phi(vec),'phi_after':phi(v2)}, indent=2))
def cmd_uplift(args):
    vec = parse_vec(args.vec); f = compile_from_glyphs([8,13,32])
    for _ in range(args.steps): vec, f = uplift_u2(vec, f)
    print(json.dumps({'vec':vec,'rest_scale':f.rest_scale,'mods':f.mods,'dyadic_depth':f.dyadic_depth}, indent=2))
def cmd_gate(args):
    vec = parse_vec(args.vec); print(json.dumps({'latches':latch_sweep(vec)}, indent=2))
def cmd_anchor(args):
    vec = parse_vec(args.vec); f=compile_from_glyphs([8,13,32]); aid,b = anchor_id(vec,f); print(json.dumps({'anchor_id':aid,'bounds_sig':b}, indent=2))
def cmd_dsl_asm(args):
    buf = assemble(open(args.input,'r').read().splitlines()); open(args.output,'wb').write(buf); print(json.dumps({'bytes':len(buf)}, indent=2))
def cmd_dsl_disasm(args):
    print(disassemble(open(args.input,'rb').read()))
def cmd_dsl_run(args):
    buf = open(args.input,'rb').read(); vec = parse_vec(args.vec) if args.vec else [13,7,9,2,18,5,1,12]; f=compile_from_glyphs([8,13,32])
    out = vm.run(buf, vec, f)
    out2={'vec':out['vec'],'frame':{'rest_scale':out['frame'].rest_scale,'dyadic_depth':out['frame'].dyadic_depth,'mods':out['frame'].mods},'latches':out['latches'],'pins_required':out['pins_required'],'pins_satisfied':out['pins_satisfied'],'payloads_count':out['payloads_count']}
    print(json.dumps(out2, indent=2))
# --- Blockchain exports ---
def cmd_chainpack(args):
    from .anchors import anchor_id
    from .pal import pal_defects
    from .frame import compile_from_glyphs
    from .blockchain import export_chainpack
    vec = parse_vec(args.vec); f=compile_from_glyphs([8,13,32]); aid,latches = anchor_id(vec, f); pal = pal_defects(vec)
    pack = export_chainpack(aid, f.hash(), f.rest_scale, latches, pal)
    print(json.dumps(pack, indent=2))


# --- Merkle ledger commands ---
def cmd_ledger(args):
    from .ledger_merkle import MerkleLedger
    led = MerkleLedger(args.path)
    if args.mode == "append":
        import json
        rec = json.loads(args.record)
        h = led.append(rec)
        print(json.dumps({"appended": h, "root": led.root()}, indent=2))
    elif args.mode == "root":
        print(json.dumps({"root": led.root()}, indent=2))
    elif args.mode == "proof":
        print(json.dumps(MerkleLedger(args.path).proof(int(args.index)), indent=2))

# --- Replay ---
def cmd_replay(args):
    import json
    from .ledger_merkle import replay_ops
    ops = json.loads(open(args.ops,"r").read())
    out = replay_ops(ops, glyphs=[8,13,32])
    print(json.dumps(out, indent=2))

def main():

    import argparse
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers()
    p=sub.add_parser('init'); p.set_defaults(func=cmd_init)
    p=sub.add_parser('verify'); p.add_argument('--vec', required=True); p.set_defaults(func=cmd_verify)
    p=sub.add_parser('reduce'); p.add_argument('--vec', required=True); p.set_defaults(func=cmd_reduce)
    p=sub.add_parser('uplift'); p.add_argument('--vec', required=True); p.add_argument('--steps', type=int, default=1); p.set_defaults(func=cmd_uplift)
    p=sub.add_parser('gate'); p.add_argument('--vec', required=True); p.set_defaults(func=cmd_gate)
    p=sub.add_parser('anchor'); p.add_argument('--vec', required=True); p.set_defaults(func=cmd_anchor)
    p=sub.add_parser('dsl-assemble'); p.add_argument('input'); p.add_argument('-o','--output', required=True); p.set_defaults(func=cmd_dsl_asm)
    p=sub.add_parser('dsl-disasm'); p.add_argument('input'); p.set_defaults(func=cmd_dsl_disasm)
    p=sub.add_parser('dsl-run'); p.add_argument('input'); p.add_argument('--vec'); p.set_defaults(func=cmd_dsl_run)
    args=ap.parse_args(); 
    if hasattr(args,'func'): args.func(args)
    else: ap.print_help()
if __name__=='__main__': main()
