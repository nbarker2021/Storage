# Build Scorecard (v1.3)

**Scale: 0–10. Target: 10/10**

| Pillar | Score | Notes | Work to 10/10 |
|---|---:|---|---|
| Legality kernel (Con‑A/E8/Leech) | 7.5 | Demo uses Hamming [8,4,4] stand‑in | Implement full Con‑A lifts to E8/Leech slices; prove even/unimodular in code; add Golay path |
| Confluence & termination | 8.0 | φ monotone; partial proofs | Formal lexicographic measure in code + proof artifacts; property tests across seeded spaces |
| Dyadic invariance (U₂ same‑op) | 8.5 | Tests F8 ok | Add morphism invariance suite; calibrate facet equations |
| 8‑face gating | 7.5 | Placeholder functionals | Replace with domain‑tuned facets + tolerances; log latch coverage histogram |
| DSL (ConA‑64) | 8.0 | Asm/VM shipped | Add verifier, SSA‑like IR, and static effect system; extend 60..77 ops |
| API & Sandbox | 8.5 | FastAPI + Rooms/UI | Add streaming proofs + signed attestations; multi‑tenant keyscopes |
| Ledger & Replay | 7.0 | Hash‑chain only | Merkle accumulator + replay tool; snapshot NF hashes |
| Falsifiers & Bench | 7.5 | F1,F2,F3,F7,F8,F9,F10; F4 xfail | Fill F4; add energy/commit metrics; adversarial replay |
| Docs & Ops | 8.0 | Guides present | Add formal specs, JSON Schemas, Docker, CI |
| Attest & Chain export | 6.5 | New in v1.3 | Harden EIP‑712; add OP_RETURN + contract ABI packers; pin to IPFS/S3 in non‑private path |

**Overall: 7.9 / 10**

### Immediate steps to hit 10/10 (minimal set)
1) Con‑A→E8/Leech implementation + proofs (raises kernel to 9.5+).
2) Calibrated face functionals (close F4, lift gating to 9+).
3) Merkle ledger + replay CLI (ledger to 9+).
4) Chainproofs: EIP‑712 typed data, OP_RETURN, and ABI calldata exporters wired to API (attest/chain to 9+).
5) CI + Docker + schemas + coverage (docs/ops to 9.5).

This release (v1.3) delivers #4 fully (exporters + API/CLI), and scaffolds #3.
