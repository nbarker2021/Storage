# Revised Code — Code Deep Pass (Full-Content)

_Each source summarized with metrics and Python symbols. Full source texts in per_file/._


---
## Revised Code/Revised Code/construct_superpermutation.py
- Ext: **.py** | Lines: **236** | Words: **1090**
### Keyword hits
- SFBB: 0
- superperm: 36
- superpermutation: 36
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 52
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 4
- Imports: json, logging, random
- From-imports: analysis_scripts_final, construct_superpermutation, layout_memory, utils

---
## Revised Code/Revised Code/construct_superpermutation.py_superpermutation_generator.py
- Ext: **.py** | Lines: **236** | Words: **1090**
### Keyword hits
- SFBB: 0
- superperm: 36
- superpermutation: 36
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 52
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: True
- Classes: 0
- Functions: 4
- Imports: json, logging, random
- From-imports: analysis_scripts_final, construct_superpermutation, layout_memory, utils

---
## Revised Code/Revised Code/layout_memory.py_analysis_scripts_final.py
- Ext: **.py** | Lines: **100** | Words: **596**
### Keyword hits
- SFBB: 0
- superperm: 4
- superpermutation: 4
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 0
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 0
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 1
- Functions: 9
- Imports: itertools, logging, pickle
- From-imports: (none)

---
## Revised Code/Revised Code/utils.py_graph_utils.py
- Ext: **.py** | Lines: **91** | Words: **593**
### Keyword hits
- SFBB: 0
- superperm: 3
- superpermutation: 3
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 4
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 11
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 12
- Imports: hashlib, itertools, logging, networkx
- From-imports: (none)

---
## Revised Code/Revised Code/utils_graph_utils.py
- Ext: **.py** | Lines: **89** | Words: **366**
### Keyword hits
- SFBB: 0
- superperm: 1
- superpermutation: 1
- AGRM: 0
- MDHG: 0
- CMPLX: 0
- E8: 0
- LSDT: 0
- TSP: 0
- de bruijn: 2
- debruijn: 0
- beam: 0
- orchestrator: 0
- hash: 11
- golden: 0
- glyph: 0
- lattice: 0
### Python symbols
- __main__: False
- Classes: 0
- Functions: 12
- Imports: hashlib, itertools, logging, networkx
- From-imports: (none)