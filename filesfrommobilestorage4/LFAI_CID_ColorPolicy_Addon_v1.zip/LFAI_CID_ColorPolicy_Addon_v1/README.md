# LFAI — Color/Policy CID Add‑On

Drop `lfaicore/cid.py` into your codebase and compute a **Color ID (CID)** bound to permission tokens + endpoint prefix.
Add headers in responses: `X-Color-ID`, `X-Policy-ID`, `X-Permission-JTI`, `X-Contract-Sub`, `X-Anchor`.
Store `{cid, cid_tag, policy_id, sub, jti}` into your ledger entries.
See `docs/CID_COLOR_POLICY.md` for details.
