# Color/Policy CID Binding (v2.9)

**Goal:** lightweight, human-visible policy skin that is cryptographically bound to permission tokens—without weakening enforcement.

## How it works
- Server derives a **Color ID (CID)** per request from: (secret, token.sub, token.policy_id, endpoint-prefix).
- CID is returned in headers and stored in the ledger alongside token identifiers.
- Enforcement remains in **JWS/contract middleware**; CID is a display/audit signal only.

## Headers
- `X-Color-ID`: `#RRGGBB` hex
- `X-Policy-ID`: policy identifier (e.g., EVAL, STRICT, PARTNER)
- `X-Permission-JTI`: token id
- `X-Contract-Sub`: token subject (grantee)
- `X-Anchor`: anchor id (when applicable)

## Ledger addendum
Each entry includes: `cid`, `cid_tag`, `policy_id`, `sub`, `jti`.
