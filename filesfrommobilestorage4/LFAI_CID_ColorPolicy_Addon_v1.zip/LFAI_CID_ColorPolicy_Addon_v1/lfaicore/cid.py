import hmac, hashlib

def _to_hex_color(digest: bytes) -> str:
    # Use first 3 bytes for RGB
    r, g, b = digest[0], digest[1], digest[2]
    return f"#{r:02x}{g:02x}{b:02x}"

def compute_cid(secret: bytes, sub: str, policy_id: str, endpoint_prefix: str) -> tuple[str, str]:
    """Return (cid_hex, tag_hex) derived from secret + identity.
    tag_hex is the full HMAC digest hex (for ledger); cid_hex is #RRGGBB for UI.
    """
    msg = f"{sub}|{policy_id}|{endpoint_prefix}".encode()
    dig = hmac.new(secret, msg, hashlib.sha256).digest()
    return _to_hex_color(dig), dig.hex()
