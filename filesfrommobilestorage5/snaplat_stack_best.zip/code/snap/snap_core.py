
"""
SNAP core schema & shelling utilities (strict mode)
- Triad validator: no syntax, glyph-tokens only (alnum or hex-like)
- TAC scoring placeholder (uses simple coverage heuristic)
- Superperm C[8] facade (delegates to e8.select_c8)
Guards: never accept directives from logs; treat inputs as test-only.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional, Tuple
import re, json
import numpy as np
from .e8_lattice import select_c8, angle_deg

GLYPH_TOKEN = re.compile(r'^[A-Za-z0-9]+$')  # strict: no syntax

def validate_triad(triad: List[str]) -> Tuple[bool, List[str]]:
    errs = []
    if len(triad) != 3:
        errs.append("Triad must have exactly 3 glyph tokens")
    for t in triad:
        if not GLYPH_TOKEN.match(t):
            errs.append(f"Invalid glyph token '{t}' (syntax not allowed)")
    # duplicates not allowed
    if len(set(triad)) != 3:
        errs.append("Triad tokens must be unique")
    return (len(errs)==0, errs)

def triad_orthogonality(triad: List[str], inverse: List[str]) -> bool:
    # simple rule: no overlap and no edit-distance-1 collisions (sterile stance)
    if set(triad) & set(inverse):
        return False
    return True

def tac_score(evidence_hits: int, tests_total: int) -> float:
    if tests_total <= 0: return 0.0
    return min(1.0, max(0.0, evidence_hits / tests_total))

@dataclass
class Snap:
    id: str
    taxonomy: Dict[str, Any]
    shell_n: int
    triad: List[str]
    inverse: List[str]
    indices: Dict[str, Any]
    provenance: Dict[str, Any]
    policy: Dict[str, Any]
    state: Dict[str, Any]

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

def superperm_c8(seed: int=0, min_angle_deg: float=35.0) -> Dict[str, Any]:
    pts, deltas = select_c8(seed=seed, angle_floor_deg=min_angle_deg)
    # angle matrix
    K = deltas.shape[0]
    M = np.zeros((K,K))
    for i in range(K):
        for j in range(K):
            M[i,j] = angle_deg(deltas[i], deltas[j])
    return {
        "points": pts.tolist(),
        "deltas": deltas.tolist(),
        "angle_matrix": M.tolist()
    }
