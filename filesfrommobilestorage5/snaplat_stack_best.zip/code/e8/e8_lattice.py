
"""
E8 lattice utilities (minimal, deterministic).
- Root generation (240 roots)
- Nearest lattice quantizer (Babai-style for E8)
- Angle computations
- Simple "C[8]" selection with diversity (angle floor)
- Coxeter-like 2D projection (via orthogonal reflection product, PCA fallback)
No external assumptions; pure math.
"""
from __future__ import annotations
from dataclasses import dataclass
import math, random
from typing import List, Tuple
import numpy as np

# ---------------- roots ----------------
def e8_roots() -> np.ndarray:
    """Return the 240 roots of E8 as an (240,8) float array."""
    roots = []
    # 112 roots of type ±e_i ± e_j, i<j
    for i in range(8):
        for j in range(i+1, 8):
            for s1 in (+1, -1):
                for s2 in (+1, -1):
                    v = np.zeros(8, dtype=float)
                    v[i] = s1
                    v[j] = s2
                    roots.append(v)
    # 128 roots of type (±1/2)^8 with even number of minus signs
    for mask in range(1<<8):
        bits = [(mask>>k) & 1 for k in range(8)]
        minus_count = sum(bits)
        if minus_count % 2 == 0:  # even number of minus signs
            v = np.array([(-0.5 if b else 0.5) for b in bits], dtype=float)
            roots.append(v)
    R = np.stack(roots, axis=0)
    assert R.shape == (240, 8)
    # Normalize each root to length sqrt(2) (already true), keep anyway for numeric hygiene
    return R

# -------------- nearest quantizer ---------------
def nearest_e8(x: np.ndarray) -> np.ndarray:
    """
    Nearest point in E8 (as D8 ∪ (D8 + 1/2)), following Conway–Sloane style parity fixes.
    Strategy:
      - Candidate A: nearest D8 (integers with even sum)
      - Candidate B: nearest (Z+0.5)^8 with parity rule (sum of ints must be odd)
      - Return closer to x.
    """
    x = np.asarray(x, dtype=float).reshape(-1)
    assert x.shape[0] == 8

    # candidate A: integers with even sum
    ya = np.rint(x)  # nearest integers
    if int(ya.sum()) % 2 != 0:
        # flip the coordinate with smallest fractional distance to change parity
        frac = np.abs(x - ya)
        i = int(np.argmin(frac))
        # Move ya[i] by ±1 toward x to change parity
        ya[i] += 1.0 if (x[i] - ya[i]) > 0 else -1.0

    # candidate B: half-integers with odd integer sum before shift (standard E8 convention)
    z = x - 0.5
    yb_int = np.rint(z)  # integers
    if int(yb_int.sum()) % 2 == 0:
        frac = np.abs(z - yb_int)
        j = int(np.argmin(frac))
        yb_int[j] += 1.0 if (z[j] - yb_int[j]) > 0 else -1.0
    yb = yb_int + 0.5

    da = np.sum((x - ya)**2)
    db = np.sum((x - yb)**2)
    return ya if da <= db else yb

def angle_deg(u: np.ndarray, v: np.ndarray, eps: float=1e-12) -> float:
    u = np.asarray(u, dtype=float); v = np.asarray(v, dtype=float)
    nu = np.linalg.norm(u); nv = np.linalg.norm(v)
    if nu < eps or nv < eps:
        return 0.0
    c = float(np.clip(np.dot(u, v) / (nu * nv), -1.0, 1.0))
    return math.degrees(math.acos(c))

# -------------- C[8] selection ------------------
def select_c8(seed: int=0, angle_floor_deg: float=35.0) -> Tuple[np.ndarray, np.ndarray]:
    """
    Select eight lattice points around origin with diverse directions.
    Build as: accumulate 8 root directions (unit) with pairwise angle >= floor.
    Return (points, deltas) where points are quantized positions at small step along those roots.
    """
    rng = random.Random(seed)
    R = e8_roots()
    # Shuffle roots deterministically
    idx = list(range(len(R)))
    rng.shuffle(idx)
    chosen_dirs = []
    for k in idx:
        candidate = R[k]
        # Normalize to unit direction
        d = candidate / (np.linalg.norm(candidate) + 1e-12)
        ok = True
        for prev in chosen_dirs:
            if angle_deg(d, prev) < angle_floor_deg:
                ok = False; break
        if ok:
            chosen_dirs.append(d)
        if len(chosen_dirs) == 8:
            break
    if len(chosen_dirs) < 8:
        # fallback: relax floor until we get 8
        for relax in (30, 25, 20, 15):
            for k in idx:
                if len(chosen_dirs) == 8: break
                d = R[k] / (np.linalg.norm(R[k]) + 1e-12)
                ok = True
                for prev in chosen_dirs:
                    if angle_deg(d, prev) < relax:
                        ok = False; break
                if ok: chosen_dirs.append(d)
            if len(chosen_dirs) == 8: break

    # Place points by stepping along directions and quantizing
    step = 0.9  # small step; keeps candidates near distinct cells
    pts = []
    deltas = []
    base = np.zeros(8)
    for d in chosen_dirs:
        raw = base + step * d
        q = nearest_e8(raw)
        pts.append(q)
        deltas.append(d)
    return np.stack(pts, 0), np.stack(deltas, 0)

# -------------- "Coxeter-like" projection -------
def coxeter_like_plane(R: np.ndarray, seed: int=0) -> np.ndarray:
    """
    Construct an orthogonal transform as a product of 8 Householder reflections around random roots,
    then take the first two columns as a plane. PCA fallback if needed.
    Returns a (2,8) projection matrix P so that y2d = P @ x.
    """
    rng = np.random.default_rng(seed)
    roots = R.copy()
    roots /= np.linalg.norm(roots, axis=1, keepdims=True) + 1e-12
    # start with identity
    M = np.eye(8)
    # product of reflections
    for _ in range(8):
        r = roots[rng.integers(0, len(roots))]
        H = np.eye(8) - 2.0 * np.outer(r, r)  # Householder reflector
        M = H @ M
    # take top-2 principal directions (PCA on transformed roots)
    X = (M @ roots.T).T
    X -= X.mean(0, keepdims=True)
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    P = Vt[:2, :]  # 2x8
    return P

# -------------- boundary sweep ------------------
def boundary_sweeps(points: np.ndarray, sweeps: int=8, step: float=0.25) -> List[int]:
    """
    For each point, walk along 'sweeps' orthonormal random directions and count Voronoi changes.
    Returns list of counts per point.
    """
    rng = np.random.default_rng(0)
    counts = []
    for p in points:
        base_cell = nearest_e8(p)
        c = 0
        # create an orthonormal frame via QR of random matrix
        A = rng.normal(size=(8, sweeps))
        Q, _ = np.linalg.qr(A)  # 8xsweeps orthonormal
        for k in range(sweeps):
            for sgn in (+1, -1):
                for m in range(1, 4):
                    x = p + sgn * m * step * Q[:, k]
                    if (nearest_e8(x) != base_cell).any():
                        c += 1
                        break
        counts.append(c)
    return counts

# -------------- replay determinism --------------
def replay_ok(points: np.ndarray) -> bool:
    for p in points:
        if (nearest_e8(nearest_e8(p)) != nearest_e8(p)).any():
            return False
    return True
