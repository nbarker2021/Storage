
"""
ThinkTank / DTT / Assembly minimal stubs with strict guards.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
import numpy as np
from .snap_core import validate_triad, triad_orthogonality, superperm_c8
from .e8_lattice import nearest_e8, angle_deg

@dataclass
class TTResult:
    triad_ok: bool
    triad_errors: List[str]
    c8: Dict[str, Any]

class ThinkTank:
    STRICT = True
    def propose(self, triad: List[str], inverse: List[str]) -> TTResult:
        ok, errs = validate_triad(triad)
        if not triad_orthogonality(triad, inverse):
            errs.append("Triad and inverse overlap or collide")
            ok = False
        c8 = superperm_c8(seed=0, min_angle_deg=35.0) if ok else {"points": [], "deltas": [], "angle_matrix": []}
        return TTResult(ok, errs, c8)

class DTT:
    def boundary_hits(self, points: List[List[float]]) -> int:
        pts = np.array(points, dtype=float)
        hits = 0
        for p in pts:
            base = nearest_e8(p)
            # probe a small ball
            for axis in range(8):
                step = np.zeros(8); step[axis] = 0.25
                if (nearest_e8(p+step) != base).any(): hits += 1; break
        return hits

class Assembly:
    def stitch_weights(self, deltas) -> List[float]:
        # Favor diversity: uniform weights over 8
        if not deltas: return []
        k = len(deltas); return [1.0/k]*k
