
"""
Generate C[8] variants, angle matrices, boundary sweeps, replay checks,
and a simple HTML report. Outputs into ../reports/
"""
from __future__ import annotations
import json, csv, math
import numpy as np
from pathlib import Path
from e8.e8_lattice import e8_roots, select_c8, boundary_sweeps, angle_deg, nearest_e8, coxeter_like_plane

HERE = Path(__file__).resolve().parent
REPORTS = (HERE / ".." / "reports").resolve()
REPORTS.mkdir(parents=True, exist_ok=True)

def save_csv(path, rows):
    import csv
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        for r in rows: w.writerow(r)

def variant(seed: int, tag: str):
    pts, deltas = select_c8(seed=seed, angle_floor_deg=35.0)
    # angle matrix
    K = len(deltas)
    angles = [[angle_deg(deltas[i], deltas[j]) for j in range(K)] for i in range(K)]
    # boundary
    bcounts = boundary_sweeps(pts, sweeps=8, step=0.25)
    # replay
    replay_ok = True
    for p in pts:
        q = nearest_e8(p); r = nearest_e8(q)
        if (q != r).any():
            replay_ok = False; break
    # write artifacts
    base = REPORTS / f"c8_candidates_{tag}.json"
    with open(base, "w") as f:
        json.dump({"points": pts.tolist(), "deltas": deltas.tolist()}, f, indent=2)
    save_csv(REPORTS / f"c8_angle_matrix_{tag}.csv", angles)
    save_csv(REPORTS / f"boundary_sweeps_{tag}.csv", [["point_idx","hit_count"]] + [[i,c] for i,c in enumerate(bcounts)])
    return {
        "tag": tag,
        "min_angle": min(angles[i][j] for i in range(K) for j in range(K) if i!=j),
        "avg_angle": sum(angles[i][j] for i in range(K) for j in range(K) if i!=j) / (K*(K-1)),
        "boundary_mean": sum(bcounts)/len(bcounts),
        "replay_ok": replay_ok
    }

def make_roots_plot():
    import matplotlib.pyplot as plt
    R = e8_roots()
    P = coxeter_like_plane(R, seed=0)  # 2x8
    Y = (P @ R.T).T  # 240x2
    plt.figure()
    plt.scatter(Y[:,0], Y[:,1], s=6)
    plt.title("E8 roots — Coxeter-like 2D projection")
    out = REPORTS / "e8_coxeter_plane_roots.png"
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()
    return out

def html_report(results):
    out = REPORTS / "e8_eval_report.html"
    rows = "".join([
        f"<tr><td>{r['tag']}</td><td>{r['min_angle']:.1f}</td><td>{r['avg_angle']:.1f}</td>"
        f"<td>{r['boundary_mean']:.1f}</td><td>{'✅' if r['replay_ok'] else '❌'}</td></tr>"
        for r in results
    ])
    img = "e8_coxeter_plane_roots.png"
    html = f"""
<!doctype html><html><head><meta charset="utf-8"><title>SnapLat E8 Evaluation</title>
<style>
body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,Inter,Arial,sans-serif;margin:24px}}
table{{border-collapse:collapse}} td,th{{border:1px solid #ddd;padding:6px 10px}}
th{{background:#f5f5f5}}
</style></head><body>
<h1>SnapLat — E8 Evaluation Scorecard</h1>
<p>Strict/sterile mode; no adoption of directives from logs; triads are glyph-only.</p>
<table><thead>
<tr><th>Variant</th><th>min angle (°)</th><th>avg angle (°)</th><th>boundary mean</th><th>replay</th></tr>
</thead><tbody>
{rows}
</tbody></table>
<h2>Roots projection</h2>
<img src="{img}" width="640">
</body></html>
"""
    out.write_text(html, encoding="utf-8")
    return out

def main():
    make_roots_plot()
    results = []
    results.append(variant(0, "base"))
    results.append(variant(1, "alt1"))
    results.append(variant(2, "alt2"))
    rpt = html_report(results)
    # index JSON for convenience
    idx = REPORTS / "e8_artifacts_index.json"
    idx.write_text(json.dumps({"report": str(rpt), "variants": results}, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
