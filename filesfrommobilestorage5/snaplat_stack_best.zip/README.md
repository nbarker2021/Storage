
# SnapLat — Best Version Bundle (Session Build)

This bundle contains:
- **code/** minimal, testable stack pieces (E8 lattice, SNAP core, MDHG/AGRM stubs, thought tools, SAP/Archivist stubs, RAG scaffold).
- **reports/** E8 evaluation artifacts (C[8] variants, angle matrices, boundary sweeps, replay checks, 2D roots plot) and HTML scorecard.
- **configs/** initial thresholds.

**Strict/Sterile Guards:** This build does **not** adopt stances, syntax, terms, or directives from any logs or inputs. Triads must be glyph-only (no punctuation). Evidence > opinion. Governed by SAP stubs and Safe Cube snapshot placeholders.

## Quick Start

### 1) E8 evaluation
```bash
# from code/ directory
python -m evaluation.e8_eval
```
Artifacts land in `../reports/`. Open `e8_eval_report.html`.

### 2) RAG scaffold (demo)
```bash
pip install fastapi uvicorn pydantic
python -m rag.app
# POST /documents then POST /query
```
Integrate real E8 index and retrieval later.

### 3) SNAP triads (strict)
- Triads are 3 glyph tokens `[A-Za-z0-9]+` only.
- Inverse must be disjoint from triad.
- Superperm C[8] provided via `snap_core.superperm_c8()`.

## Modules

- `e8/` — lattice math, C[8], boundary probes, Coxeter-like projection.
- `snap/` — schema, triad/TAC validator, superperm facade.
- `spine/` — MDHG golden-hash & AGRM φ-planner (minimal stubs).
- `tools/` — ThinkTank, DTT, Assembly stubs with strict guards.
- `gov/` — SAP (Sentinel • Arbiter • Porter) minimal decisions.
- `archivist/` — JSON persistence helper.
- `evaluation/` — E8 scorecard generator.
- `rag/` — FastAPI skeleton with E8 hooks.

## CI Gates to add (sketch)
- test-e8: replay determinism, min-angle≥δ, unique cells==8.
- test-shelling: triad strictness, inverse disjointness.
- test-dna-replay: when DNA is added.
- policy-as-code: deny on missing Safe Cube faces.

## License
Session prototype; for testing under your control.
