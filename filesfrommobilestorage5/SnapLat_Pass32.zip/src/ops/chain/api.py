from __future__ import annotations
from typing import Optional, Dict, Any
from ops.agents.api import agent_fingerprint

def _snap_fp_by_id(snap_id: Optional[str]) -> Optional[str]:
    if not snap_id:
        return None
    try:
        from agrm.snap.archivist import get_fingerprint_by_id  # type: ignore
        return get_fingerprint_by_id(snap_id)
    except Exception:
        return None

def make_chain(agent: str, snap_id: Optional[str] = None, snap_fp: Optional[str] = None) -> Dict[str, Any]:
    """Return a chain-of-custody dict with agent + optional snap fingerprint."""
    return {
        "agent_fp": agent_fingerprint(agent),
        "snap_fp": snap_fp or _snap_fp_by_id(snap_id)
    }
