from __future__ import annotations
from typing import List
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class RendezvousReport:
    checkpoints: List[str]

def sweep(points_hemi: List[str]) -> RendezvousReport:
    tid = trails.begin_trail({"op":"scout.sweep","module":__name__,"policy_hash":POLICY_HASH})
    try:
        cps = sorted(set(points_hemi or []))
        for cp in cps:
            trails.append_event(tid, {"op":"rendezvous","module":__name__,"payload":{"checkpoint": cp}})
        return RendezvousReport(checkpoints=cps)
    finally:
        trails.finalize(tid, {"op":"scout.done","module":__name__})
