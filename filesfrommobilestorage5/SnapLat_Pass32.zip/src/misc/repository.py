
import json, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Any, Optional

@dataclass
class SnapshotMeta:
    snap_id: str
    family: str
    type: str
    version: str
    created_ts: float
    tags: Dict[str, Any]

class Repository:
    def __init__(self, root: str):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, snap_id: str, obj: Dict[str, Any]):
        p = self.root / f"{snap_id}.json"
        p.write_text(json.dumps(obj, indent=2), encoding="utf-8")
        return str(p)

    def load(self, snap_id: str) -> Dict[str, Any]:
        p = self.root / f"{snap_id}.json"
        return json.loads(p.read_text(encoding="utf-8"))

    def list(self):
        return sorted([p.stem for p in self.root.glob("*.json")])

class Archivist:
    def __init__(self, repo: Repository):
        self.repo = repo

    def snapshot(self, family: str, type_: str, version: str, content: Dict[str, Any], tags: Dict[str, Any]) -> SnapshotMeta:
        snap_id = f"{family}-{type_}-{version}-{int(time.time())}"
        meta = SnapshotMeta(snap_id=snap_id, family=family, type=type_, version=version, created_ts=time.time(), tags=tags)
        payload = {"meta": asdict(meta), "content": content}
        self.repo.save(snap_id, payload)
        return meta

class Projector:
    """Ephemeral, read-only projector that emits content for consumption, no persistence."""
    def __init__(self):
        self.last_emit = None

    def emit(self, content: Dict[str, Any], audience: str = "internal") -> Dict[str, Any]:
        self.last_emit = {"audience": audience, "content": content, "ts": time.time()}
        return self.last_emit


# Shim: Archivist.post(key, payload)
def _archivist_post(self, key, payload):
    # minimal journal-like sink; no-op if real journal exists
    return {"ok": True, "key": key, "payload": payload}
try:
    Archivist.post = _archivist_post
except Exception:
    pass


# Optional meta index bridge (DuckDB)
class MetaIndexBridge:
    def __init__(self, db_path: str):
        try:
            from .index_duckdb import DuckIndex
            self.idx = DuckIndex(db_path)
        except Exception as e:
            self.idx = None

    def upsert(self, meta):
        if self.idx: self.idx.upsert(meta)

    def bulk_upsert(self, metas):
        if self.idx: self.idx.bulk_upsert(metas)

    def query(self, **kw):
        if self.idx: return self.idx.query(**kw)
        return []
