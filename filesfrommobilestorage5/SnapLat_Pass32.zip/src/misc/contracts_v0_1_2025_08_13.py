
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
@dataclass
class Capability_v0_1_2025_08_13:
    name: str
    inputs: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)
    description: str = ""
@dataclass
class Permission_v0_1_2025_08_13:
    scope: str
    reason: str = ""
@dataclass
class AgentSpec_v0_1_2025_08_13:
    agent_id: str
    version: str
    capabilities: List[Capability_v0_1_2025_08_13]
    permissions: List[Permission_v0_1_2025_08_13] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    snap_template: Dict[str, Any] = field(default_factory=dict)
@dataclass
class Task_v0_1_2025_08_13:
    intent: str
    requires: List[str]
    universes: List[str]
    inputs: Dict[str, Any]
    constraints: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    allow_agents: Optional[List[str]] = None
