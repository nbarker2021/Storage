
def thresholds_for(geom: str):
    # Tuned from earlier runs
    if geom == "ring":
        return dict(score=0.28, cross_room=0.20, cross_floor=0.30)
    if geom == "line":
        return dict(score=0.30, cross_room=0.22, cross_floor=0.33)
    # default/bimodal
    return dict(score=0.35, cross_room=0.25, cross_floor=0.35)
