
from dataclasses import dataclass, field
from typing import Dict

@dataclass
class DomainPolicy:
    name: str
    min_size: int = 6
    min_coherence: float = 0.10
    max_redundancy: float = 0.99
    min_domain: float = 0.0
    max_flip_rate: float = 0.05
    expand_step: int = 2     # how many shells to add when expanding
    max_shell_k: int = 8     # absolute cap

@dataclass
class PolicyRegistry:
    policies: Dict[str, DomainPolicy] = field(default_factory=dict)

    def add(self, p: DomainPolicy):
        self.policies[p.name] = p

    def get(self, name: str) -> DomainPolicy:
        return self.policies.get(name, DomainPolicy(name="default"))
