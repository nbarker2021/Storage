
from dataclasses import dataclass
from typing import Dict, List, Callable
import numpy as np
from .contradiction import ContradictionSweeper, Claim

@dataclass
class ProbeResult:
    name: str
    value: float

class Probes:
    @staticmethod
    def recency(item_ids: List[str], now_ts: float, get_ts: Callable[[str], float]) -> ProbeResult:
        if not item_ids:
            return ProbeResult("recency", 0.0)
        vals = []
        for gid in item_ids:
            ts = get_ts(gid)
            if ts <= 0:
                vals.append(0.5); continue
            days = max(0.0, (now_ts - ts) / 86400.0)
            score = max(0.0, 1.0 - min(days/30.0, 1.0))
            vals.append(score)
        return ProbeResult("recency", float(np.mean(vals)))

    @staticmethod
    def novelty(center_vec: np.ndarray, X: np.ndarray) -> ProbeResult:
        if X.size == 0:
            return ProbeResult("novelty", 0.0)
        c = center_vec / (np.linalg.norm(center_vec)+1e-9)
        Xn = X / (np.linalg.norm(X,axis=1,keepdims=True)+1e-9)
        cos = (Xn @ c).astype(float)
        val = float(np.mean(1.0 - cos))
        return ProbeResult("novelty", val)

    @staticmethod
    def contradiction_risk(claims: List[Claim]) -> ProbeResult:
        sweeper = ContradictionSweeper()
        rep = sweeper.sweep(claims)
        risk = 1.0 if rep.conflicts else 0.0
        return ProbeResult("contradiction_risk", float(risk))
