
import json
from pathlib import Path
from e8snap.snap_writer import write_manifest
from e8snap.validators import validate_snap

def test_write_manifest_roundtrip(tmp_path: Path) -> None:
    ex = json.loads(Path("/mnt/data/examples/snap_manifest_example.json").read_text())
    p = tmp_path / "m.json"
    write_manifest(ex, p)
    data = json.loads(p.read_text())
    assert data["schema_version"] == "2.0"
    validate_snap(data)  # no exception
