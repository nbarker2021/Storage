"""
E8-aware SNAP v2 utilities.
"""
