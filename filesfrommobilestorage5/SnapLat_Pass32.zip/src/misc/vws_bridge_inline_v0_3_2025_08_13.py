
from .vector_sketch_v0_1_2025_08_13 import VS
def seed_vws_from_inline_v0_3_2025_08_13(inline_hasher, points, building=None, top_edges=128, k_each=5):
    vws = VS()
    # Edges
    for (a,b),w in inline_hasher.edges(topk=top_edges, building=building):
        if a<b: vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+int(w)
        else: vws.edge_freq[(b,a)] = vws.edge_freq.get((b,a),0)+int(w)
    # Local neighborhood
    import numpy as np
    points=np.asarray(points,dtype=float)
    for i in range(points.shape[0]):
        q = points[i]
        neigh = inline_hasher.k_nn(q, k=k_each)
        for j in neigh:
            a,b = (i,j) if i<j else (j,i)
            vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+1
    return vws
