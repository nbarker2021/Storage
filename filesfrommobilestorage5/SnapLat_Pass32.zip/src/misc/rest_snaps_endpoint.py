
# rest_snaps_endpoint.py
# Drop-in FastAPI endpoint enforcing SNAP v2/E8-AS
from fastapi import APIRouter, HTTPException
from pathlib import Path
from .snap_service_writer import new_manifest, persist_manifest  # adjust import path to your service pkg
from e8snap.validators import validate_snap

router = APIRouter()

def path_for(manifest: dict) -> Path:
    # simple pathing; replace with your storage layout
    kind = manifest["kind"].lower()
    snap_id = manifest["snap_id"]
    return Path("snaps") / kind / f"{snap_id}.json"

@router.post("/snaps")
def create_snap(body: dict):
    if "e8" not in body or "axes" not in body:
        raise HTTPException(400, "Missing required fields: e8, axes (E8-AS).")
    try:
        manifest = new_manifest(**body)
        validate_snap(manifest)
    except Exception as e:
        raise HTTPException(400, f"Manifest validation failed: {e}")
    out = path_for(manifest)
    out.parent.mkdir(parents=True, exist_ok=True)
    persist_manifest(manifest, out)
    return {"ok": True, "snap_id": manifest["snap_id"], "path": str(out)}
