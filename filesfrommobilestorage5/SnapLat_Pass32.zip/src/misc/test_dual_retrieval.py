
import numpy as np
from retrieval.dual_compare import compare_retrieval

def test_compare_retrieval_runs():
    rng = np.random.default_rng(0)
    q = rng.standard_normal(8)
    docs = rng.standard_normal((100,8))
    rep = compare_retrieval(q, docs, topk=10)
    assert "overlap_at_k" in rep and 0.0 <= rep["overlap_at_k"] <= 1.0
