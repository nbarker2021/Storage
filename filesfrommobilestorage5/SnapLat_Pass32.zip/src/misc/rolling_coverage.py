
from __future__ import annotations
from typing import Dict, List, Tuple
from itertools import permutations

def _rk_hash(s: str, base: int = 257, mod: int = 2_147_483_647) -> int:
    h = 0
    for ch in s:
        h = (h * base + ord(ch)) % mod
    return h

def exactly_once_rk(seq: str, alphabet: List[str]) -> Tuple[bool, Dict[str,int]]:
    n = len(alphabet)
    if n == 0:
        return True, {}
    # Precompute hashes for all n-length windows
    base = 257; mod = 2_147_483_647
    L = len(seq)
    if L < n:
        return False, {}
    pow_n = pow(base, n-1, mod)
    window_hash = _rk_hash(seq[:n], base, mod)
    hashes: Dict[int, int] = {window_hash: 1}
    for i in range(1, L - n + 1):
        left = ord(seq[i-1]); right = ord(seq[i+n-1])
        window_hash = (window_hash - (left * pow_n) % mod + mod) % mod
        window_hash = (window_hash * base + right) % mod
        hashes[window_hash] = hashes.get(window_hash, 0) + 1

    # Now compute target permutation hashes and count
    counts: Dict[str,int] = {}
    from itertools import permutations
    for p in permutations(alphabet, n):
        s = ''.join(p)
        h = _rk_hash(s, base, mod)
        counts[s] = hashes.get(h, 0)  # note: hash collisions possible; full check recommended post-filter
    ok = all(v == 1 for v in counts.values())
    return ok, counts
