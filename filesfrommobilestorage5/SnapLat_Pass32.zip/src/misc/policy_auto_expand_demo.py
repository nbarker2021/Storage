
import numpy as np
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.shelling import ShellBuilder
from lattice_ai.core.shell_lifecycle import ShellManager
from lattice_ai.core.shell_qa import ShellQASuite
from lattice_ai.core.policy_registry import PolicyRegistry, DomainPolicy
from lattice_ai.core.rules_factory import rules_from_policy

def main():
    cube = SafeCube(dim=8, seed=15)
    ids = [f"g::{i}" for i in range(160)]
    P = np.stack([cube.glyph_vector(i) for i in ids], axis=0)
    sb = ShellBuilder(points=P, ids=ids)
    center = ids[0]

    # initial shells (small depth)
    shells = sb.shells_for(center, max_k=2, nn=10)
    sm = ShellManager(); sm.create(center, shells, hash_fn=lambda s: str(abs(hash(s))))

    # registry + policy
    reg = PolicyRegistry(); pol = DomainPolicy(name="docs", min_size=8, min_coherence=0.12, max_flip_rate=0.10, expand_step=2, max_shell_k=6)
    reg.add(pol)
    suite = ShellQASuite()

    def builder(center_id, max_k, nn):
        return sb.shells_for(center_id, max_k=max_k, nn=nn)

    res = sm.auto_expand_and_promote(
        center_id=center,
        policy=reg.get("docs"),
        builder=builder,
        suite=suite,
        rules_factory=rules_from_policy,
        get_vector=lambda gid: cube.glyph_vector(gid),
        score_fn=lambda _: 1.0,
    )

    print("Auto-expand result:", res)
    print("Promoted members:", len(sm.promoted_members(center)))

if __name__ == "__main__":
    main()
