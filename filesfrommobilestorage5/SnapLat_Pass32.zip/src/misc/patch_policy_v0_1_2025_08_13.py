
"""
Patch Policy with optional SFBB scoring v0_1_2025_08_13
Weights candidate patch edges using an injected EdgeScoreProvider.
"""
from typing import List, Tuple, Dict, Any
Edge = Tuple[int,int]

class PatchPolicy_v0_1_2025_08_13:
    def __init__(self, scorer=None):
        self.scorer = scorer  # should implement .score_edges(...)

    def choose(self, points, candidates: List[Edge], context: Dict[str,Any]) -> List[Edge]:
        if not candidates:
            return []
        if self.scorer is None:
            return candidates  # no reweighting
        try:
            scores = self.scorer.score_edges(points, candidates, context) or {}
            # sort by descending score, fallback stable
            ranked = sorted(candidates, key=lambda e: scores.get((min(e),max(e)), 0.0), reverse=True)
            return ranked
        except Exception:
            return candidates
