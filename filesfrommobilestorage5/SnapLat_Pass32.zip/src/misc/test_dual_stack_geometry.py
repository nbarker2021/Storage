
from lattice_ai.bridge.dual_stack import load_dual

def test_dual_loads_v14():
    v14, legacy, report = load_dual()
    assert v14 is not None
