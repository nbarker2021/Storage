
from __future__ import annotations
from typing import Any, Dict
from jsonschema import Draft202012Validator, RefResolver
from .schemas import load_e8_schema, load_snap_schema
class _Resolver(RefResolver):  # type: ignore[misc]
    def __init__(self, e8: Dict[str, Any], snap: Dict[str, Any]) -> None:
        super().__init__(base_uri=e8.get("$id", ""), referrer=e8)
        self.store = {e8["$id"]: e8, snap["$id"]: snap}
def validate_e8(e8_obj: Dict[str, Any]) -> None:
    e8 = load_e8_schema(); Draft202012Validator(e8).validate(e8_obj)
def validate_snap(manifest: Dict[str, Any]) -> None:
    e8 = load_e8_schema(); snap = load_snap_schema()
    Draft202012Validator(snap, resolver=_Resolver(e8, snap)).validate(manifest)
