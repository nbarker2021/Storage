
import json, time, numpy as np
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.hash_system import HashSystem

def synth_dataset(n_items=1000, dim=8, n_clusters=10, seed=11):
    rng = np.random.default_rng(seed)
    centers = [rng.standard_normal(dim) for _ in range(n_clusters)]
    centers = [c/ (np.linalg.norm(c)+1e-9) for c in centers]
    X = []
    labels = []
    for i in range(n_items):
        c = centers[i % n_clusters]
        x = c + 0.2*rng.standard_normal(dim)
        x = x / (np.linalg.norm(x)+1e-9)
        X.append(x); labels.append(i % n_clusters)
    return np.stack(X,axis=0), np.array(labels)

def recall_at_k(true_neighbors, ranked, k=10):
    inter = len(set(true_neighbors[:k]) & set(ranked[:k]))
    return inter / max(1, k)

def brute_rank(query_idx, X, labels, k=10):
    q = X[query_idx]
    sims = X @ q
    order = np.argsort(-sims)
    # "true neighbors" = same cluster
    same = [i for i in order if labels[i]==labels[query_idx] and i!=query_idx]
    return same[:k]

def house_rank(query_vec, X, hs: HashSystem, top=200):
    # Retrieve items that share the exact same house key (tier1+tier2), then re-rank by cosine
    qkey = hs.house_key(query_vec)
    # This demo does not index houses -> simulate by hashing all
    keys = hs.hash_batch(X)
    idx = [i for i,k in enumerate(keys) if k==qkey]
    if not idx:
        # fallback: return top-N by cosine
        sims = X @ query_vec
        order = np.argsort(-sims)[:top]
        return order.tolist()
    sims = X[idx] @ query_vec
    order = np.argsort(-sims)
    ranked = [idx[i] for i in order[:top]]
    return ranked

def run_eval(weights_json=None, n_items=3000, n_clusters=12, k=10):
    X, labels = synth_dataset(n_items=n_items, n_clusters=n_clusters)
    # baseline HS with random Tier-2
    hs = HashSystem(dim=X.shape[1], tier2_bits=64, seed=1234)
    if weights_json:
        data = json.load(open(weights_json,"r"))
        hs.import_tier2(data)

    # measure recall@k averaged over queries
    R = 0.0; t0 = time.time()
    for i in range(0, min(300, n_items), 10):
        true_nn = brute_rank(i, X, labels, k=k)
        ranked = house_rank(X[i], X, hs, top=5*k)
        R += recall_at_k(true_nn, ranked, k=k)
    dt = (time.time()-t0)*1000.0
    avg_recall = R / max(1, (min(300,n_items)//10))
    # occupancy proxy: number of unique house keys
    keys = hs.hash_batch(X)
    uniq = len(set(keys))
    return {"recall@{}".format(k): avg_recall, "latency_ms": dt, "unique_houses": uniq}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", type=str, default="")
    args = ap.parse_args()
    res = run_eval(args.weights if args.weights else None)
    print(res)
