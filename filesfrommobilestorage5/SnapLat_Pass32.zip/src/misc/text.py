
import re
def toks3(glyph: str | None):
    if not glyph: return []
    return [t for t in re.split(r"[:\s]+", str(glyph)) if t][:3]
def jaccard(a, b):
    A, B = set(a), set(b)
    if not A and not B: return 0.0
    return len(A & B) / max(1, len(A | B))
