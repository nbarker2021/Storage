
from typing import Dict, Any
from pathlib import Path
import yaml

def load_policy(path: str) -> Dict[str, Any]:
    p = Path(path)
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    return data.get("policies", {})

def apply_policy(um, universe_name: str, policy: Dict[str, Any]):
    u = um.get_universe(universe_name)
    pol = dict(u.spec.policies or {})
    pol.update(policy or {})
    u.spec.policies = pol
    um.save_universe(u)
    return pol
