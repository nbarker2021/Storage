
"""
SNAP Types/Family Registry v0_1_2025_08_13
- Families and Types are hierarchical labels for SNAP payloads.
- Registry persists as JSON for transparency and audit.
"""
import json
from pathlib import Path
from typing import List, Dict

class SnapTaxonomy_v0_1_2025_08_13:
    def __init__(self, path="snapshots/taxonomy/taxonomy.json"):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            self.data = {"families":{}, "types":{}}
            self._persist()

    def _persist(self): self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")

    def ensure_family(self, name:str, meta:Dict=None):
        if name not in self.data["families"]:
            self.data["families"][name] = {"meta": meta or {}}
            self._persist()
        return self.data["families"][name]

    def ensure_type(self, name:str, families:List[str], meta:Dict=None):
        for f in families: self.ensure_family(f)
        if name not in self.data["types"]:
            self.data["types"][name] = {"families": families, "meta": meta or {}}
            self._persist()
        return self.data["types"][name]

    def families_of_type(self, type_name:str)->List[str]:
        t = self.data["types"].get(type_name); 
        return list(t.get("families",[])) if t else []

    def to_dict(self): return self.data
