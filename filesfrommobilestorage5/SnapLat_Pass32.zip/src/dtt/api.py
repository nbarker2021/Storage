from __future__ import annotations
from typing import Any, Dict, List, Tuple
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH
from ops.agents.api import agent_fingerprint as __agent_fp_fn__

@dataclass
class TranscriptEntry:
    op: str
    ok: bool
    meta: Dict[str, Any]

@dataclass
class Transcript:
    steps: List[TranscriptEntry]
    ok: bool
    counts: Dict[str, int]

def _simulate_step(step: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
    """Deterministic dry-run logic: never side-effects, always ok unless explicitly marked."""
    op = str(step.get("op",""))
    if op.startswith("fail."):
        return False, {"reason":"explicit-fail"}
    return True, {"why": step.get("why",""), "to": step.get("to"), "universe_ref": step.get("universe_ref"), "snap_id": step.get("snap_id")}

def run_steps(steps: List[Dict[str, Any]], *, mode: str = "dry") -> Transcript:
    tid = trails.begin_trail({"op":"dtt.run", "chain": {"agent_fp": __agent_fp_fn__("dtt")},"module":__name__,"policy_hash":POLICY_HASH, "payload": {"mode": mode, "n": len(steps)}})
    entries: List[TranscriptEntry] = []
    kounts: Dict[str, int] = {}
    try:
        for idx, step in enumerate(list(steps)):
            op = str(step.get("op",""))
            k = op.split(".")[0] if "." in op else op or "unknown"
            kounts[k] = kounts.get(k, 0) + 1
            trails.append_event(tid, {"op":"dtt.step","module":__name__,"payload":{"i":idx,"op":op}})
            ok, meta = _simulate_step(step)
            entries.append(TranscriptEntry(op=op, ok=ok, meta=meta))
        ok_all = all(e.ok for e in entries)
        trails.append_event(tid, {"op":"dtt.summary","module":__name__,"payload":{"ok":ok_all,"counts":kounts}})
        return Transcript(steps=entries, ok=ok_all, counts=kounts)
    finally:
        trails.finalize(tid, {"op":"dtt.done","module":__name__})
