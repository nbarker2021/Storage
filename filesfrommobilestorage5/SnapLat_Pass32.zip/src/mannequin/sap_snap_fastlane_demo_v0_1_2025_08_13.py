import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from core.sap.sap_v0_1_2025_08_13 import Sentinel, Arbiter, Porter, SAPEvent, SAPVerdict
from core.archivist.archivist_v0_1_2025_08_13 import Repository, Archivist, Projector
from core.snap_ops.snap_ops_center_v0_1_2025_08_13 import SnapOpsCenter
from core.fastlane.fastlane_v0_1_2025_08_13 import FastLane

def run():
    # Governance setup
    sent = Sentinel()
    arb = Arbiter()
    port = Porter(io_allowed=True)

    # Simple rule: block outputs containing forbidden tag
    def forbid_sensitive(ev: SAPEvent):
        if ev.payload.get("forbidden"):
            return SAPVerdict(False, "forbidden_content", actions=["quarantine"])
        return None
    sent.register_rule(forbid_sensitive)

    # Archivist
    repo = Repository("/mnt/data/repository_store_v0_1_2025_08_13")
    arc = Archivist(repo)
    proj = Projector()

    # SNAP ops
    ops = SnapOpsCenter()
    ops.register_family_type("fiction","creative", {"compat":{"preferred_with":["culture"], "avoid_with":["science"]}, "weights":{"coverage":1.0,"freshness":0.4}})

    # Fast-lane
    fl = FastLane(quality_threshold=0.75)

    # Artifact arrives
    artifact = {"families":["fiction","culture"], "types":["creative"], "meta":{"coverage":0.82, "freshness_days":10}}
    cands = ops.propose(artifact)
    assess = [ops.assess(c) for c in cands]

    # Governance event
    ev = SAPEvent(type="output", payload={"forbidden": False})
    ver = sent.evaluate(ev)

    # If allowed, snapshot and project
    meta = arc.snapshot("fiction","creative","v0_1_2025_08_13", content={"artifact": artifact}, tags={"score": assess[0].score})
    emitted = proj.emit({"msg":"ok to show", "snap_id": meta.snap_id})

    # Fast-lane submit
    decision = fl.submit("task-1", {"preview":"...result..."}, quality=0.72)

    return {
        "governance_verdict": ver.__dict__,
        "snap_score": assess[0].__dict__,
        "snapshot_id": meta.snap_id,
        "projected": emitted,
        "fastlane_decision": decision.__dict__,
        "repo_list": repo.list()
    }

if __name__ == "__main__":
    print(run())
