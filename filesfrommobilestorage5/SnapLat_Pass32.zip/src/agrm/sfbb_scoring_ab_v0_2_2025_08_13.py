import sys, os
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

import numpy as np
from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL

def run():
    rng = np.random.default_rng(5)
    pts = rng.random((800,2))

    # A) Baseline (no plugin)
    ctrlA = CTRL(cfg={
      "hash_mode":"auto",
      "inline_dim_thresh": 16, "inline_n_thresh": 100000,
      "auto_thrash_tau": 999.0, "auto_coverage_kappa": 0.0, "auto_bucket_beta": 999.0,
      "promotion_policy":"fast_allowed",
    })
    resA = ctrlA.solve(pts, max_ticks=2)

    # B) With dummy plugin (inverse distance)
    ctrlB = CTRL(cfg={
      "hash_mode":"auto",
      "inline_dim_thresh": 16, "inline_n_thresh": 100000,
      "auto_thrash_tau": 999.0, "auto_coverage_kappa": 0.0, "auto_bucket_beta": 999.0,
      "promotion_policy":"fast_allowed",
      "sfbb_plugin_path": str(__file__).replace("sfbb_scoring_ab_v0_2_2025_08_13.py","../plugins/sfbb_dummy_edge_scorer_v0_1_2025_08_13.py")
    })
    resB = ctrlB.solve(pts, max_ticks=2)

    print("A verdict:", resA.get("verdict"), "steps:", int(resA["stats"].get("steps",0)))
    print("B verdict:", resB.get("verdict"), "steps:", int(resB["stats"].get("steps",0)))
    return resA, resB

if __name__ == "__main__":
    run()
