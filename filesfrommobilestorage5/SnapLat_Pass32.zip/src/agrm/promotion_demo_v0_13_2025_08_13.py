
import sys, json, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from agrm.archivist.repository import Repository
from agrm.universe.manager import UniverseManager, UniverseSpec
from agrm.universe.policies import load_policy, apply_policy
from agrm.universe.materialize import to_graph
from agrm.agrm.promotion import PromotionManager

REPO = '/mnt/data/repository_store_v0_1_2025_08_13'
REG  = '/mnt/data/universe_registry_v0_1_2025_08_13'

def seed_repo():
    repo = Repository(REPO)
    if not repo.list():
        for i in range(15):
            sid = f'demo-science-fact-{int(time.time())}-{i}'
            meta = {"snap_id": sid, "family":"science","type":"fact","created_ts": time.time(), "tags":{"snap_score":0.6 + 0.02*i}}
            repo.save(sid, {"meta":meta, "content":{}})

def run():
    seed_repo()
    um = UniverseManager(REPO, REG)
    # Create universes if missing
    if 'UserUniverse' not in um.list_universes():
        um.create_universe(UniverseSpec(name='UserUniverse', selectors={"family":["culture"],"type":["creative"]}))
    if 'DocumentUniverse' not in um.list_universes():
        um.create_universe(UniverseSpec(name='DocumentUniverse', selectors={"family":["science"],"type":["fact"]}))
    if 'WorkUniverse' not in um.list_universes():
        um.create_universe(UniverseSpec(name='WorkUniverse', selectors={"family":["task","science","fact"]}))

    # Apply policies
    pol_doc = load_policy(str(Path(__file__).resolve().parents[1]/"configs/profiles/document_universe.yaml"))
    pol_work= load_policy(str(Path(__file__).resolve().parents[1]/"configs/profiles/work_universe.yaml"))
    apply_policy(um, "DocumentUniverse", pol_doc)
    apply_policy(um, "WorkUniverse", pol_work)

    # Materialize a task graph from DocumentUniverse
    G, meta = to_graph("DocumentUniverse", repo_root=REPO, registry_root=REG,
                       criteria={"family":["science"],"type":["fact"],"tags":{"snap_score_gt":0.6}},
                       adj_k=6, adj_backend="grid", wave_size=8, elevators_quota=2)

    pm = PromotionManager(REPO, REG, quality_threshold=0.7)
    # Stage a result using coverage-like proxy = min(1.0, N/10)
    quality = min(1.0, G["N"]/10.0 if G["N"] else 0.0)
    res = pm.stage_result(key=f"task:{int(time.time())}", result={"N":G.get("N",0), "edges": len(G.get("edges",[]))},
                          quality=quality, source_universe="DocumentUniverse", target_universe="WorkUniverse")
    # Simulate full-path check outcome
    res2 = pm.promote_after_full(key=f"task:{int(time.time())}", ok=True, source_universe="DocumentUniverse", target_universe="WorkUniverse")

    return {"policy_applied": True, "graph_N": G.get("N",0), "stage": res.__dict__, "promote": res2.__dict__}

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
