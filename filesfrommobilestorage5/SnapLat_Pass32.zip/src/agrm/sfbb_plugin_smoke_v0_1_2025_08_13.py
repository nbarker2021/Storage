
import sys, pathlib, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL

rng = np.random.default_rng(5)
pts = rng.random((120,2))
ctrl = CTRL(cfg={
  "hash_mode":"auto",
  "inline_dim_thresh": 16, "inline_n_thresh": 100000,
  "auto_thrash_tau": 999.0, "auto_coverage_kappa": 0.0, "auto_bucket_beta": 999.0,
  "promotion_policy":"fast_allowed",
  "sfbb_plugin_path": str(pathlib.Path(__file__).resolve().parents[1] / "plugins" / "sfbb_dummy_edge_scorer_v0_1_2025_08_13.py")
})
res = ctrl.solve(pts, max_ticks=2)
print("verdict:", res.get("verdict"), "steps:", int(res["stats"].get("steps",0)))
