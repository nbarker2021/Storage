from __future__ import annotations
from typing import Dict, Any

class BeaconsRegistry:
    def __init__(self, data: Dict[str, Any] | None = None) -> None:
        self._data: Dict[str, Any] = dict(data or {})
    def get(self, name: str) -> Dict[str, Any]:
        return dict(self._data.get(name, {"vec": [], "neg": False}))

# Default process-local registry (tests can replace contents)
_REGISTRY = BeaconsRegistry()

def set_registry_data(data: Dict[str, Any]) -> None:
    global _REGISTRY
    _REGISTRY = BeaconsRegistry(data)

def get_registry() -> BeaconsRegistry:
    return _REGISTRY


import json
from pathlib import Path

def load_registry_from_file(path: str) -> None:
    """Load the default registry from a JSON file.

    Shape: { "name": {"vec": [..], "neg": bool}, ... }

    """

    p = Path(path)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("beacons file must be a JSON object")
        set_registry_data(data)  # replace default registry
    except Exception as e:
        # Fail closed: replace with empty registry to avoid stale state
        set_registry_data({})
        raise
