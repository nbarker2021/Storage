
import argparse, json, time
from pathlib import Path

from ..archivist.repository import Repository, Archivist, MetaIndexBridge
from ..universe.manager import UniverseManager, UniverseSpec
from ..universe.policies import load_policy, apply_policy
from ..snap.ops_center import SnapOpsCenter
from ..universe.materialize import to_graph

def main():
    ap = argparse.ArgumentParser(prog="agrm")
    sub = ap.add_subparsers(dest="cmd")

    # universe apply-policy
    up = sub.add_parser("universe-apply-policy")
    up.add_argument("--universe", required=True)
    up.add_argument("--policy", required=True)

    # snap ops-score
    osub = sub.add_parser("snap-ops-score")
    osub.add_argument("--slice_snap")
    osub.add_argument("--universe", required=True)

    # promote stage
    st = sub.add_parser("promote-stage")
    st.add_argument("--source", required=True)
    st.add_argument("--target", required=True)
    st.add_argument("--quality", type=float, required=True)
    st.add_argument("--result_json", required=True)

    # shared args
    ap.add_argument("--repo_root", default="/mnt/data/repository_store_v0_1_2025_08_13")
    ap.add_argument("--reg_root", default="/mnt/data/universe_registry_v0_1_2025_08_13")
    ap.add_argument("--duckdb", default=None)

    args = ap.parse_args()
    repo = Repository(args.repo_root)
    arch = Archivist(repo)
    um = UniverseManager(args.repo_root, args.reg_root)
    index = MetaIndexBridge(args.duckdb) if args.duckdb else None

    if args.cmd == "universe-apply-policy":
        pol = load_policy(args.policy)
        apply_policy(um, args.universe, pol)
        print(json.dumps({"ok": True, "universe": args.universe, "policy": pol}, indent=2))
        return

    if args.cmd == "snap-ops-score":
        # collect candidate SNAPs from the universe
        u = um.get_universe(args.universe)
        candidates = list(u.snaps)
        ops = SnapOpsCenter(repo, arch)
        rec = ops.assess_slice_against_universe(args.slice_snap, candidates)
        print(json.dumps(rec, indent=2))
        return

    if args.cmd == "promote-stage":
        from ..agrm.promotion import PromotionManager
        pm = PromotionManager(args.repo_root, args.reg_root, quality_threshold=0.7)
        key = f"cli:{int(time.time())}"
        result = json.loads(Path(args.result_json).read_text(encoding="utf-8"))
        out = pm.stage_result(key, result, args.quality, source_universe=args.source, target_universe=args.target)
        print(json.dumps(out.__dict__, indent=2))
        return

    # default: noop
    ap.print_help()

if __name__ == "__main__":
    main()
