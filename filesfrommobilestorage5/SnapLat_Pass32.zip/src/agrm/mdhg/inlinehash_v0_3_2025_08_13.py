
"""
InlineHasher_v0_3_2025_08_13
----------------------------
A lightweight "normal inline" hashing path for small/moderate dimensional tasks.
- Quantizes vectors to integer buckets (grid) after optional random projection to <=8 dims.
- Tracks bucket heat and co-occurrence edges (like MDHG, but cheaper).
- Provides k-NN within same/adjacent buckets.
- Designed to dual-write to MDHG asynchronously or in batches (here we expose a snapshot to feed the MDHG/VWS bridge).
"""
import numpy as np
from collections import defaultdict

class InlineHasher_v0_3_2025_08_13:
    def __init__(self, dim:int, grid:float=32.0, proj_dims:int=8, seed:int=17):
        self.dim = int(dim)
        self.proj_dims = int(min(proj_dims, max(1, dim)))
        self.grid = float(grid)
        self.rng = np.random.default_rng(seed)
        # Fixed random projection (Gaussian) to stabilize buckets across runs
        if self.proj_dims < dim:
            self.P = self.rng.standard_normal((dim, self.proj_dims)).astype(float)
        else:
            self.P = None
        self.bucket = defaultdict(set)    # bucket_id -> ids
        self.vecs = {}                    # id -> original vec
        self.meta = {}                    # id -> {building,floor,room}
        self.heat = defaultdict(float)    # id heat
        self.edge = defaultdict(float)    # (a,b) co-use
        self.bucket_centers = {}
        self._delta_heat = {}
        self._delta_edge = {}          # bucket_id -> centroid (for quick k_nn tie-breaks)

    def _embed(self, v:np.ndarray)->np.ndarray:
        if self.P is None: return v
        return v @ self.P

    def _key(self, v:np.ndarray)->tuple:
        u = self._embed(v)
        return tuple((np.floor(u * self.grid)).astype(int).tolist())

    def _floor_from_angle(self, v2:np.ndarray, num_sectors:int=32)->str:
        # For 2D convenience (TSP demo): fallback to F<sector> else F0
        try:
            ang = np.arctan2(v2[1], v2[0]); idx = int(np.digitize([ang], np.linspace(-np.pi, np.pi, num_sectors+1))[0]) - 1
            return "F{}".format(idx)
        except Exception:
            return "F0"

    def insert(self, id:int, vec, meta:dict):
        v = np.asarray(vec, dtype=float).reshape(-1)
        assert v.shape[0]==self.dim
        self.vecs[id]=v
        b = meta.get("building","default"); f = meta.get("floor"); r = meta.get("room","R0")
        if f is None:
            f = self._floor_from_angle(v[:2] if v.shape[0]>=2 else np.array([1.0,0.0]))
        self.meta[id] = {"building":b,"floor":f,"room":r}
        key = self._key(v)
        self.bucket[key].add(id)
        # Update bucket center
        ids = list(self.bucket[key])
        self.bucket_centers[key] = np.mean(np.stack([self.vecs[i] for i in ids], axis=0), axis=0)

    def bump_heat(self, ids):
        ids = list(ids)
        for i in ids:
            self.heat[i] += 1.0
            self._delta_heat[i] = self._delta_heat.get(i,0.0) + 1.0
        for a in ids:
            for b in ids:
                if a<b:
                    self.edge[(a,b)] += 1.0
                    self._delta_edge[(a,b)] = self._delta_edge.get((a,b),0.0) + 1.0

    def k_nn(self, qvec, k=8):
        q = np.asarray(qvec, dtype=float).reshape(-1)
        key = self._key(q)
        cand_ids = set(self.bucket.get(key, set()))
        # also look at immediate neighbor buckets (Chebyshev radius 1)
        if not cand_ids:
            base = np.array(key)
            for offset in np.ndindex(*([3]*len(base))):
                if all(o==1 for o in offset): continue
                neigh = tuple((base + (np.array(offset)-1)).tolist())
                cand_ids |= self.bucket.get(neigh, set())
        dists=[]
        for i in cand_ids:
            v=self.vecs[i]; d=float(np.linalg.norm(q-v)); dists.append((d,i))
        dists.sort(key=lambda x:x[0])
        return [i for _,i in dists[:k]]

    def edges(self, topk=64, building=None):
        items = list(self.edge.items())
        if building is not None:
            items = [((a,b),w) for (a,b),w in items if self.meta.get(a,{}).get("building")==building and self.meta.get(b,{}).get("building")==building]
        items.sort(key=lambda kv: kv[1], reverse=True)
        return items[:topk]

    def snapshot(self):
        return {
            "meta": self.meta,
            "edge": [(a,b,w) for (a,b),w in self.edge.items()]
        }

    def stats(self):
        # Returns {"buckets": int, "mean_bucket_size": float, "max_bucket_size": int}
        sizes = [len(s) for s in self.bucket.values()]
        if not sizes: return {"buckets": 0, "mean_bucket_size": 0.0, "max_bucket_size": 0}
        return {"buckets": len(sizes), "mean_bucket_size": float(sum(sizes))/len(sizes), "max_bucket_size": max(sizes)}

    def export_dualwrite(self):
        # Produces {"heat": {id: val}, "edges": [(a,b,w), ...]}
        return {
            "heat": dict(self.heat),
            "edges": [(a,b,w) for (a,b), w in self.edge.items()]
        }


    def consume_delta(self):
        dh = self._delta_heat; de = self._delta_edge
        self._delta_heat = {}; self._delta_edge = {}
        edges = [(a,b,w) for (a,b),w in de.items()]
        return {"heat": dict(dh), "edges": edges}
