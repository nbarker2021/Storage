"""
Vector Warm-Start (VWS)
-----------------------
Computes fast geometric priors for cold-start: kNN graph, greedy tour sketches,
edge-frequency priors, density/angle histograms. Feeds MDHG seeds and AGRM gating.

This is intentionally simple (numpy + networkx). Replace with ANN/HNSW later for scale.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple
import numpy as np, math, networkx as nx

@dataclass
class VectorSketch:
    knn_edges: List[Tuple[int,int]]
    edge_freq: Dict[Tuple[int,int], int]
    centers: Dict[str, float]
    angle_hist: List[int]
    density_rank: List[int]
    greedy_best_path: List[int]
    greedy_best_len: float

def _pair_len(p: np.ndarray, q: np.ndarray) -> float:
    return float(np.linalg.norm(p - q))

def compute_knn(points: np.ndarray, k: int = 8) -> List[Tuple[int,int]]:
    n = points.shape[0]
    # O(n^2) distances; fine for small N
    dists = np.sqrt(((points[:,None,:] - points[None,:,:])**2).sum(-1))
    edges = []
    for i in range(n):
        order = np.argsort(dists[i])
        for j in order[1:k+1]:
            a,b = (i,int(j)) if i < j else (int(j),i)
            if a != b:
                edges.append((a,b))
    # dedup
    edges = sorted(set(edges))
    return edges

def greedy_nn_path(points: np.ndarray, start: int) -> Tuple[List[int], float]:
    n = points.shape[0]
    unvis = set(range(n))
    path = [start]
    unvis.remove(start)
    def length(path):
        L=0.0
        for a,b in zip(path, path[1:]):
            L += _pair_len(points[a], points[b])
        L += _pair_len(points[path[-1]], points[path[0]])
        return L
    curr = start
    while unvis:
        nxt = min(unvis, key=lambda j: _pair_len(points[curr], points[j]))
        path.append(nxt)
        unvis.remove(nxt)
        curr = nxt
    return path, length(path)

def farthest_insertion(points: np.ndarray) -> Tuple[List[int], float]:
    n = points.shape[0]
    d = np.sqrt(((points[:,None,:] - points[None,:,:])**2).sum(-1))
    # start with farthest pair
    i,j = np.unravel_index(np.argmax(d), d.shape)
    tour = [i, j]
    def tour_len(t):
        return sum(np.linalg.norm(points[a]-points[b]) for a,b in zip(t, t[1:]+t[:1]))
    remaining = set(range(n)) - set(tour)
    while remaining:
        k = max(remaining, key=lambda r: min(d[r, t] for t in tour))
        # best insertion position
        best_pos, best_delta = 0, float("inf")
        for idx in range(len(tour)):
            a, b = tour[idx], tour[(idx+1)%len(tour)]
            delta = (np.linalg.norm(points[a]-points[k]) +
                     np.linalg.norm(points[k]-points[b]) -
                     np.linalg.norm(points[a]-points[b]))
            if delta < best_delta:
                best_delta, best_pos = delta, idx+1
        tour.insert(best_pos, k)
        remaining.remove(k)
    return tour, tour_len(tour)

def mst_preorder(points: np.ndarray) -> Tuple[List[int], float]:
    n = points.shape[0]
    G = nx.Graph()
    for i in range(n):
        G.add_node(i)
    for i in range(n):
        for j in range(i+1, n):
            w = float(np.linalg.norm(points[i]-points[j]))
            G.add_edge(i, j, weight=w)
    T = nx.minimum_spanning_tree(G, algorithm="kruskal")
    # Preorder DFS to get a tour
    root = 0
    order = list(nx.dfs_preorder_nodes(T, source=root))
    # Shortcut repeated nodes by order then close the tour
    def tour_len(order):
        L=0.0
        for a,b in zip(order, order[1:]):
            L += _pair_len(points[a], points[b])
        L += _pair_len(points[order[-1]], points[order[0]])
        return L
    return order, tour_len(order)

def vector_warm_start(points: np.ndarray, k: int = 8, seeds: int = 8) -> VectorSketch:
    n = points.shape[0]
    # Center stats
    center = points.mean(axis=0)
    radii = np.linalg.norm(points - center, axis=1)
    centers = {"cx": float(center[0]), "cy": float(center[1]), "r_mean": float(radii.mean()), "r_std": float(radii.std())}
    # Angle hist (16 bins)
    angles = np.arctan2(points[:,1]-center[1], points[:,0]-center[0])
    bins = np.linspace(-math.pi, math.pi, 17)
    hist,_ = np.histogram(angles, bins=bins)
    # kNN
    knn = compute_knn(points, k=k)
    # Edge frequency via greedy sketches
    edge_freq = {}
    best_len = float("inf")
    best_path = None
    starts = list(np.linspace(0, n-1, num=min(seeds,n), dtype=int))
    for s in starts:
        p1,l1 = greedy_nn_path(points, s)
        for a,b in zip(p1, p1[1:]+p1[:1]):
            e = (a,b) if a<b else (b,a)
            edge_freq[e] = edge_freq.get(e, 0) + 1
        if l1 < best_len:
            best_len, best_path = l1, p1
    # also farthest-insertion and mst
    pf, lf = farthest_insertion(points)
    for a,b in zip(pf, pf[1:]+pf[:1]):
        e = (a,b) if a<b else (b,a)
        edge_freq[e] = edge_freq.get(e, 0) + 1
    pm, lm = mst_preorder(points)
    for a,b in zip(pm, pm[1:]+pm[:1]):
        e = (a,b) if a<b else (b,a)
        edge_freq[e] = edge_freq.get(e, 0) + 1
    # density rank = inverse of radius rank (closer to center -> denser)
    density_rank = list(np.argsort(radii).tolist())
    return VectorSketch(
        knn_edges=knn,
        edge_freq=edge_freq,
        centers=centers,
        angle_hist=hist.tolist(),
        density_rank=density_rank,
        greedy_best_path=best_path,
        greedy_best_len=float(min(best_len, lf, lm)),
    )
