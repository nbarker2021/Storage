
def test_invariant_toggle_smoke():
    # We can't force an invariant violation deterministically here; just ensure API accepts both modes.
    from agrm.orchestrator.iterate import run_iterations
    class DummyRepo:
        def __init__(self): self.store = {}
        def save(self,k,v): self.store[k]=v
        def load(self,k): return self.store[k]
        def list(self,prefix):
            for k in self.store:
                if str(k).startswith(prefix): yield k
    class U: 
        def __init__(self,n): self.name=n; self.overlays={}; self.spec=type("S",(),{"policies":{}})()
    class UM:
        def __init__(self): self._={}
        def get_universe(self,n):
            if n not in self._: self._[n]=U(n)
            return self._[n]
        def save_universe(self,u): self._[u.name]=u
    import numpy as np
    repo = DummyRepo(); um = UM()
    points = np.random.default_rng(0).normal(size=(50,2))
    metas = [{"family":"science","type":"fact","content":{"text":"t"}} for _ in range(50)]
    cfg = {"use_sweeps_full": True, "arms": 6, "rounds": 2, "mdhg":{"persist": True, "promote_elevators": True, "elevator_score_min":0.2, "room_capacity":16, "max_rooms_per_floor":8, "heat_split_threshold":20, "elevator_cross_room_threshold":0.1, "elevator_cross_floor_threshold":0.2}}
    report = run_iterations(points, metas, repo=repo, um=um, base_cfg=cfg, universe="T", max_iters=2, min_promoted=1, invariant_mode="warn")
    assert len(report.iterations) >= 1
