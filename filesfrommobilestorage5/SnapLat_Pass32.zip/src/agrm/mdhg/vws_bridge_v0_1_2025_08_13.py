from .vector_sketch_v0_1_2025_08_13 import VS
def seed_vws_from_mdhg_v0_1_2025_08_13(mdhg, points, building=None, k_each=5, top_edges=128,
                                       seeding_strategy="exact", grid_size=16, grid_k=4, grid_radius=1):
    vws = VS()
    # seed prior MDHG edges
    for (a,b),w in mdhg.edges(topk=top_edges, building=building):
        if a<b: vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+int(w)
        else: vws.edge_freq[(b,a)] = vws.edge_freq.get((b,a),0)+int(w)
    import numpy as np, math, random
    points=np.asarray(points,dtype=float)
    n=points.shape[0]
    if seeding_strategy=="grid" and points.shape[1]>=2:
        # Build simple uniform grid on first two dims (0..1). If outside [0,1], normalize by min/max.
        mins = points.min(axis=0); maxs = points.max(axis=0); span = np.maximum(maxs - mins, 1e-9)
        P = (points - mins) / span
        gs = max(2, int(grid_size))
        # cell id
        cx = np.clip((P[:,0]*gs).astype(int), 0, gs-1)
        cy = np.clip((P[:,1]*gs).astype(int), 0, gs-1)
        cells = {}
        for i in range(n):
            cells.setdefault((int(cx[i]), int(cy[i])), []).append(i)
        # neighbor offsets within radius
        offs = [(dx,dy) for dx in range(-grid_radius, grid_radius+1) for dy in range(-grid_radius, grid_radius+1)]
        for i in range(n):
            x=int(cx[i]); y=int(cy[i])
            cand=set()
            for dx,dy in offs:
                k=(x+dx, y+dy)
                if 0<=k[0]<gs and 0<=k[1]<gs:
                    ids=cells.get(k,[])
                    if len(ids)>grid_k:
                        # sample a few per cell
                        for j in random.sample(ids, grid_k):
                            if j!=i: cand.add(j)
                    else:
                        for j in ids:
                            if j!=i: cand.add(j)
            if not cand:
                continue
            C = np.array(sorted(cand))
            # compute distances to candidates only
            d = np.linalg.norm(points[C] - points[i], axis=1)
            idx = np.argsort(d)[:k_each]
            for j in C[idx]:
                a,b = (i,int(j)) if i<int(j) else (int(j),i)
                vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+1
        return vws
    else:
        # exact (existing behavior)
        for i in range(points.shape[0]):
            q = points[i]
            neigh = mdhg.k_nn(q, k=k_each, building=building)
            for j in neigh:
                a,b = (i,j) if i<j else (j,i)
                vws.edge_freq[(a,b)] = vws.edge_freq.get((a,b),0)+1
        return vws
