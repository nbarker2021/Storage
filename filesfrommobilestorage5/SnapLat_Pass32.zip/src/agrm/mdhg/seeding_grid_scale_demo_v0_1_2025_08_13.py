
import sys, pathlib, time, json
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL

def run(N, seed=123, ticks=1):
    rng = np.random.default_rng(seed)
    pts = rng.random((N,2))
    t0=time.time()
    ctrl = CTRL(cfg={
        "hash_mode":"mdhg",
        "num_sectors":32, "num_shells":8,
        "vws_seeding":"grid",
        "vws_grid_size": 20,
        "vws_grid_k": 4,
        "vws_grid_radius": 1,
        "vws_k": 2, "vws_edges": 64
    })
    res = ctrl.solve(pts, max_ticks=ticks)
    t1=time.time()
    return {"N":N, "elapsed_s": round(t1-t0,4), "journal_applied": int(res["stats"].get("journal_applied",0)), "steps": int(res["stats"].get("steps",0))}

for N in [1000, 3000]:
    print(run(N))
