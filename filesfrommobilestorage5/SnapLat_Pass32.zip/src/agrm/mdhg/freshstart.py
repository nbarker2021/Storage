
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
from typing import Dict, Any
import time
from agrm.utils.repo_ops import list_prefix, delete_prefix

def fresh_start(repo, um, universe: str, *, wipe: bool = True) -> Dict[str,Any]:
    """Reset per-universe artifacts so a run starts clean.
    - wipe=True: best-effort delete mdhg snapshots, events, and results for the universe.
    - Always increments a session counter SNAP for audit.
    """
    deleted = 0
    if wipe:
        for pref in [
            f"mdhg::{universe}::",
            f"mdhg_event::{universe}::elevator::",
            f"result::elevator::{universe}::",
            f"universe_diff::{universe}::",
        ]:
            deleted += delete_prefix(repo, pref)
    sid = f"freshstart::{universe}::{int(time.time())}"
    repo.save(sid, {"meta":{"snap_id": sid, "family":"freshstart","type":"session","tags":{"universe":universe}},
                    "content":{"deleted": deleted, "wipe": wipe}})
    u = um.get_universe(universe)
    u.overlays = {}
    um.save_universe(u)
    return {"deleted": deleted, "session_id": sid}
