
import math, time
from typing import Dict, Any, List, Tuple
from agrm.config.neg_beacons import NEG_BEACON_PAIRS, DEFAULT_PENALTY
from agrm.snapcore.decorators import instrument
from agrm.snap_tools.stitch import stitch

def _cosine(a: Dict[str,float], b: Dict[str,float]) -> float:
    keys = ["who","what","where","when","why","how"]
    A = [float(a.get(k,0.0)) for k in keys]
    B = [float(b.get(k,0.0)) for k in keys]
    na = math.sqrt(sum(x*x for x in A)) or 1.0
    nb = math.sqrt(sum(y*y for y in B)) or 1.0
    dot = sum(x*y for x,y in zip(A,B))
    return max(0.0, min(1.0, (dot/(na*nb) + 1.0)/2.0))

def _jaccard(a: str|None, b: str|None) -> float:
    sa = set((a or "").split("::")); sb = set((b or "").split("::"))
    if not sa and not sb: return 0.0
    return len(sa & sb) / (len(sa | sb) or 1)

@instrument(family="tpg", type_="build_graph", universe_key="universe")
def build_graph(summary: Dict[str,Any], *, w_mdhg: float=0.5, w_w5h: float=0.3, w_glyph: float=0.2,
                imperf_threshold: float=0.8, max_nodes: int=24, neg_pairs: List[Tuple[str,str]]|None=None,
                neg_penalty: float|None=None, repo=None, um=None, universe: str="Global") -> Dict[str,Any]:
    neg_pairs = set(tuple(p) for p in (neg_pairs if neg_pairs is not None else NEG_BEACON_PAIRS))
    neg_penalty = float(DEFAULT_PENALTY if neg_penalty is None else neg_penalty)
    md = summary.get("mdhg", {})
    rooms = md.get("rooms", [])
    rooms_sorted = sorted(rooms, key=lambda r: -float(r.get("heat",0.0)))[:max_nodes]
    node_ix = {tuple(r["id"]): i for i,r in enumerate(rooms_sorted)}
    nodes = [tuple(r["id"]) for r in rooms_sorted]
    elevs = md.get("elevators", [])
    max_score = 1.0
    struct = {}
    for ev in elevs:
        a,b = tuple(ev.get("a")), tuple(ev.get("b"))
        score = float(ev.get("score", 0.0))
        max_score = max(max_score, score)
        if a in node_ix and b in node_ix:
            struct[(a, b)] = score
            struct[(b, a)] = score
    for k in list(struct.keys()):
        struct[k] = (struct[k] / max_score) if max_score>0 else 0.0

    N = len(nodes)
    costs = [[0.0]*N for _ in range(N)]
    overlaps = [[0.0]*N for _ in range(N)]
    leak_mask = [[False]*N for _ in range(N)]
    metas = {tuple(r["id"]): r for r in rooms_sorted}
    for i, a in enumerate(nodes):
        ra = metas[a]
        for j, b in enumerate(nodes):
            if i==j:
                costs[i][j] = float("inf"); overlaps[i][j]=0.0; continue
            rb = metas[b]
            s = struct.get((a,b), 0.1)
            w = _cosine(ra.get("tags",{}).get("w5h",{}), rb.get("tags",{}).get("w5h",{}))
            g = _jaccard(ra.get("tags",{}).get("glyph"), rb.get("tags",{}).get("glyph"))
            overlap = max(0.0, min(1.0, w_mdhg*s + w_w5h*w + w_glyph*g))
            penalty = 0.0
            if a[1] != b[1]: penalty += 0.05
            fa, fb = ra.get("tags",{}).get("family"), rb.get("tags",{}).get("family")
            if fa and fb and fa != fb: penalty += 0.02
            leak = False
            if fa and fb and (fa, fb) in neg_pairs:
                penalty += neg_penalty
                leak = True
            cost = max(0.0, 1.0 - overlap) + penalty
            overlaps[i][j] = overlap
            costs[i][j] = cost
            leak_mask[i][j] = leak
    # Emit a digest metric snap about graph stats
    try:
        from agrm.snapcore.emitter import get_emitter
        em = get_emitter(repo, um)
        em.emit(universe=universe, family="metric", type_="graph_stats",
                content={"nodes": N, "neg_pairs": list(neg_pairs), "imperf_threshold": imperf_threshold},
                tags={"universe": universe, "component":"tpg"})
    except Exception:
        pass
    return {"nodes": nodes, "costs": costs, "overlaps": overlaps, "metas": metas,
            "imperf_threshold": float(imperf_threshold), "leak_mask": leak_mask}
