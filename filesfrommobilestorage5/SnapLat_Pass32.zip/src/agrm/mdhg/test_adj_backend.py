
import numpy as np
from agrm.mdhg.adjacency import build_adjacency

def test_grid_backend():
    X = np.random.RandomState(0).rand(200,2)
    adj = build_adjacency(X, k=6, backend='grid')
    assert adj['N'] == 200 and len(adj['edges']) > 0

def test_faiss_fallback():
    X = np.random.RandomState(0).rand(200,2)
    adj = build_adjacency(X, k=6, backend='faiss')
    assert adj['N'] == 200 and len(adj['edges']) > 0
