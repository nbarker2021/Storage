
"""
SNAP Evaluator v0_1_2025_08_13
- Evaluates a SNAPDNA profile against a task using AGRM controller on a synthetic TSP proxy.
- Returns metrics: length proxy (steps, coverage_rate, thrash_per_step, etc.)
"""
import numpy as np, time
from typing import Dict, Any
from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL

def evaluate_profile(profile: Dict[str, Any], task: Dict[str, Any]) -> Dict[str, Any]:
    rng = np.random.default_rng(task.get("seed", 0))
    n = int(task.get("n_points", 120))
    pts = rng.random((n,2))
    entropy = float(profile.get("entropy_proxy", 0.4))
    # choose hash mode heuristically (could come from profile)
    mode = profile.get("hash_mode", "auto")
    cfg = {
        "hash_mode": mode,
        "num_sectors": task.get("num_sectors", 32),
        "num_shells": task.get("num_shells", 8),
        "inline_dim_thresh": profile.get("inline_dim_thresh", 16),
        "inline_n_thresh": profile.get("inline_n_thresh", 5000),
        "auto_thrash_tau": profile.get("auto_thrash_tau", 0.8),
        "auto_coverage_kappa": profile.get("auto_coverage_kappa", 0.15),
        "auto_bucket_beta": profile.get("auto_bucket_beta", 8.0),
        "promotion_policy": profile.get("promotion_policy", "sample_full"),
        "promote_thrash_tau": profile.get("promote_thrash_tau", 1.0),
        "promote_coverage_kappa": profile.get("promote_coverage_kappa", 0.10),
    }
    t0=time.time()
    ctrl = CTRL(cfg=cfg)
    res = ctrl.solve(pts, max_ticks=int(task.get("ticks", 4)))
    t1=time.time()
    brief = {
        "elapsed_s": t1-t0,
        "verdict": res.get("verdict","pass"),
        "coverage_rate": float(res["info"].get("fast_metrics",{}).get("coverage_rate", 0.0)) if "info" in res else float(res["stats"].get("coverage_gain",0.0)),
        "thrash_per_step": float(res["info"].get("fast_metrics",{}).get("thrash_per_step", 0.0)) if "info" in res else float(res["stats"].get("thrash",0.0)) / max(1, float(res["stats"].get("steps",1))),
        "steps": int(res["stats"].get("steps",0))
    }
    return brief
