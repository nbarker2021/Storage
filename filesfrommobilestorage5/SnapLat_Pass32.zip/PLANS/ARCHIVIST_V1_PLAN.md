# Archivist v1 — Expand/Contract Implementation Plan (M1.7)
## Goal
Implement deterministic Snap expansion/contracting around `SNAP_V1_SCHEMA.json` with Trails coverage and payload hashing.

## API (per spec)
- `expand(snap_id: str, *, with_bridges: bool = True) -> ExpandedContext`
- `contract(expanded: ExpandedContext) -> SnapV1` (computes `payload_hash` and emits Trail events)

## Determinism
- `(Snap + POLICY_HASH + run_manifest)` ⇒ same ExpandedContext (within tolerance).

## Tests
- Round-trip toy ExpandedContext ⇒ Snap ⇒ expand ⇒ equals original (idempotence).
- Invalid schema ⇒ Safe-Cube deny + Trail error.

