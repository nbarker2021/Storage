    # E‑DBSU Runtime — Plan (M1.8)
    ## Goal
    Implement NEW → TRIAGED → PROMOTED/DEMOTED → ARCHIVED lifecycle with Trails and Safe‑Cube integration.

    ## API (proposed)

    - `submit(candidate: Dict) -> id` (state: NEW)
- `triage(id, evidence: Dict) -> state`
- `promote(id) -> state` (links to lattices; emits glyph)
- `demote(id) -> state` (retained with reason)
- `archive(id) -> state`

    ## Signals

    - Independent corroboration counts; neg-beacon conflicts; unsafe sentinel denials.

    ## Tests

    - Happy path NEW→TRIAGED→PROMOTED; denial on unsafe candidate; retention on DEMOTED.

