# M1 Scoring Calibration Plan
## Objective
Establish a reproducible calibration loop for `promotion_breakdown` that remains valid as contracts evolve.

## Steps
1. **Fixtures:** Curate toy records spanning axes: `w5h` ∈ [0..1], `hot` ∈ {0,1}, `neg_penalty` ∈ [0..0.3], `bridge_conf` ∈ [0..0.3].
2. **Properties:** Enforce bounds [0,1], component presence, and monotonicity (↑w5h/bridge/hot ⇒ ↑score; ↑neg ⇒ ↓score).
3. **Sweeps:** Run grid sweeps and record outputs for human review (CSV logs).
4. **Weights:** Iterate `PLANS/mdhg_scoring.yaml` in small steps; keep tests focused on properties, not magic numbers.
5. **Trails:** Emit Trail events for each scoring call (already wired in wrapper).

## Exit Criteria (M1)
- Scoring satisfies properties across sweeps.
- No violations on event validation tests.
- Configurable thresholds (from YAML) proposed for M2 where real weights will replace placeholders.
