# Contract Evolution Policy (Doc‑ & Test‑Driven)
Status: EXPERIMENTAL — contracts are mutable until we sign off on a "perfect" build.

## Sources of Truth
1. **Documents** (master brief, specs) — canonical intent.
2. **Tests** (fixtures, metamorphic checks) — executable truth for behavior.

## Change Process
- Propose change in `PLANS/CONTRACT_DELTA.md` with rationale (doc refs + failing tests).
- Bump `contracts/version.json` with `minor` for backward‑compatible, `major` for breaking.
- Add/adjust stubs in `src/**/.pyi` and update runtime shims only if needed for immediate progress.
- Record Trails on the change (PR links, reasons).

## Safety Rails
- Never broaden a contract without tests that constrain new behavior.
- Provide deprecation window for removals (one milestone), unless blocking safety.
- Keep `.pyi` narrow; prefer adapters at the edges.
