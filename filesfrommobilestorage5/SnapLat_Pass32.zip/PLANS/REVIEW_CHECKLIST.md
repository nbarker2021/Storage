# Code Review Checklist
- [ ] Interfaces match plan; shims replaced or deferred with issue
- [ ] No hardcoded thresholds; config injected
- [ ] Structured logs with Trail IDs at key transitions
- [ ] No risky IO at import time; subprocess/network behind feature flags
- [ ] Docstrings + type hints on public API
- [ ] Deterministic seams for tests; fixtures in place
- [ ] Safety: Safe-Cube sentinel checks + Porter custody boundaries
