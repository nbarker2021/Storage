# Trail Event Bindings (Contract)
Required fields per event type (must be present in emitted event dicts):

- **begin**: trail_id, ts, event, op, module, policy_hash, safe_cube, payload
- **append**: trail_id, ts, event, op, module, payload
- **finalize**: trail_id, ts, event, op, module, payload
- **rendezvous**: trail_id, ts, event, module, arm, checkpoint, quorum, payload

*All events must also meet `TRAILS_LOGGING_SCHEMA.json` constraints.*
