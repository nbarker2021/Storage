from thinktank.api import ThinkTank
from dtt.api import run_steps
from trails import api as trails_api
from trails import validate as trails_validate
from trails.query.api import filter_events, summarize_ops
from ops.agents.api import agent_fingerprint

def test_query_by_agent_and_snap_fp(tmp_path):
    # produce some events with agent chain (thinktank) and with a porter attempt snap_fp
    tt = ThinkTank(panel=["mdhg","archivist"])
    # deny-by-default is fine for event shapes since we won't access results; but we need allowed for begin
    from mannequin.api import load_rules
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))
    res = tt.critique(findings=["ok"], evidence={"corroboration":1.0})
    _ = run_steps(res.steps, mode="dry")
    events = trails_api._drain()
    # Filter by agent fp for thinktank
    afp = agent_fingerprint("thinktank")
    a_events = filter_events(events, agent_fp=afp)
    assert a_events, "no events matched agent_fp thinktank"
    # Summarize ops for matched events
    counts = summarize_ops(a_events)
    assert isinstance(counts, dict)
    for e in events:
        trails_validate.validate_event(e)
