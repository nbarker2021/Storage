from dtt.api import run_steps
from assembly.api import stage
from trails import api as trails_api
from trails import validate as trails_validate

def test_assembly_stages_modules_from_transcript():
    steps = [{"op":"mdhg.to_points"},{"op":"mdhg.to_graph"},{"op":"mdhg.promotion_breakdown"},{"op":"archivist.contract"},{"op":"porter.deliver"}]
    t = run_steps(steps)
    wo = stage(t)
    assert set(["mdhg","archivist","porter"]).issubset(set(wo.modules))
    assert len(wo.ops) == len(steps)
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
