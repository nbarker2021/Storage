import pytest
try:
    from agrm.snap.archivist import expand, contract  # to be implemented
    HAVE_ARCHIVIST = True
except Exception:
    HAVE_ARCHIVIST = False

@pytest.mark.skipif(not HAVE_ARCHIVIST, reason="Archivist v1 not implemented yet — planned next")
def test_roundtrip_idempotence():
    assert True
