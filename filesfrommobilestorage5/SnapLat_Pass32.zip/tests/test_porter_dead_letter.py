from mannequin.api import Porter
from trails import api as trails_api
from trails import validate as trails_validate

def test_porter_dead_letter_on_failure():
    p = Porter()
    def bad_sink(payload): raise RuntimeError("boom")
    p.register_sink("bad", bad_sink)
    p.deliver({"y":2}, to="bad", retries=0)
    dlq = p.dead_letters("bad")
    assert dlq and dlq[0]["payload"] == {"y":2}
    evts = trails_api._drain()
    # Ensure an error append was logged
    assert any(e.get("event")=="append" and e.get("payload",{}).get("op")=="porter.error" for e in evts)
    for e in evts:
        trails_validate.validate_event(e)
