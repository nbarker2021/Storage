from trails import api as trails_api
from trails import validate as trails_validate

def test_rendezvous_event_schema():
    tid = trails_api.begin_trail({"op":"rv","module":"test"})
    trails_api.rendezvous(tid, arm="main", checkpoint="hemisphere:NW@tick=7", quorum=2, payload={"findings":["ok"]})
    trails_api.finalize(tid, {"op":"rv","status":"ok"})
    events = trails_api._drain()
    # Find the rendezvous event
    rv = [e for e in events if e.get("event") == "rendezvous"]
    assert len(rv) == 1
    trails_validate.validate_event(rv[0])
