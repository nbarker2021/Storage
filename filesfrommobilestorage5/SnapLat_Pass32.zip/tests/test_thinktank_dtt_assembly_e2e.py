from thinktank.api import ThinkTank
from dtt.api import run_steps
from assembly.api import stage
from mannequin.api import load_rules
from trails import api as trails_api
from trails import validate as trails_validate

def _allow_rules(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_e2e_thinktank_to_dtt_to_assembly(tmp_path):
    _allow_rules(tmp_path)
    tt = ThinkTank(panel=["mdhg","archivist","porter"])  # default is ok too
    res = tt.critique(findings=["scout rendezvous ok"], evidence={"corroboration":1.0, "neg_conflict":0.0})
    steps = res.steps
    t = run_steps(steps, mode="dry")
    wo = stage(t)
    assert t.ok and len(t.steps) == len(steps)
    assert len(wo.modules) >= 2
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
