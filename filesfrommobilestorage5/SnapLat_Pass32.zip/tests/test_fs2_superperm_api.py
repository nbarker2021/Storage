def test_fs2_superperm_api_skeleton():
    assert True
