from trails import api as trails_api

def test_trails_smoke():
    tid = trails_api.begin_trail({"op":"seed","module":"x","policy_hash":"","safe_cube":{"allowed":True,"reason":"seed"}})
    trails_api.append_event(tid, {"op":"work","delta":"d"})
    trails_api.finalize(tid, {"op":"done","status":"ok"})
    events = trails_api._drain()
    assert len(events) == 3
    kinds = [e["event"] for e in events]
    assert kinds == ["begin","append","finalize"]
    assert all("trail_id" in e and "ts" in e and "op" in e and "module" in e for e in events)
