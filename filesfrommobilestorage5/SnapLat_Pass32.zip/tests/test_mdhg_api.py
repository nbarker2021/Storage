def test_mdhg_api_skeleton():
    assert True
