def test_policy_mannequin_api_skeleton():
    assert True
