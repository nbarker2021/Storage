import os, tempfile, shutil
from pathlib import Path
from agrm.mdhg import wrapper as mdhg
from agrm.snap.beacons import set_registry_data

def _write_cfg(path: Path, w_w5h: float):
    path.write_text(f"weights:\n  w_w5h: {w_w5h}\n  w_hot: 0.25\n  w_neg: 0.20\n  w_bridge: 0.15\n", encoding='utf-8')

def test_config_changes_affect_score_monotonically(tmp_path: Path):
    rec = {"hot": False, "bridge_conf": 0.0, "w5h": 0.5, "neg_penalty": 0.0}
    cfg1 = tmp_path/"cfg1.yaml"; cfg2 = tmp_path/"cfg2.yaml"
    _write_cfg(cfg1, 0.10); _write_cfg(cfg2, 0.80)
    os.environ['SNAPLAT_USE_SCORING_CONFIG'] = '1'
    os.environ['SNAPLAT_SCORING_CONFIG'] = str(cfg1)
    s1 = mdhg.promotion_breakdown(rec)["score"]
    os.environ['SNAPLAT_SCORING_CONFIG'] = str(cfg2)
    s2 = mdhg.promotion_breakdown(rec)["score"]
    assert s2 >= s1

def test_named_beacons_flow():
    set_registry_data({"topicA": {"vec": (1.0, 0.0)}, "topicB": {"vec": (0.0, 1.0), "neg": True}})
    base = {"hot": False, "bridge_conf": 0.0, "room_vec": (1.0, 0.0)}
    s_named = mdhg.promotion_breakdown({**base, "beacon_name": "topicA"})["score"]
    s_vec   = mdhg.promotion_breakdown({**base, "beacon_vec": (1.0, 0.0)})["score"]
    assert abs(s_named - s_vec) < 1e-9
    s_neg = mdhg.promotion_breakdown({**base, "neg_beacon_name": "topicB"})["score"]
    s_neutral = mdhg.promotion_breakdown({**base})["score"]
    assert s_neg <= s_neutral
