from superperm.interop import summarize
from trails import api as trails_api
from trails import validate as trails_validate

def test_superperm_summarize_smoke():
    s = summarize({"n": 5, "alphabet_size": 5, "lower_bound": 153, "upper_bound": 154, "strategy": "lex"})
    assert s.n == 5 and s.alphabet_size == 5 and s.lower_bound == 153 and s.upper_bound == 154
    events = trails_api._drain()
    assert any(e.get("event") in ("begin","append","finalize") for e in events)
    for e in events:
        trails_validate.validate_event(e)
