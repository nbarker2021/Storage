from agrm.space.api import Universe, Lattice, get_default_universe, set_default_universe, tag_points
from agrm.mdhg.ops import to_points
from agrm.snap.archivist import contract, expand
from trails import api as trails_api
from trails import validate as trails_validate

def test_weyl_index_is_deterministic():
    lat = Lattice(name="E8", dim=8)
    p = (0.2, 0.8)
    assert lat.weyl_index(p) == lat.weyl_index(p)

def test_tag_points_matches_quadrants_and_mdhg_integration():
    u = Universe(name="U", hemispheres=["NW","NE","SW","SE"])
    pts = to_points(seed=1)
    tags = tag_points(u, pts.coords)
    assert len(tags) == len(pts.coords)
    # MDHG should attach hemi as well
    assert pts.hemi is None or len(pts.hemi) == len(pts.coords)

def test_archivist_passes_universe_and_weyl_fields():
    snap = contract({"glyph":"g","context":{},"n_level":1.0,"shell":0,"universe_ref":"U","weyl_index":3})
    reh = expand(snap["snap_id"])
    assert reh.get("universe_ref") == "U" and reh.get("weyl_index") == 3
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
