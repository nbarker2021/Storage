from agrm.snap.beacons import load_registry_from_file, get_registry, set_registry_data
import json

def test_registry_loads_from_file(tmp_path):
    p = tmp_path / "beacons.json"
    p.write_text(json.dumps({"topicA":{"vec":[1.0,0.0],"neg":False}}), encoding="utf-8")
    load_registry_from_file(str(p))
    reg = get_registry()
    assert reg.get("topicA").get("vec") == [1.0, 0.0]
    # hot-swap: ensure overwrite works
    set_registry_data({"topicB":{"vec":[0.0,1.0],"neg":True}})
    assert "topicA" not in get_registry().get("topicA")  # default get returns empty for missing
    assert reg.get("topicB").get("vec") == [0.0, 1.0]
