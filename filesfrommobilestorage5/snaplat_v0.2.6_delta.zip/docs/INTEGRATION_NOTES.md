
# v0.2.6 delta — integration notes

- **Add to `src/snaplat/tsp/`**: `solver.py`, `postman.py`
- **Add to `src/snaplat/superperm/`**: `nav_tsp.py` (2D-only; wire projector if available)
- **Add to `src/snaplat/agrm/`**: `salesman.py`

- **MDHG heat decay**: add to `src/snaplat/mdhg/core.py`:
```python
def decay(self, factor: float = 0.9, cap: int = 1000):
    for k in list(self.access.keys()):
        v = int(self.access[k] * factor)
        if v <= 0: self.access.pop(k, None)
        else: self.access[k] = min(v, cap)
```
- **Makefile**: append
```
accept:
	$(PYTHON) tools/accept_report.py
```

- **Acceptance reporter**: drop `tools/accept_report.py` from this delta into your repo; the tool scans tests for `@pytest.mark.accept(...)` and writes `artifacts/acceptance_report.json`.
