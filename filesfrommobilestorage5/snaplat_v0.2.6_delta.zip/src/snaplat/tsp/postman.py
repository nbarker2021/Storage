
from typing import Dict, List

Graph = Dict[int, Dict[int, float]]  # adjacency w/ weights

def eulerize_approx(G: Graph) -> Graph:
    H = {u: dict(nei) for u, nei in G.items()}
    odds = [u for u in H if (len(H[u]) % 2)==1]
    if not odds: return H
    nodes = list(H.keys())
    idx = {u:i for i,u in enumerate(nodes)}
    n = len(nodes)
    INF = 1e18
    D = [[INF]*n for _ in range(n)]
    for u in nodes:
        i = idx[u]; D[i][i] = 0.0
        for v,w in H[u].items():
            j = idx[v]; D[i][j] = min(D[i][j], w)
    for k in range(n):
        for i in range(n):
            Dik = D[i][k]
            if Dik==INF: continue
            rowk = D[k]
            for j in range(n):
                alt = Dik + rowk[j]
                if alt < D[i][j]: D[i][j] = alt
    used = set(); pairs = []
    for i,u in enumerate(odds):
        if u in used: continue
        best = None; bestv = None
        for v in odds[i+1:]:
            if v in used: continue
            d = D[idx[u]][idx[v]]
            if bestv is None or d < bestv: bestv, best = d, v
        if best is not None: used.add(u); used.add(best); pairs.append((u, best))
    for u,v in pairs:
        w = D[idx[u]][idx[v]]
        H[u][v] = H[u].get(v, 0.0) + w
        H[v][u] = H[v].get(u, 0.0) + w
    return H

def euler_tour(H: Graph, start: int) -> List[int]:
    G = {u: list(vs.keys()) for u,vs in H.items()}
    stack = [start]; path = []
    while stack:
        v = stack[-1]
        if G[v]:
            u = G[v].pop()
            G[u].remove(v)
            stack.append(u)
        else:
            path.append(stack.pop())
    path.reverse()
    return path
