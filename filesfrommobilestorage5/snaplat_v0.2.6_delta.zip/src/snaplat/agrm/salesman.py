
from typing import Dict, Any, List, Tuple, Optional
from ..tsp.solver import weighted_metric, tour_length, close_cycle

class SalesmanStateBus:
    def __init__(self, pts2d: List[Tuple[float,float]]):
        self.pts2d = pts2d
        self.current_cycle: List[int] = list(range(len(pts2d))) + [0] if pts2d else []
        self.salesman_proposals: List[Dict[str, Any]] = []

    def add_salesman_proposal(self, p: Dict[str, Any]): self.salesman_proposals.append(p)

    def apply_best(self, dist=None) -> Optional[Dict[str, Any]]:
        if not self.salesman_proposals: return None
        prop = self.salesman_proposals.pop(0)
        before = tour_length(self.current_cycle, dist) if self.current_cycle else 0.0
        tour = prop.get("tour") or prop.get("new_subpath_nodes") or []
        if tour and (tour[0] != tour[-1]): tour = close_cycle(tour)
        self.current_cycle = tour
        after = tour_length(self.current_cycle, dist)
        return {"before": before, "after": after, "delta": after - before}
