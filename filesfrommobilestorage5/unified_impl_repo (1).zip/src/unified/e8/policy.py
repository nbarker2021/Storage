
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from .scoring import coherence, redundancy, novelty, contradiction_risk

@dataclass
class Policy:
    tau_coh: float = 0.60
    tau_red: float = 0.92
    tau_nov: Tuple[float,float] = (0.02, 0.40)
    flip_rate_max: float = 0.20

@dataclass
class ProbeReport:
    coh: float
    red: float
    nov: float
    contra: float
    size: int
    thresholds: Dict[str, float]
    decision: str

def evaluate(vectors: np.ndarray, claims: List[dict], policy: Policy) -> Tuple[bool, ProbeReport]:
    coh = coherence(vectors)
    red = redundancy(vectors)
    nov = novelty(vectors)
    contra = contradiction_risk(claims)
    ok = (
        coh >= policy.tau_coh and
        red <= policy.tau_red and
        policy.tau_nov[0] <= nov <= policy.tau_nov[1] and
        contra == 0.0
    )
    rep = ProbeReport(
        coh=coh, red=red, nov=nov, contra=contra, size=int(vectors.shape[0]),
        thresholds={'tau_coh': policy.tau_coh, 'tau_red': policy.tau_red, 'tau_nov_min': policy.tau_nov[0], 'tau_nov_max': policy.tau_nov[1]},
        decision='approve' if ok else 'reject'
    )
    return ok, rep
