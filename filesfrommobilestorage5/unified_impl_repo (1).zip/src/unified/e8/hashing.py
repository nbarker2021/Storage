
from __future__ import annotations
import numpy as np
from dataclasses import dataclass

@dataclass
class SemanticHash:
    W: np.ndarray  # shape (B, D), B bits

    @classmethod
    def init(cls, bits: int, dim: int, seed: int = 0):
        rng = np.random.RandomState(seed)
        W = rng.randn(bits, dim).astype(np.float32)
        return cls(W=W)

    def infer_bucket(self, v: np.ndarray) -> str:
        z = self.W @ v  # (B,)
        b = (z >= 0).astype(np.uint8)
        # return as hex string (pack bits)
        acc = 0
        for bit in b:
            acc = (acc << 1) | int(bit)
        width = max(1, len(b)//4)
        return f"{acc:0{width}x}"

    def train(self, X: np.ndarray, labels: np.ndarray, lr: float=1e-3, epochs: int=5):
        # Simple perceptron-like alignment: move W to align with labeled cluster centers
        classes = sorted(set(labels.tolist()))
        centers = {c: X[labels==c].mean(axis=0) for c in classes}
        for _ in range(epochs):
            for c, mu in centers.items():
                # push W rows toward/away from mu randomly for diversity
                self.W += lr * (np.sign(mu)[None, :] - 0.001 * self.W)
        return self
