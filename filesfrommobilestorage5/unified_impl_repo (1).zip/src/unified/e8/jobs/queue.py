
from __future__ import annotations
import time, numpy as np
from typing import Dict, Any
from ..persistence import db
from ..hashing import SemanticHash
from ..shells import build_shells, evaluate_shells
from ..policy import Policy

def sweep_promotion(bits: int = 32, seed: int = 0) -> Dict[str, Any]:
    db.init()
    glyphs_list = db.list_glyphs()
    glyphs = {g['gid']: {'vector': np.asarray(g['vector']), 'claims': g['claims']} for g in glyphs_list}
    if not glyphs: return {'promoted': 0, 'shells': 0}
    dim = len(next(iter(glyphs.values()))['vector'])
    hasher = SemanticHash.init(bits=bits, dim=dim, seed=seed)
    bucket_of = {gid: hasher.infer_bucket(g['vector']) for gid, g in glyphs.items()}
    shells = build_shells(glyphs, bucket_of)
    decisions = evaluate_shells(shells, glyphs, Policy())
    promoted = 0
    for sid, sh in shells.items():
        db.put_shell({'sid': sid, 'center': sh.center, 'promoted': sh.promoted, 'meta': decisions[sid], 'gids': sh.gids})
        if sh.promoted: promoted += 1
    return {'promoted': promoted, 'shells': len(shells), 'decisions': decisions}

def sweep_contradictions() -> Dict[str, Any]:
    # Simple pass since contradiction risk is calculated per shell
    return {'status': 'ok'}

def sweep_reindex() -> Dict[str, Any]:
    # Placeholder for a heavier reindex; v1 no-op
    return {'status': 'ok'}
