
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
import numpy as np
from .policy import Policy, evaluate

@dataclass
class Shell:
    sid: str
    center: np.ndarray
    gids: List[str] = field(default_factory=list)
    promoted: bool = False
    meta: Dict = field(default_factory=dict)

def build_shells(glyphs: Dict[str, dict], bucket_of: Dict[str, str]) -> Dict[str, Shell]:
    # Group glyphs by bucket id into shells; center is mean vector
    shells: Dict[str, Shell] = {}
    for gid, g in glyphs.items():
        b = bucket_of[gid]
        if b not in shells:
            shells[b] = Shell(sid=b, center=np.zeros_like(g['vector']))
        shells[b].gids.append(gid)
    # Compute centers
    for b, sh in shells.items():
        vs = np.stack([glyphs[gid]['vector'] for gid in sh.gids], axis=0)
        sh.center = vs.mean(axis=0)
    return shells

def evaluate_shells(shells: Dict[str, Shell], glyphs: Dict[str, dict], policy: Policy):
    decisions = {}
    for sid, sh in shells.items():
        vs = np.stack([glyphs[gid]['vector'] for gid in sh.gids], axis=0)
        claims = sum([glyphs[gid]['claims'] for gid in sh.gids], [])
        ok, rep = evaluate(vs, claims, policy)
        sh.promoted = bool(ok)
        decisions[sid] = rep.__dict__
    return decisions
