
from __future__ import annotations
import sqlite3, json, os
from typing import Dict, Any, List, Optional

DB_PATH = os.environ.get('UNIFIED_DB', 'unified.db')

def _conn():
    return sqlite3.connect(DB_PATH)

def init():
    with _conn() as cx:
        cx.execute("CREATE TABLE IF NOT EXISTS glyphs (gid TEXT PRIMARY KEY, vec TEXT, ts REAL, mdhg_key TEXT)")
        cx.execute("CREATE TABLE IF NOT EXISTS claims (gid TEXT, text TEXT, ts REAL, source TEXT, contradicted INT)")
        cx.execute("CREATE TABLE IF NOT EXISTS shells (sid TEXT PRIMARY KEY, center TEXT, promoted INT, meta TEXT)")
        cx.execute("CREATE TABLE IF NOT EXISTS shell_members (sid TEXT, gid TEXT)")
        cx.execute("CREATE TABLE IF NOT EXISTS weights (id INTEGER PRIMARY KEY, W TEXT)")
        cx.execute("CREATE TABLE IF NOT EXISTS metrics (ts REAL, name TEXT, value REAL)")

def put_glyph(g: Dict[str, Any]) -> None:
    with _conn() as cx:
        cx.execute("REPLACE INTO glyphs (gid, vec, ts, mdhg_key) VALUES (?,?,?,?)",
                   (g['gid'], json.dumps((g['vector'].tolist() if hasattr(g['vector'], 'tolist') else list(g['vector']))), g['ts'], g.get('mdhg_key')))
        for c in g.get('claims', []):
            cx.execute("INSERT INTO claims (gid, text, ts, source, contradicted) VALUES (?,?,?,?,?)",
                      (g['gid'], c.get('text',''), c.get('ts',0.0), c.get('source',''), int(bool(c.get('contradicted')))))

def list_glyphs() -> List[Dict[str, Any]]:
    out = []
    with _conn() as cx:
        for gid, vec, ts, mdhg_key in cx.execute("SELECT gid, vec, ts, mdhg_key FROM glyphs"):
            out.append({'gid': gid, 'vector': json.loads(vec), 'ts': ts, 'mdhg_key': mdhg_key, 'claims': list_claims(gid)})
    return out

def list_claims(gid: str) -> List[Dict[str, Any]]:
    with _conn() as cx:
        rows = list(cx.execute("SELECT text, ts, source, contradicted FROM claims WHERE gid=?", (gid,)))
    return [{'text': t, 'ts': ts, 'source': s, 'contradicted': bool(c)} for (t, ts, s, c) in rows]

def put_shell(s: Dict[str, Any]) -> None:
    with _conn() as cx:
        cx.execute("REPLACE INTO shells (sid, center, promoted, meta) VALUES (?,?,?,?)",
                   (s['sid'], json.dumps(s['center'].tolist()), int(s.get('promoted', False)), json.dumps(s.get('meta', {}))))
        cx.execute("DELETE FROM shell_members WHERE sid=?", (s['sid'],))
        for gid in s.get('gids', []):
            cx.execute("INSERT INTO shell_members (sid, gid) VALUES (?,?)", (s['sid'], gid))

def list_shells() -> List[Dict[str, Any]]:
    with _conn() as cx:
        rows = list(cx.execute("SELECT sid, center, promoted, meta FROM shells"))
    out = []
    for sid, center, promoted, meta in rows:
        out.append({'sid': sid, 'center': json.loads(center), 'promoted': bool(promoted), 'meta': json.loads(meta), 'gids': list_shell_members(sid)})
    return out

def list_shell_members(sid: str) -> List[str]:
    with _conn() as cx:
        return [gid for (gid,) in cx.execute("SELECT gid FROM shell_members WHERE sid=?", (sid,))]

def save_weights(W) -> None:
    import numpy as np, json
    with _conn() as cx:
        cx.execute("INSERT INTO weights (W) VALUES (?)", (json.dumps(np.asarray(W).tolist()),))

def load_weights():
    import json, numpy as np
    with _conn() as cx:
        row = cx.execute("SELECT W FROM weights ORDER BY id DESC LIMIT 1").fetchone()
    if not row: return None
    return np.asarray(json.loads(row[0]))

def record_metric(name: str, value: float, ts: float) -> None:
    with _conn() as cx:
        cx.execute("INSERT INTO metrics (ts, name, value) VALUES (?,?,?)", (ts, name, value))
