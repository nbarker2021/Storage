# Governance (SAP)

- **Leakage gate**: reject if leakage > ε
- **Complexity gate**: guard frontier width and glyph DL
- **Detector gate**: require N≥2 and diversity≥0.5
- **Keeplist**: coverage, drift, leakage, consensus, diversity, glyph_dl, neighbors_count, frontier_width, distinct_cells, tac, boundary
