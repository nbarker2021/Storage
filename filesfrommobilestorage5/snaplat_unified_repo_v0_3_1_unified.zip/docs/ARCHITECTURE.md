# Architecture (Best-of)

- **E8 Engine** — lattice neighborhood + shell projections
- **Adapters** — E8, RAG, Detensor, etc., exposing `PlanAdapter` interface
- **Universal Planner (AGRM)** — detector fusion (K-of-N), budgeted scoring
- **MDHG Bus** — namespaced memory & hotmap access
- **SAP** — leakage/complexity/detector gates
- **Assembly/DNA** — glyph and MDL metrics
- **teletrail** — structured JSONL tick logs with a keeplist
