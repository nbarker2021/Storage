
from typing import List, Tuple
import math
from .roots import e8_roots

Vec = List[float]

def _round_half(x: float) -> float:
    return round(x - 0.5) + 0.5

def _parity_even_sum(vec: Vec) -> bool:
    s = sum(vec)
    return int(round(2*s)) % 2 == 0

def is_member(x: Vec, tol: float = 1e-9) -> bool:
    ints = all(abs(c - round(c)) < tol for c in x)
    halves = all(abs((c - 0.5) - round(c - 0.5)) < tol for c in x)
    if not (ints or halves):
        return False
    return _parity_even_sum(x)

def _candidate_Z(v: Vec) -> Vec:
    z = [round(c) for c in v]
    if not _parity_even_sum(z):
        diffs = [abs(vc - zc) for vc, zc in zip(v, z)]
        j = max(range(8), key=lambda i: diffs[i])
        z[j] += 1 if v[j] > z[j] else -1
    return [float(c) for c in z]

def _candidate_H(v: Vec) -> Vec:
    y = [_round_half(c) for c in v]
    if not _parity_even_sum(y):
        diffs = [abs(vc - yc) for vc, yc in zip(v, y)]
        j = max(range(8), key=lambda i: diffs[i])
        y[j] += 1 if v[j] > y[j] else -1
    return [float(c) for c in y]

def nearest(v: Vec) -> Tuple[Vec, float]:
    z = _candidate_Z(v)
    y = _candidate_H(v)
    dz = sum((vc - zc)**2 for vc, zc in zip(v, z))
    dy = sum((vc - yc)**2 for vc, yc in zip(v, y))
    best = z if dz <= dy else y
    return best, min(dz, dy)

def project(v: Vec) -> Vec:
    return nearest(v)[0]

_ROOTS = None
def roots():
    global _ROOTS
    if _ROOTS is None:
        _ROOTS = e8_roots()
    return _ROOTS

def edges(x: Vec):
    nbrs = []
    for r in roots():
        y = [xi + ri for xi, ri in zip(x, r)]
        if is_member(y):
            nbrs.append(y)
    return nbrs

def reflect(x: Vec, r: Vec) -> Vec:
    dot = sum(xi*ri for xi, ri in zip(x, r))
    return [xi - dot*ri for xi, ri in zip(x, r)]

_B1 = [1,1,1,1,-1,-1,-1,-1]
n1 = math.sqrt(sum(c*c for c in _B1)); _B1 = [c/n1 for c in _B1]
_B2 = [1,-1,1,-1,1,-1,1,-1]
dot12 = sum(a*b for a,b in zip(_B1,_B2)); _B2 = [b - dot12*a for a,b in zip(_B1,_B2)]
n2 = math.sqrt(sum(c*c for c in _B2)); _B2 = [c/n2 for c in _B2]
def coxeter_plane(x: Vec):
    return (sum(a*b for a,b in zip(_B1,x)), sum(a*b for a,b in zip(_B2,x)))
