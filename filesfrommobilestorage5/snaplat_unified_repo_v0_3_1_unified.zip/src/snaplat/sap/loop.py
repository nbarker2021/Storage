
from typing import Dict, Any
from .metrics import scorecard_for_cycle
from ..agrm.planner import Planner

def run_once(m: int = 1) -> Dict[str, Any]:
    pl = Planner(m=m)
    return pl.step()
