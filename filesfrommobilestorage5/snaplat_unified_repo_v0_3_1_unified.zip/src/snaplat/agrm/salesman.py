
from typing import Dict, Any, List, Tuple, Optional
from ..superperm.nav_tsp import tsp_on_root_shell, sector_cpp_then_tsp, project_points
from ..tsp.solver import weighted_metric, tour_length, close_cycle
from ..teletrail.log import teletrail
from ..e8.shells import root_shell
from ..e8.coxeter import get_projector

def _best_insertion(current_cycle: List[int], path_cycle: List[int], dist) -> Tuple[List[int], float]:
    """Insert an open version of path_cycle into current_cycle at the best edge cut.
    Returns (new_cycle, delta). Both inputs are cycles (last==first).
    Algorithm:
      - consider every cut (i -> i+1) in current
      - consider every cut (u -> v) in path (to open it)
      - delta = -d(i,i+1) - d(u,v) + d(i,u) + d(v,i+1) + (len(path_cycle_edges_except(u,v)))
        (the sum of path edges except (u,v) is constant across host cuts; we precompute)
    We produce the new cycle list with the chosen insertion.
    """
    if not current_cycle or not path_cycle: return current_cycle, 0.0
    # ensure cycles are closed
    if current_cycle[0] != current_cycle[-1]: current_cycle = current_cycle + [current_cycle[0]]
    if path_cycle[0] != path_cycle[-1]: path_cycle = path_cycle + [path_cycle[0]]
    # precompute path edges len and an order lookup
    pc = path_cycle
    path_edge_sum = sum(dist(pc[k], pc[k+1]) for k in range(len(pc)-1))
    best = None
    best_tuple = None
    # iterate current edges
    for i in range(len(current_cycle)-1):
        a, b = current_cycle[i], current_cycle[i+1]
        ab = dist(a,b)
        # iterate path edges to cut (u->v)
        for k in range(len(pc)-1):
            u, v = pc[k], pc[k+1]
            uv = dist(u,v)
            delta = -ab - uv + dist(a,u) + dist(v,b) + (path_edge_sum - uv)
            if best is None or delta < best:
                best = delta
                best_tuple = (i, k)
    # reconstruct
    i, k = best_tuple
    a, b = current_cycle[i], current_cycle[i+1]
    # open path at k: u..end + start..u (excluding duplicate endpoint)
    open_path = pc[k+1:-1] + pc[0:k+1]  # starts at v, ends at u
    # new cycle: current up to a, then open_path, then from b onward (excluding a repeated)
    new_cycle = current_cycle[:i+1] + open_path + current_cycle[i+1:]
    # ensure closed
    if new_cycle[0] != new_cycle[-1]:
        new_cycle = new_cycle + [new_cycle[0]]
    return new_cycle, float(best if best is not None else 0.0)

class SalesmanStateBus:
    def __init__(self, pts2d: List[Tuple[float,float]]):
        self.pts2d = pts2d
        self.current_cycle: List[int] = (list(range(len(pts2d))) + [0]) if pts2d else []
        self.salesman_proposals: List[Dict[str, Any]] = []
        self.teletrail = teletrail("artifacts/teletrail/salesman.jsonl")
        self.alpha_default: float = 0.3
        self.heat: List[float] = [0.0]*len(pts2d)  # populated from MDHG externally when available

    def add_salesman_proposal(self, p: Dict[str, Any]): self.salesman_proposals.append(p)

    def apply_best(self) -> Optional[Dict[str, Any]]:
        if not self.salesman_proposals: return None
        prop = self.salesman_proposals.pop(0)
        # metric with default alpha and our heat vector
        dist = weighted_metric(self.pts2d, heat=self.heat, alpha=self.alpha_default)
        before = tour_length(self.current_cycle, dist) if self.current_cycle else 0.0
        tour = prop.get("tour") or prop.get("new_subpath_nodes") or []
        if tour and (tour[0] != tour[-1]): tour = close_cycle(tour)
        new_cycle, delta_est = _best_insertion(self.current_cycle, tour, dist)
        self.current_cycle = new_cycle
        after = tour_length(self.current_cycle, dist)
        evt = {
            "event": "salesman_apply",
            "alpha": self.alpha_default,
            "before": before, "after": after,
            "delta": after - before,
            "delta_estimate": delta_est,
            "n": len(self.current_cycle)
        }
        self.teletrail.emit(evt)
        return {"before": before, "after": after, "delta": after - before, "alpha": self.alpha_default}

def propose_shell_tour(state_bus: SalesmanStateBus, sample: int = 64) -> Dict[str, Any]:
    res = tsp_on_root_shell(sample=sample, heat=state_bus.heat[:sample], alpha=state_bus.alpha_default)
    proposal = {"kind": "tsp_root_shell", "n": res["n"], "tsp_length": res["length"], "tour": res["tour"], "alpha": state_bus.alpha_default}
    state_bus.add_salesman_proposal(proposal); return proposal

def propose_sectorized(state_bus: SalesmanStateBus, sample: int = 120, n_sectors: int = 30, k: int = 3) -> Dict[str, Any]:
    res = sector_cpp_then_tsp(n_sectors=n_sectors, k=k, sample=sample, heat=state_bus.heat[:sample], alpha=state_bus.alpha_default)
    proposal = {"kind": "sector_cpp_then_tsp", "n": res["n"], "anchor_cycle_len_proxy": res["anchor_cycle_len_proxy"], "tour": res["ordered_nodes"], "alpha": state_bus.alpha_default}
    state_bus.add_salesman_proposal(proposal); return proposal

def demo_bus_from_root(sample: int = 60) -> SalesmanStateBus:
    R = root_shell()[:sample]
    P = get_projector()
    pts2d = [P(v) for v in R]
    return SalesmanStateBus(pts2d)
