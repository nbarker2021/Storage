from __future__ import annotations
from typing import Dict
DEFAULT_THRESH={'tac':0.95,'boundary':0.9,'drift':0.2}

def leakage_from_metrics(metrics: Dict[str,float], thresh: Dict[str,float] | None = None)->float:
    T=dict(DEFAULT_THRESH); T.update(thresh or {})
    tac=metrics.get('tac',1.0); boundary=metrics.get('boundary',1.0); drift=metrics.get('drift',0.0)
    leak=max(0.0, T['tac']-tac) + max(0.0, T['boundary']-boundary) + max(0.0, drift - T['drift'])
    return min(1.0, leak)
