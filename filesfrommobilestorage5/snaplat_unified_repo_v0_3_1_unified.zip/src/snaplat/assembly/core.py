
from typing import List, Dict, Any
from ..snap.schema import Candidate, DNA, dna_from

def stitch(candidates: List[Candidate], evidences: List[Dict[str, Any]]) -> Dict[str, Any]:
    assert len(candidates) == len(evidences) and len(candidates) > 0
    utils = [e.metrics.get("utility", 0.0) for e in evidences]  # type: ignore
    s = sum(utils) if sum(utils) > 0 else 1.0
    w = [u/s for u in utils]
    dna = dna_from(w, candidates)
    glyph = {"type": "barymix", "weights": w, "parts": [c.payload for c in candidates]}
    return {"glyph": glyph, "DNA": dna}

def replay(dna: DNA, candidate_lookup: Dict[str, Any]) -> Dict[str, Any]:
    parts = [candidate_lookup[cid] for cid in dna.candidates]
    glyph = {"type": "barymix", "weights": dna.weights, "parts": parts}
    return {"glyph": glyph, "DNA": dna}
