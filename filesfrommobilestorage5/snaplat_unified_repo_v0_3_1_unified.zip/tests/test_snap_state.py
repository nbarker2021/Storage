
from snaplat.snap.state import SNAPState
def test_snap_roundtrip_and_projection():
    s = SNAPState(name="t", base_point=[0.0]*8, orientation=[], projection="coxeter", constraints={}, neighbor_cache={})
    js = s.to_json(); s2 = SNAPState.from_json(js)
    assert s.hash() == s2.hash()
    u, v = s2.replay_projection(); assert isinstance(u, float) and isinstance(v, float)
    assert len(s2.neighbors()) > 0
