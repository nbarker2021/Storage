
import argparse, json, os
from snaplat.superperm.nav import run_shell_tour
from snaplat.sap.loop import run_once

def main():
    parser = argparse.ArgumentParser(prog="snaplat")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_tour = sub.add_parser("shell-tour")
    p_tour.add_argument("--m", type=int, default=1)
    p_tour.add_argument("--alpha", type=float, default=0.3)
    p_tour.add_argument("--sectors", type=int, default=30)
    p_tour.add_argument("--knn", type=int, default=3)

    p_plan = sub.add_parser("plan-step")
    p_plan.add_argument("--m", type=int, default=1)

    args = parser.parse_args()
    os.makedirs("artifacts", exist_ok=True)

    if args.cmd == "shell-tour":
        res = run_shell_tour(m=args.m, n_sectors=args.sectors, k=args.knn, alpha=args.alpha)
        with open("artifacts/shell_tour_m%d.json" % args.m, "w") as f: json.dump(res, f, indent=2)
        print("artifacts/shell_tour_m%d.json" % args.m)
    elif args.cmd == "plan-step":
        out = run_once(m=args.m)
        with open("artifacts/plan_step_cli.json", "w") as f: json.dump(out, f, indent=2)
        print("artifacts/plan_step_cli.json")

if __name__ == "__main__":
    main()


# === Universal AGRM commands (added) ===
from snaplat.agrm.universal import UniversalPlanner, BudgetCfg, DetectCfg
from snaplat.adapters.e8_adapter import E8Adapter
from snaplat.adapters.dtt_adapter import DTTAdapter
from snaplat.adapters.assembly_adapter import AssemblyAdapter
from snaplat.mdhg.bus import MDHGBus

def _cmd_detect(args):
    planner = UniversalPlanner()
    bus = MDHGBus()
    adapters = [E8Adapter(bus), DTTAdapter(mdhg=bus), AssemblyAdapter(bus)]
    D = planner.detect(adapters, state={}, cfg=DetectCfg(manifold_N=getattr(args, "N", 2)))
    print({"detectors": [d.__dict__ for d in D]})

def _cmd_plan(args):
    planner = UniversalPlanner()
    print({"score_example_only": planner.score(util=1.0, sc=planner.__class__.__mro__[0] if False else None, budget=BudgetCfg(lambda_=getattr(args,"lambda_",0.25)))})

