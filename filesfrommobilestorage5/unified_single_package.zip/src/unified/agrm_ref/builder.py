
from __future__ import annotations
from typing import Any, Dict, Optional, List
import time, math, random

def _route(n: int, seed: int) -> list[int]:
    random.seed(seed)
    r = list(range(n))
    random.shuffle(r)
    return r

def _score(route: list[int]) -> float:
    # simple length proxy
    return float(len(route))

class AGRMRefBuilder:
    """Reference AGRM-compatible builder for pipeline validation.
    Emits normalized snapshots using the agreed Snapshot schema.
    """
    def build(self, instance: Dict[str, Any], *, seed: Optional[int]=None) -> Dict[str, Any]:
        n = int(instance.get('params', {}).get('n', 6))
        base_seed = seed if seed is not None else 0
        snaps: List[Dict[str, Any]] = []
        now = time.time()
        for i, s in enumerate([base_seed, base_seed+1, base_seed+2]):
            route = _route(n, s)
            payload = {'route': route, 'steps': [], 'score': _score(route), 'metrics': {'n': n}}
            snap = {
                'id': f'ref-{s}-{i}',
                'seed': s,
                'ts': now + i*0.01,
                'params': {'n': n},
                'payload': payload,
                'hash': f'h-{s}-{n}'
            }
            snaps.append(snap)
        return {'result': {'ok': True, 'n': n}, 'snapshots': snaps}
