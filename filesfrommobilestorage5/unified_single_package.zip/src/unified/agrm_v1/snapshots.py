def list_snapshots():
    return []
