
from __future__ import annotations
import json, time, numpy as np
from dataclasses import dataclass
from typing import List, Tuple
from .persistence import db
from .jobs.queue import sweep_promotion

@dataclass
class GoldenCase:
    name: str
    action: str  # 'promotion'
    expect_min_promoted: int = 0

def run(cases: List[GoldenCase]) -> List[Tuple[str, bool, dict]]:
    db.init()
    out = []
    for c in cases:
        if c.action == 'promotion':
            res = sweep_promotion()
            ok = res.get('promoted',0) >= c.expect_min_promoted
            out.append((c.name, ok, res))
    return out
