
import json, re, sys
from pathlib import Path

def slug(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r'[^a-z0-9\s\-:_]+','',s)
    s = re.sub(r'[\s]+','-',s)
    return s[:128]

def index_doc(path: Path):
    text = path.read_text(encoding="utf-8", errors="ignore")
    heads = re.findall(r'^(#{1,6}\s+.+)$', text, flags=re.MULTILINE)
    anchors = []
    for h in heads:
        title = re.sub(r'^#{1,6}\s+','',h).strip()
        anchors.append({'title': title, 'anchor': slug(title)})
    return {'file': str(path), 'anchors': anchors}

def main(root):
    rootp = Path(root)
    entries = []
    for p in sorted(rootp.rglob("*")):
        if p.suffix.lower() in {'.txt','.md'} and p.is_file():
            entries.append(index_doc(p))
    out = rootp / "index.json"
    out.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    print(str(out))

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv)>1 else "docs")
