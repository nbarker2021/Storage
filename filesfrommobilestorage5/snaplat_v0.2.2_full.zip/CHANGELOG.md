
# Changelog
## 0.2.2 — 2025-08-16
- SymPy-backed Coxeter projector (with fallback), 2D plotter.
- FastLane rationale threaded into SAP+MORSR.
- Docs scaffold; tests for projector and C[8] invariants.
