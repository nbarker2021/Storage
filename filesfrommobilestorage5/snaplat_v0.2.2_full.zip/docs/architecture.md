## Architecture

E8 core, Superperm C[8], DTT harness, Assembly/DNA, SAP, AGRM, MDHG, Bridges, Telemetry.