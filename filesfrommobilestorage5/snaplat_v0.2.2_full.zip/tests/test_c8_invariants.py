
from snaplat.superperm.c8 import produce_c8, C8Config
def test_c8_non_repetition_and_diversity():
    cands = produce_c8(C8Config(seed=123))
    ids = [c.id for c in cands]
    assert len(ids) == 8 and len(set(ids)) == 8
    perms = [tuple(c.payload['perm']) for c in cands]
    assert len(set(perms)) == 8
