
from itertools import combinations

def e8_roots():
    roots = []
    # Type A: permutations of (±1, ±1, 0,...,0) with even number of minus signs
    for i, j in combinations(range(8), 2):
        for s1 in (+1, -1):
            for s2 in (+1, -1):
                if (int(s1<0) + int(s2<0)) % 2 == 0:
                    v = [0.0]*8
                    v[i] = float(s1)
                    v[j] = float(s2)
                    roots.append(v)
    # Type B: (±1/2,...,±1/2) with even number of minuses
    for mask in range(1<<8):
        bits = [(mask>>k)&1 for k in range(8)]
        if sum(bits) % 2 == 0:
            roots.append([(-0.5 if b else 0.5) for b in bits])
    assert len(roots) == 240
    return roots
