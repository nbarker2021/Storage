
from dataclasses import dataclass
from typing import Any, Dict, List
import json, hashlib

@dataclass
class Candidate:
    id: str
    payload: Any
    meta: Dict[str, Any]

@dataclass
class Evidence:
    candidate_id: str
    metrics: Dict[str, float]
    notes: Dict[str, Any]

@dataclass
class DNA:
    weights: List[float]
    candidates: List[str]
    checksum: str

def dna_from(weights: List[float], candidates: List[Candidate]) -> DNA:
    ids = [c.id for c in candidates]
    h = hashlib.sha256(json.dumps({"w": weights, "ids": ids}, sort_keys=True).encode()).hexdigest()
    return DNA(weights=weights, candidates=ids, checksum=h)
