# Changelog

## 0.3.1-unified (2025-08-19)
- Merge *best-of v0.3.1 (wired)* and *universal stack v0.2.8 (+tick)*.
- Rename MORSR → TeleTrail across code and docs.
- Keep Universal planner/diversity/fusion; Best-of RAG adapter and detensor.
- Add policy artifacts folder and loaders.
- Ensure SNAP-first workflows and WFC-style shelling are wired.
