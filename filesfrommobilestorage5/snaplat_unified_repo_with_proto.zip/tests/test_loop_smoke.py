from snaplat.mdhg.bus import MDHGBus
from snaplat.adapters.e8_adapter import E8Adapter
from snaplat.adapters.dtt_adapter import DTTAdapter
from snaplat.adapters.assembly_adapter import AssemblyAdapter
from snaplat.adapters.nav_adapter import NavAdapter
from snaplat.sap.loop import one_tick

def test_one_tick_smoke():
    bus = MDHGBus()
    adapters = [E8Adapter(bus, base_point=[0.0]*8), DTTAdapter(bus), AssemblyAdapter(bus), NavAdapter(bus, base_point=[0.0]*8)]
    cfg = {"agrm":{"alpha":0.25,"manifold_N":3}, "sap":{"epsilon":0.2,"max_frontier":3000,"max_glyph_dl":10.0}, "detectors":{"min_N":2,"min_diversity":0.5}}
    state = {"frontier_width": 240, "distinct_cells": 240, "word_length": 8, "glyph_dl": 1.0}
    rec = one_tick(adapters, state, cfg)
    assert "verdict" in rec and "fusion" in rec and "keep" in rec
