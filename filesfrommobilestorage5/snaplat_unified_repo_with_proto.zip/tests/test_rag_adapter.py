from snaplat.mdhg.bus import MDHGBus
from snaplat.adapters.rag_adapter import RAGAdapter

def test_rag_adapter_metrics():
    bus = MDHGBus()
    rag = RAGAdapter(bus)
    tr = rag.step([rag.actions()["index_sample"]], {"docs_total":100, "docs_touched":25, "index_drift":0.1})
    assert 0.0 <= tr.metrics["coverage"] <= 1.0
    assert tr.metrics["drift"] >= 0.0
