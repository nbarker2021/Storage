import numpy as np
from snaplat.proto.shelling_wfc import run_wfc
from snaplat.proto.assembly import barycentric_dna
from snaplat.proto.detector_gate import learn_monotone_theta
import pandas as pd

def test_wfc_runs():
    seq, ok = run_wfc(num_cells=6, seed=42)
    assert len(seq)==6
    assert ok

def test_barycentric_dna():
    res = barycentric_dna([0.6,0.4], ["C1","C2"])
    assert "dna" in res and "replay_hash" in res
    assert res["dna"]["contributors"][0]["weight"] == 0.6

def test_detector_curve_shape():
    # simple synthetic
    df = pd.DataFrame({
        "N_eff": np.random.randint(1,11, 1000),
        "disagreement": np.random.rand(1000),
        "y_true": np.random.randint(0,2, 1000),
        "consensus": np.random.rand(1000)
    })
    grid = learn_monotone_theta(df)
    # shape checks and monotonicity
    assert grid.shape == (5,5)
    # check monotone along rows/cols
    arr = grid.values
    for r in range(5):
        for c in range(4):
            assert arr[r, c] <= arr[r, c+1] + 1e-9  # nondecreasing across D
    for c in range(5):
        for r in range(4):
            assert arr[r, c] >= arr[r+1, c] - 1e-9  # nonincreasing down N
