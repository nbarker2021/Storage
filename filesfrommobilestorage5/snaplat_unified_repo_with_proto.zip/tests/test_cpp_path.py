
from snaplat.tsp.postman import eulerize_approx, euler_tour
def test_cpp_path_len():
    G = {0:{1:1.0}, 1:{0:1.0,2:1.0}, 2:{1:1.0}}
    H = eulerize_approx(G)
    tour = euler_tour(H, 0)
    # Should traverse edges and duplicated edge, path length in vertices >= 4
    assert len(tour) >= 4
