from snaplat.metrics.core import jaccard, glyph_dl_from_weights
from snaplat.agrm.diversity import diversity_counts, diversity_score

def test_jaccard_and_drift():
    assert abs(jaccard([1,2],[2,3]) - (1/3)) < 1e-9

def test_glyph_dl_bounds():
    dl = glyph_dl_from_weights([1,0,0,0,0,0,0,0])
    assert 0.0 <= dl <= 1.0

def test_diversity_min():
    M = [{'anchor':'A1','universe':'R1','seed':1}, {'anchor':'A2','universe':'R2','seed':2}]
    C = diversity_counts(M)
    assert C['anchors'] == 2 and C['universes'] == 2 and C['seeds'] == 2
    assert 0.0 <= diversity_score(M) <= 1.0
