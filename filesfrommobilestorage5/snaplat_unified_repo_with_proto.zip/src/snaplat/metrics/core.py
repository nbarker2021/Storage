from __future__ import annotations
from typing import Iterable, List
import math

def jaccard(a: Iterable, b: Iterable) -> float:
    A,B=set(a),set(b)
    if not A and not B: return 1.0
    return len(A & B)/float(len(A | B) or 1)

def coverage_ratio(n_covered:int, n_total:int)->float:
    if n_total<=0: return 0.0
    return max(0.0, min(1.0, n_covered/float(n_total)))

def drift_jaccard(prev_ids: Iterable, curr_ids: Iterable) -> float:
    return 1.0 - jaccard(prev_ids, curr_ids)

def entropy(p: List[float], eps: float=1e-12)->float:
    q=[max(eps, min(1.0, x)) for x in p]; Z=sum(q) or 1.0; q=[x/Z for x in q]
    return -sum(x*math.log(x+eps) for x in q)

def glyph_dl_from_weights(weights: List[float])->float:
    H=entropy(weights); Hmax=math.log(max(1,len(weights))); return float(H/(Hmax or 1.0))

def robust_avg(xs: List[float], trim: float=0.0)->float:
    if not xs: return 0.0
    ys=sorted(xs); k=int(len(ys)*trim); ys=ys[k: len(ys)-k or None]
    return sum(ys)/float(len(ys))
