
from typing import List, Tuple, Dict, Any
import math, json
from ..tsp.solver import tour_length, euclid

def coverage(cycle: List[int], n_total: int) -> float:
    return len(set(cycle[:-1])) / float(n_total) if n_total else 0.0

def drift_violations(cycle: List[int]) -> int:
    # In this 2D projected tour we don't actually change shells; keep 0 for alpha
    return 0

def entropy_of_sectors(cycle: List[int], pts2d: List[Tuple[float,float]], n_sectors: int = 30) -> float:
    if not cycle: return 0.0
    counts = [0]*n_sectors
    for idx in cycle[:-1]:
        x,y = pts2d[idx]; a = math.atan2(y,x) % (2*math.pi)
        s = int((a/(2*math.pi))*n_sectors) % n_sectors
        counts[s]+=1
    total = sum(counts) or 1
    ent = 0.0
    for c in counts:
        if c==0: continue
        p = c/total
        ent -= p*math.log(p+1e-12, 2)
    return ent

def scorecard_for_cycle(cycle: List[int], pts2d: List[Tuple[float,float]]) -> Dict[str, Any]:
    n = len(pts2d)
    d = euclid(pts2d)
    L = tour_length(cycle, d) if cycle else 0.0
    cov = coverage(cycle, n)
    drift = drift_violations(cycle)
    ent = entropy_of_sectors(cycle, pts2d, n_sectors=30)
    return {"coverage": cov, "length": L, "entropy": ent, "drift_violations": drift}
