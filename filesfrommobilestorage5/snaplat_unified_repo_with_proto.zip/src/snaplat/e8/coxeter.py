
from typing import Tuple, List, Callable
from functools import lru_cache
try:
    import sympy as sp  # type: ignore
except Exception:
    sp = None  # type: ignore
from .core import coxeter_plane as fallback_project

def _fallback():
    return lambda x: fallback_project(x)

@lru_cache(maxsize=1)
def _build_true_projector():
    if sp is None:
        return _fallback()
    roots = [
        [ 1/2, -1/2, -1/2, -1/2, -1/2, -1/2, -1/2,  1/2],
        [ 1.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0],
        [-1.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0],
        [ 0.0, -1.0,  1.0,  0.0,  0.0,  0.0,  0.0,  0.0],
        [ 0.0,  0.0, -1.0,  1.0,  0.0,  0.0,  0.0,  0.0],
        [ 0.0,  0.0,  0.0, -1.0,  1.0,  0.0,  0.0,  0.0],
        [ 0.0,  0.0,  0.0,  0.0, -1.0,  1.0,  0.0,  0.0],
        [ 0.0,  0.0,  0.0,  0.0,  0.0, -1.0,  1.0,  0.0],
    ]
    Alist = [sp.Matrix(r) for r in roots]
    I = sp.eye(8)
    def S(alpha): return I - alpha * alpha.T  # ||alpha||^2 = 2
    C = I
    for a in Alist:
        C = S(a) * C
    h = 30
    target = sp.exp(2*sp.pi*sp.I/h)
    evals = C.eigenvects()
    best_vec = None; best_dist = None
    for lam, mult, vecs in evals:
        lam_c = complex(lam.evalf())
        dist = abs(lam_c - complex(target.evalf()))
        if best_vec is None or dist < best_dist:
            best_vec, best_dist = vecs[0], dist
    v = sp.Matrix(best_vec)
    Re = sp.Matrix([sp.re(z) for z in v])
    Im = sp.Matrix([sp.im(z) for z in v])
    def _normalize(m):
        n = sp.sqrt((m.T*m)[0])
        return m/(n if n!=0 else 1)
    B1 = _normalize(Re)
    Im = Im - (Im.T*B1)[0]*B1
    B2 = _normalize(Im)
    def proj(x: List[float]) -> Tuple[float, float]:
        xv = sp.Matrix(x)
        return float((B1.T*xv)[0]), float((B2.T*xv)[0])
    return proj

def get_projector():
    try:
        return _build_true_projector()
    except Exception:
        return _fallback()
