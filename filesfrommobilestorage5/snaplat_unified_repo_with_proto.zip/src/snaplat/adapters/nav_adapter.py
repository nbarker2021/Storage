from __future__ import annotations
from typing import Dict, List, Any
from dataclasses import dataclass
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..metrics.core import coverage_ratio
from ..metrics.splus import leakage_from_metrics
from ..mdhg.bus import MDHGBus
@dataclass
class NavAdapter(PlanAdapterProto):
    mdhg: MDHGBus
    def actions(self) -> Dict[str, Action]:
        return {'sector_knn': Action(op='sector_knn', tag='E', m=4.0, est_cost=1.0), 'tsp_opt': Action(op='tsp_opt', tag='C', m=0.5, est_cost=1.0)}
    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        sectors=int(state.get('sectors',8)); visited=int(state.get('visited',4)); cov=coverage_ratio(visited, max(1,sectors))
        drift=float(state.get('drift',0.05)); leak=leakage_from_metrics({'tac':cov,'boundary':cov,'drift':drift},{'tac':0.7,'boundary':0.7,'drift':0.3})
        self.mdhg.put('nav:node', f'sec:{visited}', score=1.0)
        return Trail(metrics={'coverage':cov,'drift':drift,'leakage':leak}, artifacts={}, notes={})
    def learn(self, trace: Trail) -> None: return None
