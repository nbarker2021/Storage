from __future__ import annotations
from typing import Any, Dict
from pathlib import Path
import json, datetime

class TeleTrail:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fh = self.path.open("w", encoding="utf-8")
    def emit(self, kind: str, **data: Dict[str, Any]) -> None:
        evt = {"at": datetime.datetime.utcnow().isoformat()+"Z", "kind": kind, **data}
        self.fh.write(json.dumps(evt) + "\n"); self.fh.flush()
    def close(self):
        self.fh.close()
