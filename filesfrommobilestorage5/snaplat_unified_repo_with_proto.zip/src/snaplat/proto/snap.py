from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import hashlib, json, time

def _sha256_bytes(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

@dataclass(frozen=True)
class Snap:
    urn: str
    kind: str = "snap"
    version: str = "1.0.0"
    lane: str = "shadow"
    created_at: str = ""
    pins: Dict[str, Any] = field(default_factory=dict)
    provenance: Dict[str, Any] = field(default_factory=dict)
    governance: Dict[str, Any] = field(default_factory=dict)
    security: Dict[str, Any] = field(default_factory=dict)
    audit: Dict[str, Any] = field(default_factory=dict)
    payload: Dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def capture(namespace: str, topic: str, content: bytes, modal: str = "text") -> "Snap":
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        urn = f"urn:slat:snap:{namespace}:{topic}:{ts}"
        payload_hash = _sha256_bytes(content)
        payload = {
            "content_ref": [ {"cid": payload_hash, "codec": "raw", "bytes": len(content)} ],
            "modal": { modal: {"bytes": len(content)} },
            "anchors": [], "indices": {}, "views": {}, "constraints": {"role":"intake","s_plus": True}
        }
        audit = { "events": [ {"at": ts, "code": "capture", "data": {"bytes": len(content)}} ], "signatures": [] }
        return Snap(urn=urn, created_at=ts, payload=payload)

    def add_index(self, name: str, data: bytes) -> "Snap":
        new = dict(self.__dict__)
        ih = _sha256_bytes(data)
        idx = dict(new["payload"].get("indices", {}))
        idx[name] = ih
        new["payload"] = dict(new["payload"], indices=idx)
        return Snap(**new)

    def minimal_replay_set(self) -> dict:
        return {
            "target": {"urn": self.urn, "kind": self.kind},
            "content": self.payload.get("content_ref", []),
            "indices": self.payload.get("indices", {}),
            "pins": self.pins,
            "normalizers": self.provenance.get("normalizers", []),
            "seeds": self.audit.get("seeds", None)
        }
