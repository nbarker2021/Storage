from __future__ import annotations
from typing import List, Dict, Any, Tuple
import numpy as np

class WFCState:
    def __init__(self, num_cells: int, states: List[str]):
        self.num_cells = num_cells
        self.states = states
        self.superpos = [set(states) for _ in range(num_cells)]
        self.assignments = [None]*num_cells

    def entropy(self, i: int) -> int:
        return len(self.superpos[i])

def collapse_lowest_entropy(w: WFCState, rng: np.random.Generator) -> int:
    candidates = [i for i in range(w.num_cells) if w.assignments[i] is None]
    if not candidates: return -1
    ent = np.array([w.entropy(i) for i in candidates])
    i_min = candidates[int(ent.argmin())]
    choice = rng.choice(sorted(list(w.superpos[i_min])))
    w.superpos[i_min] = {choice}
    w.assignments[i_min] = choice
    return i_min

def propagate(w: WFCState, constraints: Dict[str, List[str]]) -> bool:
    # Simple constraint: neighbors cannot hold disallowed pairs
    changed = True
    while changed:
        changed = False
        for i in range(w.num_cells-1):
            left = w.superpos[i]; right = w.superpos[i+1]
            allowed = set()
            for a in left:
                allowed |= set(constraints.get(a, w.states))
            new_right = right & allowed
            if new_right != right:
                w.superpos[i+1] = new_right; changed = True
            # Symmetric
            allowed_L = set()
            for b in right:
                allowed_L |= set([k for k, vs in constraints.items() if b in vs]) or set(w.states)
            new_left = left & allowed_L
            if new_left != left:
                w.superpos[i] = new_left; changed = True
        # Check contradictions
        for s in w.superpos:
            if len(s)==0: return False
    return True

def run_wfc(num_cells: int=8, states: List[str]=None, constraints: Dict[str, List[str]]=None, seed: int=123) -> Tuple[List[str], bool]:
    if states is None: states = ["A","B","C","D"]
    if constraints is None: constraints = {"A":["A","B"], "B":["B","C"], "C":["C","D"], "D":["A","D"]}
    w = WFCState(num_cells, states)
    rng = np.random.default_rng(seed)
    ok = True
    while any(a is None for a in w.assignments):
        idx = collapse_lowest_entropy(w, rng)
        if idx < 0: break
        if not propagate(w, constraints):
            ok = False; break
    return [a if a is not None else sorted(list(w.superpos[i]))[0] for i,a in enumerate(w.assignments)], ok
