from __future__ import annotations
import numpy as np, pandas as pd

def cumulative_min(arr):
    out = arr.copy()
    for i in range(1, len(out)): out[i] = min(out[i], out[i-1])
    return out

def cumulative_max(arr):
    out = arr.copy()
    for i in range(1, len(out)): out[i] = max(out[i], out[i-1])
    return out

def learn_monotone_theta(df: pd.DataFrame, w_FA: float = 5.0, w_FH: float = 1.0) -> pd.DataFrame:
    # df must have: N_eff, disagreement, y_true, consensus
    df = df.copy()
    df["N_bin"] = pd.cut(df["N_eff"], bins=[0,2,4,6,8,10], labels=[1,3,5,7,9])
    df["D_bin"] = pd.cut(df["disagreement"], bins=np.linspace(0,1,6), labels=[0.1,0.3,0.5,0.7,0.9])
    thresholds = np.linspace(0,1,101)

    def best_theta(bdf):
        if len(bdf)==0: return np.nan
        cs = bdf["consensus"].to_numpy(); yt = bdf["y_true"].to_numpy()
        costs = []
        for t in thresholds:
            dec = (cs >= t).astype(int)
            fa = ((dec==1) & (yt==0)).sum()
            fh = ((dec==0) & (yt==1)).sum()
            costs.append(w_FA*fa + w_FH*fh)
        return float(thresholds[int(np.argmin(costs))])

    grid = pd.DataFrame(index=[1,3,5,7,9], columns=[0.1,0.3,0.5,0.7,0.9], dtype=float)
    for n in grid.index:
        for d in grid.columns:
            bdf = df[(df["N_bin"]==n) & (df["D_bin"]==d)]
            grid.loc[n, d] = best_theta(bdf)

    theta = grid.values.copy()
    for _ in range(8):
        for j in range(theta.shape[1]):
            theta[:, j] = cumulative_min(theta[:, j])
        for i in range(theta.shape[0]):
            theta[i, :] = cumulative_max(theta[i, :])
    return pd.DataFrame(theta, index=grid.index, columns=grid.columns)

def lookup_theta(grid_mono: pd.DataFrame, n_eff: int, disagreement: float, theta0: float=0.60) -> float:
    nbin = [1,3,5,7,9][min(4, max(0, int((n_eff-1)//2)))]
    dbins = [0.1,0.3,0.5,0.7,0.9]
    idx = min(range(len(dbins)), key=lambda k: abs(disagreement - dbins[k]))
    dbin = dbins[idx]
    val = grid_mono.loc[nbin, dbin]
    return float(val) if not np.isnan(val) else theta0
