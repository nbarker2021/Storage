from __future__ import annotations
import numpy as np, pandas as pd

def eval_policies(u: np.ndarray, s: np.ndarray, y_true: np.ndarray) -> dict:
    # Robust bands
    q_u = np.quantile(u, 0.90); q_s = np.quantile(s, 0.90)
    accept_band = ((u>=q_u) & (s>=q_s)).astype(int)
    leak_band = int(((accept_band==1) & (y_true==0)).sum())
    rate_band = float(accept_band.mean())

    # Pareto + top-decile
    score = 0.5*u + 0.5*s
    q_score = np.quantile(score, 0.90)
    vals = np.stack([u,s], axis=1)
    M = len(u); is_eff = np.ones(M, dtype=bool)
    for i in range(M):
        if not is_eff[i]: continue
        mask_i = is_eff.copy()
        dom = (vals[mask_i][:,0] >= vals[i,0]) & (vals[mask_i][:,1] >= vals[i,1]) & ((vals[mask_i][:,0] > vals[i,0]) | (vals[mask_i][:,1] > vals[i,1]))
        idxs = np.where(mask_i)[0]
        is_eff[idxs[dom]] = False
        is_eff[i] = True
    accept_pareto = ((is_eff==1) | (score>=q_score)).astype(int)
    leak_pareto = int(((accept_pareto==1) & (y_true==0)).sum())
    rate_pareto = float(accept_pareto.mean())

    return {
        "accept_rate_band": rate_band, "leakage_band": leak_band,
        "accept_rate_pareto": rate_pareto, "leakage_pareto": leak_pareto,
        "accept_rate_uplift_vs_band": rate_pareto - rate_band
    }
