from __future__ import annotations
from typing import List, Dict, Any
import hashlib, json

def barycentric_dna(weights: List[float], ids: List[str]) -> Dict[str, Any]:
    assert abs(sum(weights)-1.0) < 1e-6, "weights must sum to 1"
    dna = {"assembly":"barycentric","contributors":[{"id": ids[i], "weight": float(weights[i])} for i in range(len(ids))]}
    h = hashlib.sha256(json.dumps(dna, sort_keys=True).encode()).hexdigest()
    return {"dna": dna, "replay_hash": "sha256:"+h}
