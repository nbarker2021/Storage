from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict

@dataclass
class DetensorBudget:
    max_rank: int = 64
    max_growth: float = 2.0

@dataclass
class DetensorReport:
    rank_before: int
    rank_after: int
    growth: float
    clamped: bool
    notes: Dict[str, float]

def estimate_rank(weights: List[float]) -> int:
    return sum(1 for w in weights if w > 1e-6)

def clamp(weights: List[float], budget: DetensorBudget) -> DetensorReport:
    rb = estimate_rank(weights)
    growth = float(rb) / float(max(1, min(rb, budget.max_rank)))
    clamped = False
    ra = rb
    if rb > budget.max_rank or growth > budget.max_growth:
        idx = sorted(range(len(weights)), key=lambda i: weights[i], reverse=True)[:budget.max_rank]
        ra = len(idx); clamped = True
    return DetensorReport(rank_before=rb, rank_after=ra, growth=growth, clamped=clamped, notes={"lambda": 1.0/growth if growth>0 else 1.0})
