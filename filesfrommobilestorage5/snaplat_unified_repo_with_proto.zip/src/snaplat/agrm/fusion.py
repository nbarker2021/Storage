from __future__ import annotations
from typing import List, Dict, Any
LEAK_GOOD_MAX=0.05

def fuse_kofn(detectors: List[Dict[str,Any]], k:int=2, diversity:float=0.0)->Dict[str,Any]:
    N=max(1,len(detectors)); agree=sum(1 for d in detectors if float(d.get('leakage',1.0))<=LEAK_GOOD_MAX)
    consensus=agree/float(N); disagreement=max(0.0,1.0-consensus)
    novelty=float(sum(1 for d in detectors if d.get('novelty',0.0)>0.5))/N
    consensus=min(1.0, consensus*(1.0+0.1*diversity))
    return {'policy':'KofN','k':k,'consensus':consensus,'disagreement':disagreement,'novelty':novelty}
