
from typing import Dict, Any, List, Tuple
import json, os, math, random
from .salesman import SalesmanStateBus, propose_shell_tour, propose_sectorized
from ..superperm.nav import run_shell_tour
from ..e8.shells import root_shell
from ..e8.coxeter import get_projector
from ..sap.metrics import scorecard_for_cycle
from ..config import get_config
from ..teletrail.log import teletrail

class Planner:
    def __init__(self, m: int = 1):
        self.m = m
        self.cfg = get_config()
        self.teletrail = teletrail("artifacts/teletrail/planner.jsonl")
        # Build 2D points for the target shell (m=1 only for now)
        R = root_shell()
        P = get_projector()
        self.pts2d = [P(v) for v in (R if m==1 else R)]
        self.bus = SalesmanStateBus(self.pts2d)
        # prime heat from config if provided
        alpha = float(self.cfg.get("alpha", 0.3))
        self.bus.alpha_default = alpha

    def step(self) -> Dict[str, Any]:
        # Propose a sectorized covering tour and splice it
        prop = propose_sectorized(self.bus, sample=len(self.pts2d), n_sectors=self.cfg.get("n_sectors", 30), k=self.cfg.get("k_nn", 3))
        res = self.bus.apply_best()
        # Score
        sc = scorecard_for_cycle(self.bus.current_cycle, self.pts2d)
        evt = {"event":"planner_step","config": self.cfg, "score": sc}
        self.teletrail.emit(evt)
        # Write artifact
        os.makedirs("artifacts", exist_ok=True)
        out = {"proposal": prop, "apply": res, "score": sc, "config": self.cfg}
        with open("artifacts/plan_step.json", "w") as f: json.dump(out, f, indent=2)
        return out
