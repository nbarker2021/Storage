from __future__ import annotations
from typing import List, Dict, Any

def diversity_counts(manifold: List[Dict[str,Any]])->Dict[str,int]:
    anchors={m.get('anchor') for m in manifold}; univ={m.get('universe') for m in manifold}; seeds={m.get('seed') for m in manifold}
    return {'anchors':len(anchors),'universes':len(univ),'seeds':len(seeds),'N':len(manifold)}

def diversity_score(manifold: List[Dict[str,Any]])->float:
    C=diversity_counts(manifold); parts=[C.get('anchors',0),C.get('universes',0),C.get('seeds',0)]
    return min(1.0, sum(1 for x in parts if x>=2)/3.0)
