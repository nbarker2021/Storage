from __future__ import annotations
from typing import Protocol, Dict, List, Any, Literal
from dataclasses import dataclass
Tag = Literal['E','C','I','G','L']
@dataclass
class Action:
    op: str; tag: Tag; m: float=1.0; est_cost: float=1.0; args: Dict[str,Any]|None=None; pre: Dict[str,Any]|None=None; post: Dict[str,Any]|None=None
@dataclass
class Trail:
    metrics: Dict[str,float]; artifacts: Dict[str,Any]; notes: Dict[str,Any]
class PlanAdapterProto(Protocol):
    def actions(self) -> Dict[str,Action]: ...
    def step(self, schedule: List[Action], state: Dict[str,Any]) -> Trail: ...
    def learn(self, trace: Trail) -> None: ...
@dataclass
class DetectorVector:
    coverage: float; drift: float; leakage: float; cues: Dict[str,float]; hotmap_delta: Dict[str,float]; confidence: float=1.0
