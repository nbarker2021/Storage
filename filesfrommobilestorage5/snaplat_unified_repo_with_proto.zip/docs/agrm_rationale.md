## AGRM Rationale

FastLane reasons are threaded into SAP verdict notes and teletrail events.