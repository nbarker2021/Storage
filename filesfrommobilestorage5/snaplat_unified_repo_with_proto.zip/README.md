# SnapLat (Unified Repo)

This repository unifies **best-of v0.3.1 (wired)** and **universal stack v0.2.8 (+tick)**.

Key decisions:
- Namespace **TeleTrail** replaces legacy MORSR (all imports/paths updated).
- Planner spine + diversity/fusion from *Universal*; RAG adapter + detensor from *Best-of*.
- Gates are adaptive policies (functions) loaded via `policy_pin`.
- SNAPs are first-class; shelling is WFC-style; multi-run per tick with per-tick validation.

## Layout
- `src/snaplat/teletrail/*` — tick logs, event writer, release manifest
- `src/snaplat/agrm/*` — planner, diversity, fusion
- `src/snaplat/adapters/*` — RAG adapter (best-of), others
- `src/snaplat/detensor/*` — contraction ops (best-of)
- `src/snaplat/metrics/*`, `mdhg/*`, `assembly/*`, `snap/*`, `viz/*`, `e8/*`, `agents/*`
- `policy/` — detector curve + acceptance policy stubs
- `docs/diffs/` — unified diffs from branch synthesis

## Quickstart
```bash
python -m pip install -e .[dev]
pytest -q
python scripts/cli.py --help
```

## TeleTrail
All tick events and releases are logged via TeleTrail; export with `slat tt export`.
