
import os, json, hashlib

ART = os.path.join(os.getcwd(), "artifacts")
os.makedirs(ART, exist_ok=True)
manifest = {"artifacts": {}}

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

# Walk artifacts dir
for root, _, files in os.walk(ART):
    for fn in files:
        p = os.path.join(root, fn)
        rel = os.path.relpath(p, ART)
        try:
            manifest["artifacts"][rel] = {"sha256": sha256(p), "bytes": os.path.getsize(p)}
        except Exception:
            pass

# Optional: include release zip checksum if provided
zip_path = os.environ.get("SNAPLAT_RELEASE_ZIP")
if zip_path and os.path.exists(zip_path):
    manifest["release_zip"] = {"path": zip_path, "sha256": sha256(zip_path), "bytes": os.path.getsize(zip_path)}

out = os.path.join(ART, "manifest.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2, sort_keys=True)
print(out)


# Also emit a simple teletrail-style event if release zip provided
rel = manifest.get("release_zip")
if rel:
    teletrail = os.path.join(ART, "morsr_release.jsonl")
    evt = {"event": "release", "zip_path": rel["path"], "sha256": rel["sha256"], "bytes": rel["bytes"]}
    with open(teletrail, "a", encoding="utf-8") as f:
        import json as _json, time as _time
        evt["ts"] = _time.time()
        f.write(_json.dumps(evt, sort_keys=True) + "\n")
