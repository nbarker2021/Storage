
import json, math, random, datetime
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from hashlib import sha256

def sigmoid(x): return 1/(1+np.exp(-x))

def cumulative_min(arr):
    out = arr.copy()
    for i in range(1, len(out)): out[i] = min(out[i], out[i-1])
    return out

def cumulative_max(arr):
    out = arr.copy()
    for i in range(1, len(out)): out[i] = max(out[i], out[i-1])
    return out

def payload_hash(chunks):
    hlist = [sha256(c).hexdigest() for c in chunks]
    return sha256("".join(sorted(hlist)).encode()).hexdigest()

class TeleTrail:
    def __init__(self, path):
        self.path = Path(path)
        self.f = open(self.path, "w", encoding="utf-8")
    def emit(self, kind, **data):
        evt = {"at": datetime.datetime.utcnow().isoformat()+"Z", "kind": kind, **data}
        self.f.write(json.dumps(evt)+"\n")
        self.f.flush()
    def close(self):
        self.f.close()

def learn_detector_curve(df, binsN, binsD, w_FA=5.0, w_FH=1.0):
    # Bin-based θ that minimizes weighted error, then monotone projection
    df["N_bin"] = pd.cut(df["N_eff"], bins=[0,2,4,6,8,10], labels=[1,3,5,7,9])
    df["D_bin"] = pd.cut(df["disagreement"], bins=np.linspace(0,1,6), labels=[0.1,0.3,0.5,0.7,0.9])
    thresholds = np.linspace(0,1,101)

    def best_theta(bdf):
        if len(bdf)==0: return np.nan
        cs = bdf["consensus"].to_numpy(); yt = bdf["y_true"].to_numpy()
        costs = []
        for t in thresholds:
            dec = (cs >= t).astype(int)
            fa = ((dec==1) & (yt==0)).sum()
            fh = ((dec==0) & (yt==1)).sum()
            costs.append(w_FA*fa + w_FH*fh)
        return float(thresholds[int(np.argmin(costs))])

    grid = pd.DataFrame(index=[1,3,5,7,9], columns=[0.1,0.3,0.5,0.7,0.9], dtype=float)
    for n in grid.index:
        for d in grid.columns:
            bdf = df[(df["N_bin"]==n) & (df["D_bin"]==d)]
            grid.loc[n, d] = best_theta(bdf)

    theta = grid.values.copy()
    # Monotone: θ nonincreasing vs N; nondecreasing vs D
    for _ in range(8):
        for j in range(theta.shape[1]):
            theta[:, j] = cumulative_min(theta[:, j])
        for i in range(theta.shape[0]):
            theta[i, :] = cumulative_max(theta[i, :])

    grid_mono = pd.DataFrame(theta, index=grid.index, columns=grid.columns)
    return grid, grid_mono

def run(exp_dir):
    exp_dir = Path(exp_dir)
    cfg = json.loads((exp_dir/'exp_config.json').read_text())
    out = exp_dir/'out'; out.mkdir(exist_ok=True, parents=True)
    rng = np.random.default_rng(cfg['seed'])
    tt = TeleTrail(out/'teletrail_release.jsonl')

    report_lines = []

    for tick in range(cfg['n_ticks']):
        # Synthetic detector dataset
        N = cfg['n_samples_per_tick']
        N_eff = rng.integers(1, 11, size=N)
        disagreement = rng.beta(2,5, size=N)
        p_true = 1/(1+np.exp(-(0.0 + 1.2*(N_eff-5)/5.0 - 2.0*(disagreement-0.5)*2.0)))
        y_true = rng.binomial(1, p_true)
        mu_cons = 1/(1+np.exp(-(-0.2 + 1.4*(N_eff-5)/5.0 - 1.6*(disagreement-0.5)*2.0)))
        kappa = 15.0
        alpha = np.clip(mu_cons*kappa, 0.5, None)
        beta  = np.clip((1-mu_cons)*kappa, 0.5, None)
        consensus = rng.beta(alpha, beta)

        df = pd.DataFrame({"N_eff":N_eff, "disagreement":disagreement, "y_true":y_true, "consensus":consensus})

        # Detector curve learning
        grid_raw, grid_mono = learn_detector_curve(df.copy(), cfg['bins']['N'], cfg['bins']['D'],
                                                   cfg['detector_weights']['false_accept'], cfg['detector_weights']['false_hold'])
        grid_raw.to_csv(out/f"detector_curve_raw_tick{tick}.csv")
        grid_mono.to_csv(out/f"detector_curve_monotone_tick{tick}.csv")
        tt.emit("gate:detector_curve_learned", tick=tick, path=str((out/f'detector_curve_monotone_tick{tick}.csv').name))

        # Policy eval vs fixed θ
        theta0 = 0.60
        dec0 = (df["consensus"] >= theta0).astype(int)
        fa0 = int(((dec0==1) & (df["y_true"]==0)).sum())
        fh0 = int(((dec0==0) & (df["y_true"]==1)).sum())
        Wfa, Wfh = cfg['detector_weights']['false_accept'], cfg['detector_weights']['false_hold']
        cost0 = Wfa*fa0 + Wfh*fh0

        # Lookup by nearest bin
        def lookup_theta(n, d):
            nbin = [1,3,5,7,9][min(4, max(0, int((n-1)//2)))]
            dbins = [0.1,0.3,0.5,0.7,0.9]
            idx = min(range(len(dbins)), key=lambda k: abs(d - dbins[k]))
            dbin = dbins[idx]
            t = float(grid_mono.loc[nbin, dbin])
            return t if not np.isnan(t) else theta0

        thetas = np.array([lookup_theta(n,d) for n,d in zip(df['N_eff'], df['disagreement'])])
        dec1 = (df['consensus'].to_numpy() >= thetas).astype(int)
        fa1 = int(((dec1==1) & (df["y_true"]==0)).sum())
        fh1 = int(((dec1==0) & (df["y_true"]==1)).sum())
        cost1 = Wfa*fa1 + Wfh*fh1

        eval_row = {"tick":tick, "fixed_theta_false_accepts":fa0, "fixed_theta_false_holds":fh0, "fixed_theta_cost":cost0,
                    "mono_theta_false_accepts":fa1, "mono_theta_false_holds":fh1, "mono_theta_cost":cost1, "N":len(df)}
        pd.DataFrame([eval_row]).to_csv(out/f"detector_eval_tick{tick}.csv", index=False)
        tt.emit("gate:detector_curve_eval", tick=tick, metrics=eval_row)

        # AcceptanceGate: utility & stability
        M = len(df)
        rng2 = np.random.default_rng(1234+tick)
        u = rng2.normal(loc=0.5*df["y_true"].to_numpy() + 0.2*(df["N_eff"]/10).to_numpy() - 0.2*df["disagreement"].to_numpy(), scale=0.6, size=M)
        s = rng2.normal(loc=0.4*df["y_true"].to_numpy() + 0.3*(1.0-df["disagreement"].to_numpy()), scale=0.5, size=M)
        adf = pd.DataFrame({"utility":u, "stability":s, "y_true":df["y_true"]})

        # Bands
        q_u = np.quantile(adf["utility"], 0.90); q_s = np.quantile(adf["stability"], 0.90)
        accept_band = ((adf["utility"]>=q_u) & (adf["stability"]>=q_s)).astype(int)
        leak_band = int(((accept_band==1) & (adf["y_true"]==0)).sum())
        rate_band = float(accept_band.mean())

        # Pareto + top-decile
        score = 0.5*u + 0.5*s
        q_score = np.quantile(score, 0.90)
        vals = np.stack([u,s], axis=1)
        is_eff = np.ones(M, dtype=bool)
        for i in range(M):
            if not is_eff[i]: continue
            mask_i = is_eff.copy()
            dom = (vals[mask_i][:,0] >= vals[i,0]) & (vals[mask_i][:,1] >= vals[i,1]) & ((vals[mask_i][:,0] > vals[i,0]) | (vals[mask_i][:,1] > vals[i,1]))
            idxs = np.where(mask_i)[0]
            is_eff[idxs[dom]] = False
            is_eff[i] = True
        accept_pareto = ((is_eff==1) | (score>=q_score)).astype(int)
        leak_pareto = int(((accept_pareto==1) & (adf["y_true"]==0)).sum())
        rate_pareto = float(accept_pareto.mean())

        acc_eval = {"tick":tick, "accept_rate_band":rate_band, "leakage_band":leak_band,
                    "accept_rate_pareto":rate_pareto, "leakage_pareto":leak_pareto,
                    "accept_rate_uplift_vs_band": rate_pareto - rate_band}
        pd.DataFrame([acc_eval]).to_csv(out/f"acceptance_eval_tick{tick}.csv", index=False)
        tt.emit("gate:acceptance_eval", tick=tick, metrics=acc_eval)

        # SNAPs + C[8] + Assembly (mock but consistent)
        # Generate 8 candidates; pick top-2 by consensus mean; barycentric mix
        cand_scores = np.array([np.mean(rng.normal(loc=mu, scale=0.05, size=100)) for mu in np.linspace(0.55,0.85,8)])
        top_idx = cand_scores.argsort()[-2:][::-1].tolist()
        dna = {"assembly":"barycentric", "contributors":[{"id": int(i), "weight": float(w)} for i,w in zip(top_idx, [0.6,0.4])]}
        dna_hash = sha256(json.dumps(dna, sort_keys=True).encode()).hexdigest()
        glyph = {"urn":"urn:slat:glyph:exp:SPR001:%d"%tick, "dna": dna, "replay_hash":"sha256:"+dna_hash, "posture":"S+"}
        (out/f"glyph_tick{tick}.json").write_text(json.dumps(glyph, indent=2))

        tt.emit("assemble:glyph", tick=tick, glyph=glyph["urn"], replay_hash=glyph["replay_hash"])

    # Export TeleTrail done
    tt.close()
    return True

if __name__ == "__main__":
    import sys
    run(sys.argv[1] if len(sys.argv)>1 else ".")

# NOTE: proto modules available under snaplat.proto.* for gradual swap-in of real code.
