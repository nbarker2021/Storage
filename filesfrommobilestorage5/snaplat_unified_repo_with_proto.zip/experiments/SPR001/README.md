# SPR001 — Outputs

Run config: `exp_config.json`  
Runner: `run_exp_spr001.py`  
Outputs under: `out/`

Key artifacts:
- `teletrail_release.jsonl` — tick events for detector learning/eval, acceptance eval, glyph assembly.
- `detector_curve_monotone_tick*.csv` — learned θ grids per tick.
- `detector_eval_tick*.csv` — false-accept/false-hold metrics vs fixed θ.
- `acceptance_eval_tick*.csv` — bands vs pareto metrics.
- `glyph_tick*.json` — assembled glyphs (mock DNA with replay hash).

Human-in-the-loop checklist: `HITL_checklist.md`.
