
from typing import List
from .roots import e8_roots

def sigma3(n: int) -> int:
    s = 0
    for d in range(1, n+1):
        if n % d == 0:
            s += d**3
    return s

def oracle_count(m: int) -> int:
    return 240 * sigma3(m)

def root_shell() -> List[List[float]]:
    return e8_roots()


def shell_count(m: int) -> int:
    """Return the number of lattice points in the shell of squared norm 2*m.
    For E8 this equals 240 * sigma3(m), the theta-series coefficient.
    """
    return oracle_count(m)


def _sign_assign(values, signs):
    return [v if b>0 else -v for v, b in zip(values, signs)]

def _all_signs(k):
    for mask in range(1<<k):
        yield [(1 if ((mask>>i)&1)==0 else -1) for i in range(k)]

def shell(m: int):
    """Return list of E8 lattice vectors with squared norm 2*m for m=1..3.
    Construction is combinatorial and exact for these shells; counts match 240*sigma3(m).
    """
    if m == 1:
        return root_shell()
    out = []

    if m == 2:
        # Integer patterns
        # (±2, 0^7)
        for i in range(8):
            for sgn in (+1.0, -1.0):
                v = [0.0]*8; v[i] = 2.0*sgn; out.append(v)
        # (±1,±1,±1,±1,0^4)
        from itertools import combinations
        for idxs in combinations(range(8), 4):
            for signs in _all_signs(4):
                v = [0.0]*8
                for j, sgn in zip(idxs, signs):
                    v[j] = 1.0 if sgn>0 else -1.0
                out.append(v)
        # Half-integer: one 3/2 and seven 1/2 (signs restricted by parity)
        for i in range(8):
            for mask in range(1<<8):
                signs = [1 if ((mask>>k)&1)==0 else -1 for k in range(8)]
                y = [signs[k] for k in range(8)]
                y[i] *= 3  # make one entry 3
                if (sum(y) % 4) != 0:
                    continue
                v = [(yk/2.0) for yk in y]
                out.append(v)
        # Dedup (just in case)
        ded = {}
        for v in out:
            key = tuple(v)
            ded[key] = v
        out = list(ded.values())
        return out

    if m == 3:
        # Integer patterns
        from itertools import combinations
        # (±2, ±1, ±1, 0^5)
        for i in range(8):
            for s2 in (+1.0, -1.0):
                for (j, k) in combinations([x for x in range(8) if x!=i], 2):
                    for s1a, s1b in _all_signs(2):
                        v = [0.0]*8
                        v[i] = 2.0*s2
                        v[j] = 1.0 if s1a>0 else -1.0
                        v[k] = 1.0 if s1b>0 else -1.0
                        out.append(v)
        # (±1)*6, 0^2
        for idxs in combinations(range(8), 6):
            for signs in _all_signs(6):
                v = [0.0]*8
                for j, sgn in zip(idxs, signs):
                    v[j] = 1.0 if sgn>0 else -1.0
                out.append(v)
        # Half-integer: two 3/2 and six 1/2
        for (i, j) in combinations(range(8), 2):
            for mask in range(1<<8):
                signs = [1 if ((mask>>k)&1)==0 else -1 for k in range(8)]
                y = [signs[k] for k in range(8)]
                y[i] *= 3; y[j] *= 3
                if (sum(y) % 4) != 0:
                    continue
                v = [(yk/2.0) for yk in y]
                out.append(v)
        ded = {}
        for v in out:
            ded[tuple(v)] = v
        return list(ded.values())

    raise NotImplementedError("shell(m) currently implemented for m in {1,2,3}")


def shell_stream(m: int, max_coord: int | None = None):
    """Yield E8 lattice vectors with squared norm 2m.
    E8 = {x∈Z^8 : sum(x) even} ∪ {(x+1/2)^8 with integer x and sum(x) odd}.
    This is a streaming enumerator with a simple coordinate bound.
    NOTE: For large m this is expensive; choose bounds carefully.
    """
    import math
    if m <= 0: return
    if max_coord is None:
        max_coord = int(math.ceil((2*m)**0.5))  # rough bound
    # integer coset
    vec = [0]*8
    def rec_int(i, rem):
        if i == 8:
            if rem == 0 and (sum(vec) % 2 == 0):
                yield tuple(float(v) for v in vec)
            return
        # try values within bound that do not overshoot rem
        for val in range(-max_coord, max_coord+1):
            new_rem = rem - val*val
            if new_rem < 0: continue
            vec[i] = val
            yield from rec_int(i+1, new_rem)
        vec[i] = 0
    yield from rec_int(0, 2*m)

    # half-integer coset (x+1/2)
    vec = [0]*8
    def rec_half(i, rem):
        if i == 8:
            if rem == 0 and (sum(vec) % 2 == 1):  # sum(x) odd
                yield tuple(float(v + 0.5) for v in vec)
            return
        for val in range(-max_coord, max_coord+1):
            # (val+1/2)^2 = val^2 + val + 1/4
            # sum squares -> 2m  => sum(4*(...)) = 8m
            # handle by tracking 4*rem
            pass  # keep simple; half-coset skipped in streaming mode for now
    # For performance + simplicity in this alpha, we only stream the integer coset.


# --- v0.2.9 additions: completed shell_stream & helpers ---
def shell_stream(m: int, max_coord: int | None = None):
    """Yield E8 lattice vectors with squared norm 2m (both cosets), as tuples of floats.
    E8 = {x∈Z^8 : sum(x) even} ∪ {(x+1/2)^8 : x∈Z^8, sum(x) odd}.
    """
    import math
    if m <= 0:
        return
        yield  # pragma: no cover

    B = int(math.ceil((2*m)**0.5)) if max_coord is None else max_coord

    # Integer coset
    vec = [0]*8
    def rec_int(i, rem, ssum):
        if i == 8:
            if rem == 0 and (ssum % 2 == 0):
                yield tuple(float(v) for v in vec)
            return
        for val in range(-B, B+1):
            t = val*val
            if t > rem: 
                continue
            vec[i] = val
            yield from rec_int(i+1, rem - t, ssum + val)
        vec[i] = 0
    yield from rec_int(0, 2*m, 0)

    # Half-integer coset
    x = [0]*8
    def rec_half(i, rem, ssum):
        if i == 8:
            if rem == 0 and (ssum % 2 == 1):
                yield tuple(float(v + 0.5) for v in x)
            return
        for val in range(-B, B+1):
            t = val*val + val  # x^2 + x
            if t > rem:
                continue
            x[i] = val
            yield from rec_half(i+1, rem - t, ssum + val)
        x[i] = 0
    target = 2*m - 2
    if target >= 0:
        yield from rec_half(0, target, 0)

def shell_list(m: int) -> list[tuple[float, ...]]:
    return list(shell_stream(m))

def shell_count(m: int) -> int:
    return sum(1 for _ in shell_stream(m))

def shell_count_oracle(m: int) -> int | None:
    lookup = {1: 240, 2: 2160, 3: 6720, 4: 17520}
    return lookup.get(m)


# --- v0.3.0: performance helpers ---
def _sq_table(B: int):
    return [i*i for i in range(-B, B+1)], list(range(-B, B+1))

def shell_stream_fast(m: int, max_coord: int | None = None, split: int | None = None):
    """Like shell_stream but with pruning and optional naive split over the first coordinate.
    If split is provided, yields a list of chunks; caller can process in parallel.
    """
    import math
    if m <= 0: return [] if split else iter(())
    B = int(math.ceil((2*m)**0.5)) if max_coord is None else max_coord
    S, vals = _sq_table(B)
    Smap = {v: i-B for i,v in enumerate(S)}  # square -> value mapping

    def int_coset():
        vec = [0]*8
        out = []
        def rec(i, rem, ssum):
            if rem < 0: return
            # optimistic lower bound (all zeros): 0; upper bound: (B^2)*(8-i) >= rem, else prune
            if rem > S[-1]*(8-i): return
            if i == 8:
                if rem == 0 and (ssum % 2 == 0):
                    out.append(tuple(float(v) for v in vec))
                return
            for val in vals:
                t = val*val
                if t > rem: break
                vec[i] = val
                rec(i+1, rem - t, ssum + val)
            vec[i] = 0
        rec(0, 2*m, 0)
        return out

    def half_coset():
        x = [0]*8
        out = []
        target = 2*m - 2
        def rec(i, rem, ssum):
            if rem < 0: return
            if rem > (S[-1] + (B))*(8-i): return  # loose upper bound for x^2+x
            if i == 8:
                if rem == 0 and (ssum % 2 == 1):
                    out.append(tuple(float(v + 0.5) for v in x))
                return
            for val in vals:
                t = val*val + val
                if t > rem: break
                x[i] = val
                rec(i+1, rem - t, ssum + val)
            x[i] = 0
        if target >= 0:
            rec(0, target, 0)
        return out

    if split:
        # split on x0 integer coset for simplicity
        chunks = []
        for v0 in vals:
            t0 = v0*v0
            if t0 > 2*m: break
            chunks.append(("int", v0, 2*m - t0, v0))
        # half-coset split on x0 too
        target = 2*m - 2
        if target >= 0:
            for v0 in vals:
                t0 = v0*v0 + v0
                if t0 > target: break
                chunks.append(("half", v0, target - t0, v0))
        return chunks

    # default: return generator
    for v in int_coset(): yield v
    for v in half_coset(): yield v
