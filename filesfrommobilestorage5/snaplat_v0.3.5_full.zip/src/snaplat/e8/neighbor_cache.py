
from typing import Dict, List, Tuple
from .core import nearest, edges

class NeighborCache:
    def __init__(self):
        self.cache: Dict[Tuple[float,...], List[List[float]]] = {}

    def get_first_shell(self, x: List[float]) -> List[List[float]]:
        px, _ = nearest(x)
        key = tuple(px)
        if key not in self.cache:
            self.cache[key] = edges(px)
        return self.cache[key]
