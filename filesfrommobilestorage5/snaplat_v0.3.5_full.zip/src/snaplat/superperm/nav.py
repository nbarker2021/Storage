
from typing import Dict, Any, List, Tuple
from .nav_tsp import sector_cpp_then_tsp_on_points
from ..e8.coxeter import get_projector
from ..e8.shells import shell_list, root_shell

def _project_points_from_shell(m: int, sample: int | None = None):
    P = get_projector()
    if m == 1:
        V = root_shell()
    else:
        V = shell_list(m)
    if sample: V = V[:sample]
    return [P(v) for v in V], len(V)

def run_shell_tour(m: int = 1, n_sectors: int = 30, k: int = 3, alpha: float = 0.3, sample: int | None = None) -> Dict[str, Any]:
    pts2d, n = _project_points_from_shell(m, sample=sample)
    res = sector_cpp_then_tsp_on_points(pts2d, n_sectors=n_sectors, k=k, heat=None, alpha=alpha)
    # coverage stats by sectors
    counts = [0]*n_sectors
    import math
    for idx in res.get("ordered_nodes", []):
        x,y = pts2d[idx]; a = math.atan2(y,x) % (2*math.pi)
        s = int((a/(2*math.pi))*n_sectors) % n_sectors
        counts[s]+=1
    covered = sum(1 for c in counts if c>0)
    res.update({"m": m, "n": n, "sector_covered": covered, "sector_total": n_sectors})
    return res

def _proxy_cost(res):
    covered = res.get("sector_covered", 0)
    total = res.get("sector_total", 1)
    balance = covered/float(total)
    return res.get("anchor_cycle_len_proxy", 0.0) - 0.1*balance

def auto_tune_params(m: int = 1, grid = None, alpha: float = 0.3):
    if grid is None:
        grid = [(s,k) for s in (24, 30, 36, 48) for k in (3,4,5)]
    best = None; best_res = None
    pts2d, n = _project_points_from_shell(m)
    for s,k in grid:
        res = sector_cpp_then_tsp_on_points(pts2d, n_sectors=s, k=k, heat=None, alpha=alpha)
        # compute coverage
        counts = [0]*s
        import math
        for idx in res.get("ordered_nodes", []):
            x,y = pts2d[idx]; a = math.atan2(y,x) % (2*math.pi)
            sec = int((a/(2*math.pi))*s) % s; counts[sec]+=1
        res["sector_covered"] = sum(1 for c in counts if c>0)
        res["sector_total"] = s
        cost = _proxy_cost(res)
        if best is None or cost < best:
            best, best_res = cost, (s,k,res)
    return {"sectors": best_res[0], "k": best_res[1], "res": best_res[2], "cost": best}
