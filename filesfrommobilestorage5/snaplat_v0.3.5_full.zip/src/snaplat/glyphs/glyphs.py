
from __future__ import annotations
from typing import List, Tuple
import math

def build_glyph_map(pts2d: List[Tuple[float,float]], n_glyph_sectors: int = 60) -> List[int]:
    glyph = []
    for (x,y) in pts2d:
        a = math.atan2(y,x) % (2*math.pi)
        g = int((a/(2*math.pi)) * n_glyph_sectors) % n_glyph_sectors
        glyph.append(g)
    return glyph
