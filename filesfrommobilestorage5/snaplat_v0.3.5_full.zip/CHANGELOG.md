# Changelog

## 0.3.2 — 2025-08-16
- Initialized changelog for v0.3.2.

## 0.3.3 — 2025-08-16
- **Snap→Braid mimicry:** deterministic snap-stitch target + compiled braid that reproduces stitching effects.
- **SAP wiring:** braid_length (−) and braid_entropy (+) added to weighted score.
- **Acceptance gates:** max braid length per step via `mdhg.max_braid_len_factor` (× n nodes) with splice fallback.
- **Minor compiler tweaks:** stricter penalties for cross-sector/glyph/shell swaps; robust to partial targets.
- **Robust eval:** m=1 (10 seeds) & m=2 (3 seeds) A/B with gates; artifact bundle.

## 0.3.4 — 2025-08-16
- **Gate tuned:** `mdhg.max_braid_len_factor` → **9.0** (from 6.0) for fewer unnecessary fallbacks.
- **Lightweight braid compression:** windowed commuting cancellation (expose s_i · s_i^-1) + reduce; applied post-compile.
- **Robust eval:** re-run m=1 (10 seeds) & m=2 (3 seeds) after compression; artifacts updated.

## 0.3.5 — 2025-08-16
- **Macro-braid rewrites:** local patterns (e.g., s_i s_(i+1) s_i s_(i+1)^-1 s_i^-1 → s_(i+1)) to expose cancellations before compression.
- **Compression telemetry:** record `pre_len`, `post_len`, `saved` in braid_info.
- **Anchor randomization:** `mdhg.anchor_mode` = `fixed`|`random` + CLI `--anchor-mode` flag.
- **Eval:** two-step A/B with anchor randomization to stress braids; artifacts updated.
