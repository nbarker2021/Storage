from __future__ import annotations
from typing import Deque, Dict, Iterable, List, Optional
from collections import deque

_BUF: Deque[Dict] = deque(maxlen=5000)

def configure(maxlen: int = 5000) -> None:
    global _BUF
    old = list(_BUF)
    _BUF = deque(old, maxlen=maxlen)

def clear() -> None:
    _BUF.clear()

def ingest(events: Iterable[Dict]) -> int:
    n = 0
    for e in events:
        _BUF.append(e)
        n += 1
    return n

def snapshot() -> List[Dict]:
    return list(_BUF)
