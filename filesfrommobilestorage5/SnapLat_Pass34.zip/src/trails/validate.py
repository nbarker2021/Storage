from __future__ import annotations
from typing import Dict, List

# Minimal required fields per event type (kept in sync with PLANS/TRAIL_EVENT_BINDINGS.md)
REQUIRED = {
    "begin":   ["trail_id", "ts", "event", "op", "module", "policy_hash", "safe_cube", "payload"],
    "append":  ["trail_id", "ts", "event", "op", "module", "payload"],
    "finalize":["trail_id", "ts", "event", "op", "module", "payload"],
        "rendezvous":["trail_id","ts","event","module","arm","checkpoint","quorum","payload"],
}

class ValidationError(AssertionError):
    pass

def validate_event(evt: Dict) -> None:
    et = evt.get("event")
    if et not in REQUIRED:
        raise ValidationError(f"unknown event type: {et!r}")
    missing: List[str] = [k for k in REQUIRED[et] if k not in evt]
    if missing:
        raise ValidationError(f"missing fields for {et}: {missing}")
    # Light type checks
    if not isinstance(evt.get("trail_id"), str): raise ValidationError("trail_id must be str")
    if not isinstance(evt.get("module"), str): raise ValidationError("module must be str")
    if not isinstance(evt.get("op"), str): raise ValidationError("op must be str")
    if not isinstance(evt.get("payload"), dict): raise ValidationError("payload must be dict")
