"""Minimal runtime seed for Trails API.
This satisfies the contract during early wiring and keeps events in‑memory.
Replace with real emitter once sinks (files/DB) are approved.
"""
from __future__ import annotations
from typing import Any, Dict, List
from uuid import uuid4
from datetime import datetime, timezone

# In‑memory sink (process‑local)
_EVENTS: List[Dict[str, Any]] = []

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def begin_trail(context: Dict[str, Any]) -> str:
    trail_id = str(uuid4())
    evt = {
        "trail_id": trail_id,
        "ts": _now_iso(),
        "event": "begin",
        "op": context.get("op","<op>"),
        "module": context.get("module","trails.api"),
        "policy_hash": context.get("policy_hash",""),
        "safe_cube": context.get("safe_cube", {"allowed": True, "reason":"seed"}),
        "payload": {"context": context}
    }
    _EVENTS.append(evt)
    return trail_id

def append_event(trail_id: str, event: Dict[str, Any]) -> None:
    evt = {
        "trail_id": trail_id,
        "ts": _now_iso(),
        "event": "append",
        "op": event.get("op","<op>"),
        "module": event.get("module","trails.api"),
        "payload": event
    }
    _EVENTS.append(evt)

def finalize(trail_id: str, summary: Dict[str, Any]) -> None:
    evt = {
        "trail_id": trail_id,
        "ts": _now_iso(),
        "event": "finalize",
        "op": summary.get("op","<op>"),
        "module": summary.get("module","trails.api"),
        "payload": summary
    }
    _EVENTS.append(evt)

def _drain() -> List[Dict[str, Any]]:
    """Testing helper: return and clear events."""
    global _EVENTS
    out = list(_EVENTS)
    _EVENTS.clear()
    return out

def rendezvous(trail_id: str, *, arm: str, checkpoint: str, quorum: int, payload: Dict[str, Any]) -> None:
    """Emit a 'rendezvous' event. Used by tests and orchestration harnesses."""
    evt = {
        "trail_id": trail_id,
        "ts": _now_iso(),
        "event": "rendezvous",
        "module": "trails.api",
        "arm": arm,
        "checkpoint": checkpoint,
        "quorum": int(quorum),
        "payload": payload,
    }
    _EVENTS.append(evt)
