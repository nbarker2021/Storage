import os
POLICY_HASH = os.environ.get('SNAPLAT_POLICY_HASH', 'dev')
