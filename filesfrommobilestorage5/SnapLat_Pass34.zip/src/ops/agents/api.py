from __future__ import annotations
import hashlib
from typing import Dict
from ops.policy.api import POLICY_HASH

_CACHE: Dict[str, str] = {}

def agent_fingerprint(agent: str) -> str:
    """Deterministic fingerprint for an agent name under current policy hash."""
    key = f"{agent}|{POLICY_HASH}"
    fp = _CACHE.get(key)
    if fp: return fp
    h = hashlib.sha256(key.encode("utf-8")).hexdigest()
    _CACHE[key] = h
    return h
