from __future__ import annotations
from typing import Any, Dict, List, Set
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH
from ops.agents.api import agent_fingerprint as __agent_fp_fn__

@dataclass
class WorkOrder:
    modules: List[str]
    ops: List[str]
    counts: Dict[str,int]

def stage(transcript) -> WorkOrder:
    tid = trails.begin_trail({"op":"assembly.stage", "chain": {"agent_fp": __agent_fp_fn__("assembly")},"module":__name__,"policy_hash":POLICY_HASH})
    try:
        mods: Set[str] = set()
        ops: List[str] = []
        for e in transcript.steps:
            ops.append(e.op)
            head = e.op.split(".")[0] if "." in e.op else e.op
            if head: mods.add(head)
        wo = WorkOrder(modules=sorted(mods), ops=ops, counts=dict(transcript.counts), snap_ids=sorted({e.meta.get('snap_id') for e in transcript.steps if getattr(e,'meta',None) and e.meta.get('snap_id')}))
        trails.append_event(tid, {"op":"assembly.staged","module":__name__,"payload":{"modules":wo.modules,"n":len(wo.ops)}})
        return wo
    finally:
        trails.finalize(tid, {"op":"assembly.done","module":__name__})
