from __future__ import annotations
from typing import Any, Dict, List
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class RegionMap:
    regions: Dict[str, float]  # simple probability mass over regions

def analyze(transcript) -> RegionMap:
    tid = trails.begin_trail({"op":"morsr.analyze","module":__name__,"policy_hash":POLICY_HASH})
    try:
        counts: Dict[str,int] = getattr(transcript, "counts", {}) or {}
        total = float(sum(counts.values())) or 1.0
        regions = {k: (v/total) for k, v in counts.items()}
        trails.append_event(tid, {"op":"morsr.regions","module":__name__,"payload":{"n":len(regions)}})
        return RegionMap(regions=regions)
    finally:
        trails.finalize(tid, {"op":"morsr.done","module":__name__})
