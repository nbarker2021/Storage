
from typing import Dict, Any

class SchemaRegistry:
    def __init__(self):
        self._schemas: Dict[str, Dict[str,Any]] = {}
    def key(self, family: str, type_: str) -> str:
        return f"{family}/{type_}"
    def register(self, family: str, type_: str, schema: Dict[str,Any]):
        self._schemas[self.key(family,type_)] = dict(schema)
    def get(self, family: str, type_: str) -> Dict[str,Any] | None:
        return self._schemas.get(self.key(family,type_), None)

registry = SchemaRegistry()

# Seed a few core schemas
registry.register("bridge", "tpg_bridge", {"required":["meta","content"]})
registry.register("proposal", "tpg_order", {"required":["meta","content"]})
registry.register("trail", "events", {"required":["meta","content"]})
registry.register("state", "save", {"required":["meta","content"]})
registry.register("metric", "point", {"required":["meta","content"]})
registry.register("decision","promotion",{"required":["meta","content"]})
