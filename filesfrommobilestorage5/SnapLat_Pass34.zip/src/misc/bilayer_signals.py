
import re
from typing import Dict, Tuple

SUPPORT = re.compile(r"\b(supports?|enables?|improves?|increases?|reinforce[sd]?|aligns?|favors?)\b", re.I)
OPPOSE  = re.compile(r"\b(oppose[sd]?|prevents?|reduces?|decreases?|conflicts?|contradicts?|negates?)\b", re.I)
NEGATE  = re.compile(r"\b(not|no|never|without|unless)\b", re.I)

def token_overlap(a: str, b: str) -> float:
    A = set(w.lower() for w in re.findall(r"[A-Za-z]{3,}", a or ""))
    B = set(w.lower() for w in re.findall(r"[A-Za-z]{3,}", b or ""))
    if not A or not B: 
        return 0.0
    return len(A & B) / float(min(len(A), len(B)))

def laso_lite(a: str, b: str) -> float:
    # cheap lexical coherence proxy: overlap minus negation penalty
    ov = token_overlap(a, b)
    neg = 0
    if NEGATE.search(a or ""): neg += 0.05
    if NEGATE.search(b or ""): neg += 0.05
    return max(0.0, ov - neg)

def bilayer_relation(a_text: str, b_text: str) -> Tuple[str, float]:
    sa = SUPPORT.search(a_text or "")
    sb = SUPPORT.search(b_text or "")
    oa = OPPOSE.search(a_text or "")
    ob = OPPOSE.search(b_text or "")
    if (sa and ob) or (sb and oa):
        return ("annihilate", 0.4 + 0.4*laso_lite(a_text, b_text))
    if (sa and sb) and not (oa or ob):
        return ("reinforce", 0.6 + 0.4*laso_lite(a_text, b_text))
    # fallback by coherence
    coh = laso_lite(a_text, b_text)
    if coh >= 0.2:
        return ("reinforce", 0.5 + 0.5*coh)
    return ("ambiguous", 0.3*coh)


def relation_weight(rel: str, score: float) -> float:
    """Map bilayer relation to an edge weight delta."""
    if rel == "reinforce":
        return min(0.25, 0.1 + 0.5*score)
    if rel == "annihilate":
        return -min(0.25, 0.1 + 0.5*score)
    return 0.0
