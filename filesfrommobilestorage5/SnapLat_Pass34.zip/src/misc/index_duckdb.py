
from typing import List, Dict, Any, Optional
from pathlib import Path
import duckdb, json

class DuckIndex:
    """Optional DuckDB index for SNAP metadata.
Stores meta rows (snap_id, family, type, created_ts, tags_json)
    """
    def __init__(self, db_path: str):
        self.path = Path(db_path)
        self.conn = duckdb.connect(str(self.path))
        self.conn.execute("""CREATE TABLE IF NOT EXISTS meta(
            snap_id TEXT PRIMARY KEY,
            family TEXT,
            type TEXT,
            created_ts DOUBLE,
            tags_json TEXT
        )""")

    def upsert(self, meta: Dict[str,Any]):
        snap_id = meta.get("snap_id")
        if not snap_id: return
        rec = (snap_id, meta.get("family"), meta.get("type"), float(meta.get("created_ts", 0.0)),
               json.dumps(meta.get("tags", {})))
        self.conn.execute("DELETE FROM meta WHERE snap_id = ?", [snap_id])
        self.conn.execute("INSERT INTO meta VALUES (?,?,?,?,?)", rec)

    def bulk_upsert(self, metas: List[Dict[str,Any]]):
        for m in metas: self.upsert(m)

    def query(self, family: Optional[str]=None, typ: Optional[str]=None, tag_key: Optional[str]=None, tag_value: Optional[str]=None) -> List[str]:
        if tag_key and tag_value is not None:
            sql = "SELECT snap_id FROM meta WHERE (? IS NULL OR family=?) AND (? IS NULL OR type=?) AND json_extract(tags_json, ?) = ?"
            key = f'$.{tag_key}'
            rs = self.conn.execute(sql, [family, family, typ, typ, key, tag_value]).fetchall()
        else:
            sql = "SELECT snap_id FROM meta WHERE (? IS NULL OR family=?) AND (? IS NULL OR type=?)"
            rs = self.conn.execute(sql, [family, family, typ, typ]).fetchall()
        return [r[0] for r in rs]
