
import re
from typing import List, Set

TOK = re.compile(r"[A-Za-z][A-Za-z0-9_\-]{2,}")

def tokenize(s: str) -> List[str]:
    return [t.lower() for t in TOK.findall(s or "")]

def split_sents(text: str) -> List[str]:
    # Split on sentence enders or blank lines
    parts = re.split(r'(?<=[\.!?])\s+|\n{2,}', (text or "").strip())
    return [p.strip() for p in parts if p and p.strip()]

def refine_text(text: str, min_new: int = 4, max_keep: int = 10) -> str:
    """
    Keep sentences that add >= min_new new tokens compared to what we've already kept.
    Cap total kept sentences to max_keep.
    Deterministic, auditable, and cheap.
    """
    keep: List[str] = []
    seen: Set[str] = set()
    for sent in split_sents(text):
        toks = set(tokenize(sent))
        new = [t for t in toks if t not in seen]
        if len(new) >= min_new or not keep:
            keep.append(sent)
            seen.update(new)
        if len(keep) >= max_keep:
            break
    return "\n".join(keep) if keep else (text or "")[:400]
