
"""
Lightweight in-process task queue.
- FIFO queue with background worker threads.
- Each task has: name, args (dict), enqueued_ts, started_ts, finished_ts, status, result/error.
- Notation: tasks should be idempotent; retries can be added later.
"""
import time, threading, queue
from dataclasses import dataclass, field
from typing import Callable, Dict, Any, List, Optional

@dataclass
class Task:
    name: str
    args: Dict[str, Any] = field(default_factory=dict)
    id: int = 0
    enqueued_ts: float = field(default_factory=time.time)
    started_ts: float = 0.0
    finished_ts: float = 0.0
    status: str = "queued"  # queued|running|done|error
    result: Any = None
    error: str = ""

class TaskQueue:
    def __init__(self, workers: int = 2):
        self.q = queue.Queue()
        self.tasks: Dict[int, Task] = {}
        self.handlers: Dict[str, Callable[[Dict[str, Any]], Any]] = {}
        self._id = 0
        self._threads: List[threading.Thread] = []
        self._stop = False
        for _ in range(workers):
            t = threading.Thread(target=self._loop, daemon=True)
            t.start()
            self._threads.append(t)

    def register(self, name: str, handler: Callable[[Dict[str, Any]], Any]):
        self.handlers[name] = handler

    def enqueue(self, name: str, **args) -> int:
        self._id += 1
        tid = self._id
        task = Task(name=name, args=args, id=tid)
        self.tasks[tid] = task
        self.q.put(tid)
        return tid

    def _loop(self):
        while not self._stop:
            tid = self.q.get()
            task = self.tasks.get(tid)
            if not task:
                continue
            task.status = "running"
            task.started_ts = time.time()
            try:
                fn = self.handlers.get(task.name)
                if not fn:
                    raise RuntimeError(f"No handler for task {task.name}")
                task.result = fn(task.args)
                task.status = "done"
            except Exception as e:
                task.error = str(e)
                task.status = "error"
            finally:
                task.finished_ts = time.time()

    def get(self, tid: int) -> Optional[Task]:
        return self.tasks.get(tid)

    def list(self) -> List[Task]:
        return list(self.tasks.values())
