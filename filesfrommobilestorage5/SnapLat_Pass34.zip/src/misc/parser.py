
from typing import List, Dict, Any
from pathlib import Path
import time

def simple_text_parser(path: str, chunk_chars: int = 800) -> List[Dict[str,Any]]:
    """Very simple text parser: splits into ~chunk_chars and returns SNAP-like dicts (meta+content)."""
    p = Path(path)
    text = p.read_text(encoding="utf-8", errors="ignore")
    chunks = []
    for i in range(0, len(text), chunk_chars):
        chunk = text[i:i+chunk_chars]
        sid = f"docchunk::{p.name}::{i}"
        meta = {"snap_id": sid, "family":"doc","type":"chunk","created_ts": time.time(),"tags":{"source_file": p.name}}
        chunks.append({"meta": meta, "content": {"text": chunk}})
    return chunks
