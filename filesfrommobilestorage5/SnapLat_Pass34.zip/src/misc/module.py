def fnv1a64(b: bytes):
    return int.from_bytes(b[:8].ljust(8,b'\0'), 'little')
