
from __future__ import annotations
import re, json, hashlib, os
from typing import List, Dict, Any
from .utils import parse_log, file_tokens, tokseq
from .e8 import encode_text_to_e8, E8Key, OU, EU, DU, GU, UU
from .graph import Node, Edge, Ledger
from .snaps import generate_snaps

APPROVAL = re.compile(r"\b(go with|go ahead|proceed|continue|yes,? please|approved|explicit.*approval)\b", re.IGNORECASE)
ISSUE = re.compile(r"\b(error|fail|traceback|missing|not found|quota|upload.*cap|blocked|laggy|slow)\b", re.IGNORECASE)

def gid(prefix: str, text: str) -> str:
    h = hashlib.sha1(text.encode('utf-8')).hexdigest()[:12]
    return f"{prefix}_{h}"

def build_universes(events: List[Dict[str,Any]]):
    led = Ledger()
    # Event nodes + edges
    for idx, ev in enumerate(events, start=1):
        role = ev['role']; content = ev.get('content','')
        uni = EU if role != 'user' else UU
        n = Node(
            gid=gid('evt', f"{role}:{ev['line_start']}-{ev['line_end']}"),
            kind='event',
            label=f"{role}@{ev['line_start']}..{ev['line_end']}",
            e8=encode_text_to_e8(content, uni, tags=(role,)),
            meta={'idx':idx,'role':role,'lines':[ev['line_start'], ev['line_end']], 'file_tokens':file_tokens(content)}
        )
        led.upsert_node(n)
        # approvals/issues tagging via edges to virtual labels
        if APPROVAL.search(content) and role=='user':
            a = Node(gid=gid('tag','approval'), kind='tag', label='approval', e8=encode_text_to_e8('approval', DU, tags=('tag',)))
            led.upsert_node(a); led.add_edge(Edge(n.gid, a.gid, 'has_tag', {}))
        if ISSUE.search(content):
            b = Node(gid=gid('tag','issue'), kind='tag', label='issue', e8=encode_text_to_e8('issue', DU, tags=('tag',)))
            led.upsert_node(b); led.add_edge(Edge(n.gid, b.gid, 'has_tag', {}))
        # document universe nodes from file tokens
        for t in n.meta['file_tokens']:
            d = Node(gid=gid('doc', t), kind='document', label=t, e8=encode_text_to_e8(t, DU, tags=('document',)), meta={})
            led.upsert_node(d); led.add_edge(Edge(n.gid, d.gid, 'mentions', {}))
    # Simple temporal edges
    evt_nodes = [k for k,v in led.nodes.items() if v.kind=='event']
    evt_nodes_sorted = sorted(evt_nodes, key=lambda g: led.nodes[g].meta['idx'])
    for a, b in zip(evt_nodes_sorted, evt_nodes_sorted[1:]):
        led.add_edge(Edge(a, b, 'next', {}))
    return led

def generate_all(log_text: str, out_dir: str) -> Dict[str,str]:
    events = parse_log(log_text)
    ledger = build_universes(events)
    # snaps
    snaps_dir = os.path.join(out_dir, 'snaps')
    os.makedirs(snaps_dir, exist_ok=True)
    snap_paths = generate_snaps(snaps_dir, extra=[
        dict(name="SNAPThermo", domain="Thermodynamics", purpose="Run and report simulations from formulas"),
        dict(name="SNAPCrystals", domain="Mineralogy", purpose="Index and catalog crystal items"),
        dict(name="SNAPWheelhouse", domain="Runtime", purpose="Manage Linux wheels and ABI gates"),
    ])
    # dumps
    ledger_path = os.path.join(out_dir, 'SnapOS_e8_ledger_v1.json')
    universes_path = os.path.join(out_dir, 'SnapOS_universes_v1.json')
    snaps_path = os.path.join(out_dir, 'SnapOS_snaps_catalog_v1.json')
    with open(ledger_path, 'w', encoding='utf-8') as f:
        json.dump(ledger.to_json(), f, indent=2)
    with open(universes_path, 'w', encoding='utf-8') as f:
        json.dump({"universes":["EU","UU","DU","OU","GU"], "counts": {"nodes": len(ledger.nodes), "edges": len(ledger.edges)}}, f, indent=2)
    with open(snaps_path, 'w', encoding='utf-8') as f:
        json.dump({"generated": snap_paths}, f, indent=2)
    return {"ledger": ledger_path, "universes": universes_path, "snaps": snaps_path}
