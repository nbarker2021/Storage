
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import re

STOP = set('the a an and or of to in for on at with without into from by as is are was were be been being about this that these those it its our your their you we i not'.split())

@dataclass
class ShellLevel:
    n: int
    nodes: List[Dict[str,Any]]

def _tokenize(text: str) -> List[str]:
    text = text.lower()
    toks = re.findall(r"[a-z0-9][a-z0-9\-]{1,}", text)
    toks = [t for t in toks if t not in STOP and len(t) > 2]
    return toks

def _bigrams(tokens: List[str]) -> List[Tuple[str,str]]:
    return [(tokens[i], tokens[i+1]) for i in range(len(tokens)-1)]

def _top_terms(text_hint: str, k: int = 12) -> List[str]:
    toks = _tokenize(text_hint or '')
    if not toks:
        return []
    freq = {}
    for t in toks: freq[t] = freq.get(t, 0) + 1
    bi = _bigrams(toks)
    bonus = {}
    for a,b in bi:
        bonus[a] = bonus.get(a,0)+0.5
        bonus[b] = bonus.get(b,0)+0.5
    scored = sorted(freq.items(), key=lambda kv: -(kv[1] + bonus.get(kv[0],0)))
    return [w for w,_ in scored[:k]]

def normalize_meta(meta: Dict[str,Any]) -> Dict[str,Any]:
    return {
        "family": meta.get("family"),
        "type": meta.get("type"),
        "tags": meta.get("tags", {}),
        "text_hint": (meta.get("content", {}) or {}).get("text", "")[:500]
    }

def to_three_words(level: ShellLevel) -> List[str]:
    bag = []
    for m in level.nodes:
        hint = m.get("text_hint","")
        bag.extend(_top_terms(hint, k=6))
    top = []
    seen = set()
    for t in bag:
        if t not in seen:
            top.append(t); seen.add(t)
        if len(top) >= 3: break
    if len(top) < 3:
        for m in level.nodes:
            for f in (m.get("type"), m.get("family")):
                if f and f not in seen:
                    top.append(str(f)); seen.add(str(f))
                    if len(top) >= 3: break
            if len(top) >= 3: break
    while len(top) < 3: top.append("∅")
    return top[:3]

def shell(meta: Dict[str,Any], max_n:int=5) -> List[ShellLevel]:
    base = normalize_meta(meta)
    hint = base.get("text_hint","")
    atoms = _top_terms(hint, k=24)
    if not atoms and (base.get("type") or base.get("family")):
        atoms = [x for x in [base.get("type"), base.get("family")] if x]
    level1 = [ {"atom": a, "text_hint": a} for a in atoms ] or [base]
    levels = [ShellLevel(n=1, nodes=level1)]
    cur = level1
    for n in range(2, max_n+1):
        if len(cur) <= 1:
            levels.append(ShellLevel(n=n, nodes=cur))
            continue
        win = 2 if n<=3 else 3
        nxt = []
        for i in range(0, len(cur), win):
            grp = cur[i:i+win]
            merged_hint = " ".join([m.get("text_hint","") for m in grp])[:240]
            nxt.append({"group": [m.get("atom", m.get("group", m)) for m in grp], "text_hint": merged_hint})
        cur = nxt
        levels.append(ShellLevel(n=n, nodes=cur))
    return levels
