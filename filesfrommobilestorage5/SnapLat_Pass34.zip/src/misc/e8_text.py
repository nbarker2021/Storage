
from __future__ import annotations
import numpy as np, hashlib

# 8 approximate "root" directions in R^8 (orthonormal basis for simplicity here).
_BASIS = np.eye(8, dtype=np.float32)

def _h(text: str, salt: str) -> int:
    d = hashlib.blake2b((salt+text).encode('utf-8'), digest_size=8).digest()
    return int.from_bytes(d, 'little')

def embed_text(text: str, salt: str = "E8") -> np.ndarray:
    """Deterministic 8D embedding: mix hashed weights across basis vectors.
    This is a stand-in for a real E8 encoder; it's stable and reversible if needed."""
    h1 = _h(text, salt+"1"); h2 = _h(text, salt+"2")
    coeffs = np.zeros(8, dtype=np.float32)
    for i in range(8):
        # map to signed float in [-1,1]
        vi = ((h1 >> (i*8)) & 0xFF) / 127.5 - 1.0
        wi = ((h2 >> (i*8)) & 0xFF) / 127.5 - 1.0
        coeffs[i] = 0.7*vi + 0.3*wi
    v = (_BASIS * coeffs.reshape(-1,1)).sum(axis=0)
    # normalize to unit length
    n = np.linalg.norm(v) + 1e-12
    return (v / n).astype(np.float32)

def embed_batch(texts: list[str], salt: str = "E8") -> np.ndarray:
    X = np.stack([embed_text(t, salt) for t in texts], axis=0)
    return X
