
from __future__ import annotations
from fastapi import APIRouter, Body, Query
from pydantic import BaseModel
from lattice_ai.encode.e8_lattice import E8LatticeEncoder

router = APIRouter(prefix="/encode", tags=["encode"])
enc = E8LatticeEncoder(salt="E8")
enc.allocate_bank("docs", shape="E8:Shells", capacity=1024)
enc.allocate_bank("blobs", shape="E8:Bytes", capacity=512)

class TextsIn(BaseModel):
    texts: list[str]
    bank: str | None = "docs"
    k: int = 3
    shell_k: int = 1

@router.post("/texts")
def encode_texts(payload: TextsIn):
    out = enc.encode_texts(payload.texts, bank=payload.bank, k=payload.k, shell_k=payload.shell_k)
    return {"vectors_shape": list(out["vectors"].shape), "meta_0": out["meta"][0], "bank": payload.bank}

@router.post("/text")
def encode_text(text: str = Body(..., embed=True), bank: str | None = "docs", k: int = Query(3), shell_k: int = Query(1)):
    out = enc.encode_text(text, bank=bank, k=k, shell_k=shell_k)
    return {"meta": out["meta"], "bank_index": out.get("bank_index")}
