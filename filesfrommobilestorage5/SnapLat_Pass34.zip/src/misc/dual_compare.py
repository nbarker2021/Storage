
from __future__ import annotations
import json
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple
import numpy as np

from lattice_ai.bridge.dual_stack import load_dual, maybe_emit_snap
from retrieval.scorer import ScorerConfig, rerank

@dataclass(slots=True)
class RetrievalReport:
    k: int
    overlap_at_k: float
    jaccard_at_k: float
    rank_corr_tau: float

def _kendall_tau(a: List[int], b: List[int]) -> float:
    # very small n; naive Kendall tau
    n = len(a)
    if n <= 1:
        return 1.0
    pairs = 0
    concord = 0
    pos_b = {v:i for i,v in enumerate(b)}
    for i in range(n):
        for j in range(i+1, n):
            ai, aj = a[i], a[j]
            bi, bj = pos_b[ai], pos_b[aj]
            pairs += 1
            concord += 1 if bi < bj else 0
    return (2*concord/pairs) - 1.0

def compare_retrieval(q: np.ndarray, docs: np.ndarray, topk: int = 20, axes: Dict[str, Any] | None = None) -> Dict[str, Any]:
    v14, legacy, _ = load_dual()
    cfg = ScorerConfig(alpha=1.0, beta=0.15)  # small beta proxy
    idx_v14, _ = rerank(q, docs, cfg, topk=topk)
    idx_leg, _ = rerank(q, docs, cfg, topk=topk) if legacy else (idx_v14, None)  # same scorer; geometry parity tested elsewhere

    a = list(map(int, idx_v14))
    b = list(map(int, idx_leg))
    overlap = len(set(a) & set(b)) / float(topk)
    jaccard = len(set(a) & set(b)) / float(len(set(a) | set(b)))
    tau = _kendall_tau(a, b)
    report = {
        "topk": topk,
        "overlap_at_k": overlap,
        "jaccard_at_k": jaccard,
        "rank_corr_tau": tau,
    }
    if axes is None:
        axes = {"version_container": "v14", "tenant": "demo", "domain": "retrieval"}
    maybe_emit_snap(report, axes)
    return report
