
from __future__ import annotations
import argparse, pathlib, shutil, json
from detect_version import path_version

def find_candidates(root: pathlib.Path):
    hits = []
    for p in root.rglob("*e8_roots.py"): hits.append(p)
    for p in root.rglob("*e8.py"): hits.append(p)
    return hits

def choose_canonical(root: pathlib.Path):
    cands = find_candidates(root)
    scored = []
    for p in cands:
        v = path_version(p); scored.append((v if v is not None else -1, p))
    scored.sort(reverse=True)
    return scored[0][1].parent

def promote_to_canonical(root: pathlib.Path, chosen_dir: pathlib.Path):
    tgt = root / "canonical_v14" / "lattice_ai" / "geometry"
    tgt.mkdir(parents=True, exist_ok=True)
    for fn in ("e8_roots.py","e8.py"):
        src = chosen_dir / fn
        if src.exists():
            shutil.copy2(src, tgt / fn); print("[copy]", src, "->", tgt / fn)
    print("[ok] Canonical:", tgt); return tgt

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); args = ap.parse_args()
    root = pathlib.Path(args.root).resolve()
    chosen = choose_canonical(root)
    pkg = promote_to_canonical(root, chosen)
    print(json.dumps({"canonical_geometry": str(pkg)}, indent=2))
if __name__ == "__main__": main()
