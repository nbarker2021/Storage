
import time, json
from dataclasses import dataclass
from typing import Any, Dict, Callable, Tuple
@dataclass
class Budgets_v0_1_2025_08_13:
    seconds: float = 5.0
    max_input_bytes: int = 1_000_000
    max_output_bytes: int = 1_000_000
    max_steps: int = 10
@dataclass
class RunStats_v0_1_2025_08_13:
    ok: bool; duration_s: float; steps: int; in_bytes: int; out_bytes: int; error: str = ""
def _sizeof(obj)->int:
    try: return len(json.dumps(obj))
    except Exception: return 0
def run_with_budgets_v0_1_2025_08_13(fn: Callable[[], Dict[str, Any]], inputs: Dict[str, Any], budgets: Budgets_v0_1_2025_08_13) -> Tuple[Dict[str, Any], RunStats_v0_1_2025_08_13]:
    t0=time.perf_counter(); in_b=_sizeof(inputs)
    if in_b > budgets.max_input_bytes:
        return {}, RunStats_v0_1_2025_08_13(ok=False, duration_s=0.0, steps=0, in_bytes=in_b, out_bytes=0, error="input-bytes-exceeded")
    try: out = fn()
    except Exception as e:
        return {}, RunStats_v0_1_2025_08_13(ok=False, duration_s=time.perf_counter()-t0, steps=0, in_bytes=in_b, out_bytes=0, error=str(e))
    dur=time.perf_counter()-t0; out_b=_sizeof(out)
    if dur > budgets.seconds:
        return out, RunStats_v0_1_2025_08_13(ok=False, duration_s=dur, steps=out.get("_steps",0), in_bytes=in_b, out_bytes=out_b, error="time-budget-exceeded")
    if out_b > budgets.max_output_bytes:
        return out, RunStats_v0_1_2025_08_13(ok=False, duration_s=dur, steps=out.get("_steps",0), in_bytes=in_b, out_bytes=out_b, error="output-bytes-exceeded")
    return out, RunStats_v0_1_2025_08_13(ok=True, duration_s=dur, steps=out.get("_steps",0), in_bytes=in_b, out_bytes=out_b, error="")
