
from __future__ import annotations
from typing import Dict, Any, List
import numpy as np
from lattice_ai.tests.goldens_recall_latency import synth_corpus, _cosine
from lattice_ai.encode.e8_lattice import _geodesic_proxy
from lattice_ai.snap.snaphash import SnapHash, save_snaphash
from lattice_ai.snap.think_tank import publish

def run(snaphash_id: str = "shells→governance", seed: int = 99, K: int = 10, gdist_gate: float = 0.8, coh_gate: float = 0.05) -> Dict[str, Any]:
    texts, X, labels = synth_corpus(seed=seed)
    # fake shells by building small neighborhoods around topic medoids
    idxs = []
    for t in range(8):
        idx = [i for i,l in enumerate(labels) if l==t]
        center = idx[len(idx)//2]
        # neighbors by cosine in-topic
        sims = _cosine(X[center], X[idx]); order = np.argsort(-sims)[:K]
        idxs.append([idx[i] for i in order])
    # compute governance metrics
    promotes = 0; coh_list=[]; gmax_list=[]
    for j, group in enumerate(idxs):
        C = X[group]
        coh = float(np.mean(_cosine(np.mean(C,axis=0), C)))
        gmax = float(max(_geodesic_proxy(v) for v in C))
        coh_list.append(coh); gmax_list.append(gmax)
        if gmax <= gdist_gate and coh >= coh_gate: promotes += 1
    prom_rate = promotes/len(idxs)
    metrics = {"promote_rate": prom_rate, "coh_mean": float(np.mean(coh_list)), "gdist_max": float(np.max(gmax_list))}
    sh = SnapHash(snaphash_id=snaphash_id, src={"system":"shells"}, dst={"system":"governance","policy":"default"}, replay={"seed":seed}, expect={"promote_rate_min":0.5}, metrics={"actual": metrics})
    out = save_snaphash(sh)
    publish("shells.gov.metrics", metrics)
    return out
