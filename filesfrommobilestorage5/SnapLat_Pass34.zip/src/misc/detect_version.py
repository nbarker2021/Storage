
import re, pathlib
from typing import Optional
VER_PAT = re.compile(r"[vV](\d{1,3})\b")
def find_version_from_name(name: str) -> Optional[int]:
    m = VER_PAT.search(name); return int(m.group(1)) if m else None
def path_version(p: pathlib.Path) -> Optional[int]:
    return find_version_from_name(str(p))
