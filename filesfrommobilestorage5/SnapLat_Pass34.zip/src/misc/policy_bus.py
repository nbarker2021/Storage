
from dataclasses import dataclass
from typing import Dict, Any, Optional, List

@dataclass
class PolicyDecision:
    allow: bool
    reason: str
    actions: Optional[List[str]] = None

def _subset_ok(values, allowlist):
    return not allowlist or (set(values) <= set(allowlist))

def _intersects(values, denylist):
    return bool(set(values) & set(denylist))

def check_policy(policies: Dict[str,Any], criteria: Dict[str,Any]) -> PolicyDecision:
    fam = criteria.get("family", [])
    typ = criteria.get("type", [])
    tags = criteria.get("tags", {})
    fam_allow = policies.get("family_allow", [])
    fam_deny  = policies.get("family_deny", [])
    typ_allow = policies.get("type_allow", [])
    typ_deny  = policies.get("type_deny", [])
    safe_cube = bool(policies.get("safe_cube", False))

    if _intersects(fam, fam_deny):
        return PolicyDecision(False, "family_denied", ["deny"])
    if not _subset_ok(fam, fam_allow) and fam:
        return PolicyDecision(False, "family_not_allowed", ["deny"])
    if _intersects(typ, typ_deny):
        return PolicyDecision(False, "type_denied", ["deny"])
    if not _subset_ok(typ, typ_allow) and typ:
        return PolicyDecision(False, "type_not_allowed", ["deny"])
    if safe_cube and not tags:
        return PolicyDecision(False, "safe_cube_requires_tags", ["deny"])
    return PolicyDecision(True, "ok")
