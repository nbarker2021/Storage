
from typing import Dict, List
from collections import defaultdict
from .families import families_for_text

from .entity_graph import build_entity_graph
from .bilayer_signals import bilayer_relation, relation_weight

def build_graph(nodes: List[Dict]) -> List[Dict]:
    edges: List[Dict] = []
    # parent-child edges
    for n in nodes:
        if n.get("parent"):
            rel, sc = bilayer_relation(n.get("raw_text",""), n.get("refined_text",""))
            edges.append({"src": n["parent"], "dst": n["id"], "type": "parent", "w": 0.1 + relation_weight(rel, sc)})
    # annotate families per node, then add cross-doc edges
    fam_index = defaultdict(list)
    for n in nodes:
        fams = families_for_text(n.get("title","") + "\n" + n.get("refined_text",""))
        n["families"] = fams
        for f in fams:
            fam_index[f].append(n["id"])
    for fam, ids in fam_index.items():
        L = len(ids)
        for i in range(L):
            for j in range(i+1, min(i+6, L)):
                # family edges get a small positive prior; bilayer from titles
                rel, sc = bilayer_relation(nodes[i-1].get("title",""), nodes[j-1].get("title","")) if i>0 and j>0 else ("ambiguous", 0.0)
                w = 0.05 + relation_weight(rel, sc)
                edges.append({"src": ids[i], "dst": ids[j], "type": f"fam:{fam}", "w": w})
                edges.append({"src": ids[j], "dst": ids[i], "type": f"fam:{fam}", "w": w})
    ent = build_entity_graph(nodes)
    # entity edges default small positive weight
    for e in ent['edges']:
        e.setdefault('w', 0.03)
        edges.append(e)
    return edges
