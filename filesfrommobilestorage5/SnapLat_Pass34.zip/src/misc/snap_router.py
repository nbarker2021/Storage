
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pathlib import Path
from typing import Dict, Any
from e8snap.validators import validate_snap
from e8snap.snap_writer import write_manifest, now_iso

# Simple in-memory counters; swap for Prometheus in your app
METRICS = {
    "snap_v2_write_total": 0,
    "snap_v2_validate_fail_total": 0,
}

router = APIRouter()

def path_for(manifest: Dict[str, Any]) -> Path:
    kind = manifest.get("kind","Run").lower()
    snap_id = manifest["snap_id"]
    return Path("snaps") / kind / f"{snap_id}.json"

@router.post("/snaps")
def create_snap(body: Dict[str, Any]) -> Dict[str, Any]:
    if "e8" not in body or "axes" not in body:
        raise HTTPException(400, "Missing required fields: e8, axes (E8-AS).")
    manifest = {
        "schema_version": "2.0",
        "snap_id": body["snap_id"],
        "created_at": body.get("created_at", now_iso()),
        "e8": body["e8"],
        "axes": body["axes"],
        "kind": body["kind"],
        "parent_id": body.get("parent_id"),
        "children": body.get("children", []),
        "hashes": body.get("hashes", {}),
        "payload": body.get("payload"),
        "provenance": body.get("provenance", {}),
        "security": {"allow_pickle": False, **body.get("security", {})},
        "metrics": body.get("metrics", {}),
        "notes": body.get("notes", ""),
    }
    try:
        validate_snap(manifest)
    except Exception as e:
        METRICS["snap_v2_validate_fail_total"] += 1
        raise HTTPException(400, f"Manifest validation failed: {e}")
    out = path_for(manifest)
    out.parent.mkdir(parents=True, exist_ok=True)
    write_manifest(manifest, out)
    METRICS["snap_v2_write_total"] += 1
    return {"ok": True, "snap_id": manifest["snap_id"], "path": str(out)}
