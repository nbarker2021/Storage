
from __future__ import annotations
import numpy as np
from typing import Dict, Any, Tuple, List
from lattice_ai.tests.goldens_recall_latency import synth_corpus, _cosine
from lattice_ai.hash.two_tier import TwoTierHash, build_houses

def run_grid(bits_list=(16,24,32,40), mods=(257,521,1021), K=10, seed=99) -> Dict[str, Any]:
    texts, X, labels = synth_corpus(seed=seed)
    results = []
    for bits in bits_list:
        for mod in mods:
            h = TwoTierHash.make(bits=bits, seed=seed)
            keys = h.house_keys(X)
            houses = build_houses(keys, mod=mod)
            # queries: one per topic
            q_idx = []
            for t in range(8):
                idx = [i for i,l in enumerate(labels) if l==t]
                q_idx.append(idx[len(idx)//2])
            Q = X[q_idx]
            rec_hits = 0; total=0; cand_counts=[]; ops=0
            for qi, q in enumerate(Q):
                b = int(h.house_keys(q.reshape(1,-1))[0] % mod)
                cand = houses.get(b, [])
                cand_counts.append(int(len(cand)))
                ops += 1 + len(cand) + K
                if len(cand)==0: continue
                sims = _cosine(q, X[cand]); order = np.argsort(-sims)
                truth = set(i for i,l in enumerate(labels) if l==labels[q_idx[qi]] and i!=q_idx[qi])
                topk = [int(cand[i]) for i in order[:K]]
                hits = sum(1 for i in topk if i in truth)
                rec_hits += 1 if hits>0 else 0
                total += 1
            results.append({"bits": bits, "mod": mod, "recall@1_nonzero": rec_hits/max(total,1),
                            "avg_cand": float(np.mean(cand_counts)), "p95_cand": float(np.percentile(cand_counts,95)),
                            "ops": ops})
    return {"_artifact":"golden_grid","data":{"results": results}}
