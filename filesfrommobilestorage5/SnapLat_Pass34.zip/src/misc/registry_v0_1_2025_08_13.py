
from typing import Dict, List, Optional
from .contracts_v0_1_2025_08_13 import AgentSpec_v0_1_2025_08_13
class AgentRegistry_v0_1_2025_08_13:
    def __init__(self):
        self._agents: Dict[str, AgentSpec_v0_1_2025_08_13] = {}
    def register(self, spec: AgentSpec_v0_1_2025_08_13):
        self._agents[spec.agent_id] = spec
    def get(self, agent_id: str) -> Optional[AgentSpec_v0_1_2025_08_13]:
        return self._agents.get(agent_id)
    def by_capability(self, cap_name: str) -> List[AgentSpec_v0_1_2025_08_13]:
        return [a for a in self._agents.values() if any(c.name==cap_name for c in a.capabilities)]
    def by_tag(self, tag: str) -> List[AgentSpec_v0_1_2025_08_13]:
        return [a for a in self._agents.values() if tag in a.tags]
    def all(self)->List[AgentSpec_v0_1_2025_08_13]:
        return list(self._agents.values())
