
from __future__ import annotations
from typing import Any, Dict
from lattice_ai.encode.e8_lattice import E8LatticeEncoder

def demo() -> Dict[str, Any]:
    enc = E8LatticeEncoder(salt="E8")
    enc.allocate_bank("docs", shape="E8:Shells", capacity=256)
    enc.allocate_bank("blobs", shape="E8:Bytes", capacity=128)
    texts = [
        "E8 lattice intro",
        "Routing with houses and shells",
        "Governance SAP arbiter",
        "Two-tier hashing with CMPLX",
        "Superpermutation constructor dry-run",
    ]
    res = enc.encode_texts(texts, bank="docs", k=3, shell_k=1)
    _ = enc.encode_bytes(b"binary-payload-01", bank="blobs", k=4, shell_k=2)
    snap_docs = enc.bank_snapshot("docs", limit=5)
    # Compute a simple coxeter span from snapshot sample if any
    cspan = None
    if snap_docs.get('sample'):
        # no stored coords in bank; we can only report count for now
        cspan = len(snap_docs.get('sample', []))
    return {
        "_artifact": "e8_encoder_demo",
        "data": {
            "vectors_shape": list(res["vectors"].shape),
            "first_vector": res["vectors"][0].tolist(),
            "docs_bank": snap_docs,
            "meta_sample": res["meta"][0],
        },
        "govern": {"coxeter_span_proxy": cspan},
        "_optimization_points": [
            "Hook real E8 geodesic distances and Coxeter coordinates into meta",
            "Cache root picks per hash to avoid recomputation under high QPS",
        ]
    }
