# Auto‑generated shim skeletons (names only; no implementations)
from __future__ import annotations

nan
