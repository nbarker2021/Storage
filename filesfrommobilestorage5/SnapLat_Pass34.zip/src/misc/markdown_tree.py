
import re
from typing import Dict, List, Optional
from pathlib import Path
from .refiner import refine_text

def parse_markdown_tree(path: Path) -> List[Dict]:
    """
    Parse a markdown file into a heading tree.
    Each node contains: id, doc, level, title, parent, position, raw_text, refined_text.
    """
    text = path.read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()
    nodes: List[Dict] = []
    stack: List[tuple] = []
    node_id = 0
    buf: List[str] = []
    cur: Optional[Dict] = None

    def flush_buf():
        nonlocal buf, cur
        if cur is not None:
            cur['raw_text'] = "\n".join(buf).strip()
            cur['refined_text'] = refine_text(cur['raw_text'])
            buf = []

    layout_regions = []
    for i, line in enumerate(lines, start=1):
        # naive layout capture for tables/images in markdown
        if line.strip().startswith('!['):
            layout_regions.append({'kind':'image','line': i})
        if '|' in line and line.count('|')>=2 and set(line.strip())-set('|-: '):
            layout_regions.append({'kind':'table','line': i})
        m = re.match(r'^(#{1,6})\s+(.*)', line)
        if m:
            flush_buf()
            level = len(m.group(1))
            title = m.group(2).strip()
            node_id += 1
            nid = f"{path.name}:{node_id}"
            parent = None
            while stack and stack[-1][0] >= level:
                stack.pop()
            if stack:
                parent = stack[-1][1]
            cur = {"id": nid, "doc": path.name, "level": level, "title": title, "parent": parent,
                   "position": i, "raw_text": "", "refined_text": ""}
            nodes.append(cur)
            stack.append((level, nid))
        else:
            if cur is None:
                node_id += 1
                nid = f"{path.name}:{node_id}"
                cur = {"id": nid, "doc": path.name, "level": 1, "title": "(preamble)", "parent": None,
                       "position": 1, "raw_text": "", "refined_text": ""}
                nodes.append(cur)
                stack = [(1, nid)]
            buf.append(line)
    flush_buf()
    # attach layout summary to the preamble node if exists
    if nodes:
        nodes[0]['layout_regions'] = layout_regions
    # sidecar VRDU: if a .layout.json exists beside the file, merge into nodes[0]
    sidecar = path.with_suffix(path.suffix + '.layout.json')
    if sidecar.exists():
        try:
            import json
            nodes[0]['vrdu_layout'] = json.loads(sidecar.read_text())
        except Exception:
            pass
    return nodes
