
import time
from typing import Dict, Any
def write_run_manifest(repo, *, component: str, params: Dict[str,Any], inputs: Dict[str,Any], policies: Dict[str,Any]) -> str:
    snap_id = f"manifest::{component}::{int(time.time())}"
    meta = {"snap_id": snap_id, "family": "manifest", "type": component, "created_ts": time.time(), "tags": {"component": component}}
    content = {"params": params, "inputs": inputs, "policies": policies}
    repo.save(snap_id, {"meta": meta, "content": content})
    return snap_id
