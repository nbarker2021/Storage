
from __future__ import annotations
import argparse, pathlib, importlib.util, numpy as np, json, sys

def load_mod(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

def check(geo_dir: pathlib.Path):
    e8r = load_mod("e8_roots", geo_dir/"e8_roots.py")
    e8 = load_mod("e8", geo_dir/"e8.py")
    R = e8r.generate_e8_roots()
    ok_shape = tuple(R.shape)==(240,8)
    norms = np.sum(R*R, axis=1)
    ok_norm = np.allclose(norms, 2.0)
    g = e8.E8Geometry(); r0=R[0]; V=R[:5]
    Vr=g.reflect(V,r0); Vb=g.reflect(Vr,r0)
    ok_refl = np.allclose(V,Vb)
    return {"root_shape_ok":bool(ok_shape),"norms_ok":bool(ok_norm),"reflect_involution_ok":bool(ok_refl)}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); args = ap.parse_args()
    root = pathlib.Path(args.root).resolve()
    geo_dir = root/"canonical_v14"/"lattice_ai"/"geometry"
    if not (geo_dir/"e8_roots.py").exists():
        print("[err] no canonical geometry at", geo_dir); sys.exit(1)
    rep = check(geo_dir); print(json.dumps(rep, indent=2)); 
    sys.exit(0 if all(rep.values()) else 2)
if __name__ == "__main__": main()
