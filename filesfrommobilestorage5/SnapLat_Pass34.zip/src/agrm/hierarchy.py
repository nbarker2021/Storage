
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional, Callable
import math, time
from agrm.policy.policy_bus import check_policy

RoomID = Tuple[int,int,int]  # (building, floor, room)

@dataclass
class Room:
    id: RoomID
    indices: List[int] = field(default_factory=list)
    heat: float = 0.0
    tags: Dict[str,Any] = field(default_factory=dict)  # dominant glyph, family/type, etc.

@dataclass
class Floor:
    building: int
    level: int
    rooms: List[Room] = field(default_factory=list)

@dataclass
class Building:
    id: int
    floors: List[Floor] = field(default_factory=list)

@dataclass
class HierarchyParams:
    room_capacity: int = 64
    max_rooms_per_floor: int = 8
    heat_split_threshold: float = 128.0
    elevator_cross_floor_threshold: float = 12.0
    elevator_cross_room_threshold: float = 18.0
    decay_half_life_hours: float = 24.0  # decay for room heat
    policy_for_split: Dict[str,Any] = None  # PolicyBus-compatible policy dict
    promote_elevators: bool = False
    elevator_score_min: float = 0.5  # min score to emit candidate

class HierarchyManager:
    def __init__(self, params: HierarchyParams | None = None):
        self.params = params or HierarchyParams()
        self.buildings: List[Building] = []
        self.index_room: Dict[int, RoomID] = {}
        self.elevators: List[Tuple[RoomID, RoomID]] = []
        self.elevator_scores: Dict[Tuple[RoomID,RoomID], float] = {}
        self.events: List[Dict[str,Any]] = []
        self.last_ts: float = time.time()

    # ---------- construction ----------
    def build_initial(self, N: int):
        cap = max(1, int(self.params.room_capacity))
        b = Building(id=0, floors=[Floor(building=0, level=0, rooms=[])])
        rcount = math.ceil(N / cap)
        idx = 0
        for r in range(rcount):
            take = list(range(idx, min(N, idx+cap)))
            rid = (0,0,r)
            room = Room(id=rid, indices=take, heat=0.0, tags={})
            b.floors[0].rooms.append(room)
            for i in take:
                self.index_room[i] = rid
            idx += len(take)
        self.buildings = [b]
        self.events.append({"event":"build_initial","rooms": rcount,"N":N})
        self.last_ts = time.time()

    def _ranges_from_indices(self, indices: List[int]) -> List[List[int]]:
        if not indices: return []
        seq = sorted(set(indices))
        ranges = []
        start = seq[0]; prev = seq[0]
        for v in seq[1:]:
            if v == prev + 1:
                prev = v
                continue
            ranges.append([start, prev])
            start = prev = v
        ranges.append([start, prev])
        return ranges

    def _indices_from_ranges(self, ranges: List[List[int]]) -> List[int]:
        out = []
        for a,b in ranges or []:
            out.extend(list(range(int(a), int(b)+1)))
        return out

    def rebuild_from_snapshot(self, snap: Dict[str,Any]):
        self.buildings = []
        self.index_room = {}
        self.elevators = snap.get("elevators", [])
        self.elevator_scores = {}
        b = Building(id=0, floors=[])
        floors_map: Dict[int, Floor] = {}
        # rebuild rooms with membership
        for rrec in snap.get("rooms", []):
            bid, fl, rm = rrec["id"]
            flr = floors_map.get(fl)
            if flr is None:
                flr = Floor(building=0, level=fl, rooms=[])
                floors_map[fl] = flr
            members = rrec.get("members", {})
            indices = []
            if "ranges" in members:
                indices = self._indices_from_ranges(members["ranges"])
            elif "list" in members:
                indices = [int(x) for x in members["list"]]
            else:
                # fallback: allocate placeholder of 'size'
                indices = [-1] * int(rrec.get("size", 0))
            room = Room(id=(0, fl, rm), indices=indices, heat=float(rrec.get("heat",0.0)), tags=rrec.get("tags",{}))
            flr.rooms.append(room)
            for i in indices:
                if i >= 0:
                    self.index_room[i] = room.id
        b.floors = [floors_map[k] for k in sorted(floors_map.keys())]
        self.buildings = [b]
        self.events.append({"event":"rebuild_from_snapshot","ts": time.time()})

    def snapshot(self) -> Dict[str,Any]:
        floors = []
        rooms = []
        for b in self.buildings:
            for f in b.floors:
                floors.append({"building": b.id, "floor": f.level, "rooms": len(f.rooms)})
                for r in f.rooms:
                    rooms.append({"id": r.id,
                                  "size": len(r.indices),
                                  "heat": r.heat,
                                  "tags": r.tags,
                                  "members": {"ranges": self._ranges_from_indices(r.indices)}})
        return {"floors": floors, "rooms": rooms, "elevators": [(a,b) for a,b in self.elevators], "events": list(self.events)}

    # ---------- tagging ----------
    def tag_rooms_from_metas(self, metas: List[Dict[str,Any]], *, three_words_fn: Optional[Callable[[Dict[str,Any]], List[str]]] = None):
        def default_three(meta: Dict[str,Any]) -> List[str]:
            from agrm.shelling.engine import shell, to_three_words
            levels = shell(meta, max_n=3)
            return to_three_words(levels[-1])
        get_three = three_words_fn or default_three
        for b in self.buildings:
            for f in b.floors:
                for r in f.rooms:
                    fam_counts = {}
                    typ_counts = {}
                    bag = {}
                    for i in [ix for ix in r.indices if 0 <= ix < len(metas)]:
                        m = metas[i]
                        fam = m.get("family")
                        typ = m.get("type")
                        if fam: fam_counts[fam] = fam_counts.get(fam,0)+1
                        if typ: typ_counts[typ] = typ_counts.get(typ,0)+1
                        words = get_three(m)
                        for w in words:
                            bag[w] = bag.get(w,0)+1
                    fam = max(fam_counts, key=fam_counts.get) if fam_counts else None
                    typ = max(typ_counts, key=typ_counts.get) if typ_counts else None
                    glyph = "::".join([w for w,_ in sorted(bag.items(), key=lambda kv: -kv[1])][:3]) if bag else None
                    r.tags.update({"family": fam, "type": typ, "glyph": glyph})

    # ---------- heat & updates ----------
    def _decay_factor(self, now: float) -> float:
        hl = max(0.1, float(self.params.decay_half_life_hours))
        dt_h = max(0.0, (now - self.last_ts) / 3600.0)
        return 0.5 ** (dt_h / hl)

    def apply_heat(self, heat_snapshot: Dict[str,Dict], *, policies: Optional[Dict[str,Any]] = None):
        now = time.time()
        decay = self._decay_factor(now)
        for b in self.buildings:
            for f in b.floors:
                for r in f.rooms:
                    r.heat *= decay

        edges_raw = heat_snapshot.get("edges", {})
        edges: Dict[Tuple[int,int], int] = {}
        if edges_raw and isinstance(next(iter(edges_raw)), str):
            for k,v in edges_raw.items():
                try:
                    a,b = k.strip("()").split(",")
                    edges[(int(a), int(b))] = int(v)
                except Exception:
                    continue
        else:
            edges = {tuple(map(int,k)): int(v) for k,v in edges_raw.items()}

        for (a,b), w in edges.items():
            ra = self.index_room.get(a)
            rb = self.index_room.get(b)
            if ra: self._room_by_id(ra).heat += w
            if rb and rb != ra: self._room_by_id(rb).heat += w

        cross_count: Dict[Tuple[RoomID, RoomID], float] = {}
        for (a,b), w in edges.items():
            ra = self.index_room.get(a)
            rb = self.index_room.get(b)
            if not ra or not rb or ra == rb: continue
            key = (ra, rb) if ra < rb else (rb, ra)
            size_a = len(self._room_by_id(ra).indices) or 1
            size_b = len(self._room_by_id(rb).indices) or 1
            norm = w / math.sqrt(size_a * size_b)
            cross_count[key] = cross_count.get(key, 0.0) + norm

        for pair, val in cross_count.items():
            prev = self.elevator_scores.get(pair, 0.0) * decay
            self.elevator_scores[pair] = prev + val

        for pair, score in list(self.elevator_scores.items()):
            a,b = pair
            af, bf = a[1], b[1]
            thresh = self.params.elevator_cross_floor_threshold if af != bf else self.params.elevator_cross_room_threshold
            if score >= thresh:
                self._add_elevator(a,b,score, reason="score_threshold")

        for b in self.buildings:
            for f in b.floors:
                new_rooms: List[Room] = []
                for room in list(f.rooms):
                    need_split = (room.heat >= self.params.heat_split_threshold) or (len(room.indices) > self.params.room_capacity)
                    if not need_split: 
                        continue
                    pol = policies or self.params.policy_for_split or {}
                    crit = {"family": [room.tags.get("family")] if room.tags.get("family") else [],
                            "type": [room.tags.get("type")] if room.tags.get("type") else [],
                            "tags": {"room_hot_gt": room.heat}}
                    dec = check_policy(pol, crit)
                    if not dec.allow:
                        self.events.append({"event":"room_split_blocked","room": room.id, "reason": dec.reason})
                        continue
                    half = max(1, len(room.indices)//2)
                    left = room.indices[:half]
                    right = room.indices[half:]
                    f.rooms.remove(room)
                    next_rid = max([r.id[2] for r in f.rooms], default=-1) + 1
                    rida = (b.id, f.level, next_rid)
                    ridb = (b.id, f.level, next_rid + 1)
                    ra = Room(id=rida, indices=left, heat=room.heat*0.5, tags=room.tags.copy())
                    rb = Room(id=ridb, indices=right, heat=room.heat*0.5, tags=room.tags.copy())
                    new_rooms.extend([ra, rb])
                    for i in left: self.index_room[i] = rida
                    for i in right: self.index_room[i] = ridb
                    self.events.append({"event":"room_split","from":room.id,"to":[rida,ridb],"reason":"heat_or_size"})
                f.rooms.extend(new_rooms)
                while len(f.rooms) > self.params.max_rooms_per_floor:
                    move = f.rooms[self.params.max_rooms_per_floor:]
                    f.rooms = f.rooms[:self.params.max_rooms_per_floor]
                    nf = Floor(building=b.id, level=f.level+1, rooms=[])
                    for r in move:
                        rid = (b.id, nf.level, r.id[2])
                        nf.rooms.append(Room(id=rid, indices=r.indices, heat=r.heat, tags=r.tags.copy()))
                        for i in r.indices: self.index_room[i] = rid
                    b.floors.append(nf)
                    self.events.append({"event":"floor_split","from":f.level,"to":nf.level,"moved_rooms":len(move)})
        self.last_ts = now

    # ---------- helpers ----------
    def _room_by_id(self, rid: RoomID) -> Room:
        b = self.buildings[rid[0]]
        for f in b.floors:
            if f.level == rid[1]:
                for r in f.rooms:
                    if r.id == rid:
                        return r
        raise KeyError(rid)

    def _add_elevator(self, a: RoomID, b: RoomID, score: float, reason: str):
        pair = (a,b) if a < b else (b,a)
        if pair not in self.elevators:
            self.elevators.append(pair)
            self.events.append({"event":"elevator","a":a,"b":b,"score":score,"reason":reason})
