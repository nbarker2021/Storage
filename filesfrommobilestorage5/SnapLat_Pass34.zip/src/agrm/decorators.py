
import time, functools
from typing import Callable
from agrm.snapcore.emitter import get_emitter

def instrument(family: str, type_: str, *, universe_key: str="universe"):
    def deco(fn: Callable):
        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            repo = kwargs.get("repo") or kwargs.get("repository") or kwargs.get("repo_obj")
            um = kwargs.get("um") or kwargs.get("universe_manager") or kwargs.get("um_obj")
            universe = kwargs.get(universe_key, "Global")
            em = get_emitter(repo, um)
            sid_start = em.emit(universe=universe, family=family, type_=f"{type_}.start",
                                content={"fn": fn.__name__}, tags={"universe": universe})
            t0 = time.time()
            try:
                out = fn(*args, **kwargs)
                dt = (time.time()-t0)*1000.0
                em.emit(universe=universe, family=family, type_=f"{type_}.success",
                        content={"fn": fn.__name__, "dt_ms": dt}, tags={"universe": universe}, parents=[sid_start] if sid_start else [])
                return out
            except Exception as e:
                dt = (time.time()-t0)*1000.0
                em.emit(universe=universe, family=family, type_=f"{type_}.error",
                        content={"fn": fn.__name__, "dt_ms": dt, "err": str(e)}, tags={"universe": universe}, parents=[sid_start] if sid_start else [])
                raise
        return wrapped
    return deco
