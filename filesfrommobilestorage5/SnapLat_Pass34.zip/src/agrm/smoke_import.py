
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
from agrm.universe.manager import UniverseManager, UniverseSpec
from agrm.mannequin.lattice import LatticeMannequinV2
print("OK: imports")
