
#!/usr/bin/env python3
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
import argparse, json
from importlib import import_module
from agrm.orchestrator.freshstart import fresh_start
from agrm.orchestrator.iterate import run_iterations

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--universe", required=True)
    ap.add_argument("--max-iters", type=int, default=5)
    ap.add_argument("--min-promoted", type=int, default=1)
    ap.add_argument("--stability-eps", type=float, default=0.05)
    ap.add_argument("--threshold", type=float, default=None)
    ap.add_argument("--wipe", action="store_true")
    ns = ap.parse_args()

    repo = import_module("env.repo").repo
    um   = import_module("env.um").um
    data = import_module("env.data")  # must expose points, metas, cfg

    if ns.wipe:
        fresh = fresh_start(repo, um, ns.universe, wipe=True)
        print(json.dumps({"freshstart": fresh}, indent=2))

    report = run_iterations(data.points, data.metas, repo=repo, um=um, base_cfg=data.cfg,
                            universe=ns.universe, max_iters=ns.max_iters,
                            min_promoted=ns.min_promoted, stability_eps=ns.stability_eps,
                            promotion_threshold=ns.threshold, compat_policy={"family_deny":["fiction"]})
    print(json.dumps({"delivered": report.delivered, "reason": report.reason}, indent=2))

if __name__ == "__main__":
    main()
