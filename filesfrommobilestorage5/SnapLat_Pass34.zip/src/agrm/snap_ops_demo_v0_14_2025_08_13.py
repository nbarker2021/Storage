
import sys, json, time
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from agrm.archivist.repository import Repository, Archivist, MetaIndexBridge
from agrm.universe.manager import UniverseManager, UniverseSpec
from agrm.mannequin.lattice import LatticeMannequinV2
from agrm.snap.ops_center import SnapOpsCenter

REPO = '/mnt/data/repository_store_v0_1_2025_08_13'
REG  = '/mnt/data/universe_registry_v0_1_2025_08_13'
DB   = '/mnt/data/agrm_meta.duckdb'

def seed(repo):
    if not repo.list():
        for i in range(20):
            sid = f'demo-culture-creative-{int(time.time())}-{i}'
            meta = {"snap_id": sid, "family":"culture","type":"creative","created_ts": time.time(), "tags":{"snap_score":0.55 + 0.02*i}}
            repo.save(sid, {"meta":meta, "content":{}})

def run():
    repo = Repository(REPO); arch=Archivist(repo); idx=MetaIndexBridge(DB)
    seed(repo)
    um = UniverseManager(REPO, REG)
    if 'OpsUniverse' not in um.list_universes():
        um.create_universe(UniverseSpec(name='OpsUniverse', selectors={"family":["culture"],"type":["creative"]}))
    # Activate a slice to create a slice SNAP
    m = LatticeMannequinV2('OpsUniverse', repo_root=REPO, registry_root=REG)
    m.build_manifest(); m.toggle(on=True)
    stream, gate = m.activate_stream(criteria={"family":["culture"],"type":["creative"], "tags":{"snap_score_gt":0.6}}, wave_size=5)
    slice_id = None
    if stream:
        sh = next(iter(stream))
        slice_id = m.save_slice_snap(sh)
    # Index all metas (light pass)
    metas = [repo.load(s)["meta"] for s in repo.list()[:200]]
    idx.bulk_upsert(metas)
    # Ops evaluate
    ops = SnapOpsCenter(repo, arch)
    res = ops.assess_slice_against_universe(slice_id, um.get_universe('OpsUniverse').snaps) if slice_id else {"error":"no_slice"}
    return {"gate": gate, "slice": slice_id, "ops": res, "duckdb_candidates": idx.query(family="culture", typ="creative")[:5]}

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
