"""M1 Sandbox: MDHG wrapper
- Exposes contract surfaces and emits Trails events.
- Attempts to call a legacy winner module if present (best-of staging),
  otherwise falls back to a tiny, deterministic toy implementation.
- No edits to legacy code; this is an adapter.
"""
from __future__ import annotations
from typing import Any, Dict, Sequence, Tuple, List, Optional
import importlib.util, sys
from trails import api as trails
import os
from typing import Mapping

def _parse_yaml_like(path: str) -> dict:
    d: dict = {"weights":{}, "thresholds":{}}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            section = None
            for raw in f:
                line = raw.strip()
                if not line or line.startswith('#'):
                    continue
                if line.endswith(':') and not ':' in line[:-1]:
                    section = line[:-1]
                    if section not in d:
                        d[section] = {}
                    continue
                if ':' in line and section:
                    k, v = [t.strip() for t in line.split(':', 1)]
                    try:
                        d[section][k] = float(v)
                    except Exception:
                        d[section][k] = v
        return d
    except Exception:
        return {"weights":{}, "thresholds":{}}

def _load_scoring_config() -> Mapping[str, float]:
    path = os.environ.get('SNAPLAT_SCORING_CONFIG', '/mnt/data/_repo_snaplat/PLANS/mdhg_scoring.yaml')
    cfg = _parse_yaml_like(path)
    weights = cfg.get('weights', {}) or {}
    return {
        'w_w5h': float(weights.get('w_w5h', 0.40)),
        'w_hot': float(weights.get('w_hot', 0.25)),
        'w_neg': float(weights.get('w_neg', 0.20)),
        'w_bridge': float(weights.get('w_bridge', 0.15)),
    }


# Optional legacy entrypoint (set to your staged winner module path if available)
_LEGACY_SPEC = None  # type: ignore

def _load_legacy():
    global _LEGACY_SPEC
    if _LEGACY_SPEC is not None:
        return _LEGACY_SPEC
    # Attempt dynamic discovery: look for 'legacy_mdhg.py' placed by integrators (opt-in)
    # We avoid importing arbitrary staged modules to prevent side effects in the sandbox.
    return None

# ---- Toy fallback implementations (deterministic) ----
def _toy_points(universe: Any) -> List[Dict[str, Any]]:
    # Accepts dicts or lists; produces a tiny set of labeled points
    pts: List[Dict[str, Any]] = []
    if isinstance(universe, dict):
        for i, (k, v) in enumerate(sorted(universe.items())):
            pts.append({"id": f"p{i}", "key": str(k), "val": v})
    elif isinstance(universe, (list, tuple)):
        for i, v in enumerate(universe):
            pts.append({"id": f"p{i}", "val": v})
    else:
        pts = [{"id":"p0","val":str(universe)}]
    return pts

def _toy_graph(points: Sequence[Dict[str, Any]], *, quotas: Optional[Dict[str, int]] = None) -> Tuple[List[Any], List[Tuple[Any, Any, Dict[str, Any]]]]:
    nodes = [p["id"] for p in points]
    edges: List[Tuple[Any, Any, Dict[str, Any]]] = []
    # Chain edges p0->p1->...; limit by quotas.get('edges', ...)
    max_edges = quotas.get('edges', len(nodes)-1) if quotas else len(nodes)-1
    for i in range(min(len(nodes)-1, max_edges)):
        edges.append((nodes[i], nodes[i+1], {"w": 1.0}))
    return nodes, edges

from agrm.snap.w5h import compute_w5h_alignment
from agrm.snap.beacons import get_registry
def _toy_promotion_breakdown(record: Dict[str, Any]) -> Dict[str, Any]:
        use_cfg = os.environ.get('SNAPLAT_USE_SCORING_CONFIG', '0') == '1'
        weights = _load_scoring_config() if use_cfg else {'w_w5h':0.40,'w_hot':0.25,'w_neg':0.20,'w_bridge':0.15}
    # Simple scoring using presence of features (placeholder for M1)
    score = 0.0
    if record.get("hot", False): score += 0.25
    if record.get("bridge_conf", 0) > 0: score += 0.15
    if record.get("w5h", 0) > 0: score += 0.40
    if record.get("neg_penalty", 0) > 0: score -= min(0.20, float(record.get("neg_penalty",0)))
    return {
        "components": {
            "w5h": float(record.get("w5h",0)),
            "hot": 1.0 if record.get("hot", False) else 0.0,
            "neg": float(record.get("neg_penalty",0)),
            "bridge": float(record.get("bridge_conf",0))
        },
        "score": max(0.0, min(1.0, score))
    }

# ---- Public contract surfaces (emit Trails, then delegate) ----
def to_points(universe: Any) -> List[Dict[str, Any]]:
    tid = trails.begin_trail({"op":"mdhg.to_points","module":__name__})
    try:
        spec = _load_legacy()
        if spec is not None:
            m = importlib.util.module_from_spec(spec)  # type: ignore
            spec.loader.exec_module(m)  # type: ignore
            pts = m.to_points(universe)  # type: ignore[attr-defined]
        else:
            pts = _toy_points(universe)
        trails.append_event(tid, {"op":"mdhg.to_points","delta":"points","count":len(pts)})
        return pts
    finally:
        trails.finalize(tid, {"op":"mdhg.to_points","status":"ok"})

def to_graph(points: Sequence[Dict[str, Any]], *, quotas: Optional[Dict[str, int]] = None):
    tid = trails.begin_trail({"op":"mdhg.to_graph","module":__name__})
    try:
        spec = _load_legacy()
        if spec is not None:
            m = importlib.util.module_from_spec(spec)  # type: ignore
            spec.loader.exec_module(m)  # type: ignore
            nodes, edges = m.to_graph(points, quotas=quotas)  # type: ignore[attr-defined]
        else:
            nodes, edges = _toy_graph(points, quotas=quotas)
        trails.append_event(tid, {"op":"mdhg.to_graph","delta":"graph","nodes":len(nodes),"edges":len(edges)})
        return nodes, edges
    finally:
        trails.finalize(tid, {"op":"mdhg.to_graph","status":"ok"})

def promotion_breakdown(record: Dict[str, Any]) -> Dict[str, Any]:
    tid = trails.begin_trail({"op":"mdhg.promotion_breakdown","module":__name__})
    try:
        spec = _load_legacy()
        if spec is not None:
            m = importlib.util.module_from_spec(spec)  # type: ignore
            spec.loader.exec_module(m)  # type: ignore
            out = m.promotion_breakdown(record)  # type: ignore[attr-defined]
        else:
            out = _toy_promotion_breakdown(record)
        trails.append_event(tid, {"op":"mdhg.promotion_breakdown","delta":"score","score":out.get("score",0)})
        return out
    finally:
        trails.finalize(tid, {"op":"mdhg.promotion_breakdown","status":"ok"})
