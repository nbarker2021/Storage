
from typing import Dict, Any, List
import numpy as np, math
from agrm.mdhg.hotmap import HotMap

def plan_arms(points: np.ndarray, x:int=8) -> Dict[str,Any]:
    if points.size == 0:
        return {"centroid": [0,0], "arms": []}
    C = points.mean(axis=0)
    V = points - C
    ang = np.arctan2(V[:,1], V[:,0]) if points.shape[1]>=2 else np.zeros(points.shape[0])
    buckets = np.linspace(-math.pi, math.pi, x+1)
    arms = []
    for i in range(x):
        mask = (ang >= buckets[i]) & (ang < buckets[i+1])
        idx = np.where(mask)[0].tolist()
        arms.append({"arm": i, "count": len(idx), "indices": idx})
    return {"centroid": C.tolist(), "arms": arms}

def simulate_sweeps(points: np.ndarray, *, rounds:int=2, x:int=8) -> Dict[str,Any]:
    if points.size == 0:
        return {"rounds": 0, "arms": [], "heat": {"edges":{}, "rooms":{}}}
    C = points.mean(axis=0)
    V = points - C
    ang = np.arctan2(V[:,1], V[:,0]) if points.shape[1]>=2 else np.zeros(points.shape[0])
    rad = np.linalg.norm(V[:, :2], axis=1) if points.shape[1]>=2 else np.abs(V[:,0])
    hot = HotMap()
    buckets = np.linspace(-math.pi, math.pi, x+1)
    arms_stats: List[Dict[str,Any]] = []
    for r in range(rounds):
        arm_counts = []
        for i in range(x):
            mask = (ang >= buckets[i]) & (ang < buckets[i+1])
            idx = np.where(mask)[0]
            seq = idx[np.argsort(rad[idx])].tolist()
            for a,b in zip(seq[:-1], seq[1:]):
                hot.bump_edge(int(a), int(b), 1)
            arm_counts.append({"arm": i, "count": len(seq)})
        arms_stats.append({"round": r+1, "counts": arm_counts})
        imb = [c["count"] for c in arm_counts]
        if max(imb) - min(imb) > 1:
            shift = 0.01
            buckets = buckets + shift
    return {"rounds": rounds, "centroid": C.tolist(), "arms": arms_stats, "heat": hot.snapshot()}
