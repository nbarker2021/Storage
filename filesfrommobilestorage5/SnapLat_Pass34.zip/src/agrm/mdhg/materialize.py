
from typing import Dict, Any, Optional, Tuple
import numpy as np
from .manager import UniverseManager, UniverseSpec
from ..mannequin.lattice import LatticeMannequinV2 as Mannequin
from ..mdhg.adjacency import build_adjacency, build_elevators

def to_points(universe_name: str, *, repo_root:str, registry_root:str,
              criteria: Dict[str, Any], wave_size:int=256, max_nodes:int=None) -> Tuple[np.ndarray, Dict[str,Any]]:
    m = Mannequin(universe_name, repo_root=repo_root, registry_root=registry_root)
    m.build_manifest(); m.toggle(on=True)
    stream, gate = m.activate_stream(criteria, wave_size=wave_size, max_nodes=max_nodes)
    if stream is None:
        m.toggle(on=False)
        return np.zeros((0,8)), {"gate":gate, "count":0}
    coords_list=[]
    total=0
    for sh in stream:
        coords_list.append(np.array(sh.coords, dtype=float))
        total += sh.budget_used
    m.toggle(on=False)
    if coords_list:
        X = np.vstack(coords_list)
    else:
        X = np.zeros((0,8))
    return X, {"gate":gate, "count":int(total)}

def to_graph(universe_name: str, *, repo_root:str, registry_root:str,
             criteria: Dict[str, Any], adj_k:int=8, adj_buckets:int=64, adj_backend:str='grid',
             wave_size:int=256, max_nodes:int=None, elevators_quota:int=0) -> Tuple[Dict[str,Any], Dict[str,Any]]:
    X, meta = to_points(universe_name, repo_root=repo_root, registry_root=registry_root, criteria=criteria,
                        wave_size=wave_size, max_nodes=max_nodes)
    if X.shape[0] == 0:
        return {"N":0,"edges":[]}, meta
    adj = build_adjacency(X, k=adj_k, buckets=adj_buckets, backend=adj_backend)
    elev = build_elevators(X, adj, quota=elevators_quota)
    g = {"N": adj["N"], "edges": adj["edges"], "elevators": elev["elevators"]}
    return g, meta
