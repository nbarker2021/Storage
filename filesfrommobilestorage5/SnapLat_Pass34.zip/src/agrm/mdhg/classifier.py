
import re
from typing import Dict, List
from pathlib import Path

CODEY = re.compile(r"[{};]|^\s*#|^\s*//|^\s*/\*|^\s*\*|^\s*import\s|\bdef\s|\bclass\s|\bfunction\s|\breturn\b|\bconsole\.|^\s*if\s*\(|=>|::")
HEAD = re.compile(r'^\s*#{1,6}\s+\S')
BULLET = re.compile(r'^\s*(?:[-*+]|[0-9]{1,2}\.)\s+')
JSON_KEY = re.compile(r'^\s*"[A-Za-z0-9_\- .]+"\s*:\s*')
NORM_ANCHOR = re.compile(r"\b(must|shall|should|never|forbidden|cannot|can\s+not|required|always)\b", re.I)

def file_features(path: Path) -> Dict:
    text = path.read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()
    n = len(lines) or 1
    def ratio(rx): return sum(1 for ln in lines if rx.search(ln)) / n
    feats = {
        "codey_ratio": ratio(CODEY),
        "heading_ratio": ratio(HEAD),
        "bullet_ratio": ratio(BULLET),
        "jsonkey_ratio": ratio(JSON_KEY),
        "normative_ratio": sum(1 for ln in lines if NORM_ANCHOR.search(ln) and not CODEY.search(ln)) / n
    }
    return feats

def guess_role_universe(path: Path, feats: Dict) -> Dict:
    name = path.name.lower()
    uni = "UNK"; role = "other"
    if "document" in name or "docuniverse" in name: uni = "DU"
    if "operational" in name or "ledger_operational" in name: uni = "OU"
    if "governance" in name or "policy" in name or "boundary" in name or "ci_" in name: uni = "GU"
    if "user" in name: uni = "UU"
    if "manifest" in name: role = "manifest"
    elif "ledger" in name or "events" in name or "mdhg" in name: role = "ledger"
    elif "policy" in name or "boundary" in name: role = "policy"
    elif "ci" in name or "reconciliation" in name: role = "ci_report"
    elif any(k in name for k in ["familygraph","interaction","morsr","bilayer","glyphpack","bilayer_deltas","sentpmi","lineledger"]):
        role = "analysis_artifact"
    elif path.suffix.lower() in [".py",".js",".ts",".tsx",".c",".cpp",".h",".hpp",".go",".rs",".rb",".sh"] or feats["codey_ratio"]>0.15:
        role = "code"
    elif feats["jsonkey_ratio"]>0.2 and path.suffix.lower() in [".json",".json5"]:
        role = "config"
    elif feats["heading_ratio"]>0.02 and path.suffix.lower() in [".md",".rst",".txt"]:
        role = "prose_guide"
    elif "log" in name or "session" in name or "chat" in name:
        role = "log"
    norm_weight = "LOW"
    if role in ("policy","ci_report"): norm_weight = "HIGH"
    elif role in ("analysis_artifact","prose_guide"): norm_weight = "MEDIUM"
    return {"universe": uni, "role": role, "normative_weight": norm_weight, "features": feats}
