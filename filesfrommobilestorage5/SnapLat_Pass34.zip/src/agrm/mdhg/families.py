
from typing import List, Set

FAMILIES = {
    "AGRM": ["agrm","argm"],
    "CMPLX": ["cmplx"],
    "SUPERPERMUTATION": ["superpermutation","superperm"],
    "E8": ["e8","lattice"],
    "MORSR": ["morsr","middle out","ripple","subripple"],
    "SNAP": ["snap","snapdna"],
    "MDHG": ["mdhg"],
    "BILAYER": ["bilayer","anti-space","dual","anti space","anti"],
    "GLYPH": ["glyph","n=-1","glyphic index"],
    "SAFE": ["safe cube","now anchor","anchor","pinning"],
    "SELC": ["selc","shell extension logic controller"],
    "CI": ["ci","threshold","gate","gating","reconciliation"],
    "POLICY": ["policy","governance","boundary"],
    "LEDGER": ["ledger","provenance","build id","events"],
}

def families_for_text(s: str) -> List[str]:
    sL = s.lower()
    tags: Set[str] = set()
    for fam, keys in FAMILIES.items():
        if any(k in sL for k in keys):
            tags.add(fam)
    return sorted(tags)


def gazetteer_terms():
    """Return a flat set of lowercase gazetteer terms for entity matching."""
    terms = set()
    for _, keys in FAMILIES.items():
        for k in keys:
            terms.add(k.lower())
    return terms
