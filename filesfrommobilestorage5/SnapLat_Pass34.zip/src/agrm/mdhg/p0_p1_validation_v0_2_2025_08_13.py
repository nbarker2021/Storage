import sys, os
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

import numpy as np, time
from core.infra.journal_v0_1_2025_08_13 import Journal_v0_1_2025_08_13 as Journal
from core.mdhg.vws_bridge_v0_2_2025_08_13 import seed_vws_from_mdhg
from core.mdhg.adjacency_v0_1_2025_08_13 import build_adjacency, build_elevators
from core.agrm.promotion_guard_v0_1_2025_08_13 import adjust_sampling_cfg

def run():
    j = Journal()
    rng = np.random.default_rng(7)

    for N in [1500, 3000, 6000]:
        pts = rng.random((N, 2))
        # Seeding (grid) with guard
        t0=time.time()
        res = seed_vws_from_mdhg(pts, strategy="grid", grid_size=64, force_grid=True, N_guard=4000, journal=j)
        t1=time.time()
        # Try illegal path at large N and catch
        illegal = None
        if N>=4000:
            try:
                seed_vws_from_mdhg(pts, strategy="exact", force_grid=True, N_guard=4000, journal=j)
            except Exception as e:
                illegal = str(e)[:80]
        # Build adjacency and elevators to show scale
        adj = build_adjacency(pts, k=8, buckets=64)
        elv = build_elevators(pts, adj, quota= pts.shape[0]//20)

        print(f"N={N} | seed picks={len(res['indices'])} in {t1-t0:.3f}s | illegal='{illegal}' | avg_degree~{adj['avg_degree']:.2f} | elevators={elv['count']}")
    return j.dump()

if __name__ == "__main__":
    run()
