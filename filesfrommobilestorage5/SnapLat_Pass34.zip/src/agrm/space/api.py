from __future__ import annotations
from typing import Any, Dict, List, Tuple
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class Universe:
    name: str
    hemispheres: List[str]

@dataclass
class Lattice:
    name: str
    dim: int = 8  # E8 default placeholder

    def weyl_index(self, point: Tuple[float, float]) -> int:
        """Deterministic stub: hash a 2D point into 0..7.

        (For now: 4 quadrants × 2 parity buckets.)
        """
        x, y = float(point[0]), float(point[1])
        quad = 0
        if x < 0.5 and y >= 0.5: quad = 1   # NW
        elif x < 0.5 and y < 0.5: quad = 2  # SW
        elif x >= 0.5 and y < 0.5: quad = 3 # SE
        # parity by triangle split across diagonal
        parity = 1 if (x + y) >= 1.0 else 0
        idx = (quad * 2 + parity) % 8
        return idx

_DEFAULT_UNIVERSE: Universe | None = Universe(name="default", hemispheres=["NW","NE","SW","SE"])

def get_default_universe() -> Universe:
    return _DEFAULT_UNIVERSE

def set_default_universe(u: Universe) -> None:
    global _DEFAULT_UNIVERSE
    _DEFAULT_UNIVERSE = u

def tag_points(universe: Universe | None, coords: List[Tuple[float, float]]) -> List[str]:
    """Assign hemisphere tags by simple 2D quadrant mapping (NW/NE/SW/SE)."""
    u = universe or _DEFAULT_UNIVERSE
    tags: List[str] = []
    if u is None or not u.hemispheres:
        return [""] * len(coords)
    for (x, y) in coords:
        if x < 0.5 and y >= 0.5:
            tags.append("NW" if "NW" in u.hemispheres else u.hemispheres[0])
        elif x >= 0.5 and y >= 0.5:
            tags.append("NE" if "NE" in u.hemispheres else u.hemispheres[0])
        elif x < 0.5 and y < 0.5:
            tags.append("SW" if "SW" in u.hemispheres else u.hemispheres[0])
        else:
            tags.append("SE" if "SE" in u.hemispheres else u.hemispheres[0])
    return tags

def log_universe(u: Universe) -> None:
    tid = trails.begin_trail({"op":"space.universe","module":__name__,"policy_hash":POLICY_HASH,"payload":{"name":u.name,"hemispheres":u.hemispheres}})
    trails.finalize(tid, {"op":"space.universe.done","module":__name__})

def log_lattice(l: Lattice) -> None:
    tid = trails.begin_trail({"op":"space.lattice","module":__name__,"policy_hash":POLICY_HASH,"payload":{"name":l.name,"dim":l.dim}})
    trails.finalize(tid, {"op":"space.lattice.done","module":__name__})
