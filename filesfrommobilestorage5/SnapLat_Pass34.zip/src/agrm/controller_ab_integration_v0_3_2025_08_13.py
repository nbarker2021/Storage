
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
import numpy as np
from core.agrm.controller_v0_7_2025_08_13 import AGRMController_v0_7_2025_08_13 as CTRL

def run_once(N=4000, use_pref=False, use_new=True, prior_path=None):
    rng = np.random.default_rng(11)
    pts = rng.random((N, 2))
    cfg = {
        "vws_force_grid": True, "vws_N_guard": 3000,
        "vws_grid_size": 64, "seeding_strategy": "grid",
        "vws_skip_seed": False,
        "use_adjacency_prefilter": use_pref,
    }
    ctrl = CTRL(cfg=cfg)
    res = ctrl.solve(pts, max_ticks=3)
    return res

if __name__ == "__main__":
    base = run_once(N=3500, use_pref=False)
    print("BASE:", base)
    new = run_once(N=3500, use_pref=True)
    print("NEW :", new)
