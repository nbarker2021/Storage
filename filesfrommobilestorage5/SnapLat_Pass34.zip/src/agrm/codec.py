
from dataclasses import dataclass
from typing import Any, Dict, List
import hashlib
from agrm.shelling.engine import ShellLevel, to_three_words

@dataclass
class Glyph:
    key: str
    three: List[str]
    payload: Dict[str,Any]

def _checksum(words: List[str]) -> str:
    s = "::".join(words).encode("utf-8", "ignore")
    return hashlib.sha1(s).hexdigest()[:12]

def compress(levels: List[ShellLevel], meta: Dict[str,Any]=None) -> Glyph:
    top = levels[-1] if levels else None
    words = to_three_words(top) if top else ["∅","∅","∅"]
    key = "::".join(words)
    return Glyph(key=key, three=words, payload={
        "levels": [l.n for l in levels],
        "checksum": _checksum(words),
        "meta": {"family": (meta or {}).get("family"), "type": (meta or {}).get("type")}
    })

def inflate(glyph: Glyph) -> List[ShellLevel]:
    return [ShellLevel(n=n, nodes=[{"glyph_key": glyph.key, "n": n}]) for n in glyph.payload.get("levels", [])]

def invert(glyph: Glyph) -> Glyph:
    inv_words = [f"¬{w}" if not str(w).startswith("¬") else str(w)[1:] for w in glyph.three]
    key = "::".join(inv_words)
    return Glyph(key=key, three=inv_words, payload={**glyph.payload, "inverse_of": glyph.key})
