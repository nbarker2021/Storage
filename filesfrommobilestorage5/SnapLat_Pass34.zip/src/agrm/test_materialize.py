
import time, json
from pathlib import Path
from agrm.archivist.repository import Repository
from agrm.universe.manager import UniverseManager, UniverseSpec
from agrm.universe.materialize import to_points, to_graph

REPO = '/mnt/data/repository_store_v0_1_2025_08_13'
REG  = '/mnt/data/universe_registry_v0_1_2025_08_13'

def test_materialize_points_and_graph(tmp_path):
    repo = Repository(REPO)
    # seed a few SNAPs if none exist
    if not repo.list():
        for i in range(6):
            sid = f'test-culture-creative-{int(time.time())}-{i}'
            meta = {"snap_id": sid, "family":"culture","type":"creative","created_ts": time.time(),"tags":{"snap_score":0.6 + 0.05*i}}
            repo.save(sid, {"meta":meta, "content":{}})
    um = UniverseManager(REPO, REG)
    if 'UnitTestUniverse' not in um.list_universes():
        um.create_universe(UniverseSpec(name='UnitTestUniverse', selectors={"family":["culture"],"type":["creative"]}))
    X, meta = to_points('UnitTestUniverse', repo_root=REPO, registry_root=REG, criteria={"family":["culture"],"type":["creative"]}, wave_size=4)
    assert meta['count'] >= 0
    G, meta2 = to_graph('UnitTestUniverse', repo_root=REPO, registry_root=REG, criteria={"family":["culture"],"type":["creative"]}, adj_k=3)
    assert G['N'] >= 0
