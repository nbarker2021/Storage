
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from adapters.legacy_auto.agrm_cmplx.hash_adapters import Hash64
@dataclass
class LegacyHashBackend:
    module: str; func: str
    def __post_init__(self): self._h = Hash64(self.module, self.func)
    def encode(self, X: np.ndarray) -> np.ndarray:
        X = np.atleast_2d(X).astype(np.float32)
        out = np.empty((X.shape[0],), dtype=np.uint64)
        for i in range(X.shape[0]): out[i] = self._h.hash_bytes(X[i].tobytes()) & ((1<<64)-1)
        return out
