"""
LegacyAGRMSolver wraps /mnt/data/AGRM.py without modifying it.
"""
from typing import Any, Dict, List, Tuple
import importlib.util
import numpy as np

class LegacyAGRMSolver:
    def __init__(self, config: Dict[str, Any] | None = None, module_path: str = "/mnt/data/AGRM.py"):
        self.config = config or {}
        spec = importlib.util.spec_from_file_location("agrm_legacy_module", module_path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load legacy AGRM module at {module_path}")
        self._mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self._mod)
        if not hasattr(self._mod, "AGRMController"):
            raise RuntimeError("Legacy module lacks AGRMController")
        self._controller_cls = getattr(self._mod, "AGRMController")

    def solve(self, points: List[Tuple[float,float]] | np.ndarray):
        pts = np.asarray(points, dtype=float)
        controller = self._controller_cls(self.config)
        return controller.solve(pts)
