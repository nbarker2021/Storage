
import time
def begin_trail(repo, universe: str, label: str, cfg):
    tid = f"trail::{universe}::{label}::{int(time.time()*1000)}"
    repo.save(tid, {"meta":{"snap_id":tid,"family":"trail","type":"events","tags":{"universe":universe}},
                    "content":{"cfg":cfg,"events":[]}})
    return tid
def append_event(repo, trail_id: str, event: dict):
    obj = repo.load(trail_id)
    obj["content"]["events"].append(event)
    repo.save(trail_id, obj)
def finalize(repo, um, universe: str, trail_id: str, summary: dict):
    obj = repo.load(trail_id)
    obj["content"]["summary"] = summary
    repo.save(trail_id, obj)
