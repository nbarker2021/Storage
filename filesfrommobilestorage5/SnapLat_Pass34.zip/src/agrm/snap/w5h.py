from __future__ import annotations
from typing import Sequence
import math

def _dot(a: Sequence[float], b: Sequence[float]) -> float:
    return sum((float(x)*float(y) for x, y in zip(a, b)))

def _norm(a: Sequence[float]) -> float:
    return math.sqrt(sum((float(x)*float(x) for x in a))) or 0.0

def compute_w5h_alignment(beacon_vec, room_vec) -> float:
    """Deterministic cosine-similarity mapped to [0,1].
    If vectors have different lengths, zip truncation is used. Zero vectors => 0.0.
    """
    try:
        num = _dot(beacon_vec, room_vec)
        den = (_norm(beacon_vec) * _norm(room_vec))
        if den <= 0.0:
            return 0.0
        cos = max(-1.0, min(1.0, num/den))
        return 0.5*(cos + 1.0)
    except Exception:
        return 0.0
