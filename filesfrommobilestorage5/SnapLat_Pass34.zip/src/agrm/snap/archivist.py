from __future__ import annotations
from typing import Any, Dict
from datetime import datetime, timezone
from uuid import uuid4
import json, hashlib
from trails import api as trails
from trails import validate as trails_validate
from mannequin.api import get_sentinel
from ops.policy.api import POLICY_HASH
from ops.chain.api import make_chain

# In-memory registry of Snaps for sandbox purposes
_REG: Dict[str, Dict[str, Any]] = {}

REQUIRED_FIELDS = ["snap_id","parent_ids","glyph","context","n_level","shell","trail_id","created_at"]

def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def _canonical_dumps(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",",":"), ensure_ascii=False)

def _payload_hash(expanded: Dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_dumps(expanded).encode("utf-8")).hexdigest()

def _validate_snap_dict(snap: Dict[str, Any]) -> bool:
    # Minimal schema validation per SNAP_V1_SCHEMA.json (not full JSON Schema)
    for k in REQUIRED_FIELDS:
        if k not in snap:
            return False
    if not isinstance(snap.get("snap_id"), str): return False
    if not isinstance(snap.get("parent_ids"), list): return False
    if not isinstance(snap.get("glyph"), str): return False
    if not isinstance(snap.get("context"), dict): return False
    if not isinstance(snap.get("n_level"), (int,float)): return False
    if not isinstance(snap.get("shell"), int): return False
    return True

def contract(expanded: Dict[str, Any]) -> Dict[str, Any]:
    """Compress active reasoning into a SnapV1; deterministic payload_hash; Trails coverage.
    Safe-Cube checked with op 'archivist.contract'."""
    tid = trails.begin_trail({
        "op": "archivist.contract",
        "module": __name__,
        "policy_hash": POLICY_HASH,
        "payload": {"preview": list(expanded.keys())}, "chain": make_chain("archivist")
    })
    try:
        sentinel = get_sentinel()
        if not sentinel.allow("archivist.contract", {"keys": list(expanded.keys())}):
            trails.append_event(tid, {"op":"archivist.contract.denied","module":__name__,"payload":{}})
            raise PermissionError("Safe-Cube denied archivist.contract")
        snap = {
            "snap_id": uuid4().hex,
            "parent_ids": expanded.get("parent_ids", []),
            "glyph": expanded.get("glyph", ""),
            "context": expanded.get("context", {}),
            "n_level": expanded.get("n_level", 0.0),
            "shell": int(expanded.get("shell", 0)),
            "trail_id": tid,
            "created_at": _iso_now(),
        }
        # optional fields
        if "weyl_index" in expanded: snap["weyl_index"] = expanded["weyl_index"]
        if "universe_ref" in expanded: snap["universe_ref"] = expanded["universe_ref"]
        snap["payload_hash"] = _payload_hash(expanded)
            snap["fingerprint"] = hashlib.sha256((snap["payload_hash"] + "|" + POLICY_HASH).encode("utf-8")).hexdigest()
        # register
        _REG[snap["snap_id"]] = dict(snap)
        trails.append_event(tid, {"op":"archivist.contract.created","module":__name__,"payload":{"snap_id":snap["snap_id"]}})
        return snap
    finally:
        trails.finalize(tid, {"op":"archivist.contract.done","module":__name__,"payload":{}})

def expand(snap_id: str, *, with_bridges: bool = True) -> Dict[str, Any]:
    """Rehydrate a Snap into an ExpandedContext (sandbox). Validates schema; Safe-Cube denies invalid.
    Uses registry-only for now; in real impl, would hydrate from storage and bridges.
    """
    raw = _REG.get(snap_id, None)
    invalid = (raw is None) or (not isinstance(raw, dict)) or (not _validate_snap_dict(raw))
    op = "archivist.expand.invalid_schema" if invalid else "archivist.expand"
    tid = trails.begin_trail({
        "op": op,
        "module": __name__,
        "policy_hash": POLICY_HASH,
        "payload": {"snap_id": snap_id, "invalid": bool(invalid)}
    })
    try:
        sentinel = get_sentinel()
        if not sentinel.allow(op, {"snap_id": snap_id, "invalid": bool(invalid)}):
            trails.append_event(tid, {"op":"archivist.expand.denied","module":__name__,"payload":{"snap_id":snap_id}})
            raise PermissionError("Safe-Cube denied expand (invalid schema or policy)")
        if invalid:
            trails.append_event(tid, {"op":"archivist.expand.error","module":__name__,"payload":{"reason":"invalid or unknown snap"}})
            raise ValueError("Invalid or unknown Snap")
        # Build ExpandedContext deterministically from stored snap
        snap = raw
        expanded = {
            "glyph": snap["glyph"],
            "context": snap["context"],
            "n_level": snap["n_level"],
            "shell": snap["shell"],
            "parent_ids": snap.get("parent_ids", []),
            "weyl_index": snap.get("weyl_index", None),
            "universe_ref": snap.get("universe_ref", None),
            "snap_id": snap_id,
            "with_bridges": bool(with_bridges),
        }
        trails.append_event(tid, {"op":"archivist.expand.ok","module":__name__,"payload":{"snap_id":snap_id}})
        return expanded
    finally:
        trails.finalize(tid, {"op":"archivist.expand.done","module":__name__,"payload":{"snap_id":snap_id}})

# Testing helper (not exported in .pyi): allow tests to inject malformed snaps
def _register_snap_for_tests(snap: Dict[str, Any]) -> str:
    if not isinstance(snap, dict) or "snap_id" not in snap:
        raise ValueError("snap must include snap_id")
    _REG[snap["snap_id"]] = dict(snap)
    return snap["snap_id"]

def get_fingerprint_by_id(snap_id: str) -> str | None:
    rec = _REG.get(snap_id)
    return (rec or {}).get("fingerprint") if rec else None
