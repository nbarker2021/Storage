
import json
from pathlib import Path
from universal_state_spec.lib.w5h_scorer import w5h_aggregate

def test_w5h_aggregate_final_key() -> None:
    beacon = json.loads(Path("/mnt/data/universal_state_spec/examples/beacon_example.json").read_text())
    scores = w5h_aggregate(beacon)
    assert 0.0 <= scores["final"] <= 1.0
    for k in ["who","what","where","when","why","how"]:
        assert 0.0 <= scores[k] <= 1.0
