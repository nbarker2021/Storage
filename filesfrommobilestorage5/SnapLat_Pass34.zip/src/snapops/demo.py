from __future__ import annotations
import argparse, json
from snapops.api import run
from mannequin.api import load_rules
from ops.agents.api import agent_fingerprint
from trails import api as trails_api
from trails.query import buffer as tqb
from trails.query.api import filter_events, summarize_ops

def main():
    ap = argparse.ArgumentParser(description="SnapOps demo (policy-aware)")
    ap.add_argument("--inject-fail", action="store_true", help="Inject a failing step to exercise E-DBSU branch")
    ap.add_argument("--snap-id", type=str, default=None, help="Subject snap id (optional)")
    args = ap.parse_args()
    # Allow ThinkTank

    load_rules(json.dumps({"version":1,"rules":[{"op":"thinktank.critique","allow":True}]}))

    req = {"inject_fail": bool(args.inject_fail), "snap_id": args.snap_id}

    result = run(req)

    print("OK:", result.ok, "Transcript OK:", result.transcript_ok)

    if result.workorder:

        print("WorkOrder modules:", ",".join(result.workorder.modules))

    if result.edbsu_state:

        print("E-DBSU state:", result.edbsu_state)

    # Drain and summarize trails

    events = trails_api._drain()

    tqb.clear(); tqb.ingest(events)

    fp = agent_fingerprint("snapops")

    matched = filter_events(tqb.snapshot(), agent_fp=fp)

    print("Trail matches for SnapOps:", len(matched))

    print("Op counts:", json.dumps(summarize_ops(matched), indent=2))


if __name__ == "__main__":

    main()

