from __future__ import annotations
from typing import Any, Dict, List
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class OrchestrationPlan:
    steps: List[Dict[str, Any]]

def orchestrate(request: Dict[str, Any]) -> OrchestrationPlan:
    tid = trails.begin_trail({"op":"snapops.orchestrate","module":__name__,"policy_hash":POLICY_HASH,"payload":{"keys": list((request or {}).keys())}})
    try:
        # Minimal: echo a ThinkTank-like step plan, but tagged
        plan = [
            {"op":"mdhg.to_points","why":"seed (soc)"},
            {"op":"mdhg.to_graph","why":"structure (soc)"},
            {"op":"mdhg.promotion_breakdown","why":"score (soc)"},
            {"op":"archivist.contract","why":"compress (soc)"},
            {"op":"porter.deliver","to":"dtt.harness","why":"dry (soc)"}
        ]
        trails.append_event(tid, {"op":"snapops.plan","module":__name__,"payload":{"n": len(plan)}})
        return OrchestrationPlan(steps=plan)
    finally:
        trails.finalize(tid, {"op":"snapops.done","module":__name__})


from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from ops.agents.api import agent_fingerprint
from thinktank.api import ThinkTank
from dtt.api import run_steps
from assembly.api import stage, WorkOrder
from agrm.snap import edbsu as edb
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class OrchestrationResult:
    ok: bool
    plan_steps: List[Dict[str, Any]]
    transcript_ok: bool
    workorder: Optional[WorkOrder]
    edbsu_state: Optional[str]

def run(request: Dict[str, Any]) -> OrchestrationResult:
    """Policy‑aware orchestration:

    1) Ask ThinkTank for a critique‑plan (Safe‑Cube gated via rules outside).

    2) Dry‑run via DTT. If transcript.ok==False → submit to E‑DBSU and TRIAGE.

    3) If transcript.ok==True → stage a WorkOrder via Assembly.
    """

    agent_fp = agent_fingerprint("snapops")
    tid = trails.begin_trail({"op":"snapops.run","module":__name__,"policy_hash":POLICY_HASH, "chain": {"agent_fp": agent_fp}})
    try:

        # 1) ThinkTank plan

        tt = ThinkTank(panel=request.get("panel") or ["mdhg","archivist","porter"])

        findings = request.get("findings") or ["ok"]

        evidence = request.get("evidence") or {"corroboration":1.0, "neg_conflict":0.0}

        subject_snap_id = request.get("snap_id")

        res = tt.critique(findings=findings, evidence=evidence, subject_snap_id=subject_snap_id)

        steps = list(res.steps)

        if request.get("inject_fail"):

            steps.append({"op":"fail.synthetic","why":"policy‑aware branch test"})

        trails.append_event(tid, {"op":"snapops.plan","module":__name__,"payload":{"n": len(steps)}})



        # 2) DTT dry‑run

        transcript = run_steps(steps, mode="dry")

        trails.append_event(tid, {"op":"snapops.transcript","module":__name__,"payload":{"ok": bool(transcript.ok), "counts": transcript.counts}})



        workorder = None

        ed_state = None

        if not transcript.ok:

            # 2b) Failure branch → E‑DBSU


            cand = {

                "cause": "dtt.failure",

                "counts": dict(transcript.counts),

                "subject_snap_id": subject_snap_id,

            }

            cid = edb.submit(cand)

            ev = {"corroboration": 0.0, "neg_conflict": 1.0}

            edb.triage(cid, ev)

            ed_state = edb.get_state(cid)

            trails.append_event(tid, {"op":"snapops.edbsu","module":__name__,"payload":{"state": ed_state}})

            ok = False

        else:

            # 3) Success branch → Assembly

            workorder = stage(transcript)

            trails.append_event(tid, {"op":"snapops.assembly","module":__name__,"payload": {"modules": workorder.modules}})

            ok = True

        return OrchestrationResult(ok=ok, plan_steps=steps, transcript_ok=bool(transcript.ok), workorder=workorder, edbsu_state=ed_state)

    finally:

        trails.finalize(tid, {"op":"snapops.done","module":__name__})



@dataclass
class Policy:
    triage_threshold: float = 0.50    # neg_conflict threshold to send to E-DBSU
    retry_on_fail: bool = True        # try a salvage pass
    max_retries: int = 1              # one salvage attempt by default
    archive_on_persist: bool = False  # optional escalation

def _as_policy(p: Dict[str, Any] | None) -> Policy:
    d = dict(p or {})
    return Policy(
        triage_threshold=float(d.get("triage_threshold", 0.50)),
        retry_on_fail=bool(d.get("retry_on_fail", True)),
        max_retries=int(d.get("max_retries", 1)),
        archive_on_persist=bool(d.get("archive_on_persist", False)),
    )
