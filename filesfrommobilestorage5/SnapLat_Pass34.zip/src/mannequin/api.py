from __future__ import annotations
from typing import Any, Dict, List
from dataclasses import dataclass, field
import json
from pathlib import Path
from trails import api as trails
from ops.policy.api import POLICY_HASH
from ops.agents.api import agent_fingerprint

@dataclass
class Rule:
    op: str
    allow: bool
    reason: str | None = None

@dataclass
class Ruleset:
    version: int = 1
    rules: List[Rule] = field(default_factory=list)

class SafeCubeSentinel:
    def __init__(self) -> None:
        self._rules: Ruleset = Ruleset()

    def load_rules(self, path: str) -> None:
        p = Path(path)
        data = json.loads(p.read_text(encoding="utf-8"))
        rs = Ruleset(version=int(data.get("version", 1)), rules=[])
        for r in data.get("rules", []):
            rs.rules.append(Rule(op=str(r.get("op","")), allow=bool(r.get("allow", False)), reason=r.get("reason")))
        self._rules = rs

    def allow(self, op: str, context: Dict[str, Any]) -> bool:
        # Begin trail for decision
        tid = trails.begin_trail({
            "op": "safe_cube.allow",
            "module": __name__,
            "policy_hash": POLICY_HASH,
            "safe_cube": {"rules_version": self._rules.version}
        })
        # Decide
        decision = False
        reason = "deny-by-default"
        matched = None
        for r in self._rules.rules:
            if r.op == op:
                decision = r.allow
                reason = r.reason or ("allow" if decision else "deny")
                matched = r.op
                break
        trails.append_event(tid, {
            "op": "safe_cube.decision",
            "module": __name__,
            "payload": {"op": op, "matched": matched, "decision": decision, "reason": reason, "context": context}
        })
        trails.finalize(tid, {"op": "safe_cube.result", "module": __name__, "payload": {"allowed": decision}})
        return decision

# Module-level helper and default sentinel
_CURRENT = SafeCubeSentinel()

def load_rules(path: str) -> None:
    _CURRENT.load_rules(path)

def get_sentinel() -> SafeCubeSentinel:
    return _CURRENT

# Minimal Porter seed (kept tiny; real semantics in next pass)
class Porter:
    def __init__(self) -> None:
        self._delivered: List[Dict[str, Any]] = []
    def deliver(self, payload: Any, *, to: str) -> None:
        self._delivered.append({"to": to, "payload": payload})


# --- Convenience: inspect chain by agent/snap fingerprint (test/debug only)
def _porter_inspect_impl(*, agent_fp: str | None = None, snap_fp: str | None = None, drain: bool = True) -> dict:
    from trails import api as trails_api
    from trails.query import buffer as tqb
    from trails.query.api import filter_events, summarize_ops
    if drain:
        ev = trails_api._drain()
        tqb.ingest(ev)
    events = tqb.snapshot()
    matched = filter_events(events, agent_fp=agent_fp, snap_fp=snap_fp)
    return {
        "n_events": len(matched),
        "counts": summarize_ops(matched),
    }

# expose via Porter instance for convenience
class Porter(Porter):  # type: ignore[valid-type, misc]
    def inspect(self, *, agent_fp: str | None = None, snap_fp: str | None = None, drain: bool = True) -> dict:
        return _porter_inspect_impl(agent_fp=agent_fp, snap_fp=snap_fp, drain=drain)
