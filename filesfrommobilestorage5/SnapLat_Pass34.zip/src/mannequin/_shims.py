# Auto‑generated shim skeletons (names only; no implementations)
from __future__ import annotations

class Porter:
    """Shim — to be implemented during refactor."""
    pass

class SafeCubeSentinel:
    """Shim — to be implemented during refactor."""
    pass

nan
