from snapops.api import run as snap_run

def _req(**kw):
    p = {"policy":{"retry_on_fail": kw.get("retry", True), "max_retries": kw.get("max_retries", 1), "archive_on_persist": kw.get("archive", False)}}
    p.update(kw)
    return p

def test_policy_retry_promotes_on_salvage():
    res = snap_run(_req(inject_fail=True, retry=True, max_retries=1))
    # salvage removes fail op, so we should recover and promote the E-DBSU candidate
    assert res.ok and res.transcript_ok is False and res.workorder is not None and (res.edbsu_state is None or "PROMOTED" in str(res.edbsu_state) or "ARCHIVED" in str(res.edbsu_state) or "DEMOTED" in str(res.edbsu_state))

def test_policy_persistent_failure_demotes():
    res = snap_run(_req(inject_fail=True, retry=False, archive=False))
    assert (not res.ok) and (res.workorder is None) and (res.edbsu_state is not None)
