def test_agrm_tpg_api_skeleton():
    assert True
