from agrm.mdhg.ops import to_points, to_graph
from trails import api as trails_api
from trails import validate as trails_validate

def test_to_points_determinism():
    p1 = to_points(seed=7)
    p2 = to_points(seed=7)
    assert p1.coords == p2.coords
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)

def test_to_graph_quota_monotonic():
    pts = to_points(seed=3)
    g1 = to_graph(pts, quotas={"edges": 2})
    g2 = to_graph(pts, quotas={"edges": 4})
    assert len(g2.edges) >= len(g1.edges)
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)


def test_promotion_breakdown_scores_and_ranking():
    pts = to_points(seed=5)
    g = to_graph(pts, quotas={"edges": 6})
    from agrm.mdhg.ops import promotion_breakdown
    pb = promotion_breakdown(g)
    assert pb.ranking and len(pb.scores) == len(pts.coords)
