from mannequin.api import Porter
from trails import api as trails_api
from trails import validate as trails_validate

def test_porter_success_and_trails():
    p = Porter()
    processed = []
    p.register_sink("ok", lambda payload: processed.append(payload))
    tid = trails_api.begin_trail({"op":"porter-test","module":"x"})
    p.deliver({"x":1}, to="ok")
    trails_api.finalize(tid, {"op":"porter-test","status":"ok"})
    assert processed == [{"x":1}]
    evts = trails_api._drain()
    assert len(evts) >= 3  # wrapper begin/append/finalize, plus our begin/append/finalize
    for e in evts:
        trails_validate.validate_event(e)
