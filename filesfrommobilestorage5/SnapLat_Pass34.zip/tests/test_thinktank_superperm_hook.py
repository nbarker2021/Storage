from thinktank.api import ThinkTank
from mannequin.api import load_rules

def _allow(ttmp):
    p = ttmp / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_thinktank_emits_superperm_step_on_signal(tmp_path):
    _allow(tmp_path)
    tt = ThinkTank(panel=["mdhg","archivist","porter"])
    res = tt.critique(findings=["consider superperm and n=5"], evidence={"corroboration":1.0})
    assert any(s.get("op")=="superperm.summarize" for s in res.steps)
