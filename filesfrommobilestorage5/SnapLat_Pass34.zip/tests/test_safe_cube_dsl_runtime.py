from mannequin.api import load_rules, get_sentinel
from trails import api as trails_api
from trails import validate as trails_validate

def test_safe_cube_allow_and_deny(tmp_path):
    # Write a temp ruleset
    rules = tmp_path / "rules.json"
    rules.write_text('{"version":1,"rules":[{"op":"ok","allow":true},{"op":"nope","allow":false,"reason":"blocked"}]}', encoding="utf-8")
    load_rules(str(rules))
    s = get_sentinel()
    # Allow path
    ok = s.allow("ok", {"foo":"bar"})
    # Deny path
    no = s.allow("nope", {"foo":"bar"})
    assert ok is True and no is False
    # Validate Trail events
    events = trails_api._drain()
    assert len(events) >= 6  # begin/append/finalize for each call
    for e in events:
        trails_validate.validate_event(e)
