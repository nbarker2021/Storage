from thinktank.api import ThinkTank
from mannequin.api import Porter, load_rules
from dtt.api import run_steps
from trails import api as trails_api
from trails import validate as trails_validate

def _allow_thinktank(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_porter_orchestration_failure_goes_to_dlq(tmp_path):
    _allow_thinktank(tmp_path)
    tt = ThinkTank(panel=["mdhg","archivist","porter"])
    res = tt.critique(findings=["inject failure"], evidence={"corroboration":0.0, "neg_conflict":0.0})

    # Force a failing step into the plan
    steps = list(res.steps) + [{"op":"fail.synthetic","why":"test failure"}]

    port = Porter()
    def dtt_sink(payload):
        t = run_steps(payload["steps"], mode="dry")
        # If any step failed, surface an exception so Porter sends to DLQ
        if not t.ok:
            raise RuntimeError("dtt reported failure")
    port.register_sink("dtt.harness", dtt_sink)

    port.deliver({"steps": steps}, to="dtt.harness", retries=0)

    dlq = port.dead_letters("dtt.harness")
    assert dlq and isinstance(dlq[0], dict) and "payload" in dlq[0]

    events = trails_api._drain()
    assert any(e.get("event")=="append" and e.get("payload",{}).get("op")=="porter.error" for e in events)
    for e in events:
        trails_validate.validate_event(e)
