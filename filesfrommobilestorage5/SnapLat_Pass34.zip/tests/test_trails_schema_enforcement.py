from trails import api as trails_api
from trails import validate as trails_validate
from agrm.mdhg import wrapper as mdhg

def test_trail_events_conform_to_schema():
    tid = trails_api.begin_trail({"op":"schema-smoke","module":"test"})
    pts = mdhg.to_points({"x":1,"y":2})
    nodes, edges = mdhg.to_graph(pts, quotas={"edges":1})
    _ = mdhg.promotion_breakdown({"hot": True, "w5h": 0.3})
    trails_api.finalize(tid, {"op":"done","status":"ok"})
    events = trails_api._drain()
    assert [e["event"] for e in events] == ["begin","append","finalize","begin","append","finalize","begin","append","finalize"]
    for e in events:
        trails_validate.validate_event(e)
