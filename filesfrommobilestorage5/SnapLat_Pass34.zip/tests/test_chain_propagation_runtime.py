from thinktank.api import ThinkTank
from dtt.api import run_steps
from assembly.api import stage
from agrm.snap.archivist import contract
from mannequin.api import load_rules
from trails import api as trails_api
from trails import validate as trails_validate

def _allow(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_snap_id_propagates_thinktank_to_dtt_to_assembly(tmp_path):
    _allow(tmp_path)
    # Create a subject Snap
    snap = contract({"glyph":"topic","context":{},"n_level":1.0,"shell":0})
    sid = snap["snap_id"]
    tt = ThinkTank(panel=["mdhg","archivist","porter"])
    res = tt.critique(findings=["ok"], evidence={"corroboration":1.0}, subject_snap_id=sid)
    assert any(s.get("snap_id")==sid for s in res.steps)
    t = run_steps(res.steps, mode="dry")
    wo = stage(t)
    assert sid in (wo.snap_ids or [])
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
