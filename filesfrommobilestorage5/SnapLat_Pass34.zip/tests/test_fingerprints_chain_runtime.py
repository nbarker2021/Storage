from agrm.snap.archivist import contract, expand, get_fingerprint_by_id
from mannequin.api import Porter
from trails import api as trails_api
from trails import validate as trails_validate

def test_snap_fingerprint_exists_and_is_attached():
    snap = contract({"glyph":"g","context":{},"n_level":1.0,"shell":0})
    fp = snap.get("fingerprint")
    assert fp and len(fp) == 64
    try:
        _ = expand(snap["snap_id"])
    except Exception:
        pass
    events = trails_api._drain()
    assert any(e.get("event")=="begin" and e.get("payload",{}).get("chain",{}).get("snap_fp")==fp for e in events)
    for e in events:
        trails_validate.validate_event(e)

def test_porter_attempt_includes_snap_fp_if_present():
    port = Porter()
    port.deliver({"snap_id":"s", "snap_fingerprint":"abc123"}, to="noop")  # no sink registered
    events = trails_api._drain()
    assert any(e.get("event")=="append" and e.get("payload",{}).get("op")=="porter.attempt" and e.get("payload",{}).get("snap_fp")=="abc123" for e in events)
    for e in events:
        trails_validate.validate_event(e)
