from thinktank.api import ThinkTank
from mannequin.api import Porter, load_rules
from dtt.api import run_steps
from trails import api as trails_api
from trails import validate as trails_validate

def _allow_thinktank(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_no_assembly_when_dtt_fails(tmp_path):
    _allow_thinktank(tmp_path)
    tt = ThinkTank(panel=["mdhg","archivist","porter"])
    res = tt.critique(findings=["trigger fail"], evidence={"corroboration":0.0, "neg_conflict":0.0})
    # Force a failing step into the plan (no exception raised; just don't forward on failure)
    steps = list(res.steps) + [{"op":"fail.synthetic","why":"test failure"}]

    port = Porter()
    assembly_called = {"value": False}

    def dtt_sink(payload):
        t = run_steps(payload["steps"], mode="dry")
        if t.ok:
            port.deliver(t, to="assembly.harness")
        # else: swallow and DO NOT forward to assembly

    def assembly_sink(payload):
        assembly_called["value"] = True  # should remain False

    port.register_sink("dtt.harness", dtt_sink)
    port.register_sink("assembly.harness", assembly_sink)

    port.deliver({"steps": steps}, to="dtt.harness")

    # Assert assembly never ran
    assert assembly_called["value"] is False

    # Additionally assert NO assembly Trails exist
    events = trails_api._drain()
    assert not any(e.get("module","").startswith("assembly.") for e in events), "Assembly Trails should be absent"
    for e in events:
        trails_validate.validate_event(e)
