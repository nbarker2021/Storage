from thinktank.api import ThinkTank, get_panel
from mannequin.api import load_rules
from trails import api as trails_api
from trails import validate as trails_validate

def _allow_rules(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_thinktank_produces_steps_and_trails(tmp_path):
    _allow_rules(tmp_path)
    tt = ThinkTank(panel=["mdhg","archivist"])
    res = tt.critique(findings=["bridge ambiguity","weyl crossover"], evidence={"corroboration":1.0, "neg_conflict":0.0})
    assert res.steps and isinstance(res.score, float)
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)

def test_thinktank_safe_cube_denial(tmp_path):
    # deny by default (no rules loaded): expect PermissionError
    denied = False
    try:
        get_panel().critique(findings=["x"], evidence={})
    except PermissionError:
        denied = True
    assert denied
