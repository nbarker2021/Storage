# Execution Plan — Pass 8
This is the prioritized work queue derived from the Interface Fit Report. No logic changes have been made yet.
Work proceeds milestone-by-milestone, highest priority first, with Trails/telemetry from day one.

## Prioritization
- **P0:** Blocking integration surfaces (policy_hash, trails_hooks, to_points/to_graph, tpg_config)
- **P1:** High-importance scoring & alignment (promotion_breakdown, w5h_alignment, beacons_registry, neg_beacon)
- **P2:** Plugin/supporting surfaces (FS2 uniqueness/cache/envelope, porter_custody, safe_cube_sentinel)
- **P3:** Remaining items

## Milestones
- M1 — MDHG Core
- M2 — AGRM + TPG
- M3 — Trails/W5H/Beacons
- M4 — FS2 Superperm Plugin
- M5 — Policy/Mannequin
