# Code Review — Pass 34 (Contracts/Naming/Trails)


## Naming

- Event `op` keys standardized to `<namespace>.<verb>`; avoid mixed hyphen/underscore.

- Keep `module` in Trail payloads; ensure all `begin` events include `policy_hash` and `chain.agent_fp` when applicable.


## Contracts

- ThinkTank → DTT → Assembly: steps carry `universe_ref` and optional `snap_id`; DTT preserves them in `meta`; Assembly emits `WorkOrder.snap_ids`.

- Archivist `contract/expand`: stamps `fingerprint`; Trails include chain-of-custody.

- Porter: `deliver` begins include agent fingerprint; `porter.attempt` appends may include `snap_fp`.


## Trails

- Use `begin/append/finalize` pattern consistently. Current modules follow this.

- Inspector returns modules + indices; timestamps are optional (future: add `ts`).


## Gaps slated for future migration (non-breaking now)

- Harmonize all `*.done` vs `*.finalize` event suffix usage.

- Gradually switch op literals to constants module (`ops.contracts.naming`) to reduce drift.

- Add richer MDHG scoring (bridge-aware, hemisphere weighting) behind flags.

