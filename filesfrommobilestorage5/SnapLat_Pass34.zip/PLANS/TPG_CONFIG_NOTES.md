# TPGConfig Notes
- Fields locked by tests: enabled (bool), max_nodes (int), beam (int), imperf_threshold (float), use_two_opt (bool).
- `two_opt` and `apply_surgery` are sandbox no-ops to pin orchestration interfaces without side effects.
- Real 2-opt wiring and heuristics will be introduced behind feature flags in a later milestone.
