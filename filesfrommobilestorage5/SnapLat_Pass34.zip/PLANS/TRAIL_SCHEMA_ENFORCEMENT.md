# Trail Schema Enforcement (Tests-Only)
We validate every emitted event in tests using `src/trails/validate.py` against the required
fields listed in `TRAIL_EVENT_BINDINGS.md`. This provides early, low-risk enforcement without
coupling runtime to a specific sink. Failing tests indicate contracts drifted and must be updated.
