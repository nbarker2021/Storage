# Beacons Registry Loading — Plan (M1.4)
## Goal
Allow optional loading of `BeaconsRegistry` from a project file `PLANS/beacons.json` to seed named beacons.

## File Shape (`PLANS/beacons.json`)
{
  "topicA": { "vec": [1.0, 0.0], "neg": false },
  "topicB": { "vec": [0.0, 1.0], "neg": true }
}

## API (proposed)
- `load_registry_from_file(path: str) -> None` in `agrm.snap.beacons` sets the default registry.

## Tests
- Create a temp JSON, call loader, assert named lookups reflect new data.

## Non-Goals
- No network or external sinks; file-only, synchronous load.
