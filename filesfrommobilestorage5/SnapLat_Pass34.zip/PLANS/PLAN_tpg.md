        # Plan — tpg
        ## Intake Files
        - `tpg/bridge.py`
- `tpg/schema.py`

        ## Known Gaps (from Fit Report)
        - neg_beacon_support
- tpg_config
- trails_hooks

        ## Minimal Shims Required
        - `class TPGConfig: enabled: bool; max_nodes: int; beam: int; imperf_threshold: float; use_two_opt: bool`
- `def append_event(trail_id: str, event: dict) -> None: ...`
- `def begin_trail(context: dict) -> str: ...`
- `def finalize(trail_id: str, summary: dict) -> None: ...`
- `def get_neg_beacon_penalty(scenario: str) -> float: ...`

        ## Refactor Steps (initial)
        - Normalize config and constants to `config.py` in this package.
        - Replace any hardcoded thresholds with injected config.
        - Add Trail hooks at entry/exit of key functions/methods.
        - Decompose large modules into single‑responsibility files.
        - Add docstrings and type hints for all public symbols.
        - Prepare unit harness targets (see `tests/` skeletons).
