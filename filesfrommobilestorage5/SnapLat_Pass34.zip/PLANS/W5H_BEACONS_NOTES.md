# W5H & Beacons — Sandbox Semantics
- `compute_w5h_alignment(beacon_vec, room_vec)` uses cosine similarity mapped to [0,1].
- In M1, `promotion_breakdown` prefers vector-derived `w5h` if present; otherwise uses numeric `w5h` in record.
- Negative beacons: if `neg_beacon_vec` + `room_vec` are present, a penalty up to 0.2 is applied (linear with alignment).
- Future: move coefficients to `mdhg_scoring.yaml` and support named beacons via `BeaconsRegistry`.

