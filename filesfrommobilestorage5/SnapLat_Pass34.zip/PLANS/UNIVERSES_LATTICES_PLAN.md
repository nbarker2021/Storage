# Universes & Lattices — Skeleton (M1.11) — Plan

## Goal

Provide minimal types and APIs to represent a Universe (hemispheres/quadrants) and nested Lattices with Weyl indexing, sufficient to:

- annotate MDHG to_points seeds

- tag Archivist Snaps with `universe_ref` and `weyl_index`

- enable Scout rendezvous checkpoints per hemisphere


## Proposed API

- `class Universe(name, hemispheres: List[str])`

- `class Lattice(name, dim: int)` with `weyl_index(point) -> int` (stub: hash-based mapping)

- Registry functions for tests: `get_default_universe()`, `set_default_universe(u)`


## Tests

- Deterministic `weyl_index` for identical points; stable quadrant tags; Trails on creation/logging.

