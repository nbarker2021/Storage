# DTT — Deterministic Test Tooling (M1.9) — Plan
## Goal
Provide a dry-run execution harness that accepts ThinkTank step proposals and simulates tool calls deterministically (no side effects), emitting Trails and returning a transcript for Assembly Line.

## Proposed API
- `run_steps(steps: List[Dict], *, mode: Literal["dry","live"]="dry") -> Transcript`
- Emits Trails per step (`begin/append/finalize`), attaching success/failure and simple timings.

## Tests
- Given a fixed set of steps, `run_steps(..., "dry")` returns a deterministic transcript and validates Trail schema.
