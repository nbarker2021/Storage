# SnapLat (staging) — Best‑Of Intake
This repository is an **intake‑only** staging of selected winners from legacy oracle code.
No refactors have been applied yet. Shim files (names only) are included to guarantee
interface fit against the reconstructed design (AGRM/MDHG/TPG/Trails/W5H/FS2).

## Structure
- `src/` — code (winners) placed according to proposed mapping

- `src/**/_shims.py` — minimal interfaces (names only, no logic)

## Notes
- This is not production; it's the gate to begin refactors with full provenance.

