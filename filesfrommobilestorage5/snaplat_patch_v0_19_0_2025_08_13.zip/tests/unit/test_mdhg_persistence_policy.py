
from agrm.mdhg.hierarchy import HierarchyManager, HierarchyParams
from agrm.mdhg.persistence import save_hierarchy, load_last_hierarchy

class DummyRepo:
    def __init__(self): self.store = {}
    def save(self, k, v): self.store[k]=v
    def load(self, k): return self.store[k]

def test_save_and_load_latest():
    repo = DummyRepo()
    params = HierarchyParams(room_capacity=10)
    hm = HierarchyManager(params)
    hm.build_initial(25)
    snap = hm.snapshot()
    sid = save_hierarchy(repo, "U", snap)
    last = load_last_hierarchy(repo, "U")
    assert last is not None
    assert last["floors"][0]["rooms"] >= 1

def test_room_split_policy_blocks():
    params = HierarchyParams(room_capacity=4, heat_split_threshold=1e-6, policy_for_split={"family_deny":["fiction"]})
    hm = HierarchyManager(params)
    hm.build_initial(8)
    # tag rooms as fiction
    for f in hm.buildings[0].floors:
        for r in f.rooms:
            r.tags["family"] = "fiction"
            r.heat = 999.0  # ensure split would happen
    hm.apply_heat({"edges":{}, "rooms":{}}, policies=params.policy_for_split)
    # no split should have occurred
    total_rooms = sum(len(f.rooms) for f in hm.buildings[0].floors)
    assert total_rooms == 2  # initial 2 rooms of capacity 4 each
