
# MDHG Persistence, Policy, and Tagging (SnapLat v0.19.0)

This patch adds:
- **Persistence** of MDHG hierarchy snapshots to the Repository with a `latest` pointer.
- **Decay** of room heat via half-life, making recency matter.
- **PolicyBus gate** for room splits (`params.policy_for_split` or `cfg['mdhg']['split_policy']`).
- **Room tagging** from metas (dominant family/type and 3-word glyph).
- **Elevator candidates** emitted as `mdhg_event` SNAPs (optional).

## Controller cfg example
```python
cfg = {
  "use_sweeps_full": True,
  "arms": 8,
  "rounds": 2,
  "universe": "DocUniverse",
  "mdhg": {
    "persist": True,
    "room_capacity": 64,
    "max_rooms_per_floor": 8,
    "heat_split_threshold": 128.0,
    "decay_half_life_hours": 24.0,
    "split_policy": {"family_allow": ["fact","science"], "family_deny": ["fiction"]},
    "promote_elevators": True,
    "elevator_score_min": 0.5
  }
}
```
