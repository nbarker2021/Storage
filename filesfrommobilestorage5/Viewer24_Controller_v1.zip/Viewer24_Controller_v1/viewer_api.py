
import json, os
from wsgiref.simple_server import make_server
from urllib.parse import parse_qs
from niemeier_specs import NIEMEIER_SPECS, parse_root_spec
from transforms import world_to_screen, apply_affine, angles_for_spec

SESSION = {"points": [], "meta": {}}

def read_json(environ):
    try:
        length = int(environ.get('CONTENT_LENGTH', '0'))
    except (ValueError): length = 0
    body = environ['wsgi.input'].read(length) if length > 0 else b'{}'
    return json.loads(body.decode('utf-8') or "{}")

def respond(start_response, status: str, obj: dict, ctype="application/json"):
    data = json.dumps(obj).encode("utf-8")
    headers = [('Content-Type', ctype), ('Content-Length', str(len(data)))]
    start_response(status, headers)
    return [data]

def app(environ, start_response):
    path = environ.get('PATH_INFO', '/')
    method = environ.get('REQUEST_METHOD', 'GET')

    if path == "/api/ping":
        return respond(start_response, '200 OK', {"ok": True})

    if path == "/api/load" and method == "POST":
        payload = read_json(environ)
        pts = payload.get("points") or []
        meta = payload.get("meta") or {}
        SESSION["points"] = pts
        SESSION["meta"] = meta
        return respond(start_response, '200 OK', {"ok": True, "count": len(pts)})

    if path == "/api/screens":
        # return per-screen descriptors: spec label + coxeter angles
        out = []
        for i, spec in enumerate(NIEMEIER_SPECS + ["LEECH"]):
            if spec == "LEECH":
                angles = [0.0]  # no roots overlay
            else:
                angles = angles_for_spec(spec)
            out.append({"index": i, "label": spec, "angles": angles})
        return respond(start_response, '200 OK', {"screens": out})

    if path == "/api/frame":
        # compute global affine for given canvas size so all screens align
        q = parse_qs(environ.get('QUERY_STRING',''))
        w = int(q.get('w', ['320'])[0]); h = int(q.get('h', ['240'])[0])
        s, tx, ty = world_to_screen(SESSION.get("points") or [], w, h, padding=0.08)
        return respond(start_response, '200 OK', {"s": s, "tx": tx, "ty": ty})

    if path == "/":
        try:
            with open("./static/index.html","rb") as f: data = f.read()
            start_response('200 OK', [('Content-Type','text/html')]); return [data]
        except Exception:
            start_response('404 NOT FOUND', [('Content-Type','text/plain')]); return [b'no index']

    if path.startswith("/static/"):
        p = "."+path
        try:
            with open(p,"rb") as f: data = f.read()
            ctype = "text/plain"
            if p.endswith(".html"): ctype="text/html"
            if p.endswith(".js"): ctype="text/javascript"
            if p.endswith(".css"): ctype="text/css"
            start_response('200 OK', [('Content-Type', ctype)]); return [data]
        except Exception:
            start_response('404 NOT FOUND', [('Content-Type','text/plain')]); return [b'not found']

    start_response('404 NOT FOUND', [('Content-Type','application/json')])
    return [b'{}']

def serve(host="127.0.0.1", port=8989):
    httpd = make_server(host, port, app)
    print(f"Viewer24 Controller on http://{host}:{port}")
    httpd.serve_forever()

if __name__ == "__main__":
    serve()
