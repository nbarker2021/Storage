
# Viewer24 Controller v1 (pure stdlib)

A 24-screen, lattice-aware viewer controller for your CQE stack. Each screen
corresponds to one of the 23 rooted Niemeier root systems plus the Leech (rootless)
context. All screens share a common world-to-screen affine so **edges are aligned**
and you get a single, uniform viewer mosaic.

## What it shows
- A 6x4 grid of canvases (24 max), with per-screen Coxeter-angle overlays derived
  from the root system components (A/D/E) of that Niemeier spec.
- Your loaded 2D points are drawn with a **single global affine** so all canvases
  share the same bounding box, centering, and scale.
- Leech screen shows no root overlay (rootless context).

## Run
```bash
python viewer_api.py
# open http://127.0.0.1:8989
```

Paste points like:
```json
[[1,0],[0,1],[-1,0],[0,-1]]
```

## Integration
- Hook coherence/collapse: call CoherenceSuite on the same points; keep the receipt.
- Hook Monster/Moonshine DB: send the embedding for nearest neighbors.
- Hook LatticeBuilder: for any screen's label, you can call the builder to get the
  block-diagonal Cartan Gram and validate properties.

## Uniform edges (design)
- The server computes a single affine (scale s, translation tx, ty) from the global
  bbox of the active point set. All 24 canvases reuse **exactly** that affine.
- Grid layout is fixed (6x4) so outer edges align perfectly. The radial Coxeter
  overlays share their center and radius, so "spokes" align visually across the grid.

## Files
- viewer_api.py            - WSGI server, APIs: /api/load, /api/screens, /api/frame
- niemeier_specs.py        - ADE Cartan builders and Niemeier spec list
- transforms.py            - global affine mapping and Coxeter angles
- static/index.html, app.js, style.css

## Roadmap
- Per-screen overlays for coherence score, delta-phi, nearest-moonshine class.
- Click-to-open details (calls CoherenceSuite and Monster/Moonshine DB).
- Multiple point layers (prev/curr) and on-canvas collapse markers.
- Timeline scrubber to navigate receipts with a unified mosaic refresh.
