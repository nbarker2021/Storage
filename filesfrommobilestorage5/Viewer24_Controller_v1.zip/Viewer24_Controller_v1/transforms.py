
import math
from typing import List, Tuple, Dict

Vec = Tuple[float,float]

def bbox(points: List[Vec]):
    if not points: return (0.0,0.0,1.0,1.0)
    xs = [p[0] for p in points]; ys = [p[1] for p in points]
    return (min(xs), min(ys), max(xs), max(ys))

def world_to_screen(points: List[Vec], width: int, height: int, padding: float=0.08):
    # compute affine mapping shared by all screens; pad to keep edges aligned
    xmin,ymin,xmax,ymax = bbox(points)
    dx = xmax - xmin; dy = ymax - ymin
    if dx == 0: dx = 1.0
    if dy == 0: dy = 1.0
    sx = (1.0 - 2*padding) * width / dx
    sy = (1.0 - 2*padding) * height / dy
    s = min(sx, sy)
    cx = (xmin + xmax)/2.0; cy = (ymin + ymax)/2.0
    tx = width*0.5 - s*cx
    ty = height*0.5 - s*cy
    return (s, tx, ty)

def apply_affine(points: List[Vec], s: float, tx: float, ty: float) -> List[Vec]:
    return [(s*p[0]+tx, s*p[1]+ty) for p in points]

def coxeter_number(component: str) -> int:
    c = component.strip().upper()
    if c.startswith("A"):
        n = int(c[1:]); return n+1
    if c.startswith("D"):
        n = int(c[1:]); return 2*(n-1)
    if c == "E6": return 12
    if c == "E7": return 18
    if c == "E8": return 30
    return 12

def angles_for_spec(spec: str) -> List[float]:
    # choose base step as 2pi / max_h across components to share a common grid
    comps = [t for t in spec.replace("+"," ").split()]
    hs = [coxeter_number(c) for c in comps]
    h = max(hs) if hs else 12
    k = h
    return [2*math.pi*i/h for i in range(k)]
