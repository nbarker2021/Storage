
# Elevator Promotion Workflow (v0.21.0)

Use `promote_elevators(repo, um, universe, threshold, compat_policy)` to process `mdhg_event::...::elevator` SNAPs:
- Decisions are made by `SnapOpsCenter` (threshold + family allow/deny).
- On promotion, a `result::mdhg_elevator` SNAP is written and the result id is added to the universe's `elevators` overlay.

CLI (`scripts/run_elevator_promotion.py`) expects `env.repo` and `env.um` modules that expose `repo` and `um` singletons.
