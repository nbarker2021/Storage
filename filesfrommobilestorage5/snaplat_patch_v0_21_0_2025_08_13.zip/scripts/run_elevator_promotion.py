
#!/usr/bin/env python3
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
import json, argparse
from agrm.agrm.elevator_promotion import promote_elevators

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--universe", required=True)
    ap.add_argument("--threshold", type=float, default=1.0)
    ap.add_argument("--allow", nargs="*", default=[])
    ap.add_argument("--deny", nargs="*", default=[])
    ns = ap.parse_args()

    # Expect the embedding environment to provide repo & um singletons
    from importlib import import_module
    repo = import_module("env.repo").repo
    um   = import_module("env.um").um

    out = promote_elevators(repo, um, ns.universe, threshold=ns.threshold,
                            compat_policy={"family_allow": ns.allow, "family_deny": ns.deny})
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
