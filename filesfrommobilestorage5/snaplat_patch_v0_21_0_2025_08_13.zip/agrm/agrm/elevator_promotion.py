
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from typing import Dict, Any, List, Iterable
import time

from agrm.snap.ops_center import SnapOpsCenter

def _iter_elevator_events(repo, universe: str) -> Iterable[Dict[str,Any]]:
    prefix = f"mdhg_event::{universe}::elevator::"
    # Generic iteration fallback: try repo.list(prefix) else scan repo.store keys (dummy repos)
    keys = []
    if hasattr(repo, "list"):
        try:
            keys = list(repo.list(prefix))
        except Exception:
            keys = []
    elif hasattr(repo, "store"):
        keys = [k for k in repo.store.keys() if str(k).startswith(prefix)]
    elif hasattr(repo, "keys"):
        keys = [k for k in repo.keys() if str(k).startswith(prefix)]
    events = []
    for k in keys:
        try:
            rec = repo.load(k)
            if rec.get("meta", {}).get("family") == "mdhg_event" and rec.get("meta", {}).get("type") == "elevator_candidate":
                events.append(rec)
        except Exception:
            continue
    return events

def promote_elevators(repo, um, universe: str, *, threshold: float=1.0, compat_policy: Dict[str,Any]=None) -> Dict[str,Any]:
    ops = SnapOpsCenter(elevator_threshold=threshold, compat_policy=compat_policy or {})
    events = _iter_elevator_events(repo, universe)
    promoted, rejected = 0, 0
    results = []
    for ev in events:
        cand = ev.get("content", {})
        dec = ops.review_elevator(cand | {"score": ev.get("meta", {}).get("tags", {}).get("score", 0.0)})
        if dec.promoted:
            promoted += 1
            rid = f"result::elevator::{universe}::{int(time.time())}::{promoted}"
            repo.save(rid, {"meta":{"snap_id": rid, "family":"result", "type":"mdhg_elevator", "tags":{"universe": universe}},
                            "content": cand})
            results.append(rid)
            # optional: attach to universe overlays
            try:
                u = um.get_universe(universe)
                ov = u.overlays.get("elevators", [])
                ov.append(rid)
                u.overlays["elevators"] = sorted(set(ov))
                um.save_universe(u)
            except Exception:
                pass
        else:
            rejected += 1
    return {"promoted": promoted, "rejected": rejected, "results": results}
