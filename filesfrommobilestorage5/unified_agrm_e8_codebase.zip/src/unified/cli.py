
import argparse
from unified.agrm.runner import main as agrm_main

def main():
    parser = argparse.ArgumentParser(description="Unified solver CLI (AGRM + E8 scaffold)")
    parser.add_argument("--use-e8", action="store_true", help="(future) enable E8 lattice integration (not implemented)")
    parser.add_argument("args", nargs=argparse.REMAINDER, help="args forwarded to AGRM runner")
    ns = parser.parse_args()
    if ns.use_e8:
        print("E8 integration not yet implemented; running AGRM-only.")
    # Forward to existing AGRM runner
    return agrm_main()

if __name__ == "__main__":
    main()
