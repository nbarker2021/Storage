
# Shelling & Glyphs (SnapLat A.1)
- `shell(meta, max_n=5)` → levels `n=1..5` via atomization and coalescence
- `to_three_words(level)` → derive 3-word base from top-level
- `compress(levels, meta)` / `inflate(glyph)` / `invert(glyph)`

This pass uses lightweight heuristics. Swap `_top_terms` for stronger extraction later.
