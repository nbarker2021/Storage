
# AGRM Full Sweeps (SnapLat A.2)
`simulate_sweeps(points, rounds=2, x=8)` partitions into angular arms, connects by radius to build heat,
and applies tiny boundary rotation when arms are imbalanced. Controller enables this with `use_sweeps_full`.
