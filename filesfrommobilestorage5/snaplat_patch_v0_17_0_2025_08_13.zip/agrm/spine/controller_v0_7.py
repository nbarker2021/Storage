
import numpy as np
from typing import Dict, Any
from agrm.policy.policy_bus import check_policy
from agrm.agrm.sweeps import simulate_sweeps
from agrm.mdhg.hotmap import HotMap

def _summary(points: np.ndarray) -> Dict[str,Any]:
    return {"N": int(points.shape[0]), "dims": int(points.shape[1]) if points.ndim==2 else 0}

class AGRMController_v0_7_2025_08_13:
    def __init__(self, cfg: Dict[str,Any] = None, repo=None, policies: Dict[str,Any] = None):
        self.cfg = cfg or {}
        self.repo = repo
        self.policies = policies or {}

    def solve(self, points: np.ndarray, max_ticks:int=1) -> Dict[str,Any]:
        dec = check_policy(self.policies, {"family": self.cfg.get("family", []), "type": self.cfg.get("type", []), "tags": self.cfg.get("tags", {})})
        if not dec.allow:
            return {"ok": False, "reason": dec.reason}
        summary = _summary(points)
        if bool(self.cfg.get("use_sweeps_full", False)) and points.size>0:
            out = simulate_sweeps(points, rounds=int(self.cfg.get("rounds",2)), x=int(self.cfg.get("arms",8)))
            summary["sweeps_full"] = {"rounds": out["rounds"], "arms": out["arms"]}
            summary["heat"] = out["heat"]
        else:
            summary["heat"] = HotMap().snapshot()
        try:
            from agrm.utils.run_manifest import write_run_manifest
            write_run_manifest(self.repo, component="controller", params=self.cfg, inputs={"N": summary["N"]}, policies=self.policies)
        except Exception:
            pass
        return summary
