
from agrm.shelling.engine import shell, to_three_words
from agrm.glyphs.codec import compress, inflate, invert

def test_shell_basic_roundtrip():
    meta = {"family":"doc","type":"fact","content":{"text":"Golden ratio modulation for lattice navigation. Shelling compresses complex ideas to three words."}}
    levels = shell(meta, max_n=5)
    assert len(levels) == 5
    g = compress(levels, meta=meta)
    skel = inflate(g)
    assert [l.n for l in skel] == [1,2,3,4,5]

def test_three_words_nonempty():
    meta = {"content":{"text":"E8 lattice glyph compression yields concise representations."}}
    levels = shell(meta, max_n=3)
    words = to_three_words(levels[-1])
    assert len(words) == 3
    assert any(w != "∅" for w in words)

def test_inverse_glyph_marks_words():
    meta = {"content":{"text":"Manifold navigation via arms and heatmaps."}}
    g = compress(shell(meta, 2), meta=meta)
    g2 = invert(g)
    assert g2.key != g.key
    assert all(w.startswith("¬") or w=="∅" for w in g2.three)
