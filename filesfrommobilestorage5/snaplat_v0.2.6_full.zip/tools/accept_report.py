
import os, re, json, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
tests = list((ROOT / "tests").glob("test_*.py"))
report = []
for t in tests:
    txt = t.read_text(encoding="utf-8", errors="ignore")
    for m in re.finditer(r"@pytest\.mark\.accept\('([^']+)'\)", txt):
        report.append({"file": str(t.relative_to(ROOT)), "accept": m.group(1)})
out = ROOT / "artifacts" / "acceptance_report.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({"items": report}, indent=2), encoding="utf-8")
print(out)
