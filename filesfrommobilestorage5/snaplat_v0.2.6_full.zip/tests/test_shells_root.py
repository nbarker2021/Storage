
from snaplat.e8.shells import root_shell, oracle_count
def test_root_shell_count():
    roots = root_shell(); assert len(roots) == 240
    assert oracle_count(1) == 240
