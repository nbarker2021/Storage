# SnapLat

Core-first E8 reasoning system.