
from typing import Dict, Any, List, Tuple, Optional
from ..superperm.nav_tsp import tsp_on_root_shell, sector_cpp_then_tsp
from ..tsp.solver import weighted_metric, tour_length, close_cycle
from ..morsr.log import MORSR

class SalesmanStateBus:
    def __init__(self, pts2d: List[Tuple[float,float]]):
        self.pts2d = pts2d
        self.current_cycle: List[int] = list(range(len(pts2d))) + [0] if pts2d else []
        self.salesman_proposals: List[Dict[str, Any]] = []
        self.morsr = MORSR("artifacts/morsr/salesman.jsonl")

    def add_salesman_proposal(self, p: Dict[str, Any]): self.salesman_proposals.append(p)

    def apply_best(self, dist=None) -> Optional[Dict[str, Any]]:
        if not self.salesman_proposals: return None
        prop = self.salesman_proposals.pop(0)
        before = tour_length(self.current_cycle, dist) if self.current_cycle else 0.0
        tour = prop.get("tour") or prop.get("new_subpath_nodes") or []
        if tour and (tour[0] != tour[-1]): tour = close_cycle(tour)
        self.current_cycle = tour
        after = tour_length(self.current_cycle, dist)
        evt = {"event": "salesman_apply", "before": before, "after": after, "delta": after - before, "n": len(self.current_cycle)}
        self.morsr.emit(evt)
        return {"before": before, "after": after, "delta": after - before}

def propose_shell_tour(state_bus: SalesmanStateBus, sample: int = 64, heat: List[float] | None = None, alpha: float = 0.0) -> Dict[str, Any]:
    res = tsp_on_root_shell(sample=sample, heat=heat, alpha=alpha)
    proposal = {"kind": "tsp_root_shell", "n": res["n"], "tsp_length": res["length"], "tour": res["tour"]}
    state_bus.add_salesman_proposal(proposal); return proposal

def propose_sectorized(state_bus: SalesmanStateBus, sample: int = 120, n_sectors: int = 30, k: int = 3, heat: List[float] | None = None, alpha: float = 0.0) -> Dict[str, Any]:
    res = sector_cpp_then_tsp(n_sectors=n_sectors, k=k, sample=sample, heat=heat, alpha=alpha)
    proposal = {"kind": "sector_cpp_then_tsp", "n": res["n"], "anchor_cycle_len_proxy": res["anchor_cycle_len_proxy"], "tour": res["ordered_nodes"]}
    state_bus.add_salesman_proposal(proposal); return proposal
