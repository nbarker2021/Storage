# SnapLat

Core-first E8 reasoning system. See Architecture for module map.