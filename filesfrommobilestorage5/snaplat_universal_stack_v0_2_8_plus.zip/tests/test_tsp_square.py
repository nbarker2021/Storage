
from snaplat.tsp.solver import solve
def test_tsp_square():
    pts = [(0,0),(1,0),(1,1),(0,1)]
    tour, L = solve(pts, start=0)
    assert len(tour) == 5  # cycle
    assert L >= 4.0 - 1e-9 and L <= 4.0 + 1e-6
