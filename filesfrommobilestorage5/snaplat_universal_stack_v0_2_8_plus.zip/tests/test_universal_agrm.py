from snaplat.agrm.plan_adapter import Action
from snaplat.agrm.universal import UniversalPlanner, DetectCfg, BudgetCfg, Scorecard
from snaplat.adapters.e8_adapter import E8Adapter
from snaplat.mdhg.bus import MDHGBus

def test_detect_two_sidecars():
    planner = UniversalPlanner(); bus = MDHGBus()
    D = planner.detect([E8Adapter(bus), E8Adapter(bus)], state={}, cfg=DetectCfg(manifold_N=2))
    assert len(D) == 2

def test_budget_respects_growth():
    schedule = [Action('neighbors','E',m=8.0), Action('project','C',m=0.5)]
    planner = UniversalPlanner(); assert planner.respects_budget(schedule, BudgetCfg(Mmax=64.0))

def test_scorecard_phi():
    sc = Scorecard(frontier_width=10, radius=2, distinct_cells=5, word_length=3, glyph_dl=0.4)
    planner = UniversalPlanner(); phi = sc.phi(planner.alpha); assert phi > 0.0
