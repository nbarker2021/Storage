
import os, pathlib
TOOLS_DIR = pathlib.Path(__file__).resolve().parent
REPO_ROOT = TOOLS_DIR.parent  # one level up from tools/
SRC_ROOT = REPO_ROOT / "src" / "snaplat"
lines = ["# Module Index\n"]
for dirpath, _, files in os.walk(SRC_ROOT):
    rel = pathlib.Path(dirpath).relative_to(SRC_ROOT)
    depth = len(rel.parts)
    if "__pycache__" in dirpath: continue
    if depth == 0:
        lines.append("- **snaplat/**")
    else:
        lines.append("  " * depth + f"- {rel}/")
    for fn in sorted(f for f in files if f.endswith(".py")):
        if fn == "__init__.py": continue
        lines.append("  " * (depth+1) + f"- {fn}")
out = REPO_ROOT / "docs" / "module_index.md"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text("\n".join(lines), encoding="utf-8")
print(out)
