from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
from .plan_adapter import PlanAdapterProto, Action, DetectorVector
from .fusion import fuse_kofn
from .diversity import diversity_score

@dataclass
class BudgetCfg:
    lambda_: float = 0.25; Mmax: float = 64.0; K: int = 2; Fmax: int = 256; DLmax: float = 3.0
@dataclass
class DetectCfg:
    manifold_N: int = 2; microK: int = 2
@dataclass
class FusionCfg:
    policy: str = 'KofN'; k: int = 2
@dataclass
class Scorecard:
    frontier_width:int=0; radius:int=0; distinct_cells:int=0; word_length:int=0; glyph_dl:float=0.0; phi_before:float=0.0; phi_after:float=0.0
    def phi(self, alpha: Dict[str,float])->float:
        return (alpha.get('W',1.0)*self.frontier_width + alpha.get('R',0.3)*self.radius + alpha.get('C',0.5)*self.distinct_cells + alpha.get('L',0.2)*self.word_length + alpha.get('D',0.8)*self.glyph_dl)
class UniversalPlanner:
    def __init__(self, alpha_weights: Dict[str,float] | None = None): self.alpha = alpha_weights or {'W':1.0,'R':0.3,'C':0.5,'L':0.2,'D':0.8}
    def detect(self, adapters: List[PlanAdapterProto], state: Dict[str,Any], cfg: DetectCfg)->List[DetectorVector]:
        out: List[DetectorVector]=[]
        for ad in adapters[:cfg.manifold_N]:
            acts=list(ad.actions().values()); E=[a for a in acts if a.tag=='E']; C=[a for a in acts if a.tag=='C']; schedule: List[Action]=[]
            if E: schedule.append(E[0]);
            if C: schedule.append(C[0]);
            trail=ad.step(schedule, state); m=trail.metrics
            out.append(DetectorVector(coverage=float(m.get('coverage',0.0)), drift=float(m.get('drift',0.0)), leakage=float(m.get('leakage',0.0)), cues={k:float(v) for k,v in m.items() if k not in ('coverage','drift','leakage')}, hotmap_delta=trail.notes.get('hotmap_delta',{}), confidence=float(m.get('confidence',1.0))))
        return out
    def fuse_with_diversity(self, D: List[DetectorVector], manifold_meta: List[dict])->Dict[str,Any]:
        div=diversity_score(manifold_meta); dets=[d.__dict__ for d in D]; F=fuse_kofn(dets, k=min(2, len(D) or 1), diversity=div); F.update({'diversity':div,'N':len(D)}); return F
    def respects_budget(self, schedule: List[Action], budget: BudgetCfg)->bool:
        m_prod=1.0; last_E_idx=-10
        for i,a in enumerate(schedule):
            if a.tag=='E': m_prod*=max(1.0,a.m); last_E_idx=i
            if a.tag=='C' and (i-last_E_idx)<=budget.K: m_prod=max(1.0, m_prod/2.0)
        return (m_prod<=budget.Mmax)
    def score(self, util: float, sc: Scorecard, budget: BudgetCfg)->float:
        return util - budget.lambda_ * sc.phi(self.alpha)
