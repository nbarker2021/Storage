from __future__ import annotations
from typing import Dict, List, Any
from dataclasses import dataclass
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..assembly.core import stitch
from ..superperm.c8 import produce_c8, C8Config
from ..dtt.harness import DTT, DTTConfig
from ..metrics.core import glyph_dl_from_weights
from ..metrics.splus import leakage_from_metrics
from ..mdhg.bus import MDHGBus
@dataclass
class AssemblyAdapter(PlanAdapterProto):
    mdhg: MDHGBus
    def actions(self) -> Dict[str, Action]: return {'barymix': Action(op='barymix', tag='C', m=0.25, est_cost=0.5)}
    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        cands=produce_c8(C8Config(seed=state.get('seed',123))); ev=DTT(DTTConfig(seed=state.get('seed',99))).run(cands)
        out=stitch(cands, ev); weights=out['DNA'].weights  # type: ignore
        dl=glyph_dl_from_weights(weights); tac=float(state.get('tac',1.0)); boundary=float(state.get('boundary',1.0)); drift=float(state.get('drift',0.0))
        leak=leakage_from_metrics({'tac':tac,'boundary':boundary,'drift':drift}); gid=out['DNA'].checksum  # type: ignore
        self.mdhg.put('asm:glyph', gid, score=1.0, notes={'dl':dl})
        return Trail(metrics={'glyph_dl':dl,'coverage':1.0,'drift':drift,'leakage':leak}, artifacts={'dna':gid}, notes={})
    def learn(self, trace: Trail) -> None: return None
