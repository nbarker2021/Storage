
import json, argparse, hashlib
from pathlib import Path
from typing import List
from .markdown_tree import parse_markdown_tree
from .graph_index import build_graph
from .retriever import build_tree_index, hybrid_retrieve
from .classifier import file_features, guess_role_universe
from .provenance import mdhg_chain, build_id
from .manifest import build_manifests

def discover_docs(root: Path) -> List[Path]:
    exts = {".md",".txt"}
    docs = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in exts and p.stat().st_size>0:
            docs.append(p)
    return docs

def build(root: Path, out: Path):
    docs = discover_docs(root)
    all_nodes = []
    for p in docs:
        all_nodes.extend(parse_markdown_tree(p))
    idf, vecs = build_tree_index(all_nodes)
    edges = build_graph(all_nodes)
    out.mkdir(parents=True, exist_ok=True)
    (out / "tree.json").write_text(json.dumps({"nodes": all_nodes}, indent=2))
    (out / "graph.json").write_text(json.dumps({"edges": edges}, indent=2))
    (out / "idf.json").write_text(json.dumps(idf, indent=2))
    (out / "vecs.json").write_text(json.dumps(vecs, indent=2))
    (out / "index_meta.json").write_text(json.dumps({"docs": [str(p) for p in docs]}, indent=2))
    # provenance
    chain = mdhg_chain(all_nodes)
    bid = build_id(chain)
    (out / "provenance.json").write_text(json.dumps({"chain": chain, "build_id": bid}, indent=2))
    return all_nodes, idf, vecs, edges

def query(out: Path, q: str, k: int = 8):
    nodes = json.loads((out / "tree.json").read_text())["nodes"]
    idf = json.loads((out / "idf.json").read_text())
    vecs = json.loads((out / "vecs.json").read_text())
    edges = json.loads((out / "graph.json").read_text())["edges"]
    results = hybrid_retrieve(q, nodes, idf, vecs, edges, topk=k)
    print(json.dumps({"query": q, "results": results}, indent=2))

def classify(root: Path, out: Path):
    records = []
    for p in root.rglob("*"):
        if p.is_file() and p.stat().st_size>0 and p.suffix.lower() in {".md",".txt",".json",".json5"}:
            feats = file_features(p)
            rec = guess_role_universe(p, feats)
            records.append({"path": str(p), **rec})
    (out / "classify.json").write_text(json.dumps(records, indent=2))

def eval_run(out: Path, gate_evidence: float = 0.6, gate_369: bool = True):
    # Simple eval: evidence@k for built-in probes + 3/6/9 coverage
    probes = [
        {"q":"n=-1 glyph compression mechanics and glyphic index", "kws":["glyph","index","n=-1","compress"]},
        {"q":"Safe Cube now anchor and dual context pinning", "kws":["safe","anchor","dual","context","pin"]},
        {"q":"3/6/9 shell checkpoints and anti-space bilayer", "kws":["shell","anti","bilayer"]}
    ]
    nodes = json.loads((out / "tree.json").read_text())["nodes"]
    idf = json.loads((out / "idf.json").read_text())
    vecs = json.loads((out / "vecs.json").read_text())
    edges = json.loads((out / "graph.json").read_text())["edges"]

    def evidence_score(results, keywords):
        text = " ".join(r.get("snippet","") + " " + r.get("title","") for r in results).lower()
        found = sum(1 for k in keywords if k in text)
        return found/len(keywords) if keywords else 0.0

    from .reranker import triad_ok, support_ok, outcome_ok
    report = []
    ci_pass = True
    for pr in probes:
        res = hybrid_retrieve(pr["q"], nodes, idf, vecs, edges, topk=8)
        ev = evidence_score(res, [k.lower() for k in pr["kws"]])
        tri = triad_ok(res); sup = support_ok(res); outc = outcome_ok(res)
        item = {"query": pr["q"], "evidence_at_k": round(ev,3), "triad": tri, "support": sup, "outcome": outc, "top_titles": [r["title"] for r in res]}
        report.append(item)
        if ev < gate_evidence: ci_pass = False
        if gate_369 and not (tri and sup and outc): ci_pass = False
    payload = {"eval": report, "ci_pass": ci_pass, "gate_evidence": gate_evidence, "gate_369": gate_369}
    (out / "eval.json").write_text(json.dumps(payload, indent=2))
    print(json.dumps(payload, indent=2))

def main():
    import argparse
    ap = argparse.ArgumentParser(description="Doc Tool (Best-of)")
    ap.add_argument("--root", type=Path, required=True, help="Root directory to scan for docs")
    ap.add_argument("--out", type=Path, required=True, help="Output directory for indices/artifacts")
    ap.add_argument("--cmd", choices=["build","query","classify","eval","manifest"], required=True)
    ap.add_argument("--q", type=str, default="")
    ap.add_argument("-k", type=int, default=8)
    ap.add_argument("--gate_evidence", type=float, default=0.6)
    ap.add_argument("--no_gate_369", action="store_true")
    args = ap.parse_args()

    if args.cmd == "build":
        nodes, idf, vecs, edges = build(args.root, args.out)
        print(json.dumps({"nodes": len(nodes), "edges": len(edges)}, indent=2))
    elif args.cmd == "query":
        if not args.q:
            raise SystemExit("--q is required for query")
        query(args.out, args.q, args.k)
    elif args.cmd == "classify":
        classify(args.root, args.out)
    elif args.cmd == "eval":
        eval_run(args.out, gate_evidence=args.gate_evidence, gate_369=(not args.no_gate_369))
    elif args.cmd == "manifest":
        build_manifests(args.root, args.out)
        print(json.dumps({"status":"ok","wrote":"tool_manifest.json"}, indent=2))

if __name__ == "__main__":
    main()
