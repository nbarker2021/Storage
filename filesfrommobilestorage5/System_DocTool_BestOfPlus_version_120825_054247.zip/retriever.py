
from typing import Dict, List
from .indexers import build_tfidf, vecize, cosine
from .families import families_for_text

def layout_score(node: Dict, target_levels=(2,3)) -> float:
    lvl = node.get("level", 1)
    if lvl in target_levels: return 1.0
    if lvl == 1: return 0.7
    if lvl >= 4: return 0.8
    return 0.9

def graph_proximity_score(node: Dict, seed_ids: set, edges: List[Dict], qfams: List[str]) -> float:
    score = 0.0
    fams = node.get("families", [])
    if fams and qfams:
        overlap = len(set(fams) & set(qfams))
        score += 0.15 * overlap
    nid = node["id"]
    neigh = [e["dst"] for e in edges if e["src"]==nid] + [e["src"] for e in edges if e["dst"]==nid]
    if any(n in seed_ids for n in neigh):
        score += 0.1
    return score

def build_tree_index(nodes: List[Dict]):
    texts = [(n.get("title","") + "\n" + n.get("refined_text","")).strip() for n in nodes]
    docs = [text.split() for text in texts]  # quick tokenization via split; refiner already reduced noise
    idf, vecs = build_tfidf(docs)
    return idf, vecs

from .reranker import rerank

def hybrid_retrieve(query: str, nodes: List[Dict], idf: Dict[str,float], vecs: List[Dict[str,float]], edges: List[Dict], topk: int = 8,
                    alpha: float = 0.75, beta: float = 0.15, gamma: float = 0.10) -> List[Dict]:
    qv = vecize(query, idf)
    # base text scores
    base_scores = [0.0] * len(nodes)
    for i,n in enumerate(nodes):
        base_scores[i] = cosine(qv, vecs[i])
    # seed set = text-strong nodes
    seed_idx = sorted(range(len(nodes)), key=lambda i: base_scores[i], reverse=True)[:max(3, topk//2)]
    seed_ids = {nodes[i]["id"] for i in seed_idx}
    qf = families_for_text(query)
    scores = []
    for i,n in enumerate(nodes):
        sc = alpha*base_scores[i] + beta*layout_score(n) + gamma*graph_proximity_score(n, seed_ids, edges, qf)
        scores.append(sc)
    ranked = sorted(range(len(nodes)), key=lambda i: scores[i], reverse=True)[:max(12, topk*2)]
    prelim = [{
        "id": nodes[i]["id"], "doc": nodes[i]["doc"], "level": nodes[i].get("level",1), "title": nodes[i].get("title",""),
        "score": round(scores[i],4), "families": nodes[i].get("families", []),
        "snippet": nodes[i].get("refined_text","")[:240]
    } for i in ranked]
    # Rerank with structure signals (degree + 3/6/9 path)
    final = rerank(prelim, edges)
    return final[:topk]
