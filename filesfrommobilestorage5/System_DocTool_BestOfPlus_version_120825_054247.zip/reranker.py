
import re
from typing import Dict, List, Tuple

SUPPORT_CUES = re.compile(r"\b(because|therefore|thus|supports?|evidence|proof|shows?)\b", re.I)
OUTCOME_CUES = re.compile(r"\b(conclusion|summary|outcome|decision|result|therefore)\b", re.I)

def triad_ok(nodes: List[Dict]) -> bool:
    return any(n.get("level",1)==2 for n in nodes)  # H2 present

def support_ok(nodes: List[Dict]) -> bool:
    # evidence cues in H3 nodes
    return any(n.get("level",1)==3 and (SUPPORT_CUES.search(n.get("title","")) or SUPPORT_CUES.search(n.get("snippet",""))) for n in nodes)

def outcome_ok(nodes: List[Dict]) -> bool:
    return any((OUTCOME_CUES.search(n.get("title","")) or OUTCOME_CUES.search(n.get("snippet",""))) for n in nodes)

def three_six_nine_bonus(nodes: List[Dict]) -> float:
    b = 0.0
    if triad_ok(nodes): b += 0.1
    if support_ok(nodes): b += 0.1
    if outcome_ok(nodes): b += 0.1
    return b

def degree_bonus(node_id: str, edges: List[Dict]) -> float:
    deg = sum(1 for e in edges if e.get("src")==node_id or e.get("dst")==node_id)
    # diminishing returns
    return min(0.15, 0.03 * (deg ** 0.5))

def rerank(initial: List[Dict], edges: List[Dict]) -> List[Dict]:
    # Apply per-item degree bonus + global 3/6/9 path bonus (spread across items)
    items = initial[:]
    # per-item
    for it in items:
        it["score2"] = it["score"] + degree_bonus(it["id"], edges)
    # global bonus distributed
    bonus = three_six_nine_bonus(items)
    if bonus > 0:
        per = bonus / max(1, len(items))
        for it in items: it["score2"] += per
    items = sorted(items, key=lambda x: x["score2"], reverse=True)
    return items
