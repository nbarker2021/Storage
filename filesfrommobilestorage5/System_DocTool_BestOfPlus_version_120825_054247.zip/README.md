
# Doc Tool — Tree/Graph RAG (MORSR-aligned)

## Install
No install needed here—run in this environment with:

```bash
python -m doc_tool.cli --root /mnt/data --out /mnt/data/doc_build --cmd build
python -m doc_tool.cli --root /mnt/data --out /mnt/data/doc_build --cmd query --q "Safe Cube dual context pinning" -k 6
python -m doc_tool.cli --root /mnt/data --out /mnt/data/doc_build --cmd classify
```

## Components
- Refiner: sentence-level novelty filter (min_new=4, max_keep=10)
- Markdown Tree: headings → nodes (id, doc, level, title, parent, position, raw/refined)
- Graph Index: parent-child edges + cross-doc family edges (E8/GLYPH/MORSR/SNAP/SAFE/...)
- Hybrid Retriever: text tf-idf + layout depth + graph proximity
- Logic Chain Classifier: pre-review file classification

## Notes
- This build intentionally avoids external deps to run offline here.
- PDFs/layout-aware ingestion can be added later with a VRDU encoder.
