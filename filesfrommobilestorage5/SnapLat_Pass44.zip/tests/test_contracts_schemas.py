from ops.contracts.schemas import validate_step, validate_transcript, validate_workorder

def test_validate_step_roundtrip():
    s = validate_step({"op":"mdhg.to_points","payload":{"seed":7}})
    assert s.op=="mdhg.to_points" and "seed" in s.payload

def test_validate_transcript_minimal():
    t = validate_transcript({"ok": True, "steps": [{"op":"x"}], "counts": {"a":1}})
    assert t.ok and t.steps[0].op=="x"

def test_validate_workorder():
    w = validate_workorder({"steps":[{"op":"porter.deliver"}], "snap_ids":["s1"]})
    assert w.snap_ids==["s1"] and w.steps[0].op=="porter.deliver"
