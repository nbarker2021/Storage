from ops.contracts.schemas import validate_step

# Pass 44 step schema check
try:
    for _s in (locals().get('steps') or []):
        if isinstance(_s, dict): validate_step(_s)
except Exception:
    pass
