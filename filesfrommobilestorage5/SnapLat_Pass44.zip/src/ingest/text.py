from __future__ import annotations
import re
from typing import Dict, List, Tuple
from collections import defaultdict, deque

WORD = re.compile(r"[A-Za-z0-9_]+")

def tokenize(s: str) -> List[str]:
    return [w.lower() for w in WORD.findall(s)]

def build_graph_from_text(s: str, window: int = 5) -> Tuple[int, List[Tuple[int,int]]]:
    """Return (n, edges) by word co-occurrence within a sliding window."""
    toks = tokenize(s)
    idx: Dict[str, int] = {}
    def get_id(t: str) -> int:
        if t not in idx: idx[t] = len(idx)
        return idx[t]
    q: deque[int] = deque()
    edges: set[Tuple[int,int]] = set()
    for t in toks:
        nid = get_id(t)
        for j in q:
            a, b = sorted((nid, j))
            if a != b: edges.add((a, b))
        q.append(nid)
        if len(q) > max(1, window): q.popleft()
    return len(idx), sorted(edges)
