from ops.contracts.schemas import validate_transcript, validate_workorder
import re
class Policy:
    rw_lambda_h: float = 0.15
    rw_require_true_tags: bool = False
    adopt_advisory: bool = False


# policy fields will be patched by earlier passes; placeholder here

# Pass 44 schema guard
try:
    _ = validate_transcript(getattr(transcript, '__dict__', {'ok': getattr(transcript,'ok', False), 'steps': [], 'counts': {}}))
except Exception:
    pass
