from __future__ import annotations
from typing import List, Tuple
def degree_distribution(n: int, edges: List[Tuple[int,int]]):
    deg = [0]*n
    for i,j in edges:
        if 0<=i<n and 0<=j<n:
            deg[i]+=1; deg[j]+=1
    return deg
def redundancy_ratio(n: int, edges: List[Tuple[int,int]]):
    deg = degree_distribution(n, edges)
    return sum(1 for d in deg if d>=2) / max(1,n)
def neg_conflict_proxy(n: int, edges: List[Tuple[int,int]]):
    # simple proxy
    return 1.0 - redundancy_ratio(n, edges)

def neg_conflict(n: int, edges: List[Tuple[int,int]], *, signs: Dict[Tuple[int,int], int] | None = None, bridges: List[Tuple[int,int]] | None = None) -> float:
    """Estimate contradiction rate.
    - If `signs` provided (edge polarity in {+1,-1}), compute fraction of triangles with negative product (odd negatives).
    - Else fallback to proxy using degree imbalance and low triangle closure.
    - If `bridges` provided, upweight conflicts incident to bridge edges.
    Returns value in [0,1].
    """
    # Normalize edge keys
    eset = set(tuple(sorted(e)) for e in edges)
    # Build adjacency
    adj = {i:set() for i in range(n)}
    for i,j in eset:
        adj[i].add(j); adj[j].add(i)
    # Triangle-based measure if signs given
    tri_total = 0
    tri_neg = 0
    if signs:
        # normalize signs keys
        sgn = {tuple(sorted(k)): (1 if v>=0 else -1) for k,v in signs.items() if isinstance(v,(int,float))}
        for i in range(n):
            for j in adj[i]:
                if j<=i: continue
                # common neighbors form triangles
                cn = adj[i].intersection(adj[j])
                for k in cn:
                    if j<k and i<j:  # count each triangle once
                        tri_total += 1
                        prod = sgn.get(tuple(sorted((i,j))),1) * sgn.get(tuple(sorted((j,k))),1) * sgn.get(tuple(sorted((i,k))),1)
                        if prod < 0:
                            tri_neg += 1
        if tri_total>0:
            base = tri_neg/tri_total
        else:
            base = 0.0
    else:
        # Fallback: contradiction proxy = 1 - clustering * redundancy
        deg = degree_distribution(n, edges)
        # simple global clustering estimate via triplets closed ratio (cheap proxy)
        closed = 0; trip = 0
        for i in range(n):
            di = len(adj[i])
            if di>=2:
                nbrs = list(adj[i])
                trip += di*(di-1)/2
                # count closed among neighbors (cheap: intersection sizes)
                inter = 0
                s = adj[i]
                for a_idx in range(di):
                    a = nbrs[a_idx]
                    for b_idx in range(a_idx+1, di):
                        b = nbrs[b_idx]
                        if b in adj[a]:
                            inter += 1
                closed += inter
        clustering = (closed/trip) if trip>0 else 0.0
        base = max(0.0, 1.0 - clustering * (redundancy_ratio(n, edges)))
    # Bridge upweighting if provided
    if bridges:
        bset = set(tuple(sorted(e)) for e in bridges)
        incident = 0
        for i,j in eset:
            if (i,j) in bset:
                incident += 1
        if len(eset)>0:
            w = min(0.5, incident/len(eset))  # cap upweighting
            base = min(1.0, base*(1.0 + w))
    return float(max(0.0, min(1.0, base)))
