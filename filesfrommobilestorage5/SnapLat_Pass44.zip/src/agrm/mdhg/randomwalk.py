# placeholder; previous passes should have added functions

def derive_tags(n: int):
    """Best-effort fetch of weyl/hemisphere tags from Universe; fallback to cyclic tags.
    Returns (weyl_tags, hem_tags, true_tags)."""
    bias_weyl = [i % 8 for i in range(n)]
    bias_hem = [i % 4 for i in range(n)]
    true_tags = False
    try:
        from agrm.space.api import get_default_universe
        u = get_default_universe()
        if u and hasattr(u, 'weyl_index_for') and hasattr(u, 'hemisphere_for'):
            bias_weyl = [int(u.weyl_index_for(i)) for i in range(n)]
            bias_hem = [int(u.hemisphere_for(i)) for i in range(n)]
            true_tags = True
    except Exception:
        pass
    return bias_weyl, bias_hem, true_tags

def power_iter_rw(n: int, edges, teleport=None, alpha: float = 0.15, bias_deg: float = 0.0,
                  bias_weyl=None, bias_hem=None, lambda_w: float = 0.25, lambda_h: float = 0.15, iters: int = 50):
    # minimal safe fallback to keep module importable if earlier passes missing.
    return [1.0/max(1,n)] * n

def rank_by_random_walk(n: int, edges, **kw):
    scores = power_iter_rw(n, edges, **kw)
    return {i: scores[i] for i in range(n)}

def rw_scores_with_e8(n: int, edges, *, alpha: float=0.15, lambda_w: float=0.25, lambda_h: float=0.15, iters: int=50):
    wy, hm, _tags_ok = derive_tags(n)
    return rank_by_random_walk(n, edges, alpha=alpha, bias_deg=1.0, bias_weyl=wy, bias_hem=hm, lambda_w=lambda_w, lambda_h=lambda_h, iters=iters)
