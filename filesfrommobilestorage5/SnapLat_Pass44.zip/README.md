
### Contracts & Schemas
Lightweight validators under `ops/contracts/schemas.py` provide `validate_step`, `validate_transcript`, and `validate_workorder` for cross-module payloads.

### Advisory adoption (opt-in, re-order only)
In policy set `adopt_advisory=true`; optional `rw_require_true_tags=true` to only use RW hints when Universe exposes real tags.

### Improved `neg_conflict`
In `agrm/metrics/coverage.py`:
- If edge `signs` are available, we compute the fraction of **negative triangles** (odd number of negative edges) as a contradiction proxy.
- Otherwise we fall back to a clustering×redundancy complement proxy.
- Optional `bridges` list upweights conflicts incident to bridge edges.

### Scout queue advisory adoption
- `scout/queue.py` provides `reorder_by_hints(queue, ranking, key)` and `extract_node_id` helper.
- When policy `adopt_advisory=true`, you can re-order Scout queues using `scout.rw.hints` rankings. Reordering is logged via `scout.queue.reordered`.
