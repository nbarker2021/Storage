import re
class Policy:
    rw_lambda_h: float = 0.15
    rw_require_true_tags: bool = False
    adopt_advisory: bool = False


# policy fields will be patched by earlier passes; placeholder here
