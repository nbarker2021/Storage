
### Contracts & Schemas
Lightweight validators under `ops/contracts/schemas.py` provide `validate_step`, `validate_transcript`, and `validate_workorder` for cross-module payloads.

### Advisory adoption (opt-in, re-order only)
In policy set `adopt_advisory=true`; optional `rw_require_true_tags=true` to only use RW hints when Universe exposes real tags.
