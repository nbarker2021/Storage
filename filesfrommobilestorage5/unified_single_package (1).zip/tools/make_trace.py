
import yaml, json, sys
from pathlib import Path

def main(repo_root: str):
    root = Path(repo_root)
    docmap = yaml.safe_load((root / "docs" / "DOCMAP.yaml").read_text(encoding="utf-8"))
    lines = ["# Code↔Docs Traceability\n"]
    for code_rel, docs in sorted(docmap.items()):
        lines.append(f"## {code_rel}")
        for d in docs:
            lines.append(f"- {d}")
        lines.append("")
    out = root / "TRACE.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    print(str(out))

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv)>1 else ".")
