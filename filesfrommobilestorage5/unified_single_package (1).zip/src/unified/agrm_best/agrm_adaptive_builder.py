
from typing import List, Tuple, Dict
import math
from agrm_modulation_and_legalgraph import AGRMLegalGraph

class AGRMAdaptiveBuilder:
    def __init__(self, nodes: Dict[int, Tuple[float, float]], modulator=None, feedback_bus=None):
        self.nodes = nodes
        self.legal_graph = AGRMLegalGraph(nodes)
        self.modulator = modulator
        self.feedback_bus = feedback_bus
        self.path: List[int] = []

    def build_path(self, start_node: int = None) -> List[int]:
        print("[AdaptiveBuilder] Constructing adaptive legality-aware path...")
        all_nodes = set(self.nodes.keys())
        current = start_node if start_node is not None else list(all_nodes)[0]
        visited = {current}
        path = [current]

        while len(path) < len(all_nodes):
            candidates = [
                n for n in all_nodes - visited
                if self.legal_graph.is_legal(current, n, self.modulator, self.feedback_bus)
            ]
            if not candidates:
                if self.feedback_bus:
                    self.feedback_bus.broadcast("builder_stuck", {"at": current})
                    self.feedback_bus.log_failure(current)
                break

            next_node = min(
                candidates,
                key=lambda nid: self._dist(self.nodes[current], self.nodes[nid])
            )
            path.append(next_node)
            visited.add(next_node)
            current = next_node

        self.path = path
        return path

    def get_last_path(self):
        return self.path

    def _dist(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])
