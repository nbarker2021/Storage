
import math
from typing import List, Dict, Tuple

class AGRMCoreModulator:
    def __init__(self):
        self.previous_distance = None
        self.entropy_slope = 0
        self.entropy_slope_drops = 0
        self.shell_failure_count = 0
        self.shell_failure_limit = 3
        self.last_feedback_signal_count = 0
        self.entropy_floor = 0.04
        self.gradient_threshold = 2.0
        self.hysteresis_delay = 3
        self.hysteresis_buffer = []

    def compute_entropy_slope(self, history: List[float]):
        if len(history) < 3:
            return 0.0
        recent = history[-3:]
        slope = (recent[-1] - recent[0]) / max(1, abs(recent[0]))
        self.entropy_slope = slope
        return slope

    def detect_shell_failure(self, feedback_count: int):
        if feedback_count == 0:
            self.shell_failure_count += 1
        else:
            self.shell_failure_count = 0
        return self.shell_failure_count >= self.shell_failure_limit

    def detect_entropy_floor(self):
        return self.entropy_slope < self.entropy_floor

    def should_trigger_reset(self, feedback_count: int, current_distance: float, history: List[float]):
        slope = self.compute_entropy_slope(history)
        self.hysteresis_buffer.append(current_distance)
        if len(self.hysteresis_buffer) > self.hysteresis_delay:
            self.hysteresis_buffer.pop(0)

        if self.detect_shell_failure(feedback_count):
            print("[AGRMCore] Shell failure detected — reroute required.")
            return True

        if self.detect_entropy_floor():
            print(f"[AGRMCore] Entropy floor breached (slope={slope:.5f}) — reroute required.")
            return True

        return False
