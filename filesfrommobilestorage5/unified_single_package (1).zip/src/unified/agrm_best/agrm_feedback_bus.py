
from collections import defaultdict

class AGRMFeedbackBus:
    def __init__(self):
        self.buffer = []
        self.memory = defaultdict(int)

    def broadcast(self, signal: str, payload: dict = None):
        entry = {"signal": signal, "payload": payload or {}}
        self.buffer.append(entry)

    def collect_all(self):
        all_signals = self.buffer[:]
        self.buffer.clear()
        return all_signals

    def log_failure(self, node_id: int):
        self.memory[node_id] += 1

    def get_memory_map(self):
        return dict(self.memory)

    def get_most_failed_nodes(self, threshold: int = 3):
        return [nid for nid, count in self.memory.items() if count >= threshold]

    def print_summary(self):
        print("[FeedbackBus] Summary of memory map:")
        for nid, count in self.memory.items():
            if count > 0:
                print(f"  Node {nid} failed {count} times")
