
import math
from typing import Tuple, Dict, List

class AGRMSpiralReentryEngine:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()
        self.reentry_path: List[int] = []

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def generate_fallback_path(self, from_node: int) -> List[int]:
        print("[SpiralReentry] Generating fallback inward spiral...")
        sorted_nodes = sorted(
            self.nodes.items(),
            key=lambda item: self._distance(self.center, item[1])
        )
        self.reentry_path = [n for n, _ in sorted_nodes if n != from_node]
        self.reentry_path.insert(0, from_node)
        return self.reentry_path

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])
