
import argparse
import os
import json
from tsp_node_loader import select_tsp_dataset
from agrm_runtime_controller import AGRMRuntimeController
from agrm_results_export import export_results_to_json

def main():
    parser = argparse.ArgumentParser(description="AGRM CLI - Final Wired Controller")
    parser.add_argument("--dataset", required=True, help="TSP dataset name (e.g. usa13509)")
    parser.add_argument("--cycles", type=int, default=100, help="Max loop cycles to run")
    parser.add_argument("--export", action="store_true", help="Export results to JSON")
    args = parser.parse_args()

    print(f"[CLI] Loading dataset: {args.dataset}")
    loader, config, _ = select_tsp_dataset(args.dataset)
    nodes = loader.get_nodes()

    print("[CLI] Initializing AGRM runtime controller...")
    controller = AGRMRuntimeController(nodes)

    print("[CLI] Running AGRM system...")
    for _ in range(args.cycles):
        done = controller.run_cycle()
        if done:
            break

    best_cost = controller.get_best_cost()
    best_path = controller.get_best_path()
    diagnostics = controller.get_diagnostics()

    print(f"[CLI] AGRM Complete. Best Path Length: {best_cost:.3f}")
    print("[CLI] Dumping Diagnostics:")
    controller.diagnostics.print_summary()

    if args.export:
        out_json = {
            "dataset": args.dataset,
            "best_cost": best_cost,
            "path": best_path,
            "diagnostics": diagnostics
        }
        fname = f"agrm_result_{args.dataset}.json"
        with open(fname, "w") as f:
            json.dump(out_json, f, indent=2)
        print(f"[CLI] Results saved to {fname}")

if __name__ == "__main__":
    main()
