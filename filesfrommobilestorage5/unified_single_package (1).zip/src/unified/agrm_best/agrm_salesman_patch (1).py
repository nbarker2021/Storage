
import math
from typing import List, Tuple, Dict


class AGRMSalesmanPatchEngine:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes

    
def patch_subpath(self, path: List[int], start_idx: int, end_idx: int, feedback_bus=None) -> List[int]:
    if start_idx >= end_idx or end_idx > len(path):
        if feedback_bus:
            feedback_bus.broadcast("patch_skipped", {"start": start_idx, "end": end_idx})
        return path

    segment = path[start_idx:end_idx]
    rest = path[:start_idx] + path[end_idx:]

    new_segment = self._nearest_neighbor_patch(segment[0], set(segment))
    if feedback_bus:
        feedback_bus.broadcast("patch_applied", {"segment": segment, "length": len(new_segment)})
    return rest[:start_idx] + new_segment + rest[start_idx:]

        if start_idx >= end_idx or end_idx > len(path):
            return path  # invalid range, return unmodified

        segment = path[start_idx:end_idx]
        rest = path[:start_idx] + path[end_idx:]

        print(f"[PatchEngine] Repairing path from idx {start_idx} to {end_idx}...")

        new_segment = self._nearest_neighbor_patch(segment[0], set(segment))
        return rest[:start_idx] + new_segment + rest[start_idx:]

    def _nearest_neighbor_patch(self, start: int, nodes_to_visit: set) -> List[int]:
        path = [start]
        nodes_to_visit.remove(start)
        current = start
        while nodes_to_visit:
            next_node = min(nodes_to_visit, key=lambda n: self._dist(self.nodes[current], self.nodes[n]))
            path.append(next_node)
            nodes_to_visit.remove(next_node)
            current = next_node
        return path

    def _dist(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return math.hypot(a[0] - b[0], a[1] - b[1])
