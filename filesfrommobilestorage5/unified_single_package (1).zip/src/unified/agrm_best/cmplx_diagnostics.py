
from collections import defaultdict
import time

class AGRMDiagnostics:
    def __init__(self):
        self.metrics = defaultdict(int)
        self.flags = {}
        self.runtime_start = None
        self.runtime_end = None
        self.event_log = []

    def mark(self, event: str, detail: str = ""):
        self.metrics[event] += 1
        if detail:
            self.event_log.append(f"{event}: {detail}")

    def flag(self, name: str, value: bool = True):
        self.flags[name] = value

    def start_timer(self):
        self.runtime_start = time.time()

    def stop_timer(self):
        self.runtime_end = time.time()

    def print_summary(self):
        print("n===== AGRM Runtime Diagnostics Summary =====")
        if self.runtime_start and self.runtime_end:
            total = self.runtime_end - self.runtime_start
            print(f"Runtime Duration: {total:.2f} seconds")
        print("Signals Fired:")
        for k, v in sorted(self.metrics.items()):
            print(f"  {k}: {v}")
        print("Critical Flags:")
        for k, v in self.flags.items():
            print(f"  {k}: {'✅' if v else '❌'}")

    def get_report(self) -> dict:
        return {
            "duration_sec": round(self.runtime_end - self.runtime_start, 3) if self.runtime_end else 0,
            "metrics": dict(self.metrics),
            "flags": dict(self.flags),
            "event_log": self.event_log[-50:]  # last 50 messages
        }

    def check_system_health(self):
    def check_system_health(self):
        expected_signals = [
            "sweep_runs", "builder_builds", "feedback_signals", "entropy_slope_drops",
            "patch_suggestions", "spiral_collapses", "reroute_triggered", "path_improved"
        ]
        print("\n[Diagnostics] System Health Check:")
        for signal in expected_signals:
            if self.metrics.get(signal, 0) == 0:
                print(f"❌ Missing Signal: {signal}")
            else:
                print(f"✅ {signal}: {self.metrics[signal]}")
    print(f"✅ {signal}: {self.metrics[signal]}")
    n
    def track_feedback(self, signal_type: str):
    self.mark(f"feedback::{signal_type}")

    def track_override(self, from_node: int, to_node: int):
    self.mark("legality_override")
    self.event_log.append(f"Override used on {from_node} -> {to_node}")

    def track_patch(self, node_ids: list):
    self.mark("patch_attempt")
    if node_ids:
    self.event_log.append(f"Patched segment: {node_ids}")
