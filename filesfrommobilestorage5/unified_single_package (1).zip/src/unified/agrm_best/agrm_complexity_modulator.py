
from typing import Dict, List, Tuple
import math

class AGRMComplexityWeightedModulator:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.weights: Dict[int, float] = {}

    def compute_weights(self, path: List[int]):
        print("[Modulator] Calculating complexity weights per node...")
        self.weights.clear()
        for i in range(1, len(path) - 1):
            a, b, c = self.nodes[path[i - 1]], self.nodes[path[i]], self.nodes[path[i + 1]]
            angle = self._angle_between(a, b, c)
            strain = abs(angle - math.pi)
            self.weights[path[i]] = strain
        self._normalize()

    def _angle_between(self, a: Tuple[float, float], b: Tuple[float, float], c: Tuple[float, float]) -> float:
        def vec(p1, p2): return (p2[0] - p1[0], p2[1] - p1[1])
        def dot(u, v): return u[0]*v[0] + u[1]*v[1]
        def mag(v): return math.hypot(v[0], v[1])

        ba = vec(b, a)
        bc = vec(b, c)
        cosine = dot(ba, bc) / (mag(ba) * mag(bc) + 1e-9)
        return math.acos(max(-1.0, min(1.0, cosine)))

    def _normalize(self):
        max_val = max(self.weights.values(), default=1e-9)
        for k in self.weights:
            self.weights[k] /= max_val

    def get_high_complexity_nodes(self, threshold: float = 0.6) -> List[int]:
        return [nid for nid, w in self.weights.items() if w >= threshold]

    def print_summary(self):
        count = len(self.weights)
        high = len(self.get_high_complexity_nodes())
        print(f"[Modulator] {high}/{count} nodes above complexity threshold.")
