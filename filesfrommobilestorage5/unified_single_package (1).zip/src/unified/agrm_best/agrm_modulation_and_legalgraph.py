
import math
from typing import List, Tuple, Dict, Set


class AGRMLegalGraph:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.legal_edges: Dict[int, Set[int]] = {n: set(nodes.keys()) - {n} for n in nodes}

    def invalidate_edge(self, a: int, b: int):
        self.legal_edges[a].discard(b)
        self.legal_edges[b].discard(a)

    def is_legal(self, a: int, b: int) -> bool:
        return b in self.legal_edges.get(a, set())

    def neighbors(self, node: int) -> Set[int]:
        return self.legal_edges.get(node, set())


class AGRMModulationController:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.shell_failures = 0
        self.unlocked_shells: Set[int] = set()
        self.dynamic_unlock_trigger = False
        self.phi = (1 + math.sqrt(5)) / 2

    def analyze_entropy(self, path: List[int]) -> float:
        # Estimate entropy of the path based on angular deltas
        deltas = []
        for i in range(1, len(path) - 1):
            a, b, c = self.nodes[path[i - 1]], self.nodes[path[i]], self.nodes[path[i + 1]]
            angle = self._angle_between(a, b, c)
            deltas.append(angle)
        return sum(abs(d - self.phi) for d in deltas) / max(1, len(deltas))

    def _angle_between(self, a: Tuple[float, float], b: Tuple[float, float], c: Tuple[float, float]) -> float:
        def v(p1, p2): return (p2[0] - p1[0], p2[1] - p1[1])
        def dot(u, v): return u[0]*v[0] + u[1]*v[1]
        def mag(v): return math.hypot(v[0], v[1])

        ba, bc = v(b, a), v(b, c)
        cosine = dot(ba, bc) / (mag(ba) * mag(bc) + 1e-9)
        angle = math.acos(max(-1, min(1, cosine)))
        return round(angle, 4)

    def unlock_shell(self, shell_idx: int):
        self.unlocked_shells.add(shell_idx)

    def should_unlock(self, shell_idx: int) -> bool:
        return shell_idx in self.unlocked_shells or self.dynamic_unlock_trigger

    def trigger_global_unlock(self):
        self.dynamic_unlock_trigger = True

    def mark_shell_failure(self):
        self.shell_failures += 1
        if self.shell_failures >= 3:
            print("[AGRM Modulation] Shell failure cascade triggered.")
            self.trigger_global_unlock()
