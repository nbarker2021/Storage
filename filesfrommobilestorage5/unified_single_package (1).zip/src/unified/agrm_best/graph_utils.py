graph_utils.py

# graph_utils.py
import networkx as nx
import logging
from utils import calculate_overlap

def build_de_bruijn_graph(kmers):
    """
    Builds a De Bruijn graph from a list of k-mers.

    Args:
        kmers (list of str): The list of k-mers.

    Returns:
        networkx.DiGraph: The constructed De Bruijn graph.
    """
    graph = nx.DiGraph()
    for kmer in kmers:
        prefix = kmer[:-1]
        suffix = kmer[1:]
        graph.add_edge(prefix, suffix)
    logging.debug(f"De Bruijn graph constructed with {graph.number_of_nodes()} nodes and {graph.number_of_edges()} edges.")
    return graph

def find_eulerian_path(graph: nx.DiGraph):
    """
    Finds an Eulerian path in the given graph.

    Args:
        graph (networkx.DiGraph): The De Bruijn graph.

    Returns:
        list of str: The nodes in the Eulerian path, or an empty list if no path is found.
    """
    try:
        path = list(nx.eulerian_path(graph))
        eulerian_path = [u for u, v in path] + [path[-1][1]]
        logging.debug(f"Eulerian path found with length {len(eulerian_path)}.")
        return eulerian_path
    except nx.NetworkXError as e:
        logging.error(f"No Eulerian path found: {e}")
        return []