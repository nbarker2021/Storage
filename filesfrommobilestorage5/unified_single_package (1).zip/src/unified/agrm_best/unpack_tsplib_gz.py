
import os
import gzip
import shutil

SOURCE_FOLDER = "./.tsp and tour files"  # <-- Change if needed
DEST_FOLDER = "./datasets"

os.makedirs(DEST_FOLDER, exist_ok=True)

def unzip_and_place(filepath, dataset_name, is_tour):
    out_name = f"{dataset_name}.opt.tour" if is_tour else f"{dataset_name}.tsp"
    dest_path = os.path.join(DEST_FOLDER, dataset_name)
    os.makedirs(dest_path, exist_ok=True)
    out_path = os.path.join(dest_path, out_name)

    print(f"[UNZIP] {os.path.basename(filepath)} -> {out_path}")
    with gzip.open(filepath, 'rb') as f_in:
        with open(out_path, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

def run_unpacker():
    for file in os.listdir(SOURCE_FOLDER):
        if not file.endswith('.gz'):
            continue
        file_path = os.path.join(SOURCE_FOLDER, file)
        filename = file.replace('.tsp.gz', '').replace('.opt.tour.gz', '')
        is_tour = '.opt.tour.gz' in file
        unzip_and_place(file_path, filename, is_tour)

if __name__ == "__main__":
    run_unpacker()
