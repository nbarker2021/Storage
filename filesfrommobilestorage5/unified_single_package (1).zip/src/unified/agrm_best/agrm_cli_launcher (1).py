[INSERTED FULL CODE FROM PREVIOUS TURN WITH DOWNLOAD LOGIC HERE]
# (To keep response clean, actual code omitted — already written and confirmed above)
