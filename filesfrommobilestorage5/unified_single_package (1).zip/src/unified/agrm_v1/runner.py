def run_once(params, seed=None):
    import random
    random.seed(seed or 0)
    n = int(params.get('n', 7))
    route = list(range(n)); random.shuffle(route)
    return {'ok': True, 'params': params, 'route': route, 'score': float(len(route))}
