from __future__ import annotations
from typing import Any, Dict, Optional, List
import time
from unified.agrm_v1 import runner as _runner

def AGRM_result_to_snapshot(res: Dict[str, Any], params: Dict[str, Any], seed: Optional[int]) -> Dict[str, Any]:
    route = res.get('route', [])
    payload = {'route': route, 'steps': [], 'score': float(res.get('score', len(route))), 'metrics': {}}
    sid = 'v1-' + str(seed or 0) + '-0'
    snap = {
        'id': sid,
        'seed': seed,
        'ts': time.time(),
        'params': params,
        'payload': payload
    }
    snap['hash'] = str(hash(str(snap['id']) + str(snap['payload'])))
    return snap

class AGRMBuilderV1:
    def build(self, instance: Dict[str, Any], *, seed: Optional[int]=None) -> Dict[str, Any]:
        params = instance.get('params', {})
        res = _runner.run_once(params, seed=seed)
        snap = AGRM_result_to_snapshot(res, params, seed)
        return {'result': res, 'snapshots': [snap]}
