
from __future__ import annotations
from typing import Dict, Any, Optional

class MDHGIndex:
    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}

    def put(self, key: str, payload: Dict[str, Any]) -> None:
        self._store[key] = payload

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        return self._store.get(key)

    def exists(self, key: str) -> bool:
        return key in self._store
