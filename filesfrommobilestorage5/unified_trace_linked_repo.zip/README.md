
# Unified Codebase: AGRM/CMPLX/MDHG/TSP + E8 Scaffold

This repository combines the working solver stack from the 81025 archive with a **non-implemented** scaffold that mirrors the E8 modules described in the E8 actualization docs.

## What's real (copied verbatim)
- `unified/agrm/core.py`, `runner.py`, `snapshots.py`, `validation.py`, `utils.py`
- `unified/cmplx/core.py`
- `unified/mdhg/index.py`
- `unified/tsp/reduce.py`

## What's scaffolded (no algorithms, per docs)
- `unified/e8/` (glyphs, shell_policy, probes, scoring, persistence/db, jobs/queue, rest/ui, tuner, governance, router, goldens)

## CLI
```bash
python -m unified.cli --help
python -m unified.cli              # runs AGRM runner (AGRM-only)
python -m unified.agrm.__main__    # original runner
```

## Integration policy
- No new algorithms were invented. E8 modules are placeholders raising NotImplementedError.
- The bridge in `unified/integration/bridge.py` only defines type contracts and passthroughs.

## Mapping to Docs
See `MAPPING.md` for a mapping from E8 doc sections to scaffolded files.
