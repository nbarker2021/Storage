
import os
def list_keys(root=".deepstore"):
    out = []
    for d,_,fs in os.walk(root):
        for f in fs:
            if not f.endswith(".meta.json"):
                out.append(os.path.relpath(os.path.join(d,f), root))
    return out

def sweep(unreachable_keys, root=".deepstore"):
    removed = []
    for k in unreachable_keys:
        p = os.path.join(root, k)
        if os.path.exists(p):
            os.remove(p)
            meta = p + ".meta.json"
            if os.path.exists(meta): os.remove(meta)
            removed.append(k)
    return removed
