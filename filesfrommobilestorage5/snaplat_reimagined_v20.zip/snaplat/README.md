
# SNAPLAT — v20
Adds:
- Deep-store GC & compaction (reachability via index)
- Resource-negative proofs (recall-over-compute metrics)
- Resilience tests (fault injection: missing chunk, queue delay)
