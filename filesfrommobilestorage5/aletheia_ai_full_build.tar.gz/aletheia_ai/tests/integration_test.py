"""
Aletheia AI - Integration Test Suite

Comprehensive validation of all system components:
1. Core geometric engine
2. DNA memory + geometric recall
3. SNAP encoding (multi-modal)
4. Self-healing governance
5. Intent slicing
6. Agent creation
7. End-to-end pipeline
8. Stress testing

Tests validate:
- Geometric correctness
- Governance enforcement
- Memory persistence
- Cross-modal similarity
- Self-healing behavior
- Provenance coverage
"""

import sys
sys.path.insert(0, '/home/ubuntu/aletheia_ai')

import numpy as np
import json
from pathlib import Path

from core.geometric_engine import GeometricEngine, ActionLattice
from memory.dna_memory import DNAMemorySystem
from encoding.snap_encoder import SNAPEncoder, DataType
from governance.self_healing import SelfHealingSystem
from aletheia import AletheiaAI


def test_geometric_engine():
    """Test core geometric engine."""
    print("\n" + "="*80)
    print("TEST 1: GEOMETRIC ENGINE")
    print("="*80)
    
    engine = GeometricEngine()
    
    # Test E8 lattice
    assert len(engine.e8.roots) == 240, "E8 should have 240 roots"
    print("✓ E8 lattice: 240 roots")
    
    # Test Leech holy construction
    leech_point = engine.leech.project_to_lattice(np.random.randn(24))
    assert len(leech_point) == 24, "Leech should be 24D"
    print("✓ Leech lattice: 24D holy construction")
    
    # Test action lattices
    vector = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    transformed = engine.actions.apply_action(vector, ActionLattice.TERNARY)
    assert transformed.shape == (8,), "Action should preserve dimension"
    print("✓ Action lattices: Transformations working")
    
    # Test remainder interpretation
    interpretation = engine.interpret_remainder(4838.82)
    assert interpretation['triple_8'], "4838.82 should have triple-8"
    assert interpretation['leech_complete'], "4838.82 should be Leech-complete"
    print(f"✓ Remainder interpretation: Triple-8 detected in 4838.82")
    
    print("\n✓✓✓ GEOMETRIC ENGINE: ALL TESTS PASSED")
    return True


def test_dna_memory():
    """Test DNA memory system."""
    print("\n" + "="*80)
    print("TEST 2: DNA MEMORY SYSTEM")
    print("="*80)
    
    memory = DNAMemorySystem(dimension=8)
    
    # Store items
    items = [
        "E8 lattice is optimal in 8D",
        "Leech lattice is optimal in 24D",
        "Digital root 7 is the attractor",
        [1, 2, 3, 4, 5, 6, 7, 8],
        [10, 20, 30, 40]
    ]
    
    node_ids = []
    for item in items:
        node_id = memory.store(item)
        node_ids.append(node_id)
    
    assert len(node_ids) == 5, "Should store 5 items"
    print(f"✓ Storage: {len(node_ids)} items stored")
    
    # Geometric recall
    similar = memory.recall("E8 is the best", k=3)
    assert len(similar) > 0, "Should find similar items"
    print(f"✓ Geometric recall: Found {len(similar)} similar items")
    
    # Cross-modal recall
    similar_nums = memory.recall([1, 2, 3, 4, 5, 6, 7, 8], k=3)
    assert len(similar_nums) > 0, "Should find similar numerical items"
    print(f"✓ Cross-modal recall: Numbers found similar items")
    
    # Snapshot and restore
    snapshot_id = memory.create_snapshot("test_snapshot")
    stats_before = memory.get_statistics()
    
    memory.store("New item")
    memory.restore_snapshot(snapshot_id)
    
    stats_after = memory.get_statistics()
    assert stats_before['total_nodes'] == stats_after['total_nodes'], "Snapshot restore should work"
    print(f"✓ Snapshot/restore: Working correctly")
    
    print("\n✓✓✓ DNA MEMORY: ALL TESTS PASSED")
    return True


def test_snap_encoding():
    """Test SNAP encoding system."""
    print("\n" + "="*80)
    print("TEST 3: SNAP ENCODING")
    print("="*80)
    
    encoder = SNAPEncoder()
    
    # Test text encoding
    text_enc = encoder.encode("E8 lattice has 240 roots")
    assert text_enc.data_type == DataType.TEXT, "Should detect text"
    assert len(text_enc.vector) == 8, "Should be 8D vector"
    print(f"✓ Text encoding: {text_enc.data_type.value}, DR={text_enc.digital_root}")
    
    # Test numerical encoding
    num_enc = encoder.encode([1, 2, 3, 4, 5])
    assert num_enc.data_type == DataType.NUMERICAL, "Should detect numerical"
    print(f"✓ Numerical encoding: {num_enc.data_type.value}, DR={num_enc.digital_root}")
    
    # Test image encoding
    fake_image = np.random.rand(32, 32, 3)
    img_enc = encoder.encode(fake_image)
    assert img_enc.data_type == DataType.IMAGE, "Should detect image"
    print(f"✓ Image encoding: {img_enc.data_type.value}, DR={img_enc.digital_root}")
    
    # Test cross-modal similarity
    corpus = [text_enc, num_enc, img_enc]
    results = encoder.cross_modal_search("E8 lattice", corpus, k=3)
    assert len(results) == 3, "Should find all items"
    print(f"✓ Cross-modal search: Found {len(results)} items")
    
    # Test serialization
    enc_dict = text_enc.to_dict()
    restored = encoder.encode.__self__.SNAPEncoding.from_dict(enc_dict)
    assert np.allclose(text_enc.vector, restored.vector), "Serialization should be lossless"
    print(f"✓ Serialization: Lossless save/restore")
    
    print("\n✓✓✓ SNAP ENCODING: ALL TESTS PASSED")
    return True


def test_self_healing():
    """Test self-healing governance."""
    print("\n" + "="*80)
    print("TEST 4: SELF-HEALING GOVERNANCE")
    print("="*80)
    
    system = SelfHealingSystem()
    
    # Create initial state
    initial_vector = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    state = system.create_state(initial_vector)
    print(f"✓ Initial state: Entropy={state.entropy:.4f}, DR={state.digital_root}")
    
    # Test entropy-decreasing transformation (should pass)
    def decrease_entropy(v):
        return v * 0.9
    
    new_state, receipt = system.commit(state, decrease_entropy, provenance=["test"])
    assert receipt.delta_phi <= 0, "Entropy should decrease or stay same"
    assert len(receipt.gates_failed) == 0, "All gates should pass"
    print(f"✓ Entropy decrease: ΔΦ={receipt.delta_phi:.4f}, gates passed={len(receipt.gates_passed)}")
    
    # Test entropy-increasing transformation (should be corrected)
    def increase_entropy(v):
        return v + np.random.randn(len(v)) * 0.5
    
    corrected_state, receipt2 = system.commit(new_state, increase_entropy, provenance=["test_bad"])
    assert receipt2.delta_phi <= 0.01, "Entropy increase should be corrected"
    print(f"✓ Self-healing: ΔΦ corrected from positive to {receipt2.delta_phi:.4f}")
    
    # Test rollback
    rolled_back = system.rollback(steps=1)
    assert rolled_back is not None, "Rollback should work"
    assert system.credits_escrowed < 500, "Credits should be deducted"
    print(f"✓ Rollback: State restored, credits={system.credits_escrowed:.1f}")
    
    # Test statistics
    stats = system.get_statistics()
    assert stats['total_operations'] >= 2, "Should have recorded operations"
    print(f"✓ Statistics: {stats['total_operations']} operations recorded")
    
    print("\n✓✓✓ SELF-HEALING GOVERNANCE: ALL TESTS PASSED")
    return True


def test_integration():
    """Test complete Aletheia AI integration."""
    print("\n" + "="*80)
    print("TEST 5: COMPLETE INTEGRATION")
    print("="*80)
    
    aletheia = AletheiaAI(memory_dimension=8, strict_governance=True, enable_worldforge=True)
    
    # Test 1: Process text
    result1 = aletheia.process("E8 lattice has 240 roots")
    assert 'encoding' in result1, "Should have encoding"
    assert 'intent' in result1, "Should have intent"
    assert 'agent' in result1, "Should have agent"
    assert 'governance' in result1, "Should have governance"
    assert 'memory' in result1, "Should have memory"
    print(f"✓ Text processing: Complete pipeline working")
    
    # Test 2: Process numerical (should recall text)
    result2 = aletheia.process([1, 2, 3, 4, 5, 6, 7, 8])
    assert result2['memory']['similar_count'] > 0, "Should find similar items"
    print(f"✓ Numerical processing: Found {result2['memory']['similar_count']} similar items")
    
    # Test 3: Process similar text (should recall both)
    result3 = aletheia.process("E8 is optimal in 8 dimensions")
    assert result3['memory']['similar_count'] >= 2, "Should find multiple similar items"
    print(f"✓ Similar text: Found {result3['memory']['similar_count']} similar items")
    
    # Test 4: Verify governance
    assert len(result1['governance']['gates_failed']) == 0, "All gates should pass"
    assert result1['governance']['delta_phi'] <= 0.01, "Entropy should be controlled"
    print(f"✓ Governance: ΔΦ={result1['governance']['delta_phi']:.4f}, all gates passed")
    
    # Test 5: Verify agents
    stats = aletheia.get_statistics()
    assert stats['agents']['total'] >= 3, "Should have created agents"
    print(f"✓ Agents: {stats['agents']['total']} created, {stats['agents']['active']} active")
    
    # Test 6: Verify memory growth
    assert stats['memory']['total_nodes'] >= 3, "Memory should grow"
    print(f"✓ Memory: {stats['memory']['total_nodes']} nodes, avg {stats['memory']['avg_neighbors']:.1f} neighbors")
    
    # Test 7: Verify visualization
    assert result1['visualization'] is not None, "Should generate visualization"
    print(f"✓ Visualization: {result1['visualization']['type']}")
    
    print("\n✓✓✓ COMPLETE INTEGRATION: ALL TESTS PASSED")
    return True


def test_stress():
    """Stress test with many operations."""
    print("\n" + "="*80)
    print("TEST 6: STRESS TEST")
    print("="*80)
    
    aletheia = AletheiaAI(memory_dimension=8, strict_governance=True, enable_worldforge=False)
    
    # Process many items
    items = [
        "E8 lattice",
        "Leech lattice",
        "Digital root 7",
        "Parity channels",
        "Weyl chambers",
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
        "Geometric recall",
        "SNAP encoding"
    ]
    
    for i, item in enumerate(items):
        result = aletheia.process(item)
        assert len(result['governance']['gates_failed']) == 0, f"Item {i} should pass governance"
    
    print(f"✓ Processed {len(items)} items successfully")
    
    # Check statistics
    stats = aletheia.get_statistics()
    assert stats['memory']['total_nodes'] == len(items), "All items should be stored"
    assert stats['agents']['total'] == len(items), "Should create agent for each"
    assert stats['governance']['avg_delta_phi'] <= 0.1, "Average entropy should be controlled"
    
    print(f"✓ Memory: {stats['memory']['total_nodes']} nodes")
    print(f"✓ Agents: {stats['agents']['total']} total, {stats['agents']['active']} active")
    print(f"✓ Governance: Avg ΔΦ={stats['governance']['avg_delta_phi']:.4f}")
    print(f"✓ Current state: Entropy={stats['current_state']['entropy']:.4f}, DR={stats['current_state']['digital_root']}")
    
    print("\n✓✓✓ STRESS TEST: ALL TESTS PASSED")
    return True


def run_all_tests():
    """Run all integration tests."""
    print("\n" + "="*80)
    print("ALETHEIA AI - COMPLETE INTEGRATION TEST SUITE")
    print("="*80)
    
    tests = [
        ("Geometric Engine", test_geometric_engine),
        ("DNA Memory", test_dna_memory),
        ("SNAP Encoding", test_snap_encoding),
        ("Self-Healing Governance", test_self_healing),
        ("Complete Integration", test_integration),
        ("Stress Test", test_stress)
    ]
    
    results = []
    for name, test_func in tests:
        try:
            passed = test_func()
            results.append((name, passed, None))
        except Exception as e:
            results.append((name, False, str(e)))
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    passed_count = sum(1 for _, passed, _ in results if passed)
    total_count = len(results)
    
    for name, passed, error in results:
        status = "✓ PASSED" if passed else "✗ FAILED"
        print(f"{status}: {name}")
        if error:
            print(f"  Error: {error}")
    
    print(f"\nTotal: {passed_count}/{total_count} tests passed")
    
    if passed_count == total_count:
        print("\n" + "="*80)
        print("✓✓✓ ALL TESTS PASSED - ALETHEIA AI IS FULLY OPERATIONAL ✓✓✓")
        print("="*80)
        return True
    else:
        print("\n" + "="*80)
        print("✗✗✗ SOME TESTS FAILED - REVIEW ERRORS ABOVE ✗✗✗")
        print("="*80)
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)

