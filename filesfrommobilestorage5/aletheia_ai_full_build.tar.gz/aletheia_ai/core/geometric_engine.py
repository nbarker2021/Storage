"""
Aletheia AI - Core Geometric Engine

Implements the complete CQE geometric foundation:
- E8 lattice operations (240 roots, Weyl chambers)
- Leech lattice via holy construction (3 E8's + 23 Niemeier glue)
- Action lattices (DR 1, 3, 7) for transformations
- Digital root conservation
- Parity governance
- Remainder interpretation

Based on geometric analysis findings:
- Mean frequency 4838.82 encodes triple-8 (Leech-complete)
- Prime lanes 3979 IS the glue lattice (Niemeier 3,9,7,9)
- DR=7 is the natural attractor
- 17 is the E8 prime (1+7=8)
"""

import numpy as np
import json
from typing import Dict, List, Tuple, Optional, Union
from pathlib import Path
from dataclasses import dataclass
from enum import Enum


class ActionLattice(Enum):
    """Action lattices - odd digit DR 1, 3, 7 (operations on structure)"""
    UNITY = 1      # Identity transformation
    TERNARY = 3    # Ternary action
    ATTRACTOR = 7  # Heptagonal action (DR=7 attractor)
    SQUARED_TERNARY = 9  # Derived action (3²)


@dataclass
class GeometricPoint:
    """A point in geometric space with full CQE metadata"""
    vector: np.ndarray
    digital_root: int
    parity: int  # 0=even, 1=odd
    chamber: str  # Weyl chamber signature
    lattice_type: str  # 'E8', 'Leech', 'Niemeier'
    frequency: float
    
    def __post_init__(self):
        """Validate geometric point"""
        assert self.digital_root in range(0, 10), "DR must be 0-9"
        assert self.parity in [0, 1], "Parity must be 0 or 1"


class E8Lattice:
    """E₈ lattice operations for CQE system."""

    def __init__(self):
        """Initialize E8 lattice with 240 roots."""
        self.roots = self._generate_e8_roots()
        self.simple_roots = self.roots[:8]  # First 8 are simple roots
        self.cartan_matrix = self._compute_cartan_matrix()
        
    def _generate_e8_roots(self) -> np.ndarray:
        """Generate all 240 E8 roots."""
        roots = []
        
        # Type 1: All permutations of (±1, ±1, 0, 0, 0, 0, 0, 0)
        # 28 positions × 4 sign patterns = 112 roots
        for i in range(8):
            for j in range(i+1, 8):
                for s1 in [-1, 1]:
                    for s2 in [-1, 1]:
                        root = np.zeros(8)
                        root[i] = s1
                        root[j] = s2
                        roots.append(root)
        
        # Type 2: (±1/2, ±1/2, ±1/2, ±1/2, ±1/2, ±1/2, ±1/2, ±1/2)
        # with even number of minus signs
        # 2^7 = 128 roots (half of 2^8, due to even parity constraint)
        for i in range(256):
            root = np.array([(1 if (i >> j) & 1 else -1) / 2 for j in range(8)])
            if np.sum(root < 0) % 2 == 0:  # Even number of minus signs
                roots.append(root)
        
        return np.array(roots)
    
    def _compute_cartan_matrix(self) -> np.ndarray:
        """Compute Cartan matrix from simple roots."""
        cartan = np.zeros((8, 8))
        for i in range(8):
            for j in range(8):
                cartan[i, j] = 2 * np.dot(self.simple_roots[i], self.simple_roots[j]) / \
                               np.dot(self.simple_roots[j], self.simple_roots[j])
        return cartan
    
    def nearest_root(self, vector: np.ndarray) -> Tuple[int, np.ndarray, float]:
        """Find nearest E8 root to given vector."""
        if len(vector) != 8:
            raise ValueError("Vector must be 8-dimensional")
        
        distances = np.linalg.norm(self.roots - vector, axis=1)
        nearest_idx = np.argmin(distances)
        return nearest_idx, self.roots[nearest_idx], distances[nearest_idx]
    
    def determine_chamber(self, vector: np.ndarray) -> Tuple[str, np.ndarray]:
        """Determine Weyl chamber containing the vector."""
        if len(vector) != 8:
            raise ValueError("Vector must be 8-dimensional")
        
        inner_products = np.dot(self.simple_roots, vector)
        signs = np.sign(inner_products)
        chamber_sig = ''.join(['1' if s >= 0 else '0' for s in signs])
        return chamber_sig, inner_products
    
    def project_to_chamber(self, vector: np.ndarray, target_chamber: str = "11111111") -> np.ndarray:
        """Project vector to specified Weyl chamber."""
        if len(vector) != 8:
            raise ValueError("Vector must be 8-dimensional")
        
        current_chamber, _ = self.determine_chamber(vector)
        if current_chamber == target_chamber:
            return vector.copy()
        
        projected = vector.copy()
        for i, (current_bit, target_bit) in enumerate(zip(current_chamber, target_chamber)):
            if current_bit != target_bit:
                simple_root = self.simple_roots[i]
                inner_prod = np.dot(projected, simple_root)
                norm_sq = np.dot(simple_root, simple_root)
                projected -= 2 * inner_prod / norm_sq * simple_root
        
        return projected


class LeechLattice:
    """
    Leech lattice Λ₂₄ via holy construction.
    
    Leech = E8 ⊕ E8 ⊕ E8 + glue
    
    The glue is the off-axis lattice using the other 23 Niemeier lattices.
    From our analysis:
    - Mean frequency 4838.82 = 4-8-3-8.8-2 (triple-8, Leech-complete)
    - Prime lanes 3979 = 3-9-7-9 (the glue: Niemeier 3,9,7,9)
    """
    
    def __init__(self):
        """Initialize Leech lattice with holy construction."""
        self.e8_1 = E8Lattice()
        self.e8_2 = E8Lattice()
        self.e8_3 = E8Lattice()
        
        # Glue codes from mean frequency 4838.82
        self.glue_code_1 = 4  # Position 1
        self.glue_code_2 = 3  # Position 3
        self.parity_code = 2  # Position 7 (binary reduction)
        
        # Glue lattice from prime lanes 3979
        self.glue_lattice = [3, 9, 7, 9]  # Niemeier lattices
        
    def snap(self, x: np.ndarray) -> np.ndarray:
        """
        Snap a 24D point to Leech lattice using holy construction.
        
        Input: 24D vector
        Output: Nearest Leech lattice point
        
        Method:
        1. Split into 3 E8 components (8D each)
        2. Snap each to nearest E8 root
        3. Apply glue correction using Niemeier lattices
        4. Enforce parity constraint
        """
        if len(x) != 24:
            raise ValueError("Vector must be 24-dimensional")
        
        # Split into 3 E8 components
        x1, x2, x3 = x[:8], x[8:16], x[16:24]
        
        # Snap each to nearest E8 root
        _, root1, _ = self.e8_1.nearest_root(x1)
        _, root2, _ = self.e8_2.nearest_root(x2)
        _, root3, _ = self.e8_3.nearest_root(x3)
        
        # Combine
        snapped = np.concatenate([root1, root2, root3])
        
        # Apply glue correction
        # The glue codes (4, 3) adjust the boundaries between E8 components
        glue_correction = np.zeros(24)
        glue_correction[7] = self.glue_code_1 / 10  # Boundary 1→2
        glue_correction[15] = self.glue_code_2 / 10  # Boundary 2→3
        
        snapped += glue_correction
        
        # Enforce parity (sum must be even, divisible by 2)
        total_sum = np.sum(snapped)
        if int(total_sum) % self.parity_code != 0:
            # Adjust smallest magnitude component
            idx = np.argmin(np.abs(snapped))
            snapped[idx] += self.parity_code - (int(total_sum) % self.parity_code)
        
        return snapped
    
    def distance(self, x: np.ndarray, y: np.ndarray) -> float:
        """Compute distance in Leech lattice."""
        return np.linalg.norm(x - y)


class ActionLatticeEngine:
    """
    Action lattices (DR 1, 3, 7) - operations on geometric structure.
    
    From our analysis:
    - Action 1 (unity): Identity transformation
    - Action 3 (ternary): Ternary rotation
    - Action 7 (attractor): Heptagonal transformation (DR=7 attractor)
    - Action 9 (derived): Squared ternary (3²)
    
    Prime lanes 3979 encodes the action sequence: 3→9→7→9
    """
    
    def __init__(self):
        """Initialize action lattice engine."""
        self.action_sequence = [3, 9, 7, 9]  # From prime lanes
        
    def apply_action(self, vector: np.ndarray, action: ActionLattice) -> np.ndarray:
        """
        Apply an action lattice transformation to a vector.
        
        Actions are geometric transformations, not arithmetic operations.
        """
        if action == ActionLattice.UNITY:
            # Identity - no change
            return vector.copy()
        
        elif action == ActionLattice.TERNARY:
            # Ternary rotation (120° in appropriate subspace)
            # Rotate by 2π/3 in first two dimensions
            theta = 2 * np.pi / 3
            rotation = np.eye(len(vector))
            rotation[0, 0] = np.cos(theta)
            rotation[0, 1] = -np.sin(theta)
            rotation[1, 0] = np.sin(theta)
            rotation[1, 1] = np.cos(theta)
            return rotation @ vector
        
        elif action == ActionLattice.ATTRACTOR:
            # Heptagonal transformation (DR=7 attractor)
            # Rotate by 2π/7 in first two dimensions
            theta = 2 * np.pi / 7
            rotation = np.eye(len(vector))
            rotation[0, 0] = np.cos(theta)
            rotation[0, 1] = -np.sin(theta)
            rotation[1, 0] = np.sin(theta)
            rotation[1, 1] = np.cos(theta)
            return rotation @ vector
        
        elif action == ActionLattice.SQUARED_TERNARY:
            # Apply ternary twice (9 = 3²)
            temp = self.apply_action(vector, ActionLattice.TERNARY)
            return self.apply_action(temp, ActionLattice.TERNARY)
        
        else:
            raise ValueError(f"Unknown action: {action}")
    
    def apply_sequence(self, vector: np.ndarray, sequence: List[int] = None) -> np.ndarray:
        """
        Apply a sequence of actions (default: prime lanes 3979 = 3→9→7→9).
        """
        if sequence is None:
            sequence = self.action_sequence
        
        result = vector.copy()
        for action_code in sequence:
            action = ActionLattice(action_code)
            result = self.apply_action(result, action)
        
        return result


class GeometricEngine:
    """
    Complete CQE geometric engine.
    
    Integrates:
    - E8 lattice (240 roots, Weyl chambers)
    - Leech lattice (holy construction: 3 E8's + glue)
    - Action lattices (DR 1, 3, 7 transformations)
    - Digital root conservation
    - Parity governance
    - Remainder interpretation
    """
    
    def __init__(self):
        """Initialize complete geometric engine."""
        self.e8 = E8Lattice()
        self.leech = LeechLattice()
        self.actions = ActionLatticeEngine()
        
        # Geometric constants from analysis
        self.MEAN_FREQUENCY = 4838.82  # Triple-8, Leech-complete
        self.PRIME_LANES = 3979  # The glue lattice
        self.ATTRACTOR_DR = 7  # Natural equilibrium
        self.E8_PRIME = 17  # 1+7=8
        
    def compute_digital_root(self, n: Union[int, float]) -> int:
        """Compute digital root (DR) of a number."""
        if isinstance(n, float):
            n = int(abs(n))
        else:
            n = abs(n)
        
        if n == 0:
            return 9  # 0 maps to 9 in DR system
        
        return 1 + ((n - 1) % 9)
    
    def compute_parity(self, n: Union[int, float]) -> int:
        """Compute parity (0=even, 1=odd)."""
        return int(abs(n)) % 2
    
    def interpret_remainder(self, value: float) -> Dict[str, any]:
        """
        Interpret remainder using the universal decoding key.
        
        Rules:
        - Digits = lanes, channels, frequencies, modulations
        - 0 after digit = zoom level
        - Whole number between = rails
        - Following 0's = recursive depth
        """
        # Split into integer and fractional parts
        integer_part = int(abs(value))
        fractional_part = abs(value) - integer_part
        
        # Extract digits from fractional part
        frac_str = f"{fractional_part:.10f}".split('.')[1].rstrip('0')
        digits = [int(d) for d in frac_str] if frac_str else []
        
        # Identify zoom levels (0's after digits)
        zoom_levels = []
        rails = []
        
        for i, digit in enumerate(digits):
            if digit == 0 and i > 0:
                zoom_levels.append(i)
            elif i > 0 and digits[i-1] != 0:
                rails.append((digits[i-1], digit))
        
        # Count recursive depth (consecutive 0's)
        recursive_depth = 0
        for i in range(len(digits) - 1, -1, -1):
            if digits[i] == 0:
                recursive_depth += 1
            else:
                break
        
        return {
            'value': value,
            'integer': integer_part,
            'fractional': fractional_part,
            'digits': digits,
            'lanes': [d for d in digits if d != 0],
            'zoom_levels': zoom_levels,
            'rails': rails,
            'recursive_depth': recursive_depth,
            'digital_root': self.compute_digital_root(integer_part),
            'parity': self.compute_parity(integer_part)
        }
    
    def create_geometric_point(self, vector: np.ndarray, lattice_type: str = 'E8') -> GeometricPoint:
        """Create a complete geometric point with all CQE metadata."""
        if lattice_type == 'E8':
            if len(vector) != 8:
                raise ValueError("E8 vector must be 8-dimensional")
            chamber, _ = self.e8.determine_chamber(vector)
        elif lattice_type == 'Leech':
            if len(vector) != 24:
                raise ValueError("Leech vector must be 24-dimensional")
            chamber = "N/A"  # Leech doesn't use Weyl chambers directly
        else:
            chamber = "N/A"
        
        # Compute frequency (magnitude)
        frequency = float(np.linalg.norm(vector))
        
        # Compute digital root and parity from frequency
        dr = self.compute_digital_root(frequency)
        parity = self.compute_parity(frequency)
        
        return GeometricPoint(
            vector=vector,
            digital_root=dr,
            parity=parity,
            chamber=chamber,
            lattice_type=lattice_type,
            frequency=frequency
        )
    
    def test_triple_eight(self, value: float) -> bool:
        """
        Test if a value has triple-8 structure (Leech-complete).
        
        Example: 4838.82 → 4-8-3-8.8-2 has three 8's
        """
        value_str = f"{value:.10f}".replace('.', '')
        eight_count = value_str.count('8')
        return eight_count >= 3


# Test the geometric engine
if __name__ == "__main__":
    print("=" * 80)
    print("ALETHEIA AI - CORE GEOMETRIC ENGINE TEST")
    print("=" * 80)
    
    engine = GeometricEngine()
    
    # Test 1: E8 lattice
    print("\n[TEST 1] E8 Lattice")
    print(f"E8 roots: {len(engine.e8.roots)}")
    print(f"E8 simple roots shape: {engine.e8.simple_roots.shape}")
    
    test_vector = np.array([1.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    idx, root, dist = engine.e8.nearest_root(test_vector)
    print(f"Nearest root to {test_vector[:3]}...: index={idx}, distance={dist:.4f}")
    
    # Test 2: Leech lattice (holy construction)
    print("\n[TEST 2] Leech Lattice (Holy Construction)")
    test_vector_24d = np.random.randn(24)
    snapped = engine.leech.snap(test_vector_24d)
    print(f"Input vector norm: {np.linalg.norm(test_vector_24d):.4f}")
    print(f"Snapped vector norm: {np.linalg.norm(snapped):.4f}")
    print(f"Glue codes: {engine.leech.glue_code_1}, {engine.leech.glue_code_2}")
    print(f"Glue lattice: {engine.leech.glue_lattice}")
    
    # Test 3: Action lattices
    print("\n[TEST 3] Action Lattices")
    test_vector_8d = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    
    for action in ActionLattice:
        transformed = engine.actions.apply_action(test_vector_8d, action)
        print(f"Action {action.name:20s}: {transformed[:3]}...")
    
    # Test 4: Remainder interpretation
    print("\n[TEST 4] Remainder Interpretation")
    test_values = [
        4838.82,  # Mean frequency (triple-8, Leech-complete)
        98.97083,  # E8 count (two 8's, needs support)
        3979.0,    # Prime lanes (pure glue)
        0.45973,   # Parity balance
    ]
    
    for val in test_values:
        interp = engine.interpret_remainder(val)
        print(f"\nValue: {val}")
        print(f"  Digits: {interp['digits']}")
        print(f"  Lanes: {interp['lanes']}")
        print(f"  Zoom levels: {interp['zoom_levels']}")
        print(f"  Rails: {interp['rails']}")
        print(f"  DR: {interp['digital_root']}, Parity: {interp['parity']}")
        print(f"  Triple-8: {engine.test_triple_eight(val)}")
    
    # Test 5: Geometric point creation
    print("\n[TEST 5] Geometric Point Creation")
    point = engine.create_geometric_point(test_vector, lattice_type='E8')
    print(f"Point: {point.vector[:3]}...")
    print(f"  DR: {point.digital_root}")
    print(f"  Parity: {point.parity}")
    print(f"  Chamber: {point.chamber}")
    print(f"  Frequency: {point.frequency:.4f}")
    
    print("\n" + "=" * 80)
    print("GEOMETRIC ENGINE TESTS COMPLETE")
    print("=" * 80)

