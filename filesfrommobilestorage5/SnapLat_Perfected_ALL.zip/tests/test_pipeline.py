from snaplat.cli.run_pipeline import run

def test_pipeline():
    out = run()
    assert out["c8"] <= 8 and out["replay_ok"]
