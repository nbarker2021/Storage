from typing import List
from .e8 import angle

def closure_score(deficiency: List[int], surplus: List[int], incompatibility: float = 0.0) -> float:
    gain = sum(1 for d, s in zip(deficiency, surplus) if d and s)
    return max(0.0, gain - incompatibility)

def coherence(a: List[float], b: List[float], min_angle: float) -> bool:
    return angle(a, b) >= min_angle
