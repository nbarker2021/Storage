import json, pathlib
from typing import Dict, Any

class Archivist:
    def __init__(self, root: str):
        self.root = pathlib.Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.index = self.root / "index.json"
        if not self.index.exists(): self.index.write_text("{}", encoding="utf-8")

    def save(self, kind: str, obj: Dict[str, Any]) -> str:
        oid = obj.get("id"); assert oid, "missing id"
        p = self.root / kind / f"{oid.replace(':','_')}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
        idx = json.loads(self.index.read_text(encoding="utf-8"))
        idx.setdefault(kind, {})[oid] = str(p)
        self.index.write_text(json.dumps(idx, indent=2, sort_keys=True), encoding="utf-8")
        return str(p)

    def load(self, kind: str, oid: str) -> Dict[str, Any]:
        idx = json.loads(self.index.read_text(encoding="utf-8"))
        p = idx.get(kind, {}).get(oid)
        if not p: raise KeyError(oid)
        return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))
