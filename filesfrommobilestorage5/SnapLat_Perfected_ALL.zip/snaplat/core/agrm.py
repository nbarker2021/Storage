import math
from typing import List, Dict

PHI = (1 + 5**0.5)/2

class PhiScheduler:
    def __init__(self, n: int):
        self.n = n; self.i = 0; self.step = max(1, int(n/PHI))

    def next(self) -> int:
        self.i = (self.i + self.step) % self.n
        return self.i

def plan_tick(mode: str) -> Dict[str, float]:
    # nominal cadences
    return {"normal":1.0, "deep":0.5, "superfast":0.1, "slow":2.0}.get(mode, 1.0)
