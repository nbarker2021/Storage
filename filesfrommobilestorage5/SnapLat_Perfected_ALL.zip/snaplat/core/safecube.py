from typing import Dict, Any

def faces_green(snapshot: Dict[str, Any]) -> bool:
    faces = snapshot.get("faces", {})
    return all(faces.get(k,{}).get("status") == "green" for k in ("legal","technical","operational","ethical"))

def gate_1729(evidence_nodes: int, required: int = 1729) -> bool:
    return evidence_nodes >= required
