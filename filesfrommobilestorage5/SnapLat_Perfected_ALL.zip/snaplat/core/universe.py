from typing import List

def to_local(x: List[float], S: float = 1.0, t: List[float] = None) -> List[float]:
    t = t or [0.0]*len(x)
    return [S*xi + ti for xi, ti in zip(x, t)]

def to_global(x: List[float], S: float = 1.0, t: List[float] = None) -> List[float]:
    t = t or [0.0]*len(x)
    return [(xi - ti)/S for xi, ti in zip(x, t)]
