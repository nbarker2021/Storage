from typing import List, Dict
import math

def triad_adequacy(triad: List[str], inverse: List[str], tests: List[str]) -> float:
    # Heuristic: uniqueness + orthogonality + evidence count
    if not triad or not inverse: return 0.0
    u = len(set(triad)) + len(set(inverse))
    ortho = 1.0 if set(triad).isdisjoint(set(inverse)) else 0.5
    ev = min(1.0, len(tests)/20.0)
    return min(1.0, (u/6.0)*ortho*0.8 + 0.2*ev)

def underverse_coverage(matrix_8x8: List[List[int]]) -> float:
    ok = sum(1 for r in matrix_8x8 for v in r if v in (0,1))
    return ok/64.0

def diversity_ok(vecs: List[List[float]], min_angle: float, angle_fn) -> bool:
    for i in range(len(vecs)):
        for j in range(i+1, len(vecs)):
            if angle_fn(vecs[i], vecs[j]) < min_angle:
                return False
    return True
