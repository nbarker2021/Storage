import math, hashlib
from typing import List, Tuple, Dict

PHI = (1 + 5**0.5)/2
GOLDEN_ANGLE = 2*math.pi*(1 - 1/PHI)

def rotate_pairs(x: List[float], k: int) -> List[float]:
    ang = k * GOLDEN_ANGLE
    out = x[:]
    for i in range(0, len(x), 2):
        a = out[i]; b = out[i+1] if i+1 < len(out) else 0.0
        out[i] = a*math.cos(ang) - b*math.sin(ang)
        if i+1 < len(out):
            out[i+1] = a*math.sin(ang) + b*math.cos(ang)
    return out

def quantize(x: List[float], q: float = 1.0) -> Tuple[int, ...]:
    return tuple(int(round(v/q)) for v in x)

def golden_hashes(x: List[float], m: int = 4, q: float = 1.0) -> List[Tuple[int, ...]]:
    return [ quantize(rotate_pairs(x, k), q) for k in range(m) ]

class CountMinSketch:
    def __init__(self, depth=4, width=1024):
        self.depth = depth; self.width = width
        self.tables = [[0]*width for _ in range(depth)]

    def _h(self, row: int, key: str) -> int:
        h = hashlib.blake2b((str(row)+key).encode(), digest_size=8).hexdigest()
        return int(h, 16) % self.width

    def add(self, key: str, count: int = 1):
        for r in range(self.depth):
            self.tables[r][self._h(r, key)] += count

    def est(self, key: str) -> int:
        return min(self.tables[r][self._h(r, key)] for r in range(self.depth))
