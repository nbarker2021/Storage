from typing import List, Dict, Any, Tuple
from .e8 import nearest_lattice_point

def boundary_walk(x0: List[float], x1: List[float], steps: int = 16) -> Dict[str, Any]:
    path = []
    # Linear interpolation; record nearest cell across steps
    for k in range(steps+1):
        t = k/steps
        x = [ (1-t)*x0[i] + t*x1[i] for i in range(len(x0)) ]
        cell = nearest_lattice_point(x)
        path.append({"x": x, "cell": cell})
    # count boundary hits (cell id changes along the path)
    changes = sum(1 for i in range(1, len(path)) if path[i]["cell"] != path[i-1]["cell"])
    return {"changes": changes, "path": path}

def evidence_yield(results: List[Dict[str, Any]]) -> float:
    if not results: return 0.0
    hits = sum(1 for r in results if r["changes"] > 0)
    return hits / len(results)
