import math
from typing import List, Tuple, Dict

Vector = List[float]
Cell = Tuple[float, ...]  # lattice point

# --- E8 root system (240 roots) ---
def e8_roots() -> List[Cell]:
    roots = []
    # 112 roots: permutations of (±1, ±1, 0^6) with all sign choices
    for i in range(8):
        for j in range(i+1, 8):
            for s1 in (-1.0, 1.0):
                for s2 in (-1.0, 1.0):
                    v = [0.0]*8
                    v[i] = s1; v[j] = s2
                    roots.append(tuple(v))
    # 128 roots: all half-integers (±1/2)^8 with even sum (sum of signs divisible by 4 → even number of +)
    from itertools import product
    for signs in product((-0.5, 0.5), repeat=8):
        # Sum of components must be integer => number of +0.5 must be even
        plus = sum(1 for s in signs if s > 0)
        if plus % 2 == 0:
            roots.append(tuple(signs))
    return roots

ROOTS = e8_roots()

def dot(a: Vector, b: Vector) -> float:
    return sum(x*y for x, y in zip(a, b))

def norm2(a: Vector) -> float:
    return dot(a, a)

def norm(a: Vector) -> float:
    return math.sqrt(norm2(a))

def add(a: Vector, b: Vector) -> Vector:
    return [x+y for x,y in zip(a,b)]

def sub(a: Vector, b: Vector) -> Vector:
    return [x-y for x,y in zip(a,b)]

def mul(a: Vector, k: float) -> Vector:
    return [x*k for x in a]

def angle(a: Vector, b: Vector) -> float:
    na = norm(a); nb = norm(b)
    if na == 0 or nb == 0: return 0.0
    c = max(-1.0, min(1.0, dot(a,b)/(na*nb)))
    return math.degrees(math.acos(c))

def _nearest_Z8_even(x: Vector) -> Cell:
    # Round to nearest integer; enforce even sum parity
    z = [round(v) for v in x]
    s = int(sum(z))
    if s % 2 == 0:
        return tuple(float(v) for v in z)
    # flip the component with largest fractional deviation
    diffs = [abs(v - zi) for v, zi in zip(x, z)]
    k = max(range(8), key=lambda i: diffs[i])
    z[k] += -1 if (x[k] < z[k]) else 1  # nudge toward x
    return tuple(float(v) for v in z)

def _nearest_Z8_half_even(x: Vector) -> Cell:
    # Shift by 0.5, round, shift back; enforce even parity on doubled sum
    y = [v - 0.5 for v in x]
    z = [round(v) for v in y]
    z = [zi + 0.5 for zi in z]
    s2 = int(round(2*sum(z)))  # sum of (±1) must be multiple of 4 (even parity on halves)
    if s2 % 2 == 0:
        return tuple(float(v) for v in z)
    # adjust the component with largest frac in y
    diffs = [abs(v - yi - 0.5) for v, yi in zip(x, [round(u) for u in y])]
    k = max(range(8), key=lambda i: diffs[i])
    # Flip by +/−1 to maintain half-grid
    z[k] += -1.0 if (x[k] < z[k]) else 1.0
    return tuple(float(v) for v in z)

def nearest_lattice_point(x: Vector) -> Cell:
    # Choose closer between integer-even and half-integer-even cosets
    a = _nearest_Z8_even(x)
    b = _nearest_Z8_half_even(x)
    da = norm2(sub(list(x), list(a)))
    db = norm2(sub(list(x), list(b)))
    return a if da <= db else b

def k_neighbors(cell: Cell, k: int = 12) -> List[Cell]:
    # Nearest neighbors at squared distance 2 are cell + root vectors of type length sqrt(2)
    # We can return the first k
    out = []
    for r in ROOTS:
        nb = tuple(ci + ri for ci, ri in zip(cell, r))
        out.append(nb)
        if len(out) >= k: break
    return out

def coxeter_project(x: Vector, axes=(0,1)) -> Tuple[float, float]:
    i, j = axes
    return float(x[i]), float(x[j])
