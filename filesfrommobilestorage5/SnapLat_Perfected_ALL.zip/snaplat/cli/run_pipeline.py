import random
from ..core.ids import new_id
from ..agents.thinktank import propose_c8
from ..agents.dtt_agent import run_pairs
from ..agents.assembly_agent import stitch_equal
from ..core.sap import arbiter_decide
from ..core.safecube import faces_green

def run(seed=123):
    rng = random.Random(seed)
    pts = [{"id": new_id("snap"), "vec": [rng.uniform(-2,2) for _ in range(8)]} for _ in range(24)]
    c8 = propose_c8(pts, min_angle=25.0)
    pairs = [{"a": c8[i]["vec"], "b": c8[(i+1)%len(c8)]["vec"]} for i in range(len(c8))]
    dtt = run_pairs(pairs, steps=24)
    stitched = stitch_equal([p["vec"] for p in c8], [p["id"] for p in c8], closure={"yield": dtt["yield"]})
    snapshot = {"faces": {k: {"status":"green"} for k in ("legal","technical","operational","ethical")}}
    decision = arbiter_decide({"safe_cube": snapshot, "high_assurance": False, "evidence_nodes": 0})
    return {"c8": len(c8), "yield": dtt["yield"], "replay_ok": stitched["replay_ok"], "arbiter": decision["decision"]}

if __name__ == "__main__":
    print(run())
