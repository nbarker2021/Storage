from typing import List, Dict, Any
from ..core.e8 import angle

def propose_c8(candidates: List[Dict[str, Any]], min_angle: float = 30.0) -> List[Dict[str, Any]]:
    chosen: List[Dict[str, Any]] = []
    for c in candidates:
        v = c.get("vec", [0]*8)
        if all(angle(v, x.get("vec",[0]*8)) >= min_angle for x in chosen):
            chosen.append(c)
        if len(chosen) == 8: break
    return chosen
