from typing import List, Dict, Any
from ..core.assembly import stitch, replay_ok

def stitch_equal(points: List[List[float]], sources: List[str], closure=None) -> Dict[str, Any]:
    w = [1.0/len(points)]*len(points)
    out = stitch(points, w, sources, closure=closure or {})
    out["replay_ok"] = replay_ok(out["dna"], points, w)
    return out
