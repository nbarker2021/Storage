from typing import List, Dict, Any
from ..core.dtt import boundary_walk, evidence_yield

def run_pairs(pairs: List[Dict[str, Any]], steps=16) -> Dict[str, Any]:
    results = []
    for p in pairs:
        results.append(boundary_walk(p["a"], p["b"], steps=steps))
    return {"results": results, "yield": evidence_yield(results)}
