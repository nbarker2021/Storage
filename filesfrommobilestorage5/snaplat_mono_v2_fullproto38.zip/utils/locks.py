import pathlib, time, contextlib

LOCKDIR = pathlib.Path("outputs/locks")
LOCKDIR.mkdir(parents=True, exist_ok=True)

@contextlib.contextmanager
def endpoint_lock(endpoint_id: str, timeout: float = 5.0):
    p = LOCKDIR / f"{endpoint_id}.lock"
    t0 = time.time()
    while p.exists() and (time.time() - t0) < timeout:
        time.sleep(0.05)
    if p.exists():
        # stale lock — best effort break
        try: p.unlink()
        except Exception: pass
    try:
        p.write_text(str(time.time()), encoding="utf-8")
        yield
    finally:
        try: p.unlink()
        except Exception: pass
