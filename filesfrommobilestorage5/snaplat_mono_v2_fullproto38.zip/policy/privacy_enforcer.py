from kernel.db import get_conn, query
from kernel.telemetry import emit

def crosswalk_allowed(src_surface:str, dst_surface:str)->bool:
    # Deny moving from person.* to public.* as a simple LawPack rule
    if src_surface.startswith("person.") and dst_surface.startswith("public."):
        emit("privacy.deny", "lawpack", {"src": src_surface, "dst": dst_surface})
        return False
    return True

def create_crosswalk(cw_id:str, kind:str, src_surface:str, dst_surface:str, policy_json:str="{}") -> bool:
    if kind=="privacy" and not crosswalk_allowed(src_surface, dst_surface):
        return False
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO crosswalks(cw_id,kind,src_surface,dst_surface,policy,created_at) VALUES(?,?,?,?,?,strftime('%s','now')*1000)", (cw_id, kind, src_surface, dst_surface, policy_json))
    conn.commit()
    emit("crosswalk.create", "policy", {"cw_id": cw_id, "kind": kind, "src": src_surface, "dst": dst_surface})
    return True
