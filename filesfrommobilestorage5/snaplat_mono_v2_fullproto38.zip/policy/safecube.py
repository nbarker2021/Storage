from kernel.telemetry import emit
import yaml, pathlib, math
from kernel.db import get_conn, query
from kernel.graph_metrics import evidence_for_endpoint
from policy import reasons as REASONS
from policy.lawpack_engine import enforce_lawpacks
from kernel.rmi_reads import recent_trails
import time, math, yaml, pathlib

REQUIRED_EDGES = 3
REQUIRED_OCTANTS = 2

def _edge_diversity(endpoint_id:str)->int:
    """Count distinct neighbor nodes from lineage touching the endpoint."""
    conn = get_conn()
    rows = query(conn, "SELECT src_id,dst_id FROM lineage_edges WHERE src_id=? OR dst_id=?", (endpoint_id, endpoint_id))
    neigh = set()
    for r in rows:
        if r['src_id'] != endpoint_id: neigh.add(r['src_id'])
        if r['dst_id'] != endpoint_id: neigh.add(r['dst_id'])
    return len(neigh)

def _octant_coverage(endpoint_id:str)->int:
    """Count distinct octants where the endpoint appears in Top‑K history/current."""
    conn = get_conn()
    octs = set()
    # current view
    rows = query(conn, "SELECT octant, choice_id FROM v_i8_topk_current WHERE choice_id=?", (endpoint_id,))
    octs.update([r['octant'] for r in rows])
    # historical
    rows = query(conn, "SELECT octant, choice_id FROM i8_topk WHERE choice_id=?", (endpoint_id,))
    octs.update([r['octant'] for r in rows])
    return len(octs)

def _lawpack_ok()->(bool,list):
    trails = recent_trails(limit=200)
    # Minimal slice: let CTO enrichment handle details; fallback to privacy consent only
    try:
        from triads.reasoning_overlays.cto.window import _enrich_slice
        slice_desc = _enrich_slice(trails)
    except Exception:
        # fallback: search for consent in trails
        consent = any((t.get('payload') or {}).get('consent') for t in trails if isinstance(t, dict))
        slice_desc = {'consent': bool(consent)}
    ok, reasons = enforce_lawpacks(slice_desc)
    return ok, reasons


def _thresholds(domain: str|None=None):
    cfgp = pathlib.Path("policy/safecube.yaml")
    edges, octs = REQUIRED_EDGES, REQUIRED_OCTANTS
    mult_e, mult_o = 1.0, 1.0
    if cfgp.exists():
        try:
            y = yaml.safe_load(cfgp.read_text(encoding='utf-8')) or {}
            edges = int(y.get('required_edges', edges))
            octs = int(y.get('required_octants', octs))
            dm = (y.get('domain_multipliers') or {})
            if domain and domain in dm:
                try:
                    mult_e = float(dm[domain].get('edges', 1.0))
                    mult_o = float(dm[domain].get('octants', 1.0))
                except Exception:
                    pass
        except Exception:
            pass
    # Apply domain multipliers, ceil to ints
    return math.ceil(edges*mult_e), math.ceil(octs*mult_o)


def _ego_metrics(endpoint_id:str)->dict:
    conn = get_conn()
    # neighbors via distinct nodes connected
    rows = query(conn, "SELECT src_id,dst_id FROM lineage_edges WHERE src_id=? OR dst_id=?", (endpoint_id, endpoint_id))
    neighbors = set(); edges = 0; deg = {}
    for r in rows:
        edges += 1
        s,d = r['src_id'], r['dst_id']
        if s != endpoint_id: neighbors.add(s); deg[s] = deg.get(s,0)+1
        if d != endpoint_id: neighbors.add(d); deg[d] = deg.get(d,0)+1
    min_deg = min(deg.values()) if deg else 0
    return {"neighbors": len(neighbors), "edges": edges, "min_degree": int(min_deg)}

def _policy_thresholds(domain: str|None=None):
    thr_edges, thr_oct = _thresholds(domain)
    # ego minima
    edges_min = 3; nodes_min = 3; deg_min = 1
    cfgp = pathlib.Path("policy/safecube.yaml")
    if cfgp.exists():
        try:
            y = yaml.safe_load(cfgp.read_text(encoding='utf-8')) or {}
            nodes_min = int(y.get('ego_min_nodes', nodes_min))
            edges_min = int(y.get('ego_min_edges', edges_min))
            deg_min = int(y.get('ego_min_degree', deg_min))
            edm = (y.get('ego_domain_multipliers') or {})
            if domain and domain in edm:
                try:
                    nodes_min = math.ceil(nodes_min * float(edm[domain].get('nodes', 1.0)))
                    edges_min = math.ceil(edges_min * float(edm[domain].get('edges', 1.0)))
                    deg_min   = math.ceil(deg_min   * float(edm[domain].get('degree',1.0)))
                except Exception:
                    pass
        except Exception:
            pass
    return thr_edges, thr_oct, nodes_min, edges_min, deg_min

def assess(payload:dict) -> (bool, dict):
    endpoint_id = (payload or {}).get('endpoint_id')
    dom = (payload or {}).get('domain')
    ev = (payload or {}).get('evidence') or {}
    thr_edges, thr_oct, nodes_min, edges_min, deg_min = _policy_thresholds(dom)
    neigh = _edge_diversity(endpoint_id) if endpoint_id else 0
    octs = _octant_coverage(endpoint_id) if endpoint_id else 0
    ego = _ego_metrics(endpoint_id) if endpoint_id else {"neighbors":0,"edges":0,"min_degree":0}
    lp_ok, lp_reasons = _lawpack_ok()
    ok = (ev.get('edges',0) >= thr_edges) and (neigh >= thr_edges) and (octs >= thr_oct)          and (ego['edges'] >= edges_min) and (ego['neighbors'] >= nodes_min) and (ego['min_degree'] >= deg_min)          and lp_ok
    details = {
        'ok': ok,
        'endpoint': endpoint_id,
        'domain': dom,
        'evidence_edges': ev.get('edges',0),
        'neighbors': neigh,
        'octants': octs,
        'ego_edges': ego['edges'],
        'ego_neighbors': ego['neighbors'],
        'ego_min_degree': ego['min_degree'],
        'thr_edges': thr_edges,
        'thr_oct': thr_oct,
        'ego_nodes_min': nodes_min,
        'ego_edges_min': edges_min,
        'ego_degree_min': deg_min,
        'lawpack_ok': lp_ok,
        'lawpack_reasons': lp_reasons,
        't': int(time.time()*1000),
    }
    reasons = []
    if ev.get('edges',0) < thr_edges:
        reasons.append(REASONS.SAFE['EVIDENCE_EDGES_LOW'])
    if neigh < thr_edges:
        reasons.append(REASONS.SAFE['NEIGHBORS_LOW'])
    if octs < thr_oct:
        reasons.append(REASONS.SAFE['OCTANTS_LOW'])
    if ego['neighbors'] < nodes_min:
        reasons.append(REASONS.SAFE['EGO_NODES_LOW'])
    if ego['edges'] < edges_min:
        reasons.append(REASONS.SAFE['EGO_EDGES_LOW'])
    if ego['min_degree'] < deg_min:
        reasons.append(REASONS.SAFE['EGO_DEGREE_LOW'])
    if not lp_ok:
        reasons.append(REASONS.SAFE['LAWPACK_BLOCK'])
    details['reasons'] = reasons
    emit('safecube.check', 'policy', details)
    return ok, details


def check(payload:dict) -> bool:
    endpoint_id = (payload or {}).get('endpoint_id')
    ev = (payload or {}).get('evidence') or {}
    neigh = _edge_diversity(endpoint_id) if endpoint_id else 0
    octs = _octant_coverage(endpoint_id) if endpoint_id else 0
    lp_ok, lp_reasons = _lawpack_ok()
    ok, details = assess(payload)
    reasons = []
    if ev.get('edges',0) < thr_edges:
        reasons.append(REASONS.SAFE['EVIDENCE_EDGES_LOW'])
    if neigh < thr_edges:
        reasons.append(REASONS.SAFE['NEIGHBORS_LOW'])
    if octs < thr_oct:
        reasons.append(REASONS.SAFE['OCTANTS_LOW'])
    if ego['neighbors'] < nodes_min:
        reasons.append(REASONS.SAFE['EGO_NODES_LOW'])
    if ego['edges'] < edges_min:
        reasons.append(REASONS.SAFE['EGO_EDGES_LOW'])
    if ego['min_degree'] < deg_min:
        reasons.append(REASONS.SAFE['EGO_DEGREE_LOW'])
    if not lp_ok:
        reasons.append(REASONS.SAFE['LAWPACK_BLOCK'])
    details['reasons'] = reasons
    emit('safecube.check', 'policy', details)
    return ok

        'endpoint': endpoint_id,
        'edges': ev.get('edges',0),
        'neighbors': neigh,
        'octants': octs,
        'thr_edges': thr_edges,
        'domain': (payload or {}).get('domain'),
        'thr_oct': thr_oct,
        'lawpack_ok': lp_ok,
        'lawpack_reasons': lp_reasons,
        't': int(time.time()*1000)
    })
    return ok
