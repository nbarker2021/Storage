
# Security — Manifests & Signing (Build 9)
- Crypto adapter supports Ed25519 (if available) or fallback mode.
- Key rotation: `make rotate-keys` (prefers Ed25519 with SNAPLAT_CRYPTO=ed25519).
- Manifest v2: adds `version`, `key_id`, `sig_mode`, `signer_fp`, `created_at` and rebinds `policy_hash`.
- Migration: `make manifests-migrate` converts legacy lockfiles to v2 and re-signs.
- DB migrator: `make db-migrate` adds indices and performs VACUUM/ANALYZE.
