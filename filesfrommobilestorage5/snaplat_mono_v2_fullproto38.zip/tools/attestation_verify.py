#!/usr/bin/env python3
import json, pathlib, sys, hmac, hashlib, glob

CAS = pathlib.Path("outputs/cas")

def _load_cas(cas_hash: str) -> dict:
    p = CAS / cas_hash[:2] / cas_hash[2:]
    obj = json.loads(p.read_text(encoding="utf-8"))
    # Recompute and confirm
    blob = json.dumps(obj, sort_keys=True, separators=(",",":")).encode("utf-8")
    h = hashlib.sha256(blob).hexdigest()
    if h != cas_hash:
        raise ValueError(f"CAS hash mismatch for {cas_hash}")
    return obj

def _manifest_verify_sig(man: dict, secret: str|None) -> bool:
    sig = (man.get("signature") or {}).get("sig")
    if not secret:
        # If no secret provided, succeed but indicate 'unchecked'
        return True
    man_u = dict(man); man_u.pop("signature", None)
    blob = json.dumps(man_u, sort_keys=True, separators=(",",":")).encode("utf-8")
    expect = hmac.new(secret.encode("utf-8"), blob, hashlib.sha256).hexdigest()
    return (sig == expect)

def _latest_attestation_for_endpoint(endpoint_id: str) -> str|None:
    idxdir = pathlib.Path("outputs/index/attest")
    if not idxdir.exists(): return None
    cands = sorted(idxdir.glob(f"{endpoint_id}-*.json"))
    if not cands: return None
    # Load the newest
    data = json.loads(cands[-1].read_text(encoding="utf-8"))
    return data.get("cas_hash")

def verify_attestation(att_cas: str|None=None, endpoint_id: str|None=None, secret: str|None=None) -> tuple[bool, dict]:
    if (att_cas is None) and endpoint_id:
        att_cas = _latest_attestation_for_endpoint(endpoint_id)
    if not att_cas:
        return False, {"error":"no attestation provided/found"}
    att = _load_cas(att_cas)
    man_cas = att.get("manifest_cas","")
    prov_cas = att.get("provenance_cas","")
    man = _load_cas(man_cas)
    prov = _load_cas(prov_cas)
    # manifest must point to provenance as well (if present)
    if man.get("provenance") and man.get("provenance") != prov_cas:
        return False, {"error":"manifest.provenance != attestation.provenance_cas", "manifest":man_cas, "provenance":prov_cas}
    sig_ok = _manifest_verify_sig(man, secret)
    ok = sig_ok
    report = {
        "attestation": att_cas,
        "endpoint_id": att.get("endpoint_id"),
        "manifest_cas": man_cas,
        "provenance_cas": prov_cas,
        "signature_checked": bool(secret),
        "signature_ok": sig_ok,
        "manifest_has_provenance": bool(man.get("provenance")),
    }
    return ok, report

def main(argv):
    import argparse, os
    ap = argparse.ArgumentParser()
    ap.add_argument("--att", help="CAS hash of attestation")
    ap.add_argument("--endpoint", help="Endpoint id (uses latest attestation index)")
    ap.add_argument("--secret", help="HMAC secret (or via env SNAPLAT_SECRET)")
    args = ap.parse_args(argv)
    secret = args.secret or os.environ.get("SNAPLAT_SECRET","")
    ok, rep = verify_attestation(att_cas=args.att, endpoint_id=args.endpoint, secret=secret)
    print(json.dumps({"ok": ok, **rep}, indent=2, sort_keys=True))
    return 0 if ok else 2

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
