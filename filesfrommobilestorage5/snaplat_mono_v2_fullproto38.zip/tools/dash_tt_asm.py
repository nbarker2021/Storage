#!/usr/bin/env python3
import sqlite3, pathlib, time
from kernel.authz import guard_rmi_read

DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/tt_asm.html")

def fetch(kind_prefix):
    if not guard_rmi_read(context={'script':'dash_tt_asm'}):
        return []
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    rows = cur.execute("SELECT created_at, kind, actor FROM trails WHERE kind LIKE ? ORDER BY created_at DESC LIMIT 200", (kind_prefix+'%',)).fetchall()
    return [dict(r) for r in rows]

def render():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    html = ["<html><head><meta charset='utf-8'><title>TT/ASM</title><style>body{font-family:sans-serif} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style></head><body>"]
    html.append("<nav style='padding:8px;background:#f0f0f0;border-bottom:1px solid #ddd'>\n  <a href='topk.html'>Top-K</a> |\n  <a href='overlays.html'>Overlays</a> |\n  <a href='lineage.html'>Lineage</a> |\n  <a href='topk_history.html'>Top-K History</a> |\n  <a href='tt_asm.html'>TT/ASM</a>\n</nav>")
    html.append("<h2>ThinkTank & Assembly events</h2>")
    tt = fetch('thinktank.')
    asm = fetch('assembly.')
    def table(rows, title):
        html.append(f"<h3>{title}</h3>")
        html.append("<table><tr><th>created_at</th><th>kind</th><th>actor</th><th>Evidence (nodes/edges)</th><th>ready</th><th>domain</th></tr>")
        import json
        for r in rows:
            evid = ""; ready = ""; dom = ""
            try:
                con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
                pr = cur.execute("SELECT payload FROM trails WHERE created_at=? AND kind=? AND actor=?", (r['created_at'], r['kind'], r['actor'])).fetchone()
                if pr:
                    pobj = json.loads(pr['payload']) if isinstance(pr['payload'], str) else pr['payload']
                    if isinstance(pobj, dict):
                        e = pobj.get('evidence') or {}
                        evid = f"{e.get('nodes','')}/{e.get('edges','')}"
                        ready = str(pobj.get('ready',''))
                        dom = str(pobj.get('domain',''))
            except Exception:
                pass
            html.append(f"<tr><td>{r['created_at']}</td><td>{r['kind']}</td><td>{r['actor']}</td><td>{evid}</td><td>{ready}</td><td>{dom}</td></tr>")
        html.append("</table>")
    table(tt, 'ThinkTank Trails')
    table(asm, 'Assembly Trails')
    html.append("</body></html>")
    OUT.write_text("\n".join(html), encoding='utf-8')

if __name__ == '__main__':
    render()
