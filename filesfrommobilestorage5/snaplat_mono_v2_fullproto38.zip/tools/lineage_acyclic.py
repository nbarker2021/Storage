#!/usr/bin/env python3
import sqlite3, collections, sys
from kernel.telemetry import emit

DB = "rmi/snaplat.db"

def has_cycle():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; cur = con.cursor()
    edges = cur.execute("SELECT src_id, dst_id FROM lineage_edges").fetchall()
    adj = collections.defaultdict(list); indeg = collections.defaultdict(int)
    nodes = set()
    for r in edges:
        u, v = r["src_id"], r["dst_id"]
        adj[u].append(v); indeg[v] += 1; nodes.add(u); nodes.add(v)
    # Kahn's topological sort
    q = collections.deque([n for n in nodes if indeg[n]==0])
    visited = 0
    while q:
        u = q.popleft(); visited += 1
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v]==0: q.append(v)
    return visited != len(nodes)

def main():
    cyc = False
    try:
        cyc = has_cycle()
    except Exception as e:
        emit("lineage.acyclic.error", "ops", {"error": str(e)})
        print("ERROR", str(e)); return 2
    emit("lineage.acyclic", "ops", {"acyclic": (not cyc)})
    print("ACYCLIC" if not cyc else "CYCLIC")
    return 0 if not cyc else 3

if __name__ == "__main__":
    raise SystemExit(main())
