#!/usr/bin/env python3
import sqlite3, pathlib, json, time
from kernel.authz import guard_rmi_read
from kernel.rmi_reads import overlays_with_counts
DB = "rmi/snaplat.db"
OUT = pathlib.Path("outputs/dash/overlays.html")

def fetch():
    if not guard_rmi_read(context={'script':'dash_overlays'}):
        return []
    rows = overlays_with_counts()
    # augment with member counts locally (deferred until RMI helper adds it)
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    cur = con.cursor()
    counts = {r['overlay_id']: r['c'] for r in cur.execute("SELECT overlay_id, COUNT(1) AS c FROM overlay_members GROUP BY overlay_id").fetchall()}
    for r in rows:
        r['members'] = counts.get(r['overlay_id'], 0)
    return rows

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    html = ["<html><head><meta charset='utf-8'><title>Overlays</title><style>body{font-family:sans-serif} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:6px}</style></head><body><nav style='padding:8px;background:#f0f0f0;border-bottom:1px solid #ddd'>
  <a href='topk.html'>Top‑K</a> |
  <a href='overlays.html'>Overlays</a> |
  <a href='lineage.html'>Lineage</a> |
  <a href='topk_history.html'>Top‑K History</a>
</nav>
"]
    html.append(f"<h2>Overlays (generated {int(time.time())})</h2>")
    html.append("<table><tr><th>overlay_id</th><th>members</th><th>tau</th></tr>")
    for r in rows:
        html.append(f"<tr><td>{r['overlay_id']}</td><td>{r['members']}</td><td>{r['tau']}</td></tr>")
    html.append("</table></body></html>")
    OUT.write_text("\n".join(html), encoding="utf-8")

if __name__ == "__main__":
    render(fetch())
