#!/usr/bin/env python3
import sqlite3, pathlib, time
from datetime import datetime
import matplotlib.pyplot as plt
from kernel.authz import guard_rmi_read

OUT = pathlib.Path("outputs/dash/topk_history.png")

def fetch():
    if not guard_rmi_read(context={'script':'topk_history'}):
        return []
    con = sqlite3.connect("rmi/snaplat.db"); con.row_factory = sqlite3.Row
    cur = con.cursor()
    rows = cur.execute("SELECT octant, created_at FROM i8_topk ORDER BY created_at").fetchall()
    return [dict(r) for r in rows]

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        OUT.write_bytes(b""); return str(OUT)
    # bin by minute per octant
    series = {i: {} for i in range(1,9)}
    for r in rows:
        t = int(r['created_at']//60000)  # minute bucket
        series[r['octant']][t] = series[r['octant']].get(t,0) + 1
    # unify x
    xs = sorted({t for s in series.values() for t in s.keys()})
    plt.figure()
    for o in range(1,9):
        ys = [series[o].get(t,0) for t in xs]
        plt.plot(xs, ys, label=f"octant {o}")
    plt.xlabel("minute bucket"); plt.ylabel("Top-K entries")
    plt.title("Top-K history by octant")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT)
    plt.close()
    return str(OUT)

if __name__ == "__main__":
    render(fetch())
