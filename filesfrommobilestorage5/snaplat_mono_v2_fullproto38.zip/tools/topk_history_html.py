#!/usr/bin/env python3
import sqlite3, json, pathlib, time
from kernel.authz import guard_rmi_read

OUT = pathlib.Path("outputs/dash/topk_history.html")

def fetch():
    if not guard_rmi_read(context={'script':'topk_history_html'}):
        return []
    con = sqlite3.connect("rmi/snaplat.db"); con.row_factory = sqlite3.Row
    cur = con.cursor()
    rows = cur.execute("SELECT octant, created_at FROM i8_topk ORDER BY created_at").fetchall()
    return [dict(r) for r in rows]

def render(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    data_json = json.dumps(rows)
    html = f"""
<html><head><meta charset='utf-8'><title>Top-K History</title>
<style>body{{font-family:sans-serif}} .legend span{{margin-right:10px; cursor:pointer}}</style>
</head><body><nav style='padding:8px;background:#f0f0f0;border-bottom:1px solid #ddd'>
  <a href='topk.html'>Top‑K</a> |
  <a href='overlays.html'>Overlays</a> |
  <a href='lineage.html'>Lineage</a> |
  <a href='topk_history.html'>Top‑K History</a>
</nav>

<h2>Top-K history (interactive)</h2>
<div class='legend'></div>
<svg id='chart' width='800' height='400' style='background:#fafafa;border:1px solid #ddd'></svg>
<script>
const rows = {data_json};
const svg = document.getElementById('chart');
const W=800,H=400,pad=40;
// bucket by minute and octant
const series = Array.from({{length:9}},()=>({{}}));
rows.forEach(r=>{{ const t=Math.floor(r.created_at/60000); series[r.octant][t]=(series[r.octant][t]||0)+1; }});
const xs = [...new Set(rows.map(r=>Math.floor(r.created_at/60000)))].sort((a,b)=>a-b);
const xmin = xs[0]||0, xmax=xs[xs.length-1]||1;
const x = t => pad + (W-2*pad) * ((t - xmin) / Math.max(1, (xmax - xmin)));
const ymax = Math.max(1, ...series.slice(1).map(s=>Math.max(0,...Object.values(s))));
const y = v => H-pad - (H-2*pad) * (v / ymax);
function pathFor(oct){
  const s=series[oct]; const pts = xs.map(t=>[x(t), y(s[t]||0)]);
  return 'M'+pts.map(p=>p[0]+','+p[1]).join(' L');
}
// axes
function line(x1,y1,x2,y2){{const l=document.createElementNS('http://www.w3.org/2000/svg','line');l.setAttribute('x1',x1);l.setAttribute('y1',y1);l.setAttribute('x2',x2);l.setAttribute('y2',y2);l.setAttribute('stroke','#333'); l.setAttribute('stroke-width','1'); svg.appendChild(l);}}
line(pad,H-pad,W-pad,H-pad); line(pad,pad,pad,H-pad);
// legend + series
const colors=['#000','#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd','#8c564b','#e377c2','#7f7f7f'];
for(let o=1;o<=8;o++){{
  const g=document.createElementNS('http://www.w3.org/2000/svg','path');
  g.setAttribute('d', pathFor(o));
  g.setAttribute('fill','none');
  g.setAttribute('stroke', colors[o]);
  g.setAttribute('stroke-width','1.5');
  g.setAttribute('data-oct', o);
  svg.appendChild(g);
  const s=document.createElement('span'); s.textContent='oct '+o; s.style.color=colors[o];
  s.onclick=()=>{{ const vis = g.getAttribute('visibility')!=='hidden'; g.setAttribute('visibility', vis?'hidden':'visible'); }};
  document.querySelector('.legend').appendChild(s);
}}
</script>
</body></html>
""";
    OUT.write_text(html, encoding='utf-8')

if __name__ == '__main__':
    render(fetch())
