import os
from triads.thinktank_dtt_assembly.assembly.publish import build_lockfile, finalize_gate

def test_finalize_gate_policy_defaults():
    ok, rs = finalize_gate({'evidence_nodes': 1729, 'evidence_edges': 3})
    assert ok

def test_build_lockfile_signs(monkeypatch, tmp_path):
    monkeypatch.setenv("SNAPLAT_SECRET", "test-secret")
    man = build_lockfile({'endpoint_id': 'ep-test', 'evidence_nodes': 1729, 'evidence_edges': 3})
    assert isinstance(man, dict)
    assert 'signature' in man and man['signature'].get('alg') == 'HS256'
