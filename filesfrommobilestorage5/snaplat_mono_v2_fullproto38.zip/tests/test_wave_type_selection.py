
from triads.morsr_wavepool.morsr import select_wave_type

def test_wave_type_logic():
    assert select_wave_type('low', True, False) == 'explore'
    assert select_wave_type('low', False, False) == 'explore'
    assert select_wave_type('high', False, True) == 'exploit'
    assert select_wave_type('medium', False, False) == 'refine'
