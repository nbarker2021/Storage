import subprocess, json, pathlib
import policy.safecube as sc

def test_healthcare_blocks_without_consent(monkeypatch, tmp_path):
    # Fresh DB, ingest NO consent
    subprocess.check_call(['python','tools/seed_fixture_db.py'])
    # Overwrite consent with false to simulate missing
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_no_consent.json'])
    # Set low thresholds
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epX","evidence":{"edges":2},"domain":"healthcare"})
    assert not ok and 'law' in ''.join(details.get('reasons',[])).lower()

def test_healthcare_allows_with_consent(monkeypatch, tmp_path):
    subprocess.check_call(['python','tools/seed_fixture_db.py'])
    subprocess.check_call(['python','tools/ingest_fixture.py','fixtures/law/ingest_consent.json'])
    monkeypatch.setattr(sc, "_thresholds", lambda domain=None: (1,1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 2)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 2)
    monkeypatch.setattr(sc, "_ego_metrics", lambda eid: {"neighbors":2,"edges":2,"min_degree":1})
    ok, details = sc.assess({"endpoint_id":"epY","evidence":{"edges":2},"domain":"healthcare"})
    assert ok
