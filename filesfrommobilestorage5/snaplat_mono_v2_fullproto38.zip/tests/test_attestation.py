from triads.sap_snapops_archivist.archivist.attest import write_attestation

def test_attestation_write_smoke():
    h = write_attestation('epA', 'casM', 'casP', {'alg':'HS256','sig':'deadbeef'})
    assert isinstance(h, str) and len(h) > 0
