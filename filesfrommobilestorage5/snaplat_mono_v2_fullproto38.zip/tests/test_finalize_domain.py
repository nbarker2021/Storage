import pathlib, yaml
from triads.thinktank_dtt_assembly.assembly.publish import finalize_gate

def test_finalize_domain_multipliers(tmp_path, monkeypatch):
    # write finalize policy with domain multipliers
    p = pathlib.Path("policy/finalize.yaml"); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("min_evidence_nodes: 2\nmin_evidence_edges: 2\ndomain_multipliers:\n  governance: {edges: 1.5}\n", encoding="utf-8")
    ok, rs = finalize_gate({'evidence_nodes': 2, 'evidence_edges': 3, 'domain': 'governance'})
    assert ok
