import os, subprocess, json, pathlib
from triads.thinktank_dtt_assembly.assembly.pipeline import run_pipeline
from kernel.migrations import ensure_indexes

def test_e2e_fixture(tmp_path, monkeypatch):
    # Seed fixture DB
    subprocess.check_call(["python", "tools/seed_fixture_db.py"])
    ensure_indexes()
    # Lower finalize thresholds for test
    pathlib.Path("policy").mkdir(parents=True, exist_ok=True)
    (pathlib.Path("policy")/ "finalize.yaml").write_text("min_evidence_nodes: 1\nmin_evidence_edges: 1\n", encoding="utf-8")
    # Run pipeline for ep-demo
    out = run_pipeline(subject="fixture", endpoint_id="ep-demo", domain="governance")
    assert isinstance(out, dict) and out.get("ready", False), f"pipeline not ready: {out}"
