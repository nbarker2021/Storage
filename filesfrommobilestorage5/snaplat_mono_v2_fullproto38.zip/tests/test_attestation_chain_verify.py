import os, pathlib, json
from triads.sap_snapops_archivist.archivist.provenance import write_provenance
from triads.thinktank_dtt_assembly.assembly.publish import build_lockfile
from triads.sap_snapops_archivist.archivist.attest import write_attestation
from tools.attestation_verify import verify_attestation

def test_attestation_verify_smoke(monkeypatch):
    monkeypatch.setenv("SNAPLAT_SECRET", "test-secret")
    prov = write_provenance('epT', {'k':'v'})
    man = build_lockfile({'endpoint_id':'epT','evidence_nodes':1729,'evidence_edges':3,'provenance':prov})
    att = write_attestation('epT', man.get('cas_hash',''), prov, man.get('signature'))
    ok, rep = verify_attestation(att_cas=att, endpoint_id=None, secret="test-secret")
    assert ok and rep['signature_ok']
