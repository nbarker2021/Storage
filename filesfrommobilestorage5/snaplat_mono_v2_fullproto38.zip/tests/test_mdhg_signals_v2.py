from triads.snap_agrm_mdhg.mdhg.signals_v2 import stability_summary, cusum

def test_cusum_detects_drift():
    xs = [0.5]*50 + [0.8]*20
    drift, cp = cusum(xs, k=0.02, h=0.1)
    assert drift and cp > 0.1
