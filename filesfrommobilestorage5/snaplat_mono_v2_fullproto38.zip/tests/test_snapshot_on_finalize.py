import subprocess, json, pathlib
from triads.thinktank_dtt_assembly.assembly.pipeline import run_pipeline

def test_snapshot_written_on_finalize():
    subprocess.check_call(['python','tools/seed_fixture_db.py'])
    out = run_pipeline(subject='fixture', endpoint_id='ep-demo', domain='governance')
    # snapshot present in result (may be '')
    assert 'snapshot' in out
