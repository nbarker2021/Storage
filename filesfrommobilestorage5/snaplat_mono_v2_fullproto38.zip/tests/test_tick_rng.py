from kernel.tick import begin_tick
import random

def test_tick_seeds_rng():
    t1 = begin_tick()
    a = random.random()
    t2 = begin_tick()
    b = random.random()
    # Subsequent begin_tick() reseeds; two draws should differ unless time froze
    assert a != b or t1 != t2
