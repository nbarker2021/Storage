import pathlib, json, time, random, os

STATE = pathlib.Path("outputs/state")
STATE.mkdir(parents=True, exist_ok=True)
CLOCK = STATE / "tick.json"

def begin_tick() -> int:
    now = int(time.time() * 1000)
    if CLOCK.exists():
        try:
            obj = json.loads(CLOCK.read_text(encoding="utf-8"))
            last = int(obj.get("last", 0))
        except Exception:
            last = 0
    else:
        last = 0
    tid = max(now, last + 1)
    CLOCK.write_text(json.dumps({"last": tid}, sort_keys=True), encoding="utf-8")
    # Seed global RNG deterministically for this tick
    seed = tid ^ (int(os.environ.get("SNAPLAT_SEED", "0")) & 0xFFFFFFFF)
    random.seed(seed)
    return tid
