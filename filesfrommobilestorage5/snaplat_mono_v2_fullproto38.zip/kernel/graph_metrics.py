import sqlite3

DB = "rmi/snaplat.db"

def _conn():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def evidence_for_endpoint(endpoint_id: str) -> dict:
    """Compute coarse evidence metrics from lineage_edges touching the endpoint.
    Returns {nodes:int, edges:int}. Safe under sparse or missing tables.
    """
    try:
        con = _conn(); cur = con.cursor()
        rows = cur.execute("SELECT src_id, dst_id FROM lineage_edges WHERE src_id=? OR dst_id=?", (endpoint_id, endpoint_id)).fetchall()
        edges = len(rows)
        nodes = set()
        for r in rows:
            nodes.add(r['src_id']); nodes.add(r['dst_id'])
        # remove the endpoint itself if present
        if endpoint_id in nodes: nodes.discard(endpoint_id)
        return {"nodes": len(nodes), "edges": edges}
    except Exception:
        return {"nodes": 0, "edges": 0}
