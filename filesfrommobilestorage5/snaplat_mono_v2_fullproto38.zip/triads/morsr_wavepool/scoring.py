
import json, pathlib
from triads.snap_agrm_mdhg.mdhg.signals_v2 import stability_summary
from triads.e8.proof import generate_proof

TRAILS = pathlib.Path('outputs/trails/trails.jsonl')

def recent_reasons(limit=200):
    rs = []
    if TRAILS.exists():
        for line in TRAILS.read_text(encoding='utf-8').splitlines()[-limit:]:
            try:
                rec = json.loads(line)
                if rec.get('kind') in ('safecube.check','assembly.blocked','mdhg.alert'):
                    payload = rec.get('payload',{})
                    rs.extend(payload.get('reasons',[]) or payload.get('issues',[]) or [])
            except Exception:
                pass
    return rs

def compose(endpoint_id: str, domain: str|None):
    rs = recent_reasons()
    policy_penalty = min(0.5, 0.02*len(rs))
    st = stability_summary(endpoint_id)
    band_score = {'low':0.2,'medium':0.6,'high':0.9}.get(st.get('band','low'),0.2)
    drift_penalty = 0.2 if st.get('drift') else 0.0
    e8 = generate_proof(endpoint_id)
    rotation_bonus = 0.1 if e8.get('rotation_ok') else 0.0
    base = 0.5
    score = max(0.0, min(1.0, base + (band_score-0.5) + rotation_bonus - policy_penalty - drift_penalty))
    return {'policy_penalty': policy_penalty, 'band': st.get('band'), 'drift': st.get('drift'), 'rotation_ok': e8.get('rotation_ok'), 'score': score, 'reasons': rs[-16:]}
