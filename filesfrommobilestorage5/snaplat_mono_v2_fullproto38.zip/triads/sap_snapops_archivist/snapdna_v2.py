
import json, hashlib, base64, os, hmac
from typing import Any
from triads.sap_snapops_archivist.archivist.cas import put
from kernel.telemetry import emit

GLYPH_VERSION = 2

def _hash_bytes(b: bytes) -> str:
    return base64.urlsafe_b64encode(hashlib.blake2b(b, digest_size=16).digest()).decode('ascii')

def _mini_hash(v: Any) -> str:
    try:
        if isinstance(v, (dict, list)):
            b = json.dumps(v, sort_keys=True, separators=(',',':')).encode('utf-8')
        else:
            b = str(v).encode('utf-8')
    except Exception:
        b = repr(v).encode('utf-8')
    return _hash_bytes(b)

def encode_v2(obj: dict) -> dict:
    kind = obj.get('kind','unknown')
    shape = sorted(list(obj.keys()))
    field_hashes = {k: _mini_hash(obj[k]) for k in shape}
    payload = {
        "v": GLYPH_VERSION,
        "kind": kind,
        "shape": shape,
        "fields": field_hashes
    }
    blob = json.dumps(payload, sort_keys=True, separators=(',',':')).encode('utf-8')
    dna = _hash_bytes(blob)[:24]
    sig = ""
    secret_env = os.environ.get("SNAPLAT_SECRET")
    if secret_env:
        secret = secret_env.encode('utf-8')
        sig = base64.urlsafe_b64encode(hmac.new(secret, blob, hashlib.sha256).digest()).decode('ascii')
        payload["sig_alg"] = "HMAC-SHA256"
    doc = {"kind":"snap_dna_v2","dna": dna, "payload": payload, "signature": sig}
    h = put(doc)
    emit("snap.dna.v2","archivist",{"dna": dna, "kind": kind, "cas": h, "sig": bool(sig)})
    return {"dna": dna, "cas": h, "payload": payload, "signature": sig}

def compare(a: dict, b: dict) -> float:
    fa = a.get('payload',{}).get('fields',{}); fb = b.get('payload',{}).get('fields',{})
    if not fa or not fb: return 0.0
    keys = set(fa.keys()) | set(fb.keys())
    same = sum(1 for k in keys if fa.get(k)==fb.get(k))
    return same / max(1, len(keys))
