from kernel.db import get_conn, query
from kernel.authz import guard_rmi_read
from policy.lawpack_engine import enforce_lawpacks
from api.archivist import read_lockfile_checked

def context_ok(recent_trails: list, lockfile_endpoint_id: str|None) -> (bool, list):
    reasons = []
    # trail contradiction heuristic
    for t in recent_trails[-50:]:
        if t.get("kind","").endswith(".contradiction"):
            reasons.append("trail.contradiction"); break
    # crosswalk privacy check: if a privacy crosswalk exists, deny
    conn = get_conn()
    if not guard_rmi_read(context={'fn':'cto.crosswalks'}):
        return (False, ['rbac.deny.cto'])
    rows = query(conn, "SELECT cw_id FROM crosswalks WHERE kind='privacy' LIMIT 1", ())
    if rows:
        reasons.append("privacy.crosswalk.boundary")
    # LawPack field-level enforcement on slice
    lp_ok, lp_rs = enforce_lawpacks({"recent": len(recent_trails)})
    if not lp_ok:
        reasons.extend(lp_rs)
    # Lockfile verification if referenced
    if lockfile_endpoint_id:
        lf = read_lockfile_checked(lockfile_endpoint_id)
        if lf is None:
            reasons.append('lockfile.verify.failed')
    return (len(reasons) == 0, reasons)
