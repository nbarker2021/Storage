#!/usr/bin/env bash
echo 'rotating signer (stub)'
