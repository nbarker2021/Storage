
from dataclasses import dataclass
from typing import Dict
import math
PHI = (1 + 5**0.5) / 2

@dataclass
class AGRMState:
    step: int
    tac: float

def plan(state: AGRMState) -> Dict:
    r = 1 + int(math.floor((state.step / PHI) % 2))
    floors = 1 if state.tac >= 0.5 else 2
    elevators = 1
    schedule = ["neighbors", "edges", "reflect"]
    return {"radius": r, "floors": floors, "elevators": elevators, "schedule": schedule}
