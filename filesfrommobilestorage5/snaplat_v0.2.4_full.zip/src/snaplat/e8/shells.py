
from typing import List
from .roots import e8_roots

def sigma3(n: int) -> int:
    s = 0
    for d in range(1, n+1):
        if n % d == 0:
            s += d**3
    return s

def oracle_count(m: int) -> int:
    return 240 * sigma3(m)

def root_shell() -> List[List[float]]:
    return e8_roots()


def shell_count(m: int) -> int:
    """Return the number of lattice points in the shell of squared norm 2*m.
    For E8 this equals 240 * sigma3(m), the theta-series coefficient.
    """
    return oracle_count(m)


def _sign_assign(values, signs):
    return [v if b>0 else -v for v, b in zip(values, signs)]

def _all_signs(k):
    for mask in range(1<<k):
        yield [(1 if ((mask>>i)&1)==0 else -1) for i in range(k)]

def shell(m: int):
    """Return list of E8 lattice vectors with squared norm 2*m for m=1..3.
    Construction is combinatorial and exact for these shells; counts match 240*sigma3(m).
    """
    if m == 1:
        return root_shell()
    out = []

    if m == 2:
        # Integer patterns
        # (±2, 0^7)
        for i in range(8):
            for sgn in (+1.0, -1.0):
                v = [0.0]*8; v[i] = 2.0*sgn; out.append(v)
        # (±1,±1,±1,±1,0^4)
        from itertools import combinations
        for idxs in combinations(range(8), 4):
            for signs in _all_signs(4):
                v = [0.0]*8
                for j, sgn in zip(idxs, signs):
                    v[j] = 1.0 if sgn>0 else -1.0
                out.append(v)
        # Half-integer: one 3/2 and seven 1/2 (signs restricted by parity)
        for i in range(8):
            for mask in range(1<<8):
                signs = [1 if ((mask>>k)&1)==0 else -1 for k in range(8)]
                y = [signs[k] for k in range(8)]
                y[i] *= 3  # make one entry 3
                if (sum(y) % 4) != 0:
                    continue
                v = [(yk/2.0) for yk in y]
                out.append(v)
        # Dedup (just in case)
        ded = {}
        for v in out:
            key = tuple(v)
            ded[key] = v
        out = list(ded.values())
        return out

    if m == 3:
        # Integer patterns
        from itertools import combinations
        # (±2, ±1, ±1, 0^5)
        for i in range(8):
            for s2 in (+1.0, -1.0):
                for (j, k) in combinations([x for x in range(8) if x!=i], 2):
                    for s1a, s1b in _all_signs(2):
                        v = [0.0]*8
                        v[i] = 2.0*s2
                        v[j] = 1.0 if s1a>0 else -1.0
                        v[k] = 1.0 if s1b>0 else -1.0
                        out.append(v)
        # (±1)*6, 0^2
        for idxs in combinations(range(8), 6):
            for signs in _all_signs(6):
                v = [0.0]*8
                for j, sgn in zip(idxs, signs):
                    v[j] = 1.0 if sgn>0 else -1.0
                out.append(v)
        # Half-integer: two 3/2 and six 1/2
        for (i, j) in combinations(range(8), 2):
            for mask in range(1<<8):
                signs = [1 if ((mask>>k)&1)==0 else -1 for k in range(8)]
                y = [signs[k] for k in range(8)]
                y[i] *= 3; y[j] *= 3
                if (sum(y) % 4) != 0:
                    continue
                v = [(yk/2.0) for yk in y]
                out.append(v)
        ded = {}
        for v in out:
            ded[tuple(v)] = v
        return list(ded.values())

    raise NotImplementedError("shell(m) currently implemented for m in {1,2,3}")
