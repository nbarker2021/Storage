
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Tuple
import json, hashlib
from ..e8.core import nearest
from ..e8.coxeter import get_projector
from ..e8.neighbor_cache import NeighborCache
@dataclass
class SNAPState:
    name: str
    base_point: List[float]
    orientation: List[int]
    projection: str
    constraints: Dict[str, Any]
    neighbor_cache: Dict[str, Any]
    def to_json(self) -> str: return json.dumps(asdict(self), sort_keys=True)
    @staticmethod
    def from_json(s: str) -> "SNAPState":
        return SNAPState(**json.loads(s))
    def hash(self) -> str: return hashlib.sha256(self.to_json().encode()).hexdigest()
    def replay_projection(self) -> Tuple[float,float]:
        proj = get_projector(); px, _ = nearest(self.base_point); return proj(px)
    def neighbors(self) -> List[List[float]]:
        nc = NeighborCache(); return nc.get_first_shell(self.base_point)
