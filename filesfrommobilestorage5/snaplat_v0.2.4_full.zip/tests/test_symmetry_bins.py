
def test_symmetry_bins_if_sympy():
    try:
        import sympy  # noqa: F401
        from snaplat.e8.shells import root_shell
        from snaplat.e8.coxeter import get_projector
        import math
    except Exception:
        return  # sympy not available -> no-op

    pts = [get_projector()(r) for r in root_shell()]
    angles = [math.atan2(v, u) for (u, v) in pts]
    bins = [0]*30
    for a in angles:
        k = int(((a + math.pi) / (2*math.pi)) * 30) % 30
        bins[k] += 1
    # Expect non-empty coverage across many bins; allow tolerance
    nonzero = sum(1 for b in bins if b > 0)
    assert nonzero >= 24
