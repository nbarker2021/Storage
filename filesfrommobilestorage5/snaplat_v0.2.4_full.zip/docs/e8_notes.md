## E8 Notes

Coxeter plane implemented with SymPy path and deterministic fallback.