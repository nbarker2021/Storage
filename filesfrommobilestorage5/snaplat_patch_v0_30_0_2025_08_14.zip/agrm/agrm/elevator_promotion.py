
from typing import Dict, Any
from agrm.snapcore.decorators import instrument
from agrm.snap_tools.stitch import stitch

@instrument(family="mdhg", type_="promote", universe_key="universe")
def promote_elevators(repo, um, universe: str, threshold: float, compat_policy: Dict[str,Any], scoring_cfg: Dict[str,Any]) -> Dict[str,Any]:
    # toy result
    promoted = 3 if threshold <= 0.7 else 1
    rejected = 2
    breakdown = {"w5h_align_mean": 0.62}
    # emit a decision snap
    stitch(repo, um, universe=universe, family="decision", type_="promotion",
           content={"promoted": promoted, "rejected": rejected, "threshold": threshold, "compat_policy": compat_policy, "breakdown": breakdown})
    return {"promoted": promoted, "rejected": rejected, "breakdown": breakdown}
