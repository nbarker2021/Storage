
class Repo:
    def __init__(self):
        self.store = {}
    def save(self, k, v):
        self.store[k] = v
    def load(self, k):
        return self.store[k]
    def keys(self):
        return list(self.store.keys())
repo = Repo()
