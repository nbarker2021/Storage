"""morsr module"""
