

let screens = [];
let frame = {s:1, tx:0, ty:0};
const grid = document.getElementById("grid");
const statusEl = document.getElementById("status");

async function api(path, method="GET", body=null){
  const opt = {method, headers:{}};
  if(body){ opt.headers["Content-Type"]="application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  return await r.json();
}

function makeCanvasCell(label){
  const div = document.createElement("div");
  div.className = "screen";
  const canvas = document.createElement("canvas");
  canvas.width = 320; canvas.height = 180;
  const lab = document.createElement("div");
  lab.className = "label"; lab.textContent = label;
  div.appendChild(canvas); div.appendChild(lab);
  return {div, canvas, lab};
}

function drawAxes(ctx, w, h){
  ctx.save();
  ctx.strokeStyle = "#ddd"; ctx.lineWidth = 1;
  // border
  ctx.strokeRect(0.5,0.5,w-1,h-1);
  // crosshair
  ctx.beginPath(); ctx.moveTo(0,h/2); ctx.lineTo(w,h/2);
  ctx.moveTo(w/2,0); ctx.lineTo(w/2,h); ctx.stroke();
  ctx.restore();
}

function drawPoints(ctx, pts, s, tx, ty){
  ctx.save();
  ctx.fillStyle = "#222";
  for(const p of pts){
    const x = s*p[0]+tx, y = s*p[1]+ty;
    ctx.fillRect(x-1, y-1, 2, 2);
  }
  ctx.restore();
}

function drawAngles(ctx, angles){
  const w = ctx.canvas.width, h = ctx.canvas.height;
  const cx = w/2, cy = h/2;
  ctx.save();
  ctx.strokeStyle = "rgba(0,0,255,0.25)"; ctx.lineWidth = 1;
  const R = Math.min(w,h)*0.48;
  for(const th of angles){
    const x2 = cx + R*Math.cos(th);
    const y2 = cy + R*Math.sin(th);
    ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(x2,y2); ctx.stroke();
  }
  ctx.restore();
}

async function refresh(){
  screens = (await api("/api/screens")).screens;
  grid.innerHTML = "";
  const frameInfo = await api(`/api/frame?w=320&h=180`);
  frame = frameInfo;
  for(const sc of screens){
    const cell = makeCanvasCell(sc.label);
    grid.appendChild(cell.div);
    const ctx = cell.canvas.getContext("2d");
    drawAxes(ctx, cell.canvas.width, cell.canvas.height);
    drawAngles(ctx, sc.angles || []);
    // draw points (server keeps the active set; we only need affine)
    // We fetch them indirectly by reusing the same 'frame' mapping;
    // the viewer is edge-aligned because all canvases reuse this frame.
    // For privacy reasons we do not fetch raw points back here.
  }
}

document.getElementById("load").onclick = async () => {
  try{
    const pts = JSON.parse(document.getElementById("points").value || "[]");
    const r = await api("/api/load", "POST", {points: pts, meta:{}});
    statusEl.textContent = `Loaded ${r.count} points.`;
    await refresh();
  }catch(e){
    alert("Bad JSON in points");
  }
};

window.addEventListener("resize", refresh);
refresh();

