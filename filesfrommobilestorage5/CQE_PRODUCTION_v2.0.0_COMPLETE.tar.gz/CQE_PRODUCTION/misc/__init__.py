"""CQE Utilities Module"""
from .cqe_utils import *

__all__ = [
    # Mathematical
    'compute_digital_root', 'fibonacci', 'factorial', 'gcd', 'lcm', 'is_prime',
    # Geometric
    'norm', 'normalize', 'dot_product', 'angle_between', 'distance',
    'project_onto', 'reflect', 'rotate_2d',
    # Interpolation
    'lerp', 'clamp', 'smoothstep', 'interpolate_vectors',
    # Hashing
    'hash_sha256', 'hash_to_int', 'murmur_hash_32',
    # Validation
    'validate_vector_dimension', 'validate_unit_vector', 'validate_orthogonal',
    'sanitize_float',
    # Conversion
    'degrees_to_radians', 'radians_to_degrees',
    'cartesian_to_polar', 'polar_to_cartesian',
    # Statistical
    'mean', 'variance', 'std_dev', 'median',
    # Bit manipulation
    'popcount', 'next_power_of_2', 'is_power_of_2',
    # String
    'truncate_string', 'format_bytes', 'format_duration',
    # CQE-specific
    'phi_golden_ratio', 'e8_dimension', 'niemeier_dimension',
    'channel_numbers', 'is_valid_channel',
]
