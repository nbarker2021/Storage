class IndexType(Enum):
    """Types of indices for fast retrieval"""
    QUAD_INDEX = "quad_index"
    E8_SPATIAL_INDEX = "e8_spatial_index"
    CONTENT_INDEX = "content_index"
    TEMPORAL_INDEX = "temporal_index"
    METADATA_INDEX = "metadata_index"
    HASH_INDEX = "hash_index"
    SEMANTIC_INDEX = "semantic_index"
