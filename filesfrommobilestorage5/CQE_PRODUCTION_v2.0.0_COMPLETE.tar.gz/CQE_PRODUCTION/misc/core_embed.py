def embed(text, optimize):
    """Embed text into E8 space"""
    client = CQEClient()
    overlay = client.embed(text, optimize=optimize)

    click.echo(f"Overlay ID: {overlay.hash_id}")
    click.echo(f"Active slots: {len(overlay.active_slots)}/248")
    click.echo(f"Cartan active: {overlay.cartan_active}/8")

    metrics = client.get_phi_metrics(overlay)
    click.echo(f"\nΦ Metrics:")
    for key, value in metrics.items():
        click.echo(f"  {key}: {value:.3f}")


@main.command()