

<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Viewer24 Controller — CQE Lattice Screens</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  <header>
    <h1>Viewer24 Controller</h1>
    <div class="controls">
      <textarea id="points" rows="4" placeholder='[[x,y], ...]'></textarea>
      <button id="load">Load Points</button>
      <span id="status"></span>
    </div>
  </header>
  <main id="grid"></main>
  <script src="/static/app.js"></script>
</body>
</html>

