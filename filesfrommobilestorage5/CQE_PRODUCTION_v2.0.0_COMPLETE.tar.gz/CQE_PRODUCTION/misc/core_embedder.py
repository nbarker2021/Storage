def embedder(e8_lattice):
    """Babai embedder instance"""
    return BabaiEmbedder(e8_lattice)


@pytest.fixture