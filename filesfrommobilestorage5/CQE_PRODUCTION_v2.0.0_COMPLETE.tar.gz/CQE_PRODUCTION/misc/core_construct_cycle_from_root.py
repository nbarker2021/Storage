def construct_cycle_from_root(root, variety):
    # Generate cycle from E8 root space
    constraints = []
    for i, root_coord in enumerate(root):
        if abs(root_coord) > 1e-10:  # Non-zero coordinate
            # Create geometric constraint
            constraint = generate_geometric_constraint(i, root_coord, variety)
            constraints.append(constraint)
    
    # Intersect constraints to get cycle
    cycle = intersect_constraints(constraints, variety)
    return cycle
