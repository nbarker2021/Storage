"""
Module Extractor - Extract real code from CQE monolith files by line ranges
"""
import json
import os
from typing import Dict, List, Set, Optional
from pathlib import Path


class ModuleExtractor:
    """Extract modules from CQE monolith files based on module_analysis.json"""
    
    def __init__(self, analysis_file: str = "module_analysis.json"):
        self.analysis_file = analysis_file
        self.modules: Dict = {}
        self.monolith_cache: Dict[str, List[str]] = {}
        self.base_dir = Path(__file__).parent
        
        # Load module analysis
        with open(self.base_dir / analysis_file, 'r') as f:
            data = json.load(f)
            # Extract modules from the JSON structure
            if isinstance(data, dict) and 'modules' in data:
                self.modules = data['modules']
                self.stats = data.get('stats', {})
                self.capability_index = data.get('capability_index', {})
            else:
                self.modules = data
                self.stats = {}
                self.capability_index = {}
    
    def _load_monolith(self, source_file: str) -> List[str]:
        """Load monolith file into memory (cached)"""
        if source_file in self.monolith_cache:
            return self.monolith_cache[source_file]
        
        # Map source_file names to actual files
        file_map = {
            "gvs_monolith": "CQE_CORE_MONOLITH_fixed.py",
            "prototype": "CQE_CORE_MONOLITH_fixed.py",
            "speedlight": "CQE_CORE_MONOLITH_fixed.py",
            "render_engine": "CQE_CORE_MONOLITH_fixed.py",
            "core": "CQE_CORE_MONOLITH_fixed.py",
            "blockchain": "CQE_CORE_MONOLITH_fixed.py",
            "ai": "CQE_CORE_MONOLITH_fixed.py",
            "video": "CQE_CORE_MONOLITH_fixed.py",
        }
        
        actual_file = file_map.get(source_file, "CQE_CORE_MONOLITH_fixed.py")
        file_path = self.base_dir / actual_file
        
        if not file_path.exists():
            raise FileNotFoundError(f"Monolith file not found: {file_path}")
        
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        self.monolith_cache[source_file] = lines
        return lines
    
    def extract_module(self, module_name: str) -> Optional[str]:
        """Extract a single module's code"""
        if module_name not in self.modules:
            return None
        
        module_info = self.modules[module_name]
        source_file = module_info.get("source_file", "gvs_monolith")
        line_start = module_info.get("line_start", 0)
        line_end = module_info.get("line_end", 0)
        
        if line_start == 0 and line_end == 0:
            return None
        
        # Load monolith
        lines = self._load_monolith(source_file)
        
        # Extract lines (convert to 0-indexed)
        extracted_lines = lines[line_start:line_end]
        
        return "".join(extracted_lines)
    
    def extract_modules(self, module_names: List[str]) -> Dict[str, str]:
        """Extract multiple modules"""
        result = {}
        for name in module_names:
            code = self.extract_module(name)
            if code:
                result[name] = code
        return result
    
    def get_module_info(self, module_name: str) -> Optional[Dict]:
        """Get module metadata"""
        return self.modules.get(module_name)
    
    def find_modules_by_capability(self, capability: str) -> List[str]:
        """Find all modules with a specific capability"""
        result = []
        for name, info in self.modules.items():
            if capability in info.get("capabilities", []):
                result.append(name)
        return result
    
    def find_modules_by_category(self, category: str) -> List[str]:
        """Find all modules in a category"""
        result = []
        for name, info in self.modules.items():
            if info.get("category") == category:
                result.append(name)
        return result
    
    def resolve_dependencies(self, module_names: List[str]) -> List[str]:
        """Resolve module dependencies recursively"""
        resolved = set()
        to_process = set(module_names)
        
        while to_process:
            current = to_process.pop()
            if current in resolved:
                continue
            
            resolved.add(current)
            
            # Get dependencies
            info = self.get_module_info(current)
            if info:
                deps = info.get("dependencies", [])
                for dep in deps:
                    if dep not in resolved:
                        to_process.add(dep)
        
        return list(resolved)
    
    def generate_tool(
        self,
        tool_name: str,
        description: str,
        module_names: List[str],
        resolve_deps: bool = True
    ) -> Dict[str, any]:
        """Generate a complete standalone tool"""
        
        # Resolve dependencies if requested
        if resolve_deps:
            all_modules = self.resolve_dependencies(module_names)
        else:
            all_modules = module_names
        
        # Extract all module code
        extracted = self.extract_modules(all_modules)
        
        # Collect all imports
        imports = set()
        for name in all_modules:
            info = self.get_module_info(name)
            if info:
                for imp in info.get("imports", []):
                    # Skip relative imports (they're internal)
                    if not imp.startswith("."):
                        imports.add(imp)
        
        # Build the tool script
        script_parts = []
        
        # Header
        script_parts.append(f'"""')
        script_parts.append(f'{tool_name}')
        script_parts.append(f'')
        script_parts.append(f'{description}')
        script_parts.append(f'')
        script_parts.append(f'Generated from CQE modules: {", ".join(all_modules[:5])}{"..." if len(all_modules) > 5 else ""}')
        script_parts.append(f'Total modules: {len(all_modules)}')
        script_parts.append(f'"""')
        script_parts.append('')
        
        # Imports
        script_parts.append('# Standard library imports')
        stdlib_imports = {'os', 'sys', 'time', 'json', 'copy', 'hashlib', 'dataclasses', 'typing', '__future__'}
        for imp in sorted(imports):
            if imp in stdlib_imports or '.' not in imp:
                script_parts.append(f'import {imp}')
        
        script_parts.append('')
        script_parts.append('# External dependencies')
        for imp in sorted(imports):
            if imp not in stdlib_imports and '.' not in imp:
                script_parts.append(f'# import {imp}  # May need: pip install {imp}')
        
        script_parts.append('')
        script_parts.append('# ============================================================================')
        script_parts.append('# EXTRACTED CQE MODULES')
        script_parts.append('# ============================================================================')
        script_parts.append('')
        
        # Module code
        for name in all_modules:
            if name in extracted:
                script_parts.append(f'# --- Module: {name} ---')
                script_parts.append(extracted[name])
                script_parts.append('')
        
        # Main entry point
        script_parts.append('')
        script_parts.append('# ============================================================================')
        script_parts.append('# MAIN ENTRY POINT')
        script_parts.append('# ============================================================================')
        script_parts.append('')
        script_parts.append('if __name__ == "__main__":')
        script_parts.append('    print(f"Tool: {tool_name}")')
        script_parts.append(f'    print(f"Modules loaded: {len(all_modules)}")')
        script_parts.append('    print("Ready to use!")')
        script_parts.append('')
        
        script_content = '\n'.join(script_parts)
        
        # Calculate stats
        total_lines = sum(info.get("size_lines", 0) for name in all_modules if (info := self.get_module_info(name)))
        
        return {
            "tool_name": tool_name,
            "description": description,
            "script_content": script_content,
            "modules": all_modules,
            "module_count": len(all_modules),
            "total_lines": total_lines,
            "imports": list(imports)
        }


# Singleton instance
_extractor = None

def get_extractor() -> ModuleExtractor:
    """Get or create the module extractor singleton"""
    global _extractor
    if _extractor is None:
        _extractor = ModuleExtractor()
    return _extractor


if __name__ == "__main__":
    # Test extraction
    extractor = get_extractor()
    
    print("Testing module extraction...")
    print(f"Total modules available: {len(extractor.modules)}")
    
    # Test extracting a single module
    test_module = "speedlight"
    print(f"\nExtracting module: {test_module}")
    code = extractor.extract_module(test_module)
    if code:
        print(f"Extracted {len(code)} characters")
        print(f"First 200 chars:\n{code[:200]}")
    
    # Test finding modules by capability
    e8_modules = extractor.find_modules_by_capability("e8_operations")
    print(f"\nModules with e8_operations capability: {len(e8_modules)}")
    print(f"Examples: {e8_modules[:5]}")
    
    # Test generating a tool
    print("\nGenerating test tool...")
    tool = extractor.generate_tool(
        tool_name="test_e8_tool",
        description="Test E8 operations tool",
        module_names=["speedlight"],
        resolve_deps=False
    )
    print(f"Generated tool with {tool['module_count']} modules, {tool['total_lines']} lines")
    print(f"Script size: {len(tool['script_content'])} characters")
