def overlay_dsc(X8, V, R):
    P1 = pose_bits(X8, V, E8_ROOTS, R)
    Sflip = np.diag([1,1,1,1,-1,-1,-1,-1])
    Rm = Sflip @ R
    P2 = pose_bits(X8, V, E8_ROOTS, Rm)
    return np.all(P1 == P2, axis=1)
