def overlay_hnf(X8, V, R):
    _, _, di, dh, _, _ = e8_snap_block(X8)
    margin = coset_margin(di, dh)
    P = pose_bits(X8, V, E8_ROOTS, R)
    powers = (1 << np.arange(P.shape[1]))[::-1]
    ints = P @ powers
    vals, counts = np.unique(ints, return_counts=True)
    modal = vals[np.argmax(counts)]
    in_modal = (ints == modal)
    return (margin <= 0.02) & in_modal
