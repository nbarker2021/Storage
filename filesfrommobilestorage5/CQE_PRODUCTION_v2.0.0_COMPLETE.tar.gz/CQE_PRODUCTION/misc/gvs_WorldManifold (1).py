class WorldManifold:
    """A forged world manifold."""
    world_type: WorldType
    e8_seed: np.ndarray  # Seed state in E8 space
    weyl_chamber: int  # Primary Weyl chamber (determines style)
    digital_root: int  # Digital root (determines force/energy)
    
    # World properties
    complexity: float  # [0, 1] - how complex the world is
    coherence: float  # [0, 1] - how internally consistent
    stability: float  # [0, 1] - how stable over time
    
    # Geometric properties
    curvature: float  # Spacetime curvature
    topology: str  # Topological type
    symmetry_group: int  # Dihedral symmetry group
    
    # Content metadata
    objects: List[Dict]  # Objects in the world
    lighting: Dict  # Lighting configuration
    physics: Dict  # Physics parameters
    
    metadata: Dict  # Additional metadata

