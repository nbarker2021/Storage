def sha(s): return hashlib.sha256(s.encode()).hexdigest()

# -------- E8 machinery --------