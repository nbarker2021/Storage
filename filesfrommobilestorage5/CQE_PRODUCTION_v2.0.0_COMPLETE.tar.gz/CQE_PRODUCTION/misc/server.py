"""
SERVER Module
-------------

Contains: FractalBehavior, InterfaceType, server_1, app.js
"""


try:
    import serve
except ImportError:
    serve = None

try:
    import numpy as np
except ImportError:
    np = None


# ============================================================================
# FractalBehavior
# ============================================================================

class FractalBehavior(Enum):
    """Mandelbrot fractal behavior classification"""
    BOUNDED = "BOUNDED"           # Stays bounded (interior, compression)
    ESCAPING = "ESCAPING"         # Escapes to infinity (exterior, expansion)
    BOUNDARY = "BOUNDARY"         # On the boundary (critical behavior)
    PERIODIC = "PERIODIC"         # Periodic orbit (stable cycles)




# ============================================================================
# InterfaceType
# ============================================================================

class InterfaceType(Enum):
    """Types of interfaces supported"""
    COMMAND_LINE = "command_line"
    REST_API = "rest_api"
    GRAPHQL = "graphql"
    WEBSOCKET = "websocket"
    NATURAL_LANGUAGE = "natural_language"
    VISUAL = "visual"
    VOICE = "voice"
    GESTURE = "gesture"
    BRAIN_COMPUTER = "brain_computer"
    CQE_NATIVE = "cqe_native"




# ============================================================================
# server_1
# ============================================================================



if __name__ == '__main__':
    serve()




# ============================================================================
# app.js
# ============================================================================



async function addItem(){
  try{
    let pts = JSON.parse(document.getElementById("points").value || "[]");
    let kind = document.getElementById("kind").value || "geom";
    let channel = parseFloat(document.getElementById("channel").value || "3");
    let payload = {kind, points: pts, meta: {channel}};
    let r = await fetch("/api/add", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)});
    let j = await r.json();
    alert("Added: " + JSON.stringify(j));
    loadStats();
  }catch(e){ alert("Bad JSON in points"); }
}
async function doSearch(){
  try{
    let pts = JSON.parse(document.getElementById("qpoints").value || "[]");
    let chart = document.getElementById("chart").value;
    let payload = {points: pts, meta: {}, topk: 10, chart: chart||undefined};
    let r = await fetch("/api/search", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)});
    let j = await r.json();
    document.getElementById("results").textContent = JSON.stringify(j, null, 2);
  }catch(e){ alert("Bad JSON in query points"); }
}
async function loadStats(){
  let r = await fetch("/api/stats"); let j = await r.json();
  document.getElementById("stats").textContent = JSON.stringify(j, null, 2);
}
loadStats();



