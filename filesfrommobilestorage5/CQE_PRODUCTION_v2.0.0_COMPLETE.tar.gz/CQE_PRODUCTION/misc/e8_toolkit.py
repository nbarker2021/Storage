#!/usr/bin/env python3
"""
E8_TOOLKIT - Pure E8 geometry and lattice mathematics

Auto-generated custom tool using CQE monolith building blocks.

Available modules:
# - LatticeBuilderV1
# - NiemeierSpecs
# - Init
# - E8Bridge
# - GeometryTransformerStandaloneV2
# - NiemeierSpecs1
# - Transforms1
# - CqeMath
# - CqePersonalNode
# - GeometricTransformer1m
# - GeometricTransformerStandalone
# - CaTileGenerator
"""

import sys
from pathlib import Path

# Add module paths
MODULES_DIR = Path(__file__).parent / "modules"
sys.path.insert(0, str(MODULES_DIR))

def main():
    print("🚀 E8_TOOLKIT")
    print("Pure E8 geometry and lattice mathematics")
    print()
    print("Available modules:")
    
    modules = ['"LatticeBuilderV1"', '"NiemeierSpecs"', '"Init"', '"E8Bridge"', '"GeometryTransformerStandaloneV2"', '"NiemeierSpecs1"', '"Transforms1"', '"CqeMath"', '"CqePersonalNode"', '"GeometricTransformer1m"', '"GeometricTransformerStandalone"', '"CaTileGenerator"']
    
    for mod_name in modules:
        try:
            __import__(mod_name)
            print(f"  ✓ {mod_name}")
        except Exception as e:
            print(f"  ✗ {mod_name}: {e}")
    
    print()
    print("Use: from <module> import <class>")

if __name__ == '__main__':
    main()
