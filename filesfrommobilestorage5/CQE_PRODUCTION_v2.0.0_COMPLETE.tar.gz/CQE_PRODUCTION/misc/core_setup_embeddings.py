def setup_embeddings():
    """Generate E₈ embeddings."""
    print("Setting up E₈ embeddings...")

    try:
        # Import and run E₈ embedding generator
        from embeddings.e8_embedding import save_embedding
        save_embedding()
        print("✓ E₈ embedding generated successfully")

    except Exception as e:
        print(f"✗ Failed to generate E₈ embedding: {e}")
        return False

    return True
