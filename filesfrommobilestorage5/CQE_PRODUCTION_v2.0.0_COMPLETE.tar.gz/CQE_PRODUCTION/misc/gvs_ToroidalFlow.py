class ToroidalFlow:
    """Toroidal flow engine for temporal evolution."""
    
    def __init__(self, coupling: float = COUPLING, 
                 major_radius: float = MAJOR_RADIUS,
                 minor_radius: float = MINOR_RADIUS):
        self.coupling = coupling
        self.R = major_radius
        self.r = minor_radius
        
    def _rotation_matrix_2d(self, angle: float) -> np.ndarray:
        """2D rotation matrix."""
        return np.array([
            [np.cos(angle), -np.sin(angle)],
            [np.sin(angle), np.cos(angle)]
        ])
    
    def _rotation_matrix_e8(self, axis1: int, axis2: int, 
                           angle: float) -> np.ndarray:
        """E8 rotation matrix in specified plane."""
        R = np.eye(8)
        R2d = self._rotation_matrix_2d(angle)
        R[axis1:axis1+2, axis1:axis1+2] = R2d
        return R
    
    def rotate_poloidal(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Poloidal rotation (around minor circle).
        Maps to electromagnetic force (DR 1, 4, 7).
        """
        angle = dt * 2 * np.pi
        # Rotate in 0-1 plane
        R = self._rotation_matrix_e8(0, 1, angle)
        return R @ e8_state
    
    def rotate_toroidal(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Toroidal rotation (around major circle).
        Maps to weak nuclear force (DR 2, 5, 8).
        """
        angle = dt * 2 * np.pi
        # Rotate in 2-3 plane
        R = self._rotation_matrix_e8(2, 3, angle)
        return R @ e8_state
    
    def rotate_meridional(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Meridional rotation (along meridian).
        Maps to strong nuclear force (DR 3, 6, 9).
        """
        angle = dt * 2 * np.pi
        # Rotate in 4-5 plane
        R = self._rotation_matrix_e8(4, 5, angle)
        return R @ e8_state
    
    def rotate_helical(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Helical rotation (spiral motion).
        Maps to gravitational force (DR 0).
        This is the unifying rotation mode.
        """
        angle = dt * 2 * np.pi
        
        # Combine all three rotations with golden ratio weighting
        poloidal = self.rotate_poloidal(e8_state, dt / PHI)
        toroidal = self.rotate_toroidal(e8_state, dt / PHI**2)
        meridional = self.rotate_meridional(e8_state, dt / PHI**3)
        
        # Helical = weighted combination
        helical = (poloidal + toroidal + meridional) / 3
        
        # Normalize
        norm = np.linalg.norm(helical)
        if norm > 0:
            helical = helical / norm * np.sqrt(2)
        
        return helical
    
    def evolve_state(self, e8_state: np.ndarray, dt: float = None) -> np.ndarray:
        """
        Evolve E8 state by one timestep using all four rotation modes.
        This is the core temporal flow operation.
        """
        if dt is None:
            dt = self.coupling
        
        # Apply all four rotation modes
        poloidal = self.rotate_poloidal(e8_state, dt)
        toroidal = self.rotate_toroidal(e8_state, dt)
        meridional = self.rotate_meridional(e8_state, dt)
        helical = self.rotate_helical(e8_state, dt)
        
        # Combine with coupling weight
        # The 0.03 coupling ensures smooth evolution
        next_state = (
            poloidal * 0.25 +
            toroidal * 0.25 +
            meridional * 0.25 +
            helical * 0.25
        ) * dt
        
        # Add current state (Euler integration)
        next_state = e8_state + next_state
        
        # Project to toroidal manifold
        next_state = self.project_to_torus(next_state)
        
        return next_state
    
    def project_to_torus(self, e8_state: np.ndarray) -> np.ndarray:
        """
        Project E8 state to toroidal manifold.
        Ensures closure - no information leaks out.
        """
        # Extract toroidal coordinates from E8
        x, y = e8_state[0], e8_state[1]
        z = e8_state[2]
        
        # Compute angles
        phi = np.arctan2(y, x)  # Toroidal angle
        rho = np.sqrt(x**2 + y**2)  # Distance from z-axis
        
        # Ensure rho is in valid range
        if rho < self.R - self.r:
            rho = self.R - self.r
        elif rho > self.R + self.r:
            rho = self.R + self.r
        
        # Compute poloidal angle
        theta = np.arccos(np.clip((rho - self.R) / self.r, -1, 1))
        
        # Reconstruct on torus
        new_x = (self.R + self.r * np.cos(theta)) * np.cos(phi)
        new_y = (self.R + self.r * np.cos(theta)) * np.sin(phi)
        new_z = self.r * np.sin(theta)
        
        # Update E8 state
        projected = e8_state.copy()
        projected[0] = new_x
        projected[1] = new_y
        projected[2] = new_z
        
        # Normalize to maintain E8 norm
        norm = np.linalg.norm(projected)
        if norm > 0:
            projected = projected / norm * np.sqrt(2)
        
        return projected
    
    def extract_toroidal_state(self, e8_state: np.ndarray, 
                              timestamp: float) -> ToroidalState:
        """Extract toroidal state from E8 embedding."""
        x, y = e8_state[0], e8_state[1]
        z = e8_state[2]
        
        # Compute angles
        phi = np.arctan2(y, x)
        rho = np.sqrt(x**2 + y**2)
        theta = np.arccos(np.clip((rho - self.R) / self.r, -1, 1))
        
        # Meridional and helical phases from remaining coordinates
        psi = np.arctan2(e8_state[5], e8_state[4])
        omega = np.arctan2(e8_state[7], e8_state[6])
        
        return ToroidalState(
            poloidal_angle=theta,
            toroidal_angle=phi,
            meridional_phase=psi,
            helical_phase=omega,
            e8_embedding=e8_state,
            timestamp=timestamp
        )
    
    def compute_flow_velocity(self, e8_state: np.ndarray) -> float:
        """Compute flow velocity at current state."""
        # Velocity is proportional to distance from center
        rho = np.sqrt(e8_state[0]**2 + e8_state[1]**2)
        velocity = (rho - self.R) / self.r  # Normalized [-1, 1]
        return velocity * self.coupling
    
    def check_closure(self, trajectory: list) -> bool:
        """
        Check if trajectory forms a closed loop (toroidal closure).
        True lossless generation requires closure.
        """
        if len(trajectory) < 2:
            return False
        
        start = trajectory[0]
        end = trajectory[-1]
        
        # Check if end state is close to start state
        distance = np.linalg.norm(end - start)
        
        # Closure threshold: one coupling unit
        return distance < self.coupling

