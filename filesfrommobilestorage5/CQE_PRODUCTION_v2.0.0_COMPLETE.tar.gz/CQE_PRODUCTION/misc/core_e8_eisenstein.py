def e8_eisenstein(s, z, N_max=10000):
    total = 0.0
    for n in range(1, N_max + 1):
        coeff = e8_fourier_coefficient(n, z)
        total += coeff / (n ** s)
    return total
