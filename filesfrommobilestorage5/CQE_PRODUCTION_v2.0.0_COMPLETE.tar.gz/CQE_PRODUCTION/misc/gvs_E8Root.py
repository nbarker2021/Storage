class E8Root:
    """E8 root vector."""
    coords: np.ndarray  # (8,) coordinates
    index: int  # Root index [0-239]
    norm: float  # Norm (should be √2)
    
    def __post_init__(self):
        if self.norm is None:
            self.norm = np.linalg.norm(self.coords)
