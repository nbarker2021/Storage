def orbit_hash(X8, V, R):
    P = pose_bits(X8, V, E8_ROOTS, R)
    Sflip = np.diag([1,1,1,1,-1,-1,-1,-1]); Rm = Sflip @ R
    Q = pose_bits(X8, V, E8_ROOTS, Rm)
    N = X8.shape[0]; cos = np.zeros(N, dtype=int)
    for i in range(N):
        _, _, d0, d1, c, _ = e8_nearest(X8[i])
        cos[i] = 0 if d0 <= d1 else 1
    powers = (1 << np.arange(P.shape[1]))[::-1]
    a = P @ powers; b = Q @ powers; c = cos.astype(int)
    sig = (a.astype(np.int64) << 9) | (b.astype(np.int64) << 1) | c
    vals, counts = np.unique(sig, return_counts=True)
    return pd.DataFrame({"orbit_sig": vals, "count": counts}).sort_values("count", ascending=False)

# -------- Controller --------