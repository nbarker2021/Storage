"""
AI Module
---------

Contains: _MonolithFinder, Octet, index_2.html, SyntaxLevel, QueryResponse, SliceSensors, glyphs
"""


try:
    import Any
except ImportError:
    Any = None
try:
    import Dict
except ImportError:
    Dict = None

try:
    import numpy as np
except ImportError:
    np = None


# ============================================================================
# _MonolithFinder
# ============================================================================

class _MonolithFinder(importlib.abc.MetaPathFinder):
    def __init__(self):
        raw = base64.b64decode(_EMBED_ZIP_B64.encode("ascii"))
        self.z = zipfile.ZipFile(io.BytesIO(raw), "r")
        self.names = set(self.z.namelist())
    def find_spec(self, fullname, path, target=None):
        p = fullname.replace(".", "/")
        for c in (f"{p}.py", f"{p}/__init__.py"):
            if c in self.names:
                loader = _MonolithLoader(self.z, fullname, c)
                is_pkg = c.endswith("__init__.py")
                return importlib.util.spec_from_loader(fullname, loader, origin=loader.get_filename(fullname), is_package=is_pkg)
        return None


# ============================================================================
# Octet
# ============================================================================

class Octet:
    views: Dict[str, str]  # V1..V8 -> token

@dataclass



# ============================================================================
# index_2.html
# ============================================================================



<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Monster/Moonshine VOA DB</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  <h1>Monster/Moonshine VOA Embeddings — Personal Server</h1>
  <section>
    <h3>Add Item</h3>
    <textarea id="points" rows="6" placeholder='[[x,y], ...]'></textarea>
    <div>
      <label>Kind <input id="kind" value="geom"></label>
      <label>Channel <input id="channel" value="3"></label>
      <button onclick="addItem()">Add</button>
    </div>
  </section>
  <section>
    <h3>Search</h3>
    <textarea id="qpoints" rows="6" placeholder='[[x,y], ...]'></textarea>
    <div>
      <label>Chart
        <select id="chart">
          <option value="">(all)</option>
          <option>moonshine</option>
          <option>geom</option>
          <option>cqe</option>
        </select>
      </label>
      <button onclick="doSearch()">Search</button>
    </div>
    <pre id="results"></pre>
  </section>
  <section>
    <h3>Stats</h3>
    <pre id="stats"></pre>
  </section>
  <script src="/static/app.js"></script>
</body>
</html>




# ============================================================================
# SyntaxLevel
# ============================================================================

class SyntaxLevel(Enum):
    """Levels of syntax analysis"""
    PHONETIC = "phonetic"        # Sound/character level
    MORPHEMIC = "morphemic"      # Word/token level
    SYNTACTIC = "syntactic"      # Sentence/statement level
    SEMANTIC = "semantic"        # Meaning level
    PRAGMATIC = "pragmatic"      # Context/usage level
    DISCOURSE = "discourse"      # Document/conversation level

@dataclass



# ============================================================================
# QueryResponse
# ============================================================================

class QueryResponse(BaseModel):
    """Response model for similarity query"""
    results: List[Dict[str, Any]]
    query_overlay_id: str




# ============================================================================
# SliceSensors
# ============================================================================

class SliceSensors:
    def __init__(self, W: int = 80, topk: int = 16):
        self.W = W
        self.topk = topk
        self.theta = [2.0 * math.pi * m / W for m in range(W)]

    # --- projections & helpers ---
    @staticmethod
    def _project_stream(vals: Sequence[int], base: int, theta: float) -> List[float]:
        # Treat each sample as a point on its base-gon; project onto direction θ
        out: List[float] = []
        for v in vals:
            ang = 2.0 * math.pi * (v % base) / base
            out.append(math.cos(ang - theta))
        return out

    @staticmethod
    def _argmax_idx(arr: Sequence[float]) -> int:
        best = -1e9; idx = 0
        for i, x in enumerate(arr):
            if x > best:
                best = x; idx = i
        return idx

    @staticmethod
    def _quadrant_bins(vals: Sequence[int], base: int, theta: float) -> Tuple[int,int,int,int]:
        # Bin positions after rotation; 4 equal arcs on the circle
        bins = [0,0,0,0]
        for v in vals:
            ang = (2.0 * math.pi * (v % base) / base - theta) % (2.0 * math.pi)
            q = int((ang / (2.0 * math.pi)) * 4.0) % 4
            bins[q] += 1
        return (bins[0], bins[1], bins[2], bins[3])

    @staticmethod
    def _chord_hist(vals: Sequence[int], base: int) -> Dict[int,int]:
        c: Dict[int,int] = {}
        for a, b in zip(vals, vals[1:]):
            step = (b - a) % base
            c[step] = c.get(step, 0) + 1
        return c

    @staticmethod
    def _perm_by_projection(vals: Sequence[int], base: int, theta: float, topk: int) -> List[int]:
        proj = SliceSensors._project_stream(vals, base, theta)
        order = sorted(range(len(vals)), key=lambda i: proj[i], reverse=True)
        return order[:min(topk, len(order))]

    @staticmethod
    def _adjacent_transpositions(prev: List[int], curr: List[int]) -> int:
        # Count inversions between adjacent elements moving from prev to curr (small topk, O(n^2) ok)
        pos_curr = {v: i for i, v in enumerate(curr)}
        common = [v for v in prev if v in pos_curr]
        mapped = [pos_curr[v] for v in common]
        inv = 0
        for i in range(len(mapped)):
            for j in range(i+1, len(mapped)):
                if mapped[i] > mapped[j]:
                    inv += 1
        return inv

    def compute(self, face: Face) -> SliceObservables:
        W, base, vals = self.W, face.base, face.values
        theta = self.theta
        extreme_idx: List[int] = []
        quadrant_bins: List[Tuple[int,int,int,int]] = []
        chord_hist: List[Dict[int,int]] = []
        perm: List[List[int]] = []
        braid_current: List[int] = []

        prev_order: Optional[List[int]] = None
        for th in theta:
            proj = self._project_stream(vals, base, th)
            extreme_idx.append(self._argmax_idx(proj))
            quadrant_bins.append(self._quadrant_bins(vals, base, th))
            chord_hist.append(self._chord_hist(vals, base))  # independent of θ in this simple model
            order = self._perm_by_projection(vals, base, th, self.topk)
            perm.append(order)
            if prev_order is None:
                braid_current.append(0)
            else:
                braid_current.append(self._adjacent_transpositions(prev_order, order))
            prev_order = order

        # Energies (Dirichlet) on discrete circle
        def dirichlet_energy_int(seq: Sequence[int]) -> float:
            n = len(seq); acc = 0.0
            for i in range(n):
                a = seq[(i+1) % n]; b = seq[i]; c = seq[(i-1) % n]
                acc += float((a - 2*b + c)**2)
            return acc / float(max(1, n))

        def q_imbalance_energy(qbins: Sequence[Tuple[int,int,int,int]]) -> float:
            e = 0.0
            for q in qbins:
                m = sum(q) / 4.0
                e += sum((qi - m)**2 for qi in q)
            return e / float(max(1, len(qbins)))

        energies = {
            "E_extreme": dirichlet_energy_int(extreme_idx),
            "E_quads": q_imbalance_energy(quadrant_bins),
            "Crossings": float(sum(braid_current)),
        }
        return SliceObservables(theta, extreme_idx, quadrant_bins, chord_hist, perm, braid_current, energies)

# -----------------------------------------------------------------------------
# Actuators
# -----------------------------------------------------------------------------




# ============================================================================
# glyphs
# ============================================================================



# Simple glyph table: maps runes to AST constructors
GLYPH_TABLE: Dict[str, Any] = {
    "λ": A.Lam,
    "•": A.App,
    "×": A.Pair,
    "→": "ARROW",  # used in types, not terms
    "μ": A.Mu,
    "⊳": A.Fst,
    "⊲": A.Snd,
}

def parse_tokens(tokens):
    # Minimal demo parser; real grammar would be EBNF.
    stack = []
    for t in tokens:
        if t == "true": stack.append(A.Const("true", True))
        elif t == "false": stack.append(A.Const("false", False))
        elif t.isdigit(): stack.append(A.Const("nat", int(t)))
        elif t == "pair":
            b = stack.pop(); a = stack.pop(); stack.append(A.Pair(a,b))
        elif t == "fst": stack.append(A.Fst(stack.pop()))
        elif t == "snd": stack.append(A.Snd(stack.pop()))
        else:
            stack.append(A.Var(t))
    return stack[-1] if stack else None



