#!/usr/bin/env python3
"""
GENESIS_MINI - Minimal Genesis blockchain node with E8 ledger core

Auto-generated custom tool using CQE monolith building blocks.

Available modules:
# - Runtime
# - GeometryTransformerStandaloneV2
# - GeoTokenizerTieinV1
# - ReceiptsBridge
# - StateStore
# - Callbacks
# - AnalyticsCli
# - ApiServer
# - CqeGovernance
# - SpeedlightSidecar
"""

import sys
from pathlib import Path

# Add module paths
MODULES_DIR = Path(__file__).parent / "modules"
sys.path.insert(0, str(MODULES_DIR))

def main():
    print("🚀 GENESIS_MINI")
    print("Minimal Genesis blockchain node with E8 ledger core")
    print()
    print("Available modules:")
    
    modules = ['"Runtime"', '"GeometryTransformerStandaloneV2"', '"GeoTokenizerTieinV1"', '"ReceiptsBridge"', '"StateStore"', '"Callbacks"', '"AnalyticsCli"', '"ApiServer"', '"CqeGovernance"', '"SpeedlightSidecar"']
    
    for mod_name in modules:
        try:
            __import__(mod_name)
            print(f"  ✓ {mod_name}")
        except Exception as e:
            print(f"  ✗ {mod_name}: {e}")
    
    print()
    print("Use: from <module> import <class>")

if __name__ == '__main__':
    main()
