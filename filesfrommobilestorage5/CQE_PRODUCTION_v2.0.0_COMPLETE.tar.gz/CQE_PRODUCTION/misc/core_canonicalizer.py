def canonicalizer(e8_lattice):
    """Canonicalizer instance"""
    return Canonicalizer(e8_lattice)


@pytest.fixture