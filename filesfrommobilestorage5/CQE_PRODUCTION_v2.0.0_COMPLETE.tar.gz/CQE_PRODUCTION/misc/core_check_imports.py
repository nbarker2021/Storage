def check_imports():
    """Verify all core imports work"""
    print("Checking imports...")

    try:
        from cqe import CQEClient, __version__
        from cqe.core.lattice import E8Lattice
        from cqe.core.overlay import CQEOverlay
        from cqe.morsr.protocol import MORSRProtocol
        from cqe.operators.rotation import RotationOperator
        print(f"  ✓ All imports successful (CQE v{__version__})")
        return True
    except ImportError as e:
        print(f"  ✗ Import failed: {e}")
        return False

