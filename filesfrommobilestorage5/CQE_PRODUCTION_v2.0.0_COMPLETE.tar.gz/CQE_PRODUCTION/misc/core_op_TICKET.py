def op_TICKET(st:O8State, args):
    # Boundary tickets across both 8D blocks
    V0, di0, dh0, cos0, alt0 = e8_snap_block(st.X[:,:8])
    V1, di1, dh1, cos1, alt1 = e8_snap_block(st.X[:,8:16])
    m0 = coset_margin(di0, dh0); m1 = coset_margin(di1, dh1)
    mask = (m0 <= st.tau_w) | (m1 <= st.tau_w)
    st.tickets = {"idx": np.where(mask)[0], "m_min": np.minimum(m0, m1), "move_cost": np.linalg.norm(np.hstack([alt0,alt1]) - np.hstack([V0,V1]), axis=1)}
    st.log("TICKETS","boundary found", {"count": int(mask.sum())})
    return {"count": int(mask.sum())}
