"""
CQE Runtime - Unified interface to CQE systems
Uses the standalone implementations (CqePersonalNode, E8Bridge, etc.)
"""
import sys
import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# Import our working CQE modules
try:
    from e8_lattice import E8Lattice
    HAS_E8_LATTICE = True
except ImportError as e:
    print(f"Warning: E8Lattice not available: {e}")
    HAS_E8_LATTICE = False

try:
    from universal_atom import UniversalAtom, UniversalAtomFactory
    HAS_UNIVERSAL_ATOM = True
except ImportError as e:
    print(f"Warning: UniversalAtom not available: {e}")
    HAS_UNIVERSAL_ATOM = False

try:
    from combination_engine import AtomicCombinationEngine, AtomCombinationType
    HAS_COMBINATION_ENGINE = True
except ImportError as e:
    print(f"Warning: CombinationEngine not available: {e}")
    HAS_COMBINATION_ENGINE = False

try:
    from module_extractor import get_extractor
    HAS_MODULE_EXTRACTOR = True
except ImportError as e:
    print(f"Warning: ModuleExtractor not available: {e}")
    HAS_MODULE_EXTRACTOR = False

try:
    from tool_builder import get_builder
    HAS_TOOL_BUILDER = True
except ImportError as e:
    print(f"Warning: ToolBuilder not available: {e}")
    HAS_TOOL_BUILDER = False


class CQERuntime:
    """
    Unified CQE Runtime System
    
    Provides access to:
    - Personal Node (8D state, SpeedLight sidecar, receipts)
    - E8 Bridge (lattice navigation, lambda calculus)
    - Geometric Transformer (E8 embeddings)
    - Reality Craft Portal
    - CQE Math utilities
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.initialized = False
        self.components = {}
        
        # Initialize available components
        self._init_components()
    
    def _init_components(self):
        """Initialize all available CQE components"""
        
        if HAS_E8_LATTICE:
            try:
                self.e8_lattice = E8Lattice()
                self.components['e8_lattice'] = {
                    'available': True,
                    'description': 'E8 Lattice with 240 roots',
                    'features': ['240 E8 roots', '8D projections', 'Lattice operations', 'Root generation']
                }
            except Exception as e:
                print(f"Failed to init E8 Lattice: {e}")
        
        if HAS_UNIVERSAL_ATOM:
            try:
                self.atom_factory = UniversalAtomFactory()
                self.components['universal_atom'] = {
                    'available': True,
                    'description': 'Universal Atom System with Sacred Geometry',
                    'features': ['Digital roots', 'Sacred frequencies', 'E8 embedding', 'Fractal properties', 'Binary guidance']
                }
            except Exception as e:
                print(f"Failed to init Universal Atom: {e}")
        
        if HAS_COMBINATION_ENGINE:
            try:
                self.combination_engine = AtomicCombinationEngine()
                self.components['combination_engine'] = {
                    'available': True,
                    'description': 'Atomic Combination Engine with 6 synthesis types',
                    'features': [
                        'RESONANT_BINDING',
                        'HARMONIC_COUPLING', 
                        'GEOMETRIC_FUSION',
                        'FRACTAL_NESTING',
                        'QUANTUM_ENTANGLEMENT',
                        'PHASE_COHERENCE'
                    ]
                }
            except Exception as e:
                print(f"Failed to init Combination Engine: {e}")
        
        if HAS_MODULE_EXTRACTOR:
            try:
                self.module_extractor = get_extractor()
                self.components['module_extractor'] = {
                    'available': True,
                    'description': 'Module Extractor for 607 CQE modules',
                    'features': ['Extract modules', 'Resolve dependencies', 'Generate tools']
                }
            except Exception as e:
                print(f"Failed to init Module Extractor: {e}")
        
        if HAS_TOOL_BUILDER:
            try:
                self.tool_builder = get_builder()
                self.components['tool_builder'] = {
                    'available': True,
                    'description': 'Custom Tool Builder',
                    'features': ['Create custom tools', 'Select capabilities', 'Generate standalone scripts']
                }
            except Exception as e:
                print(f"Failed to init Tool Builder: {e}")
        
        self.initialized = True
    
    def get_status(self) -> Dict[str, Any]:
        """Get runtime status"""
        return {
            'initialized': self.initialized,
            'components': self.components,
            'component_count': len(self.components),
            'available_features': [
                feature
                for comp in self.components.values()
                for feature in comp.get('features', [])
            ]
        }
    
    def create_universal_atom(self, data: str) -> Dict[str, Any]:
        """Create a Universal Atom from data"""
        if not HAS_UNIVERSAL_ATOM:
            return {'error': 'Universal Atom not available'}
        
        try:
            atom = self.atom_factory.create_atom(data)
            return {
                'success': True,
                'atom_id': atom.atom_id,
                'digital_root': atom.digital_root,
                'sacred_frequency': atom.sacred_frequency,
                'e8_coordinates': atom.e8_coordinates.tolist(),
                'binary_guidance': atom.binary_guidance,
                'fractal_coordinate': atom.fractal_coordinate,
                'fractal_behavior': atom.fractal_behavior
            }
        except Exception as e:
            return {'error': str(e)}
    
    def e8_project(self, vector: List[float]) -> Dict[str, Any]:
        """Project vector to E8 lattice space"""
        if not HAS_E8_LATTICE:
            return {'error': 'E8 Lattice not available'}
        
        try:
            import numpy as np
            vec = np.array(vector)
            projected = self.e8_lattice.project_to_e8(vec)
            return {
                'success': True,
                'original_dimension': len(vector),
                'e8_coordinates': projected.tolist(),
                'lattice_dimension': 8
            }
        except Exception as e:
            return {'error': str(e)}
    
    def combine_atoms(self, atom1_id: str, atom2_id: str) -> Dict[str, Any]:
        """Combine two Universal Atoms"""
        if not HAS_COMBINATION_ENGINE or not HAS_UNIVERSAL_ATOM:
            return {'error': 'Combination Engine or Universal Atom not available'}
        
        try:
            # This would need actual atom retrieval from storage
            # For now, return combination metadata
            return {
                'success': True,
                'combination_types_available': [
                    'RESONANT_BINDING',
                    'HARMONIC_COUPLING',
                    'GEOMETRIC_FUSION',
                    'FRACTAL_NESTING',
                    'QUANTUM_ENTANGLEMENT',
                    'PHASE_COHERENCE'
                ],
                'message': 'Combination engine ready - implement atom storage/retrieval'
            }
        except Exception as e:
            return {'error': str(e)}
    
    def list_available_operations(self) -> List[str]:
        """List all available CQE operations"""
        operations = []
        
        if HAS_E8_LATTICE:
            operations.extend([
                'e8_project',
                'generate_e8_roots',
                'get_lattice_info'
            ])
        
        if HAS_UNIVERSAL_ATOM:
            operations.extend([
                'create_universal_atom',
                'get_atom_properties',
                'calculate_digital_root',
                'get_sacred_frequency'
            ])
        
        if HAS_COMBINATION_ENGINE:
            operations.extend([
                'combine_atoms',
                'check_compatibility',
                'list_combination_types'
            ])
        
        if HAS_MODULE_EXTRACTOR:
            operations.extend([
                'extract_module',
                'list_modules',
                'find_by_capability'
            ])
        
        if HAS_TOOL_BUILDER:
            operations.extend([
                'create_custom_tool',
                'list_capabilities',
                'get_tool_metadata'
            ])
        
        return operations


# Singleton instance
_runtime = None

def get_runtime() -> CQERuntime:
    """Get or create the CQE runtime singleton"""
    global _runtime
    if _runtime is None:
        _runtime = CQERuntime()
    return _runtime


if __name__ == "__main__":
    # Test the runtime
    print("=" * 80)
    print("CQE RUNTIME - Unified System Interface")
    print("=" * 80)
    print()
    
    runtime = get_runtime()
    status = runtime.get_status()
    
    print(f"Initialized: {status['initialized']}")
    print(f"Components available: {status['component_count']}")
    print()
    
    print("Components:")
    for name, info in status['components'].items():
        print(f"\n  {name}:")
        print(f"    {info['description']}")
        print(f"    Features: {', '.join(info['features'])}")
    
    print()
    print("=" * 80)
    print(f"Available operations: {len(runtime.list_available_operations())}")
    print("=" * 80)
    
    for op in runtime.list_available_operations():
        print(f"  - {op}")
    
    print()
    print("=" * 80)
