class ToroidalState:
    """State on toroidal manifold."""
    poloidal_angle: float  # θ ∈ [0, 2π) - around minor circle
    toroidal_angle: float  # φ ∈ [0, 2π) - around major circle
    meridional_phase: float  # ψ ∈ [0, 2π) - along meridian
    helical_phase: float  # ω ∈ [0, 2π) - helical (gravitational)
    
    e8_embedding: np.ndarray  # (8,) E8 coordinates
    timestamp: float  # Time in seconds
    
    def to_cartesian(self, R: float = MAJOR_RADIUS, 
                    r: float = MINOR_RADIUS) -> Tuple[float, float, float]:
        """Convert to 3D Cartesian coordinates."""
        x = (R + r * np.cos(self.poloidal_angle)) * np.cos(self.toroidal_angle)
        y = (R + r * np.cos(self.poloidal_angle)) * np.sin(self.toroidal_angle)
        z = r * np.sin(self.poloidal_angle)
        return x, y, z

