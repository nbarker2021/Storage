def e8_snap_block(X):
    N = X.shape[0]
    V = np.zeros_like(X); di = np.zeros(N); dh = np.zeros(N)
    altV = np.zeros_like(X)
    coset = np.empty(N, dtype=object)
    for i in range(N):
        vb, db, d0, d1, c, av = e8_nearest(X[i])
        V[i]=vb; di[i]=d0; dh[i]=d1; coset[i]=c; altV[i]=av
    return V, di, dh, coset, altV
