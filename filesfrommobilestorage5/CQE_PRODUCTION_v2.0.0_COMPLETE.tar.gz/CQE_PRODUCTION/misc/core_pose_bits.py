def pose_bits(X, V, R=None):
    if R is None: R = np.eye(8)
    Rroots = E8_ROOTS @ R.T
    Rroots = Rroots / (np.linalg.norm(Rroots, axis=1, keepdims=True)+1e-9)
    Rres = X - V
    S = (Rres @ Rroots.T)
    return (S >= 0).astype(int)
