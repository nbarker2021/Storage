def text_to_faces(text: str) -> Tuple[Face, Face]:
    """Map text into two aligned numeric streams: mod10 (decagon) and mod8 (octagon). Deterministic."""
    # FNV-1a 64-bit rolling hash over bytes; split into bases.
    h = 0xcbf29ce484222325  # FNV offset
    d10: List[int] = []
    d8: List[int] = []
    for ch in text.encode("utf-8", errors="ignore"):
        h ^= ch
        h = (h * 0x100000001b3) & ((1<<64)-1)  # FNV prime
        d10.append((h // 2654435761) % 10)
        d8.append((h // 11400714819323198485) % 8)
    if not d10:
        d10 = [0]; d8 = [0]
    return Face(d10, 10, "decagon"), Face(d8, 8, "octagon")

# -----------------------------------------------------------------------------
# Slice lattice & observables
# -----------------------------------------------------------------------------

@dc.dataclass