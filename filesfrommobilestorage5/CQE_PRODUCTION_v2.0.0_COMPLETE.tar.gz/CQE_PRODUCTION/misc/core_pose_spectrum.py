def pose_spectrum(X8, V, R):
    P = pose_bits(X8, V, E8_ROOTS, R)
    powers = (1 << np.arange(P.shape[1]))[::-1]
    ints = P @ powers
    vals, counts = np.unique(ints, return_counts=True)
    return pd.DataFrame({"pose_code": vals, "count": counts}).sort_values("count", ascending=False)
