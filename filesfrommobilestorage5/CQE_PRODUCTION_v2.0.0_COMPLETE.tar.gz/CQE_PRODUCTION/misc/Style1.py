

body { font-family: system-ui, sans-serif; margin: 12px; }
header { display: flex; align-items: center; gap: 16px; }
.controls { display: flex; align-items: center; gap: 8px; }
#grid { display: grid; grid-template-columns: repeat(6, 1fr); grid-auto-rows: 180px; gap: 6px; margin-top: 12px; }
.screen { position: relative; border: 1px solid #bbb; background: #fff; }
.screen canvas { width: 100%; height: 100%; display: block; image-rendering: pixelated; }
.label { position: absolute; left: 6px; top: 4px; font-size: 12px; background: rgba(255,255,255,0.8); padding: 2px 4px; border-radius: 4px; }
.badge { position: absolute; right: 6px; top: 4px; font-size: 11px; background: rgba(0,0,0,0.5); color:#fff; padding: 2px 4px; border-radius: 4px; }
textarea { width: 360px; height: 70px; }

