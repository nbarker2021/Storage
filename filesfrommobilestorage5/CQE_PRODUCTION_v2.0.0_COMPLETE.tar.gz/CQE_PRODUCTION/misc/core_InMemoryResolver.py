class InMemoryResolver(RefResolver):
    def __init__(self):
        super().__init__(base_uri=E8_SCHEMA.get("$id",""), referrer=E8_SCHEMA)
        self.store = {
            E8_SCHEMA["$id"]: E8_SCHEMA,
            SNAP_SCHEMA["$id"]: SNAP_SCHEMA
        }
