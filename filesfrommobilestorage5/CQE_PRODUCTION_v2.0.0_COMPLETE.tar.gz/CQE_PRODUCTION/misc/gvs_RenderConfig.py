class RenderConfig:
    """Rendering configuration."""
    resolution: Tuple[int, int] = (1920, 1080)
    fps: float = 30.0
    color_depth: int = 8  # bits per channel
    anti_aliasing: bool = True
    super_sampling: int = 1  # 1=none, 2=2x2, 4=4x4
    
    def total_pixels(self) -> int:
        return self.resolution[0] * self.resolution[1]

