class WorldType(Enum):
    """Types of worlds that can be forged."""
    RIEMANN = "riemann"  # Mathematical/abstract world
    YANG_MILLS = "yangmills"  # Physical/particle world
    HODGE = "hodge"  # Algebraic/geometric world
    LEECH = "leech"  # Lattice/crystalline world
    NATURAL = "natural"  # Natural/organic world
    URBAN = "urban"  # Urban/architectural world
    COSMIC = "cosmic"  # Cosmic/astronomical world
    QUANTUM = "quantum"  # Quantum/microscopic world
    CUSTOM = "custom"  # Custom user-defined world


@dataclass