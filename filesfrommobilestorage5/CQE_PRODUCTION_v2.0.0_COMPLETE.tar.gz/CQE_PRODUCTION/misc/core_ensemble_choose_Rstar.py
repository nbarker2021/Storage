def ensemble_choose_Rstar(ensemble, Rset):
    per_pack = {}
    for name, X8 in ensemble.items():
        V, d_best, di, dh, coset, altV = e8_snap_block(X8)
        margins = coset_margin(di, dh)
        per_pack[name] = {"X8":X8, "V":V, "margins":margins}
    best_rate = -1.0; best_R = None; perR_store = {}
    for R in Rset:
        rates = []
        for name, st in per_pack.items():
            P = pose_bits(st["X8"], st["V"], E8_ROOTS, R)
            r, ints = alignment_rate(P)
            rates.append(r)
        mean_rate = float(np.mean(rates))
        perR_store[str(id(R))] = float(mean_rate)
        if mean_rate > best_rate:
            best_rate = mean_rate; best_R = R
    return best_R, best_rate, per_pack, perR_store
