class DimensionalConfig:
    """Configuration for E₈ dimensional enforcement."""
    lattice_rank: int = 8
    minimal_vectors: int = 240
    snap_tolerance: float = 1e-6
    adjacency_check: bool = True
    phase_slope_validation: bool = True
    geometric_proofs: bool = True
