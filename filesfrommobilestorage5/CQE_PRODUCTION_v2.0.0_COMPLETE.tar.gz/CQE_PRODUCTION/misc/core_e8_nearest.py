def e8_nearest(y):
    z0 = np.rint(y)
    if (int(np.sum(z0)) & 1) == 1:
        frac = np.abs(y - z0); k = int(np.argmin(frac))
        z0[k] += 1 if y[k] > z0[k] else -1
    d0 = np.linalg.norm(y - z0)
    yh = y - 0.5
    z1 = np.rint(yh)
    if (int(np.sum(z1)) & 1) == 1:
        frac = np.abs(yh - z1); k = int(np.argmin(frac))
        z1[k] += 1 if yh[k] > z1[k] else -1
    x1 = z1 + 0.5
    d1 = np.linalg.norm(y - x1)
    if d0 <= d1:
        return z0, d0, d0, d1, "int", x1
    else:
        return x1, d1, d0, d1, "half", z0
