def op_POSE(st:O8State, args):
    # Choose rotation maximizing alignment for first 8D block
    X8 = st.X[:,:8]
    V, di, dh, coset, altV = e8_snap_block(X8)
    best=None; bestR=None
    for R in st.rotset:
        P = pose_bits(X8, V, R); r = alignment_rate(P)
        if best is None or r>best: best=r; bestR=R
    st.R = bestR
    st.log("POSE","gauge set", {"alignment": float(best)})
    return {"alignment": float(best)}
