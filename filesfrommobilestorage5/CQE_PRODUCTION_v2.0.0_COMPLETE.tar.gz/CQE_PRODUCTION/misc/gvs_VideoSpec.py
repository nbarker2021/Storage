class VideoSpec:
    """Video generation specification."""
    prompt: str
    duration: float  # seconds
    fps: float = 30.0
    resolution: Tuple[int, int] = (1920, 1080)
    world_type: WorldType = WorldType.NATURAL
    seed: Optional[int] = None
    
    def total_frames(self) -> int:
        return int(self.duration * self.fps)

