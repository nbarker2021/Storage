class TQFConfig:
    """Configuration for TQF governance system."""
    quaternary_encoding: bool = True
    orbit4_symmetries: bool = True
    crt_locking: bool = True
    resonant_gates: bool = True
    e_scalar_metrics: bool = True
    acceptance_thresholds: Dict[str, float] = field(default_factory=lambda: {
        "E4": 0.0, "E6": 0.0, "E8": 0.25
    })

@dataclass