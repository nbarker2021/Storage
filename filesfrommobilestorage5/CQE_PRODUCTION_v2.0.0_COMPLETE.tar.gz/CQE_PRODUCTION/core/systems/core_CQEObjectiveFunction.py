class CQEObjectiveFunction:
    def __init__(self, e8_lattice: E8Lattice, parity_channels: ParityChannels)
    
    def evaluate(self, vector: np.ndarray, reference_channels: Dict[str, float],
                domain_context: Optional[Dict] = None) -> Dict[str, float]
    
    def gradient(self, vector: np.ndarray, reference_channels: Dict[str, float],
                domain_context: Optional[Dict] = None, epsilon: float = 1e-5) -> np.ndarray
    
    def suggest_improvement_direction(self, vector: np.ndarray,
                                    reference_channels: Dict[str, float],
                                    domain_context: Optional[Dict] = None) -> Tuple[np.ndarray, Dict[str, str]]
    
    def set_weights(self, new_weights: Dict[str, float])
```

### MORSRExplorer

Multi-objective random search and repair algorithm.

```python