class CQERunner:
    def __init__(self, e8_embedding_path: str = "embeddings/e8_248_embedding.json", 
                 config: Optional[Dict] = None)
    
    def solve_problem(self, problem_description: Dict, 
                     domain_type: str = "computational") -> Dict[str, Any]
    
    def run_test_suite(self) -> Dict[str, bool]
    
    def benchmark_performance(self, problem_sizes: List[int] = [10, 50, 100, 200]) -> Dict
```

### DomainAdapter

Converts problems to E₈-compatible feature vectors.

```python