class CQEToken:
    """Enhanced token representation with CQE overlay"""
    original_token: Any
    e8_embedding: np.ndarray  # 8D E8 projection
    cartan_offset: np.ndarray  # Continuous Cartan coordinates
    root_index: int  # Discrete root index (0-239)
    parity_state: int  # Parity class (mod 3)
    phi_components: Dict[str, float]  # Four-term objective values
    metadata: Dict[str, Any]
    provenance_hash: str  # Content-addressed hash
    
    def to_dict(self):
        result = asdict(self)
        result['e8_embedding'] = self.e8_embedding.tolist()
        result['cartan_offset'] = self.cartan_offset.tolist()
        return result
