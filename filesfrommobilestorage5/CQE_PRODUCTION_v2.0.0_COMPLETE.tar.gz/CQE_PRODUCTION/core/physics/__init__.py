"""physics module"""
