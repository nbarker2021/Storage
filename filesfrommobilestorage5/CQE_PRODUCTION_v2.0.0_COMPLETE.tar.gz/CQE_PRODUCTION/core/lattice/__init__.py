"""CQE Lattice Module"""
