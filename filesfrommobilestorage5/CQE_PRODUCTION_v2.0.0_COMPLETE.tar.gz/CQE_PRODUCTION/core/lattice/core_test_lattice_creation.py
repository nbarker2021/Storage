def test_lattice_creation(e8_lattice):
    """Test E8 lattice initialization"""
    assert e8_lattice.dimension == 8
    assert e8_lattice.num_roots == 240
    assert e8_lattice.total_slots == 248

