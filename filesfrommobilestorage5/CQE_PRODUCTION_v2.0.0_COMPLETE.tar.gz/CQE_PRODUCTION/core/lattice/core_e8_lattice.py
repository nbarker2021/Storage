def e8_lattice():
    """E8 lattice instance"""
    return E8Lattice()


@pytest.fixture