-- MonsterMoonshineDB Schema
CREATE TABLE IF NOT EXISTS embeddings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE NOT NULL,
    source TEXT,
    vector_json TEXT NOT NULL,  -- JSON array of 24 floats
    norm REAL,
    lattice_point TEXT DEFAULT 'Leech',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_embeddings_key ON embeddings(key);
CREATE INDEX idx_embeddings_source ON embeddings(source);
CREATE INDEX idx_embeddings_norm ON embeddings(norm);

CREATE TABLE IF NOT EXISTS relationships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_concept TEXT NOT NULL,
    to_concept TEXT NOT NULL,
    strength REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_relationships_from ON relationships(from_concept);
CREATE INDEX idx_relationships_to ON relationships(to_concept);
