"""
E8 Lattice Operations
Extracted from CQE_CORE_MONOLITH_fixed.py and GeometricTransformerStandalone.py

E₈ lattice structure for geometric constraints.
Provides the 240 root vectors of E₈.
"""


from typing import List, Tuple

# Core Constants
E8_ROOTS_COUNT = 240
E8_NORM = np.sqrt(2)
E8_DIMENSION = 8


class E8Lattice:
    """
    E₈ lattice structure for geometric constraints.
    Provides the 240 root vectors of E₈.
    """
    
    @staticmethod
    def get_roots() -> np.ndarray:
        """
        Generate the 240 root vectors of E₈.
        
        Returns:
            np.ndarray: Array of shape (240, 8) containing all E8 root vectors
        """
        roots = []
        
        # Type 1: All permutations of (±1, ±1, 0, 0, 0, 0, 0, 0)
        # 112 roots
        for i in range(8):
            for j in range(i+1, 8):
                for s1 in [1, -1]:
                    for s2 in [1, -1]:
                        root = [0] * 8
                        root[i] = s1
                        root[j] = s2
                        roots.append(root)
        
        # Type 2: (±1/2, ±1/2, ±1/2, ±1/2, ±1/2, ±1/2, ±1/2, ±1/2)
        # with even number of minus signs
        # 128 roots
        for signs in range(256):
            root = []
            num_minus = 0
            for bit in range(8):
                if signs & (1 << bit):
                    root.append(0.5)
                else:
                    root.append(-0.5)
                    num_minus += 1
            if num_minus % 2 == 0:
                roots.append(root)
        
        return np.array(roots[:240])  # Ensure exactly 240 roots
    
    @staticmethod
    def project_to_e8(vector: np.ndarray) -> np.ndarray:
        """
        Project a vector onto the nearest E₈ lattice point.
        This enforces geometric constraints.
        
        Args:
            vector: Input vector (any dimension, will be padded/truncated to 8D)
            
        Returns:
            np.ndarray: Projected vector on E8 lattice
        """
        # Ensure 8D
        if len(vector) < 8:
            vector = np.pad(vector, (0, 8 - len(vector)), 'constant')
        elif len(vector) > 8:
            vector = vector[:8]
        
        # Simplified projection: round to nearest lattice point
        # In full implementation, would use Voronoi cell
        return np.round(vector * 2) / 2
    
    @staticmethod
    def normalize_to_e8_norm(vector: np.ndarray) -> np.ndarray:
        """
        Normalize vector to E8 standard norm (√2).
        
        Args:
            vector: Input 8D vector
            
        Returns:
            np.ndarray: Normalized vector with norm √2
        """
        current_norm = np.linalg.norm(vector)
        if current_norm == 0:
            return vector
        return vector * (E8_NORM / current_norm)
    
    @staticmethod
    def get_weyl_chambers() -> int:
        """
        Get the number of Weyl chambers in E8.
        
        Returns:
            int: 48 Weyl chambers
        """
        return 48
    
    @staticmethod
    def get_weyl_group_order() -> int:
        """
        Get the order of the Weyl group.
        
        Returns:
            int: 696,729,600 = 2¹⁴ × 3⁵ × 5² × 7
        """
        return 696729600
    
    @staticmethod
    def embed_to_e8(data: np.ndarray) -> np.ndarray:
        """
        Embed arbitrary data into E8 lattice space.
        
        Args:
            data: Input data (any shape)
            
        Returns:
            np.ndarray: 8D E8 embedding
        """
        # Flatten data
        flat = data.flatten()
        
        # Hash to 8D space
        if len(flat) < 8:
            # Pad with zeros
            embedded = np.pad(flat, (0, 8 - len(flat)), 'constant')
        elif len(flat) > 8:
            # Use modular arithmetic to compress
            embedded = np.zeros(8)
            for i, val in enumerate(flat):
                embedded[i % 8] += val
        else:
            embedded = flat
        
        # Project to E8 lattice
        projected = E8Lattice.project_to_e8(embedded)
        
        # Normalize to E8 norm
        normalized = E8Lattice.normalize_to_e8_norm(projected)
        
        return normalized
    
    @staticmethod
    def distance_in_e8(v1: np.ndarray, v2: np.ndarray) -> float:
        """
        Calculate distance between two points in E8 space.
        
        Args:
            v1: First 8D vector
            v2: Second 8D vector
            
        Returns:
            float: Euclidean distance
        """
        return np.linalg.norm(v1 - v2)
    
    @staticmethod
    def dot_product_e8(v1: np.ndarray, v2: np.ndarray) -> float:
        """
        Calculate dot product in E8 space.
        
        Args:
            v1: First 8D vector
            v2: Second 8D vector
            
        Returns:
            float: Dot product
        """
        return np.dot(v1, v2)
    
    @staticmethod
    def project_to_2d_for_visualization(vector: np.ndarray) -> Tuple[float, float]:
        """
        Project 8D E8 vector to 2D for visualization.
        Uses first two principal components.
        
        Args:
            vector: 8D E8 vector
            
        Returns:
            Tuple[float, float]: (x, y) coordinates for 2D plot
        """
        # Simple projection: use first two dimensions
        # In full implementation, would use PCA or t-SNE
        return (float(vector[0]), float(vector[1]))
    
    @staticmethod
    def get_nearest_root(vector: np.ndarray) -> np.ndarray:
        """
        Find the nearest E8 root vector to the given vector.
        
        Args:
            vector: Input 8D vector
            
        Returns:
            np.ndarray: Nearest root vector from the 240 roots
        """
        roots = E8Lattice.get_roots()
        distances = np.linalg.norm(roots - vector, axis=1)
        nearest_idx = np.argmin(distances)
        return roots[nearest_idx]
    
    @staticmethod
    def validate_e8_vector(vector: np.ndarray) -> bool:
        """
        Validate if a vector is properly formatted for E8 operations.
        
        Args:
            vector: Vector to validate
            
        Returns:
            bool: True if valid, False otherwise
        """
        if not isinstance(vector, np.ndarray):
            return False
        if vector.shape != (8,):
            return False
        if not np.isfinite(vector).all():
            return False
        return True


# Golden ratio constant (used in geometric fusion)
GOLDEN_RATIO = (1 + np.sqrt(5)) / 2


if __name__ == "__main__":
    # Test E8 lattice operations
    print("Testing E8 Lattice...")
    
    roots = E8Lattice.get_roots()
    print(f"✓ Generated {len(roots)} E8 roots")
    
    test_vector = np.array([1.2, 2.3, 3.4, 4.5, 5.6, 6.7, 7.8, 8.9])
    projected = E8Lattice.project_to_e8(test_vector)
    print(f"✓ Projected vector: {projected}")
    
    normalized = E8Lattice.normalize_to_e8_norm(projected)
    norm = np.linalg.norm(normalized)
    print(f"✓ Normalized to E8 norm: {norm:.4f} (target: {E8_NORM:.4f})")
    
    print("All E8 lattice tests passed! ✓")
