"""
CQE Utility Functions - Expanded Module
Clean, production-ready utility functions for CQE system
"""
import math
import hashlib

from typing import List, Tuple, Any, Optional, Union

# =============================================================================
# Mathematical Utilities
# =============================================================================

def compute_digital_root(n: int) -> int:
    """
    Compute digital root (repeated sum of digits until single digit).
    
    Args:
        n: Input integer
        
    Returns:
        Digital root (1-9, or 0 for n=0)
        
    Examples:
        >>> compute_digital_root(123)
        6
        >>> compute_digital_root(999)
        9
    """
    if n == 0:
        return 0
    return 1 + (n - 1) % 9

def fibonacci(n: int) -> int:
    """
    Compute nth Fibonacci number.
    
    Args:
        n: Index (0-indexed)
        
    Returns:
        Fibonacci number F(n)
    """
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

def factorial(n: int) -> int:
    """Compute factorial n!"""
    if n <= 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def gcd(a: int, b: int) -> int:
    """Greatest common divisor using Euclid's algorithm"""
    while b:
        a, b = b, a % b
    return abs(a)

def lcm(a: int, b: int) -> int:
    """Least common multiple"""
    return abs(a * b) // gcd(a, b)

def is_prime(n: int) -> bool:
    """Check if n is prime"""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        if n % i == 0:
            return False
    return True

# =============================================================================
# Geometric Utilities
# =============================================================================

def norm(v: Union[List[float], np.ndarray]) -> float:
    """Compute Euclidean norm of vector"""
    if isinstance(v, list):
        return math.sqrt(sum(x*x for x in v))
    return np.linalg.norm(v)

def normalize(v: Union[List[float], np.ndarray]) -> Union[List[float], np.ndarray]:
    """Normalize vector to unit length"""
    n = norm(v)
    if n == 0:
        return v
    if isinstance(v, list):
        return [x/n for x in v]
    return v / n

def dot_product(v1: List[float], v2: List[float]) -> float:
    """Compute dot product of two vectors"""
    return sum(a*b for a, b in zip(v1, v2))

def angle_between(v1: List[float], v2: List[float]) -> float:
    """Compute angle between two vectors (in radians)"""
    dot = dot_product(v1, v2)
    n1, n2 = norm(v1), norm(v2)
    if n1 == 0 or n2 == 0:
        return 0.0
    cos_angle = dot / (n1 * n2)
    cos_angle = max(-1.0, min(1.0, cos_angle))  # Clamp for numerical stability
    return math.acos(cos_angle)

def distance(v1: List[float], v2: List[float]) -> float:
    """Compute Euclidean distance between two points"""
    return math.sqrt(sum((a-b)**2 for a, b in zip(v1, v2)))

def project_onto(v: List[float], onto: List[float]) -> List[float]:
    """Project vector v onto vector onto"""
    dot_v_onto = dot_product(v, onto)
    dot_onto_onto = dot_product(onto, onto)
    if dot_onto_onto == 0:
        return [0.0] * len(v)
    scale = dot_v_onto / dot_onto_onto
    return [scale * x for x in onto]

def reflect(v: List[float], normal: List[float]) -> List[float]:
    """Reflect vector v across plane with given normal"""
    proj = project_onto(v, normal)
    return [v[i] - 2*proj[i] for i in range(len(v))]

def rotate_2d(x: float, y: float, angle: float) -> Tuple[float, float]:
    """Rotate 2D point by angle (radians)"""
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    return (x * cos_a - y * sin_a, x * sin_a + y * cos_a)

# =============================================================================
# Interpolation Utilities
# =============================================================================

def lerp(a: float, b: float, t: float) -> float:
    """Linear interpolation between a and b"""
    return a + (b - a) * t

def clamp(x: float, min_val: float, max_val: float) -> float:
    """Clamp x to [min_val, max_val]"""
    return max(min_val, min(max_val, x))

def smoothstep(edge0: float, edge1: float, x: float) -> float:
    """Smooth interpolation (Hermite interpolation)"""
    t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)

def interpolate_vectors(v1: List[float], v2: List[float], t: float) -> List[float]:
    """Linearly interpolate between two vectors"""
    return [lerp(a, b, t) for a, b in zip(v1, v2)]

# =============================================================================
# Hashing & Encoding Utilities
# =============================================================================

def hash_sha256(data: Union[str, bytes]) -> str:
    """Compute SHA-256 hash"""
    if isinstance(data, str):
        data = data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()

def hash_to_int(data: Union[str, bytes], modulo: Optional[int] = None) -> int:
    """Hash data to integer"""
    h = hash_sha256(data)
    val = int(h, 16)
    if modulo:
        return val % modulo
    return val

def murmur_hash_32(data: bytes, seed: int = 0) -> int:
    """
    Simple MurmurHash3 32-bit implementation.
    
    Args:
        data: Bytes to hash
        seed: Hash seed
        
    Returns:
        32-bit hash value
    """
    c1 = 0xcc9e2d51
    c2 = 0x1b873593
    
    length = len(data)
    h1 = seed
    roundedEnd = (length & 0xfffffffc)
    
    for i in range(0, roundedEnd, 4):
        k1 = (data[i] & 0xff) | ((data[i+1] & 0xff) << 8) | \
             ((data[i+2] & 0xff) << 16) | (data[i+3] << 24)
        k1 *= c1
        k1 = (k1 << 15) | ((k1 & 0xffffffff) >> 17)
        k1 *= c2
        h1 ^= k1
        h1 = (h1 << 13) | ((h1 & 0xffffffff) >> 19)
        h1 = h1 * 5 + 0xe6546b64
    
    k1 = 0
    val = length & 0x03
    if val == 3:
        k1 = (data[roundedEnd + 2] & 0xff) << 16
    if val in [2, 3]:
        k1 |= (data[roundedEnd + 1] & 0xff) << 8
    if val in [1, 2, 3]:
        k1 |= data[roundedEnd] & 0xff
        k1 *= c1
        k1 = (k1 << 15) | ((k1 & 0xffffffff) >> 17)
        k1 *= c2
        h1 ^= k1
    
    h1 ^= length
    h1 ^= ((h1 & 0xffffffff) >> 16)
    h1 *= 0x85ebca6b
    h1 ^= ((h1 & 0xffffffff) >> 13)
    h1 *= 0xc2b2ae35
    h1 ^= ((h1 & 0xffffffff) >> 16)
    
    return h1 & 0xffffffff

# =============================================================================
# Data Validation Utilities
# =============================================================================

def validate_vector_dimension(v: List[float], expected_dim: int) -> bool:
    """Check if vector has expected dimension"""
    return len(v) == expected_dim

def validate_unit_vector(v: List[float], tolerance: float = 1e-6) -> bool:
    """Check if vector is unit length"""
    return abs(norm(v) - 1.0) < tolerance

def validate_orthogonal(v1: List[float], v2: List[float], tolerance: float = 1e-6) -> bool:
    """Check if two vectors are orthogonal"""
    return abs(dot_product(v1, v2)) < tolerance

def sanitize_float(x: float, default: float = 0.0) -> float:
    """Replace NaN/Inf with default value"""
    if math.isnan(x) or math.isinf(x):
        return default
    return x

# =============================================================================
# Conversion Utilities
# =============================================================================

def degrees_to_radians(degrees: float) -> float:
    """Convert degrees to radians"""
    return degrees * math.pi / 180.0

def radians_to_degrees(radians: float) -> float:
    """Convert radians to degrees"""
    return radians * 180.0 / math.pi

def cartesian_to_polar(x: float, y: float) -> Tuple[float, float]:
    """Convert Cartesian (x,y) to polar (r, theta)"""
    r = math.sqrt(x*x + y*y)
    theta = math.atan2(y, x)
    return (r, theta)

def polar_to_cartesian(r: float, theta: float) -> Tuple[float, float]:
    """Convert polar (r, theta) to Cartesian (x,y)"""
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return (x, y)

# =============================================================================
# Statistical Utilities
# =============================================================================

def mean(values: List[float]) -> float:
    """Compute arithmetic mean"""
    if not values:
        return 0.0
    return sum(values) / len(values)

def variance(values: List[float]) -> float:
    """Compute variance"""
    if len(values) < 2:
        return 0.0
    m = mean(values)
    return sum((x - m)**2 for x in values) / (len(values) - 1)

def std_dev(values: List[float]) -> float:
    """Compute standard deviation"""
    return math.sqrt(variance(values))

def median(values: List[float]) -> float:
    """Compute median"""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    if n % 2 == 0:
        return (sorted_vals[n//2 - 1] + sorted_vals[n//2]) / 2
    return sorted_vals[n//2]

# =============================================================================
# Bit Manipulation Utilities
# =============================================================================

def popcount(n: int) -> int:
    """Count number of 1 bits in integer"""
    count = 0
    while n:
        count += n & 1
        n >>= 1
    return count

def next_power_of_2(n: int) -> int:
    """Find next power of 2 >= n"""
    if n <= 0:
        return 1
    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return n + 1

def is_power_of_2(n: int) -> bool:
    """Check if n is a power of 2"""
    return n > 0 and (n & (n - 1)) == 0

# =============================================================================
# String Utilities
# =============================================================================

def truncate_string(s: str, max_length: int, suffix: str = "...") -> str:
    """Truncate string to max length with suffix"""
    if len(s) <= max_length:
        return s
    return s[:max_length - len(suffix)] + suffix

def format_bytes(num_bytes: int) -> str:
    """Format bytes as human-readable string"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if num_bytes < 1024.0:
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.2f} PB"

def format_duration(seconds: float) -> str:
    """Format duration in seconds as human-readable string"""
    if seconds < 60:
        return f"{seconds:.2f}s"
    elif seconds < 3600:
        return f"{seconds/60:.2f}m"
    elif seconds < 86400:
        return f"{seconds/3600:.2f}h"
    else:
        return f"{seconds/86400:.2f}d"

# =============================================================================
# CQE-Specific Utilities
# =============================================================================

def phi_golden_ratio() -> float:
    """Return golden ratio Φ = (1 + √5) / 2"""
    return (1 + math.sqrt(5)) / 2

def e8_dimension() -> int:
    """Return E8 lattice dimension"""
    return 8

def niemeier_dimension() -> int:
    """Return Niemeier lattice dimension"""
    return 24

def channel_numbers() -> List[int]:
    """Return valid CQE channel numbers"""
    return [3, 6, 9]

def is_valid_channel(channel: int) -> bool:
    """Check if channel number is valid"""
    return channel in channel_numbers()
