"""
SpeedLight Dependency Tracking:
External dependencies removed: numpy
Original file: cqe_modules/core_test_lattice_info.py

NEEDS_DEPS: ["numpy"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

def test_lattice_info(e8_lattice):
    """Test lattice info retrieval"""
    info = e8_lattice.info()

    assert 'dimension' in info
    assert 'num_roots' in info
    assert info['dimension'] == 8
"""
Mathematical utility functions
"""


from typing import Tuple

