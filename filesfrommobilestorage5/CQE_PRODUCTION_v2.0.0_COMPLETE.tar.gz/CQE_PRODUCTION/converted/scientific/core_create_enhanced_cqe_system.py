"""
SpeedLight Dependency Tracking:
External dependencies removed: numpy
Original file: cqe_modules/core_create_enhanced_cqe_system.py

NEEDS_DEPS: ["numpy"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

def create_enhanced_cqe_system(governance_type: str = "hybrid", **kwargs) -> EnhancedCQESystem:
    """Factory function to create enhanced CQE system with specified governance."""
    governance_enum = GovernanceType(governance_type.lower())
    return EnhancedCQESystem(governance_type=governance_enum, **kwargs)
"""
Basic Usage Examples for CQE System

Demonstrates fundamental operations and problem-solving workflows.
"""


from cqe import CQESystem
from cqe.core import E8Lattice, MORSRExplorer, CQEObjectiveFunction
from cqe.domains import DomainAdapter
from cqe.validation import ValidationFramework
