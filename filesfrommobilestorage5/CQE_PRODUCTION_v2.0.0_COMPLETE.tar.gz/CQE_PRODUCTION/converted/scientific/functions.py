"""
CQE Utility Functions
Extracted from monolithic files
"""
import math

from typing import List, Tuple, Any, Optional


# Mathematical Functions
#==============================================================================

    def compute_digital_root(self, vector: np.ndarray) -> int:
        """Compute digital root (0-9) from E8 vector."""
        # Sum all components, reduce to single digit
        total = int(np.sum(np.abs(vector)) * 1000)  # Scale for precision
        while total >= 10:
            total = sum(int(d) for d in str(total))
        return total if total > 0 else 9


# Geometric Functions
#==============================================================================

    def project_to_lattice(self, vector: np.ndarray) -> np.ndarray:
        """Project vector to nearest E8 lattice point."""
        # Find nearest root
        distances = [np.linalg.norm(vector - root.coords) 
                    for root in self.roots]
        nearest_idx = np.argmin(distances)
        return self.roots[nearest_idx].coords


    def project_to_manifold(self, vector: np.ndarray) -> np.ndarray:
        """Project to continuous E8 manifold (unit sphere)."""
        norm = np.linalg.norm(vector)
        if norm > 0:
            return vector / norm * E8_NORM
        return vector


    def rotate_e8(self, vector: np.ndarray, axis1: int, axis2: int, 
                  angle: float) -> np.ndarray:
        """Rotate vector in E8 space around plane defined by axis1, axis2."""
        result = vector.copy()
        
        # 2D rotation in the specified plane
        cos_a = np.cos(angle)
        sin_a = np.sin(angle)
        
        x = result[axis1]
        y = result[axis2]
        
        result[axis1] = cos_a * x - sin_a * y
        result[axis2] = sin_a * x + cos_a * y
        
        return result


    def r_theta_snap(self, vector: np.ndarray) -> np.ndarray:
        """Snap to nearest Rθ position (polar snap)."""
        # Convert to polar coordinates
        r = np.linalg.norm(vector)
        
        # Snap radius to Fibonacci lattice
        fib_radii = [PHI**n * COUPLING for n in range(-10, 10)]
        nearest_r = min(fib_radii, key=lambda x: abs(x - r))
        
        # Normalize and scale
        if r > 0:
            snapped = vector / r * nearest_r
        else:
            snapped = vector
        
        return snapped


    def project_curvature(self, vector: np.ndarray, 
                         face_angle: float = 0.0) -> np.ndarray:
        """
        Project E8 face to show curvature on flat surface.
        This is the key ALENA operation - creates spacetime curvature.
        """
        # Rotate face
        rotated = self.e8.face_rotation(vector, face_angle)
        
        # Project to lower dimensions (creates curvature effect)
        # Use stereographic projection from E8 to R^7
        if abs(rotated[7] - 1.0) < 1e-6:
            # Avoid singularity at north pole
            projected = rotated[:7]
        else:
            scale = 1.0 / (1.0 - rotated[7])
            projected = rotated[:7] * scale
        
        # Embed back into E8 with curvature information
        curved = np.zeros(8)
        curved[:7] = projected
        curved[7] = np.linalg.norm(projected) * COUPLING  # Curvature measure
        
        return self.e8.project_to_manifold(curved)


    def rotate_poloidal(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Poloidal rotation (around minor circle).
        Maps to electromagnetic force (DR 1, 4, 7).
        """
        angle = dt * 2 * np.pi
        # Rotate in 0-1 plane
        R = self._rotation_matrix_e8(0, 1, angle)
        return R @ e8_state


    def rotate_toroidal(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Toroidal rotation (around major circle).
        Maps to weak nuclear force (DR 2, 5, 8).
        """
        angle = dt * 2 * np.pi
        # Rotate in 2-3 plane
        R = self._rotation_matrix_e8(2, 3, angle)
        return R @ e8_state


    def rotate_meridional(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Meridional rotation (along meridian).
        Maps to strong nuclear force (DR 3, 6, 9).
        """
        angle = dt * 2 * np.pi
        # Rotate in 4-5 plane
        R = self._rotation_matrix_e8(4, 5, angle)
        return R @ e8_state


    def rotate_helical(self, e8_state: np.ndarray, dt: float) -> np.ndarray:
        """
        Helical rotation (spiral motion).
        Maps to gravitational force (DR 0).
        This is the unifying rotation mode.
        """
        angle = dt * 2 * np.pi
        
        # Combine all three rotations with golden ratio weighting
        poloidal = self.rotate_poloidal(e8_state, dt / PHI)
        toroidal = self.rotate_toroidal(e8_state, dt / PHI**2)
        meridional = self.rotate_meridional(e8_state, dt / PHI**3)
        
        # Helical = weighted combination
        helical = (poloidal + toroidal + meridional) / 3
        
        # Normalize
        norm = np.linalg.norm(helical)
        if norm > 0:
            helical = helical / norm * np.sqrt(2)
        
        return helical


    def project_to_torus(self, e8_state: np.ndarray) -> np.ndarray:
        """
        Project E8 state to toroidal manifold.
        Ensures closure - no information leaks out.
        """
        # Extract toroidal coordinates from E8
        x, y = e8_state[0], e8_state[1]
        z = e8_state[2]
        
        # Compute angles
        phi = np.arctan2(y, x)  # Toroidal angle
        rho = np.sqrt(x**2 + y**2)  # Distance from z-axis
        
        # Ensure rho is in valid range
        if rho < self.R - self.r:
            rho = self.R - self.r
        elif rho > self.R + self.r:
            rho = self.R + self.r
        
        # Compute poloidal angle
        theta = np.arccos(np.clip((rho - self.R) / self.r, -1, 1))
        
        # Reconstruct on torus
        new_x = (self.R + self.r * np.cos(theta)) * np.cos(phi)
        new_y = (self.R + self.r * np.cos(theta)) * np.sin(phi)
        new_z = self.r * np.sin(theta)
        
        # Update E8 state
        projected = e8_state.copy()
        projected[0] = new_x
        projected[1] = new_y
        projected[2] = new_z
        
        # Normalize to maintain E8 norm
        norm = np.linalg.norm(projected)
        if norm > 0:
            projected = projected / norm * np.sqrt(2)
        
        return projected


    def _calculate_radii_and_angles(self):
        if self.center is None: self._calculate_center()
        cx, cy = self.center
        max_r_sq = 0
        for i, (x, y) in enumerate(self.cities):
            dx, dy = x - cx, y - cy
            radius_sq = dx*dx + dy*dy
            radius = math.sqrt(radius_sq) if radius_sq > 0 else 0
            angle = math.atan2(dy, dx)
            self.sweep_data[i].update({'radius': radius, 'angle': angle})
            if radius_sq > max_r_sq: max_r_sq = radius_sq
        self.max_radius = math.sqrt(max_r_sq) if max_r_sq > 0 else 0


    def _check_distance_cap(self, node_from: int, node_to: int, data_from: Dict, params: Dict) -> bool:
        """ Checks if the edge distance exceeds a dynamic cap. """
        avg_dist_in_shell = max(1.0, self.bus.shell_width or 10.0) # Proxy
        base_dist_cap = avg_dist_in_shell * params.get("distance_cap_factor", 3.0)
        if data_from.get('density') == "sparse":
            base_dist_cap *= self.config.get("dist_cap_sparse_mult", 1.5)

        effective_dist_cap = base_dist_cap
        if params.get("soft_override_active", False) or params.get("reentry_mode", False):
             effective_dist_cap *= self.config.get("dist_cap_override_mult", 1.5)
        try:
            actual_dist = math.dist(self.bus.cities[node_from], self.bus.cities[node_to])
        except IndexError: return False
        return actual_dist <= effective_dist_cap


# Data Processing Functions
#==============================================================================

    def encode_prompt(self, prompt: str, seed: Optional[int] = None) -> np.ndarray:
        """
        Encode text prompt to E8 state.
        
        Uses digital root mapping and semantic analysis.
        """
        if seed is not None:
            np.random.seed(seed)
        
        # Compute digital root from prompt
        total = sum(ord(c) for c in prompt)
        while total >= 10:
            total = sum(int(d) for d in str(total))
        dr = total if total > 0 else 9
        
        print(f"  Prompt DR: {dr}")
        
        # Generate E8 state biased by digital root
        e8_state = np.random.randn(8)
        
        # Emphasize dimension corresponding to DR
        e8_state[dr % 8] *= 2.0
        
        # Add semantic weighting based on keywords
        keywords = {
            'fast': [0, 1],      # EM dimensions
            'slow': [2, 3],      # Weak dimensions
            'strong': [4, 5],    # Strong dimensions
            'gentle': [6, 7],    # Gravity dimensions
            'bright': [0, 4],
            'dark': [2, 6],
            'colorful': [4, 5, 6],
            'simple': [0, 1, 2],
            'complex': [5, 6, 7]
        }
        
        prompt_lower = prompt.lower()
        for keyword, dims in keywords.items():
            if keyword in prompt_lower:
                for dim in dims:
                    e8_state[dim] *= 1.5
        
        # Normalize to E8 manifold
        norm = np.linalg.norm(e8_state)
        if norm > 0:
            e8_state = e8_state / norm * np.sqrt(2)
        
        return e8_state


    def _hash(self, key: Any) -> int:
        """ Primary hash function. Using MurmurHash for better distribution. """
        return self._murmur_hash(key)


    def _secondary_hash(self, key: Any) -> int:
        """ Secondary hash function for specific regions like velocity. Using FNV. """
        return self._fnv_hash(key)


    def _murmur_hash(self, key: Any) -> int:
        """ MurmurHash3 32-bit implementation. """
        key_bytes = str(key).encode('utf-8')
        length = len(key_bytes)
        seed = 0x9747b28c # Example seed
        c1 = 0xcc9e2d51
        c2 = 0x1b873593
        r1 = 15
        r2 = 13
        m = 5
        n = 0xe6546b64
        hash_value = seed

        nblocks = length // 4
        for i in range(nblocks):
            idx = i * 4
            k = (key_bytes[idx] |
                 (key_bytes[idx + 1] << 8) |
                 (key_bytes[idx + 2] << 16) |
                 (key_bytes[idx + 3] << 24))
            k = (k * c1) & 0xFFFFFFFF
            k = ((k << r1) | (k >> (32 - r1))) & 0xFFFFFFFF
            k = (k * c2) & 0xFFFFFFFF
            hash_value ^= k
            hash_value = ((hash_value << r2) | (hash_value >> (32 - r2))) & 0xFFFFFFFF
            hash_value = ((hash_value * m) + n) & 0xFFFFFFFF

        tail_index = nblocks * 4
        k = 0
        tail_size = length & 3
        if tail_size >= 3: k ^= key_bytes[tail_index + 2] << 16
        if tail_size >= 2: k ^= key_bytes[tail_index + 1] << 8
        if tail_size >= 1: k ^= key_bytes[tail_index]
        if tail_size > 0:
            k = (k * c1) & 0xFFFFFFFF
            k = ((k << r1) | (k >> (32 - r1))) & 0xFFFFFFFF
            k = (k * c2) & 0xFFFFFFFF
            hash_value ^= k

        hash_value ^= length
        hash_value ^= hash_value >> 16
        hash_value = (hash_value * 0x85ebca6b) & 0xFFFFFFFF
        hash_value ^= hash_value >> 13
        hash_value = (hash_value * 0xc2b2ae35) & 0xFFFFFFFF
        hash_value ^= hash_value >> 16

        return abs(hash_value) # Ensure positive


    def _fnv_hash(self, key: Any) -> int:
        """ FNV-1a 32-bit hash implementation. """
        key_bytes = str(key).encode('utf-8')
        fnv_prime = 0x01000193 # 16777619
        fnv_offset_basis = 0x811c9dc5 # 2166136261
        hash_value = fnv_offset_basis
        for byte in key_bytes:
            hash_value ^= byte
            hash_value = (hash_value * fnv_prime) & 0xFFFFFFFF
        return abs(hash_value) # Ensure positive


    def _hash_to_building(self, key: Any) -> str:
        """ Determine which building should contain a key using primary hash. """
        if not self.buildings: raise ValueError("MDHGHashTable has no buildings initialized.")
        hash_value = self._hash(key)
        building_idx = hash_value % len(self.buildings)
        return f"B{building_idx}"


    def _hash_to_velocity_index(self, key: Any, building_id: str) -> int:
        """ Calculate velocity region index using secondary hash. """
        building = self.buildings.get(building_id)
        if not building: raise ValueError(f"Building {building_id} not found.")
        velocity_size = len(building['velocity_region'])
        if velocity_size == 0: return 0
        return self._secondary_hash(key) % velocity_size


    def _hash_to_coords(self, key: Any, building_id: str) -> Optional[Tuple]:
        """ Calculate multi-dimensional coordinates using variations of primary hash. """
        building = self.buildings.get(building_id)
        if not building: raise ValueError(f"Building {building_id} not found.")
        dimension_sizes = building.get('dimension_sizes')
        if not dimension_sizes or len(dimension_sizes) != self.dimensions:
            return None # Cannot calculate coords if dimensions mismatch

        coords = []
        # Use primary hash and modify it for each dimension to get variation
        base_hash = self._hash(key)
        for i in range(self.dimensions):
            # Simple variation: XOR with dimension index and shift
            dim_hash = (base_hash ^ (i * 0x9e3779b9)) # Use golden ratio conjugate for mixing
            dim_hash = (dim_hash >> i) | (dim_hash << (32 - i)) & 0xFFFFFFFF # Rotate
            coord_val = abs(dim_hash) % dimension_sizes[i]
            coords.append(coord_val)
        return tuple(coords)


    def _hash_to_conflict_key(self, key: Any, coords: Tuple) -> int:
        """ Create a conflict key combining key hash and coordinates hash. """
        key_hash = self._hash(key)
        coords_hash = hash(coords) # Python's hash for tuple
        return abs(key_hash ^ coords_hash)


# Computation Functions
#==============================================================================

    def compute_digital_root(self, vector: np.ndarray) -> int:
        """Compute digital root (0-9) from E8 vector."""
        # Sum all components, reduce to single digit
        total = int(np.sum(np.abs(vector)) * 1000)  # Scale for precision
        while total >= 10:
            total = sum(int(d) for d in str(total))
        return total if total > 0 else 9


    def compute_parity_channels(self, vector: np.ndarray) -> np.ndarray:
        """Compute 24 parity channels from E8 vector."""
        # Use Leech lattice embedding (24D)
        channels = np.zeros(24)
        
        # Embed E8 into first 8 channels
        channels[:8] = vector
        
        # Generate remaining 16 channels via modular arithmetic
        for i in range(8, 24):
            # Use CRT rails (3, 6, 9) and coupling (0.03)
            mod = (i % 3) + 3  # Moduli: 3, 4, 5, 3, 4, 5, ...
            channels[i] = (np.sum(vector) * COUPLING * i) % mod
        
        return channels


    def compute_flow_velocity(self, e8_state: np.ndarray) -> float:
        """Compute flow velocity at current state."""
        # Velocity is proportional to distance from center
        rho = np.sqrt(e8_state[0]**2 + e8_state[1]**2)
        velocity = (rho - self.R) / self.r  # Normalized [-1, 1]
        return velocity * self.coupling


    def compute_pixel_influence(self, e8_state: np.ndarray, 
                               pixel_coords: np.ndarray) -> float:
        """
        Compute E8 state's influence at pixel position.
        
        Uses Gaussian falloff based on E8 distance.
        """
        # Get spatial position from E8
        x, y = self.e8_to_spatial(e8_state)
        
        # Compute distance to pixel
        dx = pixel_coords[0] - x
        dy = pixel_coords[1] - y
        dist = np.sqrt(dx**2 + dy**2)
        
        # Gaussian falloff with 0.03 coupling as sigma
        influence = np.exp(-dist**2 / (2 * COUPLING**2))
        
        return influence


    def _calculate_dimension_sizes(self, core_region_base_size: int) -> List[int]:
        """ Calculate sizes for each dimension using golden ratio proportions. """
        if self.dimensions <= 0: return []
        # Estimate base size per dimension
        # Using geometric mean approach: base_size ^ dimensions ≈ core_region_base_size
        # Add epsilon to avoid potential log(0) or root(0) issues if base_size is tiny
        safe_base_size = max(1, core_region_base_size)
        base_size = max(2.0, safe_base_size ** (1.0/self.dimensions)) # Use float for calculation

        sizes = []
        product = 1.0
        # Scale dimensions using PHI, ensuring minimum size 2
        for i in range(self.dimensions):
            # Example scaling: could use other GR-based factors
            # Ensure denominator is safe
            phi_exponent = i / max(1.0, float(self.dimensions - 1))
            size_float = base_size / (self.PHI ** phi_exponent)
            size = max(2, int(round(size_float))) # Round before int conversion
            sizes.append(size)
            product *= size

        # Optional: Adjust sizes slightly if product is too far off target
        # This part requires careful balancing logic to avoid infinite loops or drastic changes
        # print(f"      Calculated dimension sizes: {sizes} (Product: {product}, Target Base: {core_region_base_size})")
        return sizes


    def _compute_hamiltonian_path(self, building_id: str, start_coords: Tuple) -> List[Tuple]:
        """
        Compute a Hamiltonian-like path (visits many points uniquely) starting from coordinates.
        Uses GR steps. This is a heuristic path, not guaranteed to be truly Hamiltonian or optimal length.
        """
        building = self.buildings.get(building_id)
        if not building or not building.get('dimension_sizes'): return []
        dimension_sizes = building['dimension_sizes']

        # Basic validation of start_coords
        if len(start_coords) != self.dimensions: return []
        if not all(0 <= start_coords[i] < dimension_sizes[i] for i in range(self.dimensions)): return []

        path = [start_coords]
        current = list(start_coords)
        visited = {start_coords}

        # Determine path length heuristic
        total_core_points = math.prod(dimension_sizes) if dimension_sizes else 0
        if total_core_points == 0: return path # Path is just the start point

        path_length_limit = min(total_core_points, self.config.get("mdhg_path_length_limit", 1000))
        # Aim for a path length that covers a reasonable fraction, e.g., sqrt or similar heuristic
        path_length_target = max(self.dimensions * 2, int(math.sqrt(total_core_points) * 2)) # Cover more?
        path_length = min(path_length_limit, path_length_target)

        # Use golden ratio for dimension selection and step direction bias
        for step in range(1, path_length):
            # Choose dimension based on golden ratio progression [cite: 1021]
            dim_choice = int((step * self.PHI) % self.dimensions)

            # Determine step direction (+1 or -1) based on another GR sequence
            direction_bias = (step * self.PHI**2) % 1.0
            step_dir = 1 if direction_bias < 0.5 else -1

            # Try moving in the chosen dimension and direction
            next_coord_list = list(current)
            next_coord_list[dim_choice] = (next_coord_list[dim_choice] + step_dir + dimension_sizes[dim_choice]) % dimension_sizes[dim_choice] # Ensure positive result
            next_coords = tuple(next_coord_list)

            if next_coords not in visited:
                path.append(next_coords)
                visited.add(next_coords)
                current = next_coord_list
            else:
                # Collision: Try alternative dimensions or directions (simple linear probe)
                found_alternative = False
                for alt_offset in range(1, self.dimensions + 1): # Try all dimensions + opposite dir
                    # Try alternative dimension, original direction
                    alt_dim = (dim_choice + alt_offset) % self.dimensions
                    alt_coord_list = list(current)
                    alt_coord_list[alt_dim] = (alt_coord_list[alt_dim] + step_dir + dimension_sizes[alt_dim]) % dimension_sizes[alt_dim]
                    alt_coords = tuple(alt_coord_list)
                    if alt_coords not in visited:
                        path.append(alt_coords)
                        visited.add(alt_coords)
                        current = alt_coord_list
                        found_alternative = True
                        break

                    # Try alternative dimension, opposite direction
                    alt_coord_list = list(current)
                    alt_coord_list[alt_dim] = (alt_coord_list[alt_dim] - step_dir + dimension_sizes[alt_dim]) % dimension_sizes[alt_dim]
                    alt_coords = tuple(alt_coord_list)
                    if alt_coords not in visited:
                        path.append(alt_coords)
                        visited.add(alt_coords)
                        current = alt_coord_list
                        found_alternative = True
                        break

                # If no alternative found after checking all dims/dirs, stop path
                if not found_alternative:
                    # print(f"      Path generation stuck at step {step}, coords {current}")
                    break # Stop if stuck

        return path


    def _calculate_center(self):
        if not self.cities: self.center = (0.0, 0.0); return
        sum_x = sum(c[0] for c in self.cities)
        sum_y = sum(c[1] for c in self.cities)
        self.center = (sum_x / self.num_nodes, sum_y / self.num_nodes)


    def _calculate_radii_and_angles(self):
        if self.center is None: self._calculate_center()
        cx, cy = self.center
        max_r_sq = 0
        for i, (x, y) in enumerate(self.cities):
            dx, dy = x - cx, y - cy
            radius_sq = dx*dx + dy*dy
            radius = math.sqrt(radius_sq) if radius_sq > 0 else 0
            angle = math.atan2(dy, dx)
            self.sweep_data[i].update({'radius': radius, 'angle': angle})
            if radius_sq > max_r_sq: max_r_sq = radius_sq
        self.max_radius = math.sqrt(max_r_sq) if max_r_sq > 0 else 0


    def _calculate_gr_sweep_scores(self):
        # Placeholder: Rank by shell, then angle. Needs proper GR spiral logic.
        temp_nodes = []
        for i in range(self.num_nodes):
            shell = self.sweep_data[i].get('shell', 999)
            angle = self.sweep_data[i].get('angle', 0.0)
            score = shell + (abs(angle) / (2*math.pi)) # Simple composite score
            temp_nodes.append((score, i))
        temp_nodes.sort()
        for rank, (score, i) in enumerate(temp_nodes):
            self.sweep_data[i]['sweep_rank'] = rank
            self.sweep_data[i]['gr_score'] = score
        if temp_nodes:
            self.start_node_fwd = temp_nodes[0][1]
            self.start_node_rev = temp_nodes[-1][1]


    def _calculate_global_metrics(self) -> Dict:
        """ Calculates high-level quality metrics for the final path. """
        metrics = {}
        path = self.bus.full_path
        # 1. Final Path Length
        final_cost = self.bus.calculate_total_path_cost(path) # Use bus helper
        metrics['final_path_cost'] = final_cost
        metrics['final_efficiency'] = final_cost / max(1, self.bus.num_nodes)

        # 2. Comparison to Baseline (e.g., simple Nearest Neighbor from start)
        baseline_cost = self._run_simple_nn_baseline()
        metrics['baseline_nn_cost'] = baseline_cost
        if baseline_cost > 0:
             metrics['length_vs_baseline'] = final_cost / baseline_cost

        # 3. Remaining Salesman Flags (Count reported by Salesman)
        # Need Salesman to store final flag count accessible here
        # metrics['remaining_salesman_flags'] = self.bus.salesman_final_flags?

        # 4. Structural Metrics (Example: Bounding Box Ratio)
        if path:
             coords = np.array([self.bus.cities[i] for i in path[:-1]]) # Exclude return to start
             min_x, min_y = np.min(coords, axis=0)
             max_x, max_y = np.max(coords, axis=0)
             width = max_x - min_x
             height = max_y - min_y
             metrics['bounding_box_ratio'] = width / height if height > 0 else 1.0

        # 5. Add more metrics: Avg turn angle, std dev of edge lengths, etc.
        return metrics


    def calculate_total_path_cost(self, path: Optional[List[int]]) -> float:
        """ Calculates the Euclidean distance of the TSP path. """
        if not path or len(path) < 2: return 0.0
        total_distance = 0.0
        for i in range(len(path) - 1):
            # Add checks for valid indices
            idx1, idx2 = path[i], path[i+1]
            if 0 <= idx1 < self.num_nodes and 0 <= idx2 < self.num_nodes:
                 pos1 = self.cities[idx1]
                 pos2 = self.cities[idx2]
                 total_distance += math.dist(pos1, pos2)
            else:
                 print(f"ERROR: Invalid node index in path during cost calculation: {idx1} or {idx2}")
                 return 0.0 # Indicate error
        return total_distance


# Interpolation Functions
#==============================================================================

    def interpolate_geodesic(self, start: np.ndarray, end: np.ndarray, 
                            t: float) -> np.ndarray:
        """Interpolate along geodesic on E8 manifold."""
        # Spherical linear interpolation (SLERP)
        dot = np.dot(start, end) / (np.linalg.norm(start) * np.linalg.norm(end))
        dot = np.clip(dot, -1.0, 1.0)
        theta = np.arccos(dot)
        
        if abs(theta) < 1e-6:
            # Vectors are parallel, use linear interpolation
            return (1 - t) * start + t * end
        
        sin_theta = np.sin(theta)
        a = np.sin((1 - t) * theta) / sin_theta
        b = np.sin(t * theta) / sin_theta
        
        result = a * start + b * end
        return self.project_to_manifold(result)


    def interpolate_worlds(self, world1: WorldManifold, 
                          world2: WorldManifold,
                          num_frames: int) -> List[np.ndarray]:
        """
        Interpolate between two worlds (morphing).
        
        Args:
            world1: Starting world
            world2: Ending world
            num_frames: Number of interpolation frames
            
        Returns:
            List of E8 states (trajectory)
        """
        trajectory = []
        
        for i in range(num_frames):
            t = i / (num_frames - 1) if num_frames > 1 else 0
            
            # Geodesic interpolation in E8 space
            state = self.e8.interpolate_geodesic(
                world1.e8_seed, world2.e8_seed, t
            )
            
            trajectory.append(state)
        
        return trajectory

