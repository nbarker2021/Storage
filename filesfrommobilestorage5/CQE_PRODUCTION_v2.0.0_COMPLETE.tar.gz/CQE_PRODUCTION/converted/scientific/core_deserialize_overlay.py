"""
SpeedLight Dependency Tracking:
External dependencies removed: numpy
Original file: cqe_modules/core_deserialize_overlay.py

NEEDS_DEPS: ["numpy"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

def deserialize_overlay(json_str: str) -> CQEOverlay:
    """
    Deserialize overlay from JSON string.

    Args:
        json_str: JSON string from serialize_overlay()

    Returns:
        Reconstructed CQEOverlay
    """
    data = json.loads(json_str)
    return overlay_from_dict(data)
"""Overlay canonicalization using Weyl reflections"""


import hashlib
from cqe.core.overlay import CQEOverlay
from cqe.core.lattice import E8Lattice

