"""
SpeedLight Dependency Tracking:
External dependencies removed: numpy
Original file: cqe_python/semantic_extractor.py

NEEDS_DEPS: ["numpy"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

#!/usr/bin/env python3
"""
Semantic Extractor - Geometry to Human-Readable Text
====================================================
Extracts semantic meaning FROM geometric properties.
Geometry-first internally, human-facing output.

Based on CQE monolith's semantic extraction pipeline (lines 26125-31200).
"""

from typing import Dict, Any, List


class SemanticExtractor:
    """
    Extract human-readable semantics from geometric properties.
    
    Flow:
    1. Geometric properties (E8, sacred, fractal, toroidal)
    2. Pattern recognition
    3. Semantic mapping
    4. Human-readable text generation
    """
    
    def __init__(self):
        self.semantic_mappings = self._initialize_mappings()
    
    def _initialize_mappings(self) -> Dict[str, Any]:
        """Initialize geometric-to-semantic mappings"""
        return {
            'digital_root': {
                1: {'category': 'INITIATOR', 'quality': 'beginning, source, unity'},
                2: {'category': 'BALANCER', 'quality': 'duality, partnership, balance'},
                3: {'category': 'CREATOR', 'quality': 'creation, expression, growth'},
                4: {'category': 'STABILIZER', 'quality': 'foundation, structure, order'},
                5: {'category': 'TRANSFORMER', 'quality': 'change, freedom, adventure'},
                6: {'category': 'HARMONIZER', 'quality': 'harmony, responsibility, nurturing'},
                7: {'category': 'SEEKER', 'quality': 'wisdom, introspection, analysis'},
                8: {'category': 'MANIFESTER', 'quality': 'power, abundance, achievement'},
                9: {'category': 'COMPLETER', 'quality': 'completion, universality, enlightenment'}
            },
            'fractal_behavior': {
                'BOUNDED': 'stable and contained',
                'PERIODIC': 'cyclical and rhythmic',
                'CHAOTIC': 'dynamic and unpredictable',
                'CONVERGENT': 'focusing and concentrating',
                'DIVERGENT': 'expanding and radiating'
            },
            'force_classification': {
                'GRAVITATIONAL': 'attractive and binding',
                'ELECTROMAGNETIC': 'connecting and communicating',
                'STRONG_NUCLEAR': 'cohesive and fundamental',
                'WEAK_NUCLEAR': 'transformative and decaying',
                'CREATIVE': 'generative and innovative',
                'HARMONIC': 'resonant and balanced',
                'MORPHIC': 'pattern-forming and organizing'
            },
            'sacred_frequency': {
                (0, 200): 'grounding and foundational',
                (200, 400): 'stabilizing and structural',
                (400, 600): 'energizing and activating',
                (600, 800): 'elevating and inspiring',
                (800, 1000): 'transcendent and enlightening'
            }
        }
    
    def extract_from_universal_atom(self, atom_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract semantics from Universal Atom geometric properties.
        
        Args:
            atom_data: Dictionary containing:
                - e8_coordinates: E8 lattice position
                - digital_root: Sacred geometry root
                - sacred_frequency: Resonance frequency
                - fractal_coordinate: Mandelbrot position
                - fractal_behavior: Fractal classification
                - toroidal_position: Toroidal coordinates
                - force_classification: Force type
                - compression_ratio: Information density
        
        Returns:
            Dictionary with human-readable semantic properties
        """
        semantics = {
            'primary_concept': '',
            'qualities': [],
            'relationship_type': '',
            'process_nature': '',
            'energy_signature': '',
            'human_readable_summary': ''
        }
        
        # Extract from digital root
        digital_root = atom_data.get('digital_root', 1)
        root_mapping = self.semantic_mappings['digital_root'].get(digital_root, {})
        semantics['primary_concept'] = root_mapping.get('category', 'UNKNOWN')
        semantics['qualities'].append(root_mapping.get('quality', 'undefined'))
        
        # Extract from fractal behavior
        fractal_behavior = atom_data.get('fractal_behavior', 'BOUNDED')
        semantics['process_nature'] = self.semantic_mappings['fractal_behavior'].get(
            fractal_behavior, 'undefined'
        )
        
        # Extract from force classification
        force_type = atom_data.get('force_classification', 'HARMONIC')
        semantics['relationship_type'] = self.semantic_mappings['force_classification'].get(
            force_type, 'undefined'
        )
        
        # Extract from sacred frequency
        sacred_freq = atom_data.get('sacred_frequency', 432)
        for (low, high), quality in self.semantic_mappings['sacred_frequency'].items():
            if low <= sacred_freq < high:
                semantics['energy_signature'] = quality
                break
        
        # Analyze E8 coordinates for complexity
        e8_coords = atom_data.get('e8_coordinates', [0]*8)
        if isinstance(e8_coords, list) and len(e8_coords) == 8:
            coord_magnitude = np.linalg.norm(e8_coords)
            coord_balance = np.std(e8_coords)
            
            complexity_level = min(1.0, coord_magnitude / 10.0)
            balance_factor = 1.0 / (1.0 + coord_balance)
            
            if complexity_level > 0.7:
                semantics['qualities'].append('highly complex')
            elif complexity_level > 0.4:
                semantics['qualities'].append('moderately complex')
            else:
                semantics['qualities'].append('simple')
            
            if balance_factor > 0.7:
                semantics['qualities'].append('well-balanced')
            elif balance_factor > 0.4:
                semantics['qualities'].append('partially balanced')
            else:
                semantics['qualities'].append('asymmetric')
        
        # Generate human-readable summary
        semantics['human_readable_summary'] = self._generate_summary(semantics, atom_data)
        
        return semantics
    
    def _generate_summary(self, semantics: Dict[str, Any], atom_data: Dict[str, Any]) -> str:
        """Generate human-readable summary from semantic properties"""
        
        concept = semantics['primary_concept']
        qualities = ', '.join(semantics['qualities'])
        process = semantics['process_nature']
        relationship = semantics['relationship_type']
        energy = semantics['energy_signature']
        
        summary = f"This is a {concept} archetype characterized by {qualities}. "
        summary += f"Its process nature is {process}, "
        summary += f"with {relationship} relationship dynamics. "
        summary += f"The energy signature is {energy}."
        
        # Add compression efficiency insight
        compression = atom_data.get('compression_ratio', 1.0)
        if compression > 5.0:
            summary += f" Highly information-dense (compression: {compression:.1f}x)."
        elif compression > 2.0:
            summary += f" Moderately information-dense (compression: {compression:.1f}x)."
        
        return summary
    
    def extract_from_synthesis(self, atom1_semantics: Dict[str, Any], 
                               atom2_semantics: Dict[str, Any],
                               combined_atom_data: Dict[str, Any]) -> str:
        """
        Generate human-readable synthesis text from two atoms' semantics.
        
        Args:
            atom1_semantics: Semantics of first atom
            atom2_semantics: Semantics of second atom
            combined_atom_data: Geometric properties of combined atom
        
        Returns:
            Human-readable synthesis text
        """
        
        # Extract combined semantics
        combined_semantics = self.extract_from_universal_atom(combined_atom_data)
        
        # Generate synthesis narrative
        synthesis_text = "# Synthesis of Concepts\n\n"
        
        synthesis_text += f"## Source Concepts\n\n"
        synthesis_text += f"**First Concept**: {atom1_semantics['primary_concept']} - "
        synthesis_text += f"{atom1_semantics['human_readable_summary']}\n\n"
        synthesis_text += f"**Second Concept**: {atom2_semantics['primary_concept']} - "
        synthesis_text += f"{atom2_semantics['human_readable_summary']}\n\n"
        
        synthesis_text += f"## Combined Concept\n\n"
        synthesis_text += f"**Emergent Archetype**: {combined_semantics['primary_concept']}\n\n"
        synthesis_text += f"{combined_semantics['human_readable_summary']}\n\n"
        
        synthesis_text += f"## Synthesis Dynamics\n\n"
        synthesis_text += f"The combination creates a {combined_semantics['process_nature']} process "
        synthesis_text += f"with {combined_semantics['relationship_type']} dynamics. "
        synthesis_text += f"The resulting energy signature is {combined_semantics['energy_signature']}, "
        synthesis_text += f"integrating the qualities of both source concepts into a unified whole.\n\n"
        
        # Add geometric compatibility insight
        digital_root = combined_atom_data.get('digital_root', 1)
        synthesis_text += f"### Geometric Compatibility\n\n"
        synthesis_text += f"The combined digital root of {digital_root} indicates "
        
        if digital_root in [3, 6, 9]:
            synthesis_text += "high resonance and sacred alignment. "
            synthesis_text += "This combination is geometrically harmonious and stable.\n"
        else:
            synthesis_text += "transitional dynamics. "
            synthesis_text += "This combination represents an evolutionary bridge between states.\n"
        
        return synthesis_text
    
    def extract_from_e8_coordinates(self, e8_coords: List[float]) -> str:
        """
        Generate human-readable description from raw E8 coordinates.
        
        Args:
            e8_coords: 8-dimensional E8 lattice coordinates
        
        Returns:
            Human-readable description
        """
        if len(e8_coords) != 8:
            return "Invalid E8 coordinates"
        
        coords = np.array(e8_coords)
        magnitude = np.linalg.norm(coords)
        balance = np.std(coords)
        dominant_dim = np.argmax(np.abs(coords))
        
        description = f"E8 Position Analysis:\n\n"
        description += f"- **Magnitude**: {magnitude:.2f} (distance from origin)\n"
        description += f"- **Balance**: {balance:.2f} (coordinate distribution)\n"
        description += f"- **Dominant Dimension**: {dominant_dim + 1}/8\n\n"
        
        if magnitude > 5.0:
            description += "This represents a highly energetic state, far from equilibrium. "
        elif magnitude > 2.0:
            description += "This represents a moderately active state. "
        else:
            description += "This represents a grounded, stable state. "
        
        if balance < 1.0:
            description += "The coordinates are well-balanced across dimensions, "
            description += "indicating harmonic integration.\n"
        elif balance < 3.0:
            description += "The coordinates show moderate variation, "
            description += "indicating selective emphasis.\n"
        else:
            description += "The coordinates show high variation, "
            description += "indicating strong directional bias.\n"
        
        return description
    
    def tokens_to_text(self, token_sequence: List[str], 
                      geometric_properties: Dict[str, Any]) -> str:
        """
        Convert geometric token sequence back to human-readable text.
        
        Args:
            token_sequence: Sequence of geometric tokens
            geometric_properties: Geometric properties of token sequence
        
        Returns:
            Human-readable text
        """
        
        # This would integrate with GeoTokenizer's reverse mapping
        # For now, return a descriptive analysis
        
        text = f"Token Sequence Analysis:\n\n"
        text += f"- **Token Count**: {len(token_sequence)}\n"
        text += f"- **Sequence Type**: {geometric_properties.get('sequence_type', 'unknown')}\n\n"
        
        if 'semantic_hints' in geometric_properties:
            text += "**Semantic Interpretation**:\n"
            for hint in geometric_properties['semantic_hints']:
                text += f"- {hint}\n"
        
        return text

# Singleton instance
_extractor = None

def get_semantic_extractor() -> SemanticExtractor:
    """Get singleton semantic extractor instance"""
    global _extractor
    if _extractor is None:
        _extractor = SemanticExtractor()
    return _extractor
