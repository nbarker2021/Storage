"""
SpeedLight Dependency Tracking:
External dependencies removed: LatticeBuilderV1, CqeGovernance
Original file: cqe_python/custom_builder.py

NEEDS_DEPS: ["LatticeBuilderV1", "CqeGovernance"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

#!/usr/bin/env python3
"""
CQE Custom Tool Builder
======================

Builds custom tools on-demand by selecting modules from the monolith repository.

This demonstrates the TRUE power of the CQE build system - treating monoliths
as read-only repositories of building blocks that can be mixed and matched
to create any tool you need.

Usage:
    python custom_builder.py create <name> <description> <capabilities>
    
Example:
    python custom_builder.py create mini_node "Minimal blockchain node" "ledger_system,e8_operations"
"""

import sys
import json
from pathlib import Path
from typing import List, Set

BUILD_DIR = Path("/home/claude/cqe_build")
OUTPUT_DIR = Path("/mnt/user-data/outputs/custom_tools")
ANALYSIS_FILE = BUILD_DIR / "analysis.json"

class CustomToolBuilder:
    """Build custom tools from monolith building blocks."""
    
    def __init__(self):
        self.analysis = self._load_analysis()
    
    def _load_analysis(self):
        """Load module analysis."""
        if not ANALYSIS_FILE.exists():
            print("❌ Run 'python cqe_builder.py analyze' first")
            sys.exit(1)
        return json.loads(ANALYSIS_FILE.read_text())
    
    def create_tool(self, name: str, description: str, 
                   required_caps: List[str], max_modules: int = 15):
        """Create a custom tool with specific capabilities."""
        
        print(f"\n🔨 Building Custom Tool: {name}")
        print(f"   Description: {description}")
        print(f"   Required: {', '.join(required_caps)}")
        print(f"   Max modules: {max_modules}\n")
        
        # Find modules with required capabilities
        selected = []
        selected_names = set()
        
        for cap in required_caps:
            if cap in self.analysis['capability_index']:
                for mod_name in self.analysis['capability_index'][cap]:
                    if mod_name not in selected_names and len(selected) < max_modules:
                        mod_info = self.analysis['modules'][mod_name]
                        selected.append((mod_name, mod_info))
                        selected_names.add(mod_name)
                        print(f"  ✓ {mod_name:30} [{mod_info['category']:12}] {mod_info['size_lines']} lines")
        
        print(f"\n  Selected {len(selected)} modules")
        
        # Create tool directory
        tool_dir = OUTPUT_DIR / name
        tool_dir.mkdir(parents=True, exist_ok=True)
        
        # Create main script
        self._create_main_script(name, description, selected, tool_dir)
        
        # Create README
        self._create_readme(name, description, selected, tool_dir)
        
        print(f"\n✅ Custom tool created: {tool_dir}")
        return tool_dir
    
    def _create_main_script(self, name: str, description: str, 
                           modules: List, tool_dir: Path):
        """Create the main script for the tool."""
        
        # List available modules
        module_list = '\n'.join(f"# - {n}" for n, _ in modules)
        
        script = f'''#!/usr/bin/env python3
"""
{name.upper()} - {description}

Auto-generated custom tool using CQE monolith building blocks.

Available modules:
{module_list}
"""

import sys
from pathlib import Path

# Add module paths
MODULES_DIR = Path(__file__).parent / "modules"
sys.path.insert(0, str(MODULES_DIR))

def main():
    print("🚀 {name.upper()}")
    print("{description}")
    print()
    print("Available modules:")
    
    modules = {[f'"{n}"' for n, _ in modules]}
    
    for mod_name in modules:
        try:
            __import__(mod_name)
            print(f"  ✓ {{mod_name}}")
        except Exception as e:
            print(f"  ✗ {{mod_name}}: {{e}}")
    
    print()
    print("Use: from <module> import <class>")

if __name__ == '__main__':
    main()
'''
        
        (tool_dir / f"{name}.py").write_text(script)
        print(f"  Created {name}.py")
    
    def _create_readme(self, name: str, description: str, 
                      modules: List, tool_dir: Path):
        """Create README for the tool."""
        
        module_list = '\n'.join(
            f"- **{n}** ({info['size_lines']} lines) - {info['category']}"
            for n, info in modules
        )
        
        readme = f'''# {name.upper()}

{description}

## Modules Included

{module_list}

## Usage

```python
import sys
sys.path.insert(0, './modules')

# Import the modules you need


# etc...
```

## Run

```bash
python {name}.py
```
'''
        
        (tool_dir / "README.md").write_text(readme)
        print(f"  Created README.md")


def main():
    """CLI entry point."""
    if len(sys.argv) < 4:
        print(__doc__)
        return
    
    command = sys.argv[1]
    
    if command != 'create':
        print(f"Unknown command: {command}")
        return
    
    name = sys.argv[2]
    description = sys.argv[3]
    capabilities = sys.argv[4].split(',') if len(sys.argv) > 4 else []
    max_modules = int(sys.argv[5]) if len(sys.argv) > 5 else 15
    
    builder = CustomToolBuilder()
    builder.create_tool(name, description, capabilities, max_modules)


if __name__ == '__main__':
    main()
