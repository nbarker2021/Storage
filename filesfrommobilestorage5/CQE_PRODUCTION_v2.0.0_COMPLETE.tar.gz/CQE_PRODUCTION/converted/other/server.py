"""
SpeedLight Dependency Tracking:
External dependencies removed: api
Original file: cqe_python/moonshine_db/server.py

NEEDS_DEPS: ["api"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""



if __name__ == '__main__':
    serve()
