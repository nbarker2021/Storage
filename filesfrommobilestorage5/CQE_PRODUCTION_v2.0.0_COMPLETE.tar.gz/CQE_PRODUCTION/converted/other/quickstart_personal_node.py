"""
SpeedLight Dependency Tracking:
External dependencies removed: morphonic_cqe_unified
Original file: cqe_python/morphonic_cqe_unified/apps/quickstart_personal_node.py

NEEDS_DEPS: ["morphonic_cqe_unified"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

from morphonic_cqe_unified.apps.cqe_personal_node import main
if __name__ == "__main__":
    main()