"""
SpeedLight Dependency Tracking:
External dependencies removed: CQE_CORE_MONOLITH_fixed, module_extractor
Original file: cqe_python/tool_builder.py

NEEDS_DEPS: ["CQE_CORE_MONOLITH_fixed", "module_extractor"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""

#!/usr/bin/env python3
"""
CQE Tool Builder API
===================

Stdlib-only custom tool creation system.
Builds tools on-demand by selecting modules from the 607-module repository.
"""

import json
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Set
from datetime import datetime


ANALYSIS_FILE = Path(__file__).parent / "module_analysis.json"
OUTPUT_DIR = Path(__file__).parent / "generated_tools"

class ToolBuilder:
    """Build custom CQE tools from module building blocks."""
    
    def __init__(self):
        self.analysis = self._load_analysis()
        OUTPUT_DIR.mkdir(exist_ok=True)
    
    def _load_analysis(self) -> Dict[str, Any]:
        """Load module analysis database."""
        if not ANALYSIS_FILE.exists():
            raise FileNotFoundError(f"Module analysis not found: {ANALYSIS_FILE}")
        return json.loads(ANALYSIS_FILE.read_text())
    
    def get_capabilities(self) -> List[str]:
        """Get list of all available capabilities."""
        caps = set()
        for mod_info in self.analysis['modules'].values():
            caps.update(mod_info.get('capabilities', []))
        return sorted(list(caps))
    
    def get_categories(self) -> List[str]:
        """Get list of all module categories."""
        cats = set()
        for mod_info in self.analysis['modules'].values():
            cats.add(mod_info.get('category', 'general'))
        return sorted(list(cats))
    
    def get_modules_by_capability(self, capability: str) -> List[Dict[str, Any]]:
        """Get all modules that provide a specific capability."""
        modules = []
        for name, info in self.analysis['modules'].items():
            if capability in info.get('capabilities', []):
                modules.append({
                    'name': name,
                    'category': info.get('category', 'general'),
                    'size_lines': info.get('size_lines', 0),
                    'capabilities': info.get('capabilities', []),
                    'keywords': info.get('keywords', [])
                })
        return modules
    
    def get_modules_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Get all modules in a specific category."""
        modules = []
        for name, info in self.analysis['modules'].items():
            if info.get('category') == category:
                modules.append({
                    'name': name,
                    'category': category,
                    'size_lines': info.get('size_lines', 0),
                    'capabilities': info.get('capabilities', []),
                    'keywords': info.get('keywords', [])
                })
        return modules
    
    def get_all_modules(self) -> List[Dict[str, Any]]:
        """Get all available modules."""
        modules = []
        for name, info in self.analysis['modules'].items():
            modules.append({
                'name': name,
                'category': info.get('category', 'general'),
                'size_lines': info.get('size_lines', 0),
                'capabilities': info.get('capabilities', []),
                'keywords': info.get('keywords', []),
                'source_file': info.get('source_file', ''),
                'line_start': info.get('line_start', 0),
                'line_end': info.get('line_end', 0)
            })
        return modules
    
    def create_tool(self, name: str, description: str, 
                   required_caps: List[str], 
                   max_modules: int = 50) -> Dict[str, Any]:
        """
        Create a custom tool with specific capabilities.
        
        Returns:
            Dict with tool_id, selected_modules, script_content, readme_content
        """
        
        # Find modules with required capabilities
        selected = []
        selected_names = set()
        
        for cap in required_caps:
            for mod_name, mod_info in self.analysis['modules'].items():
                if cap in mod_info.get('capabilities', []):
                    if mod_name not in selected_names and len(selected) < max_modules:
                        selected.append({
                            'name': mod_name,
                            'category': mod_info.get('category', 'general'),
                            'size_lines': mod_info.get('size_lines', 0),
                            'capabilities': mod_info.get('capabilities', []),
                            'source_file': mod_info.get('source_file', ''),
                            'line_start': mod_info.get('line_start', 0),
                            'line_end': mod_info.get('line_end', 0)
                        })
                        selected_names.add(mod_name)
        
        # Generate tool ID
        tool_id = hashlib.sha256(
            f"{name}:{description}:{','.join(required_caps)}".encode()
        ).hexdigest()[:16]
        
        # Create tool directory
        tool_dir = OUTPUT_DIR / tool_id
        tool_dir.mkdir(exist_ok=True)
        
        # Create main script
        script_content = self._create_main_script(name, description, selected)
        script_path = tool_dir / f"{name}.py"
        script_path.write_text(script_content)
        
        # Create README
        readme_content = self._create_readme(name, description, selected, required_caps)
        readme_path = tool_dir / "README.md"
        readme_path.write_text(readme_content)
        
        # Create metadata
        metadata = {
            'tool_id': tool_id,
            'name': name,
            'description': description,
            'required_capabilities': required_caps,
            'selected_modules': selected,
            'module_count': len(selected),
            'total_lines': sum(m['size_lines'] for m in selected),
            'created_at': datetime.now().isoformat(),
            'script_path': str(script_path),
            'readme_path': str(readme_path)
        }
        
        metadata_path = tool_dir / "metadata.json"
        metadata_path.write_text(json.dumps(metadata, indent=2))
        
        return {
            'tool_id': tool_id,
            'name': name,
            'description': description,
            'selected_modules': selected,
            'module_count': len(selected),
            'total_lines': sum(m['size_lines'] for m in selected),
            'script_content': script_content,
            'readme_content': readme_content,
            'script_path': str(script_path),
            'readme_path': str(readme_path)
        }
    
    def _create_main_script(self, name: str, description: str, 
                           modules: List[Dict]) -> str:
        """Create the main script for the tool using real extracted code."""
        
        # Use module_extractor to generate real executable code
        extractor = get_extractor()
        module_names = [m['name'] for m in modules]
        
        # Generate tool with actual extracted code
        generated = extractor.generate_tool(
            tool_name=name,
            description=description,
            module_names=module_names,
            resolve_deps=True
        )
        
        return generated['script_content']
    
    def _create_readme(self, name: str, description: str, 
                      modules: List[Dict], capabilities: List[str]) -> str:
        """Create README for the tool."""
        
        module_list = '\n'.join(
            f"- **{m['name']}** ({m['size_lines']} lines) - {m['category']}"
            for m in modules
        )
        
        cap_list = ', '.join(f"`{c}`" for c in capabilities)
        
        readme = f'''# {name.upper()}

{description}

**Created**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Capabilities**: {cap_list}
**Modules**: {len(modules)}
**Total Lines**: {sum(m['size_lines'] for m in modules):,}

## 🎯 Capabilities

This tool provides the following CQE capabilities:

{chr(10).join(f"- **{cap}**" for cap in capabilities)}

## 📦 Modules Included

{module_list}

## 🚀 Usage

This tool is built from CQE monolith building blocks and uses **only Python stdlib** - no external dependencies required.

### Run the tool

```bash
python {name}.py
```

### Use modules in your code

```python
# Import from the CQE monolith


# Or extract specific modules using the CQE builder
```

## 📋 Module Details

Each module is extracted from the CQE_CORE_MONOLITH_fixed.py file:

{chr(10).join(f"- **{m['name']}**: Lines {m['line_start']}-{m['line_end']} ({m['size_lines']} lines)" for m in modules)}

## 🔧 Customization

To modify this tool:

1. Edit the module selection in the Tool Builder UI
2. Add or remove capabilities
3. Regenerate the tool with your new configuration

## 📖 CQE Framework

This tool is part of the CQE (Computational Quantum Equivalence) framework, which provides:

- E8 lattice operations (240 roots, 8D space)
- Universal Atom synthesis (6 combination types)
- Sacred geometry integration
- Blockchain provenance
- And much more...

---

*Generated by CQE Tool Builder - Stdlib-only custom tool creation*
'''
        
        return readme
    
    def get_tool_metadata(self, tool_id: str) -> Dict[str, Any]:
        """Get metadata for a created tool."""
        tool_dir = OUTPUT_DIR / tool_id
        metadata_path = tool_dir / "metadata.json"
        
        if not metadata_path.exists():
            raise FileNotFoundError(f"Tool not found: {tool_id}")
        
        return json.loads(metadata_path.read_text())
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """List all created tools."""
        tools = []
        for tool_dir in OUTPUT_DIR.iterdir():
            if tool_dir.is_dir():
                metadata_path = tool_dir / "metadata.json"
                if metadata_path.exists():
                    tools.append(json.loads(metadata_path.read_text()))
        return sorted(tools, key=lambda t: t['created_at'], reverse=True)
    
    def delete_tool(self, tool_id: str) -> bool:
        """Delete a created tool."""
        tool_dir = OUTPUT_DIR / tool_id
        if tool_dir.exists():
            import shutil
            shutil.rmtree(tool_dir)
            return True
        return False
    
    def get_tool_script(self, tool_id: str) -> str:
        """Get the script content for a tool."""
        metadata = self.get_tool_metadata(tool_id)
        script_path = Path(metadata['script_path'])
        return script_path.read_text()
    
    def get_tool_readme(self, tool_id: str) -> str:
        """Get the README content for a tool."""
        metadata = self.get_tool_metadata(tool_id)
        readme_path = Path(metadata['readme_path'])
        return readme_path.read_text()


# Singleton instance
_builder = None

def get_builder() -> ToolBuilder:
    """Get or create the ToolBuilder singleton."""
    global _builder
    if _builder is None:
        _builder = ToolBuilder()
    return _builder
