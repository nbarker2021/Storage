"""
SpeedLight Dependency Tracking:
External dependencies removed: setuptools
Original file: cqe_modules/setup.py

NEEDS_DEPS: ["setuptools"]

This module has been converted to stdlib-only.
SpeedLight will track and manage any runtime dependency needs.
"""



setup(
    name="video_gen",
    version="1.0.0",
    description="CQE Generative Video System",
    packages=find_packages(),
    python_requires=">=3.9"
)
