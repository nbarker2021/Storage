"""Aletheia AI - Local Reasoning Engine"""
