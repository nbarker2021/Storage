# Contributing

## Dev setup
```bash
python -m venv .venv && source .venv/bin/activate
python -m pip install -U pip
pip install -e .[dev]
```

## Quality
- `make test` — unit tests
- `make lint` — ruff (fast) 
- `make format` — black

## PR checklist
- [ ] Add/Update tests when changing behavior
- [ ] Update docs if public API changes
- [ ] Keep MORSR `keep{}` fields populated for new metrics
