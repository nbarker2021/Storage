# Runbook

## One-time setup
```bash
make setup
```

## Daily
```bash
make tick
make test
```

## Demos
- RAG: `make rag`
- Detensor: `make detensor`
