import re, json, collections, argparse, csv, sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--outdir", default="artifacts/keyword_intake")
    args = ap.parse_args()

    Path(args.outdir).mkdir(parents=True, exist_ok=True)
    STOP = set("a an and are as at be been but by for from had has have he her him his i if in into is it its just me more most my no nor not of on or our she should so than that the their them then there these they this to too was we were what when where which who whom why will with you your".split())
    token_pat = re.compile(r"[A-Za-z0-9][A-Za-z0-9_\-+.]*|\b[CA]\[[0-9]+\]\b")
    freq = collections.Counter()
    pairs = collections.Counter()
    tokens = []
    for p in args.inputs:
        t = Path(p).read_text(encoding="utf-8", errors="ignore")
        toks = token_pat.findall(t)
        toks = [w if (w.upper() == w) else w.lower() for w in toks if w.lower() not in STOP]
        tokens.extend(toks)
    for i,w in enumerate(tokens):
        freq[w]+=1
        for j in range(i+1,min(i+11,len(tokens))):
            a,b = sorted([w,tokens[j]])
            if a!=b: pairs[(a,b)]+=1
    with open(Path(args.outdir)/"all_terms_frequency.csv","w",newline="",encoding="utf-8") as f:
        wtr = csv.writer(f); wtr.writerow(["term","count"]); wtr.writerows(freq.most_common())
    with open(Path(args.outdir)/"keyword_links_pairs.csv","w",newline="",encoding="utf-8") as f:
        wtr = csv.writer(f); wtr.writerow(["term_a","term_b","co_count"]); wtr.writerows([(a,b,c) for (a,b),c in pairs.most_common()])
    print("Wrote keyword intake to", args.outdir)

if __name__=="__main__":
    main()
