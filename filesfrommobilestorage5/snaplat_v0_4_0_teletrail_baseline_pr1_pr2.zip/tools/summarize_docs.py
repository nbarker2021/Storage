import re, argparse, json
from pathlib import Path

MUST = ["goal","assumption","constraint","algorithm","metric","plan","risk","test","acceptance","governance","detector","leakage","coverage","drift","MDHG","AGRM","SAP","E8","DTT","DNA","glyph","coxeter","shell","neighbor"]

def summarize(path: Path)->str:
    t = path.read_text(encoding="utf-8", errors="ignore")
    lines = t.splitlines()
    sents = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", t)
    keep = [s.strip() for s in sents if any(k.lower() in s.lower() for k in MUST)]
    out = ["# " + path.name, "", "## Must-keep", *["- " + s for s in keep[:120]]]
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--outdir", default="artifacts/summaries")
    args = ap.parse_args()
    Path(args.outdir).mkdir(parents=True, exist_ok=True)
    for p in args.inputs:
        md = summarize(Path(p))
        out = Path(args.outdir)/(Path(p).name+".md")
        out.write_text(md, encoding="utf-8")
    print("Wrote summaries to", args.outdir)

if __name__=="__main__":
    main()
