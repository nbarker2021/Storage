# Security Policy

- Report sensitive issues privately.
- Do not include secret keys in the repo; use `.env` (not committed).
- Respect S⁺ leakage thresholds when adding demos or datasets.
