
from collections import defaultdict
from typing import Any, Dict
class MDHG:
    def __init__(self):
        self.kv: Dict[str, Any] = {}
        self.access = defaultdict(int)
    def put(self, k: str, v: Any): self.kv[k] = v
    def get(self, k: str, default=None):
        self.access[k] += 1
        return self.kv.get(k, default)
    def has(self, k: str) -> bool: return k in self.kv
    def hotmap(self): return dict(self.access)



def decay(self, factor: float = 0.9, cap: int = 1000):
    """Decay access counts and cap them to stabilize heat."""
    for k in list(self.access.keys()):
        v = int(self.access[k] * factor)
        if v <= 0: self.access.pop(k, None)
        else: self.access[k] = min(v, cap)
