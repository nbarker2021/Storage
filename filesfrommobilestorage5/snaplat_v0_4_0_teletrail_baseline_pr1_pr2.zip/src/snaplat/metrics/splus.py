def leakage_from_metrics(m: dict) -> float:
    # toy leakage: higher with drift; lower with tac and boundary
    return max(0.0, min(1.0, m.get("drift",0.0) + 0.5*(1.0-m.get("tac",1.0)) + 0.5*(1.0-m.get("boundary",1.0)) ))
