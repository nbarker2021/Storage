from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
from math import log
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..mdhg.bus import MDHGBus

try:
    from ..assembly.core import stitch
    from ..superperm.c8 import produce_c8, C8Config
    from ..dtt.harness import DTT, DTTConfig
except Exception:
    stitch = None

def md_length(weights: List[float]) -> float:
    # Shannon-like DL: -sum w log2 w (ignore zeros)
    s = 0.0
    for w in weights:
        if w > 0.0:
            s += -w * (log(w)/log(2.0))
    return s

@dataclass
class AssemblyAdapter(PlanAdapterProto):
    mdhg: MDHGBus
    seed: int = 99

    def actions(self) -> Dict[str, Action]:
        return {
            "stitch": Action(op="stitch", tag="C", m=0.5),
        }

    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        if stitch is None:
            glyph_dl = 1.0
            self.mdhg.put("asm:last", {"glyph_dl": glyph_dl}, score=1.0, notes={})
            return Trail(metrics={"coverage": 1.0, "drift": 0.0, "glyph_dl": glyph_dl}, artifacts={}, notes={"fallback": True})
        cands = produce_c8(C8Config(seed=self.seed))
        ev = DTT(DTTConfig(seed=self.seed)).run(cands)
        out = stitch(cands, ev)
        # coverage: number of non-zero weights / total
        w = out["DNA"].weights  # type: ignore
        nz = sum(1 for x in w if x > 0.0)
        coverage = nz / float(len(w) or 1)
        gdl = md_length(w)
        self.mdhg.put("asm:last_glyph", out["glyph"], score=coverage, notes={"glyph_dl": gdl})
        return Trail(metrics={"coverage": coverage, "drift": 0.0, "glyph_dl": gdl}, artifacts={"glyph": out["glyph"]}, notes={})

    def learn(self, trace: Trail) -> None:
        return None
