from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
from ..mdhg.bus import MDHGBus

# If nav modules exist use them; otherwise approximate using E8 neighbors as "sector" coverage
try:
    from ..e8.core import nearest, edges
except Exception:
    def nearest(v): return ([0.0]*8, 0.0)
    def edges(x): return [[0.0]*8 for _ in range(240)]

@dataclass
class NavAdapter(PlanAdapterProto):
    mdhg: MDHGBus
    base_point: List[float]

    def actions(self) -> Dict[str, Action]:
        return {
            "sectorize": Action(op="sectorize", tag="E", m=1.0),
            "tour": Action(op="tour", tag="C", m=0.5),
        }

    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        p, _ = nearest(self.base_point or [0.0]*8)
        nbrs = edges(p)
        # Fake sector coverage by sampling every k-th neighbor
        k = int(state.get("sectors", 8))
        touched = len(nbrs[::max(1,k)])
        coverage = min(1.0, touched / 240.0)
        drift = 0.05  # placeholder until proper nav metrics wired
        self.mdhg.put("nav:last", {"touched": touched, "k": k}, score=coverage, notes={"drift": drift})
        return Trail(metrics={"coverage": coverage, "drift": drift}, artifacts={"touched": touched}, notes={})

    def learn(self, trace: Trail) -> None:
        return None
