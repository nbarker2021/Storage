
from __future__ import annotations
import time, json, importlib, pathlib, traceback
from typing import Any, Dict, List, Optional
import yaml
from .queue_router import OpQueue, Op, RouteDecision
from .runlog import RunLog
from .sap_stubs import sentinel_check, arbiter_rule

class Orchestrator:
    def __init__(self, code_root: str, plan_path: str, out_report: str):
        self.code_root = pathlib.Path(code_root).resolve()
        self.plan_path = pathlib.Path(plan_path).resolve()
        self.out_report = pathlib.Path(out_report).resolve()
        self.runlog = RunLog()
        self.queue = OpQueue()
        self.context: Dict[str, Any] = {"code_root": str(self.code_root)}

    def _patch_sys_path(self):
        import sys
        if str(self.code_root) not in sys.path:
            sys.path.insert(0, str(self.code_root))

    def load_plan(self) -> Dict[str, Any]:
        spec = yaml.safe_load(self.plan_path.read_text())
        return spec

    def enqueue_from_plan(self, spec: Dict[str, Any]):
        for i, step in enumerate(spec.get("steps", []), 1):
            op = Op(
                name=step["name"],
                family=step.get("family", "generic"),
                module=step["module"],
                func=step["func"],
                args=step.get("args", []),
                kwargs=step.get("kwargs", {}),
                priority=int(step.get("priority", 100)),
                policy_id=step.get("policy_id", "policy:default"),
                allow_3d=bool(step.get("allow_3d", False)),
            )
            self.queue.push(op)

    def _import_callable(self, module: str, func: str):
        m = importlib.import_module(module)
        fn = getattr(m, func)
        return fn

    def _govern(self, family: str, metrics: Dict[str, Any], policy_id: str) -> str:
        att = sentinel_check(policy_id, metrics)
        rule = arbiter_rule(att)
        self.runlog.log_sap(att, rule, family)
        return rule.decision

    def run(self) -> Dict[str, Any]:
        self._patch_sys_path()
        spec = self.load_plan()
        self.enqueue_from_plan(spec)
        self.runlog.start_run(spec)

        while not self.queue.empty():
            op = self.queue.pop()
            t0 = time.perf_counter()
            status = "ok"; err = None; out: Any = None
            try:
                fn = self._import_callable(op.module, op.func)
                # governance pre-check (stubbed metrics for now)
                pre_metrics = {"tau": 0.99, "overlap": 0.99}  # placeholder
                decision = self._govern(op.family, pre_metrics, op.policy_id)
                if decision == "deny":
                    status = "skipped_denied"
                    out = None
                else:
                    out = fn(*op.args, **op.kwargs)
            except Exception as e:
                status = "error"
                err = {"type": type(e).__name__, "msg": str(e), "trace": traceback.format_exc()}
            dur = (time.perf_counter() - t0) * 1000.0
            self.runlog.log_op(op, status, dur, out, err)
        rep = self.runlog.finish_run()
        self.out_report.write_text(json.dumps(rep, indent=2))
        return rep
