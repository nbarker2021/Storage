
#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
export CODE_UNDER_TEST="${CODE_UNDER_TEST:-/mnt/data/ground_up_build}"
export TEST_PLAN="${TEST_PLAN:-$ROOT_DIR/plans/example_plan.yml}"
export DRYRUN_REPORT="${DRYRUN_REPORT:-$ROOT_DIR/dryrun_report.json}"

python -c "from src.testlib_plus.orchestrator import Orchestrator; import os; print('Running orchestrator...'); Orchestrator(os.environ['CODE_UNDER_TEST'], os.environ['TEST_PLAN'], os.environ['DRYRUN_REPORT']).run()"

pytest -q -m orchestrated
echo "Dry run complete. Report at: $DRYRUN_REPORT"
