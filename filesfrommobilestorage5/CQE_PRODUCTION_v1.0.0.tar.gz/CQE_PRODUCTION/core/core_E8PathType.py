class E8PathType(Enum):
    WEYL_CHAMBER = "weyl_chamber"
    ROOT_SYSTEM = "root_system" 
    WEIGHT_SPACE = "weight_space"
    COXETER_PLANE = "coxeter_plane"
    KISSING_NUMBER = "kissing_number"
    LATTICE_PACKING = "lattice_packing"

@dataclass