from __future__ import annotations
from typing import Any, Dict
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class Summary:
    n: int | None
    alphabet_size: int | None
    lower_bound: int | None
    upper_bound: int | None
    hints: Dict[str, Any]

def summarize(config: Dict[str, Any]) -> Summary:
    """Read‑only summarizer for superpermutation configs; no heavy search.

    Extracts shallow parameters and emits Trails for audit.
    """
    tid = trails.begin_trail({"op":"superperm.summarize","module":__name__,"policy_hash":POLICY_HASH})
    try:
        n = None
        a = None
        lb = None
        ub = None
        if isinstance(config, dict):
            n = int(config.get("n")) if config.get("n") is not None else None
            a = int(config.get("alphabet_size")) if config.get("alphabet_size") is not None else None
            lb = int(config.get("lower_bound")) if config.get("lower_bound") is not None else None
            ub = int(config.get("upper_bound")) if config.get("upper_bound") is not None else None
        hints = {k:v for k,v in (config or {}).items() if k not in {"n","alphabet_size","lower_bound","upper_bound"}}
        trails.append_event(tid, {"op":"superperm.summary","module":__name__,"payload":{"n":n,"a":a,"lb":lb,"ub":ub}})
        return Summary(n=n, alphabet_size=a, lower_bound=lb, upper_bound=ub, hints=hints)
    finally:
        trails.finalize(tid, {"op":"superperm.done","module":__name__})
