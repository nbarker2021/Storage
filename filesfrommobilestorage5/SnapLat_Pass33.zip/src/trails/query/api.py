from __future__ import annotations
from typing import Any, Dict, Iterable, List, Optional

def _match_chain(payload: Dict[str, Any], *, agent_fp: Optional[str], snap_fp: Optional[str]) -> bool:
    ch = payload.get("chain") if isinstance(payload, dict) else None
    if ch and isinstance(ch, dict):
        aok = (agent_fp is None) or (ch.get("agent_fp") == agent_fp)
        sok = (snap_fp is None) or (ch.get("snap_fp") == snap_fp)
        if aok and sok:
            return True
    # some append events (e.g., porter.attempt) may expose snap_fp at top-level payload
    if snap_fp is not None and payload.get("snap_fp") == snap_fp:
        if agent_fp is None:
            return True
    return False

def filter_events(events: Iterable[Dict[str, Any]], *, agent_fp: Optional[str] = None, snap_fp: Optional[str] = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for e in events:
        payload = e.get("payload", {}) if isinstance(e, dict) else {}
        if _match_chain(payload, agent_fp=agent_fp, snap_fp=snap_fp):
            out.append(e)
    return out

def summarize_ops(events: Iterable[Dict[str, Any]]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for e in events:
        op = e.get("payload", {}).get("op")
        if isinstance(op, str):
            counts[op] = counts.get(op, 0) + 1
    return counts
