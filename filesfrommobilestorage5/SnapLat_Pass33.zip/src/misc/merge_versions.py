
from __future__ import annotations
import argparse, pathlib, zipfile, tarfile, shutil, json
from detect_version import path_version

def is_archive(p: pathlib.Path) -> bool:
    return p.suffix.lower() in (".zip",".tar",".gz",".tgz",".bz2",".xz")

def extract(p: pathlib.Path, out: pathlib.Path) -> pathlib.Path:
    out.mkdir(parents=True, exist_ok=True)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p,"r") as zf: zf.extractall(out)
    elif p.suffix.lower() in (".tar",".gz",".tgz",".bz2",".xz"):
        with tarfile.open(p,"r:*") as tf: tf.extractall(out)
    elif p.is_dir():
        shutil.copytree(p, out, dirs_exist_ok=True)
    else:
        raise ValueError(f"Unsupported input: {p}")
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inputs", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    out = pathlib.Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    manifest = {"inputs": [], "versions": []}
    for inp in args.inputs:
        p = pathlib.Path(inp).resolve()
        ver = path_version(p)
        vdir = out / f"stage_v{ver if ver is not None else 'unknown'}" / p.stem
        print(f"[stage] {p} -> {vdir}")
        extract(p, vdir)
        manifest["inputs"].append(str(p))
        manifest["versions"].append({"path": str(vdir), "version": ver})
    (out/"merge_manifest.json").write_text(json.dumps(manifest, indent=2))
    print("[done] Staged all inputs.")
if __name__ == "__main__": main()
