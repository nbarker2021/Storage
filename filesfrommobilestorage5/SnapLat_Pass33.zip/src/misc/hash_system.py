
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional
import numpy as np, hashlib
from .types import House

@dataclass
class HashSystem:
    """
    Two-tier hash:
      Tier1: geometric LSH via random projections in R^8.
      Tier2: semantic hash (trainable weights + bias); default random.
    """
    dim: int = 8
    tier1_bits: int = 64
    tier2_bits: int = 64
    version: int = 1
    seed: int = 1234

    def __post_init__(self):
        self.houses: Dict[Tuple[bytes, bytes], House] = {}
        rng = np.random.default_rng(self.seed)
        self.W1 = rng.standard_normal((self.dim, self.tier1_bits))
        # Tier2 weights and bias
        self.W2 = rng.standard_normal((self.dim, self.tier2_bits))
        self.b2 = np.zeros((self.tier2_bits,), dtype=float)

    # --- trainable Tier-2 injection ---
    def set_tier2_weights(self, W: np.ndarray, b: np.ndarray):
        assert W.shape == (self.dim, self.tier2_bits)
        assert b.shape == (self.tier2_bits,)
        self.W2 = W.astype(float)
        self.b2 = b.astype(float)

    def _bits_to_bytes(self, bits: np.ndarray) -> bytes:
        b = 0
        out = bytearray()
        for i, bit in enumerate(bits.astype(np.uint8)):
            b = (b << 1) | int(bit)
            if (i+1) % 8 == 0:
                out.append(b); b = 0
        rem = len(bits) % 8
        if rem != 0:
            out.append(b << (8 - rem))
        return bytes(out)

    def tier1(self, v: np.ndarray) -> bytes:
        proj = v @ self.W1
        bits = (proj >= 0).astype(np.uint8)
        return self._bits_to_bytes(bits)

    def tier2(self, v: np.ndarray, meta: Optional[np.ndarray] = None, temperature: float = 1.0) -> bytes:
        x = v
        if meta is not None and meta.ndim == 1:
            if meta.size < self.dim:
                meta = np.pad(meta, (0, self.dim - meta.size))
            else:
                meta = meta[:self.dim]
            x = (v + meta) / 2.0
        proj = x @ self.W2 + self.b2
        proj = proj / max(1e-6, temperature)
        bits = (proj >= 0).astype(np.uint8)
        return self._bits_to_bytes(bits)

    def house_key(self, v: np.ndarray, meta: Optional[np.ndarray] = None) -> Tuple[bytes, bytes]:
        return (self.tier1(v), self.tier2(v, meta))

    def touch_house(self, key: Tuple[bytes, bytes]) -> House:
        h = self.houses.get(key)
        if h is None:
            h = House(h1=key[0], h2=key[1])
            self.houses[key] = h
        h.hotness = 0.8*h.hotness + 1.0
        return h

    def add_item(self, key: Tuple[bytes, bytes], item_id: str):
        h = self.touch_house(key)
        if item_id not in h.items:
            h.items.append(item_id)

    def neighbors_link(self, key_a: Tuple[bytes, bytes], key_b: Tuple[bytes, bytes]):
        ha = self.touch_house(key_a)
        hb = self.touch_house(key_b)
        if key_b not in ha.neighbors:
            ha.neighbors.append(key_b)
        if key_a not in hb.neighbors:
            hb.neighbors.append(key_a)

    def hot_zones(self, hot_thresh: float = 2.0) -> List[House]:
        return [h for h in self.houses.values() if h.hotness >= hot_thresh]


# --- export/import Tier-2 ---
def export_tier2(self):
    return {"W2": self.W2.tolist(), "b2": self.b2.tolist(), "bits": int(self.tier2_bits), "dim": int(self.dim)}

def import_tier2(self, data):
    W = np.array(data["W2"], dtype=float); b = np.array(data["b2"], dtype=float)
    self.set_tier2_weights(W, b)

def hash_batch(self, V: np.ndarray):
    keys = []
    for v in V:
        keys.append(self.house_key(v))
    return keys
