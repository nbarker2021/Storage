
from __future__ import annotations
import numpy as np, time
from typing import Dict, Any, List, Tuple
from lattice_ai.encode.e8_text import embed_batch
from lattice_ai.encode.e8_lattice import E8LatticeEncoder
from lattice_ai.hash.two_tier import TwoTierHash, build_houses

def _cosine(a: np.ndarray, B: np.ndarray) -> np.ndarray:
    a = a/(np.linalg.norm(a)+1e-12)
    B = B/(np.linalg.norm(B,axis=1,keepdims=True)+1e-12)
    return B @ a

def synth_corpus(num_topics=8, per_topic=60, noise=0.08, seed=99)->Tuple[List[str], np.ndarray, List[int]]:
    """Create clustered text corpus; return texts, embeddings, labels."""
    rng = np.random.default_rng(seed)
    topics = [f"topic_{i}" for i in range(num_topics)]
    texts: List[str] = []
    labels: List[int] = []
    for ti, t in enumerate(topics):
        for j in range(per_topic):
            s = f"{t} sample {j} E8-lattice reasoner"
            texts.append(s); labels.append(ti)
    enc = E8LatticeEncoder(salt="E8"); X = enc.encode_texts(texts, k=3, shell_k=1)["vectors"]
    # add tiny noise in the 8D space to spread per topic
    X = X + rng.normal(0.0, noise, X.shape).astype(np.float32)
    X = X / (np.linalg.norm(X, axis=1, keepdims=True)+1e-12)
    return texts, X.astype(np.float32), labels

def eval_recall_latency(K=10, seed=99, house_mod=257) -> Dict[str, Any]:
    texts, X, labels = synth_corpus(seed=seed)
    # Build Two-Tier hash
    h = TwoTierHash.make(bits=16, seed=seed)
    keys = h.house_keys(X)
    houses = build_houses(keys, mod=house_mod)

    # Queries: one per topic — pick a median example
    q_idx = []
    for t in range(8):
        idx = [i for i,l in enumerate(labels) if l==t]
        q_idx.append(idx[len(idx)//2])
    Q = X[q_idx]

    # Routing under budget: prefilter to house of q, exact rerank by cosine
    rec_hits = 0; total=0; lat_ops=0; cand_counts=[]
    for qi, q in enumerate(Q):
        b = int(h.house_keys(q.reshape(1,-1))[0] % house_mod)
        cand = houses.get(b, [])
        cand_counts.append(int(len(cand)))
        lat_ops += 1 + len(cand) + K  # simplistic proxy
        if len(cand)==0: continue
        sims = _cosine(q, X[cand]); order = np.argsort(-sims)
        # ground truth: same-topic items (excluding q if present)
        truth = set(i for i,l in enumerate(labels) if l==labels[q_idx[qi]] and i!=q_idx[qi])
        topk = [int(cand[i]) for i in order[:K]]
        hits = sum(1 for i in topk if i in truth)
        rec_hits += 1 if hits>0 else 0
        total += 1

    recall_at1_nonzero = rec_hits / max(total,1)
    return {
        "_artifact": "golden_recall_latency",
        "data": {
            "K": K,
            "recall@1_nonzero": recall_at1_nonzero,
            "avg_cand": float(np.mean(cand_counts)) if cand_counts else 0.0,
            "p95_cand": float(np.percentile(cand_counts,95)) if cand_counts else 0.0,
            "latency_proxy_ops": lat_ops,
            "house_mod": house_mod,
            "notes": {"tier1_bits": 16}
        },
        "_optimization_points": ["Try bits=24 and house_mod≈1021", "Consider α/β blending when geodesic is ready"],
        "_weak_spots": ["No learned Tier-2 yet; using legacy hash backend, may be uncorrelated with semantics"]
    }
