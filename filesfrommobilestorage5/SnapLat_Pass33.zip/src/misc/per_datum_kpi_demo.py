
import numpy as np
from lattice_ai.core.safe_cube import SafeCube
from lattice_ai.core.per_datum import PerDatumLattice

def main():
    cube = SafeCube(dim=8, seed=1)
    vg = cube.glyph_vector("doc::0")
    pd_t = PerDatumLattice(id="template", rank=2)
    pd_t.add_anchor_pair(vg, vg); pd_t.fit_map()

    pd = PerDatumLattice(id="doc::0", rank=2)
    pd.init_from_template(pd_t)
    pd.add_anchor_pair(vg, vg*0.98); pd.fit_map()

    dist = pd.kpi_round_trip()
    print("Round-trip distortion:", round(dist,6))

    pd.set_capabilities("summary", ["write","read"])
    try:
        pd.add_memory_guarded("summary", "Hello", "write")
        print("KV write ok")
    except Exception as e:
        print("KV write failed:", e)

if __name__ == "__main__":
    main()
