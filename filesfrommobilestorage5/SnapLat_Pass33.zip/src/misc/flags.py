
import os

ENABLE_DUAL_RETRIEVAL = os.getenv("ENABLE_DUAL_RETRIEVAL", "0") == "1"
ENABLE_DUAL_SHELLS = os.getenv("ENABLE_DUAL_SHELLS", "0") == "1"
SNAP_ON_COMPARE = os.getenv("SNAP_ON_COMPARE", "0") == "1"
