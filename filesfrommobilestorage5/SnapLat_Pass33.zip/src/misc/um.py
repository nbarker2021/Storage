
class Universe:
    def __init__(self, name):
        self.name = name
        self.overlays = {}
        self.spec = type('Spec', (), {'policies':{}})()
class UM:
    def __init__(self):
        self.u = {}
    def get_universe(self, n):
        if n not in self.u:
            self.u[n] = Universe(n)
        return self.u[n]
    def save_universe(self, u):
        self.u[u.name] = u
um = UM()
