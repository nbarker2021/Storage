
import re, json
from pathlib import Path
from typing import Dict, List
from .classifier import file_features, guess_role_universe

HEAD = re.compile(r'^\s{0,3}(?:#{1,6}|[-*+]\s+|\d+\.\s+)\s*(?:Tool|Agent|Module|Pipeline|System|Controller|Engine|Service|CLI|Indexer|Retriever|Reranker|Compressor|Navigator|Ledger|Policy)\b[:\s\-]*([A-Za-z0-9_\- ()./]+)?', re.I)
JSON_TOOLS = re.compile(r'"(?:tools|modules|pipelines|agents)"\s*:\s*\[', re.I)

def discover_tools(root: Path) -> List[Dict]:
    tools = []
    for p in root.rglob("*"):
        if not p.is_file() or p.stat().st_size==0 or p.suffix.lower() not in {".md",".txt",".json",".json5"}:
            continue
        feats = file_features(p)
        scope = guess_role_universe(p, feats)
        text = p.read_text(encoding="utf-8", errors="ignore")
        lines = text.splitlines()
        for i, ln in enumerate(lines, start=1):
            m = HEAD.match(ln)
            if m:
                name = (m.group(1) or "").strip() or ln.strip()[:80]
                tools.append({"tool": name, "file": p.name, "line": i, "universe": scope["universe"], "role": scope["role"]})
            if JSON_TOOLS.search(ln):
                block = [ln]; j=i
                while j < len(lines) and ']' not in lines[j]:
                    j+=1
                    if j<len(lines): block.append(lines[j])
                for nm in re.findall(r'"([A-Za-z0-9_\- .:/]+)"', "\n".join(block)):
                    if len(nm)>=3:
                        tools.append({"tool": nm, "file": p.name, "line": i, "universe": scope["universe"], "role": scope["role"]})
    return tools

def canonicalize(tools: List[Dict]) -> Dict:
    # simple case-fold canonicalization
    canon = {}
    variants = {}
    for t in tools:
        k = t["tool"].strip()
        c = k.lower()
        canon.setdefault(c, {"canonical": k, "variants": set(), "universes": set(), "roles": set(), "files": set()})
        canon[c]["variants"].add(k)
        canon[c]["universes"].add(t["universe"])
        canon[c]["roles"].add(t["role"])
        canon[c]["files"].add(t["file"])
    # materialize
    out = []
    for c, rec in sorted(canon.items()):
        out.append({
            "canonical": sorted(rec["variants"], key=len)[0],
            "variants": sorted(rec["variants"]),
            "universes": sorted(rec["universes"]),
            "roles": sorted(rec["roles"]),
            "files": sorted(rec["files"])
        })
    return {"tools": out}

def build_manifests(root: Path, out: Path):
    tools = discover_tools(root)
    canon = canonicalize(tools)
    # per-universe manifests
    per_uni = {}
    for t in canon["tools"]:
        for u in t["universes"]:
            per_uni.setdefault(u, []).append(t["canonical"])
    # write
    (out / "tool_manifest.json").write_text(json.dumps({"canonical": canon, "per_universe": per_uni}, indent=2))
