
import time
def write_ops_report(repo, *, rows):
    rid = f"ops_report::{int(time.time())}"
    payload = {"meta":{"snap_id": rid, "family":"report","type":"ops"}, "content":{"rows": rows}}
    repo.save(rid, payload)
    return rid, payload
