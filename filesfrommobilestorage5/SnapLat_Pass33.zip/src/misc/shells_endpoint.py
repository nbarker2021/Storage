
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
import numpy as np

from config.flags import ENABLE_DUAL_SHELLS
from shelling.dual_compare_shells import compare_shells

router = APIRouter()

class ShellsBody(BaseModel):
    center: list[float] = Field(..., min_items=8, max_items=8)
    neighbors_v14: list[list[float]]
    neighbors_legacy: list[list[float]] | None = None

METRICS = {
    "shell_requests_total": 0,
    "shell_dual_compare_total": 0,
}

@router.post("/build_shells")
def build_shells(body: ShellsBody):
    METRICS["shell_requests_total"] += 1
    center = np.array(body.center, dtype=float)
    v14 = np.array(body.neighbors_v14, dtype=float)
    leg = np.array(body.neighbors_legacy, dtype=float) if body.neighbors_legacy is not None else None
    res = {"ok": True}
    if ENABLE_DUAL_SHELLS:
        METRICS["shell_dual_compare_total"] += 1
        rep = compare_shells(center, v14, leg, axes={"version_container":"v14","tenant":"demo","domain":"shelling"})
        res["dual_compare"] = rep
    return res
