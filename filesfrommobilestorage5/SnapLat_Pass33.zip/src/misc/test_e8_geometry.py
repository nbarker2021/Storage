
import numpy as np
from lattice_ai.geometry.e8_roots import E8, generate_e8_roots, standard_simple_roots
from lattice_ai.geometry.e8 import E8Geometry

def test_root_count_and_lengths():
    R = generate_e8_roots()
    assert R.shape == (240, 8)
    norms = np.sum(R*R, axis=1)
    assert np.allclose(norms, 2.0)

def test_simple_roots_basis():
    S = standard_simple_roots()
    assert S.shape == (8, 8)

def test_neighbor_graph_invariant():
    e8 = E8.build()
    R, nbrs = e8.neighbor_graph()
    assert len(nbrs) == len(R)
    assert any(len(n) > 0 for n in nbrs)

def test_reflections_are_involutions():
    g = E8Geometry()
    R = generate_e8_roots()[:3]
    r0 = R[0]
    V_ref = g.reflect(R, r0)
    V_back = g.reflect(V_ref, r0)
    assert np.allclose(R, V_back)
