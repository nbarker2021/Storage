
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
from typing import Iterable, List

def list_prefix(repo, prefix: str) -> List[str]:
    keys = []
    if hasattr(repo, "list"):
        try:
            keys = list(repo.list(prefix))
        except Exception:
            pass
    elif hasattr(repo, "store"):
        keys = [k for k in repo.store.keys() if str(k).startswith(prefix)]
    elif hasattr(repo, "keys"):
        keys = [k for k in repo.keys() if str(k).startswith(prefix)]
    return list(map(str, keys))

def delete_prefix(repo, prefix: str) -> int:
    deleted = 0
    # native batch delete
    if hasattr(repo, "delete_prefix"):
        try:
            return int(repo.delete_prefix(prefix))
        except Exception:
            pass
    # fallback: manual
    if hasattr(repo, "store"):
        for k in list(repo.store.keys()):
            if str(k).startswith(prefix):
                try:
                    del repo.store[k]
                    deleted += 1
                except Exception:
                    continue
    return deleted
