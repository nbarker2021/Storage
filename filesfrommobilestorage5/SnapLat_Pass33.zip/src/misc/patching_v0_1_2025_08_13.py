
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict, Any
import numpy as np, math, random

@dataclass
class PatchProposal_v0_1_2025_08_13:
    kind: str                    # 'SNI' | 'TNI' | 'SCS' | 'ESW'
    insert_nodes: Tuple[int, ...]
    edge: Tuple[int, int]        # (i, j) edge being replaced
    score: float
    delta_length: float
    cov_gain: int
    tension_gain: float
    meta: Dict[str, Any]

def tour_length_v0_1_2025_08_13(points: np.ndarray, tour: List[int]) -> float:
    L=0.0
    for a,b in zip(tour, tour[1:] + tour[:1]):
        L += float(np.linalg.norm(points[a] - points[b]))
    return L

def _edge_len(points: np.ndarray, a: int, b: int) -> float:
    return float(np.linalg.norm(points[a]-points[b]))

def _sector_continuity_gain(sectors, i, j, k=None, l=None) -> float:
    # reward if sector ids change less after insertion; simple absolute diff heuristic
    def diff(a,b): 
        return abs((a-b))
    base = diff(sectors[i], sectors[j])
    if k is None:
        return 0.0
    gain = base - (diff(sectors[i], sectors[k]) + diff(sectors[k], sectors[j]))
    if l is not None:
        gain = base - (diff(sectors[i], sectors[k]) + diff(sectors[k], sectors[l]) + diff(sectors[l], sectors[j]))
    return float(gain)

def propose_single_node_v0_1_2025_08_13(points: np.ndarray, tour: List[int], unvisited: List[int], sectors: List[int], w=(1.0, 0.7, 0.2, 0.01), topk: int=20) -> List[PatchProposal_v0_1_2025_08_13]:
    w_len, w_cov, w_ten, w_cost = w
    n = len(tour)
    props = []
    if not unvisited: 
        return props
    # sample some edges (or all if small)
    edge_indices = list(range(n))
    if n > 128:
        random.shuffle(edge_indices)
        edge_indices = edge_indices[:64]
    for ei in edge_indices:
        i = tour[ei]
        j = tour[(ei+1)%n]
        base_len = _edge_len(points, i, j)
        for k in random.sample(unvisited, min(len(unvisited), 64)):
            new_len = _edge_len(points, i, k) + _edge_len(points, k, j)
            delta = base_len - new_len
            cov = 1 if (sectors[k] not in {sectors[i], sectors[j]}) else 0
            ten = _sector_continuity_gain(sectors, i, j, k)
            score = w_len*delta + w_cov*cov + w_ten*ten - w_cost*1.0
            props.append(PatchProposal_v0_1_2025_08_13(kind="SNI", insert_nodes=(k,), edge=(i,j), score=score, delta_length=delta, cov_gain=cov, tension_gain=ten, meta={"ei":ei}))
    props.sort(key=lambda p: p.score, reverse=True)
    return props[:topk]

def apply_patch_v0_1_2025_08_13(tour: List[int], patch: PatchProposal_v0_1_2025_08_13) -> List[int]:
    i, j = patch.edge
    # find edge (i,j) position
    n = len(tour)
    for idx in range(n):
        if tour[idx]==i and tour[(idx+1)%n]==j:
            pos = idx+1
            return tour[:pos] + list(patch.insert_nodes) + tour[pos:]
    # also try reversed edge in case
    for idx in range(n):
        if tour[idx]==j and tour[(idx+1)%n]==i:
            pos = idx+1
            return tour[:pos] + list(patch.insert_nodes) + tour[pos:]
    return tour

def revert_patch_v0_1_2025_08_13(tour: List[int], patch: PatchProposal_v0_1_2025_08_13) -> List[int]:
    # remove the inserted sequence from tour (first occurrence)
    ins = list(patch.insert_nodes)
    out = []
    skip = 0
    for x in tour:
        if skip < len(ins) and x == ins[skip]:
            skip += 1
            continue
        out.append(x)
    return out

def patch_loop_v0_1_2025_08_13(points: np.ndarray, tour: List[int], sectors: List[int], budget_edges: int=50, budget_iter: int=25):
    all_nodes = set(range(points.shape[0]))
    in_tour = set(tour)
    unvisited = list(all_nodes - in_tour)
    before = tour_length_v0_1_2025_08_13(points, tour)
    it = 0
    accepted = 0
    while it < budget_iter and unvisited:
        proposals = propose_single_node_v0_1_2025_08_13(points, tour, unvisited, sectors, topk=10)
        if not proposals:
            break
        p = proposals[0]
        new_tour = apply_patch_v0_1_2025_08_13(tour, p)
        after = tour_length_v0_1_2025_08_13(points, new_tour)
        # accept if improves length or brings coverage and doesn't worsen length too much
        if after <= before or (p.cov_gain>0 and after <= before*1.01):
            tour = new_tour
            before = after
            for k in p.insert_nodes:
                if k in unvisited:
                    unvisited.remove(k)
            accepted += 1
        it += 1
    return tour, {"accepted": float(accepted), "iters": float(it), "final_length": float(before)}
