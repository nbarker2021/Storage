
import numpy as np
from retrieval.scorer import ScorerConfig, blended_score

def test_blended_monotonicity():
    q = np.eye(8)[0]
    docs = np.eye(8)
    s = blended_score(q, docs, ScorerConfig(alpha=1.0, beta=0.0))
    # best match should be index 0 with cosine=1
    assert int(np.argmax(s)) == 0
