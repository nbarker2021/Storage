
import numpy as np
def knn(points: np.ndarray, queries: np.ndarray, k:int=8):
    try:
        import hnswlib  # type: ignore
        d = points.shape[1]
        p = hnswlib.Index(space='l2', dim=d)
        p.init_index(max_elements=points.shape[0], ef_construction=100, M=16)
        p.add_items(points.astype(np.float32))
        p.set_ef(50)
        I, D = p.knn_query(queries.astype(np.float32), k=k)
        return I, D
    except Exception:
        # fallback: brute-force
        I_list=[]; D_list=[]
        for q in queries:
            dists = np.linalg.norm(points - q, axis=1)
            idx = np.argsort(dists)[:k]
            I_list.append(idx); D_list.append(dists[idx])
        return np.stack(I_list), np.stack(D_list)
