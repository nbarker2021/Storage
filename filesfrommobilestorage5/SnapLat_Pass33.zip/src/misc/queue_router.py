
from __future__ import annotations
import heapq
from dataclasses import dataclass, field
from typing import Any, List

@dataclass(order=True)
class PrioritizedItem:
    priority: int
    item: Any=field(compare=False)

@dataclass
class Op:
    name: str
    family: str
    module: str
    func: str
    args: list
    kwargs: dict
    priority: int = 100
    policy_id: str = "policy:default"
    allow_3d: bool = False

class RouteDecision: ...

class OpQueue:
    def __init__(self) -> None:
        self._h: List[PrioritizedItem] = []

    def push(self, op: Op) -> None:
        heapq.heappush(self._h, PrioritizedItem(op.priority, op))

    def pop(self) -> Op:
        return heapq.heappop(self._h).item

    def empty(self) -> bool:
        return len(self._h) == 0
