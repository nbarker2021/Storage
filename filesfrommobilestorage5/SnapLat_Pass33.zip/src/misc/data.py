
import numpy as np
rng = np.random.default_rng(13579)
def make_points(style, N):
    if style=="bimodal":
        C1 = rng.normal([-2.5, 0.0], 1.1, size=(N//2,2))
        C2 = rng.normal([+3.0, 0.2], 1.2, size=(N - N//2,2))
        return np.vstack([C1,C2])
    if style=="ring":
        r = rng.normal(4.2, 0.4, size=(N,))
        th = rng.uniform(-np.pi, np.pi, size=(N,))
        return np.c_[r*np.cos(th), r*np.sin(th)]
    if style=="line":
        x = rng.uniform(-6, 6, size=(N,))
        y = 0.55*x + rng.normal(0, 1.0, size=(N,))
        return np.c_[x,y]
    return rng.normal([0,0],1.0,size=(N,2))
families_pool = ["science","finance","biology","data_mgmt","governance","fiction"]
types_pool = ["fact","narrative","metric","policy","spec","note"]
def make_metas(N, bias_family=None):
    metas = []
    for i in range(N):
        fam = bias_family if (bias_family and rng.random()<0.6) else families_pool[int(rng.integers(0,len(families_pool)))]
        typ = types_pool[int(rng.integers(0,len(types_pool)))]
        metas.append({"family": fam, "type": typ, "content": {"text": f"{fam}::{typ} record {i}"}})
    return metas
