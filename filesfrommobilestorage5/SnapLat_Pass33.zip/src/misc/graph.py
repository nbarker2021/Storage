
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, List, Tuple
from .e8 import E8Key

@dataclass
class Node:
    gid: str
    kind: str
    label: str
    e8: E8Key
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Edge:
    src: str
    dst: str
    rel: str
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Ledger:
    nodes: Dict[str, Node] = field(default_factory=dict)
    edges: List[Edge] = field(default_factory=list)

    def upsert_node(self, node: Node):
        self.nodes[node.gid] = node

    def add_edge(self, e: Edge):
        self.edges.append(e)

    def to_json(self):
        return {
            "nodes": {gid: {"kind":n.kind,"label":n.label,"e8":asdict(n.e8),"meta":n.meta} for gid,n in self.nodes.items()},
            "edges": [asdict(e) for e in self.edges],
        }
