
"""
Runtime configuration loader.
- Sources: environment variables with prefix LATTICE_*
- Defaults chosen for local demo; override in Docker/env.
"""
import os

class Config:
    API_KEY = os.getenv("LATTICE_API_KEY", "")
    DB_PATH = os.getenv("LATTICE_DB_PATH", "/mnt/data/lattice_ai_v16.db")
    BUDGET_P95_MS = float(os.getenv("LATTICE_BUDGET_P95_MS", "20.0"))
    CANDIDATE_START = int(os.getenv("LATTICE_CANDIDATE_START", "64"))
    CANDIDATE_MIN = int(os.getenv("LATTICE_CANDIDATE_MIN", "16"))
    CANDIDATE_MAX = int(os.getenv("LATTICE_CANDIDATE_MAX", "256"))
