
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import numpy as np

@dataclass
class PerDatumLattice:
    "Per-datum lattice with identity mapping (baseline), KV store, KPIs, capabilities, templates."
    id: str
    rank: int = 2
    anchors_global: np.ndarray = field(default_factory=lambda: np.zeros((0,8)))
    anchors_local: np.ndarray = field(default_factory=lambda: np.zeros((0,8)))
    kv_delta: Dict[str, Any] = field(default_factory=dict)
    kv_caps: Dict[str, List[str]] = field(default_factory=dict)
    template_id: str = ''

    # Identity map for baseline; can swap for AnchorMap later
    def to_local(self, V: np.ndarray) -> np.ndarray:
        return V

    def to_global(self, V: np.ndarray) -> np.ndarray:
        return V

    def add_anchor_pair(self, vg: np.ndarray, vl: np.ndarray):
        if self.anchors_global.size == 0:
            self.anchors_global = vg[None, :]
            self.anchors_local = vl[None, :]
        else:
            self.anchors_global = np.vstack([self.anchors_global, vg[None, :]])
            self.anchors_local = np.vstack([self.anchors_local, vl[None, :]])

    def fit_map(self):
        # No-op for identity map baseline
        pass

    # KPI: round-trip distortion (identity => 0 if anchors match exactly)
    def kpi_round_trip(self) -> float:
        if self.anchors_global.shape[0] == 0:
            return 0.0
        X = self.anchors_global
        X2 = self.to_global(self.to_local(X))
        return float(np.mean(np.linalg.norm(X2 - X, axis=1)))

    # Capabilities
    def set_capabilities(self, key: str, caps: List[str]):
        self.kv_caps[key] = list(caps)

    def can_access(self, key: str, cap: str) -> bool:
        return cap in self.kv_caps.get(key, [])

    def add_memory_guarded(self, key: str, value: Any, required_cap: str):
        if not self.can_access(key, required_cap):
            raise PermissionError(f'missing capability: {required_cap} for key {key}')
        self.kv_delta[key] = value

    # Templates
    def init_from_template(self, template: 'PerDatumLattice'):
        self.rank = template.rank
        self.template_id = template.id
        self.anchors_global = template.anchors_global.copy()
        self.anchors_local = template.anchors_local.copy()
