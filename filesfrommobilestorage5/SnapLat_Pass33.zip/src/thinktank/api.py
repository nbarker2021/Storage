from __future__ import annotations
from typing import Any, Dict, List
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH
from mannequin.api import get_sentinel

@dataclass
class CritiqueResult:
    steps: List[Dict[str, Any]]
    score: float
    notes: List[str]

class ThinkTank:
    """Panel-driven critique (sandbox). Deterministic heuristics, Trails-covered."""
    def __init__(self, panel: List[str] | None = None) -> None:
        self.panel = list(panel or ["mdhg","w5h","beacons","archivist","porter"])  # default panel names

    def critique(self, *, findings: List[str], evidence: Dict[str, float] | None = None, subject_snap_id: str | None = None) -> CritiqueResult:
        tid = trails.begin_trail({
            "op": "thinktank.critique",
            "module": __name__,
            "policy_hash": POLICY_HASH,
            "payload": {"panel": self.panel, "findings": findings[:5]}
        })
        try:
            sentinel = get_sentinel()
            if not sentinel.allow("thinktank.critique", {"panel": self.panel, "n_findings": len(findings)}):
                trails.append_event(tid, {"op":"thinktank.denied","module":__name__,"payload":{}})
                raise PermissionError("Safe-Cube denied thinktank.critique")

            ev = dict(evidence or {})
            # Deterministic scoring heuristic
            w_corr = float(ev.get("corroboration", 0.0))
            w_neg  = float(ev.get("neg_conflict", 0.0))
            base_score = max(0.0, min(1.0, 0.5 + 0.2*w_corr - 0.3*w_neg))

            # Step synthesis (order deterministic)
            steps: List[Dict[str, Any]] = []
            # Always confirm space bounds before heavy ops
            steps.append({"op":"mdhg.to_points", "why":"seed points from universe"})
                try:
                    from agrm.space.api import get_default_universe
                    u = get_default_universe()
                    if u and getattr(u, "name", None):
                        for s in steps:
                            s.setdefault("universe_ref", u.name)
                except Exception:
                    pass
            steps.append({"op":"mdhg.to_graph", "why":"structure edges", "quotas": {"edges": 8}})
            steps.append({"op":"mdhg.promotion_breakdown", "why":"score candidates"})
            # If negatives high, route to E-DBSU triage; else propose archivist contract
            if w_neg > 0.5:
                steps.append({"op":"edbsu.triage", "why":"neg conflicts present", "signals": ev})
            else:
                steps.append({"op":"archivist.contract", "why":"compress current reasoning"})
            # Handoff suggestion to DTT/Assembly (dry-run), via Porter
            steps.append({"op":"porter.deliver", "to":"dtt.harness", "why":"dry-run proposals"})
                # Snap-ID stamping (chain-of-custody)
                if subject_snap_id:
                    for s in steps:
                        s.setdefault("snap_id", subject_snap_id)


            notes = []
            if w_neg > 0.5: notes.append("High neg_conflict: prioritize E-DBSU")
            if w_corr >= 1.0: notes.append("Corroboration present: safe to attempt contract")

            out = CritiqueResult(steps=steps, score=base_score, notes=notes)
            trails.append_event(tid, {"op":"thinktank.proposed","module":__name__,"payload":{"steps": len(steps), "score": base_score}})
            return out
        finally:
            trails.finalize(tid, {"op":"thinktank.done","module":__name__})

# Module-level singleton accessor (optional)
_TT = ThinkTank()
def get_panel() -> ThinkTank:
    return _TT
