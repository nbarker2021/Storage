
from __future__ import annotations
import importlib
import json
from dataclasses import dataclass
from typing import Any, Tuple, Optional, Dict
import numpy as np

from .config import MODE, LEGACY_HINT, SNAP_COMPARE, SNAP_KIND

def _try_import(module: str):
    try:
        return importlib.import_module(module)
    except Exception:
        return None

def _import_v14():
    mod_roots = _try_import("lattice_ai.geometry.e8_roots")
    mod_geo = _try_import("lattice_ai.geometry.e8")
    return mod_roots, mod_geo

def _import_legacy():
    # optional hint for non-standard package path
    if LEGACY_HINT:
        try:
            import sys
            if LEGACY_HINT not in sys.path:
                sys.path.insert(0, LEGACY_HINT)
        except Exception:
            pass
    # Try known legacy paths
    candidates = [
        ("lattice_system_base_v14.lattice_ai.geometry.e8_roots", "lattice_system_base_v14.lattice_ai.geometry.e8"),
        ("lattice_system_base_v12.lattice_system_base_v12.lattice_ai.geometry.e8_roots", "lattice_system_base_v12.lattice_system_base_v12.lattice_ai.geometry.e8"),
        ("lattice_system_base_v10.lattice_system_base_v10.lattice_ai.geometry.e8_roots", "lattice_system_base_v10.lattice_system_base_v10.lattice_ai.geometry.e8"),
    ]
    for r, g in candidates:
        mr = _try_import(r)
        mg = _try_import(g)
        if mr and mg:
            return mr, mg
    return None, None

@dataclass
class E8APIs:
    roots_mod: Any
    geo_mod: Any

    def generate_roots(self) -> np.ndarray:
        return self.roots_mod.generate_e8_roots()

    def simple_roots(self) -> np.ndarray:
        return self.roots_mod.standard_simple_roots()

    def build(self):
        return self.roots_mod.E8.build()

    def reflect(self, V: np.ndarray, r: np.ndarray) -> np.ndarray:
        g = self.geo_mod.E8Geometry()
        return g.reflect(V, r)

def load_api_set(kind: str) -> Optional[E8APIs]:
    if kind == "v14":
        r, g = _import_v14()
    else:
        r, g = _import_legacy()
    if r is None or g is None:
        return None
    return E8APIs(r, g)

def _roughly_equal_roots(A: np.ndarray, B: np.ndarray, tol: float = 1e-6) -> bool:
    if A.shape != B.shape:
        return False
    # Compare sorted rows for approximate equality
    Ax = np.sort(A.round(6), axis=0)
    Bx = np.sort(B.round(6), axis=0)
    return np.allclose(Ax, Bx, atol=tol)

def _neighbor_degrees(e8_obj) -> np.ndarray:
    R, nbrs = e8_obj.neighbor_graph()
    return np.array([len(n) for n in nbrs], dtype=int)

def compare_sets(v14: E8APIs, legacy: E8APIs) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    R14 = v14.generate_roots()
    RL = legacy.generate_roots()
    out["roots_same_shape"] = tuple(R14.shape) == tuple(RL.shape)
    out["roots_approx_equal"] = _roughly_equal_roots(R14, RL)
    out["root_norms_v14_mean"] = float(np.mean(np.sum(R14*R14, axis=1)))
    out["root_norms_legacy_mean"] = float(np.mean(np.sum(RL*RL, axis=1)))

    e14 = v14.build()
    el = legacy.build()
    deg14 = _neighbor_degrees(e14)
    degl = _neighbor_degrees(el)
    out["deg_same_len"] = len(deg14) == len(degl)
    out["deg_mean_v14"] = float(np.mean(deg14))
    out["deg_mean_legacy"] = float(np.mean(degl))
    out["deg_dist_close"] = abs(out["deg_mean_v14"] - out["deg_mean_legacy"]) < 1e-3

    # Reflection involution check on a small sample
    r0 = R14[0]
    V = R14[:5]
    V_ref14 = v14.reflect(V, r0)
    V_back14 = v14.reflect(V_ref14, r0)
    out["reflect_involution_v14"] = bool(np.allclose(V, V_back14))

    r0L = RL[0]
    VL = RL[:5]
    V_refL = legacy.reflect(VL, r0L)
    V_backL = legacy.reflect(V_refL, r0L)
    out["reflect_involution_legacy"] = bool(np.allclose(VL, V_backL))

    return out

def load_dual() -> Tuple[E8APIs, Optional[E8APIs], Optional[Dict[str, Any]]]:
    v14 = load_api_set("v14")
    if v14 is None:
        raise ImportError("Failed to import v14 E8 geometry.")
    legacy = None
    report = None
    if MODE == "legacy":
        legacy = load_api_set("legacy")
        if legacy is None:
            raise ImportError("Failed to import legacy E8 geometry.")
        return legacy, None, None
    if MODE == "shadow":
        legacy = load_api_set("legacy")
        if legacy:
            report = compare_sets(v14, legacy)
    return v14, legacy, report

def maybe_emit_snap(report: Dict[str, Any], axes: Dict[str, Any], e8_obj: Optional[Dict[str, Any]] = None) -> None:
    if not SNAP_COMPARE or not report:
        return
    try:
        from e8snap.snap_writer import write_manifest, now_iso
        manifest = {
            "schema_version": "2.0",
            "snap_id": "compare:e8-dual-shadow",
            "created_at": now_iso(),
            "e8": e8_obj or {"version":"0.1","coords":[1,0,0,0,0,0,0,0],
                             "root_loc":{"nearest_roots":[{"index":0,"inner_product":1.0}],
                                         "reflections":[],"adjacency_rule":"inner_product_eq_1"},
                             "axes": axes},
            "axes": axes,
            "kind": SNAP_KIND,
            "metrics": report,
            "provenance": {"code_version": axes.get("version_container","v14"),
                           "modules":["lattice_ai.bridge.dual_stack"]},
            "payload": {"format":"json","location":"snaps/reports/e8_dual_shadow.json","size_bytes":0,"secure":True},
        }
        out = pathlib.Path("snaps/reports/e8_dual_shadow.json")
        out.parent.mkdir(parents=True, exist_ok=True)
        write_manifest(manifest, out)
    except Exception:
        # Best-effort only
        pass
