from __future__ import annotations
from typing import Any, Dict, List, Tuple
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class Ranked:
    items: List[Tuple[str, float]]  # (id, score)

def pool_candidates(cands: Dict[str, float]) -> Ranked:
    tid = trails.begin_trail({"op":"wave.pool","module":__name__,"policy_hash":POLICY_HASH})
    try:
        ranked = sorted((cands or {}).items(), key=lambda kv: kv[1], reverse=True)
        trails.append_event(tid, {"op":"wave.ranked","module":__name__,"payload":{"n":len(ranked)}})
        return Ranked(items=ranked)
    finally:
        trails.finalize(tid, {"op":"wave.done","module":__name__})
