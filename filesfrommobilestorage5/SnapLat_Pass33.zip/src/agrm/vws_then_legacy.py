import argparse, json, numpy as np
from core.agrm.vector_sketch import vector_warm_start
from core.agrm.solver_legacy import LegacyAGRMSolver

def make_points(n, seed):
    rng = np.random.default_rng(seed)
    return rng.random((n, 2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--n", type=int, default=150)
    args = ap.parse_args()
    pts = make_points(args.n, args.seed)
    vws = vector_warm_start(pts, k=8, seeds=8)
    print("[VWS] greedy_best_len:", vws.greedy_best_len, "knn_edges:", len(vws.knn_edges))
    solver = LegacyAGRMSolver(config={})
    try:
        res = solver.solve(pts)
        print("[LEGACY RUN] ok:", type(res))
    except NotImplementedError as e:
        print("[LEGACY RUN] legacy controller not fully implemented:", e)
    except Exception as e:
        print("[LEGACY RUN] error:", e)

if __name__ == "__main__":
    main()
