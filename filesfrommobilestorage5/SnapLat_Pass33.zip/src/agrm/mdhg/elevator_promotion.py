
import time
from typing import Dict, Any, Iterable, Tuple
from agrm.snap.ops_center import SnapOpsCenter
from agrm.utils.repo_ops import list_prefix
from agrm.utils.text import toks3, jaccard

def _iter_elevator_events(repo, universe: str):
    pref = f"mdhg_event::{universe}::elevator::"
    keys = list_prefix(repo, pref)
    events = []
    for k in keys:
        try:
            rec = repo.load(k)
            if rec.get("meta",{}).get("family")=="mdhg_event":
                events.append((k, rec))
        except Exception:
            pass
    return events

def _parse_ts_from_mdhg_snap_id(snap_id: str | None) -> float | None:
    if not snap_id: return None
    try:
        # formats: mdhg::<universe>::<ts> or mdhg::<universe>::ephemeral::<ts>
        parts = str(snap_id).split("::")
        ts = int(parts[-1])
        return float(ts)
    except Exception:
        return None

def _family_diversity(roomA: Dict[str,Any], roomB: Dict[str,Any]) -> float:
    fa, fb = roomA.get("family"), roomB.get("family")
    if not fa or not fb: return 0.0
    return 1.0 if fa != fb else 0.25  # prefer cross-family links

def _type_diversity(roomA: Dict[str,Any], roomB: Dict[str,Any]) -> float:
    ta, tb = roomA.get("type"), roomB.get("type")
    if not ta or not tb: return 0.0
    return 0.6 if ta != tb else 0.2

def _glyph_inverse_bonus(invA: str | None, invB: str | None) -> float:
    # simple: if inverse tokens share low overlap with originals, bonus; else small
    A = toks3(invA); B = toks3(invB)
    if not A and not B: return 0.0
    overlap = jaccard(A, B)
    return 0.4 * (1.0 - overlap)

def _recency_weight(age_seconds: float, half_life_hours: float = 6.0) -> float:
    hl = max(0.5, float(half_life_hours))
    return 0.5 ** (max(0.0, age_seconds) / (hl*3600.0))

def _composite_score(ev_meta: Dict[str,Any], content: Dict[str,Any], now: float) -> float:
    base = float(ev_meta.get("tags",{}).get("score", 0.0))
    snap_ts = _parse_ts_from_mdhg_snap_id(ev_meta.get("tags",{}).get("mdhg_snap") or content.get("mdhg_snap"))
    age = (now - snap_ts) if snap_ts else 0.0
    recency = _recency_weight(age, half_life_hours=6.0)
    fam = _family_diversity(content.get("roomA",{}), content.get("roomB",{}))
    typ = _type_diversity(content.get("roomA",{}), content.get("roomB",{}))
    inv = _glyph_inverse_bonus(content.get("inverseA"), content.get("inverseB"))
    # weights can be tuned
    w_base, w_rec, w_fam, w_typ, w_inv = 0.6, 0.2, 0.1, 0.05, 0.05
    return w_base*base + w_rec*recency + w_fam*fam + w_typ*typ + w_inv*inv

def promote_elevators(repo, um, universe: str, *, threshold: float=1.0, compat_policy: Dict[str,Any]=None) -> Dict[str,Any]:
    ops = SnapOpsCenter(elevator_threshold=threshold, compat_policy=compat_policy or {})
    events = _iter_elevator_events(repo, universe)
    promoted, rejected = 0, 0
    results = []
    # per-family/type breakdowns
    fam_prom, fam_rej = {}, {}
    type_prom, type_rej = {}, {}

    now = time.time()
    for k, ev in events:
        cand = ev.get("content", {})
        # enrich with composite score
        comp = _composite_score(ev.get("meta", {}), cand, now)
        # stash composite score for decision
        meta_with_comp = dict(ev.get("meta", {}))
        meta_with_comp.setdefault("tags", {})["score_composite"] = comp
        ev["meta"] = meta_with_comp
        dec = ops.review_elevator({**cand, "score": comp})
        fa = (cand.get("roomA") or {}).get("family"); fb = (cand.get("roomB") or {}).get("family")
        ta = (cand.get("roomA") or {}).get("type");   tb = (cand.get("roomB") or {}).get("type")
        fam_pair = tuple(sorted([fa, fb])); type_pair = tuple(sorted([ta, tb]))
        if dec.promoted:
            promoted += 1
            rid = f"result::elevator::{universe}::{promoted}"
            repo.save(rid, {"meta":{"snap_id": rid, "family":"result","type":"mdhg_elevator","tags":{"universe":universe,"score_composite":comp}},
                            "content": cand})
            results.append(rid)
            try:
                u = um.get_universe(universe)
                ov = u.overlays.get("elevators", [])
                ov.append(rid); u.overlays["elevators"] = sorted(set(ov)); um.save_universe(u)
            except Exception: pass
            fam_prom[fam_pair] = fam_prom.get(fam_pair, 0) + 1
            type_prom[type_pair] = type_prom.get(type_pair, 0) + 1
        else:
            rejected += 1
            fam_rej[fam_pair] = fam_rej.get(fam_pair, 0) + 1
            type_rej[type_pair] = type_rej.get(type_pair, 0) + 1

    breakdown = {
        "family": {"promoted": {str(k): v for k,v in fam_prom.items()}, "rejected": {str(k): v for k,v in fam_rej.items()}},
        "type":   {"promoted": {str(k): v for k,v in type_prom.items()}, "rejected": {str(k): v for k,v in type_rej.items()}},
    }
    return {"promoted": promoted, "rejected": rejected, "results": results, "breakdown": breakdown}
