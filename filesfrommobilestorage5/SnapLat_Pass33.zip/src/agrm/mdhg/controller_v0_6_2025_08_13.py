
import numpy as np
from .statebus_v0_4_2025_08_13 import StateBus_v0_4_2025_08_13 as Bus
from .navigator_v0_4_2025_08_13 import NavigatorGR_v0_4_2025_08_13 as Nav
from .vws_bridge_v0_1_2025_08_13 import seed_vws_from_mdhg_v0_1_2025_08_13 as seed
from .mdhg_v0_2_2025_08_13 import MDHG_v0_2_2025_08_13 as MDHG
from .inlinehash_v0_3_2025_08_13 import InlineHasher_v0_3_2025_08_13 as InlineH
from .vws_bridge_inline_v0_3_2025_08_13 import seed_vws_from_inline_v0_3_2025_08_13 as seed_inline
from .dualwrite_v0_1_2025_08_13 import DualWriteQueue_v0_1_2025_08_13 as Dual
from ..snap.snap_v0_1_2025_08_13 import create_snap
class AGRMController_v0_6_2025_08_13:
    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.bus = Bus()
        self.navigator = Nav(self.cfg, self.bus)
        self.dual = Dual()
        self.mdhg = None
        self.inline = None
    def _build_mdhg(self, points):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        m = MDHG(dim=points.shape[1], decay_lambda=self.cfg.get("mdhg_decay", 0.01))
        n = points.shape[0]
        center = points.mean(axis=0); vecs = points - center
        angles = _np.arctan2(vecs[:,1], vecs[:,0])
        num_floors = self.cfg.get("num_sectors", 32)
        sec_edges = _np.linspace(-_np.pi, _np.pi, num_floors+1)
        sectors = _np.digitize(angles, sec_edges) - 1
        for i in range(n):
            meta = {"building": self.cfg.get("building","default"), "floor": f"F{sectors[i]}", "room": "R0"}
            m.insert(i, points[i], meta)
        for i in range(n): m.bump_heat([i])
        return m
    def solve(self, points, max_ticks=8):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        mode = self.cfg.get('hash_mode','auto')
        use_inline = False
        if mode=='inline': use_inline=True
        elif mode=='mdhg': use_inline=False
        else:
            # auto: prefer inline for moderate dims/size, escalate if needed later
            use_inline = (points.shape[1] <= int(self.cfg.get('inline_dim_thresh',16)) and points.shape[0] <= int(self.cfg.get('inline_n_thresh',5000)))
        if use_inline:
            self.inline = self._build_inline(points)
            self.bus.vws = seed_inline(self.inline, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128))
        else:
            self.mdhg = self._build_mdhg(points)
            self.bus.vws = seed(self.mdhg, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128))
        _ = self.navigator.assign_shells_and_sectors(points)
        chosen_all = []
        escalated = False
        for _ in range(max_ticks):
            chosen_all.extend(self.navigator.sweep_step(points))
            # --- AUTO-ESCALATE CHECKS ---
            if self.cfg.get("hash_mode","auto")=="auto" and self.inline is not None and not escalated:
                ticks = max(1, int(self.bus.stats.get("ticks",1)))
                steps = max(1, int(self.bus.stats.get("steps",1)))
                thrash = float(self.bus.stats.get("thrash",0.0))
                coverage = float(self.bus.stats.get("coverage_gain",0.0))
                thrash_per_step = thrash/steps
                coverage_rate = coverage/ticks
                inline_stats = self.inline.stats()
                mean_bucket = inline_stats.get("mean_bucket_size", 0.0)
                # thresholds
                tau = float(self.cfg.get("auto_thrash_tau", 0.8))
                kappa = float(self.cfg.get("auto_coverage_kappa", 0.15))
                beta = float(self.cfg.get("auto_bucket_beta", 8.0))
                need_escalate = (thrash_per_step >= tau) or (coverage_rate <= kappa) or (mean_bucket >= beta)
                if need_escalate:
                    # Build MDHG and transfer dual state
                    self.mdhg = self._build_mdhg(points)
                    # apply dual edges/heat
                    try:
                        self.dual.flush_to_mdhg(self.mdhg)
                    except Exception:
                        pass
                    # seed VWS from MDHG and flip path
                    self.bus.vws = seed(self.mdhg, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128))
                    self.inline = None
                    escalated = True
        # --- Promotion / Staging policy ---
        policy = self.cfg.get("promotion_policy","sample_full")  # "fast_allowed" | "sample_full" | "must_pass_full"
        mode = self.cfg.get("hash_mode","auto")
        staged = (mode in ("auto","inline") and self.inline is not None)
        info = {"staged": staged, "policy": policy}
        brief = self._metrics_brief()
        info["fast_metrics"] = brief
        # auto-escalation SNAP (if we switched to MDHG during run)
        if self.cfg.get("hash_mode","auto")=="auto" and self.inline is None and self.mdhg is not None:
            try:
                create_snap({
                    "universes":["work.fast"],
                    "n_level": 1.0,
                    "provenance":{"event":"auto_escalate","thresholds":{
                        "tau": float(self.cfg.get("auto_thrash_tau",0.8)),
                        "kappa": float(self.cfg.get("auto_coverage_kappa",0.15)),
                        "beta": float(self.cfg.get("auto_bucket_beta",8.0))
                    }},
                    "meta":{"pre_metrics": brief}
                }, kind="auto_escalate")
            except Exception:
                pass
        decision = "canonical"
        if staged:
            if policy=="fast_allowed":
                decision = "promoted"
            else:
                sample = self._promotion_check(points, sample_ticks=int(self.cfg.get("promotion_sample_ticks",3)))
                info["sample_metrics"] = sample
                # Gate rules
                thrash_ok = brief["thrash_per_step"] <= float(self.cfg.get("promote_thrash_tau", 0.8))
                cover_ok  = brief["coverage_rate"]    >= float(self.cfg.get("promote_coverage_kappa", 0.15))
                # Compare with sample (MDHG) for sanity
                delta_cover = sample["coverage_rate"] - brief["coverage_rate"]
                delta_thrash= brief["thrash_per_step"] - sample["thrash_per_step"]
                info["delta_cover"] = delta_cover; info["delta_thrash"] = delta_thrash
                if policy=="must_pass_full":
                    decision = "promoted" if (thrash_ok and cover_ok and delta_cover<=0.05 and delta_thrash>=-0.05) else "quarantined"
                else:
                    decision = "promoted" if (thrash_ok and cover_ok) else "quarantined"
            try:
                create_snap({
                    "universes":["work.fast"],
                    "n_level": 1.0,
                    "provenance":{"event":"promotion_decision","policy":policy},
                    "meta":{"decision": decision, "info": info}
                }, kind="promotion")
            except Exception:
                pass
        return {"stats": self.bus.stats, "chosen": chosen_all, "meta": self.bus.meta, "verdict": decision, "info": info}


    def _build_inline(self, points):
        import numpy as _np
        points=_np.asarray(points,dtype=float)
        ih = InlineH(dim=points.shape[1], grid=float(self.cfg.get("inline_grid", 32.0)), proj_dims=int(self.cfg.get("inline_proj_dims", 8)), seed=int(self.cfg.get("inline_seed", 17)))
        n = points.shape[0]
        center = points.mean(axis=0); vecs = points - center
        angles = _np.arctan2(vecs[:,1], vecs[:,0])
        num_floors = self.cfg.get("num_sectors", 32)
        sec_edges = _np.linspace(-_np.pi, _np.pi, num_floors+1)
        sectors = _np.digitize(angles, sec_edges) - 1
        for i in range(n):
            meta = {"building": self.cfg.get("building","default"), "floor": f"F{sectors[i]}", "room": "R0"}
            ih.insert(i, points[i], meta)
        for i in range(n): ih.bump_heat([i])
        # prime dual-write with current inline state
        dual_export = ih.export_dualwrite()
        for i,h in dual_export['heat'].items(): self.dual.heat[i]+=h
        for (a,b,w) in dual_export['edges']: self.dual.record_edge_weight(a,b,w)
        return ih

    def _metrics_brief(self):
        ticks = max(1, int(self.bus.stats.get("ticks",1)))
        steps = max(1, int(self.bus.stats.get("steps",1)))
        thrash = float(self.bus.stats.get("thrash",0.0))
        coverage = float(self.bus.stats.get("coverage_gain",0.0))
        return {
            "thrash_per_step": thrash/steps,
            "coverage_rate": coverage/ticks,
            "sectors_visited": int(self.bus.stats.get("sectors_visited",0)),
            "ticks": ticks, "steps":steps
        }

    def _promotion_check(self, points, sample_ticks:int=3):
        # Run a tiny MDHG solve to compare core metrics
        old_bus = self.bus; old_nav = self.navigator; old_inline = self.inline; old_mdhg = self.mdhg
        try:
            from .statebus_v0_4_2025_08_13 import StateBus_v0_4_2025_08_13 as Bus
            from .navigator_v0_4_2025_08_13 import NavigatorGR_v0_4_2025_08_13 as Nav
            from .vws_bridge_v0_1_2025_08_13 import seed_vws_from_mdhg_v0_1_2025_08_13 as seed
            from .mdhg_v0_2_2025_08_13 import MDHG_v0_2_2025_08_13 as MDHG
            self.bus = Bus(); self.navigator = Nav(self.cfg, self.bus)
            m = self._build_mdhg(points); self.mdhg = m
            self.bus.vws = seed(m, points, building=self.cfg.get('building','default'), k_each=self.cfg.get('vws_k',5), top_edges=self.cfg.get('vws_edges',128))
            _ = self.navigator.assign_shells_and_sectors(points)
            for _ in range(sample_ticks):
                _ = self.navigator.sweep_step(points)
            sample_metrics = self._metrics_brief()
            return sample_metrics
        finally:
            self.bus = old_bus; self.navigator = old_nav; self.inline = old_inline; self.mdhg = old_mdhg
