from __future__ import annotations
from typing import Any, Dict, List, Tuple
from dataclasses import dataclass
from trails import api as trails
from ops.policy.api import POLICY_HASH

@dataclass
class Points:
    coords: List[Tuple[float, float]]

@dataclass
class Graph:
    points: Points
    edges: List[Tuple[int, int]]

def _gen_points(seed: int, n: int = 5) -> List[Tuple[float, float]]:
    # Simple LCG-like deterministic generator (no external deps)
    x = seed or 1
    out = []
    for i in range(max(1, n)):
        x = (1103515245 * x + 12345) % (2**31)
        # map to [0,1)
        a = (x % 9973) / 9973.0
        b = (x % 7919) / 7919.0
        out.append((a, b))
    return out

def to_points(universe: Dict[str, Any] | None = None, *, seed: int | None = None) -> Points:
    tid = trails.begin_trail({"op":"mdhg.to_points","module":__name__,"policy_hash":POLICY_HASH, "payload": {"seed": seed}})
    try:
        # derive seed either from explicit or hash of universe keys
        s = int(seed) if seed is not None else (len((universe or {}).keys()) or 1)
        pts = Points(coords=_gen_points(s, n=5))
        trails.append_event(tid, {"op":"mdhg.points","module":__name__,"payload":{"n": len(pts.coords)}})
        return pts
    finally:
        trails.finalize(tid, {"op":"mdhg.to_points.done","module":__name__})

def to_graph(points: Points, *, quotas: Dict[str, int] | None = None) -> Graph:
    tid = trails.begin_trail({"op":"mdhg.to_graph","module":__name__,"policy_hash":POLICY_HASH, "payload": {"n": len(points.coords)}})
    try:
        q = dict(quotas or {})
        equota = int(q.get("edges", 8))
        # connect sequential neighbors up to quota (deterministic)
        edges: List[Tuple[int,int]] = []
        n = len(points.coords)
        for i in range(n):
            if len(edges) >= equota: break
            j = (i+1) % n
            if i != j:
                edges.append((i, j))
        trails.append_event(tid, {"op":"mdhg.graph","module":__name__,"payload":{"edges": len(edges)}})
        return Graph(points=points, edges=edges)
    finally:
        trails.finalize(tid, {"op":"mdhg.to_graph.done","module":__name__})


@dataclass
class PromotionBreakdown:
    scores: Dict[int, float]   # node index -> score
    ranking: List[int]         # indices sorted by score desc (stable)

def promotion_breakdown(g: Graph) -> PromotionBreakdown:
    tid = trails.begin_trail({"op":"mdhg.promotion_breakdown","module":__name__,"policy_hash":POLICY_HASH})
    try:
        n = len(g.points.coords)
        # degree-based score (sequential neighbor edges) + tiny tie-breaker on coord hash
        deg = {i:0 for i in range(n)}
        for (i,j) in g.edges:
            deg[i] = deg.get(i,0)+1
            deg[j] = deg.get(j,0)+1
        def tie(i: int) -> float:
            x,y = g.points.coords[i]
            return ((int(x*10000)*31 + int(y*10000)*17) % 97) / 100000.0
        scores = {i: float(deg.get(i,0)) + tie(i) for i in range(n)}
        ranking = sorted(range(n), key=lambda i: (-scores[i], i))
        trails.append_event(tid, {"op":"mdhg.promotion_breakdown.done","module":__name__,"payload":{"n": n}})
        return PromotionBreakdown(scores=scores, ranking=ranking)
    finally:
        trails.finalize(tid, {"op":"mdhg.promotion_breakdown.finalize","module":__name__})
