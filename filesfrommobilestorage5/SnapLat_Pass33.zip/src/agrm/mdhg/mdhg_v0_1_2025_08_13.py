
import numpy as np, json, math
from collections import defaultdict

class MDHG_v0_1_2025_08_13:
    """Multi‑Dimensional Hamiltonian Golden (MVP): hot & edge maps with decay and kNN (naive exact)."""
    def __init__(self, dim: int, decay_lambda: float = 0.01):
        self.dim = dim
        self.decay_lambda = decay_lambda
        self.vecs = {}
        self.heat = defaultdict(float)
        self.edge = defaultdict(float)  # co-hit frequency proxy
        self._order = []

    def insert(self, id: int, vec):
        v = np.asarray(vec, dtype=float).reshape(-1)
        assert v.shape[0] == self.dim
        self.vecs[id] = v
        if id not in self._order: self._order.append(id)
        return id

    def bump_heat(self, ids):
        ids = list(ids)
        for i in ids:
            self.heat[i] += 1.0
        for a in ids:
            for b in ids:
                if a<b:
                    self.edge[(a,b)] += 1.0

    def decay(self):
        for k in list(self.heat.keys()):
            self.heat[k] *= (1.0 - self.decay_lambda)
            if self.heat[k] < 1e-6: del self.heat[k]
        for k in list(self.edge.keys()):
            self.edge[k] *= (1.0 - self.decay_lambda)
            if self.edge[k] < 1e-6: del self.edge[k]

    def k_nn(self, qvec, k=8):
        if not self.vecs: return []
        q = np.asarray(qvec, dtype=float).reshape(-1)
        dists = []
        for i,v in self.vecs.items():
            d = float(np.linalg.norm(q - v))
            dists.append((d,i))
        dists.sort(key=lambda x:x[0])
        return [i for _,i in dists[:k]]

    def edges(self, topk=64):
        items = sorted(self.edge.items(), key=lambda kv: kv[1], reverse=True)
        return items[:topk]

    def snapshot(self) -> dict:
        return {
            "dim": self.dim,
            "decay_lambda": self.decay_lambda,
            "vecs": {i: v.tolist() for i,v in self.vecs.items()},
            "heat": dict(self.heat),
            "edge": {"{}-{}".format(a,b): w for (a,b),w in self.edge.items()}
        }

    @staticmethod
    def restore(js: dict):
        m = MDHG_v0_1_2025_08_13(js["dim"], js["decay_lambda"])
        for i, v in js["vecs"].items():
            m.insert(int(i), np.array(v, dtype=float))
        for i, val in js["heat"].items():
            m.heat[int(i)] = float(val)
        for k, w in js["edge"].items():
            a,b = map(int, k.split("-"))
            m.edge[(a,b)] = float(w)
        return m
