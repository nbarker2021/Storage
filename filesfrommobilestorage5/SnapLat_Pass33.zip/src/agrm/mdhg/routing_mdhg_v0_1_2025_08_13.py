
from .contracts_v0_1_2025_08_13 import AgentSpec_v0_1_2025_08_13, Task_v0_1_2025_08_13
def score_agent_v0_1_2025_08_13(spec: AgentSpec_v0_1_2025_08_13, task: Task_v0_1_2025_08_13) -> float:
    hot = set(task.constraints.get("hot_tags", []))
    if not hot: return 0.0
    tags = set(spec.tags or [])
    return len(hot & tags) / max(1, len(hot))
def pick_agent_by_mdhg_v0_1_2025_08_13(cands, task: Task_v0_1_2025_08_13):
    if not cands: return None
    scored = [ (score_agent_v0_1_2025_08_13(s, task), s) for s in cands ]
    scored.sort(key=lambda t: t[0], reverse=True)
    return scored[0][1]
