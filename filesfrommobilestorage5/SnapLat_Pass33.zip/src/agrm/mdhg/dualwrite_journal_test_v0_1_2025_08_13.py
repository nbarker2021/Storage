
import sys, pathlib, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.dualwrite_journal_v0_1_2025_08_13 import DualWriteJournal_v0_1_2025_08_13 as DWJ
from core.agrm.mdhg_v0_2_2025_08_13 import MDHG_v0_2_2025_08_13 as MDHG

dwj = DWJ(dir_path="snapshots/journal_test")
# Write two batches
dwj.append({"1":2.0,"2":1.0}, [(1,2,3.0)])
dwj.append({"2":2.5}, [(2,3,1.0),(2,4,2.0)])

# Replay into a fresh MDHG
m = MDHG(dim=2)
applied = dwj.replay_into_mdhg(m, since_ts=0.0)
print("Applied records:", applied)
print("Heat keys:", sorted(list(m.heat.keys())))
print("Edge count:", len(m.edge))
