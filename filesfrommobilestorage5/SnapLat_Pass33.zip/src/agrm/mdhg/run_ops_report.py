
#!/usr/bin/env python3
import json, argparse, time
from importlib import import_module
from agrm.orchestrator.freshstart import fresh_start
from agrm.orchestrator.iterate import run_iterations
from agrm.config.presets import thresholds_for
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--universe", action="append", required=True)
    ap.add_argument("--geom", action="append", required=True)
    ap.add_argument("--N", type=int, action="append", required=True)
    ap.add_argument("--persist", action="append", required=True)  # "true"/"false"
    ap.add_argument("--min-promoted", type=int, default=8)
    ap.add_argument("--max-iters", type=int, default=4)
    ns = ap.parse_args()
    repo = import_module("env.repo").repo
    um   = import_module("env.um").um
    ops_rows = []
    for name, geom, N, persist_s in zip(ns.universe, ns.geom, ns.N, ns.persist):
        N = int(N); persist = (persist_s.lower() == "true")
        # synth data via env.data factory
        d = import_module("env.data")
        points, metas = d.make_points(geom, N), d.make_metas(N, bias_family=None)
        fresh_start(repo, um, name, wipe=True)
        thr = thresholds_for(geom)
        cfg = {"use_sweeps_full": True, "arms": 12, "rounds": 3,
               "mdhg":{"persist":persist,"promote_elevators":True,"elevator_score_min":thr["score"],
                       "room_capacity":32,"max_rooms_per_floor":10,"heat_split_threshold":40,"decay_half_life_hours":12.0,
                       "elevator_cross_room_threshold":thr["cross_room"],"elevator_cross_floor_threshold":thr["cross_floor"],
                       "split_policy":{"family_deny":["fiction"]}}}
        report = run_iterations(points, metas, repo=repo, um=um, base_cfg=cfg, universe=name, max_iters=ns.max_iters,
                                min_promoted=ns.min_promoted, stability_eps=0.05, promotion_threshold=thr["score"],
                                compat_policy={"family_deny":["fiction"]})
        final = report.iterations[-1]
        ops_rows.append({"universe": name, "geom": geom, "persist": persist,
                         "N": N, "iters": len(report.iterations), "delivered": report.delivered, "reason": report.reason,
                         "rooms": len(final.summary.get("mdhg",{}).get("rooms",[])),
                         "elevators_found": len(final.summary.get("mdhg",{}).get("elevators",[])),
                         "candidates_emitted": final.summary.get("telemetry",{}).get("candidates_emitted",0),
                         "promoted": final.promotion.get("promoted",0), "rejected": final.promotion.get("rejected",0)})
    rid = f"ops_report::{int(time.time())}"
    repo.save(rid, {"meta":{"snap_id": rid, "family":"report","type":"ops"},"content":{"rows": ops_rows}})
    print(json.dumps({"report_id": rid, "rows": ops_rows}, indent=2))
if __name__ == "__main__":
    main()
