
import sys, pathlib, numpy as np, json, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_6_2025_08_13 import AGRMController_v0_6_2025_08_13 as CTRL
from core.repo.archivist_v0_1_2025_08_13 import Archivist_v0_1_2025_08_13 as Archivist

rng = np.random.default_rng(3)
pts = rng.random((180,2))  # moderately sized; inline should be used first

arc = Archivist()
arc.add("work.fast", {"kind":"session","note":"staged universe test"})

ctrl = CTRL(cfg={
  "hash_mode":"auto",
  "num_sectors":32, "num_shells":8,
  # inline thresholds
  "inline_dim_thresh": 16, "inline_n_thresh": 5000,
  # auto escalation thresholds (keep generous so we often stay staged here)
  "auto_thrash_tau": 1.2, "auto_coverage_kappa": 0.10, "auto_bucket_beta": 12.0,
  # promotion policy
  "promotion_policy":"sample_full",  # try "must_pass_full" to be stricter
  "promotion_sample_ticks": 2,
  "promote_thrash_tau": 1.0,
  "promote_coverage_kappa": 0.10
})

res = ctrl.solve(pts, max_ticks=4)
print("Decision:", res["verdict"])
print("Staged?", res["info"]["staged"], "Policy:", res["info"]["policy"])
print("Fast metrics:", res["info"]["fast_metrics"])
if "sample_metrics" in res["info"]:
    print("Sample metrics:", res["info"]["sample_metrics"])
