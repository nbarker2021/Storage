
import sys, pathlib, time, json, math, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from core.agrm.controller_v0_4_2025_08_13 import AGRMController_v0_4_2025_08_13
from core.agrm.patching_v0_1_2025_08_13 import tour_length_v0_1_2025_08_13, patch_loop_v0_1_2025_08_13

def make_points(n, seed):
    rng = np.random.default_rng(seed)
    return rng.random((n, 2))

def build_naive_tour(points, chosen):
    n = points.shape[0]
    chosen_order = []
    seen = set()
    for c in chosen:
        if c not in seen:
            chosen_order.append(c)
            seen.add(c)
    remaining = [i for i in range(n) if i not in seen]
    if len(chosen_order) < 3:
        chosen_order = list(range(min(3,n)))
        remaining = [i for i in range(n) if i not in chosen_order]
    tour = chosen_order[:]
    for k in remaining:
        best_pos, best_delta = 0, float("inf")
        for idx in range(len(tour)):
            a, b = tour[idx], tour[(idx+1)%len(tour)]
            delta = float(np.linalg.norm(points[a]-points[k]) + np.linalg.norm(points[k]-points[b]) - np.linalg.norm(points[a]-points[b]))
            if delta < best_delta:
                best_delta, best_pos = delta, idx+1
        tour.insert(best_pos, k)
    return tour

def run_once(n=150, seed=11, cfg=None):
    pts = make_points(n, seed)
    ctrl = AGRMController_v0_4_2025_08_13(cfg=cfg or {"theta_open":0.5,"theta_close":0.2,"cooldown":1,"max_steps_per_arm":8,"num_sectors":32,"num_shells":8})
    res = ctrl.solve(pts, max_ticks=8)
    chosen = res["chosen"]
    sectors = res["meta"]["sectors"]
    # Build partial tour from chosen (unique order) and close it
    seen=set(); partial=[c for c in chosen if (not (c in seen) and not seen.add(c))]
    if len(partial)<3: partial=list(range(min(3, pts.shape[0])))
    L_partial = tour_length_v0_1_2025_08_13(pts, partial)

    # NO-PATCH: complete with greedy insertion
    tour_greedy = build_naive_tour(pts, chosen)
    L_greedy = tour_length_v0_1_2025_08_13(pts, tour_greedy)

    # PATCH: complete by patch loop (inserts unvisited nodes via SNI)
    tour_patch, stats = patch_loop_v0_1_2025_08_13(pts, partial, sectors, budget_edges=200, budget_iter=200)
    L_patch = stats["final_length"]

    return {"L_partial": float(L_partial), "L_greedy": float(L_greedy), "L_patch": float(L_patch),
             "patch_accepted": stats["accepted"], "patch_iters": stats["iters"],
             "patch_beats_greedy": float(L_greedy - L_patch)}
def main():
    seeds = [3,7,11,13,23]
    out = []
    for s in seeds:
        out.append(run_once(n=180, seed=s))
    print("RESULTS:", out)
    gain = sum(d["patch_beats_greedy"] for d in out)/len(out)
    succ = sum(1 for d in out if d["patch_beats_greedy"]>0)/len(out)
    print("AVG (greedy_length - patch_length):", gain)
    print("% seeds where patch < greedy:", succ)

if __name__ == "__main__":
    main()
