
from agrm.agrm.elevator_fastlane import ElevatorFastLane

def test_elevator_fastlane_threshold_and_family():
    efl = ElevatorFastLane(threshold=0.8, compat_policy={"family_deny":["fiction"]})
    cand_ok = {"score": 0.9, "roomA":{"family":"science"}, "roomB":{"family":"science"}}
    dec = efl.evaluate(cand_ok)
    assert dec.promoted
    cand_bad = {"score": 0.95, "roomA":{"family":"fiction"}, "roomB":{"family":"science"}}
    dec2 = efl.evaluate(cand_bad)
    assert not dec2.promoted and dec2.reason=="family_not_allowed"
