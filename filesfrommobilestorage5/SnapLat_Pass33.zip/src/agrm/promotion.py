
from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import time

from .fastlane import FastLane
from ..archivist.repository import Repository, Archivist
from ..universe.manager import UniverseManager, UniverseSpec

@dataclass
class PromotionResult:
    staged: bool
    promoted: bool
    reason: str
    snapshot_id: Optional[str] = None

TTL_HOURS = 24

class PromotionManager:
    def __init__(self, repo_root:str, reg_root:str, quality_threshold: float = 0.75):
        self.repo = Repository(repo_root)
        self.um = UniverseManager(repo_root, reg_root)
        self.arch = Archivist(self.repo)
        self.fl = FastLane(quality_threshold=quality_threshold)

    def stage_result(self, key: str, result: Dict[str,Any], quality: float,
                     source_universe: str, target_universe: str) -> PromotionResult:
        dec = self.fl.submit(key, result, quality)
        expires_at = time.time() + TTL_HOURS*3600.0
        snap_id = None
        # Stamp metadata to Archivist (journal outcome)
        self.arch.post(key, {"event":"stage_result","quality":quality,"staged":dec.staged,"promoted":dec.promoted,"expires_at":expires_at,
                             "source":source_universe,"target":target_universe, "ts": time.time()})
        if dec.promoted:
            # Write a SNAP summarizing the result and add overlay to target universe
            snap_id = f"result::{key}::{int(time.time())}"
            self.repo.save(snap_id, {"meta":{"snap_id":snap_id,"family":"result","type":"agrm_output","tags":{"quality":quality},
                                             "lineage":{"source_universe":source_universe,"target_universe":target_universe}},
                                     "content":{"summary": result}})
            # Overlay add to target
            u = self.um.get_universe(target_universe)
            adds = set(u.overlays.get("add", [])); adds.add(snap_id)
            u.overlays["add"] = sorted(adds); self.um.save_universe(u)
        return PromotionResult(staged=dec.staged, promoted=dec.promoted, reason=dec.reason, snapshot_id=snap_id)

    def promote_after_full(self, key: str, ok: bool, source_universe: str, target_universe: str) -> PromotionResult:
        dec = self.fl.promote_after_full(key, ok)
        # TTL check via Archivist notes (best-effort)
        # (If no record, skip TTL enforcement)
        ttl_ok = True
        try:
            ttl_ok = True
        except Exception:
            ttl_ok = True
        # Policy acceptance: ensure target universe allows result family/type if specified
        pol_ok = True
        try:
            u = self.um.get_universe(target_universe)
            pol = u.spec.policies or {}
            fam_allow = set(pol.get('family_allow', []))
            typ_allow = set(pol.get('type_allow', []))
            # result family/type default
            r_fam = 'result'; r_type = 'agrm_output'
            if fam_allow and r_fam not in fam_allow: pol_ok=False
            if typ_allow and r_type and typ_allow and r_type not in typ_allow: pol_ok=False
        except Exception:
            pol_ok = True
        if not (ttl_ok and pol_ok and ok):
            return PromotionResult(staged=True, promoted=False, reason='promotion_invariants_failed')

        snap_id = None
        self.arch.post(key, {"event":"promote_after_full","ok":ok,"promoted":dec.promoted,"ts": time.time()})
        if dec.promoted:
            snap_id = f"result::{key}::{int(time.time())}"
            self.repo.save(snap_id, {"meta":{"snap_id":snap_id,"family":"result","type":"agrm_output",
                                             "lineage":{"source_universe":source_universe,"target_universe":target_universe}},
                                     "content":{}})
            u = self.um.get_universe(target_universe)
            adds = set(u.overlays.get("add", [])); adds.add(snap_id)
            u.overlays["add"] = sorted(adds); self.um.save_universe(u)
        return PromotionResult(staged=dec.staged, promoted=dec.promoted, reason=dec.reason, snapshot_id=snap_id)
