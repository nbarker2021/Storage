
import sys, json
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[0]))
sys.path.append(str(Path(__file__).resolve().parents[1]))

import numpy as np
from agrm.spine.controller_v0_7 import AGRMController_v0_7_2025_08_13 as CTRL

def run_once(N=5000, sampler='grid', adj_backend='grid'):
    rng = np.random.default_rng(42)
    pts = rng.random((N,2))
    cfg = {
        "vws_force_grid": (sampler=="grid"), "vws_N_guard": 3000,
        "seeding_strategy": sampler, "vws_grid_size": 64, "vws_skip_seed": False,
        "use_adjacency_prefilter": True, "adj_k": 8, "adj_buckets": 64, "adj_backend": adj_backend,
        "enable_fastlane": True, "fastlane_threshold": 0.70
    }
    ctrl = CTRL(cfg=cfg)
    res = ctrl.solve(pts, max_ticks=3)
    return res

if __name__ == '__main__':
    base = run_once(N=4000, sampler='grid', adj_backend='grid')
    print("GRID/GRID:", json.dumps(base, indent=2))
    lhs  = run_once(N=4000, sampler='lhs', adj_backend='grid')
    print("LHS/GRID:", json.dumps(lhs, indent=2))
    pois = run_once(N=4000, sampler='poisson', adj_backend='grid')
    print("POIS/GRID:", json.dumps(pois, indent=2))
    ann  = run_once(N=4000, sampler='lhs', adj_backend='faiss')  # will fallback if faiss missing
    print("LHS/FAISS:", json.dumps(ann, indent=2))
