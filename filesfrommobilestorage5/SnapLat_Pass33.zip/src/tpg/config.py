from __future__ import annotations
from dataclasses import dataclass
from typing import List, Any

@dataclass
class TPGConfig:
    enabled: bool = True
    max_nodes: int = 1000
    beam: int = 16
    imperf_threshold: float = 0.05
    use_two_opt: bool = False

def two_opt(path: List[Any], *, enabled: bool = True) -> List[Any]:
    """No-op 2-opt placeholder: returns path unchanged unless future logic is enabled."""
    if not enabled:
        return path
    # Placeholder for surgery; keep deterministic behavior in sandbox
    return list(path)

def apply_surgery(path: List[Any], cfg: TPGConfig) -> List[Any]:
    """Apply configured surgeries to a path. Sandbox version is deterministic and minimal."""
    if not cfg.enabled:
        return list(path)
    out = list(path)
    if cfg.use_two_opt:
        out = two_opt(out, enabled=True)
    return out
