
from .shell_qa import ShellPromotionRules
def rules_from_policy(policy) -> ShellPromotionRules:
    return ShellPromotionRules(
        min_size=policy.min_size,
        min_coherence=policy.min_coherence,
        max_redundancy=policy.max_redundancy,
        min_domain=policy.min_domain,
        max_flip_rate=policy.max_flip_rate,
    )
