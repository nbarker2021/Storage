import math
import itertools
import random
import json
import os
import subprocess
import logging
import time
import shutil  # For directory removal
from typing import Any, Dict, List, Tuple, Callable, Optional

import pandas as pd  # Used in data_manager.
import networkx as nx
from sklearn.linear_model import LinearRegression  # Example ML model
from sklearn.model_selection import train_test_split #For model training
from sklearn.metrics import mean_squared_error #For model training

# ----------------------------------------------------------------------
# config.py (Combined)
# ----------------------------------------------------------------------
class ConfigManager:
    def __init__(self, config_file: str = 'config.json'):
        self.settings: Dict[str, Any] = {
            'n': 7,  # Target n value
            'auto_loop': False,  # For manual simulation, keep this False
            'strategy': 'bouncing_batch',
            'evaluation_metric': 'comprehensive',
            'length_weight': 1.0,
            'imperfection_weight': 10000000.0, # Very high to prioritize valid superpermutations
            'winner_loser_weight': 4.5,       # Tuned value
            'layout_memory_weight': 0.35,    # Tuned value
            'imbalance_weight': 0.02,       # Tuned value
            'connectivity_weight': 1.4,       # Tuned Value
            'symmetry_weight': 0.0,      # Placeholder
            'extensibility_weight': 2.0, #Placeholder Value
            'grid_dimensions': [3, 3, 3],
            'bouncing_batch_size': 7,     # Tuned Value
            'bouncing_batch_iterations': 25,  # Tuned value
            'store_full_permutations': False,  # Use (n-1)-mers for n=7
            'k_mer_size': 6,
            'data_file': 'superperm_data.json',
            'strategy_thresholds': {'small': 5, 'medium': 7},
            'auto_adjust': False, # We will manually adjust based on ThinkTank
            'auto_adjust_params': {  # Not used in the manual simulation, but kept for reference
                "max_n_factor": 1000,
                "max_n_base": 2.718,
                "local_search_iterations_base": 100,
                "local_search_iterations_factor": 50,
                "sandbox_timeout_base": 10,
                "sandbox_timeout_exponent": 2.5,
                "sandbox_timeout_factor": 2,
                "sandbox_memory_limit_percentage": 0.5,
                "sandbox_max_memory_limit_mb": 4096,
                "sandbox_max_processes": 4
            },
            'model_file': "model.pkl", # Not used in simulation
            'train_models': False,      # Not used in simulation
             "sp_formulas": {
                "sp_v14": { "phi": 1.618033988749895 }
            },
            "c_formulas": {
                "c_n_debruijn": {"a": 1.0, "b": 2.0, "c": 3.0}
            },
            "i_formulas": {
                "i_n_factorial_diff": {"a": 0.5, "b": 4.6, "c": 5, "d": 5.5, "scc_weight": 150.0},  # Tuned 'b' and added 'scc_weight'
                "i_n_exponential": {"c0": 1.0, "k": 0.175}
            }
        }
        self.config_file: str = config_file
        self.load_settings(self.config_file)  # Load settings on initialization
        # Removed call to auto_adjust_settings() for manual control.

    def load_settings(self, file_path: str) -> None:
        try:
            with open(file_path, 'r') as f:
                loaded_settings: Dict[str, Any] = json.load(f)
                self.settings.update(loaded_settings)
        except FileNotFoundError:
            print(f"Config file {file_path} not found. Using default settings.")
        except json.JSONDecodeError:
            print(f"Error parsing {file_path}. Using default settings.")

    def get_setting(self, key: str, default: Any = None) -> Any:
        return self.settings.get(key, default)

    def set_setting(self, key: str, value: Any) -> None:
        self.settings[key] = value
        # Removed interactive save

    def save_settings(self, file_path: str) -> None:
        try:
            with open(file_path, 'w') as f:
                json.dump(self.settings, f, indent=4)
            print(f"Settings saved to {file_path}")  # Keep this for the simulation output
        except IOError as e:
            print(f"Error saving settings to {file_path}: {e}") #Keep for simulation

    def get_system_specs(self):
        """Gets System Specs (Simulated)"""
        return {
            'cpu_count': 12,  # Simulated high-end CPU
            'logical_cpu_count': 24,  # Simulated with hyperthreading
            'total_memory_gb': 64.0, # Simulated RAM
            'available_memory_gb': 48.0, # Simulated available RAM
            'platform': 'simulated',
            'os': 'simulated',
        }

# ----------------------------------------------------------------------
# utility.py (Combined)
# ----------------------------------------------------------------------

def get_user_input(prompt: str) -> bool:
    # Simulated user input for the manual simulation.  Always returns True.
    print(f"SIMULATED PROMPT: {prompt}  Assuming 'y' (yes).")
    return True

def is_valid_permutation(s: str, n: int) -> bool:
    """Checks if a string 's' is a valid permutation of numbers from 1 to n."""
    return len(s) == n and len(set(s)) == n and all(c.isdigit() and 1 <= int(c) <= n for c in s)

def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings."""
    for i in range(min(len(s1), len(s2)), 0, -1):
        if s1[-i:] == s2[:i]:
            return i
    return 0

def generate_permutations(n: int) -> List[str]:
    """Generates all permutations of numbers from 1 to n as strings."""
    symbols = [str(i) for i in range(1, n + 1)]
    return [''.join(p) for p in itertools.permutations(symbols)]

def kmer_to_int(kmer: str) -> int:
    """Converts a k-mer string to a unique integer representation."""
    result = 0
    for char in kmer:
        result = result * 10 + (int(char) - 1)
    return result

def hash_permutation(permutation: Tuple[int, ...]) -> int:
    """Hashes a permutation tuple to a unique integer."""
    result = 0
    n = len(permutation)
    for val in permutation:
        result = result * (n + 1) + val
    return result

def unhash_permutation(hash_value: int, n: int) -> Tuple[int, ...]:
    """Converts a hash value back to a permutation tuple."""
    permutation = []
    for _ in range(n):
        val = hash_value % (n + 1)
        permutation.append(val)
        hash_value //= (n + 1)
    return tuple(permutation[::-1])

def compute_checksum(sequence: str) -> str:
    """Computes SHA-256 checksum of the sequence."""
    return hashlib.sha256(sequence.encode('utf-8')).hexdigest()

def assign_permutation_to_cell(permutation: Tuple[int, ...], n: int) -> Tuple[int, int, int]:
    """Assigns a permutation to a 3D cell based on digit counts."""
    group1_limit = math.ceil(n / 3)
    group2_limit = group1_limit + math.ceil((n - group1_limit) / 2)

    group1_count = 0
    group2_count = 0
    group3_count = 0

    for digit in map(int, permutation[:n-1]):  # Consider the first n-1 digits
        if digit <= group1_limit:
            group1_count += 1
        elif digit <= group2_limit:
            group2_count += 1
        else:
            group3_count += 1

    # Normalize the counts to get cell coordinates (e.g., 0-9)
    x = int((group1_count / (n - 1)) * 9)
    y = int((group2_count / (n - 1)) * 9)
    z = int((group3_count / (n - 1)) * 9)

    return x, y, z

def generate_hypothetical_prodigal(n: int, length: int) -> str:
    """Generates a hypothetical prodigal sequence of the given length."""
    if length < n:
        raise ValueError("Length must be at least n")

    # Start with a valid permutation
    symbols = [str(i) for i in range(1, n + 1)]
    prodigal = list(random.choice(list(itertools.permutations(symbols)))) # Start with a random permutation
    prodigal_str = "".join(map(str, prodigal))

    # Introduce an imperfection (simplest case: swap two elements)
    if n > 1:
      swap_index1 = random.randint(0, n - 1)
      swap_index2 = (swap_index1 + 1) % n  # Wrap around
      prodigal[swap_index1], prodigal[swap_index2] = prodigal[swap_index2], prodigal[swap_index1]
      prodigal_str = "".join(map(str, prodigal))

    # Extend to the desired length (add random digits, maintaining overlap)
    while len(prodigal_str) < length:
        prodigal_str += random.choice(symbols)

    return prodigal_str

class SystemSpecReader:
    """Reads system specifications (CPU, memory, etc.). Simulates for this example"""

    def get_specs(self) -> Dict[str, Any]:
        """Returns a dictionary of system specifications."""
        return { #Simulated Specs
            'cpu_count': 12,  # Simulated high-end CPU
            'logical_cpu_count': 24,  # Simulated with hyperthreading
            'total_memory_gb': 64.0, # Simulated RAM
            'available_memory_gb': 48.0, # Simulated available RAM
            'platform': 'simulated',
            'os': 'simulated',
        }

class RestrictedEnvironment:
    """Manages a restricted execution environment (sandbox)."""

    def __init__(self, timeout: int = 60, memory_limit_mb: int = 512, num_processes: int = 1, temp_dir: str = "sandbox_temp"):
        self.timeout = timeout
        self.memory_limit_mb = memory_limit_mb
        self.num_processes = num_processes
        self.temp_dir = temp_dir  # Directory for temporary files
        config = ConfigManager()
        self.timeout = config.get_setting("sandbox_timeout", self.timeout)
        self.memory_limit_mb = config.get_setting("sandbox_memory_limit_mb", self.memory_limit_mb)
        self.num_processes = config.get_setting("sandbox_num_processes", self.num_processes)
        self._constructed = False

    def construct(self):
        """Sets up the sandbox environment (e.g., creates a temporary directory)."""
        # if not os.path.exists(self.temp_dir): #Removed for simulation
        #     os.makedirs(self.temp_dir)
        print(f"SIMULATED: Creating sandbox directory: {self.temp_dir}") #Show user
        self._constructed = True

    def deconstruct(self):
        """Cleans up the sandbox environment (e.g., removes temporary files)."""
        # if os.path.exists(self.temp_dir): #Removed for simulation
        #     try:
        #         for filename in os.listdir(self.temp_dir):
        #             file_path = os.path.join(self.temp_dir, filename)
        #             if os.path.isfile(file_path) or os.path.islink(file_path):
        #                 os.unlink(file_path)
        #             elif os.path.isdir(file_path):
        #                 import shutil
        #                 shutil.rmtree(file_path)  # Use shutil.rmtree to remove directories
        #         os.rmdir(self.temp_dir) #Remove the now empty directory.
        #         self._constructed = False
        #     except Exception as e:
        #         print(f"Error during sandbox deconstruction: {e}")
        print(f"SIMULATED: Removing sandbox directory: {self.temp_dir}")
        self._constructed = False
    def run_in_sandbox(self, code: str) -> Tuple[int, str, str]:
        """
        Runs the given Python code in a separate process with limited resources.
        SIMULATED VERSION - Does not actually execute code.
        """
        if not self._constructed:
            raise Exception("Sandbox not constructed. Call .construct() before use.")
        print(f"SIMULATED: Running code in sandbox:\n{code}")
        return 0, "Simulated Output", "" #Simplified

class DTT:
    """Deploys, tests, and times code execution, optionally within a sandbox."""

    def __init__(self, use_sandbox: bool = True, environment: RestrictedEnvironment = None):
        self.use_sandbox = use_sandbox
        self.environment = environment or RestrictedEnvironment()
        config = ConfigManager()
        self.use_sandbox = config.get_setting("dtt_use_sandbox", self.use_sandbox)
        if self.use_sandbox:
          self.environment.construct() #Construct the environment.

    def __del__(self):
        if self.use_sandbox and self.environment._constructed:
            self.environment.deconstruct()  # Deconstruct the environment when DTT is destroyed

    def deploy_and_test(self, code: str, test_cases: List[Dict[str, Any]] = None) -> List[Dict]:
        """Deploys, tests and times the code.

        Args:
            code: The code to run.
            test_cases: List of test cases of the form [{"input":<dict>, "expected":<value>}]
        """
        results = []
        run_func = self.environment.run_in_sandbox if self.use_sandbox else self._run_directly

        start_time = time.time()
        return_code, stdout, stderr = run_func(code) #Run code
        end_time = time.time()
        execution_time = end_time - start_time

        results.append({
            "success": return_code == 0,
            "output": stdout,
            "error": stderr,
            "time": execution_time
        })

        # Run test cases, if provided
        if test_cases:
            for case in test_cases:
                test_input = case["input"]
                expected_output = case["expected"]
                # Construct code to run the test case
                test_code = code + "\n" + f"result = solve(**{test_input})" + "\n" + "print(result)"
                start_time = time.time()
                ret, out, err = run_func(test_code) #Run code.
                end_time = time.time()
                test_success = ret == 0 and out.strip() == str(expected_output)
                results.append({
                    "success": test_success,
					"output": out,
                    "error": err,
                    "time": end_time - start_time # Capture time for each test case
                 })

        return results

    def _run_directly(self, code:str):
        """Helper method for direct execution"""
        # Use a temporary file to simulate execution
        #SIMULATED
        print("SIMULATED: Running code directly (no sandbox):\n", code)
        return 0, "Simulated Output", "" #Simplified return
        # with open("temp_execution_file.py", "w") as f:
        #     f.write(code)
        # try:
        #     result = subprocess.run(["python", "temp_execution_file.py"], capture_output=True, text=True, check=False)
        #     return result.returncode, result.stdout, result.stderr
        # except Exception as e:
        #     return -2, "", str(e)
        # finally:
        #     os.remove("temp_execution_file.py") #Clean up temp file.
		
		# graph_utils.py (Expanded)
import networkx as nx
from typing import List, Dict, Tuple, Any, Optional
# from utils import generate_permutations  # Removed cross-file import

def build_de_bruijn_graph(permutations: List[str], n: int, k: int) -> nx.DiGraph:
    """Builds a De Bruijn graph from a list of permutations."""
    graph = nx.DiGraph()
    for perm in permutations:
        graph.add_edge(perm[:k], perm[1:k+1], label=perm[k])
    return graph

def analyze_debruijn_graph(graph: nx.DiGraph, n: int, k: int) -> Dict[str, Any]:
    """Analyzes a De Bruijn graph and returns relevant properties."""
    in_degrees = dict(graph.in_degree())
    out_degrees = dict(graph.out_degree())
    imbalance = sum(abs(in_degrees.get(node, 0) - out_degrees.get(node, 0)) for node in graph.nodes())
    has_eulerian_path = nx.has_eulerian_path(graph)
    has_eulerian_circuit = nx.has_eulerian_circuit(graph)
    try:
        scc = list(nx.strongly_connected_components(graph))
    except nx.NetworkXPointlessConcept:
        scc = []
    try:
        min_cut_value = nx.minimum_edge_cut(graph)
        min_cut = len(min_cut_value) if min_cut_value is not None else None
    except nx.NetworkXError:
        min_cut = None

    try:
        betweenness_centrality = nx.betweenness_centrality(graph)
    except nx.NetworkXError:
        betweenness_centrality = {}
    try:
        closeness_centrality = nx.closeness_centrality(graph)
    except nx.NetworkXError:
        closeness_centrality = {}
    try:
        eigenvector_centrality = nx.eigenvector_centrality(graph, max_iter=500)
    except (nx.NetworkXError, nx.PowerIterationFailedConvergence):
        eigenvector_centrality = {}

    cycles = list(nx.simple_cycles(graph))
    cycle_lengths = [len(cycle) for cycle in cycles]
    avg_cycle_length = sum(cycle_lengths) / len(cycle_lengths) if cycle_lengths else 0.0

    try:
        clustering_coefficient = nx.average_clustering(graph)
    except nx.NetworkXError:
        clustering_coefficient = None

    return {
        'num_nodes': graph.number_of_nodes(),
        'num_edges': graph.number_of_edges(),
        'in_degrees': in_degrees,
        'out_degrees': out_degrees,
        'imbalance': imbalance,
        'has_eulerian_path': has_eulerian_path,
        'has_eulerian_circuit': has_eulerian_circuit,
        'strongly_connected_components': scc,
        'min_cut': min_cut,
        'betweenness_centrality': betweenness_centrality,
        'closeness_centrality': closeness_centrality,
        'eigenvector_centrality': eigenvector_centrality,
        'cycles': cycles,
        'avg_cycle_length': avg_cycle_length,
        'clustering_coefficient': clustering_coefficient,
    }

def get_node_degrees(graph: nx.DiGraph) -> Tuple[Dict[Any, int], Dict[Any, int]]:
    """Gets the in-degrees and out-degrees of all nodes in the graph"""
    return dict(graph.in_degree()), dict(graph.out_degree())

def get_edge_labels(graph: nx.DiGraph) -> Dict[Tuple[Any,Any], str]:
    """Gets all edge labels"""
    return nx.get_edge_attributes(graph, 'label')
	
	# layout_memory.py (Complete - Grid and LayoutMemory)
import json
from typing import Dict, List, Tuple, Any, Optional
# from utility import calculate_overlap, kmer_to_int, is_valid_permutation, generate_permutations, hash_permutation  # Removed cross-file imports
import math  # Needed for Grid
from config import ConfigManager

class LayoutMemory:
    def __init__(self, n: int, store_full_permutations: bool = True, k: Optional[int] = None):
        self.n = n  # The 'n' value for the superpermutation problem
        self.store_full_permutations = store_full_permutations
        self.k = k # Value for n-k mers
        self.memory: Dict[str, Dict[str, Any]] = {}  # {hash: {score, sequence, overlaps, ...}}
        self.config = ConfigManager()
        self.max_size = self.config.get_setting("layout_memory_max_size", 1000) # Default max size
        self.anti_laminates = AntiLaminate(n) # Add AntiLaminate, same n value


    def _get_sequence_key(self, sequence: str) -> str:
        """Returns the key for storing the sequence in memory."""
        if self.store_full_permutations:
            return str(self.hash_permutation(tuple(int(x) for x in sequence)))  # Hash full perm
        else:
            return str(self.kmer_to_int(sequence)) #Hash k-mer

    def add_sequence(self, sequence: str, score: float, overlaps: Dict = None):
        """Adds a sequence to the memory, along with its metadata."""
        if self.store_full_permutations:
          #Check if is a valid superpermutation
            if len(sequence) < self.n or not all(self.is_valid_permutation(sequence[i:i+self.n], self.n) for i in range(len(sequence) - self.n + 1)):
                return #Invalid

        else: #Check if valid (n-k) mer
            if len(sequence) != self.n - self.k: #Check correct k-mer length.
                return


        seq_key = self._get_sequence_key(sequence)
        if seq_key not in self.memory:
            if len(self.memory) >= self.max_size:
                self.prune() #Limit Memory usage
            self.memory[seq_key] = {
                'score': score,
                'sequence': sequence,
                'overlaps': overlaps or {},  # Store overlap information
                'frequency': 1 # Initialize frequency
            }
        else:
            # If the sequence already exists, increment its frequency
            self.memory[seq_key]['frequency'] += 1
            # Update the score if the new score is better:
            if score > self.memory[seq_key]['score']:
                self.memory[seq_key]['score'] = score
                self.memory[seq_key]['sequence'] = sequence #Store the best sequence
            if overlaps:
                self.memory[seq_key]['overlaps'].update(overlaps)


    def get_sequence(self, seq_key: str) -> Optional[Dict[str, Any]]:
        """Retrieves a sequence and its metadata by key."""
        return self.memory.get(seq_key)

    def find_similar_sequences(self, sequence: str, threshold: float = 0.8) -> List[Dict]:
        """Finds sequences in memory that are similar to the given sequence."""
        similar_sequences = []

        if self.store_full_permutations:
            k = self.n - 1  # Use (n-1)-mers for similarity with full perms
        else:
            k = self.n - self.k -1 # Use (n-k-1) mers

        seq_kmers = set([sequence[i:i + k] for i in range(len(sequence) - k + 1)])

        for data in self.memory.values(): #Iterate through values directly.
            mem_kmers = set([data['sequence'][i:i+k] for i in range(len(data['sequence']) - k + 1)])
            overlap_count = len(seq_kmers.intersection(mem_kmers))
            similarity = overlap_count / max(len(seq_kmers), 1)  # Avoid division by zero
            if similarity >= threshold:
                similar_sequences.append(data)
        return similar_sequences

    def prune(self):
        """Removes the lowest-scoring sequences to stay within the size limit."""
        if len(self.memory) > self.max_size:
            sorted_sequences = sorted(self.memory.items(), key=lambda item: item[1]['score'])
            num_to_remove = len(self.memory) - self.max_size
            for seq_key, _ in sorted_sequences[:num_to_remove]:
                del self.memory[seq_key]

    def calculate_debruijn_imbalance(self, sequence: str) -> int:
      """Calculate the De Bruijn graph imbalance for a sequence."""
      if self.store_full_permutations:
          graph = self.build_de_bruijn_graph([sequence],self.n, self.n-1) # Build graph of length n-1
          return self.analyze_debruijn_graph(graph, self.n, self.n -1)['imbalance']
      else:
        graph = self.build_de_bruijn_graph([sequence],self.n, self.n - self.k - 1)
        return self.analyze_debruijn_graph(graph, self.n, self.n-self.k -1)['imbalance']

    def get_best_sequence_by_length(self, length: int) -> List[Dict]:
        """Retrieves best sequences up to a certain length"""
        valid_seqs = [data for data in self.memory.values() if len(data['sequence']) <= length ]
        return sorted(valid_seqs, key = lambda x: x['score'], reverse=True)

    def clear(self):
      self.memory = {}

    #Proxy Methods
    def is_valid_permutation(self, s: str, n: int) -> bool:
      return is_valid_permutation(s,n)
    def calculate_overlap(self, s1: str, s2: str) -> int:
      return calculate_overlap(s1, s2)
    def generate_permutations(self, n: int) -> List[str]:
        return generate_permutations(n)
    def kmer_to_int(self, kmer: str) -> int:
        return kmer_to_int(kmer)
    def hash_permutation(self, permutation: Tuple[int, ...]) -> int:
        return hash_permutation(permutation)
    def build_de_bruijn_graph(self, permutations: List[str], n: int, k: int) -> 'nx.DiGraph':
        graph = nx.DiGraph()
        for perm in permutations:
            graph.add_edge(perm[:k], perm[1:k + 1], label=perm[k])
        return graph
    def analyze_debruijn_graph(self, graph: 'nx.DiGraph', n: int, k:int) -> Dict[str, Any]:
        import networkx as nx
        in_degrees = dict(graph.in_degree())
        out_degrees = dict(graph.out_degree())
        imbalance = sum(abs(in_degrees.get(node, 0) - out_degrees.get(node, 0)) for node in graph.nodes())
        has_eulerian_path = nx.has_eulerian_path(graph)
        has_eulerian_circuit = nx.has_eulerian_circuit(graph)
        try:
            scc = list(nx.strongly_connected_components(graph))
        except nx.NetworkXPointlessConcept:
            scc = []
        try:
            min_cut_value = nx.minimum_edge_cut(graph)
            min_cut = len(min_cut_value) if min_cut_value is not None else None
        except nx.NetworkXError:
            min_cut = None

        try:
            betweenness_centrality = nx.betweenness_centrality(graph)
        except nx.NetworkXError:
            betweenness_centrality = {}
        try:
            closeness_centrality = nx.closeness_centrality(graph)
        except nx.NetworkXError:
            closeness_centrality = {}
        try:
            eigenvector_centrality = nx.eigenvector_centrality(graph, max_iter=500)
        except (nx.NetworkXError, nx.PowerIterationFailedConvergence):
            eigenvector_centrality = {}

        cycles = list(nx.simple_cycles(graph))
        cycle_lengths = [len(cycle) for cycle in cycles]
        avg_cycle_length = sum(cycle_lengths) / len(cycle_lengths) if cycle_lengths else 0.0

        try:
            clustering_coefficient = nx.average_clustering(graph)
        except nx.NetworkXError:
            clustering_coefficient = None

        return {
            'num_nodes': graph.number_of_nodes(),
            'num_edges': graph.number_of_edges(),
            'in_degrees': in_degrees,
            'out_degrees': out_degrees,
            'imbalance': imbalance,
            'has_eulerian_path': has_eulerian_path,
            'has_eulerian_circuit': has_eulerian_circuit,
            'strongly_connected_components': scc,
            'min_cut': min_cut,
            'betweenness_centrality': betweenness_centrality,
            'closeness_centrality': closeness_centrality,
            'eigenvector_centrality': eigenvector_centrality,
            'cycles': cycles,
            'avg_cycle_length': avg_cycle_length,
            'clustering_coefficient': clustering_coefficient,
        }

class Grid:
    def __init__(self, n: int, dimensions: Tuple[int, int, int] = (10, 10, 10)):
        self.n = n
        self.dimensions = dimensions
        self.cells: Dict[Tuple[int, int, int], LayoutMemory] = {}
        self.config = ConfigManager()
        self.store_full_permutations = self.config.get_setting("store_full_permutations", True)
        self.k = self.config.get_setting("k_mer_size", 2)  # Default to storing n-2 mers
        # Initialize cells
        for x in range(dimensions[0]):
            for y in range(dimensions[1]):
                for z in range(dimensions[2]):
                    self.cells[(x, y, z)] = LayoutMemory(n=self.n, store_full_permutations = self.store_full_permutations, k = self.k)

    def get_cell(self, coordinates: Tuple[int, int, int]) -> Optional[LayoutMemory]:
        """Retrieves the LayoutMemory for a given cell."""
        return self.cells.get(coordinates)

    def get_neighbors(self, coordinates: Tuple[int, int, int]) -> List[Tuple[int, int, int]]:
        """Returns the coordinates of neighboring cells (including diagonals)."""
        x, y, z = coordinates
        neighbors = []
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                for dz in [-1, 0, 1]:
                    if dx == 0 and dy == 0 and dz == 0:
                        continue  # Skip the cell itself
                    nx, ny, nz = x + dx, y + dy, z + dz
                    # Check for boundaries
if 0 <= nx < self.dimensions[0] and 0 <= ny < self.dimensions[1] and 0 <= nz < self.dimensions[2]:
                        neighbors.append((nx, ny, nz))
        return neighbors

    def is_edge_cell(self, coordinates: Tuple[int, int, int]) -> bool:
        """Checks if a cell is on the edge of the grid."""
        x, y, z = coordinates
        return (
            x == 0 or x == self.dimensions[0] - 1 or
            y == 0 or y == self.dimensions[1] - 1 or
            z == 0 or z == self.dimensions[2] - 1
        )

    def merge_laminates(self, coord1: Tuple[int, int, int], coord2: Tuple[int, int, int]):
        """Merges the laminates of two neighboring cells."""
        # Get the LayoutMemory instances for the two cells
        cell1_memory = self.get_cell(coord1)
        cell2_memory = self.get_cell(coord2)

        if cell1_memory is None or cell2_memory is None:
            print(f"Warning: Invalid cell coordinates for laminate merge: {coord1}, {coord2}")
            return

        #Incorporate sequences from cell2 to cell1.  This is a simplified merge.
        for key, data in cell2_memory.memory.items():
            cell1_memory.add_sequence(data['sequence'], data['score'], data['overlaps'])

        #and vice versa
        for key, data in cell1_memory.memory.items():
            cell2_memory.add_sequence(data['sequence'], data['score'], data['overlaps'])

    def get_all_cell_coords(self):
        """Gets all cell coordinates"""
        return list(self.cells.keys())

    def clear_all_memory(self):
        """Clears LayoutMemory of all cells"""
        for cell in self.cells.values():
            cell.clear()

# laminate.py (Complete with AntiLaminate)
from typing import List, Set, Dict, Tuple, Optional
# from utility import calculate_overlap  # Removed cross-file import

class Laminate:
    """
    Represents a laminate, a collection of sequences that are considered good
    building blocks for superpermutations.
    """

    def __init__(self, n: int):
        self.n = n
        self.sequences: Set[str] = set()  # Use a set for efficient lookup

    def add_sequence(self, sequence: str):
        """Adds a sequence to the laminate."""
        self.sequences.add(sequence)

    def contains_subsequence(self, sequence: str) -> bool:
        """Checks if any sequence in the laminate is a subsequence of the input"""
        for lam_seq in self.sequences:
            if lam_seq in sequence:
                return True
        return False

    def get_matching_sequences(self, sequence: str, min_overlap: int = 1) -> List[str]:
        """Gets the laminate sequences with some overlap with input"""
        matches = []
        for lam_seq in self.sequences:
            if self.calculate_overlap(lam_seq, sequence) >= min_overlap or self.calculate_overlap(sequence, lam_seq) >= min_overlap:
                matches.append(lam_seq)
        return matches

    def merge(self, other: "Laminate"):
        """Merges another laminate into this one."""
        if self.n != other.n:
            raise ValueError("Cannot merge laminates with different n values.")
        self.sequences.update(other.sequences)

    def __str__(self):
      return f"Laminate(n={self.n}, num_sequences={len(self.sequences)})"

    def calculate_overlap(self, s1: str, s2: str) -> int:
        """Calculates the maximum overlap between two strings."""
        for i in range(min(len(s1), len(s2)), 0, -1):
            if s1[-i:] == s2[:i]:
                return i
        return 0

class AntiLaminate:
    """
    Represents an anti-laminate, a collection of sequences that are considered
    "bad" and should be avoided.
    """

    def __init__(self, n: int):
        self.n = n
        self.sequences: Set[str] = set()

    def add_sequence(self, sequence: str):
        """Adds a sequence to the anti-laminate."""
        self.sequences.add(sequence)

    def contains_subsequence(self, sequence: str) -> bool:
        """Checks if any sequence in the anti-laminate is a subsequence of the input"""
        for anti_seq in self.sequences:
            if anti_seq in sequence:
                return True
        return False

    def merge(self, other: "AntiLaminate"):
        """Merges another anti-laminate into this one."""
        if self.n != other.n:
            raise ValueError("Cannot merge anti-laminates with different n values.")
        self.sequences.update(other.sequences)

    def __str__(self):
      return f"AntiLaminate(n={self.n}, num_sequences={len(self.sequences)})"

# formulas.py (Complete - Refactored with Helper Functions and Proxy Methods)

import math
from typing import Callable, List, Dict, Any, Optional
import itertools
import networkx as nx
# from utils import generate_permutations, is_valid_permutation, calculate_overlap, kmer_to_int  # Removed cross-file imports
# from graph_utils import build_de_bruijn_graph, analyze_debruijn_graph, get_node_degrees, get_edge_labels  # Removed
from config import ConfigManager

class SuperpermutationLengthFormulas:
    """A collection of formulas for predicting superpermutation length."""

    def __init__(self, config: ConfigManager = None):
        self.config = config or ConfigManager()  # Use a default if not provided
        self.phi = (1 + math.sqrt(5)) / 2 #Constant

    def sp_lower_bound(self, n: int) -> int:
        """SP_1: Theoretical lower bound for SP(n). Status: Validated."""
        return sum(math.factorial(i) for i in range(1, n + 1))

    def sp_v14(self, n: int, sp_n_minus_1: int) -> float:
        """SP_3: V14 (Golden Ratio Scaling). Status: Promising (n=7)."""
        phi = self.config.get_setting("sp_formulas", {}).get("sp_v14", {}).get("phi", self.phi)
        return sp_n_minus_1 * (n / phi)

    def sp_recursive(self, n: int, sp_n_minus_1: int, i_n: int) -> int:
        """SP(n) = n! + SP(n-1) + C(n)  ->  SP(n) = n! + SP(n-1) - I(n)"""
        return math.factorial(n) + sp_n_minus_1 - i_n

class CorrectionTermFormulas:
    """A collection of formulas for the correction term C(n)."""

    def __init__(self, config: ConfigManager = None):
        self.config = config or ConfigManager()

    def c_n_debruijn(self, n: int, build_de_bruijn_graph: Callable, analyze_debruijn_graph: Callable) -> float:
        """C_7: De Bruijn graph based C(n) formula. Status: Experimental, integrated into I(n)."""
        params = self.config.get_setting("c_formulas", {}).get("c_n_debruijn", {})
        a = params.get("a", 1.0)  # Default value if not in config
        b = params.get("b", 1.0)
        c = params.get("c", 1.0)

        graph = build_de_bruijn_graph(self.generate_permutations(n - 1), n, n-2)
        imbalance = analyze_debruijn_graph(graph, n, n-2)['imbalance']
        return a * imbalance + b * n + c

    def generate_permutations(self, n: int) -> List[str]:
        """Generates all permutations of numbers from 1 to n as strings."""
        symbols = [str(i) for i in range(1, n + 1)]
        return [''.join(p) for p in itertools.permutations(symbols)]

class ImperfectionFormulas:
    """A collection of formulas for predicting I(n)."""

    def __init__(self, config: ConfigManager = None):
        self.config = config or ConfigManager()


    def i_n_factorial_diff(self, n: int, build_de_bruijn_graph: Callable, analyze_debruijn_graph: Callable) -> int:
        """I_2: Factorial difference and De Bruijn imbalance."""
        params = self.config.get_setting("i_formulas", {}).get("i_n_factorial_diff", {})
        a = params.get("a", 0.5)  # Not directly used in final form, kept for ref
        b = params.get("b", 4.6) # Tuned Value
        c = params.get("c", 5.0)
        d = params.get("d", 5.5) #Imbalance weight
        scc_weight = params.get("scc_weight", 150.0)  # Weight for strongly connected components

        graph = build_de_bruijn_graph(self.generate_permutations(n - 1), n, n - 2) #Need to pass permuations, n, and k
        imbalance = analyze_debruijn_graph(graph, n, n - 2)['imbalance']
        num_scc = len(analyze_debruijn_graph(graph, n, n-2)['strongly_connected_components'])
        return round(((math.factorial(n-1) - math.factorial(n-2)) / (n * b)  - (n - c)) * (1.33 + 0.01 * (n-6)) + (imbalance - 2) * d + (num_scc - 1) * scc_weight)


    def i_n_exponential(self, n: int) -> float:
        """Exponential complexity formula for I(n)."""
        params = self.config.get_setting("i_formulas", {}).get("i_n_exponential", {})
        c0 = params.get("c0", 1.0)
        k = params.get("k", 0.175)
        return c0 * math.exp(k * n) * k

    def generate_permutations(self, n: int) -> List[str]:
        """Generates all permutations of numbers from 1 to n as strings."""
        symbols = [str(i) for i in range(1, n + 1)]
        return [''.join(p) for p in itertools.permutations(symbols)]

    def build_de_bruijn_graph(self, sequences: List[str], n: int, k: int) -> 'nx.DiGraph':
        """Builds a De Bruijn graph from a list of sequences."""
        graph = nx.DiGraph()
        for seq in sequences:
            for i in range(len(seq) - k + 1):
                kmer1 = seq[i:i + k]
                kmer2 = seq[i + 1:i + k + 1]
                if len(kmer1) == k and len(kmer2) == k:
                    graph.add_edge(kmer1, kmer2, label=seq[i + k])
        return graph

    def analyze_debruijn_graph(self, graph: 'nx.DiGraph', n : int, k: int) -> Dict[str, Any]:
        """Analyzes a De Bruijn graph and returns relevant properties."""
        in_degrees = dict(graph.in_degree())
        out_degrees = dict(graph.out_degree())
        imbalance = sum(abs(in_degrees.get(node, 0) - out_degrees.get(node, 0)) for node in graph.nodes())
        has_eulerian_path = nx.has_eulerian_path(graph)
        has_eulerian_circuit = nx.has_eulerian_circuit(graph)
        try:
            scc = list(nx.strongly_connected_components(graph))
        except nx.NetworkXPointlessConcept:
            scc = []
        try:
            min_cut_value = nx.minimum_edge_cut(graph)
            min_cut = len(min_cut_value) if min_cut_value is not None else None
        except nx.NetworkXError:
            min_cut = None

        try:
            betweenness_centrality = nx.betweenness_centrality(graph)
        except nx.NetworkXError:
            betweenness_centrality = {}
        try:
            closeness_centrality = nx.closeness_centrality(graph)
        except nx.NetworkXError:
            closeness_centrality = {}
        try:
            eigenvector_centrality = nx.eigenvector_centrality(graph, max_iter=500)
        except (nx.NetworkXError, nx.PowerIterationFailedConvergence):
            eigenvector_centrality = {}

        cycles = list(nx.simple_cycles(graph))
        cycle_lengths = [len(cycle) for cycle in cycles]
        avg_cycle_length = sum(cycle_lengths) / len(cycle_lengths) if cycle_lengths else 0.0

        try:
            clustering_coefficient = nx.average_clustering(graph)
        except nx.NetworkXError:
            clustering_coefficient = None

        return {
            'num_nodes': graph.number_of_nodes(),
            'num_edges': graph.number_of_edges(),
            'in_degrees': in_degrees,
            'out_degrees': out_degrees,
            'imbalance': imbalance,
            'has_eulerian_path': has_eulerian_path,
            'has_eulerian_circuit': has_eulerian_circuit,
            'strongly_connected_components': scc,
            'min_cut': min_cut,
            'betweenness_centrality': betweenness_centrality,
            'closeness_centrality': closeness_centrality,
            'eigenvector_centrality': eigenvector_centrality,
            'cycles': cycles,
            'avg_cycle_length': avg_cycle_length,
            'clustering_coefficient': clustering_coefficient,
        }

class SegmentLengthFormulas:
    """Formulas for predicting optimal segment lengths"""
    def __init__(self, config: ConfigManager = None):
        self.config = config or ConfigManager()
        self.phi = (1 + math.sqrt(5))/2 #Constant

    def segment_length_best(self, n: int, i_n: float) -> float:
        """Current best segment length formula. Status: Promising."""
        #No parameters to load
        return (n / self.phi) * (1 + 0.1 * i_n)

#Example of how to collect all formulas.
class FormulaManager:
    """Manages and provides access to all formula classes."""
    def __init__(self, config: ConfigManager = None):
        self.config = config or ConfigManager()
        self.sp = SuperpermutationLengthFormulas(self.config)
        self.c = CorrectionTermFormulas(self.config)
        self.i = ImperfectionFormulas(self.config)
        self.segment = SegmentLengthFormulas(self.config)

    def evaluate_all_sp(self, n: int, sp_n_minus_1: Optional[int] = None) -> Dict[str, float]:
        """Evaluates all SP(n) formulas and returns the results."""
        results = {}
        results['sp_lower_bound'] = self.sp.sp_lower_bound(n)
        if sp_n_minus_1 is not None:
            results['sp_v14'] = self.sp.sp_v14(n, sp_n_minus_1)
            i_n = self.i.i_n_factorial_diff(n, self.build_de_bruijn_graph, self.analyze_debruijn_graph)
            results['sp_recursive'] = self.sp.sp_recursive(n, sp_n_minus_1, i_n)
        return results

    def evaluate_all_i(self, n: int) -> Dict[str, float]:
        """Evaluates all I(n) formulas and returns results."""
        results = {}
        results['i_n_factorial_diff'] = self.i.i_n_factorial_diff(n, self.build_de_bruijn_graph, self.analyze_debruijn_graph)
        results['i_n_exponential'] = self.i.i_n_exponential(n)
        return results

def evaluate_all_segment_length(self, n:int, i_n: Optional[float] = None) -> Dict[str, float]:
        results = {}
        if i_n is not None:
          results['segment_length_best'] = self.segment.segment_length_best(n, i_n)
        return results
    def compare_sp_predictions(self, n_values: List[int], best_known_lengths: Dict[int, int]) -> Dict[int, Dict[str, float]]:
        """
        Compares SP(n) predictions against best-known lengths.
        Returns a dictionary: {n: {formula_name: error}}
        """
        results = {}
        sp_nm1 = 0  # Base case: SP(0) = 0  (or SP(1)=1)
        for n in n_values:
            results[n] = {}
            if n in best_known_lengths:
                actual_length = best_known_lengths[n]
                i_n_val = self.i.i_n_factorial_diff(n, self.build_de_bruijn_graph, self.analyze_debruijn_graph)

                predictions = self.evaluate_all_sp(n, sp_nm1)
                for formula_name, predicted_length in predictions.items():
                    if isinstance(predicted_length, (int, float)):
                        error = abs(predicted_length - actual_length)
                        results[n][formula_name] = error
                sp_nm1 = actual_length
            else:
                results[n]["error"] = "Unknown best length" #If we don't know
        return results
    #Proxy Methods
    def generate_permutations(self, n: int) -> List[str]:
        """Generates all permutations of numbers from 1 to n as strings."""
        symbols = [str(i) for i in range(1, n + 1)]
        return [''.join(p) for p in itertools.permutations(symbols)]
    def build_de_bruijn_graph(self, sequences: List[str], n: int, k: int) -> 'nx.DiGraph':
      """Builds a De Bruijn graph from a list of sequences."""
      graph = nx.DiGraph()
      for seq in sequences:
          for i in range(len(seq) - k + 1):
              kmer1 = seq[i:i + k]
              kmer2 = seq[i + 1:i + k + 1]
              if len(kmer1) == k and len(kmer2) == k:
                  graph.add_edge(kmer1, kmer2, label=seq[i + k])
      return graph

    def analyze_debruijn_graph(self, graph: 'nx.DiGraph', n : int, k: int) -> Dict[str, Any]:
        """Analyzes a De Bruijn graph and returns relevant properties."""
        in_degrees = dict(graph.in_degree())
        out_degrees = dict(graph.out_degree())
        imbalance = sum(abs(in_degrees.get(node, 0) - out_degrees.get(node, 0)) for node in graph.nodes())
        has_eulerian_path = nx.has_eulerian_path(graph)
        has_eulerian_circuit = nx.has_eulerian_circuit(graph)
        try:
            scc = list(nx.strongly_connected_components(graph))
        except nx.NetworkXPointlessConcept:
            scc = []
        try:
            min_cut_value = nx.minimum_edge_cut(graph)
            min_cut = len(min_cut_value) if min_cut_value is not None else None
        except nx.NetworkXError:
            min_cut = None

        try:
            betweenness_centrality = nx.betweenness_centrality(graph)
        except nx.NetworkXError:
            betweenness_centrality = {}
        try:
            closeness_centrality = nx.closeness_centrality(graph)
        except nx.NetworkXError:
            closeness_centrality = {}
        try:
            eigenvector_centrality = nx.eigenvector_centrality(graph, max_iter=500)
        except (nx.NetworkXError, nx.PowerIterationFailedConvergence):
            eigenvector_centrality = {}

        cycles = list(nx.simple_cycles(graph))
        cycle_lengths = [len(cycle) for cycle in cycles]
        avg_cycle_length = sum(cycle_lengths) / len(cycle_lengths) if cycle_lengths else 0.0

        try:
            clustering_coefficient = nx.average_clustering(graph)
        except nx.NetworkXError:
            clustering_coefficient = None

        return {
            'num_nodes': graph.number_of_nodes(),
            'num_edges': graph.number_of_edges(),
            'in_degrees': in_degrees,
            'out_degrees': out_degrees,
            'imbalance': imbalance,
            'has_eulerian_path': has_eulerian_path,
            'has_eulerian_circuit': has_eulerian_circuit,
            'strongly_connected_components': scc,
            'min_cut': min_cut,
            'betweenness_centrality': betweenness_centrality,
            'closeness_centrality': closeness_centrality,
            'eigenvector_centrality': eigenvector_centrality,
            'cycles': cycles,
            'avg_cycle_length': avg_cycle_length,
            'clustering_coefficient': clustering_coefficient,
        }
		
		#prodigal_manager.py
import random
from typing import List, Dict, Tuple, Any
from config import ConfigManager  # Import ConfigManager

class ProdigalManager:
    """Manages prodigal sequences, their properties, and relationships."""

    def __init__(self):
        self.prodigals: Dict[int, Dict[str, Dict[str, Any]]] = {}  # {n: {sequence: {data}}}
        self.config = ConfigManager() # Get Config file

    def add_prodigal(self, n: int, sequence: str, source: str, overlap_rate: float = None, parent_prodigals: List[str] = None):
        """Adds a prodigal sequence to the manager."""
        if n not in self.prodigals:
            self.prodigals[n] = {}
        if sequence not in self.prodigals[n]:
            # Calculate an initial extensibility score (placeholder - needs refinement)
            extensibility_score = self.calculate_extensibility(sequence, n)

            self.prodigals[n][sequence] = {
                'length': len(sequence),
                'overlap_rate': overlap_rate,
                'source': source,
                'extensibility_score': extensibility_score,
                'breakpoints': [],  # List of breakpoint dictionaries
                'parent_prodigals': parent_prodigals or [],
                'child_prodigals': [],
                'used_count': 0,
            }

    def get_prodigal(self, n: int, sequence: str) -> Dict[str, Any]:
        """Retrieves data for a specific prodigal."""
        return self.prodigals.get(n, {}).get(sequence)

    def get_prodigals_by_length(self, n: int, min_length: int = 0, max_length: int = float('inf')) -> List[Tuple[str, Dict]]:
        """Retrieves prodigals within a specified length range for a given n."""
        if n not in self.prodigals:
            return []
        return [(seq, data) for seq, data in self.prodigals[n].items()
                if min_length <= data['length'] <= max_length]

    def get_prodigals_by_extensibility(self, n: int, top_k: int = 10) -> List[Tuple[str, Dict]]:
        """Retrieves the top-k prodigals with the highest extensibility scores."""
        if n not in self.prodigals:
            return []
        sorted_prodigals = sorted(self.prodigals[n].items(), key=lambda item: item[1]['extensibility_score'], reverse=True)
        return sorted_prodigals[:top_k]

    def add_breakpoint(self, n: int, sequence: str, position: int, reason: str, n_values: Tuple[int,int] = None):
        """Adds a breakpoint to a prodigal's data."""
        prodigal_data = self.get_prodigal(n, sequence)
        if prodigal_data:
            prodigal_data['breakpoints'].append({'position': position, 'reason': reason, 'n_values': n_values})

    def calculate_extensibility(self, sequence: str, n:int) -> float:
        """Calculates an extensibility score for a sequence (Placeholder)."""
        # TODO: Implement a more sophisticated extensibility score calculation
        # This is a placeholder, needs a real implementation.
        # Consider: overlap with other sequences, winner/loser density, DeBruijn connectivity

        return 1.0 / len(sequence) #For now, just do inverse length.  Needs MUCH better logic.

    def mark_used(self, n: int, sequence: str):
      """Marks prodigal as used"""
      prodigal_data = self.get_prodigal(n, sequence)
      if prodigal_data:
        prodigal_data['used_count'] += 1
		
		# data_manager.py

import json
import os
import time
from typing import Dict, Any, List
import pandas as pd

class DataManager:
    def __init__(self, data_file: str = 'superperm_data.json'):
        self.data_file = data_file
        self.data: Dict[str, Any] = {} # Initialize data
        self.data_dir = "data"  # Use a data directory
        self.load_data()


    def load_data(self) -> Dict[str, Any]:
        """Loads data from the JSON data file, handling FileNotFoundError."""
        try:
            filepath = os.path.join(self.data_dir, self.data_file) #Use os.path.join
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Data file {filepath} not found. Initializing with empty data.")
            return {}
        except json.JSONDecodeError:
            print(f"Error decoding JSON in {filepath}. Initializing with empty data.")
            return {}


    def save_data(self) -> None:
        """Saves the data to the JSON data file."""
        try:
            filepath = os.path.join(self.data_dir, self.data_file)
            with open(filepath, 'w') as f:
                json.dump(self.data, f, indent=4)
        except Exception as e:
            print(f"Error saving data to {filepath}: {e}")


    def add_superpermutation(self, n: int, superpermutation: str) -> None:
        """Adds or updates a superpermutation for a given n."""
        if 'superpermutations' not in self.data:
            self.data['superpermutations'] = {}
        self.data['superpermutations'][str(n)] = superpermutation
        self.save_data()  # Save after each addition

    def get_superpermutation(self, n: int) -> str:
        """Retrieves the superpermutation for a given n, or an empty string if not found."""
        return self.data.get('superpermutations', {}).get(str(n), '')

    def add_laminate(self, n: int, laminate: List[str]) -> None:
        """Adds or updates a laminate for a given n."""
        if 'laminates' not in self.data:
            self.data['laminates'] = {}
        self.data['laminates'][str(n)] = laminate
        self.save_data()

    def get_laminate(self, n: int) -> List[str]:
        """Retrieves the laminate for a given n, or an empty list if not found."""
        return self.data.get('laminates', {}).get(str(n), [])

    def load_csv(self, filename: str, subdir: str = None) -> pd.DataFrame:
        """Loads data from a CSV file within the data directory."""
        filepath = self._get_filepath(filename, subdir)
        try:
            return pd.read_csv(filepath)
        except FileNotFoundError:
            print(f"CSV file not found: {filepath}")
            return pd.DataFrame() # Return Empty Data Frame
        except Exception as e:
            print(f"Error loading CSV {filepath}: {e}")
            return pd.DataFrame()

    def save_csv(self, filename: str, df: pd.DataFrame, subdir: str = None) -> None:
        """Saves a Pandas DataFrame to a CSV file within the data directory."""
        filepath = self._get_filepath(filename, subdir)
        try:
            df.to_csv(filepath, index=False)
            print(f"Data saved to {filepath}")
        except Exception as e:
            print(f"Error saving CSV to {filepath}: {e}")

    def load_json(self, filename: str, subdir: str = None) -> Dict[str, Any]:
        """Loads data from a JSON file within the data directory."""
        filepath = self._get_filepath(filename, subdir)
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"JSON file not found: {filepath}")
            return {}  # Return empty dict if not found
        except json.JSONDecodeError:
            print(f"Error decoding JSON in {filepath}.")
            return {}
        except Exception as e:
             print(f"Error opening JSON file in {filepath}.")
             return{}

    def save_json(self, filename: str, data: Dict[str, Any], subdir: str = None) -> None:
        """Saves data to a JSON file within the data directory."""
        filepath = self._get_filepath(filename, subdir)
        try:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)
            print(f"Data saved to {filepath}")
        except Exception as e:
            print(f"Error saving JSON to {filepath}: {e}")
    def generate_unique_filename(self, base_filename: str, extension: str, subdir: str = None) -> str:
        """Generates a unique filename with a timestamp."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"{base_filename}_{timestamp}.{extension}"
        return self._get_filepath(filename, subdir)

    def _get_filepath(self, filename: str, subdir: str = None) -> str:
        """Helper function to construct file paths within the data directory."""
        if subdir:
            return os.path.join(self.data_dir, subdir, filename)
        return os.path.join(self.data_dir, filename)
		
		import logging
from typing import Any

class ErrorHandler:
    def __init__(self):
        logging.basicConfig(filename='construct_errors.log', level=logging.ERROR)

    def handle_error(self, error: Exception, context: Any) -> None:
        logging.error(f"Error occurred: {error}. Context: {context}")
        self._attempt_recovery(error, context)

    def _attempt_recovery(self, error: Exception, context: Any) -> None:
        logging.error(f"Unable to recover from {type(error).__name__}")

# Example usage
# error_handler = ErrorHandler()
# try:
#     # Some operation that might raise an error
#     pass
# except Exception as e:
#     error_handler.handle_error(e, "Context information")