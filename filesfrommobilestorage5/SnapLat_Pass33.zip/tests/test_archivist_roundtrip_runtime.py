from agrm.snap.archivist import contract, expand, _register_snap_for_tests
from trails import api as trails_api
from trails import validate as trails_validate

def test_roundtrip_idempotence():
    expanded = {
        "glyph": "foo bar baz",
        "context": {"room": "X"},
        "n_level": 1.0,
        "shell": 0,
        "weyl_index": 3
    }
    snap = contract(expanded)
    reh = expand(snap["snap_id"])
    assert reh["glyph"] == expanded["glyph"]
    assert reh["context"] == expanded["context"]
    assert reh["n_level"] == expanded["n_level"]
    assert reh["shell"] == expanded["shell"]
    # Trails are well-formed
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)

def test_invalid_schema_denied_by_safe_cube():
    # Inject a malformed snap (missing glyph) and expect denial+error
    bad = {
        "snap_id": "deadbeef",
        "parent_ids": [],
        "context": {},
        "n_level": 1.0,
        "shell": 0,
        "trail_id": "t",
        "created_at": "now"
    }
    _register_snap_for_tests(bad)
    denied = False
    try:
        _ = expand("deadbeef")
    except PermissionError:
        denied = True
    assert denied
