from dtt.api import run_steps
from trails import api as trails_api
from trails import validate as trails_validate

def test_dtt_dry_run_is_deterministic():
    steps = [{"op":"mdhg.to_points"},{"op":"mdhg.to_graph","why":"structure"},{"op":"archivist.contract"},{"op":"porter.deliver","to":"dtt.harness"}]
    t1 = run_steps(steps, mode="dry")
    t2 = run_steps(steps, mode="dry")
    assert t1.ok and t2.ok
    assert [e.op for e in t1.steps] == [e.op for e in t2.steps]
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
