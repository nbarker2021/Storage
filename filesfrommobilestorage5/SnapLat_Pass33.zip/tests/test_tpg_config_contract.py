from tpg.config import TPGConfig, two_opt, apply_surgery

def test_tpgconfig_shape_and_defaults():
    cfg = TPGConfig()
    assert isinstance(cfg.enabled, bool)
    assert isinstance(cfg.max_nodes, int)
    assert isinstance(cfg.beam, int)
    assert isinstance(cfg.imperf_threshold, float)
    assert isinstance(cfg.use_two_opt, bool)
    # Defaults
    assert cfg.enabled is True
    assert cfg.max_nodes == 1000
    assert cfg.beam == 16
    assert abs(cfg.imperf_threshold - 0.05) < 1e-9
    assert cfg.use_two_opt is False

def test_two_opt_noop_and_apply_surgery():
    path = ["a","b","c","d"]
    out = two_opt(path, enabled=True)
    assert out == path  # no-op in sandbox
    cfg = TPGConfig(use_two_opt=True)
    out2 = apply_surgery(path, cfg)
    assert out2 == path  # still a no-op behavior-wise; interface is what we pin here
