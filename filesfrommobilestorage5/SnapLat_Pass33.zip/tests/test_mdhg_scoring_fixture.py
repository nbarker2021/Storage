import json, os
from pathlib import Path
from agrm.mdhg import wrapper as mdhg

FIX = Path(__file__).parent / "fixtures" / "mdhg_scoring_fixtures.json"

def test_scoring_components_and_bounds():
    data = json.loads(FIX.read_text())
    for rec in data:
        out = mdhg.promotion_breakdown(rec)
        assert "components" in out and "score" in out
        comp = out["components"]
        for k in ["w5h","hot","neg","bridge"]:
            assert k in comp
            assert 0.0 <= float(comp[k]) <= 1.0 or k == "neg"  # neg is a cost but stored raw
        assert 0.0 <= float(out["score"]) <= 1.0

def test_monotonicity_properties():
    base = {"hot": False, "w5h": 0.2, "neg_penalty": 0.0, "bridge_conf": 0.0}
    s_base = mdhg.promotion_breakdown(base)["score"]
    s_hot  = mdhg.promotion_breakdown({**base, "hot": True})["score"]
    s_w5h  = mdhg.promotion_breakdown({**base, "w5h": 0.6})["score"]
    s_br   = mdhg.promotion_breakdown({**base, "bridge_conf": 0.15})["score"]
    s_neg  = mdhg.promotion_breakdown({**base, "neg_penalty": 0.2})["score"]
    assert s_hot >= s_base
    assert s_w5h >= s_base
    assert s_br  >= s_base
    assert s_neg <= s_base
