from thinktank.api import ThinkTank
from mannequin.api import Porter, load_rules
from dtt.api import run_steps, Transcript
from assembly.api import stage, WorkOrder
from trails import api as trails_api
from trails import validate as trails_validate

def _allow_thinktank(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_porter_wired_thinktank_dtt_assembly(tmp_path):
    _allow_thinktank(tmp_path)
    tt = ThinkTank(panel=["mdhg","archivist","porter"])

    # Porter wiring: DTT sink triggers DTT, Assembly sink stages transcript
    port = Porter()
    outputs = {"transcript": None, "workorder": None}

    def dtt_sink(payload):
        # Expect {"steps": [...]}
        assert isinstance(payload, dict) and "steps" in payload
        t = run_steps(payload["steps"], mode="dry")
        outputs["transcript"] = t
        # handoff to Assembly
        port.deliver(t, to="assembly.harness")

    def assembly_sink(payload):
        # Expect Transcript
        assert isinstance(payload, Transcript)
        wo = stage(payload)
        outputs["workorder"] = wo

    port.register_sink("dtt.harness", dtt_sink)
    port.register_sink("assembly.harness", assembly_sink)

    # Produce steps and kick off orchestration via Porter
    res = tt.critique(findings=["weyl cross ok"], evidence={"corroboration":1.0, "neg_conflict":0.0})
    port.deliver({"steps": res.steps}, to="dtt.harness")

    # Assertions
    assert outputs["transcript"] is not None
    assert outputs["workorder"] is not None
    wo = outputs["workorder"]
    assert isinstance(wo, WorkOrder)
    assert "mdhg" in wo.modules and "archivist" in wo.modules

    # Trails produced by DTT/Assembly and Porter should validate
    events = trails_api._drain()
    assert events, "no trail events found"
    for e in events:
        trails_validate.validate_event(e)
