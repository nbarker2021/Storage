from snapops.api import run as snap_run
from mannequin.api import load_rules

def _allow():
    load_rules('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}')

def test_snapops_success_branch():
    _allow()
    res = snap_run({"findings":["ok"], "evidence":{"corroboration":1.0,"neg_conflict":0.0}})
    assert res.ok and res.transcript_ok and res.workorder is not None and res.edbsu_state is None

def test_snapops_failure_branch_goes_edbsu():
    _allow()
    res = snap_run({"inject_fail": True})
    assert (not res.ok) and (not res.transcript_ok) and (res.workorder is None) and (res.edbsu_state is not None)
