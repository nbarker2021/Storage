from dtt.api import run_steps
from morsr.api import analyze
from trails import api as trails_api
from trails import validate as trails_validate

def test_morsr_regions_from_transcript():
    t = run_steps([{"op":"a.b"},{"op":"a.c"},{"op":"b.x"}])
    rm = analyze(t)
    assert rm.regions and abs(sum(rm.regions.values()) - 1.0) < 1e-9
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
