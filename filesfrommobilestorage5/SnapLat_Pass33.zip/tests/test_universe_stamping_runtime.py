from thinktank.api import ThinkTank
from agrm.space.api import Universe, set_default_universe
from mannequin.api import load_rules

def _allow(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_thinktank_universe_stamping(tmp_path):
    _allow(tmp_path)
    set_default_universe(Universe(name="U1", hemispheres=["NW","NE","SW","SE"]))
    tt = ThinkTank(panel=["mdhg","archivist","porter"])
    res = tt.critique(findings=["ok"], evidence={"corroboration":1.0})
    assert all(s.get("universe_ref")=="U1" for s in res.steps)
