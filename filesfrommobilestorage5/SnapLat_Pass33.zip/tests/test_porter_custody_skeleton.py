import pytest
try:
    from mannequin.api import Porter
    HAVE_PORTER = True
except Exception:
    HAVE_PORTER = False

@pytest.mark.skipif(not HAVE_PORTER, reason="Porter custody semantics not implemented — planned next")
def test_dead_letter_on_failure():
    assert True
