from agrm.mdhg.ops import to_points
from scout.api import sweep
from trails import api as trails_api
from trails import validate as trails_validate

def test_scout_emits_rendezvous_for_hemi():
    pts = to_points(seed=2)
    hemi = pts.hemi or []
    rpt = sweep(hemi)
    assert set(rpt.checkpoints) <= set(["NW","NE","SW","SE"])
    evts = trails_api._drain()
    assert any(e.get("event")=="append" and e.get("payload",{}).get("op")=="rendezvous" for e in evts)
    for e in evts:
        trails_validate.validate_event(e)
