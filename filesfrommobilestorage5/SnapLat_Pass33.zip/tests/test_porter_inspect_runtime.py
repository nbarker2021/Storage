from thinktank.api import ThinkTank
from dtt.api import run_steps
from mannequin.api import Porter, load_rules
from ops.agents.api import agent_fingerprint
from trails.query import buffer as tqb

def _allow(tmp_path):
    p = tmp_path / "rules.json"
    p.write_text('{"version":1,"rules":[{"op":"thinktank.critique","allow":true}]}', encoding="utf-8")
    load_rules(str(p))

def test_porter_inspect_reports_counts(tmp_path):
    _allow(tmp_path)
    tqb.clear()
    tt = ThinkTank(panel=["mdhg","archivist"])
    res = tt.critique(findings=["ok"], evidence={"corroboration":1.0})
    _ = run_steps(res.steps, mode="dry")
    port = Porter()
    report = port.inspect(agent_fp=agent_fingerprint("thinktank"), drain=True)
    assert report.get("n_events", 0) >= 1
    assert isinstance(report.get("counts"), dict)
    assert isinstance(report.get("modules"), list)
    assert (report.get("first_idx") is None) or isinstance(report.get("first_idx"), int)
    assert (report.get("last_idx") is None) or isinstance(report.get("last_idx"), int)
