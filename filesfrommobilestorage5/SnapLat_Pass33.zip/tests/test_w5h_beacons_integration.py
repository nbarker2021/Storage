from agrm.mdhg import wrapper as mdhg

def test_alignment_increases_score():
    beacon = (1.0, 0.0)
    room_close = (0.9, 0.1)
    room_far   = (-1.0, 0.0)
    base = {"hot": False, "bridge_conf": 0.0}
    s_close = mdhg.promotion_breakdown({**base, "beacon_vec": beacon, "room_vec": room_close})["score"]
    s_far   = mdhg.promotion_breakdown({**base, "beacon_vec": beacon, "room_vec": room_far})["score"]
    assert s_close >= s_far

def test_neg_beacon_penalty_reduces_score():
    neg_beacon = (1.0, 0.0)
    room_align = (1.0, 0.0)
    base = {"hot": True, "bridge_conf": 0.15}  # give some positives
    s_neutral = mdhg.promotion_breakdown({**base, "room_vec": (0.0,1.0)})["score"]
    s_neg     = mdhg.promotion_breakdown({**base, "neg_beacon_vec": neg_beacon, "room_vec": room_align})["score"]
    assert s_neg <= s_neutral
