from snapops.api import orchestrate
from trails import api as trails_api
from trails import validate as trails_validate

def test_snapops_orchestrate_outputs_steps():
    plan = orchestrate({"task":"demo"})
    assert len(plan.steps) >= 3 and plan.steps[0]["op"].startswith("mdhg.")
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
