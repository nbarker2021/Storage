from agrm.mdhg import wrapper as mdhg
from trails import api as trails_api

def test_wrapper_points_graph_and_score():
    tid = trails_api.begin_trail({"op":"smoke","module":"test"})
    pts = mdhg.to_points({"a":1,"b":2,"c":3})
    nodes, edges = mdhg.to_graph(pts, quotas={"edges": 2})
    out = mdhg.promotion_breakdown({"hot": True, "w5h": 0.4, "bridge_conf": 0.15, "neg_penalty": 0.1})
    trails_api.finalize(tid, {"op":"smoke","status":"ok"})
    assert isinstance(pts, list) and len(pts) >= 1
    assert isinstance(nodes, list) and isinstance(edges, list)
    assert "score" in out and 0.0 <= out["score"] <= 1.0
