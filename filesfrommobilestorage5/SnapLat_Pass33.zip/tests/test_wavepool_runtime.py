from wavepool.api import pool_candidates
from trails import api as trails_api
from trails import validate as trails_validate

def test_wavepool_ranking():
    r = pool_candidates({"x": 0.2, "y": 0.9, "z": 0.1})
    assert [k for k,_ in r.items][:2] == ["y","x"]
    evts = trails_api._drain()
    for e in evts:
        trails_validate.validate_event(e)
