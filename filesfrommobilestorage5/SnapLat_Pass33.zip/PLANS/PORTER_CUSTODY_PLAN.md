# Porter Custody & Dead-Letter — Plan (M1.6)
## Goal
Provide at-least-once delivery semantics with custody log, retry/backoff, and a poison (dead-letter) queue.

## API (proposed)
- `class Porter:`
  - `deliver(payload: Any, *, to: str) -> None` (returns None; Trails emission)
  - `drain(to: str) -> List[Any]` (testing helper)
  - `dead_letters(to: str) -> List[Any]` (testing helper)

## Semantics
- On deliver: write custody log (Trail `append`), attempt handoff; if exception, enqueue to dead-letter and emit `append` with error.
- Idempotency left to consumers (tracked via payload hash in Trails payload if present).

## Tests
- Inject a failing sink; assert item moves to dead-letter, Trails contains error event.

