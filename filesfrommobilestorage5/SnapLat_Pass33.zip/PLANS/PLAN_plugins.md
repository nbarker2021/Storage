        # Plan — plugins
        ## Intake Files
        - `plugins/edges/superperm/app.py`
- `plugins/edges/superperm/generation_code_n7_dynamic_final.py`
- `plugins/edges/superperm/hybridizer_v0_1_2025_08_13.py`
- `plugins/edges/superperm/job_runner.py`
- `plugins/edges/superperm/lattice.py`
- `plugins/edges/superperm/migrations.py`
- `plugins/edges/superperm/ops_center_v0_1_2025_08_13.py`
- `plugins/edges/superperm/policy_demo.py`
- `plugins/edges/superperm/promotion_guard.py`
- `plugins/edges/superperm/router_budget_demo.py`
- `plugins/edges/superperm/routing_golden.py`
- `plugins/edges/superperm/rules_factory.py`
- `plugins/edges/superperm/shell_lifecycle.py`
- `plugins/edges/superperm/shell_qa.py`
- `plugins/edges/superperm/snap_classifier_demo_v0_1_2025_08_13.py`
- `plugins/edges/superperm/snap_promoter_v0_1_2025_08_13.py`
- `plugins/edges/superperm/sqlite_store.py`
- `plugins/edges/superperm/superperm code.py`
- `plugins/edges/superperm/superperm.py`
- `plugins/edges/superperm/test_Code_snap_superperm.py`
- `plugins/edges/superperm/test_Code_superperm_builder.py`
- `plugins/edges/superperm/test_Code_superperm_metrics.py`

        ## Known Gaps (from Fit Report)
        - (none flagged)

        ## Minimal Shims Required
        - (none)

        ## Refactor Steps (initial)
        - Normalize config and constants to `config.py` in this package.
        - Replace any hardcoded thresholds with injected config.
        - Add Trail hooks at entry/exit of key functions/methods.
        - Decompose large modules into single‑responsibility files.
        - Add docstrings and type hints for all public symbols.
        - Prepare unit harness targets (see `tests/` skeletons).
