# Archivist API (expand/contract)
## Expand
`expand(snap_id: str, *, with_bridges: bool = True) -> ExpandedContext`
- Rehydrates glyph into active lattice/shells; loads bridges (optional). Deterministic.

## Contract
`contract(expanded: ExpandedContext) -> SnapV1`
- Compresses active reasoning into a Snap; computes payload_hash; emits Trail events.

## Determinism
- Input Snap + policy_hash + manifest must reproduce identical ExpandedContext within tolerance.
