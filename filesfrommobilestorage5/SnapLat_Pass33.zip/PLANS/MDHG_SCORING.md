# MDHG Scoring Panel (draft)
Score(record) = w_w5h * align(W5H(record)) 
              + w_hot * hot_edge_density(record) 
              - w_neg * neg_beacon_penalty(record)
              + w_bridge * bridge_confidence(record)

- Calibration: grid-search weights {w_w5h, w_hot, w_neg, w_bridge} on fixtures.
- Units: all terms normalized to [0,1].
- Outputs: `promotion_breakdown(record)` returns component scores + rationale.
