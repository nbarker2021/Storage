# Milestones — SnapLat Refactor
## M1 — MDHG Core Ready
- Implement hash table / paths / conflicts / adaptation split.
- `to_points/to_graph` exposed and covered by tests.
- Trail hooks around promotions; scoring panel present.
- Exit: AGRM orchestrator can call MDHG cleanly.

## M2 — AGRM + TPG Orchestrated
- `TPGConfig` normalized; neg‑beacon support wired.
- Inline hashing on iteration boundaries; replay stitching green.
- Exit: A/B harness runs with Trails attached.

## M3 — Trails/W5H/Beacons Integrated
- Beacons registry and `w5h_alignment` hooked in scoring.
- Trail Viewer anchors validated end‑to‑end; taxonomy index exported.
- Exit: Reports carry Trail IDs with lineage pointers.

## M4 — FS2 Superperm Plugin
- Decomposed modules; caches/envelopes in place.
- Canonicalization invariants tested; batch runner harness up.
- Exit: Plugin passes smoke + unit suite with fixtures.

## M5 — Policy/Mannequin
- Policy hash pinning; Safe‑Cube sentinel; Porter custody.
- Exit: Policy bus enforces governance on critical paths.
