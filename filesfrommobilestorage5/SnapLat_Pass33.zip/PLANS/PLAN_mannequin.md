        # Plan — mannequin
        ## Intake Files
        - `mannequin/adapters_subproc_v0_1_2025_08_13.py`
- `mannequin/center_v0_1_2025_08_13.py`
- `mannequin/core.py`
- `mannequin/dual_stack.py`
- `mannequin/mannequin_demo_v0_1_2025_08_13.py`
- `mannequin/mannequin_stream_demo.py`
- `mannequin/mannequin_v0_2_2025_08_13.py`
- `mannequin/sap_snap_fastlane_demo_v0_1_2025_08_13.py`
- `mannequin/sap_v0_1_2025_08_13.py`
- `mannequin/snapdna.py`
- `mannequin/test_Code_porter_report_templates.py`
- `mannequin/universe_demo.py`
- `mannequin/universe_manager_demo_v0_1_2025_08_13.py`

        ## Known Gaps (from Fit Report)
        - porter_custody
- safe_cube_sentinel

        ## Minimal Shims Required
        - `class Porter: def deliver(self, payload, *, to: str): ...`
- `class SafeCubeSentinel: def allow(self, op: str, context: dict) -> bool: ...`

        ## Refactor Steps (initial)
        - Normalize config and constants to `config.py` in this package.
        - Replace any hardcoded thresholds with injected config.
        - Add Trail hooks at entry/exit of key functions/methods.
        - Decompose large modules into single‑responsibility files.
        - Add docstrings and type hints for all public symbols.
        - Prepare unit harness targets (see `tests/` skeletons).
