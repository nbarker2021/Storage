# Refactor Plan — SnapLat (Staging)

**Scope:** No logic changes yet. This plan defines the targeted refactors, tests, and observability wiring
to align legacy winners with the reconstructed design (AGRM/MDHG/TPG/Trails/W5H/FS2/Policy/Mannequin).

## Principles
- **Small, reversible steps** with Trails on every change.
- **Interfaces first:** honor shim contracts; convert shims into real surfaces.
- **Separation of concerns:** decompose “god modules”; one responsibility per file.
- **Determinism:** explicit config injection; no implicit globals.
- **Observability:** structured logging; Trail IDs through critical paths.
- **Safety:** Safe‑Cube sentinel checks before side effects.

## Families & Intake Summary
| family    |   files | gaps                                                                                                                                                                                  | shims                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
|:----------|--------:|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| agrm      |      82 | beacons_registry; materializers_to_points_to_graph; neg_beacon_support; policy_hash; porter_custody; promotion_breakdown; safe_cube_sentinel; tpg_config; trails_hooks; w5h_alignment | POLICY_HASH: str = ""  # injected/pinned at runtime | class Porter: def deliver(self, payload, *, to: str): ... | class TPGConfig: enabled: bool; max_nodes: int; beam: int; imperf_threshold: float; use_two_opt: bool | def append_event(trail_id: str, event: dict) -> None: ... | def begin_trail(context: dict) -> str: ... | def compute_w5h_alignment(beacon_vec, room_vec) -> float: ... | def finalize(trail_id: str, summary: dict) -> None: ... | def get_neg_beacon_penalty(scenario: str) -> float: ... | def promotion_breakdown(record) -> dict: ...  # includes w5h_alignment when present | def to_graph(points, *, quotas=None) -> tuple: ...  # nodes, edges | def to_points(universe) -> list: ... |
| mannequin |      13 | porter_custody; safe_cube_sentinel                                                                                                                                                    | class Porter: def deliver(self, payload, *, to: str): ... | class SafeCubeSentinel: def allow(self, op: str, context: dict) -> bool: ...                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| misc      |     225 |                                                                                                                                                                                       |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| plugins   |      22 |                                                                                                                                                                                       |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| tpg       |       2 | neg_beacon_support; tpg_config; trails_hooks                                                                                                                                          | class TPGConfig: enabled: bool; max_nodes: int; beam: int; imperf_threshold: float; use_two_opt: bool | def append_event(trail_id: str, event: dict) -> None: ... | def begin_trail(context: dict) -> str: ... | def finalize(trail_id: str, summary: dict) -> None: ... | def get_neg_beacon_penalty(scenario: str) -> float: ...                                                                                                                                                                                                                                                                                                                                                                                     |

## Refactor Waves
1. **MDHG Core (`agrm/mdhg/`)**
   - Split: hash table / paths / conflicts / adaptation.
   - Replace hardcoded thresholds with config (`run_manifest`/policy pins).
   - Add Trail hooks (begin/append/finalize) around promotions and splits.
   - Materializers: expose `to_points(...)`, `to_graph(...)` signatures.
2. **AGRM Orchestrator & TPG (`agrm/`, `tpg/`)**
   - Normalize `TPGConfig` surface; surface 2‑opt surgery flags.
   - Neg‑beacon penalties via config; wire into scoring panel.
   - Inline hashing at iteration boundaries for replay stitching.
3. **Trails / W5H / Beacons (`agrm/snap/`)**
   - Ensure `w5h_alignment` computation and `BeaconsRegistry` contract.
   - Trail Viewer anchors in reports; taxonomy‑enforced stitching.
4. **FS2 / Superperm Plugin (`plugins/edges/superperm/`)**
   - Separate `config.py`, `utility.py`, `graph_utils.py`, `layout_memory.py`, `solver.py`.
   - Canonicalization (relabel/rotation/reversal) tests; Step/Neg caches; Envelopes.
5. **Policy / Mannequin (`ops/policy/`, `mannequin/`)**
   - Policy hash pinning; Safe‑Cube sentinel; Porter custody boundaries.
   - `run_manifest` replay pins and governance hooks.

## Risks & Mitigations
- **Mixed concerns in legacy modules** → staged decomposition with unit harness + Trails.
- **Hidden globals/config drift** → config audit; manifest‑driven injection.
- **Silent fallback to heavy deps** → explicit feature flags; stub in tests.

## Definition of Done (per family)
- Shim interfaces replaced with implemented code and covered by unit tests.
- Trail events present at key transitions (promotion, scoring, stitching).
- Configurable thresholds; zero hardcoded magic numbers.
- Importable package with minimal, documented public API.
