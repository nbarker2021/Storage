# Assembly Line (M1.10) — Plan
## Goal
Take a DTT transcript and construct a staged work order (skeleton modules, hooks, wheels) without executing side effects; hand back to ThinkTank/Porter.

## Proposed API
- `stage(transcript) -> WorkOrder`

## Tests
- With a fixed transcript, `stage(...)` yields a deterministic WorkOrder (ids, counts) and validates Trails.
