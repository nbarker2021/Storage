# N-Level & Bridge FSM (v1)
## States
N0 (drivers/constraints), N0.25 (bridge premise), N0.5 (double-known bridge), N1..N4 (saturation), N5 (ambiguity/8-outcomes)

## Transitions
- N0 → N0.25 when a bridge premise is asserted (source lattices unknown or unverified).
- N0.25 → N0.5 when both sides verified (double-known).
- Nk → Nk+1 when context saturation passes thresholds (evidence quotas & shell coverage).
- Nk → Nk-1 (demotion) when contradicting evidence arrives (confidence below floor).
- N4 → N5 on introduction of cross-lattice ambiguity; spawn 8 evaluations (Weyl set).

## Merge/Downgrade Rules
- Merging nodes at N≥1 requires identical glyph binding and shell parity.
- Bridges accumulate confidence via independent evidence (Bayesian-like update).

## Evidence Quotas (to be calibrated)
- Shell coverage %, number of independent bridges, W5H alignment min, beacon checks.
