# E-DBSU Lifecycle (Double-Unknown Bridges)
## States
NEW → TRIAGED → PROMOTED (→ N0.5) | DEMOTED (archive) → ARCHIVED

## Transitions
- NEW: inserted by bridge detector when both endpoints unknown.
- TRIAGED: human/ThinkTank review; run counterfactuals via DTT.
- PROMOTED: sufficient evidence; emit glyph and link to lattices.
- DEMOTED: insufficient/contradictory evidence; retained for learning.

## Triage Signals
- Independent corroboration counts; neg-beacon conflicts; unsafe sentinel denials.

## Retention
- All states carry Trails; ARCHIVED entries compressed as Snaps for recall.
