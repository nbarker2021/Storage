# Branch Strategy
- Default branch: `main` (protected).
- Feature branches per milestone: `feature/mdhg-core`, `feature/agrm-tpg`, `feature/trails-w5h`, `feature/fs2-plugin`, `feature/policy-mannequin`.
- One PR per batch of atomic refactors; rebase before merge; squash commits with conventional messages.

## PR Gates
- CI: importability + tests skeleton green.
- No new global state; config via injection.
- Trails present for modified surfaces.
- Shims replaced or justified; docstrings added.
