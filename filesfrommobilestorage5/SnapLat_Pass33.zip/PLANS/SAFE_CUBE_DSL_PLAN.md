# Safe‑Cube DSL — Plan (M1.5)
## Goal
Introduce a minimal DSL for allow/deny decisions with auditable reasons and bind it to Trails.

## Rule Shape (JSON)
{
  "version": 1,
  "rules": [
    {"op": "mdhg.to_graph", "allow": true},
    {"op": "mdhg.promotion_breakdown", "allow": true},
    {"op": "agrm.risky_side_effect", "allow": false, "reason": "no side-effects in sandbox"}
  ]
}

## API (proposed, mannequin.api runtime)
- `class SafeCubeSentinel:`
  - `load_rules(path: str) -> None`
  - `allow(op: str, context: Dict[str, Any]) -> bool` (emits Trails begin/append/finalize with decision)

## Tests
- Load a temp rules file; assert allow/deny decisions and presence of Trail events.

## Non-Goals (M1)
- Complex expressions, user attributes, external policy engines; file-only, deterministic.
