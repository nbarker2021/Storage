import json, pathlib, time, hashlib
from kernel.telemetry import emit
from triads.sap_snapops_archivist.archivist.revalidate import revalidate_all
from kernel.db import get_conn, exec_sql

BARRIER_FILE = pathlib.Path("outputs/barrier.json")
POLICY_FILE = pathlib.Path("policy/safe-cube-pack-v1.2.yaml")

def _hash_policy_text(txt:str)->str:
    return hashlib.blake2b(txt.encode('utf-8'), digest_size=16).hexdigest()

def current_policy():
    if not POLICY_FILE.exists():
        return {"policy_hash": "<none>", "name":"safe-cube-pack-v1.2", "version":"1.2.0"}
    txt = POLICY_FILE.read_text(encoding="utf-8")
    h = _hash_policy_text(txt)
    return {"policy_hash": h, "name":"safe-cube-pack-v1.2", "version":"1.2.0"}

def policy_update(yaml_text: str, signer: str):
    # persist policy record + engage barrier
    h = _hash_policy_text(yaml_text)
    conn = get_conn()
    exec_sql(conn, "INSERT OR REPLACE INTO policies(policy_hash,name,version,created_at) VALUES(?,?,?,?)",
             (h, "safe-cube-pack-v1.2", "1.2.0", int(time.time()*1000)))
    BARRIER_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {"engaged": True, "at": int(time.time()*1000), "signer": signer, "policy_hash": h}
    BARRIER_FILE.write_text(json.dumps(payload), encoding="utf-8")
    emit("gcr.apply", "governance", {"signer": signer, "ts": payload["at"], "policy_hash": h})
    return payload

def barrier_state():
    if not BARRIER_FILE.exists():
        return {"engaged": False}
    try:
        return json.loads(BARRIER_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"engaged": False}

def clear_barrier(tick:int):
    if BARRIER_FILE.exists():
        s = barrier_state()
        emit("gcr.barrier.end", "governance", {"engaged_at": s.get("at"), "cleared_at": int(time.time()*1000), "tick": tick})
        BARRIER_FILE.unlink(missing_ok=True)
        # kick revalidation loop
        rl = revalidate_all()
        emit('gcr.revalidate.done', 'governance', rl)
