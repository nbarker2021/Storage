import policy.safecube as sc

def test_safecube_logic_monkeypatched(monkeypatch):
    # Force thresholds & bypass DB-dependent helpers
    monkeypatch.setattr(sc, "_thresholds", lambda: (1, 1))
    monkeypatch.setattr(sc, "_edge_diversity", lambda eid: 5)
    monkeypatch.setattr(sc, "_octant_coverage", lambda eid: 3)
    monkeypatch.setattr(sc, "_lawpack_ok", lambda: (True, []))
    ok = sc.check({"endpoint_id": "epX", "evidence": {"edges": 2}})
    assert ok
