from triads.thinktank_dtt_assembly.assembly.publish import finalize_gate

def test_finalize_gate_defaults():
    ok, rs = finalize_gate({'evidence_nodes': 1729, 'evidence_edges': 3})
    assert ok and not rs

def test_finalize_gate_fail_nodes():
    ok, rs = finalize_gate({'evidence_nodes': 100, 'evidence_edges': 3})
    assert not ok and any('gate.nodes' in r for r in rs)
