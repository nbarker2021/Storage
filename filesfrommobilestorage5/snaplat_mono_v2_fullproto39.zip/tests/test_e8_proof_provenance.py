import subprocess, json, pathlib
from triads.e8.proof import generate_proof

def test_e8_proof_and_provenance_pipeline():
    # Seed and run pipeline for ep-demo
    subprocess.check_call(['python','tools/seed_fixture_db.py'])
    proof = generate_proof('ep-demo')
    assert isinstance(proof, dict) and 'rotation_ok' in proof
