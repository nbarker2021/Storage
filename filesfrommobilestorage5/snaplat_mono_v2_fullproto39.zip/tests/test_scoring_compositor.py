
from triads.morsr_wavepool.scoring import compose

def test_compose_shape():
    r = compose('ep-demo','governance')
    assert 'score' in r and 'band' in r and 'rotation_ok' in r
