# Assembly Pipeline — SAFE‑cube & Evidence

- **Domain inference**: uses recent Trails to infer a working domain (`kernel/context.py`).
- **Persona‑aware TT**: ThinkTank 8+8 runs with the inferred domain, selecting personas accordingly.
- **Graph evidence**: `kernel/graph_metrics.evidence_for_endpoint()` counts lineage nodes/edges touching the endpoint.
- **1729 gate**: readiness requires `evidence_nodes ≥ 1729`.
- **SAFE‑cube gate**: `policy.safecube.check()` must pass before a Manifest v2 is built.
- **Micro‑job hooks**: SNAP emits a templated micro‑trace before/after pipeline for reproducibility.
