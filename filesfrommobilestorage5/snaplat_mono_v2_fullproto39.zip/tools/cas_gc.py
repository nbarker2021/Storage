#!/usr/bin/env python3
from triads.sap_snapops_archivist.archivist.lifecycle import gc
import json, sys
days = int(sys.argv[1]) if len(sys.argv)>1 else 30
keep = int(sys.argv[2]) if len(sys.argv)>2 else 3
print(json.dumps(gc(days, keep), indent=2))
