#!/usr/bin/env python3
import os, json
from tools.attestation_verify import verify_attestation, _latest_attestation_for_endpoint
from kernel.telemetry import emit

def main(endpoint_id: str, secret: str|None=None):
    ok, rep = verify_attestation(att_cas=None, endpoint_id=endpoint_id, secret=secret)
    emit('attestation.verify', 'ops', {'endpoint': endpoint_id, **rep})
    print(json.dumps({'ok': ok, **rep}, indent=2, sort_keys=True))

if __name__ == "__main__":
    import sys, os
    if len(sys.argv)<2:
        print("usage: tools/attestation_verify_report.py <endpoint_id>"); raise SystemExit(2)
    secret = os.environ.get("SNAPLAT_SECRET","")
    main(sys.argv[1], secret or None)
