#!/usr/bin/env python3
import json, pathlib, time, argparse, os, math, concurrent.futures
from kernel.telemetry import emit
from kernel.authz import guard_write

ROOT = pathlib.Path("outputs/cas")
OUTDIR = pathlib.Path("outputs/cas_compact")

def shard_stats():
    shards = {}
    total = 0; bytes_sum = 0
    if ROOT.exists():
        for d in ROOT.iterdir():
            if not d.is_dir(): continue
            count = 0; size = 0
            for f in d.iterdir():
                try:
                    st = f.stat()
                    count += 1; size += st.st_size
                except Exception:
                    pass
            shards[d.name] = {"count": count, "bytes": size}
            total += count; bytes_sum += size
    return {"total": total, "bytes": bytes_sum, "shards": shards}

def propose_width(stats: dict, target_per_shard: int = 2000) -> int:
    total = stats.get("total", 0)
    if total == 0: return 2
    width = max(2, min(4, int(math.log(max(1,total/target_per_shard), 16))+1))
    return width

def plan_rebalance(width: int) -> dict:
    plan = {"width": width, "moves": {}, "created_at": int(time.time()*1000)}
    if not ROOT.exists(): return plan
    for d in ROOT.iterdir():
        if not d.is_dir(): continue
        for f in d.iterdir():
            h = d.name + f.name
            new_shard = h[:width]
            if new_shard != d.name:
                sz = 0
                try: sz = f.stat().st_size
                except Exception: pass
                plan["moves"].setdefault(d.name, {})[f.name] = {"to": new_shard, "bytes": sz}
    plan["counts"] = {k: len(v) for k,v in plan["moves"].items()}
    # Cost model
    before = list(stats.get("shards", {}).values())
    before_counts = [s["count"] for s in before] or [0]
    before_std = (sum((c - (sum(before_counts)/max(1,len(before_counts))))**2 for c in before_counts)/max(1,len(before_counts)))**0.5
    est_after_counts = {}
    for shard, s in stats.get("shards", {}).items():
        est_after_counts[shard] = s["count"]
    for old, mv in plan["moves"].items():
        for fname, meta in mv.items():
            new = meta["to"]
            est_after_counts[old] = est_after_counts.get(old,0) - 1
            est_after_counts[new] = est_after_counts.get(new,0) + 1
    after_counts = list(est_after_counts.values()) or [0]
    after_std = (sum((c - (sum(after_counts)/max(1,len(after_counts))))**2 for c in after_counts)/max(1,len(after_counts)))**0.5
    plan["cost"] = {
        "moves": sum(len(v) for v in plan["moves"].values()),
        "bytes": sum(meta["bytes"] for mv in plan["moves"].values() for meta in mv.values()),
        "std_before": before_std,
        "std_after": after_std,
        "std_improvement": (before_std - after_std)
    }
    return plan

def write_plan(plan: dict) -> str:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    p = OUTDIR / f"plan-{plan['created_at']}.json"
    p.write_text(json.dumps(plan, indent=2, sort_keys=True), encoding="utf-8")
    return str(p)

def _apply_move(old, fname, new):
    src = ROOT / old / fname
    dst_dir = ROOT / new; dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / fname
    try:
        src.rename(dst); return True
    except Exception:
        return False

def apply_plan(plan_path: str, dry_run: bool = True, workers: int = 4) -> dict:
    if not guard_write(context={'fn':'cas.compact.apply'}):
        emit('rbac.deny.write','gc',{'fn':'cas_compact.apply'}); return {'applied':0,'skipped':0,'dry_run':True}
    plan = json.loads(pathlib.Path(plan_path).read_text(encoding='utf-8'))
    tasks = []
    for old, moves in plan.get("moves",{}).items():
        for fname, meta in moves.items():
            tasks.append((old, fname, meta["to"]))
    applied = 0; skipped = 0
    if dry_run or not tasks:
        emit('cas.compact.apply','ops',{'applied': applied, 'skipped': skipped, 'dry_run': True})
        return {'applied': applied, 'skipped': skipped, 'dry_run': True}
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,int(workers))) as ex:
        futs = [ex.submit(_apply_move, o, f, n) for (o,f,n) in tasks]
        for fu in concurrent.futures.as_completed(futs):
            ok = fu.result()
            if ok: applied += 1
            else: skipped += 1
    emit('cas.compact.apply','ops',{'applied': applied, 'skipped': skipped, 'dry_run': False})
    return {'applied': applied, 'skipped': skipped, 'dry_run': False}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target-per-shard", type=int, default=2000)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--plan", help="Path to existing plan.json (for --apply)")
    ap.add_argument("--workers", type=int, default=4)
    args = ap.parse_args()
    stats = shard_stats()
    width = propose_width(stats, args.target_per_shard)
    plan = plan_rebalance(width)
    path = write_plan(plan)
    emit('cas.compact.plan','ops',{'width': width, 'moves': plan['cost']['moves'], 'bytes': plan['cost']['bytes'], 'std_improvement': plan['cost']['std_improvement']})
    print(path)
    if args.apply:
        if not args.plan:
            args.plan = path
        res = apply_plan(args.plan, dry_run=False, workers=args.workers)
        print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
