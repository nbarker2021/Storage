#!/usr/bin/env python3
import subprocess, sys

def run(cmd):
    print("+", " ".join(cmd)); sys.stdout.flush()
    try:
        return subprocess.call(cmd)==0
    except Exception:
        return False

def main():
    ok = True
    ok &= run(["python", "tools/db_migrate.py"])
    ok &= run(["python", "tools/lineage_check.py"])
    ok &= run(["python", "tools/export_evidence_csv.py"])
    ok &= run(["python", "tools/cas_verify.py"])
    ok &= run(["python", "tools/lineage_acyclic.py"])
    print("system_doctor:", "OK" if ok else "FAIL")
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
