#!/usr/bin/env python3
import pathlib, os
from kernel.authz import guard_write
from kernel.telemetry import emit

ROOT = pathlib.Path("outputs/cas")

def main(dry_run: bool = True):
    if not guard_write(context={'fn':'tools.cas_compact'}):
        emit('rbac.deny.write','gc',{'fn':'cas_compact'}); return
    total = 0; bytes_sum = 0; shards = {}
    if ROOT.exists():
        for d in ROOT.iterdir():
            if not d.is_dir(): continue
            count = 0; size = 0
            for f in d.iterdir():
                try:
                    st = f.stat()
                    count += 1; size += st.st_size
                except Exception:
                    pass
            total += count; bytes_sum += size
            shards[d.name] = {'count': count, 'bytes': size}
    emit('cas.compact.scan','ops',{'total': total, 'bytes': bytes_sum, 'shards': shards})
    print(f"blobs={total} bytes={bytes_sum}")
    for s, m in sorted(shards.items()):
        print(f"shard={s} count={m['count']} bytes={m['bytes']}")
    if not dry_run:
        # future: implement re-sharding plan
        pass

if __name__ == "__main__":
    main(True)
