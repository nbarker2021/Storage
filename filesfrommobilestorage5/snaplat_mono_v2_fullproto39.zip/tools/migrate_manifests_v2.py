#!/usr/bin/env python3
import json, pathlib, time
from security.sign import sign_payload
from security.crypto import key_id
from api.governance import current_policy

CAS = pathlib.Path("outputs/cas")
pol = current_policy()

def main():
    changed = 0
    for p in CAS.glob("*.json"):
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        if obj.get("kind") != "lockfile": continue
        man = obj.get("payload", {})
        if man.get("version", 1) >= 2: continue
        man["version"] = 2
        man["policy_hash"] = pol.get("policy_hash")
        man["key_id"] = key_id()
        man["created_at"] = man.get("created_at") or int(time.time()*1000)
        man["signature"] = sign_payload(man)
        obj["payload"] = man
        p.write_text(json.dumps(obj, sort_keys=True), encoding="utf-8")
        changed += 1
    print(json.dumps({"migrated": changed}, indent=2))

if __name__ == "__main__":
    main()
