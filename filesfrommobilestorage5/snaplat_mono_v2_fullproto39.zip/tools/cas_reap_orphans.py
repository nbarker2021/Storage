#!/usr/bin/env python3
import json, hashlib, pathlib
from kernel.authz import guard_write
from kernel.telemetry import emit

ROOT = pathlib.Path("outputs/cas")
JOURNAL = pathlib.Path("outputs/cas_journal/ops.log")

def main():
    if not guard_write(context={'fn':'tools.cas_reap_orphans'}):
        emit('rbac.deny.write','gc',{'fn':'cas_reap_orphans'}); return
    seen = set()
    if JOURNAL.exists():
        for line in JOURNAL.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line); seen.add(rec.get("hash",""))
            except Exception: pass
    removed = 0
    if ROOT.exists():
        for d in ROOT.iterdir():
            if not d.is_dir(): continue
            for f in d.iterdir():
                h = d.name + f.name
                if h not in seen:
                    try: f.unlink(); removed += 1
                    except Exception: pass
    emit("cas.reap", "ops", {"removed": removed})
    print("removed", removed)

if __name__ == "__main__":
    main()
