#!/usr/bin/env python3
import json, pathlib
from triads.snap_agrm_mdhg.mdhg.signals_v2 import stability_summary

OUT = pathlib.Path("outputs/mdhg"); OUT.mkdir(parents=True, exist_ok=True)

def main():
    eps = ['ep-demo'] + [f'epS{i}' for i in range(10)]
    rows = []
    for ep in eps:
        s = stability_summary(ep)
        rows.append(s)
    # HTML
    html = OUT / "report.html"
    def row(s):
        return f"<tr><td>{s.get('endpoint')}</td><td>{s.get('n')}</td><td>{s.get('band')}</td><td>{s.get('drift')}</td><td>{s.get('tau'):.3f}</td><td>{s.get('delta'):.3f}</td><td>{s.get('mu'):.3f} [{s.get('ci')[0]:.3f},{s.get('ci')[1]:.3f}]</td></tr>"
    table = "\n".join(row(s) for s in rows)
    html.write_text(f"""
<html><body><h3>MDHG Stability Report</h3>
<table border='1'>
<tr><th>endpoint</th><th>n</th><th>band</th><th>drift</th><th>tau</th><th>delta</th><th>mean [CI]</th></tr>
{table}
</table>
</body></html>
""", encoding='utf-8')
    print(html)

if __name__ == "__main__":
    main()
