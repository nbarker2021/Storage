
from .core import Agency, Job, register
from triads.morsr_wavepool.wave_pool import tick as wave_tick
from triads.assembly_line.run import run as assembly_run

class MorsrAgency(Agency):
    name = "morsr"
    def run(self, job: Job) -> dict:
        out = wave_tick(max_jobs=1)
        return {'ok': True, 'result': out}

class AssemblyAgency(Agency):
    name = "assembly"
    def run(self, job: Job) -> dict:
        res = assembly_run({'kind': job.kind, 'payload': job.payload})
        return {'ok': True, 'result': res}

def init():
    register(MorsrAgency())
    register(AssemblyAgency())
