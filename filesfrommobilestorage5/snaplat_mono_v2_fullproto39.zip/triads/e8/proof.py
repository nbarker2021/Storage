import sqlite3, time, json, pathlib
from triads.sap_snapops_archivist.archivist.cas import put
from utils.fs import atomic_write

DB = "rmi/snaplat.db"
IDX = pathlib.Path("outputs/index/e8")

def _conn():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    return con

def _octant_coverage(endpoint_id: str, horizon: int = 400):
    con = _conn(); cur = con.cursor()
    rows = cur.execute("SELECT octant FROM i8_topk WHERE choice_id=? ORDER BY created_at DESC LIMIT ?", (endpoint_id, horizon)).fetchall()
    s = sorted({int(r["octant"]) for r in rows})
    missing = [o for o in range(1,9) if o not in s]
    return s, missing

def generate_proof(endpoint_id: str, horizon: int = 400) -> dict:
    covered, missing = _octant_coverage(endpoint_id, horizon=horizon)
    rotation_ok = (len(covered) == 8)
    glyph = {
        "endpoint_id": endpoint_id,
        "created_at": int(time.time()*1000),
        "octants": covered,
        "missing": missing,
        "rotation_ok": rotation_ok,
        "horizon": horizon,
    }
    rec = {"kind":"e8_proof","endpoint_id": endpoint_id, "payload": glyph, "created_at": glyph['created_at']}
    h = put(rec)
    IDX.mkdir(parents=True, exist_ok=True)
    atomic_write(IDX / f"{endpoint_id}-{glyph['created_at']}.json", json.dumps({"cas_hash": h, **glyph}, sort_keys=True).encode("utf-8"))
    return {**glyph, "cas_hash": h}
