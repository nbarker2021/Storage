
import json, pathlib
from triads.agencies.queue import drain, mark_done
from triads.assembly_line.run import run as assembly_run
from triads.thinktank_dtt_assembly.thinktank.core import run_thinktank
from .morsr import run_wave

TRAILS = pathlib.Path('outputs/trails/trails.jsonl')

def recent_reasons(limit=200):
    rs = []
    if TRAILS.exists():
        for line in TRAILS.read_text(encoding='utf-8').splitlines()[-limit:]:
            try:
                rec = json.loads(line)
                if rec.get('kind') in ('safecube.check','assembly.blocked','mdhg.alert'):
                    payload = rec.get('payload',{})
                    rs.extend(payload.get('reasons',[]) or payload.get('issues',[]) or [])
            except Exception:
                pass
    return rs

def tick(max_jobs: int = 25):
    jobs = drain(max_jobs)
    out = []
    rs = recent_reasons()
    for j in jobs:
        ep = j.get('payload',{}).get('endpoint_id','ep-demo')
        dom = j.get('payload',{}).get('domain','governance')
        tt = run_thinktank(dom, rs)
        wave = run_wave(ep, dom, tt)
        res = assembly_run({**j, 'wave': wave})
        out.append({'endpoint': ep, 'domain': dom, 'wave': wave, 'assembly': res})
        mark_done({'job': j, 'result': out[-1]})
    return out
