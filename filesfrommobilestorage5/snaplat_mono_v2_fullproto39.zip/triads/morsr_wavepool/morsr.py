
from kernel.telemetry import emit
from .scoring import compose

def propose_mutations(hypotheses: list[str], wave_type: str) -> list[str]:
    muts = []
    for h in hypotheses:
        if wave_type == 'explore':
            muts += [f"{h} / novel source", f"{h} / new persona", f"{h} / alt algo"]
        elif wave_type == 'refine':
            muts += [f"{h} / param sweep", f"{h} / prompt tighten"]
        else:  # exploit
            muts += [f"{h} / scale up", f"{h} / cache+reuse"]
    out = []
    for m in muts:
        if m not in out:
            out.append(m)
        if len(out) >= 8: break
    return out

def select_wave_type(band: str, drift: bool, rotation_ok: bool) -> str:
    if drift or band == 'low':
        return 'explore'
    if band == 'high' and rotation_ok:
        return 'exploit'
    return 'refine'

def run_wave(endpoint_id: str, domain: str|None, thinktank: dict) -> dict:
    comp = compose(endpoint_id, domain)
    wave_type = select_wave_type(comp.get('band','low'), comp.get('drift', False), comp.get('rotation_ok', False))
    muts = propose_mutations(thinktank.get('hypotheses',[]), wave_type)
    cand = {
        'endpoint': endpoint_id,
        'wave_type': wave_type,
        'personas': thinktank.get('personas',[]),
        'hypotheses': muts,
        'score': comp['score'],
        'signals': comp,
    }
    emit('morsr.wave','morsr',{'endpoint': endpoint_id, 'wave': wave_type, 'score': comp['score']})
    return cand
