import time

def run_thinktank(domain: str|None, reasons: list[str]|None) -> dict:
    domain = (domain or 'general').lower()
    reasons = reasons or []
    personas = ["Generalist"]
    if domain in ('healthcare','medical'): personas += ["Clinician","Safety"]
    if domain in ('finance','fintech'): personas += ["Risk","Accounting"]
    if domain in ('education','edtech'): personas += ["Researcher","Teacher"]
    # Feedback: include Compliance persona if policy reasons frequent
    if any(r.startswith('law.') or 'finalize.' in r for r in reasons):
        personas.append("Compliance")
    personas = sorted(set(personas))
    # Hypothesis/dichotomy stubs (could be driven by reasons)
    hypos = [f"{domain}: top-K rotation improvement", f"{domain}: evidence density increase"]
    dichos = ["strict vs lenient policy", "high-stability vs high-coverage"]
    return {"personas": personas, "hypotheses": hypos, "dichotomies": dichos, "t": int(time.time()*1000)}
