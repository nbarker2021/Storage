def capacity_ok(env: dict, budgets: dict) -> (bool, list):
    reasons = []
    gpu = env.get("gpu_mem_gb", 8); need_gpu = budgets.get("gpu_mem_gb", 1)
    if need_gpu > gpu: reasons.append("gpu.mem.insufficient")
    io = env.get("io_mb_s", 200); need_io = budgets.get("io_mb_s", 50)
    if need_io > io: reasons.append("io.bandwidth.insufficient")
    return (len(reasons) == 0, reasons)
