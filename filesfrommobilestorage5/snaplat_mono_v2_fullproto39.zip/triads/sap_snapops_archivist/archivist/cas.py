import json, hashlib, pathlib, time

ROOT = pathlib.Path("outputs/cas")

def _shard(h: str) -> pathlib.Path:
    return ROOT / h[:2] / h[2:4]

def put(obj: dict) -> str:
    ROOT.mkdir(parents=True, exist_ok=True)
    blob = json.dumps(obj, sort_keys=True, separators=(',',':')).encode('utf-8')
    h = hashlib.sha256(blob).hexdigest()
    shard = _shard(h)
    shard.mkdir(parents=True, exist_ok=True)
    p = shard / f"{h}.json"
    if not p.exists():
        p.write_bytes(blob)
    return h
