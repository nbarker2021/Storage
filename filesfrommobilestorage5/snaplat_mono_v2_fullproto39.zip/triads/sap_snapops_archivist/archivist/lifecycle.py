import json, time, pathlib, sqlite3
from kernel.telemetry import emit
from kernel.authz import guard_write
from .cas import put
from utils.fs import atomic_write

STATE_DIR = pathlib.Path("outputs/index/state")
HIST_DIR = pathlib.Path("outputs/index/state/history")
LINEAGE_IDX = pathlib.Path("outputs/index/lineage")
DB = "rmi/snaplat.db"

ALLOWED = {
    "draft": {"finalized","retired"},
    "finalized": {"superseded","retired"},
    "superseded": {"retired"},
    "retired": set(),
}

def _conn():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    return con

def get_state(obj_id: str) -> str:
    p = STATE_DIR / f"{obj_id}.json"
    if not p.exists(): return "draft"
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("state","draft")
    except Exception:
        return "draft"

def set_state(obj_id: str, next_state: str) -> bool:
    cur = get_state(obj_id)
    if next_state not in ALLOWED.get(cur, set()):
        emit("archivist.state.denied","archivist",{"id":obj_id,"from":cur,"to":next_state})
        return False
    if not guard_write(context={"fn":"archivist.set_state","id":obj_id,"to":next_state}):
        emit("rbac.deny.write","archivist",{"fn":"set_state","id":obj_id,"to":next_state}); return False
    rec = {"id": obj_id, "state": next_state, "t": int(time.time()*1000)}
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    HIST_DIR.mkdir(parents=True, exist_ok=True)
    # write index
    atomic_write(STATE_DIR / f"{obj_id}.json", json.dumps(rec, sort_keys=True).encode("utf-8"))
    # append history
    hist = HIST_DIR / f"{obj_id}.jsonl"
    old = hist.read_bytes() if hist.exists() else b""
    atomic_write(hist, old + (json.dumps(rec)+"
").encode("utf-8"))
    emit("archivist.state","archivist",{"id":obj_id,"from":cur,"to":next_state})
    return True

def snapshot_lineage(endpoint_id: str) -> str:
    """Capture a small ego graph snapshot around endpoint and store in CAS; return CAS hash."""
    try:
        con = _conn(); cur = con.cursor()
        nodes = set([endpoint_id]); edges = []
        for r in cur.execute("SELECT src_id, dst_id, weight FROM lineage_edges WHERE src_id=? OR dst_id=?", (endpoint_id, endpoint_id)):
            s, d, w = r[0], r[1], float(r[2] or 0.0)
            edges.append({"src": s, "dst": d, "w": w})
            nodes.add(s); nodes.add(d)
        rec = {"kind":"lineage_snapshot","endpoint_id": endpoint_id, "created_at": int(time.time()*1000), "nodes": sorted(nodes), "edges": edges}
        h = put(rec)
        LINEAGE_IDX.mkdir(parents=True, exist_ok=True)
        atomic_write(LINEAGE_IDX / f"{endpoint_id}-{rec['created_at']}.json", json.dumps({"cas_hash": h, **rec}, sort_keys=True).encode("utf-8"))
        emit("archivist.snapshot","archivist", {"endpoint": endpoint_id, "nodes": len(nodes), "edges": len(edges), "cas": h})
        return h
    except Exception as e:
        emit("archivist.snapshot.error","archivist", {"endpoint": endpoint_id, "error": str(e)})
        return ""

def on_finalize(endpoint_id: str, manifest_cas: str) -> str:
    """Hook called after manifest finalize; snapshot lineage and return snapshot CAS."""
    snap = snapshot_lineage(endpoint_id)
    # transition endpoint lifecycle to finalized (idempotent-ish)
    set_state(endpoint_id, "finalized")
    emit("archivist.finalize","archivist", {"endpoint": endpoint_id, "manifest": manifest_cas, "snapshot": snap})
    return snap
