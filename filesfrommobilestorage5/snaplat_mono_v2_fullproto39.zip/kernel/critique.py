def critique(job_id: str, verdict: str, reasons=None):
    return {
        "job_id": job_id,
        "verdict": verdict,
        "reasons": reasons or [],
        "fix_suggestions": []
    }
