from kernel.db import get_conn, query

def ensure_indexes():
    conn = get_conn()
    # Trails fast paths
    query(conn, "CREATE INDEX IF NOT EXISTS idx_trails_kind ON trails(kind)", ())
    query(conn, "CREATE INDEX IF NOT EXISTS idx_trails_created ON trails(created_at)", ())
    # TopK current/history
    try:
        query(conn, "CREATE INDEX IF NOT EXISTS idx_i8_topk_choice ON i8_topk(choice_id)", ())
        query(conn, "CREATE INDEX IF NOT EXISTS idx_i8_topk_octant ON i8_topk(octant)", ())
    except Exception:
        pass
    # Lineage edges
    try:
        query(conn, "CREATE INDEX IF NOT EXISTS idx_lineage_src ON lineage_edges(src_id)", ())
        query(conn, "CREATE INDEX IF NOT EXISTS idx_lineage_dst ON lineage_edges(dst_id)", ())
    except Exception:
        pass
    return True
