import json, time, pathlib, os

TRAILS_DIR = pathlib.Path("outputs/trails")
TRAILS_DIR.mkdir(parents=True, exist_ok=True)
TRAILS = TRAILS_DIR / "trails.jsonl"

def emit(kind: str, thing: str, payload: dict):
    rec = {
        "kind": kind,
        "thing": thing,
        "payload": payload or {},
        "created_at": int(time.time()*1000)
    }
    with open(TRAILS, "a", encoding="utf-8") as fp:
        fp.write(json.dumps(rec) + "\n")
    return rec
