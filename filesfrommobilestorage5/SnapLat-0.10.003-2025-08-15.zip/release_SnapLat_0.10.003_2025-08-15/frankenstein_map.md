# Frankenstein Map — duplicate/near-duplicate function bodies
## Group of 2
- new_trace_id() — src/snaplat/telemetry/__init__.py
- new_span_id() — src/snaplat/telemetry/__init__.py
