
import time
from typing import Dict, Any
from agrm.utils.repo_ops import list_prefix
def save_hierarchy(repo, universe: str, snap: Dict[str,Any]) -> str:
    sid = f"mdhg::{universe}::{int(time.time())}"
    repo.save(sid, {"meta":{"snap_id": sid, "family":"mdhg","type":"layout","tags":{"universe":universe}}, "content": snap})
    return sid
def load_last_hierarchy(repo, universe: str) -> Dict[str,Any] | None:
    keys = list_prefix(repo, f"mdhg::{universe}::")
    if not keys: return None
    keys = sorted(keys)
    snap = repo.load(keys[-1])
    return snap.get("content") if isinstance(snap, dict) else None
