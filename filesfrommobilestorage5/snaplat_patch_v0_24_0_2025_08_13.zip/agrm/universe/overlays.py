
def attach_mdhg_overlay(um, universe: str, snap_id: str, label: str = None):
    u = um.get_universe(universe)
    arr = u.overlays.get("mdhg", [])
    arr = arr if isinstance(arr, list) else []
    arr.append(snap_id)
    u.overlays["mdhg"] = sorted(set(arr))
    um.save_universe(u)
def write_universe_diff(repo, universe: str, before, after):
    import time
    sid = f"universe_diff::{universe}::{int(time.time())}"
    repo.save(sid, {"meta":{"snap_id": sid, "family":"universe","type":"diff","tags":{"universe":universe}},
                    "content":{"before": before, "after": after}})
