
from typing import Dict, Any
import time
from agrm.utils.repo_ops import delete_prefix
def fresh_start(repo, um, universe: str, *, wipe: bool = True) -> Dict[str,Any]:
    deleted = 0
    if wipe:
        for pref in [f"mdhg::{universe}::", f"mdhg_event::{universe}::elevator::", f"result::elevator::{universe}::", f"universe_diff::{universe}::", f"promotion_summary::{universe}::", f"iter_report::{universe}::"]:
            deleted += delete_prefix(repo, pref)
    sid = f"freshstart::{universe}::{int(time.time())}"
    repo.save(sid, {"meta":{"snap_id": sid, "family":"freshstart","type":"session","tags":{"universe":universe}}, "content":{"deleted": deleted, "wipe": wipe}})
    u = um.get_universe(universe); u.overlays = {}; um.save_universe(u)
    return {"deleted": deleted, "session_id": sid}
