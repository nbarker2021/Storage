
from dataclasses import dataclass
from typing import Dict, Any, List
@dataclass
class Decision:
    allow: bool
    reason: str = ""
def check_policy(policy: Dict[str,Any] | None, criteria: Dict[str,Any]) -> Decision:
    if not policy: return Decision(True, "no_policy")
    fam_deny: List[str] = policy.get("family_deny", [])
    fam_allow: List[str] = policy.get("family_allow", [])
    fams = criteria.get("family") or []
    if isinstance(fams, str): fams = [fams]
    if fam_deny and any(f in fam_deny for f in fams if f):
        return Decision(False, "family_deny")
    if fam_allow and not any(f in fam_allow for f in fams if f):
        return Decision(False, "family_not_allowed")
    return Decision(True, "ok")
