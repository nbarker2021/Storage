
from typing import List
def list_prefix(repo, prefix: str) -> List[str]:
    if hasattr(repo, "list"):
        try:
            return list(map(str, repo.list(prefix)))
        except Exception:
            pass
    if hasattr(repo, "store"):
        return [k for k in repo.store.keys() if str(k).startswith(prefix)]
    if hasattr(repo, "keys"):
        return [k for k in repo.keys() if str(k).startswith(prefix)]
    return []
def delete_prefix(repo, prefix: str) -> int:
    deleted = 0
    if hasattr(repo, "delete_prefix"):
        try: return int(repo.delete_prefix(prefix))
        except Exception: pass
    if hasattr(repo, "store"):
        for k in list(repo.store.keys()):
            if str(k).startswith(prefix):
                try: del repo.store[k]; deleted += 1
                except Exception: pass
    return deleted
