
from typing import Dict, Any, Iterable
from agrm.snap.ops_center import SnapOpsCenter
from agrm.utils.repo_ops import list_prefix
def _iter_elevator_events(repo, universe: str):
    pref = f"mdhg_event::{universe}::elevator::"
    keys = list_prefix(repo, pref)
    events = []
    for k in keys:
        try:
            rec = repo.load(k)
            if rec.get("meta",{}).get("family")=="mdhg_event":
                events.append(rec)
        except Exception:
            pass
    return events
def promote_elevators(repo, um, universe: str, *, threshold: float=1.0, compat_policy: Dict[str,Any]=None) -> Dict[str,Any]:
    ops = SnapOpsCenter(elevator_threshold=threshold, compat_policy=compat_policy or {})
    events = _iter_elevator_events(repo, universe)
    promoted, rejected = 0, 0
    results = []
    for ev in events:
        cand = ev.get("content", {})
        sc = ev.get("meta", {}).get("tags", {}).get("score", 0.0)
        dec = ops.review_elevator({**cand, "score": sc})
        if dec.promoted:
            promoted += 1
            rid = f"result::elevator::{universe}::{promoted}"
            repo.save(rid, {"meta":{"snap_id": rid, "family":"result","type":"mdhg_elevator","tags":{"universe":universe}},
                            "content": cand})
            results.append(rid)
            try:
                u = um.get_universe(universe)
                ov = u.overlays.get("elevators", [])
                ov.append(rid); u.overlays["elevators"] = sorted(set(ov)); um.save_universe(u)
            except Exception: pass
        else:
            rejected += 1
    return {"promoted": promoted, "rejected": rejected, "results": results}
