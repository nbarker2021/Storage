
from typing import Dict, Any
import numpy as np
def simulate_sweeps(points: np.ndarray, rounds: int = 2, x: int = 8) -> Dict[str,Any]:
    # Simple pseudo-sweep: for each round, connect each point to its nearest neighbor in a random projection
    n = points.shape[0]
    rng = np.random.default_rng(1234)
    edges = {}
    for r in range(rounds):
        dirs = rng.normal(size=(x, points.shape[1]))
        dirs /= np.linalg.norm(dirs, axis=1, keepdims=True) + 1e-9
        for d in dirs:
            proj = points.dot(d)
            order = np.argsort(proj)
            # connect neighbors in projection order
            for i in range(n-1):
                a = int(order[i]); b = int(order[i+1])
                if a==b: continue
                key = (a,b) if a<b else (b,a)
                edges[key] = edges.get(key, 0) + 1
    return {"rounds": rounds, "arms": list(range(x)), "heat": {"edges": {str(k): v for k,v in edges.items()}, "rooms": {}}}
