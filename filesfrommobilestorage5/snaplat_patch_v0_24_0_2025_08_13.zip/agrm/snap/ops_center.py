
from dataclasses import dataclass
from typing import Dict, Any
@dataclass
class ElevatorDecision:
    staged: bool
    promoted: bool
    reason: str
class SnapOpsCenter:
    def __init__(self, elevator_threshold: float = 0.5, compat_policy: Dict[str,Any] = None):
        self.th = float(elevator_threshold); self.compat = compat_policy or {}
    def review_elevator(self, candidate: Dict[str,Any]) -> ElevatorDecision:
        fam_deny = set(self.compat.get("family_deny", []))
        fam_allow = set(self.compat.get("family_allow", []))
        fA = (candidate.get("roomA") or {}).get("family")
        fB = (candidate.get("roomB") or {}).get("family")
        fams = {f for f in [fA,fB] if f}
        if fam_deny and any(f in fam_deny for f in fams):
            return ElevatorDecision(True, False, "family_denied")
        if fam_allow and not any(f in fam_allow for f in fams):
            return ElevatorDecision(True, False, "family_not_allowed")
        sc = float(candidate.get("score", 0.0))
        return ElevatorDecision(True, sc >= self.th, "score_gate" if sc < self.th else "ok")
