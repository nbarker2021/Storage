
# MDHG Hierarchy — Buildings, Floors, Rooms

This module introduces a concrete hierarchy for MDHG:
- **Building** → top-level container for a lattice neighborhood
- **Floor** → partitions within a building
- **Room** → capacity-bounded subsets of indices; receive heat and split when hot/oversized
- **Elevators** → cross-room (or cross-floor) connections created when edge heat between rooms exceeds thresholds

## API
```python
from agrm.mdhg.hierarchy import HierarchyManager, HierarchyParams

hm = HierarchyManager(HierarchyParams(room_capacity=64, max_rooms_per_floor=8))
hm.build_initial(N)                 # shard N indices into rooms
hm.apply_heat(heat_snapshot)        # incorporate edge heat; split rooms; create elevators
snap = hm.snapshot()                # floors, rooms, elevators, events
```

## Controller Integration
The controller now computes sweeps + heat and builds a transient hierarchy per run:
- `summary['mdhg']` includes floors, rooms, and elevators.
- Next step: persist hierarchy changes as SNAPs and reuse across runs.
