
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import math

RoomID = Tuple[int,int,int]  # (building, floor, room)

@dataclass
class Room:
    id: RoomID
    indices: List[int] = field(default_factory=list)
    heat: int = 0

@dataclass
class Floor:
    building: int
    level: int
    rooms: List[Room] = field(default_factory=list)

@dataclass
class Building:
    id: int
    floors: List[Floor] = field(default_factory=list)

@dataclass
class HierarchyParams:
    room_capacity: int = 64
    max_rooms_per_floor: int = 8
    heat_split_threshold: int = 128
    elevator_cross_floor_threshold: int = 12  # cross-floor edges required to create elevator
    elevator_cross_room_threshold: int = 18   # cross-room edges (same floor) to create elevator

class HierarchyManager:
    def __init__(self, params: HierarchyParams | None = None):
        self.params = params or HierarchyParams()
        self.buildings: List[Building] = []
        self.index_room: Dict[int, RoomID] = {}
        self.elevators: List[Tuple[RoomID, RoomID]] = []
        self.events: List[Dict[str,Any]] = []

    # ---------- construction ----------
    def build_initial(self, N: int):
        """Create a single building with floor 0, rooms sized by capacity."""
        cap = max(1, int(self.params.room_capacity))
        b = Building(id=0, floors=[Floor(building=0, level=0, rooms=[])])
        rcount = math.ceil(N / cap)
        idx = 0
        for r in range(rcount):
            take = list(range(idx, min(N, idx+cap)))
            rid = (0,0,r)
            room = Room(id=rid, indices=take, heat=0)
            b.floors[0].rooms.append(room)
            for i in take:
                self.index_room[i] = rid
            idx += len(take)
        self.buildings = [b]
        self.events.append({"event":"build_initial","rooms": rcount,"N":N})

    def snapshot(self) -> Dict[str,Any]:
        floors = []
        rooms = []
        for b in self.buildings:
            for f in b.floors:
                floors.append({"building": b.id, "floor": f.level, "rooms": len(f.rooms)})
                for r in f.rooms:
                    rooms.append({"id": r.id, "size": len(r.indices), "heat": r.heat})
        return {"floors": floors, "rooms": rooms, "elevators": [(a,b) for a,b in self.elevators], "events": list(self.events)}

    # ---------- updates from heat ----------
    def apply_heat(self, heat_snapshot: Dict[str,Dict]):
        # Edge heat provided as {(i,j): count}; bump room heat
        edges: Dict[Tuple[int,int], int] = {tuple(map(int,k.strip('()').split(', '))): v for k,v in heat_snapshot.get("edges", {}).items()}                                            if isinstance(next(iter(heat_snapshot.get("edges",{})), ()), str) else heat_snapshot.get("edges", {})
        # bump room heat
        for (a,b), w in edges.items():
            ra = self.index_room.get(a)
            rb = self.index_room.get(b)
            if ra: self._room_by_id(ra).heat += int(w)
            if rb and rb != ra: self._room_by_id(rb).heat += int(w)

        # detect cross connections to create elevators
        cross_count: Dict[Tuple[RoomID, RoomID], int] = {}
        for (a,b), w in edges.items():
            ra = self.index_room.get(a)
            rb = self.index_room.get(b)
            if not ra or not rb or ra == rb:
                continue
            key = (ra, rb) if ra < rb else (rb, ra)
            cross_count[key] = cross_count.get(key, 0) + int(w)

        for (ra, rb), cnt in cross_count.items():
            af, bf = ra[1], rb[1]
            if af != bf and cnt >= self.params.elevator_cross_floor_threshold:
                self._add_elevator(ra, rb, cnt, reason="cross_floor")
            elif af == bf and cnt >= self.params.elevator_cross_room_threshold:
                self._add_elevator(ra, rb, cnt, reason="cross_room")

        # split hot or oversized rooms
        for b in self.buildings:
            for f in b.floors:
                new_rooms: List[Room] = []
                for room in list(f.rooms):
                    if room.heat >= self.params.heat_split_threshold or len(room.indices) > self.params.room_capacity:
                        # split into two rooms
                        half = max(1, len(room.indices)//2)
                        left = room.indices[:half]
                        right = room.indices[half:]
                        f.rooms.remove(room)
                        rida = (b.id, f.level, max([r.id[2] for r in f.rooms], default=-1) + 1)
                        ridb = (b.id, f.level, rida[2] + 1)
                        ra = Room(id=rida, indices=left, heat=room.heat//2)
                        rb = Room(id=ridb, indices=right, heat=room.heat//2)
                        new_rooms.extend([ra, rb])
                        for i in left: self.index_room[i] = rida
                        for i in right: self.index_room[i] = ridb
                        self.events.append({"event":"room_split","from":room.id,"to":[rida,ridb],"reason":"heat_or_size"})
                f.rooms.extend(new_rooms)
                # if too many rooms on this floor, spill to a new floor
                while len(f.rooms) > self.params.max_rooms_per_floor:
                    # move half of rooms to a new floor
                    move = f.rooms[self.params.max_rooms_per_floor:]
                    f.rooms = f.rooms[:self.params.max_rooms_per_floor]
                    nf = Floor(building=b.id, level=f.level+1, rooms=[])
                    for r in move:
                        # update room ids to new floor
                        rid = (b.id, nf.level, r.id[2])
                        nf.rooms.append(Room(id=rid, indices=r.indices, heat=r.heat))
                        for i in r.indices: self.index_room[i] = rid
                    b.floors.append(nf)
                    self.events.append({"event":"floor_split","from":f.level,"to":nf.level,"moved_rooms":len(move)})

    # ---------- helpers ----------
    def _room_by_id(self, rid: RoomID) -> Room:
        b = self.buildings[rid[0]]
        for f in b.floors:
            if f.level == rid[1]:
                for r in f.rooms:
                    if r.id == rid:
                        return r
        raise KeyError(rid)

    def _add_elevator(self, a: RoomID, b: RoomID, cnt: int, reason: str):
        pair = (a,b) if a < b else (b,a)
        if pair not in self.elevators:
            self.elevators.append(pair)
            self.events.append({"event":"elevator","a":a,"b":b,"count":cnt,"reason":reason})
