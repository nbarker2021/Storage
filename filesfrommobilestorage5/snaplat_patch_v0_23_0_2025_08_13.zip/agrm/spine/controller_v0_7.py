
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
import time
import numpy as np
from typing import Dict, Any, List, Optional

from agrm.policy.policy_bus import check_policy
from agrm.agrm.sweeps import simulate_sweeps
from agrm.mdhg.hierarchy import HierarchyManager, HierarchyParams
from agrm.mdhg.persistence import save_hierarchy, load_last_hierarchy
from agrm.universe.overlays import attach_mdhg_overlay, write_universe_diff

def _summary(points: np.ndarray) -> Dict[str,Any]:
    return {"N": int(points.shape[0]), "dims": int(points.shape[1]) if points.ndim==2 else 0}

def _inv_str(glyph_str: Optional[str]) -> Optional[str]:
    if not glyph_str: return None
    parts = glyph_str.split("::")
    return "::".join([("¬"+p) if not p.startswith("¬") else p[1:] for p in parts])

class AGRMController_v0_7_2025_08_13:
    def __init__(self, cfg: Dict[str,Any] = None, repo=None, policies: Dict[str,Any] = None, um=None):
        self.cfg = cfg or {}
        self.repo = repo
        self.policies = policies or {}
        self.um = um

    def solve(self, points: np.ndarray, max_ticks:int=1, metas: Optional[List[Dict[str,Any]]] = None) -> Dict[str,Any]:
        dec = check_policy(self.policies, {"family": self.cfg.get("family", []), "type": self.cfg.get("type", []), "tags": self.cfg.get("tags", {})})
        if not dec.allow:
            return {"ok": False, "reason": dec.reason}
        summary = {"N": int(points.shape[0]), "dims": int(points.shape[1]) if points.ndim==2 else 0}
        telemetry = {"candidates_emitted": 0, "candidates_blocked": 0, "policy_blocks": 0}

        if bool(self.cfg.get("use_sweeps_full", False)) and points.size>0:
            out = simulate_sweeps(points, rounds=int(self.cfg.get("rounds",2)), x=int(self.cfg.get("arms",8)))
            summary["sweeps_full"] = {"rounds": out["rounds"], "arms": out["arms"]}
            heat_snapshot = out["heat"]
        else:
            summary["sweeps_full"] = {"rounds": 0, "arms": []}
            heat_snapshot = {"edges": {}, "rooms": {}}

        mdhg_cfg = self.cfg.get("mdhg", {}) if isinstance(self.cfg.get("mdhg", {}), dict) else {}
        params = HierarchyParams(
            room_capacity     = int(mdhg_cfg.get("room_capacity", 64)),
            max_rooms_per_floor = int(mdhg_cfg.get("max_rooms_per_floor", 8)),
            heat_split_threshold = float(mdhg_cfg.get("heat_split_threshold", 128)),
            elevator_cross_floor_threshold = float(mdhg_cfg.get("elevator_cross_floor_threshold", 12)),
            elevator_cross_room_threshold  = float(mdhg_cfg.get("elevator_cross_room_threshold", 18)),
            decay_half_life_hours = float(mdhg_cfg.get("decay_half_life_hours", 24.0)),
            policy_for_split = mdhg_cfg.get("split_policy", None),
            promote_elevators = bool(mdhg_cfg.get("promote_elevators", False)),
            elevator_score_min = float(mdhg_cfg.get("elevator_score_min", 0.5)),
        )
        universe = self.cfg.get("universe", "default")
        hm = HierarchyManager(params=params)

        last = None
        if self.repo is not None and bool(mdhg_cfg.get("persist", True)):
            last = load_last_hierarchy(self.repo, universe)
        if last:
            hm.rebuild_from_snapshot(last)
        else:
            hm.build_initial(summary["N"])

        if metas:
            hm.tag_rooms_from_metas(metas)
        hm.apply_heat(heat_snapshot, policies=params.policy_for_split)
        mdhg_snap = hm.snapshot()

        snap_id = None
        if self.repo is not None:
            if bool(mdhg_cfg.get("persist", True)):
                try:
                    snap_id = save_hierarchy(self.repo, universe, mdhg_snap)
                    summary["mdhg_snap_id"] = snap_id
                except Exception:
                    pass
                if self.um is not None and snap_id:
                    try:
                        u = self.um.get_universe(universe)
                        before_overlays = dict(u.overlays)
                        attach_mdhg_overlay(self.um, universe, snap_id, label="mdhg_layout")
                        after_overlays = self.um.get_universe(universe).overlays
                        write_universe_diff(self.repo, universe, before_overlays, after_overlays)
                    except Exception:
                        pass
            else:
                try:
                    snap_id = f"mdhg::{universe}::ephemeral::{int(time.time())}"
                    self.repo.save(snap_id, {"meta":{"snap_id": snap_id, "family":"mdhg_ephemeral","type":"layout","tags":{"universe":universe}},
                                             "content": mdhg_snap})
                    summary["mdhg_snap_id"] = snap_id
                except Exception:
                    pass

            # Emit candidates (increment only after successful save)
            rooms_by_id = {tuple(r["id"]): r for r in mdhg_snap.get("rooms",[])}
            for (a,b) in mdhg_snap.get("elevators", []):
                ra = rooms_by_id.get(tuple(a), {}); rb = rooms_by_id.get(tuple(b), {})
                roomA = {"id": a, "family": (ra.get("tags") or {}).get("family"), "type": (ra.get("tags") or {}).get("type"), "glyph": (ra.get("tags") or {}).get("glyph")}
                roomB = {"id": b, "family": (rb.get("tags") or {}).get("family"), "type": (rb.get("tags") or {}).get("type"), "glyph": (rb.get("tags") or {}).get("glyph")}
                score = 0.0
                try:
                    score = (hm.elevator_scores.get((tuple(a),tuple(b))) or hm.elevator_scores.get((tuple(b),tuple(a))) or 0.0)
                except Exception:
                    pass
                invA = _inv_str(roomA.get("glyph"))
                invB = _inv_str(roomB.get("glyph"))
                ev_id = f"mdhg_event::{universe}::elevator::{a}->{b}::{int(time.time())}"
                try:
                    self.repo.save(ev_id, {"meta":{"snap_id": ev_id, "family":"mdhg_event","type":"elevator_candidate",
                                                   "tags":{"universe":universe,"score":float(score)}},
                                           "content":{"roomA": roomA, "roomB": roomB, "inverseA": invA, "inverseB": invB, "mdhg_snap": snap_id}})
                    telemetry["candidates_emitted"] += 1
                except Exception:
                    # keep going but don't increment
                    pass

        try:
            from agrm.utils.run_manifest import write_run_manifest
            write_run_manifest(self.repo, component="controller", params=self.cfg, inputs={"N": summary["N"]}, policies=self.policies)
        except Exception:
            pass

        telemetry["policy_blocks"] = sum(1 for e in mdhg_snap.get("events", []) if e.get("event") == "room_split_blocked")
        summary["mdhg"] = {"floors": mdhg_snap["floors"], "rooms": mdhg_snap["rooms"], "elevators": mdhg_snap["elevators"]}
        summary["telemetry"] = telemetry
        summary["ok"] = True
        return summary
