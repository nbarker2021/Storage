
# FreshStart & Iterative Orchestration (v0.23.0)

## FreshStart
```python
from agrm.orchestrator.freshstart import fresh_start
fresh_start(repo, um, "DocUniverse", wipe=True)
```
- Best-effort deletion of prior MDHG snapshots, events, results, and diffs.
- Resets universe overlays and records a `freshstart::...` SNAP.

## IterativeRunner
```python
from agrm.orchestrator.iterate import run_iterations
report = run_iterations(points, metas, repo=repo, um=um, base_cfg=cfg, universe="DocUniverse",
                        max_iters=5, min_promoted=5, stability_eps=0.05,
                        promotion_threshold=0.5, compat_policy={"family_deny":["fiction"]})
```
- Runs controller → event emission → promotion in a loop.
- Stops when promotions meet minimum and **promotion rate stabilizes** within `stability_eps` (or `max_iters` reached).
- Writes `iter_report::...` SNAP with all iteration summaries.

## CLI
Provide `env.repo`, `env.um`, and `env.data` (with `points`, `metas`, `cfg`):
```bash
python scripts/run_freshstart_iterations.py --universe DocUniverse --wipe --max-iters 5 --min-promoted 5 --stability-eps 0.05
```
