
from snaplat.e8.shells import shell, oracle_count
from snaplat.e8.core import is_member

def _norm2(v): return sum(x*x for x in v)

def test_shell_m1_m2_m3_sizes_and_membership():
    for m in [1,2,3]:
        vecs = shell(m)
        assert len(vecs) == oracle_count(m)
        for v in vecs[:50]:
            assert abs(_norm2(v) - 2*m) < 1e-9
            assert is_member(v)
