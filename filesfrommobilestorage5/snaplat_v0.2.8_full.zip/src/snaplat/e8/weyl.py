
from typing import List, Iterable
from .core import reflect
from .roots import e8_roots

def apply_reflection(x: List[float], r_index: int) -> List[float]:
    r = e8_roots()[r_index % 240]
    return reflect(x, r)

def apply_sequence(x: List[float], seq: Iterable[int]) -> List[float]:
    y = list(x)
    for idx in seq:
        y = apply_reflection(y, idx)
    return y
