
# SNAPLAT — v19
Adds:
- Cross-modal precedence rules (operational vs reporting modes)
- Beacon policy with decay and SAP-approved overrides
- Partial trait lanes (per-trait lane; composite lane = min)
- Performance suite stubs (stitch latency, recall ratio, queue throughput)
