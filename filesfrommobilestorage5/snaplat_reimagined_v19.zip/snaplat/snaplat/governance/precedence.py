
# Two modes: operational vs reporting
OPERATIONAL = ["kernel","code","tables","text"]
REPORTING   = ["text","tables","code","kernel"]

def order(mode: str = "operational"):
    return OPERATIONAL if mode == "operational" else REPORTING
