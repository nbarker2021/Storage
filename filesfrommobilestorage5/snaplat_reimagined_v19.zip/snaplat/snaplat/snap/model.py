
from dataclasses import dataclass, field
from typing import Dict, Any

@dataclass
class SNAP:
    sid: str
    type_id: str
    seeds: Dict[str, Any] = field(default_factory=dict)
    traits: Dict[str, Any] = field(default_factory=dict)
    trait_lanes: Dict[str, str] = field(default_factory=dict)  # per-trait
    lane: str = "shadow"  # composite
    provenance: Dict[str, Any] = field(default_factory=dict)
    stitch_plan: Dict[str, Any] = field(default_factory=dict)
