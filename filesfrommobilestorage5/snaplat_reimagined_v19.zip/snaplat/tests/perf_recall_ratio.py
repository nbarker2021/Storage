
def compute_recall_ratio(recalled: int, total: int) -> float:
    return 0.0 if total==0 else recalled/total
def test_recall_ratio():
    assert abs(compute_recall_ratio(80,100) - 0.8) < 1e-9
