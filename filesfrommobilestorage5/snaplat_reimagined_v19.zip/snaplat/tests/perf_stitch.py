
import time, random
def test_stitch_latency():
    start = time.time()
    time.sleep(0.01 + random.random()*0.01)  # stub simulate
    assert (time.time() - start) < 0.2
