
from collections import deque
def test_queue_throughput():
    q = deque()
    for i in range(1000): q.append(i)
    for _ in range(1000): q.popleft()
    assert len(q)==0
