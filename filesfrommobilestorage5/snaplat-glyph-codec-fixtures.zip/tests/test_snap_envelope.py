from snap.envelope import SnapEnvelope

def test_envelope_required_fields():
    s = """
    // minimal valid SNAP envelope
    {
      v: "snap0.1",
      id: "snap:test1",
      kind: "core",
      endpoint: "internal.retrieval",
      posture: "internal",
      universe: { name: "work", anchors: [0.5, 0.618, 1.0], transforms: ["proj:coxeter-30"] },
      meta: { created_at: "2025-08-16T20:00:00Z" },
      parents: [],
      glyph_cid: "blake3:deadbeef",
      mannequin_ref: "cas://m/test1.man.json5",
      contracts: { inputs: {}, outputs: {} },
      trails: { digest: "blake3:cafebabe", case_bundle: "cas://case/1" },
      case_bundle_ref: "cas://case/1",
      policy: { sap: ["sentinel-ok"], quarantine: false }
    }
    """
    env = SnapEnvelope.from_json5(s)
    env.validate()
