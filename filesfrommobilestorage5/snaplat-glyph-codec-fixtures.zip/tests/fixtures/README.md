# SNAP Fixtures (R&D)

This folder contains canonical JSON5+mannequin pairs used by DTT to validate:
- envelope required fields (endpoint, posture, case bundle, universe, mannequin link)
- sidecar mannequin with E8 representative state and Safe Cube faces
- promotion gates exercised by policy/experiment/dataset/registry examples
