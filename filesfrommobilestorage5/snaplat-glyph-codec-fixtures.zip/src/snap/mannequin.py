from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class E8State:
    coset: str
    shell_m: int
    rep: List[int]
    orientation: List[str] = field(default_factory=list)  # generator IDs
    projection: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SafeCube:
    faces: Dict[str, str]  # legal/technical/operational/ethical → "green|yellow|red"
    all_green: bool

@dataclass
class Mannequin:
    v: str
    snap_id: str
    e8_state: E8State
    universes: Dict[str, Any]
    snapshot: Dict[str, Any]
    invariants: Dict[str, float]
    decision_hash: str
    safe_cube: Optional[SafeCube] = None
    bridges: Optional[List[Dict[str, Any]]] = None

    def digest(self) -> str:
        # Simple digest over stable subset (placeholder):
        import json, hashlib
        stable = {
            "snap_id": self.snap_id,
            "rep": self.e8_state.rep,
            "shell_m": self.e8_state.shell_m,
            "universes": self.universes,
            "invariants": self.invariants,
        }
        return "md5:" + hashlib.md5(json.dumps(stable, sort_keys=True).encode()).hexdigest()
