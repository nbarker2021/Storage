from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json
import re

_JSON5_COMMENTS = re.compile(r"//.*?$|/\*.*?\*/", re.DOTALL | re.MULTILINE)
_TRAILING_COMMAS = re.compile(r",(\s*[}\]])")

def loads_json5(s: str) -> Dict[str, Any]:
    """Very small JSON5 subset: strip // and /* */ comments, remove trailing commas."""
    s2 = _JSON5_COMMENTS.sub("", s)
    s2 = _TRAILING_COMMAS.sub(r"\1", s2)
    return json.loads(s2)

@dataclass
class UniverseInfo:
    name: str
    anchors: List[float] = field(default_factory=list)
    transforms: List[str] = field(default_factory=list)
    bridges: Optional[Dict[str, List[float]]] = None  # {deficiency:[...], surplus:[...]}

@dataclass
class SnapEnvelope:
    v: str
    id: str
    kind: str  # core|dna|persona|bundle|remediation|registry_entry
    endpoint: str
    posture: str  # internal|safe|external
    universe: UniverseInfo
    meta: Dict[str, Any]
    parents: List[str]
    glyph_cid: str
    mannequin_ref: str
    contracts: Dict[str, Any]
    trails: Dict[str, Any]
    case_bundle_ref: str
    policy: Dict[str, Any]

    def validate(self) -> None:
        req = [self.v, self.id, self.kind, self.endpoint, self.posture, self.case_bundle_ref,
               self.glyph_cid, self.mannequin_ref]
        if any(x is None or (isinstance(x, str) and x.strip() == "") for x in req):
            raise ValueError("Missing required envelope fields")
        if self.kind not in {"core","dna","persona","bundle","remediation","registry_entry"}:
            raise ValueError("Invalid kind")
        if self.posture not in {"internal","safe","external"}:
            raise ValueError("Invalid posture")
        if self.universe.name not in {"user","work","document","gov"}:
            raise ValueError("Invalid universe")

    @staticmethod
    def from_json5(s: str) -> "SnapEnvelope":
        d = loads_json5(s)
        uni = d.get("universe", {})
        env = SnapEnvelope(
            v=d.get("v","snap0.1"), id=d["id"], kind=d["kind"], endpoint=d["endpoint"],
            posture=d["posture"], universe=UniverseInfo(name=uni.get("name"), anchors=uni.get("anchors",[]),
            transforms=uni.get("transforms",[]), bridges=uni.get("bridges")), meta=d.get("meta",{}),
            parents=d.get("parents",[]), glyph_cid=d.get("glyph_cid",""), mannequin_ref=d.get("mannequin_ref",""),
            contracts=d.get("contracts",{}), trails=d.get("trails",{}), case_bundle_ref=d.get("case_bundle_ref",""),
            policy=d.get("policy",{})
        )
        env.validate()
        return env
