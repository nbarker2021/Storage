from __future__ import annotations
from typing import Dict, Any, Tuple

def fixed_point_check(envelope_json5: str, mannequin_json5: str, reencode_func) -> Tuple[bool, Dict[str, Any]]:
    """Run SNAP→Glyph→SNAP and compare byte-equality of envelope & mannequin.
    reencode_func: callable that takes (envelope_json5, mannequin_json5) and returns (env2_json5, man2_json5)
    """
    env2, man2 = reencode_func(envelope_json5, mannequin_json5)
    ok = (env2 == envelope_json5) and (man2 == mannequin_json5)
    return ok, {"env_equal": env2 == envelope_json5, "man_equal": man2 == mannequin_json5}
