from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any

@dataclass
class Port:
    snap_id: str
    port: str  # e.g., retrieval.out
    dtype: str

@dataclass
class Wiring:
    edges: List[Dict[str, str]]  # {from:"snapA:retrieval.out", to:"snapB:ranker.in"}
    constraints: Dict[str, Any]  # {sheaf:{ rules:[...] }}

class SheafGuard:
    @staticmethod
    def check(wiring: Wiring) -> None:
        # Placeholder: enforce simple type compatibility on port suffixes
        for e in wiring.edges:
            f = e["from"].split(":")[-1].split(".")[-1]
            t = e["to"].split(":")[-1].split(".")[-1]
            if f == "out" and t != "in":
                raise ValueError("Port mismatch: out→!in")
        # TODO: evaluate constraints.sheaf rules
