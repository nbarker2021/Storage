
from __future__ import annotations
from typing import List, Dict, Any
from pathlib import Path
from .snapdna import SNAPDNA

DEFAULT_SNAPS = [
    dict(name="SNAPDocs", domain="Documentation", purpose="Parse, index, and weave document universes"),
    dict(name="SNAPEight", domain="E8-Lattice", purpose="Encode, project, and traverse E8 mappings"),
    dict(name="SNAPGovernance", domain="Governance", purpose="Apply SAP hooks and audit trails"),
    dict(name="SNAPBuild", domain="Build/Runtime", purpose="Env prep, wheels, and offline-first installs"),
]

def generate_snaps(out_dir: str, extra: List[Dict[str,Any]]|None=None) -> List[str]:
    dna = SNAPDNA(out_dir)
    specs = list(DEFAULT_SNAPS)
    if extra: specs.extend(extra)
    paths = []
    for s in specs:
        s = dna.new_spec(**s)
        paths.append(dna.emit_tool(s))
    return paths
