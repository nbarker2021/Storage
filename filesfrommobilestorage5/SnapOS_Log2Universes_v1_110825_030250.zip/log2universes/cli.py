
from __future__ import annotations
import argparse, json, sys, os
from .pipeline import generate_all

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--log', required=True, help='Path to session log file')
    ap.add_argument('--out', required=True, help='Output directory')
    args = ap.parse_args()
    text = open(args.log, 'r', encoding='utf-8', errors='ignore').read()
    paths = generate_all(text, args.out)
    print(json.dumps(paths, indent=2))

if __name__ == '__main__':
    main()
