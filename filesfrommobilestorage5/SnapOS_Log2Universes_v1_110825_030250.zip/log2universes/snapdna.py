
from __future__ import annotations
from typing import Dict, Any
from pathlib import Path

TEMPLATE = """# Auto-generated SNAP tool: {name}
# Domain: {domain}
# Purpose: {purpose}
SPEC = {spec}

def run(**kwargs):
    return {{"status": "ok", "tool": "{name}", "received": kwargs}}
"""

class SNAPDNA:
    def __init__(self, out_dir: str):
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)

    def new_spec(self, **kw) -> Dict[str, Any]:
        # minimal normalizer
        return {
            "name": kw.get("name"),
            "domain": kw.get("domain","General"),
            "purpose": kw.get("purpose","General-purpose SNAP"),
            "inputs": kw.get("inputs", {"query":"str","options":"dict"}),
            "outputs": kw.get("outputs", {"results":"list","meta":"dict"}),
            "governance": kw.get("governance", {"sap_hooks":["Sentinel:init","Arbiter:report","Porter:deliver"]})
        }

    def emit_tool(self, spec: Dict[str, Any]) -> str:
        name = spec["name"]
        code = TEMPLATE.format(name=name, domain=spec["domain"], purpose=spec["purpose"], spec=repr(spec))
        path = self.out_dir / f"{name}.py"
        path.write_text(code, encoding="utf-8")
        return str(path)
