
from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, Dict, Any, List

E8_DIM = 8
OU, GU, UU, EU, DU = "OU","GU","UU","EU","DU"

@dataclass
class E8Key:
    universe: str
    vec: Tuple[float, ...]
    shell: int
    tags: Tuple[str, ...] = ()
    provenance: Dict[str, Any] = None

class Shells:
    @staticmethod
    def l2_bucket(v: Tuple[float,...]) -> int:
        s = sum(x*x for x in v)
        if s == 0: return 0
        if s < 1e2: return 1
        if s < 1e4: return 2
        if s < 1e6: return 3
        return 4

def summarize(seq: Tuple[int, ...]) -> Tuple[float, ...]:
    if not seq: return (0.0,)*E8_DIM
    n = len(seq)
    mn = float(min(seq)); mx=float(max(seq)); sm=float(sum(seq))
    mean = sm/n
    var = sum((x-mean)**2 for x in seq)/n
    return (float(n), mn, mx, mean, var, float(seq[-1]), float(seq[0]), float(len(set(seq))))

def encode_text_to_e8(text: str, universe: str, tags=()):
    seq = tokseq(text)  # from utils via import
    v = summarize(seq)
    shell = Shells.l2_bucket(v)
    return E8Key(universe, v, shell, tuple(tags), {"source":"log2universes"})
