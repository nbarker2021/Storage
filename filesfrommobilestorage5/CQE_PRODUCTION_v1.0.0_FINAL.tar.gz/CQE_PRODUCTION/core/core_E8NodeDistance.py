class E8NodeDistance:
    """Distance from a point to E8 lattice nodes"""
    node_id: int
    coordinates: List[float]
    distance: float
    angular_separation: float
    modulo_form: str
