
<!doctype html><html><head><meta charset="utf-8"><title>24-Lattice Viewer</title>
<style> body{font-family:system-ui;background:#0a0a0a;color:#0ff;margin:0;padding:20px}
.grid{display:grid;grid-template-columns:repeat(6,1fr);gap:8px} .card{border:1px solid #0ff;padding:8px;border-radius:8px;background:#101820}
.badge{font-size:11px;opacity:.7}</style>
</head><body><h1>24‑Lattice Viewer</h1><div id="grid" class="grid"></div>
<script>
async function load(){ const res = await fetch('/api/tiles'); const data = await res.json(); const grid = document.getElementById('grid');
  grid.innerHTML=''; data.slice(0,24).forEach(t=>{ const d=document.createElement('div'); d.className='card'; d.innerHTML = `
    <div><strong>${t.name}</strong> <span class="badge">id=${t.id}</span></div>
    <div>dim: ${t.dimensions[0]}×${t.dimensions[1]} | boundary: ${t.boundary}</div>
    <div class="badge">Julia: ${t.julia_param.real}, ${t.julia_param.imag}</div>`; grid.appendChild(d); }); }
load();
</script></body></html>
