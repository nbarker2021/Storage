def test_weyl_reflection(e8_lattice):
    """Test Weyl reflection"""
    vector = np.array([1, 2, 3, 4, 5, 6, 7, 8], dtype=float)

    reflected = e8_lattice.weyl_reflect(vector, root_index=0)

    assert len(reflected) == 8
    assert not np.array_equal(reflected, vector)  # Should change

