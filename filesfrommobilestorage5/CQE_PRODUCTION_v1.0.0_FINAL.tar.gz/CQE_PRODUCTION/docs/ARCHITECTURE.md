# Architecture Overview: CQE Production System

## Core Philosophy

The CQE system is built on the principle that computation is fundamentally geometric. Its architecture is designed to exploit the inherent geometric symmetries of data and problems to achieve optimal solutions.

## High-Level Components

```
+---------------------------------------+
|           main.py (Entry Point)       |
+---------------------------------------+
|    Aletheia AI (Local Reasoning)      |
+---------------------------------------+
|      Tools (SpeedLight, Governance)   |
+---------------------------------------+
|      Apps (CA Tiles, Lattice Viewer)  |
+---------------------------------------+
|      Core (Lattices, Weyl, Moonshine) |
+---------------------------------------+
| Data (MonsterMoonshineDB, RAG Cards)  |
+---------------------------------------+
|      Tests (3 Test Harnesses)         |
+---------------------------------------+
```

### 1. Core Engine (`/core`)

-   **Function**: Provides the fundamental mathematical and geometric primitives.
-   **Key Modules**: `e8_lattice.py`, `niemeier_lattices.py`, `conservation.py`, `weyl_cartan.py`, `voa_moonshine.py`.

### 2. Tool Suite (`/tools`)

-   **Function**: High-level tools that use the core engine to perform complex analysis.
-   **Key Modules**: `speedlight_sidecar_plus_1.py` (the full SpeedLight engine), `core_CQEGovernanceEngine.py`.

### 3. Applications (`/apps`)

-   **Function**: Standalone applications for specific analytical tasks.
-   **Key Modules**: `ca_tile_generator.py`, `lattice_viewer.py`.

### 4. Aletheia AI (`/aletheia`)

-   **Function**: A local, stdlib-only AI reasoning engine.
-   **Key Modules**: `reasoning_engine.py`, `rag.py`, `embeddings.py`.

### 5. Data Layer (`/data`)

-   **Function**: The knowledge base of the system.
-   **Key Components**: `monster_moonshine_db/` (74 embeddings), `rag_cards/` (40 cards), `relationships.csv` (312 connections).

### 6. Test Suite (`/tests`)

-   **Function**: Ensures the integrity and correctness of the system.
-   **Key Modules**: `core_CQETestHarness.py`, `core_ComprehensiveTestSuite.py`.

A typical request follows the 8-fold path of maximal organization:

1.  **State Definition**: Prune solution space.
2.  **Lattice Simulation**: Simulate 24 perspectives.
3.  **CA Analysis**: Analyze data density.
4.  **SpeedLight**: Find equivalence classes.
5.  **Embedding Retrieval**: Look up similar problems in MonsterMoonshineDB.
6.  **Governance**: Evaluate ethics and responsibility.
7.  **Synthesis**: Aletheia AI synthesizes a unified solution.
8.  **Meta-Observer**: The process itself is recognized as the solution (toroidal wrap).

This architecture ensures that every solution is geometrically optimal, computationally efficient, and ethically sound.
