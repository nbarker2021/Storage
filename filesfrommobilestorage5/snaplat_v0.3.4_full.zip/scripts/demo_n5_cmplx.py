
from snaplat.config import Config
from snaplat.agrm.factory import get_planner
from snaplat.agrm.simple import AGRMState
from snaplat.superperm.c8 import produce_c8, C8Config
from snaplat.dtt.harness import DTT, DTTConfig
from snaplat.assembly.core import stitch
from snaplat.sap.core import evaluate
from snaplat.morsr.log import MORSR
def main():
    cfg = Config(agrm="cmplx")
    planner = get_planner(cfg.agrm)
    cands = produce_c8(C8Config(seed=123))
    dtt = DTT(DTTConfig(seed=99))
    ev = dtt.run(cands)
    out = stitch(cands, ev)
    plan = planner.plan(AGRMState(step=2, tac=0.4))
    extra = {k: v for k, v in (plan.get('notes', {}) or {}).items() if k.startswith('fastlane')}
    verdict = evaluate([e.__dict__ for e in ev], diversity=8, extra_notes=extra)
    morsr = MORSR("artifacts/morsr/session.jsonl")
    morsr.emit({'event': 'run', 'verdict': verdict.__dict__, 'dna_checksum': out['DNA'].checksum, 'fastlane': extra})
    print("AGRMs:", cfg.agrm, "| plan:", plan)
    print("SAP:", verdict.decision, verdict.reasons)
    print("DNA:", out["DNA"].checksum)
if __name__ == "__main__":
    main()
