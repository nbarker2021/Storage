
from __future__ import annotations
from typing import List, Tuple, Dict, Any
import math, collections

class BraidWord:
    __slots__ = ("n", "gens")
    def __init__(self, n: int, gens: List[Tuple[int,int]] | None = None):
        self.n = int(n)
        self.gens = list(gens or [])

    def append(self, i: int, sign: int = 1) -> None:
        assert 1 <= i <= self.n - 1
        assert sign in (-1, 1)
        self.gens.append((i, sign))

    def extend(self, pairs: List[Tuple[int,int]]) -> None:
        for i,s in pairs: self.append(i,s)

    def copy(self) -> "BraidWord":
        return BraidWord(self.n, self.gens[:])

    def reduce(self) -> "BraidWord":
        out = []
        for i,s in self.gens:
            if out and out[-1][0] == i and out[-1][1] == -s:
                out.pop()
            else:
                out.append((i,s))
        self.gens = out
        return self

    def length(self) -> int:
        return len(self.gens)

    def entropy(self) -> float:
        if not self.gens: return 0.0
        cnt = collections.Counter(g for g,_ in self.gens)
        total = float(len(self.gens))
        H = 0.0
        for c in cnt.values():
            p = c/total
            H -= p*math.log(p+1e-12, 2)
        return H

    def to_permutation(self) -> List[int]:
        pi = list(range(self.n))
        for i, s in self.gens:
            j = i-1
            pi[j], pi[j+1] = pi[j+1], pi[j]
        return pi

    def apply_to_cycle(self, cycle: List[int], anchor_idx: int = 0) -> List[int]:
        if not cycle: return cycle
        inner = cycle[:-1]
        if not inner: return cycle
        # rotate order so anchor_idx leads
        try:
            anchor_pos = inner.index(anchor_idx)
        except ValueError:
            anchor_pos = 0
        order = inner[anchor_pos:] + inner[:anchor_pos]
        for i,_ in self.gens:
            j = i-1
            if 0 <= j < len(order)-1:
                order[j], order[j+1] = order[j+1], order[j]
        return order + [order[0]]

    def to_dict(self) -> Dict[str, Any]:
        return {"n": self.n, "gens": self.gens, "length": self.length(), "entropy": self.entropy()}

    def compress(self, max_window: int = 5, max_iters: int = 3) -> "BraidWord":
        """Lightweight reduction by commuting cancellation within a small window.
        Find s_i^±1 ... s_i^∓1 with only commuting generators s_j (|i-j|>1) between them, cancel pair.
        Repeat up to max_iters and finish with adjacent reduce().
        """
        for _ in range(max_iters):
            changed = False
            k = 0
            while k < len(self.gens):
                i, s = self.gens[k]
                lim = min(len(self.gens), k + 1 + max_window)
                found = -1
                for t in range(k+1, lim):
                    i2, s2 = self.gens[t]
                    if i2 == i and s2 == -s:
                        ok = True
                        for u in range(k+1, t):
                            j,_ = self.gens[u]
                            if abs(j - i) <= 1:
                                ok = False; break
                        if ok:
                            found = t
                        break
                if found != -1:
                    del self.gens[found]
                    del self.gens[k]
                    changed = True
                else:
                    k += 1
            if not changed:
                break
        return self.reduce()
