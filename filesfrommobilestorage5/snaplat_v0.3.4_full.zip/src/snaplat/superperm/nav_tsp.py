
from typing import List, Tuple, Dict, Any
import math
from ..e8.shells import root_shell
from ..e8.coxeter import get_projector
from ..tsp.solver import solve as tsp_solve, weighted_metric
from ..tsp.postman import eulerize_approx, euler_tour

def project_points(vs: List[List[float]]) -> List[Tuple[float,float]]:
    P = get_projector(); return [P(v) for v in vs]

def angles(pts): return [math.atan2(y, x) % (2*math.pi) for (x, y) in pts]

def sectorize(n_sectors, pts):
    ang = angles(pts); buckets = [[] for _ in range(n_sectors)]
    for idx, a in enumerate(ang):
        k = int((a / (2*math.pi)) * n_sectors) % n_sectors; buckets[k].append(idx)
    return buckets

def knn_graph(indices, pts, k=3):
    G = {i:{} for i in indices}
    for i in indices:
        xi, yi = pts[i]; dists = []
        for j in indices:
            if i==j: continue
            xj, yj = pts[j]; d = math.hypot(xi-xj, yi-yj); dists.append((d,j))
        dists.sort()
        for _, j in dists[:k]:
            dij = math.hypot(pts[i][0]-pts[j][0], pts[i][1]-pts[j][1])
            G[i][j]=dij; G[j][i]=dij
    return G

def tsp_on_root_shell(sample=None, heat=None, alpha: float=0.0):
    R = root_shell()
    if sample: R = R[:sample]
    pts2d = project_points(R)
    dist = weighted_metric(pts2d, heat=heat, alpha=alpha) if (alpha!=0.0 or heat) else None
    tour, length = tsp_solve(pts2d, start=0, dist=dist)
    return {"tour": tour, "length": length, "n": len(R)}

def sector_cpp_then_tsp(n_sectors=30, k=3, sample=None, heat=None, alpha: float=0.0):
    R = root_shell()
    if sample: R = R[:sample]
    pts2d = project_points(R)
    buckets = sectorize(n_sectors, pts2d)
    sector_paths = {}; anchors = []
    for s, idxs in enumerate(buckets):
        if not idxs: sector_paths[s]=[]; continue
        G = knn_graph(idxs, pts2d, k=k)
        start = idxs[0]; H = eulerize_approx(G); tour = euler_tour(H, start)
        sector_paths[s]=tour; anchors.append(start)
    anchor_pts = [pts2d[i] for i in anchors] if anchors else []
    dist = weighted_metric(anchor_pts, heat=[(heat[i] if heat else 0.0) for i in anchors], alpha=alpha) if anchors else None
    if anchors:
        cyc, L = tsp_solve(anchor_pts, start=0, dist=dist)
        ordered_nodes = []
        for idx in cyc[:-1]:
            s_anchor = anchors[idx]
            for s, p in sector_paths.items():
                if p and (p[0]==s_anchor or s_anchor in p):
                    ordered_nodes.extend(p); break
        full_len = L
    else:
        ordered_nodes=[]; full_len=0.0
    return {"ordered_nodes": ordered_nodes, "anchors": anchors, "anchor_cycle_len_proxy": full_len, "n": len(R)}


def tsp_on_points(pts2d, heat=None, alpha: float=0.0):
    dist = weighted_metric(pts2d, heat=heat, alpha=alpha) if (alpha!=0.0 or heat) else None
    tour, length = tsp_solve(pts2d, start=0, dist=dist)
    return {"tour": tour, "length": length, "n": len(pts2d)}

def sector_cpp_then_tsp_on_points(pts2d, n_sectors=30, k=3, heat=None, alpha: float=0.0):
    buckets = sectorize(n_sectors, pts2d)
    sector_paths = {}; anchors = []
    for s, idxs in enumerate(buckets):
        if not idxs: sector_paths[s]=[]; continue
        G = knn_graph(idxs, pts2d, k=k)
        start = idxs[0]; H = eulerize_approx(G); tour = euler_tour(H, start)
        sector_paths[s]=tour; anchors.append(start)
    anchor_pts = [pts2d[i] for i in anchors] if anchors else []
    dist = weighted_metric(anchor_pts, heat=[(heat[i] if heat else 0.0) for i in anchors], alpha=alpha) if anchors else None
    if anchors:
        cyc, L = tsp_solve(anchor_pts, start=0, dist=dist)
        ordered_nodes = []
        for idx in cyc[:-1]:
            s_anchor = anchors[idx]
            for s, p in sector_paths.items():
                if p and (p[0]==s_anchor or s_anchor in p):
                    ordered_nodes.extend(p); break
        full_len = L
    else:
        ordered_nodes=[]; full_len=0.0
    return {"ordered_nodes": ordered_nodes, "anchors": anchors, "anchor_cycle_len_proxy": full_len, "n": len(pts2d)}
