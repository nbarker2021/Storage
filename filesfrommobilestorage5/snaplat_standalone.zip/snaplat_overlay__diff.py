# Standalone export of snaplat.overlay.diff from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/overlay/diff.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""snaplat.overlay.diff — compare two result sets and render a compact diff."""
from __future__ import annotations
from typing import Any, Dict, List, Tuple

def _key(d: Dict[str, Any]) -> Any:
    return d.get("id") or d.get("title") or d.get("key")

def diff(a: List[Dict[str, Any]], b: List[Dict[str, Any]]) -> str:
    A = {_key(x): x for x in (a or [])}
    B = {_key(x): x for x in (b or [])}
    keys = set(A.keys()) | set(B.keys())
    lines: List[str] = []
    for k in sorted(keys, key=lambda x: str(x)):
        if k not in A:
            lines.append(f"+ {k}")
        elif k not in B:
            lines.append(f"- {k}")
        else:
            s1 = A[k].get("_score", 0.0)
            s2 = B[k].get("_score", 0.0)
            if abs(float(s1) - float(s2)) > 1e-6:
                lines.append(f"~ {k}  score: {s1:.3f} → {s2:.3f}")
    return "\n".join(lines)

__all__ = ["diff"]

