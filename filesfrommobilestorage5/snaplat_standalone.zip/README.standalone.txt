Standalone exports of SnapLat modules plus a monolith. These files bootstrap a minimal 'snaplat' package in sys.modules so imports resolve.
