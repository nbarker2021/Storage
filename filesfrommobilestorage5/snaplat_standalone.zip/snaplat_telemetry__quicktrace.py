# Standalone export of snaplat.telemetry.quicktrace from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/telemetry/quicktrace.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""snaplat.telemetry.quicktrace — timing helper built on telemetry.span."""
from __future__ import annotations
from typing import Any, Callable
import time
from . import span, log

class quicktrace:
    def __init__(self, label: str, **fields: Any):
        self.label = label
        self.fields = fields
        self.t0 = None
        self._span = None
    def __enter__(self):
        self.t0 = time.time()
        self._span = span(self.label, **self.fields)
        self._span.__enter__()
        return self
    def __exit__(self, exc_type, exc, tb):
        try:
            dur = int((time.time() - (self.t0 or time.time()))*1000)
            log({"event":"quicktrace","label":self.label,"duration_ms": dur})
        finally:
            if self._span:
                self._span.__exit__(exc_type, exc, tb)

def traced(label: str):
    def deco(fn: Callable[..., Any]):
        def wrapper(*a, **k):
            with quicktrace(label):
                return fn(*a, **k)
        return wrapper
    return deco

__all__ = ["quicktrace","traced"]

