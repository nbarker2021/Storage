# Standalone export of snaplat.overlay.__init__ from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/overlay/__init__.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""SnapLat overlay — simple renderer for results."""
from __future__ import annotations
from typing import Any, Dict, List
from snaplat import telemetry

def render(results: List[Dict[str, Any]] | Dict[str, Any]) -> str:
    with telemetry.span("overlay.render", kind="internal"):
            if isinstance(results, dict):
        # agent.route form {ok, results:[...]}
        hits = results.get("results", [])
    else:
        hits = results or []
    lines = []
            for i, h in enumerate(hits, 1):
        title = h.get("title") or h.get("id")
        score = h.get("_score", 0.0)
        lines.append(f"{i:02d}. {title}  (score={score:.3f})")
            return "\n".join(lines)

__all__ = ["render"]

