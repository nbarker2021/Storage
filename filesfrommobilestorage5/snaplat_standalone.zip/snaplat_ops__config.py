# Standalone export of snaplat.ops.config from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/ops/config.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""snaplat.ops.config — load JSON config and apply to subsystems (policy, rules, telemetry)."""
from __future__ import annotations
from typing import Any, Dict
import json, os
from snaplat.policy import rules as _rules
from snaplat import policy as _policy

def load(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def apply(cfg: Dict[str, Any]) -> None:
    # Policy denylist
    deny = cfg.get("policy", {}).get("denylist")
    if isinstance(deny, list):
        _policy.set_denylist([str(x).lower() for x in deny])
    # Rules: bounds + nonempty flag
    pr = cfg.get("policy", {}).get("rules", {})
    _rules.clear_rules()
    if pr.get("require_nonempty_query", True):
        _rules.add_rule("nonempty_query", lambda task: (len(str((task or {}).get("query","")).strip())>0, "empty_query"))
    tb = pr.get("top_k_bounds", {"min":1,"max":50})
    mn, mx = int(tb.get("min",1)), int(tb.get("max",50))
    _rules.add_rule("topk_bounds", lambda task: (mn <= int((task or {}).get("top_k",5)) <= mx, "top_k_out_of_bounds"))
    # Telemetry: dest path
    tel = cfg.get("telemetry", {}).get("log_path")
    if tel:
        os.environ["SNAPLAT_TELEMETRY_LOG"] = str(tel)

__all__ = ["load","apply"]

