# Standalone export of snaplat.agent.__init__ from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/agent/__init__.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""SnapLat agent — bootstrap + routing to index/search with policy + telemetry + rules + tracing."""
from __future__ import annotations
from typing import Any, Dict, List
from snaplat import policy, telemetry
from snaplat.telemetry import span, log
from snaplat.policy import rules as _rules
from snaplat import index as _index

_BOOT = {"ok": False}

def bootstrap(config: Dict[str, Any] | None = None) -> Dict[str, Any]:
    global _BOOT
    _BOOT = {"ok": True, "config": (config or {}), "version": 1}
    log({"event":"agent_bootstrap","ok":True})
    return dict(_BOOT)

def route(task: Dict[str, Any]) -> Dict[str, Any]:
    with span("agent.route"):
    """Route a task with a 'query' to index.search; returns results."""
            q = (task or {}).get("query","")
            if not policy.allowed(q):
        log({"event":"policy_block","query":q})
                return {"ok": False, "error": "blocked_by_policy"}
            rules_res = _rules.apply(task or {})
    if not rules_res.get("ok", False):
        log({"event":"rules_block","reasons": rules_res.get("reasons",[])})
                return {"ok": False, "error": "blocked_by_rules", "reasons": rules_res.get("reasons",[])}
            k = int((task or {}).get("top_k", 5))
    with span("index.search", query=q, top_k=k):
                results = _index.search(q, top_k=k, strategy=str((task or {}).get('strategy','tf')))
    log({"event":"agent_route","q":q,"count":len(results)})
            return {"ok": True, "results": results}

# optional: a simple router that dispatches to shell.sweep for batch tasks
def decide_and_run(task: Dict[str, Any]) -> Dict[str, Any]:
    mode = (task or {}).get("mode","route")
    if mode == "sweep":
        from snaplat import shell
        qs = (task or {}).get("queries") or [ (task or {}).get("query","") ]
        return shell.sweep(qs, top_k=int((task or {}).get("top_k",5)))
    return route(task)

__all__ = ["bootstrap","route","decide_and_run"]

