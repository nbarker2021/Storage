# Standalone export of snaplat.shell.__init__ from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/shell/__init__.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""SnapLat shell — sweep strategies that query the index."""
from __future__ import annotations
from typing import Any, Dict, List
from snaplat import telemetry
from snaplat import index as _index

def sweep(queries: List[str] | None = None, top_k: int = 5) -> Dict[str, Any]:
    with telemetry.span("shell.sweep", kind="internal", queries=len(queries or []), top_k=top_k):
            qs = queries or []
    out: List[Dict[str, Any]] = []
    for q in qs:
        out.append({"query": q, "hits": _index.search(q, top_k=top_k)})
    telemetry.log({"event":"shell_sweep","queries":len(qs)})
        return {"ok": True, "batches": out}

__all__ = ["sweep"]

