# Standalone export of snaplat.policy.__init__ from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/policy/__init__.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""SnapLat policy — minimal allow/deny checks for inputs."""
from __future__ import annotations
from typing import Iterable
import os

_DENY = set(w.strip().lower() for w in os.environ.get("SNAPLAT_DENYLIST","").split(",") if w.strip())
_ALLOW_ALL = os.environ.get("SNAPLAT_ALLOW_ALL","1") == "1"

def allowed(text: str) -> bool:
    if _ALLOW_ALL:
        return True
    t = (text or "").lower()
    return not any(bad in t for bad in _DENY)

def set_denylist(words):
    global _DENY
    _DENY = set(str(w).strip().lower() for w in (words or []))

def allow_all(flag: bool) -> None:
    global _ALLOW_ALL
    _ALLOW_ALL = bool(flag)

__all__ = ["allowed","set_denylist","allow_all"]


def get_denylist():
    return set(_DENY)

def matches_any(text: str):
    t = (text or '').lower()
    return [w for w in _DENY if w and w in t]

