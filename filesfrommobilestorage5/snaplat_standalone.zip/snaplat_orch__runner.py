# Standalone export of snaplat.orch.runner from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/orch/runner.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""SnapLat orchestrator runner — executes a minimal end-to-end flow with trace + strategy.
If a manifest is supplied, ingests docs then runs agent→shell→index→overlay.
"""
from __future__ import annotations
from typing import Any, Dict, List
from snaplat import agent, shell, index, overlay, telemetry

SAMPLE_DOCS = [
    {"id": "A1", "title": "Shelling strategies and hotmap", "text": "shelling sweep hotmap index graph"},
    {"id": "B2", "title": "Agent routing basics", "text": "agent routing controller task plan"},
    {"id": "C3", "title": "Metadata indexing", "text": "mdhg metadata index beacons"},
]

def run(manifest: Dict[str, Any] | None = None) -> List[Any]:
    steps: List[Any] = []
    man = manifest or {}
    docs = man.get("docs") or SAMPLE_DOCS
    strategy = man.get("strategy","tf")
    tid = telemetry.new_trace_id()
    with telemetry.trace(tid):
            with telemetry.span("orch.run", kind="internal"):
                        agent.bootstrap(man.get("agent", {}))
        index.clear()
        index.ingest(docs)
        q = man.get("query", "index")
        route_res = agent.route({"query": q, "top_k": man.get("top_k", 3), "strategy": strategy})
        steps.append(route_res)
        steps.append(shell.sweep([q], top_k=man.get("top_k", 3)))
        steps.append(route_res.get("results", []))
        steps.append(overlay.render(route_res))
        telemetry.log({"event":"orch_done"})
            return steps

