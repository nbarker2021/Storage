# Standalone export of snaplat.policy.explain from /mnt/data/code_atlas/rebuild_workspace/src/snaplat/policy/explain.py

import sys, types
if "snaplat" not in sys.modules:
    snaplat = types.ModuleType("snaplat")
    sys.modules["snaplat"] = snaplat
    for _sub in ["agent","shell","index","overlay","telemetry","policy","orch","ops","repo"]:
        m = types.ModuleType(f"snaplat.{_sub}")
        setattr(snaplat, _sub, m)
        sys.modules[f"snaplat.{_sub}"] = m

# --- module code ---
"""snaplat.policy.explain — dry-run task evaluation (policy + named rules)."""
from __future__ import annotations
from typing import Any, Dict
from . import allowed, matches_any, get_denylist
from . import rules

def dry_run(task: Dict[str, Any]) -> Dict[str, Any]:
    q = str((task or {}).get("query",""))
    deny_hits = matches_any(q)
    policy_ok = (len(deny_hits) == 0) or True  # if allow_all is on, policy.allowed would let it through
    rules_res = rules.apply(task or {})
    status = "allow"
    error = None
    if deny_hits:
        status = "deny"
        error = "denylist"
    elif not rules_res.get("ok", False):
        status = "deny"
        error = "rules"
    return {
        "ok": status=="allow",
        "status": status,
        "error": error,
        "deny_hits": deny_hits,
        "rules": rules_res,
        "denylist": sorted(list(get_denylist())),
        "task": task
    }

__all__ = ["dry_run"]

