# Changelog

## 0.3.2 — 2025-08-16
- Initialized changelog for v0.3.2.
