
from __future__ import annotations
from typing import List, Dict, Any, Tuple

def sector_labels(pts2d: List[Tuple[float,float]], n_sectors: int) -> List[int]:
    import math
    lab = []
    for (x,y) in pts2d:
        a = math.atan2(y,x) % (2*math.pi)
        lab.append(int((a/(2*math.pi))*n_sectors) % n_sectors)
    return lab

def shell_labels(m: int, n: int) -> List[int]:
    return [m]*n

def snap_cycle(cycle: List[int], snaps: List[str], anchor_idx: int, sector_of: List[int], shell_of: List[int], glyph_of: List[int]) -> List[int]:
    if not cycle: return cycle
    inner = cycle[:-1]
    if anchor_idx in inner:
        p = inner.index(anchor_idx)
        order = inner[p:] + inner[:p]
    else:
        order = inner[:]
    def key(u):
        k = []
        if "sector" in snaps: k.append(sector_of[u])
        if "shell" in snaps:  k.append(shell_of[u])
        if "glyph" in snaps:  k.append(glyph_of[u])
        k.append(u)
        return tuple(k)
    if any(s in snaps for s in ("sector","shell","glyph")):
        order = sorted(order, key=key)
    return order + [order[0]]

def apply_braid_setup(m: int, pts2d, cfg: Dict[str, Any]) -> Dict[str, Any]:
    n_sectors = int(cfg.get("n_sectors", 30))
    snaps = list(cfg.get("mdhg", {}).get("snap_types", ["anchor","sector"]))
    sector_of = sector_labels(pts2d, n_sectors)
    shell_of  = shell_labels(m, len(pts2d))
    from ..glyphs.glyphs import build_glyph_map
    glyph_of  = build_glyph_map(pts2d, n_glyph_sectors=max(60, n_sectors*2))
    return {"snaps": snaps, "sector_of": sector_of, "shell_of": shell_of, "glyph_of": glyph_of}
