
from typing import List, Tuple, Dict, Any
import math
from ..tsp.solver import tour_length, euclid

def coverage(cycle: List[int], n_total: int) -> float:
    return len(set(cycle[:-1])) / float(n_total) if (n_total and cycle) else 0.0

def drift_violations(cycle: List[int]) -> int:
    return 0

def entropy_of_sectors(cycle: List[int], pts2d: List[Tuple[float,float]], n_sectors: int = 30) -> float:
    if not cycle: return 0.0
    counts = [0]*n_sectors
    for idx in cycle[:-1]:
        x,y = pts2d[idx]; a = math.atan2(y,x) % (2*math.pi)
        s = int((a/(2*math.pi))*n_sectors) % n_sectors
        counts[s]+=1
    total = sum(counts) or 1
    ent = 0.0
    for c in counts:
        if c==0: continue
        p = c/total
        ent -= p*math.log(p+1e-12, 2)
    return ent

def window_coverage(cycle: List[int], k: int, n_total: int) -> float:
    if k <= 1 or not cycle: return 1.0
    seen = set()
    inner = cycle[:-1]
    L = len(inner)
    for i in range(L):
        if i+k <= L:
            window = tuple(inner[i:i+k])
        else:
            window = tuple(inner[i:] + inner[:(i+k-L)])
        seen.add(window)
    return len(seen) / float(L) if L else 0.0

def novelty(cycle: List[int], history: List[List[int]] | None = None) -> float:
    if not history: return 1.0 if cycle else 0.0
    prev = set()
    for h in history:
        prev.update(h[:-1])
    inner = set(cycle[:-1]) if cycle else set()
    new = len(inner - prev)
    return new / float(len(inner) or 1)

def scorecard_for_cycle(cycle: List[int], pts2d: List[Tuple[float,float]], k_window: int = 5, weights: Dict[str,float] | None = None) -> Dict[str, Any]:
    n = len(pts2d)
    d = euclid(pts2d)
    L = tour_length(cycle, d) if cycle else 0.0
    cov = coverage(cycle, n)
    drift = drift_violations(cycle)
    ent = entropy_of_sectors(cycle, pts2d, n_sectors=30)
    win = window_coverage(cycle, k_window, n)
    nov = novelty(cycle, history=None)
    scr = {"coverage": cov, "length": L, "entropy": ent, "drift_violations": drift, "window_coverage": win, "novelty": nov}
    W = weights or {"coverage":1.0, "entropy":0.2, "window_coverage":0.5, "novelty":0.3, "length":-0.001, "drift_violations":-1.0}
    total = (W.get("coverage",1.0)*cov + W.get("entropy",0.2)*ent + W.get("window_coverage",0.5)*win + W.get("novelty",0.3)*nov +
             W.get("length",-0.001)*(-L) + W.get("drift_violations",-1.0)*(-drift))
    scr["weighted_total"] = total; scr["weights"] = W
    return scr

def meets_acceptance(score: Dict[str, Any], thresh: Dict[str, float] | None = None) -> bool:
    T = thresh or {"coverage": 0.99, "drift_violations": 0, "weighted_total": -1e18}
    if score.get("coverage", 0.0) < T["coverage"]: return False
    if score.get("drift_violations", 1) > T["drift_violations"]: return False
    return True
