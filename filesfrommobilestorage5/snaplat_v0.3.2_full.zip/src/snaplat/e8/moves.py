
from typing import List, Tuple
import math

Vec = Tuple[float, ...]

def dot(a: Vec, b: Vec) -> float:
    return sum(x*y for x,y in zip(a,b))

def norm2(a: Vec) -> float:
    return dot(a,a)

def add(a: Vec, b: Vec) -> Vec:
    return tuple(x+y for x,y in zip(a,b))

def sub(a: Vec, b: Vec) -> Vec:
    return tuple(x-y for x,y in zip(a,b))

def reflect(v: Vec, r: Vec) -> Vec:
    # Reflect v across the hyperplane orthogonal to root r (||r||^2 = 2)
    # v' = v - 2*(v·r)/(r·r) * r = v - (v·r) * r  (since r·r=2)
    vr = dot(v,r)
    return tuple(vi - vr * ri for vi,ri in zip(v,r))

def feasible_same_shell(v: Vec, r: Vec, m: int, tol: float = 1e-9) -> bool:
    # Check if v +/- r stays on shell 2m using inner-products:
    # ||v ± r||^2 = ||v||^2 + 2 ± 2(v·r)  -> equals 2m iff ±2(v·r) = -2
    vr = dot(v,r)
    return abs(norm2(v) - 2*m) <= tol and (vr == -1.0 or vr == 1.0)

def neighbors_on_shell(v: Vec, roots: List[Vec], m: int, tol: float = 1e-9) -> List[Vec]:
    out = []
    nv = norm2(v)
    for r in roots:
        vr = dot(v,r)
        # v + r stays if v·r = -1 ; v - r stays if v·r = 1
        if abs(nv - 2*m) <= tol:
            if vr == -1.0:
                cand = add(v, r)
                if abs(norm2(cand) - 2*m) <= tol: out.append(cand)
            elif vr == 1.0:
                cand = sub(v, r)
                if abs(norm2(cand) - 2*m) <= tol: out.append(cand)
    return out
