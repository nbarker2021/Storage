
from typing import Dict, Any, List, Tuple
import json, os
from .salesman import SalesmanStateBus, propose_sectorized
from .braid_compile import compile_braid_to_transform
from ..superperm.nav import _project_points_from_shell
from ..tsp.solver import close_cycle, weighted_metric, tour_length
from ..sap.metrics import scorecard_for_cycle
from ..config import get_config
from ..morsr.log import MORSR
from ..mdhg.braid_setup import apply_braid_setup, snap_cycle

class _Validator:
    @staticmethod
    def check_cycle(cycle: List[int], n: int) -> bool:
        if not cycle or cycle[0] != cycle[-1]: return False
        inner = cycle[:-1]
        return set(inner) <= set(range(n)) and len(inner) == len(set(inner))

class _Patcher:
    @staticmethod
    def splice_permutation(current: List[int], proposal: List[int], n: int) -> List[int]:
        if not proposal: return current
        if proposal[0] != proposal[-1]: proposal = close_cycle(proposal)
        if not current: return proposal
        cur_set = set(current[:-1]); prop_set = set(proposal[:-1])
        keep = [i for i in current[:-1] if i not in prop_set]
        merged = proposal[:-1] + keep
        if not merged or merged[0] != merged[-1]: merged = merged + [merged[0]]
        return merged

class Planner:
    def __init__(self, m: int = 1):
        self.m = m
        self.cfg = get_config()
        self.morsr = MORSR("artifacts/morsr/planner.jsonl")
        self.pts2d, self.n = _project_points_from_shell(m)
        self.bus = SalesmanStateBus(self.pts2d)
        self.bus.alpha_default = float(self.cfg.get("alpha", 0.3))

        # Optional external hooks
        self.validator_hook = self.cfg.get("validator_hook")
        self.patcher_hook = self.cfg.get("patcher_hook")
        self._validator_ext = None
        self._patcher_ext = None
        try:
            if self.validator_hook:
                mod, fn = self.validator_hook.rsplit(":", 1)
                mod = __import__(mod, fromlist=[fn])
                self._validator_ext = getattr(mod, fn, None)
        except Exception:
            self._validator_ext = None
        try:
            if self.patcher_hook:
                mod, fn = self.patcher_hook.rsplit(":", 1)
                mod = __import__(mod, fromlist=[fn])
                self._patcher_ext = getattr(mod, fn, None)
        except Exception:
            self._patcher_ext = None

    def step(self, use_braid: bool | None = None) -> Dict[str, Any]:
        # Propose, apply (splice or braid), score, and log
        prop = propose_sectorized(self.bus, sample=len(self.pts2d),
                                  n_sectors=self.cfg.get("n_sectors", 30),
                                  k=self.cfg.get("k_nn", 3))
        tour = prop.get("tour", [])
        dist = weighted_metric(self.pts2d, heat=self.bus.heat, alpha=self.bus.alpha_default)
        before = tour_length(self.bus.current_cycle, dist) if self.bus.current_cycle else 0.0

        braid_info = None
        use_braid = (self.cfg.get('mdhg', {}).get('braid_mode', True) if use_braid is None else use_braid)

        if use_braid and self.bus.current_cycle and tour:
            setup = apply_braid_setup(self.m, self.pts2d, self.cfg)
            snaps = setup['snaps']; sector_of = setup['sector_of']; shell_of = setup['shell_of']; glyph_of = setup['glyph_of']
            anchor_idx = tour[0] if tour else 0
            target = snap_cycle(tour, snaps, anchor_idx, sector_of, shell_of, glyph_of)
            bw = compile_braid_to_transform(self.bus.current_cycle, target, anchor_idx, sector_of, int(self.cfg.get("n_sectors",30)))
            new_cycle = bw.apply_to_cycle(self.bus.current_cycle, anchor_idx=anchor_idx)
            braid_info = bw.to_dict(); braid_info['snaps'] = snaps
        else:
            # Fallback splice path
            if self._patcher_ext is not None:
                new_cycle = self._patcher_ext(self.bus.current_cycle, tour, len(self.pts2d))
            else:
                new_cycle = _Patcher.splice_permutation(self.bus.current_cycle, tour, n=len(self.pts2d))

        # Validate
        if self._validator_ext is not None:
            ok = bool(self._validator_ext(new_cycle, len(self.pts2d)))
        else:
            ok = _Validator.check_cycle(new_cycle, len(self.pts2d))
        if ok:
            self.bus.current_cycle = new_cycle

        after = tour_length(self.bus.current_cycle, dist) if ok else before
        sc = scorecard_for_cycle(self.bus.current_cycle, self.pts2d,
                                 k_window=int(self.cfg.get("k_window", 5)),
                                 weights=self.cfg.get("weights"))
        evt = {"event": "planner_step", "config": self.cfg, "alpha": self.bus.alpha_default,
               "before": before, "after": after, "delta": after-before, "valid": ok, "score": sc, "braid": braid_info}
        self.morsr.emit(evt)
        os.makedirs("artifacts", exist_ok=True)
        out = {"proposal": prop, "valid": ok, "apply": {"before": before, "after": after, "delta": after-before},
               "score": sc, "braid": braid_info, "config": self.cfg}
        with open("artifacts/plan_step.json", "w") as f: json.dump(out, f, indent=2)
        return out
