
from __future__ import annotations
from typing import List, Tuple, Dict, Any
from ..algebra.braid import BraidWord

def compile_braid_to_transform(current_cycle: List[int], target_cycle: List[int], anchor_idx: int, sector_of: List[int], n_sectors: int) -> BraidWord:
    if not current_cycle:
        n = len(target_cycle[:-1]) if target_cycle else 0
        return BraidWord(n)
    inner_cur = current_cycle[:-1]
    inner_tgt = target_cycle[:-1] if target_cycle else inner_cur

    cur = inner_cur[:]
    tgt = inner_tgt[:]
    if anchor_idx in cur:
        p = cur.index(anchor_idx); cur = cur[p:] + cur[:p]
    if anchor_idx in tgt:
        q = tgt.index(anchor_idx); tgt = tgt[q:] + tgt[:q]

    # Make target same size by appending any missing nodes in current order
    tgt_set = set(tgt)
    tgt_full = tgt + [u for u in cur if u not in tgt_set]
    n = len(cur)
    bw = BraidWord(n)

    def sector_gap(u,v):
        su, sv = sector_of[u], sector_of[v]
        d = abs(su - sv)
        return min(d, n_sectors - d)

    for i in range(n):
        goal = tgt_full[i]
        j = cur.index(goal)
        while j > i:
            u, v = cur[j-1], cur[j]
            if sector_gap(u,v) > 1 and j-2 >= i:
                j -= 1
                continue
            bw.append(j, +1)
            cur[j-1], cur[j] = cur[j], cur[j-1]
            j -= 1
    return bw.reduce()
