def test_braid_m1_and_m2_sample():
    import random
    from snaplat.agrm.planner import Planner
    from snaplat.e8.shells import shell_count
    random.seed(42)
    # m=1 full
    p1 = Planner(m=1)
    out1 = p1.step(use_braid=True)
    assert out1['score']['coverage'] >= 0.90
    # m=2 count (non-toy size check)
    assert shell_count(2) >= 1000
