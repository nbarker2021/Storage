
# Changelog
## 0.2.2 — 2025-08-16
- SymPy-backed Coxeter projector (with fallback), 2D plotter.
- FastLane rationale threaded into SAP+MORSR.
- Docs scaffold; tests for projector and C[8] invariants.

## 0.2.3 — 2025-08-16
- **Makefile & CI**: `make ci` runs tests, plot, docs stub, and writes artifact manifest.
- **Determinism**: projector determinism test; basic symmetry sanity (30-bin angle check if SymPy present).
- **MORSR manifest**: checksums for plots/docs/zip via `tools/manifest.py`.
- **Shells API (counts)**: added `shell_count(m)` (oracle-backed) and tests for m=1..3. (Full enumeration left open.)
- **Typing protocols**: vendor-agnostic interfaces for cmplx controller and MDHG.
- **Dev docs**: `README-dev.md` with runbook.

## 0.2.4 — 2025-08-16
- **Shell enumeration**: exact `shell(m)` for m=1..3 (combinatorial construction; counts match oracle), plus tests.
- **MDHG→Planner feedback**: cmplx planner adjusts radius via heat; deltas logged in plan notes.
- **Docs mini-index**: `tools/gen_module_index.py` builds `docs/module_index.md`; nav updated.
- **Release provenance event**: manifest tool also emits MORSR-style `artifacts/morsr_release.jsonl` when `SNAPLAT_RELEASE_ZIP` is provided.

## 0.2.5 — 2025-08-16
- **TSP core**: nearest-neighbor + 2‑opt; pluggable distance metrics.
- **Chinese Postman (CPP)**: undirected approx (greedy MWPM over odd nodes) + Hierholzer.
- **Navigator (superperm→TSP)**: `superperm/nav_tsp.py` uses TSP tour within shells/sectors.
- **AGRM integration**: Salesman proposals carry `tsp_length`, `cpp_length`; MDHG heat used as edge weight.
- **Tests**: TSP on square; CPP on path; navigation sanity over root‑shell subset.
