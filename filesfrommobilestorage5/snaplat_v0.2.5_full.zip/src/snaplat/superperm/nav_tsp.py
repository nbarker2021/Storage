
from typing import List, Tuple, Dict, Any
from ..e8.shells import root_shell
from ..e8.coxeter import get_projector
from ..tsp.solver import solve as tsp_solve
from ..tsp.postman import eulerize_approx, euler_tour

def project_points(vs: List[List[float]]) -> List[Tuple[float,float]]:
    P = get_projector()
    return [P(v) for v in vs]

def tsp_on_root_shell(sample: int | None = None) -> Dict[str, Any]:
    R = root_shell()
    if sample:
        R = R[:sample]
    pts2d = project_points(R)
    tour, length = tsp_solve(pts2d, start=0)
    return {"tour": tour, "length": length, "n": len(R)}

def cpp_on_sector_graph(G: Dict[int, Dict[int, float]], start: int = 0) -> List[int]:
    H = eulerize_approx(G)
    return euler_tour(H, start)
