
from itertools import combinations

def e8_roots():
    roots = []
    # Type A: all permutations of (±1, ±1, 0, ..., 0)
    for i, j in combinations(range(8), 2):
        for s1 in (+1.0, -1.0):
            for s2 in (+1.0, -1.0):
                v = [0.0]*8
                v[i] = s1; v[j] = s2
                roots.append(v)
    # Type B: (±1/2, ..., ±1/2) with an even number of negatives
    for mask in range(1<<8):
        bits = [(mask>>k)&1 for k in range(8)]
        if sum(bits) % 2 == 0:
            roots.append([(-0.5 if b else 0.5) for b in bits])
    assert len(roots) == 240
    return roots
