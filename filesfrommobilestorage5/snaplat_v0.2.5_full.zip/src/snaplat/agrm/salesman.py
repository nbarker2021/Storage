
from typing import Dict, Any, List, Tuple
from .factory import get_planner
from ..superperm.nav_tsp import tsp_on_root_shell

def propose_shell_tour(state_bus, sample: int = 64) -> Dict[str, Any]:
    res = tsp_on_root_shell(sample=sample)
    proposal = {
        "kind": "tsp_root_shell",
        "n": res["n"],
        "tsp_length": res["length"],
        "segment_indices": (0, 0),  # placeholder splice location
        "new_subpath_nodes": res["tour"],
    }
    state_bus.add_salesman_proposal(proposal)
    return proposal
