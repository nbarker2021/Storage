
from collections import defaultdict
from typing import Any, Dict
class MDHG:
    def __init__(self):
        self.kv: Dict[str, Any] = {}
        self.access = defaultdict(int)
    def put(self, k: str, v: Any): self.kv[k] = v
    def get(self, k: str, default=None):
        self.access[k] += 1
        return self.kv.get(k, default)
    def has(self, k: str) -> bool: return k in self.kv
    def hotmap(self): return dict(self.access)
