
from typing import List, Callable, Sequence, Tuple
import math, random

Point = Sequence[float]
DistFn = Callable[[int, int], float]

def euclid(points: List[Point]) -> DistFn:
    def d(i: int, j: int) -> float:
        pi, pj = points[i], points[j]
        return math.sqrt(sum((a-b)*(a-b) for a,b in zip(pi, pj)))
    return d

def nearest_neighbor(n: int, dist: DistFn, start: int = 0) -> List[int]:
    un = set(range(n)); tour = [start]; un.remove(start)
    cur = start
    while un:
        nxt = min(un, key=lambda j: dist(cur, j))
        tour.append(nxt); un.remove(nxt); cur = nxt
    return tour

def two_opt(tour: List[int], dist: DistFn, max_iter: int = 1000) -> List[int]:
    n = len(tour)
    best = tour[:]
    improved = True; it = 0
    while improved and it < max_iter:
        improved = False; it += 1
        for i in range(1, n-2):
            for k in range(i+1, n-1):
                a,b,c,d = best[i-1], best[i], best[k], best[(k+1)%n]
                if dist(a,c)+dist(b,d) < dist(a,b)+dist(c,d):
                    best[i:k+1] = reversed(best[i:k+1])
                    improved = True
        # could break early if no improvement in an outer loop
    return best

def close_cycle(tour: List[int]) -> List[int]:
    if tour and tour[0] != tour[-1]:
        return tour + [tour[0]]
    return tour

def tour_length(tour: List[int], dist: DistFn) -> float:
    return sum(dist(tour[i], tour[i+1]) for i in range(len(tour)-1))

def solve(points: List[Point], start: int = 0) -> Tuple[List[int], float]:
    d = euclid(points)
    base = nearest_neighbor(len(points), d, start)
    opt = two_opt(base, d)
    cyc = close_cycle(opt)
    return cyc, tour_length(cyc, d)
