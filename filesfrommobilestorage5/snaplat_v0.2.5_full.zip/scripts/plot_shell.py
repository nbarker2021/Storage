
from snaplat.e8.shells import root_shell
from snaplat.e8.coxeter import get_projector
from snaplat.viz.plot2d import scatter
def main():
    roots = root_shell()
    proj = get_projector()
    pts = [proj(r) for r in roots]
    scatter(pts, out_png="artifacts/plots/root_shell.png", out_svg="artifacts/plots/root_shell.svg", title="E8 Root Shell (Coxeter plane)")
    print("Wrote artifacts/plots/root_shell.png and .svg")
if __name__ == "__main__":
    main()
