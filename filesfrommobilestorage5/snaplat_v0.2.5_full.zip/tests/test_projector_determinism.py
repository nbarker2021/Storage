
from snaplat.e8.coxeter import get_projector

def test_projector_determinism():
    proj1 = get_projector()
    proj2 = get_projector()
    x = [0.25, -0.75, 1.0, 0.0, 0.5, -1.25, 0.25, 0.0]
    assert proj1(x) == proj2(x)
