
from snaplat.e8.shells import shell_count, oracle_count
def test_shell_counts_match_oracle():
    for m in [1,2,3]:
        assert shell_count(m) == oracle_count(m)
