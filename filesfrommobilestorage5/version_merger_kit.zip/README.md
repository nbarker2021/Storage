
# Version Merger Kit (v14 → v20, E8-first)
See scripts in this folder. Quickstart:
python merge_versions.py --inputs /path/v14.zip /path/v20.zip --out ./merged_workspace
python unify_e8.py --root ./merged_workspace --prefer-highest
python rewrite_imports.py --root ./merged_workspace --dry-run
python run_checks.py --root ./merged_workspace
