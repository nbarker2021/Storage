
from __future__ import annotations
import argparse, pathlib, re

LEGACY_PATTERNS = [
    r"from\s+lattice_system_base_v\d+\.lattice_ai\.geometry\.e8_roots\s+import",
    r"from\s+lattice_system_base_v\d+\.lattice_ai\.geometry\.e8\s+import",
]

def rewrite_file(p: pathlib.Path) -> int:
    txt = p.read_text(encoding="utf-8", errors="replace"); orig = txt
    for pat in LEGACY_PATTERNS:
        txt = re.sub(pat, "from lattice_ai.geometry.e8_roots import", txt)
        txt = re.sub(pat.replace("e8_roots","e8"), "from lattice_ai.geometry.e8 import", txt)
    if txt != orig: p.write_text(txt, encoding="utf-8"); return 1
    return 0

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); ap.add_argument("--dry-run", action="store_true"); args = ap.parse_args()
    root = pathlib.Path(args.root).resolve(); changed = 0
    for p in root.rglob("*.py"):
        if "site-packages" in str(p) or "/venv/" in str(p): continue
        try:
            delta = rewrite_file(p); changed += delta
            if delta and args.dry_run: print("[dry-run changed]", p)
        except Exception as e:
            print("[warn] failed", p, e)
    if args.dry_run: print(f"[dry-run] would change {changed} files")
    else: print(f"[done] changed {changed} files")
if __name__ == "__main__": main()
