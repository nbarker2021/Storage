
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Literal

@dataclass
class Attestation:
    status: Literal["pass","warn","fail"]
    policy_id: str
    reasons: List[str]
    metrics: Dict[str, Any]

@dataclass
class Ruling:
    decision: Literal["allow","deny","quarantine"]
    rationale: Dict[str, Any]

GATES = {
    "dim": {
        "tau_min": 0.92,
        "overlap_min": 0.95
    },
    "n7": {
        "exactly_once": True,
        "length_min": 5884,
        "length_max_record": 5906
    }
}

def sentinel_check(policy_id: str, metrics: Dict[str, Any]) -> Attestation:
    reasons: List[str] = []
    status: Literal["pass","warn","fail"] = "pass"
    if policy_id.startswith("policy:dim"):
        tau = float(metrics.get("tau", 1.0))
        overlap = float(metrics.get("overlap", 1.0))
        if tau < GATES["dim"]["tau_min"]:
            reasons.append(f"tau {tau} < {GATES['dim']['tau_min']}")
            status = "fail"
        if overlap < GATES["dim"]["overlap_min"]:
            reasons.append(f"overlap {overlap} < {GATES['dim']['overlap_min']}")
            status = "fail"
    if policy_id.startswith("policy:n7"):
        # Accept partial data; fail only on clear violations during non-dry runs
        if "length" in metrics:
            L = int(metrics["length"])
            if L < GATES["n7"]["length_min"]:
                reasons.append(f"length {L} < {GATES['n7']['length_min']}")
                status = "fail"
            if metrics.get("mode") == "record" and L > GATES["n7"]["length_max_record"]:
                reasons.append(f"length {L} > {GATES['n7']['length_max_record']} (record mode)")
                status = "fail"
        if "coverage_ok" in metrics and GATES["n7"]["exactly_once"]:
            if not bool(metrics["coverage_ok"]):
                reasons.append("coverage not exactly-once")
                status = "fail"
    return Attestation(status=status, policy_id=policy_id, reasons=reasons, metrics=metrics)

def arbiter_rule(att: Attestation) -> Ruling:
    if att.status == "pass":
        return Ruling(decision="allow", rationale={"policy": att.policy_id})
    return Ruling(decision="deny", rationale={"reasons": att.reasons})
