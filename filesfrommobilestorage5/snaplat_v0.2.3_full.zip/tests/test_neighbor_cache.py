
from snaplat.e8.neighbor_cache import NeighborCache
def test_neighbor_cache_smoke():
    nc = NeighborCache(); nbrs = nc.get_first_shell([0.0]*8)
    assert isinstance(nbrs, list) and len(nbrs) >= 112
