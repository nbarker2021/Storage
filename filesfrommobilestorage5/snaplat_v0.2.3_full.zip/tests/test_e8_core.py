
from snaplat.e8.core import is_member, nearest, edges, reflect, coxeter_plane, roots
def test_membership_and_nearest():
    v = [0.1, 1.9, -0.2, 0.7, -0.6, 0.0, 0.5, -1.2]
    x, d2 = nearest(v); assert is_member(x)
    y, d2b = nearest(x); assert y == x and d2b == 0.0
def test_edges_count():
    x, _ = nearest([0.0]*8); nbrs = edges(x); assert len(nbrs) >= 112
def test_reflect_involutive():
    x, _ = nearest([0.0]*8); r = roots()[0]; y = reflect(x, r); z = reflect(y, r)
    assert all(abs(a-b) < 1e-9 for a,b in zip(x,z))
def test_projection_2d():
    x, _ = nearest([0.0]*8); u, v = coxeter_plane(x); assert isinstance(u, float) and isinstance(v, float)
