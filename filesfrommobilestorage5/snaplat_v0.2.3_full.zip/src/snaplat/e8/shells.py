
from typing import List
from .roots import e8_roots

def sigma3(n: int) -> int:
    s = 0
    for d in range(1, n+1):
        if n % d == 0:
            s += d**3
    return s

def oracle_count(m: int) -> int:
    return 240 * sigma3(m)

def root_shell() -> List[List[float]]:
    return e8_roots()


def shell_count(m: int) -> int:
    """Return the number of lattice points in the shell of squared norm 2*m.
    For E8 this equals 240 * sigma3(m), the theta-series coefficient.
    """
    return oracle_count(m)
