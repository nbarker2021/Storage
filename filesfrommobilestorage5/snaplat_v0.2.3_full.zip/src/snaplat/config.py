
from dataclasses import dataclass
@dataclass
class Config:
    agrm: str = "simple"
