
from dataclasses import dataclass
from ..types.protocols import AGRMControllerProto
from typing import Dict, Any

@dataclass
class State:
    step: int
    tac: float
    hotmap: Dict[str, int]

class CmplxAGRM:
    def __init__(self):
        # Lazy vendor imports (fail-soft)
        try:
            from vendor.agrm_cmplx.agrm.spine.controller_v0_7 import AGRMController_v0_7_2025_08_13 as Controller  # type: ignore
        except Exception:
            Controller = None  # type: ignore
        try:
            from vendor.agrm_cmplx.agrm.agrm.fastlane import FastLane  # type: ignore
        except Exception:
            FastLane = None  # type: ignore
        self.ctrl: AGRMControllerProto | None = Controller() if Controller else None
        self.fastlane = FastLane() if FastLane else None

    def plan(self, state: Any) -> Dict[str, Any]:
        r = 1 + (state.step % 2)
        floors = 1 if state.tac >= 0.5 else 2
        elevators = 1
        schedule = ["neighbors", "edges", "reflect"]
        # Surface a FastLane rationale if available
        reason = None
        fl = self.fastlane
        if fl:
            try:
                if hasattr(fl, 'explain'):
                    reason = str(fl.explain({"step": state.step, "tac": state.tac, "hotmap": getattr(state, 'hotmap', {})}))
                elif hasattr(fl, 'reason') and callable(fl.reason):
                    reason = str(fl.reason())
            except Exception:
                reason = None
        notes = {"cmplx": True, "hot": bool(getattr(state, 'hotmap', {})), "fastlane_ready": bool(fl)}
        if reason:
            notes["fastlane_reason"] = reason
        return {"radius": r, "floors": floors, "elevators": elevators, "schedule": schedule, "notes": notes}

    def learn(self, trace): return None
