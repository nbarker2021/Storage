
# Failure Catalog
Levels: tick/snap/chain; taxonomy: source, symptom, site, strategy; roll-ups; repair playbooks; KPIs.
