
# System Overview
A universal atomic runtime: seeds → SNAPs on an on-demand E8 lattice; AGRM plans; MDHG pre-builds universes; Master Index shells/glyphs space; agents operate with stance flips; SAP governs; DeepStore persists with approvals; RAG stitches with provenance.
