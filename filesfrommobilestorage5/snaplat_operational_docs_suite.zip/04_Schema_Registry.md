
# Schema Registry
Type IDs, seeds (required/optional), traits, gates (faces/trait rules), replay recipes, governance. CLI: schema add/show/validate.
