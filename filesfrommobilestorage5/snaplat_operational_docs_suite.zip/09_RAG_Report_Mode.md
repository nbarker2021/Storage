
# RAG Report Mode
Index docs; generate with inline provenance markers; lane/face-aware seed weights; audit-friendly outputs.
