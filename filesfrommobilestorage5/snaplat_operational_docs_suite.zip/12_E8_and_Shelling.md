
# E8 & Shelling
E8 invariants; nearest-cell, neighbors, reflections; Shelling n-level lifecycle; Underverse; superpermutation C[8].
