
# Changelog
v17: Schema Registry, Gate Runner, Naming/Glyph, ThinkTank, Agent stubs, DeepStore queue.
v18: Agentic E2E, Failure Catalog, Restore Recipes, RAG report mode.
v19: Cross-modal precedence, beacon decay/override, partial trait lanes, perf suite.
v20: Deep-store GC/compaction, ROC proofs, resilience tests.
