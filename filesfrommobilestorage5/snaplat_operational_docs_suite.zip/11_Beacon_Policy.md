
# Beacon Policy
Hierarchical tag-weights; exponential decay; SAP-approved overrides; ledger snapshots; stability monitoring.
