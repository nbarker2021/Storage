
# Cross-Modal Precedence
Operational: kernel>code>tables>text. Reporting: text>tables>code>kernel. Ties -> lane/face + source quality.
