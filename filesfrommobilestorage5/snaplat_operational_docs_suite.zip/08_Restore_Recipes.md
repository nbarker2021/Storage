
# Restore Recipes
Rehydrate kernel payloads; tick-rate, compression, safety posture; integrity digests; fail-closed loads.
