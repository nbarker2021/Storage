
# Naming/Glyph SNAP Recall
Format: Domain.Family.Subtype.SeedDigest.CtxDigest.vN. Resolver reconstructs shell and pointer graph; collisions gated by SAP.
