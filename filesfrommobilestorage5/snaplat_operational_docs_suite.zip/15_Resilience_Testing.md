
# Resilience Testing
Fault injections: missing chunks, queue delays, partial index loss; expected behaviors; recovery drills.
