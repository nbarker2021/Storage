
# E→C Budgeting
Expansion must be followed by contraction within K steps; enforce at planner; promote only in S⁺.
