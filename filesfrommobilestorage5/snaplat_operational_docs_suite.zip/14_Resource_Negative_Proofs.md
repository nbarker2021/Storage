
# Resource-Negative Proofs
Metrics for recall-over-compute (ROC); thresholds; longitudinal dashboards; automatic stance shifts when ROC dips.
