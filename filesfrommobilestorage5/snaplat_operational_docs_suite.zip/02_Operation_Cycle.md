
# Operation Cycle
0) Choose stance + tick. 1) Sense/glyphify. 2) Plan (AGRM). 3) Build (MDHG). 4) Stage from Master Index. 5) Act (stitch/compute). 6) Govern (SAP + queue + ThinkTank). 7) Feedback → Training. 8) Adapt (beacon decay, E→C, Underverse).
