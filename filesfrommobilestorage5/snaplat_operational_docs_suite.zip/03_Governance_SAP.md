
# SAP Governance
Family -> Regional -> Global SAP; faces→lanes; gate runner reasons; governance queue for deep-store; policy templates; escalation playbooks.
