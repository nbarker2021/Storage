
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List
from math import isclose

def _cos(a: np.ndarray, b: np.ndarray) -> float:
    na = np.linalg.norm(a) + 1e-12
    nb = np.linalg.norm(b) + 1e-12
    return float(np.dot(a, b) / (na * nb))

def coherence(vs: np.ndarray, center: np.ndarray | None=None) -> float:
    if vs.size == 0: return 0.0
    c = center if center is not None else vs.mean(axis=0)
    sims = [ _cos(v, c) for v in vs ]
    return float(np.mean(sims))

def redundancy(vs: np.ndarray) -> float:
    n = vs.shape[0]
    if n < 2: return 0.0
    sims = []
    for i in range(n):
        for j in range(i+1, n):
            sims.append(_cos(vs[i], vs[j]))
    return float(np.mean(sims)) if sims else 0.0

def novelty(vs: np.ndarray, center: np.ndarray | None=None) -> float:
    if vs.size == 0: return 0.0
    c = center if center is not None else vs.mean(axis=0)
    sims = [ _cos(v, c) for v in vs ]
    return float(np.mean([1.0 - s for s in sims]))

def contradiction_risk(claims: List[dict]) -> float:
    # Simple rule per docs: any flagged contradiction -> risk 1.0
    return 1.0 if any(c.get('contradicted') for c in claims) else 0.0
