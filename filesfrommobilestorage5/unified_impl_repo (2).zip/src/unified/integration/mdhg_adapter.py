
"""Adapter: expose MDHG index as a SNAP Index."""
from typing import Any, Dict, Optional
from unified.mdhg.index import MDHGIndex

class MDHGIndexAdapter:
    def __init__(self):
        self._idx = MDHGIndex()

    def put(self, key: str, payload: Dict[str, Any]) -> None:
        self._idx.put(key, payload)

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        return self._idx.get(key)

    def exists(self, key: str) -> bool:
        return self._idx.exists(key)
