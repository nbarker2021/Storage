
"""Tool registry for SNAP: register builders, indexes, lattices, routers, etc.
Allows late binding of implementations via config, keeping the core agnostic.
"""
from __future__ import annotations
from typing import Any, Callable, Dict

class Registry:
    def __init__(self):
        self._factories: Dict[str, Callable[..., Any]] = {}

    def register(self, name: str, factory: Callable[..., Any]) -> None:
        self._factories[name] = factory

    def build(self, name: str, **kw) -> Any:
        if name not in self._factories:
            raise KeyError(f"No factory registered for '{name}'")
        return self._factories[name](**kw)

# global default registry
default = Registry()
