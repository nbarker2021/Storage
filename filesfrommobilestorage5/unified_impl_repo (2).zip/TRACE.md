# Code↔Docs Traceability

## unified/agrm/core.py
- 81025/AGRM overview.txt
- 81025/repair rules.txt
- 81025/pipeline overview.txt
- 81025/snapshot & replay.txt
- 81025/results & validation.txt

## unified/agrm/runner.py
- 81025/runner orchestration.txt
- 81025/beam strategies.txt
- 81025/seed and metrics.txt

## unified/agrm/validation.py
- 81025/golden gates.txt
- 81025/sanity checklist.txt
- 81025/results & validation.txt

## unified/cmplx/core.py
- 81025/CMPLX overview.txt
- 81025/limits & complexity.txt

## unified/e8/goldens.py
- 81025/e8 actualizeation attempt codebase part 3.txt
- 81025/hash and golden checks.txt

## unified/e8/hashing.py
- 81025/e8 actualizeation attempt codebase part 2
- 81025/e8 actualizeation attempt codebase part 3.txt

## unified/e8/jobs/queue.py
- 81025/e8 lattice initial actualization attempt
- 81025/e8 actualizeation attempt codebase part 2

## unified/e8/persistence/db.py
- 81025/e8 actualizeation attempt codebase part 2
- 81025/e8 lattice initial actualization attempt

## unified/e8/policy.py
- 81025/e8 lattice initial actualization attempt
- 81025/e8 actualizeation attempt codebase part 2

## unified/e8/router.py
- 81025/e8 lattice initial actualization attempt
- 81025/e8 actualizeation attempt codebase part 2

## unified/e8/scoring.py
- 81025/e8 lattice initial actualization attempt
- 81025/e8 actualizeation attempt codebase part 1

## unified/e8/shells.py
- 81025/e8 lattice initial actualization attempt
- 81025/e8 actualizeation attempt codebase part 2

## unified/mdhg/index.py
- 81025/MDHG scaffold.txt
- 81025/lattice indexing.txt
- 81025/hash and golden checks.txt

## unified/tsp/reduce.py
- 81025/TSP notes.txt
- 81025/debruijn notes.txt
- 81025/SFBB pointers.txt
