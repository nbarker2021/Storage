
# Mapping: E8 Docs → Scaffolded Files

- "Lattice System v20 — Full Source Dump (Part 1/2/3)" → `unified/e8/*`
  - persistence/db.py       → annotated per 'persistence' sections
  - jobs/queue.py           → per 'jobs/queue' sections
  - rest/ui.py              → per 'REST/UI' sections
  - goldens.py              → per 'tests/goldens' and 'golden checks' sections
  - shell_policy.py, probes.py, scoring.py → per promotion policy and probe metrics sections
  - tuner.py                → per 'train semantic hash weights' sections
  - governance.py, router.py → per governance/router/budgeted query/p95 control sections
  - glyphs.py               → per glyph/shell definitions

- "e8 lattice initial actualization attempt" → end-to-end procedural flows (sweeps, tenants, dashboard)
- "post mortem" → TODO markers captured for later work
