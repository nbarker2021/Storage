from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
@dataclass
class GateVerdict: ok: bool; reason: str
@dataclass
class ComplexityCfg: Fmax:int=256; DLmax:float=3.0; window_rise_max:int=0
@dataclass
class DetectorCfg: N_min:int=2; diversity_min:int=2; consensus_min:float=0.5

def leakage_gate(leakage: float, eps: float = 0.05) -> GateVerdict:
    return GateVerdict(ok=(leakage <= eps), reason=("Leakage≤ε" if leakage <= eps else "Leakage>ε"))

def complexity_gate(sc: Dict[str, float], cfg: ComplexityCfg) -> GateVerdict:
    if sc.get('frontier_width',0) > cfg.Fmax: return GateVerdict(False, 'frontier_width>Fmax')
    if sc.get('glyph_dl',0.0) > cfg.DLmax: return GateVerdict(False, 'glyph_dl>DLmax')
    if sc.get('phi_rise_ticks',0) > cfg.window_rise_max: return GateVerdict(False, 'Φ rising')
    return GateVerdict(True, 'OK')

def detector_gate(fusion: Dict[str, Any], D_meta: Dict[str, Any], cfg: DetectorCfg) -> GateVerdict:
    if D_meta.get('N',0) < cfg.N_min: return GateVerdict(False, 'detectors<N_min')
    if D_meta.get('diversity',0.0) < 0.34: return GateVerdict(False, 'diversity<min')
    if fusion.get('consensus',0.0) < cfg.consensus_min: return GateVerdict(False, 'consensus<thresh')
    return GateVerdict(True, 'OK')
