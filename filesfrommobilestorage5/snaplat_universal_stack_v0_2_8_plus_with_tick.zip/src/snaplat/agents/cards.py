from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Any
@dataclass
class AgentCard:
    name: str; purpose: str; actions: List[str]; metrics: List[str]; failure_modes: List[str]
    cost_model: Dict[str, float] = field(default_factory=dict)
    growth_model: Dict[str, float] = field(default_factory=dict)
FINDING_VERSION='1'

def make_finding(kind:str, where:List[str], confidence:float, novelty:float, impact:Dict[str,float], support:List[str], counterplan:List[str], detector_votes:Dict[str,int])->Dict[str,Any]:
    return {'version':FINDING_VERSION,'finding':kind,'where':where,'confidence':confidence,'novelty':novelty,'impact':impact,'support':support,'counterplan':counterplan,'detector_votes':detector_votes}
