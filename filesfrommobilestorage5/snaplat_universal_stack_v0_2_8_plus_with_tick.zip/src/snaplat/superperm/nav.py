
from typing import Dict, Any
from .nav_tsp import sector_cpp_then_tsp, tsp_on_root_shell

def run_shell_tour(m: int = 1, n_sectors: int = 30, k: int = 3, alpha: float = 0.3, sample: int | None = None) -> Dict[str, Any]:
    """Facade: for m=1 use root shell; higher m may plug in later. Returns visiting order & anchor info."""
    if m == 1:
        return sector_cpp_then_tsp(n_sectors=n_sectors, k=k, sample=sample, heat=None, alpha=alpha)
    else:
        # TODO: build projector points for shell(m) and run the same pipeline
        return sector_cpp_then_tsp(n_sectors=n_sectors, k=k, sample=sample, heat=None, alpha=alpha)
