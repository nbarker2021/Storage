from __future__ import annotations
from typing import Dict, List, Any
from dataclasses import dataclass
from ..dtt.harness import DTT, DTTConfig
from ..superperm.c8 import produce_c8, C8Config
from ..metrics.core import robust_avg
from ..metrics.splus import leakage_from_metrics
from ..mdhg.bus import MDHGBus
from ..agrm.plan_adapter import PlanAdapterProto, Action, Trail
@dataclass
class DTTAdapter(PlanAdapterProto):
    seed:int=7; mdhg: MDHGBus | None = None
    def actions(self) -> Dict[str, Action]:
        return {'micro_eval': Action(op='micro_eval', tag='E', m=2.0, est_cost=1.0), 'braid_reduce': Action(op='braid_reduce', tag='C', m=0.5, est_cost=0.5)}
    def step(self, schedule: List[Action], state: Dict[str, Any]) -> Trail:
        cands=produce_c8(C8Config(seed=self.seed)); ev=DTT(DTTConfig(seed=self.seed)).run(cands)
        utils=[e.metrics.get('utility',0.0) for e in ev]; stabs=[e.metrics.get('stability',0.0) for e in ev]
        util=robust_avg(utils); stab=robust_avg(stabs); med=sorted(utils)[len(utils)//2]
        coverage=sum(1 for u in utils if u>=med)/float(len(utils) or 1); drift=float(state.get('drift',0.0))
        leak=leakage_from_metrics({'tac':stab,'boundary':coverage,'drift':drift},{'tac':0.6,'boundary':0.5,'drift':0.3})
        if self.mdhg:
            for e in ev:
                cid=e.candidate_id  # type: ignore[attr-defined]
                self.mdhg.put('dtt:cand', cid, score=e.metrics.get('utility',0.0))
        return Trail(metrics={'coverage':coverage,'drift':drift,'leakage':leak,'utility':util,'stability':stab}, artifacts={}, notes={})
    def learn(self, trace: Trail) -> None: return None
