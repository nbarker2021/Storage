
from snaplat.agrm.factory import get_planner
from snaplat.agrm.simple import AGRMState

def test_heat_increases_radius_when_hot():
    planner = get_planner("cmplx")
    state = AGRMState(step=2, tac=0.4)  # we'll attach hotmap via setattr
    setattr(state, "hotmap", {"a": 5, "b": 7})  # heat=12
    plan = planner.plan(state)
    assert plan["radius"] >= 2
    assert plan["notes"].get("heat_score", 0) >= 12
