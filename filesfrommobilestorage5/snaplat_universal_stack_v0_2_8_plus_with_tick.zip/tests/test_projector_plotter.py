
from snaplat.e8.shells import root_shell
from snaplat.e8.coxeter import get_projector
def test_projector_smoke():
    proj = get_projector()
    pts = [proj(r) for r in root_shell()[:10]]
    assert all(isinstance(u, float) and isinstance(v, float) for (u,v) in pts)
