
from snaplat.superperm.nav_tsp import tsp_on_root_shell
def test_nav_tsp_smoke():
    res = tsp_on_root_shell(sample=24)
    assert res["n"] == 24
    assert isinstance(res["length"], float) and res["length"] > 0
    assert len(res["tour"]) == 25  # cycle
