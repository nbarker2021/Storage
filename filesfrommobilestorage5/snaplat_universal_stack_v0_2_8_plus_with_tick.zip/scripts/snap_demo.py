
from snaplat.snap.state import SNAPState
def main():
    s = SNAPState(name="demo", base_point=[0.0]*8, orientation=[], projection="coxeter", constraints={}, neighbor_cache={})
    print("SNAP hash:", s.hash())
    print("Projection:", s.replay_projection())
    print("Neighbors:", len(s.neighbors()))
if __name__ == "__main__":
    main()
