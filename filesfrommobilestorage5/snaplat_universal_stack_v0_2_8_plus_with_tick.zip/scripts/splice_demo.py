
import os, json
from snaplat.agrm.salesman import demo_bus_from_root, propose_shell_tour

if __name__ == "__main__":
    bus = demo_bus_from_root(sample=60)
    # Fake a bit of heat for the first 10 nodes
    for i in range(min(10, len(bus.heat))): bus.heat[i] = 25.0
    prop = propose_shell_tour(bus, sample=60)
    applied = bus.apply_best()
    out = {
        "proposal": {"n": prop["n"], "tsp_length": prop["tsp_length"], "alpha": prop["alpha"]},
        "apply": applied,
        "cycle_len": len(bus.current_cycle)
    }
    os.makedirs("artifacts", exist_ok=True)
    with open("artifacts/splice_demo.json", "w") as f: json.dump(out, f, indent=2)
    print("artifacts/splice_demo.json")
