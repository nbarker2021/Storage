
# Changelog
## 0.2.2 — 2025-08-16
- SymPy-backed Coxeter projector (with fallback), 2D plotter.
- FastLane rationale threaded into SAP+MORSR.
- Docs scaffold; tests for projector and C[8] invariants.

## 0.2.3 — 2025-08-16
- **Makefile & CI**: `make ci` runs tests, plot, docs stub, and writes artifact manifest.
- **Determinism**: projector determinism test; basic symmetry sanity (30-bin angle check if SymPy present).
- **MORSR manifest**: checksums for plots/docs/zip via `tools/manifest.py`.
- **Shells API (counts)**: added `shell_count(m)` (oracle-backed) and tests for m=1..3. (Full enumeration left open.)
- **Typing protocols**: vendor-agnostic interfaces for cmplx controller and MDHG.
- **Dev docs**: `README-dev.md` with runbook.

## 0.2.4 — 2025-08-16
- **Shell enumeration**: exact `shell(m)` for m=1..3 (combinatorial construction; counts match oracle), plus tests.
- **MDHG→Planner feedback**: cmplx planner adjusts radius via heat; deltas logged in plan notes.
- **Docs mini-index**: `tools/gen_module_index.py` builds `docs/module_index.md`; nav updated.
- **Release provenance event**: manifest tool also emits MORSR-style `artifacts/morsr_release.jsonl` when `SNAPLAT_RELEASE_ZIP` is provided.

## 0.2.5 — 2025-08-16
- **TSP core**: nearest-neighbor + 2‑opt; pluggable distance metrics.
- **Chinese Postman (CPP)**: undirected approx (greedy MWPM over odd nodes) + Hierholzer.
- **Navigator (superperm→TSP)**: `superperm/nav_tsp.py` uses TSP tour within shells/sectors.
- **AGRM integration**: Salesman proposals carry `tsp_length`, `cpp_length`; MDHG heat used as edge weight.
- **Tests**: TSP on square; CPP on path; navigation sanity over root‑shell subset.

## 0.2.6 — 2025-08-16
- **Weighted TSP metric (default-ready)**: custom `dist` + `weighted_metric(points, heat, alpha)`.
- **Sector k-NN + CPP pre-pass**: Euler tours inside sectors; anchors ordered by TSP.
- **Salesman splice application**: simple state bus with pre→post length delta, MORSR event.
- **MDHG heat decay/cap**: `decay(factor=0.9, cap=1000)` for stable planner heat.
- **Acceptance mapping reporter**: `tools/accept_report.py` emits `artifacts/acceptance_report.json`.

## 0.2.7 — 2025-08-16
- **Default MDHG‑weighted routing:** navigator uses `alpha=0.3` by default; MORSR logs metric params.
- **Real Salesman splice:** insert proposed subpath into the existing cycle via best edge cut (2‑opt style); logs pre→post deltas.
- **Artifacts:** splice demo JSON; acceptance unchanged.

## 0.2.8 — 2025-08-16
- **E8 Engine**: `shell(m)` generalized (streaming, safe bounds); `neighbors(v,m)` via root inner‑product rule; `moves.py` primitives.
- **Navigator v1**: `superperm/nav.py` facade with auto sectorization (CPP inside sectors, TSP across anchors).
- **Planner (unified)**: `agrm/planner.py` runs propose→splice→assess→log using MDHG heat and Salesman bus.
- **SAP loop**: `sap/metrics.py` + `sap/loop.py` with coverage/drift/entropy/cost; scorecard artifact.
- **Determinism & config**: `config.py` seed + knobs; MORSR logs config snapshot.
- **CLI**: `scripts/cli.py` with `shell-tour` and `plan-step` commands.
