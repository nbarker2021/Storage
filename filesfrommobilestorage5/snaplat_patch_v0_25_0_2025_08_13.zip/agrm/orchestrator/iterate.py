
from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import time
from agrm.spine.controller_v0_7 import AGRMController_v0_7_2025_08_13
from agrm.agrm.elevator_promotion import promote_elevators
from agrm.utils.promo_summary import write_promotion_summary

@dataclass
class IterationResult:
    summary: Dict[str,Any]; promotion: Dict[str,Any]
@dataclass
class IterativeReport:
    iterations: List[IterationResult]; delivered: bool; reason: str; summary_snap: str | None

def _stable_ratio(prev: Optional[float], cur: float, eps: float) -> bool:
    if prev is None: return False
    denom = max(1e-9, cur + prev); return abs(cur - prev) / denom < eps

def run_iterations(points, metas, *, repo, um, base_cfg: Dict[str,Any], universe: str,
                   max_iters: int = 5, min_promoted: int = 1, promotion_threshold: float = None,
                   compat_policy: Dict[str,Any] = None, stability_eps: float = 0.05,
                   invariant_mode: str = "warn") -> IterativeReport:
    results: List[IterationResult] = []; last_rate: Optional[float] = None; delivered=False; reason="max_iters_reached"
    for it in range(1, max_iters+1):
        cfg = dict(base_cfg); cfg["universe"] = universe
        ctl = AGRMController_v0_7_2025_08_13(cfg=cfg, repo=repo, policies={}, um=um)
        summary = ctl.solve(points, metas=metas)
        # Invariant enforcement (optional hard error)
        if summary.get("invariant_violation"):
            if invariant_mode == "error":
                return IterativeReport(iterations=[IterationResult(summary=summary, promotion={"promoted":0,"rejected":0})], delivered=False, reason=summary["invariant_violation"], summary_snap=None)
        thr = promotion_threshold if promotion_threshold is not None else cfg.get("mdhg",{}).get("elevator_score_min", 0.5)
        prom = promote_elevators(repo, um, universe, threshold=float(thr), compat_policy=compat_policy or {})
        results.append(IterationResult(summary=summary, promotion=prom))
        promoted = int(prom.get("promoted", 0)); total = promoted + int(prom.get("rejected",0)); rate = (promoted / max(1,total)) if total>0 else 0.0
        elev = len(summary.get("mdhg",{}).get("elevators",[])); cand = int(summary.get("telemetry",{}).get("candidates_emitted",0))
        if not cfg.get("mdhg",{}).get("persist", True) and elev>0 and cand==0:
            reason = "failed_event_emission_under_persist_false"; break
        if promoted >= min_promoted and _stable_ratio(last_rate, rate, stability_eps):
            delivered=True; reason="stable_promotion_rate"; break
        last_rate = rate
    # Write iterator report SNAP
    rid = f"iter_report::{universe}::{int(time.time())}"
    repo.save(rid, {"meta":{"snap_id": rid, "family":"iterative","type":"report","tags":{"universe":universe}},
                    "content":{"delivered": delivered, "reason": reason, "iterations":[{"summary": r.summary, "promotion": r.promotion} for r in results]}})
    # Auto promotion summary + overlay attach
    summary_snap = None
    try:
        summary_snap, _ = write_promotion_summary(repo, um, universe, iterations=[{"summary": r.summary, "promotion": r.promotion} for r in results], delivered=delivered, reason=reason)
    except Exception:
        pass
    return IterativeReport(iterations=results, delivered=delivered, reason=reason, summary_snap=summary_snap)
