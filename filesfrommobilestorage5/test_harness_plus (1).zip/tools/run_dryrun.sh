
#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
export CODE_UNDER_TEST="${CODE_UNDER_TEST:-/mnt/data/ground_up_build}"
export TEST_PLAN="${TEST_PLAN:-$ROOT_DIR/plans/superperm_n7_dryrun.yml}"
export DRYRUN_REPORT="${DRYRUN_REPORT:-$ROOT_DIR/dryrun_report.json}"
# Resource allowances; caps will use 75% of these
export TOTAL_WALL_MS="${TOTAL_WALL_MS:-600000}"   # 10 minutes allowance
export TOTAL_RAM_MB="${TOTAL_RAM_MB:-4096}"       # 4 GB allowance

python - <<'PY'
from src.testlib_plus.orchestrator import Orchestrator
import os
orch = Orchestrator(os.environ['CODE_UNDER_TEST'], os.environ['TEST_PLAN'], os.environ['DRYRUN_REPORT'])
rep = orch.run()
print("Run complete. Caps:", rep.get("resource_caps"))
print("Records:", len(rep.get("queue_records", [])))
PY

pytest -q -m orchestrated
echo "Dry run complete. Report at: $DRYRUN_REPORT"
