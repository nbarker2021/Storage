
from __future__ import annotations
import time
from typing import Any, Dict, List

class RunLog:
    def __init__(self) -> None:
        self.records: List[Dict[str, Any]] = []
        self.saps: List[Dict[str, Any]] = []
        self.meta: Dict[str, Any] = {}

    def start_run(self, spec: Dict[str, Any]) -> None:
        self.meta = {"started_at": time.time(), "plan": spec}

    def log_op(self, op, status: str, dur_ms: float, out: Any, err: Any) -> None:
        rec = {
            "name": op.name,
            "family": op.family,
            "module": op.module,
            "func": op.func,
            "priority": op.priority,
            "status": status,
            "duration_ms": dur_ms,
            "error": err,
        }
        # keep small results only to avoid bloating report
        if isinstance(out, (int, float, str)) or out is None:
            rec["result"] = out
        self.records.append(rec)

    def log_sap(self, att, rule, family: str):
        self.saps.append({
            "family": family,
            "attestation": {
                "status": att.status,
                "policy_id": att.policy_id,
                "reasons": att.reasons,
                "metrics": att.metrics,
            },
            "ruling": {
                "decision": rule.decision,
                "rationale": rule.rationale,
            }
        })

    def finish_run(self) -> Dict[str, Any]:
        ended = time.time()
        return {
            "meta": {**self.meta, "ended_at": ended, "elapsed_s": ended - self.meta["started_at"]},
            "queue_records": self.records,
            "sap_events": self.saps,
        }
