
from __future__ import annotations
import time, json, importlib, pathlib, traceback, os
from typing import Any, Dict, List, Optional
import yaml
from .queue_router import OpQueue, Op
from .runlog import RunLog
from .sap_stubs import sentinel_check, arbiter_rule

def _cap(val: float, pct: float = 0.75) -> float:
    return val * pct

class Orchestrator:
    def __init__(self, code_root: str, plan_path: str, out_report: str):
        self.code_root = pathlib.Path(code_root).resolve()
        self.plan_path = pathlib.Path(plan_path).resolve()
        self.out_report = pathlib.Path(out_report).resolve()
        self.runlog = RunLog()
        self.queue = OpQueue()
        self.context: Dict[str, Any] = {"code_root": str(self.code_root)}
        # Resource allowances (env-provided), caps at 75%
        total_wall_ms = float(os.environ.get("TOTAL_WALL_MS", "600000"))  # 10 min default
        total_ram_mb = float(os.environ.get("TOTAL_RAM_MB", "4096"))      # 4 GB default
        self.wall_cap_ms = _cap(total_wall_ms, 0.75)
        self.ram_cap_mb  = _cap(total_ram_mb, 0.75)
        self.wall_used_ms = 0.0
        self.ram_peak_mb = 0.0  # we track declared estimates; Python can't measure per-op reliably here

    def _patch_sys_path(self):
        import sys
        if str(self.code_root) not in sys.path:
            sys.path.insert(0, str(self.code_root))

    def load_plan(self) -> Dict[str, Any]:
        return yaml.safe_load(self.plan_path.read_text())

    def enqueue_from_plan(self, spec: Dict[str, Any]):
        for step in spec.get("steps", []):
            op = Op(
                name=step["name"],
                family=step.get("family", "generic"),
                module=step["module"],
                func=step["func"],
                args=step.get("args", []),
                kwargs=step.get("kwargs", {}),
                priority=int(step.get("priority", 100)),
                policy_id=step.get("policy_id", "policy:default"),
                allow_3d=bool(step.get("allow_3d", False)),
            )
            # attach resource estimates onto kwargs so we can log/check
            op.kwargs.setdefault("_est_wall_ms", float(step.get("est_wall_ms", 0)))
            op.kwargs.setdefault("_est_ram_mb", float(step.get("est_ram_mb", 0)))
            self.queue.push(op)

    def _import_callable(self, module: str, func: str):
        m = importlib.import_module(module)
        fn = getattr(m, func)
        return fn

    def _govern(self, family: str, metrics: Dict[str, Any], policy_id: str) -> str:
        att = sentinel_check(policy_id, metrics)
        rule = arbiter_rule(att)
        self.runlog.log_sap(att, rule, family)
        return rule.decision

    def run(self) -> Dict[str, Any]:
        self._patch_sys_path()
        spec = self.load_plan()
        self.enqueue_from_plan(spec)
        self.runlog.start_run(spec)

        while not self.queue.empty():
            op = self.queue.pop()
            est_wall = float(op.kwargs.pop("_est_wall_ms", 0.0))
            est_ram  = float(op.kwargs.pop("_est_ram_mb", 0.0))
            # Pre-check: projected usage
            proj_wall = self.wall_used_ms + est_wall
            proj_ram_peak = max(self.ram_peak_mb, est_ram)
            pre_metrics = {
                "proj_wall_ms": proj_wall, "cap_wall_ms": self.wall_cap_ms,
                "proj_ram_mb": proj_ram_peak, "cap_ram_mb": self.ram_cap_mb,
            }
            decision = self._govern(op.family, pre_metrics, op.policy_id)
            if decision == "deny" or proj_wall > self.wall_cap_ms or proj_ram_peak > self.ram_cap_mb:
                self.runlog.log_op(op, "skipped_denied", 0.0, None, {"type": "CapExceeded", "msg": "Projected cap exceeded or governance denied"})
                continue

            t0 = time.perf_counter()
            status = "ok"; err = None; out: Any = None
            try:
                fn = self._import_callable(op.module, op.func)
                out = fn(*op.args, **op.kwargs)
            except Exception as e:
                status = "error"
                err = {"type": type(e).__name__, "msg": str(e), "trace": traceback.format_exc()}
            dur = (time.perf_counter() - t0) * 1000.0
            self.wall_used_ms += dur
            self.ram_peak_mb = max(self.ram_peak_mb, est_ram)
            # Post governance (actual usage vs caps)
            post_metrics = {
                "wall_used_ms": self.wall_used_ms, "cap_wall_ms": self.wall_cap_ms,
                "ram_peak_mb": self.ram_peak_mb, "cap_ram_mb": self.ram_cap_mb,
                "op_duration_ms": dur
            }
            self._govern(op.family, post_metrics, op.policy_id)
            self.runlog.log_op(op, status, dur, out, err)

        rep = self.runlog.finish_run()
        rep["resource_caps"] = {"wall_cap_ms": self.wall_cap_ms, "ram_cap_mb": self.ram_cap_mb}
        self.out_report.write_text(json.dumps(rep, indent=2))
        return rep
