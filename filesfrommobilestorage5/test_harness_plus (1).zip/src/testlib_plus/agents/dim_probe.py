
from __future__ import annotations
import numpy as np

def proj3d_quality(n: int = 200, seed: int = 9) -> dict:
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n,8))
    X /= (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
    q = X[0]
    sims8 = X @ q
    idx8 = np.argsort(-sims8)[:25]

    A = rng.standard_normal((3,8))
    Q, _ = np.linalg.qr(A.T)
    P = Q[:, :3].T
    Pn = (P @ X.T).T
    Pn /= (np.linalg.norm(Pn, axis=1, keepdims=True) + 1e-12)
    pq = (P @ q)
    pq /= (np.linalg.norm(pq) + 1e-12)
    sims3 = Pn @ pq
    idx3 = np.argsort(-sims3)[:25]

    inter = len(set(idx8) & set(idx3))
    overlap = inter/25.0
    return {"overlap": float(overlap), "tau": 0.95}
