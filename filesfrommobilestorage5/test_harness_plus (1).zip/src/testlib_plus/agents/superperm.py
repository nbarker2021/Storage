
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple
from itertools import permutations

@dataclass
class Kernel:
    seed: int
    alphabet: List[str]
    notes: str = ""

def kernel_gen(seed: int = 42, n: int = 7, mode: str = "dry") -> Kernel:
    # DRY mode uses small alphabet for speed; records intent for n=7
    alphabet = [chr(ord('A') + i) for i in range(3 if mode=='dry' else n)]
    return Kernel(seed=seed, alphabet=alphabet, notes=f"mode={mode}")

def constructor(kernel: Kernel) -> str:
    # Very naive: concatenate all permutations (DRY: n=3)
    alpha = kernel.alphabet
    seq = ""
    for p in permutations(alpha, len(alpha)):
        seq += ''.join(p)
    return seq

def coverage_check(seq: str, alphabet: List[str], exactly_once: bool = True) -> Dict[str, Any]:
    # DRY: compute counts for small alphabet (n=3); n=7 would be heavy
    n = len(alphabet)
    counts: Dict[str,int] = {}
    for p in permutations(alphabet, n):
        s = ''.join(p)
        c = 0
        i = 0
        L = len(seq)
        while i <= L - n:
            if seq[i:i+n] == s:
                c += 1
            i += 1
        counts[s] = c
    ok = all(v == 1 for v in counts.values()) if exactly_once else all(v >= 1 for v in counts.values())
    return {"ok": ok, "n": n, "missing": [k for k,v in counts.items() if v==0], "dups": [k for k,v in counts.items() if v>1]}

def minimizer(seq: str) -> str:
    # DRY: no-op minimizer; in real run, attempt overlap-tightening rewrites
    return seq

def reproduce(kernel: Kernel, expected: str) -> bool:
    # Rebuild and compare
    return constructor(kernel) == expected
