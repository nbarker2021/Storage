
# SNAPOps, Elevator Candidates, and Universes (A.5)

This patch:
- Enriches **elevator candidates** with room family/type/glyph and **inverse glyphs**.
- Adds **universe overlay** utilities to attach MDHG snapshots to universes and record diffs.
- Introduces an **Elevator FastLane** to auto-approve candidates that meet score thresholds and family compatibility.

## Controller usage
Provide `um=UniverseManager(...)` when constructing the controller and enable persistence:
```python
controller = AGRMController_v0_7_2025_08_13(cfg={"use_sweeps_full": True,
                                                 "universe": "DocUniverse",
                                                 "mdhg": {"persist": True, "promote_elevators": True}},
                                            repo=Repository(...),
                                            um=UniverseManager(...))
summary = controller.solve(points, metas=metas)
```

The controller will:
1. Load the last MDHG layout, apply heat, persist the new snapshot.
2. Attach the snapshot as an **overlay** to the universe and write a **universe_diff** SNAP.
3. Emit enriched **mdhg_event::...::elevator** candidates with glyphs and inverse glyphs.
4. (Optional) A review loop can call **SnapOpsCenter.review_elevator(candidate)** to approve or block.

## FastLane policy
`ElevatorFastLane(threshold, compat_policy)`
- `threshold`: minimum score
- `compat_policy`: e.g., `{"family_deny":["fiction"], "family_allow":["science","fact"]}`
