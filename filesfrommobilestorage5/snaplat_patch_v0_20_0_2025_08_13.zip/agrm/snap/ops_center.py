
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from typing import Dict, Any
from agrm.agrm.elevator_fastlane import ElevatorFastLane

class SnapOpsCenter:
    def __init__(self, *, elevator_threshold: float = 1.0, compat_policy: Dict[str,Any] | None = None):
        self.efl = ElevatorFastLane(threshold=elevator_threshold, compat_policy=compat_policy or {})

    def review_elevator(self, candidate: Dict[str,Any]):
        return self.efl.evaluate(candidate)
