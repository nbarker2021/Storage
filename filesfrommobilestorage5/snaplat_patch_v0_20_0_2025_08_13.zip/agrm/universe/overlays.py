
# SnapLat — Personal-Use License & Patent Non-Assertion v1.0 (2025-08-13)
# © [Owner Name]. All rights reserved except personal-use permissions.
# See LICENSE-SNAPLAT-PERSONAL.md. No redistribution or commercial use without written approval.

from typing import Any, Dict, Optional
import time

def attach_mdhg_overlay(um, universe: str, snap_id: str, *, label: Optional[str]=None) -> Dict[str,Any]:
    """Attach an MDHG layout snapshot as an overlay to a universe."""
    u = um.get_universe(universe)
    ov = u.overlays.get("mdhg", [])
    if snap_id not in ov:
        ov.append(snap_id)
        u.overlays["mdhg"] = ov
        um.save_universe(u)
    return {"universe": universe, "overlays": u.overlays}

def write_universe_diff(repo, universe: str, before: Dict[str,Any], after: Dict[str,Any]) -> str:
    ts = int(time.time())
    diff_id = f"universe_diff::{universe}::{ts}"
    payload = {"meta":{"snap_id":diff_id, "family":"universe_diff", "type":"overlay", "tags":{"universe":universe}},
               "content":{"before": before or {}, "after": after or {}}}
    try:
        repo.save(diff_id, payload)
    except Exception:
        pass
    return diff_id
