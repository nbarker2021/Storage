
"""Adapter: expose existing AGRM runner as a SNAP Builder."""
from typing import Any, Dict, Optional
from unified.agrm import runner as _runner
from unified.agrm import snapshots as _snaps

class AGRMBuilder:
    def build(self, instance: Dict[str, Any], *, seed: Optional[int]=None) -> Dict[str, Any]:
        # Use existing runner functions. We assume instance contains required params.
        # Here we call run_once (or similar) and collect snapshots.
        res = _runner.run_once(instance.get('params', {}), seed=seed)
        snaps = _snaps.list_snapshots()
        # Map to generic structure; res may already include metrics
        return {'result': res, 'snapshots': [s for s in snaps]}
