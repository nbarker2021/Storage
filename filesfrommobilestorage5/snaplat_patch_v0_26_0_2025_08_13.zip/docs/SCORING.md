
# Elevator scoring (v0.26.0)

Composite score per candidate:
```
score = 0.6*base + 0.2*recency + 0.1*family_diversity + 0.05*type_diversity + 0.05*inverse_glyph_bonus
```
- **base**: the controller-provided normalized heat score from MDHG (already decayed over time).
- **recency**: 0.5^(age_seconds / (6h)), favors recent MDHG snapshots.
- **family_diversity**: 1.0 if room families differ else 0.25.
- **type_diversity**: 0.6 if types differ else 0.2.
- **inverse_glyph_bonus**: 0.4*(1 - Jaccard(invA, invB)) over up to 3 tokens.

Weights can be tuned in `agrm/agrm/elevator_promotion.py`.
