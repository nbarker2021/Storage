
from __future__ import annotations
import numpy as np, time
from typing import Dict, Any, List
from .persistence import db

class Router:
    def __init__(self, p95_ms_target: float = 150.0):
        self.p95_ms_target = p95_ms_target
        self.K = 50  # starting candidate pool size

    def query(self, qvec: np.ndarray, budget: int = 10) -> List[str]:
        # naive retrieval: linear scan over glyphs + top-K by cosine
        t0 = time.time()
        gl = db.list_glyphs()
        if not gl: return []
        V = np.stack([np.asarray(g['vector']) for g in gl], axis=0)
        qs = (V @ qvec) / ((np.linalg.norm(V, axis=1)+1e-12) * (np.linalg.norm(qvec)+1e-12))
        idx = np.argsort(-qs)[:min(self.K, len(gl))]
        gids = [gl[i]['gid'] for i in idx[:budget]]
        elapsed = (time.time() - t0) * 1000.0
        self._adapt_latency(elapsed)
        return gids

    def _adapt_latency(self, ms: float) -> None:
        # Simple controller: if over target, reduce K; else cautiously increase
        if ms > self.p95_ms_target and self.K > 10:
            self.K = int(self.K * 0.9)
        elif ms < 0.5 * self.p95_ms_target and self.K < 2000:
            self.K = int(self.K * 1.1)
