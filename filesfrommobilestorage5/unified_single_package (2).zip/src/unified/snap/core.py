
"""SNAP pipeline engine: intake → build → verify → index → lattice → report.
All steps call Protocols from interfaces.py via the registry.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Sequence
from .interfaces import Builder, Index, Lattice, Goldens
from .seeds import set_global_seed

@dataclass
class Context:
    params: Dict[str, Any] = field(default_factory=dict)
    report: Dict[str, Any] = field(default_factory=dict)

def run_pipeline(*, builder: Builder, index: Index, lattice: Optional[Lattice],
                 instance: Dict[str, Any], seed: Optional[int]=None,
                 goldens: Optional[Goldens]=None) -> Dict[str, Any]:
    set_global_seed(seed)
    ctx = Context(params=dict(seed=seed), report={})
    # Build
    build_out = builder.build(instance, seed=seed)
    ctx.report['build'] = {'summary': {k: v for k, v in build_out.items() if k != 'snapshots'}}
    # Index any keys in build_out if present
    if 'snapshots' in build_out:
        for s in build_out['snapshots']:
            key = s.get('hash') or s.get('key') or s.get('id')
            if key:
                index.put(str(key), s)
    # Lattice ingest/promote
    if lattice is not None and 'snapshots' in build_out:
        items = build_out['snapshots']
        lattice.ingest(items)
        ctx.report['promotion'] = lattice.promote()
    # Goldens (optional)
    if goldens is not None:
        results = list(goldens.run())
        ctx.report['goldens'] = {'results': results,
                                 'passed': all(ok for _, ok, _ in results)}
    return ctx.report
