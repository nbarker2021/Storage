
"""Adapter: expose existing AGRM runner as a SNAP Builder with normalized snapshots."""
from __future__ import annotations
from typing import Any, Dict, Optional, List
import time
from unified.agrm import runner as _runner
from unified.agrm import snapshots as _snaps
from unified.agrm import utils as _utils

def _stable_hash(d: Dict[str, Any]) -> str:
    return _utils.stable_hash(repr(sorted(d.items())))

class AGRMBuilder:
    def build(self, instance: Dict[str, Any], *, seed: Optional[int]=None) -> Dict[str, Any]:
        params = instance.get('params', {})
        res = _runner.run_once(params, seed=seed)
        # Collect snapshots from the existing snapshot system (best-effort)
        snaps_raw: List[Dict[str, Any]] = list(_snaps.list_snapshots())
        norm_snaps = []
        now = time.time()
        for i, s in enumerate(snaps_raw):
            payload = {
                'route': s.get('route'),
                'steps': s.get('steps'),
                'score': s.get('score'),
                'metrics': s.get('metrics', {}),
            }
            sid = s.get('id') or f"snap-{seed or 0}-{i}"
            snap = {
                'id': sid,
                'seed': seed,
                'ts': s.get('ts', now),
                'params': params,
                'payload': payload,
            }
            snap['hash'] = _stable_hash({'id': sid, 'payload': payload})
            norm_snaps.append(snap)
        return {'result': res, 'snapshots': norm_snaps}
