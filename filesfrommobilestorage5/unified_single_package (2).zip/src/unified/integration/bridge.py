
from __future__ import annotations
from typing import Callable, Dict, Any, List
import numpy as np

def mdhg_key_to_lattice_key(mdhg_key: str) -> str:
    return mdhg_key

def _embed_stub(payload: Dict[str, Any], *, dim: int = 64, seed: int = 0) -> np.ndarray:
    # Deterministic vector from payload hash
    import hashlib, json
    data = json.dumps(payload, sort_keys=True).encode("utf-8")
    h = hashlib.sha256(data).digest()
    # Expand deterministically to dim floats in [-1,1]
    rng = np.random.RandomState(int.from_bytes(h[:4], "big") ^ seed)
    v = rng.randn(dim).astype(np.float32)
    v /= (np.linalg.norm(v) + 1e-12)
    return v

def snapshot_to_glyphs(snapshot: Dict[str, Any], embed: Callable[[Dict[str, Any]], np.ndarray] | None = None) -> List[Dict[str, Any]]:
    # One glyph per snapshot (can be extended if payload holds multiple items)
    e = embed or _embed_stub
    v = e(snapshot.get("payload", {}))
    g = {
        "gid": snapshot["id"],
        "vector": v,
        "ts": snapshot.get("ts", 0.0),
        "mdhg_key": snapshot.get("hash"),
        "claims": [
            {"text": f"score={snapshot.get('payload',{}).get('score')}", "ts": snapshot.get("ts", 0.0), "source": "agrm", "contradicted": False}
        ],
    }
    return [g]

# Optional custom embedder wiring
try:
    from unified.embedder.custom import get_embed as _get_embed
    _embedder = _get_embed(dim=64)
except Exception:
    _embedder = None

def snapshot_to_glyphs(snapshot: dict, embed=None):
    import numpy as np, hashlib, json
    def _embed_stub(payload: dict, *, dim: int = 64, seed: int = 0) -> np.ndarray:
        data = json.dumps(payload, sort_keys=True).encode('utf-8')
        h = hashlib.sha256(data).digest()
        rng = np.random.RandomState(int.from_bytes(h[:4],'big') ^ seed)
        v = rng.randn(dim).astype(np.float32)
        v /= (np.linalg.norm(v)+1e-12)
        return v
    e = embed or _embedder or _embed_stub
    payload = snapshot.get('payload', {})
    v = e(payload)
    g = {
        'gid': snapshot['id'],
        'vector': v,
        'ts': snapshot.get('ts', 0.0),
        'mdhg_key': snapshot.get('hash'),
        'claims': [{'text': f"score={payload.get('score')}", 'ts': snapshot.get('ts', 0.0), 'source':'agrm', 'contradicted': False}],
    }
    return [g]
