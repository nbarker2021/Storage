
from agrm_diagnostics import AGRMDiagnostics
from agrm_modulation_and_legalgraph import AGRMModulationController, AGRMLegalGraph
from agrm_pathbuilder_dual import AGRMPathBuilderDual
from agrm_salesman_patch import AGRMSalesmanPatchEngine
from agrm_spiral_reentry import AGRMSpiralReentryEngine
from agrm_complexity_modulator import AGRMComplexityWeightedModulator
from agrm_dynamic_midpoint import AGRMDynamicMidpointDetector
from agrm_spiral_retention import AGRMTopXRetainer
from agrm_zone_collapse import AGRMRecursiveZoneCollapse

class AGRMRuntimeController:
    def __init__(self, nodes: dict):
        self.nodes = nodes
        self.diagnostics = AGRMDiagnostics()
        self.legal = AGRMLegalGraph(nodes)
        self.modulator = AGRMModulationController(nodes)
        self.builder = AGRMPathBuilderDual(nodes)
        self.reentry = AGRMSpiralReentryEngine(nodes)
        self.patcher = AGRMSalesmanPatchEngine(nodes)
        self.complexity = AGRMComplexityWeightedModulator(nodes)
        self.midpoint = AGRMDynamicMidpointDetector(nodes)
        self.retainer = AGRMTopXRetainer(nodes)
        self.collapse = AGRMRecursiveZoneCollapse(nodes)

        self.loop_counter = 0
        self.max_loops = 100
        self.best_path = []
        self.best_cost = float("inf")

    def _evaluate_path(self, path):
        dist = 0
        for i in range(len(path)):
            a, b = self.nodes[path[i]], self.nodes[path[(i + 1) % len(path)]]
            dist += ((a[0] - b[0])**2 + (a[1] - b[1])**2)**0.5
        return dist

    def run_cycle(self):
        self.loop_counter += 1
        if self.loop_counter == 1:
            self.diagnostics.start_timer()

        path = self.builder.build_path()
        self.diagnostics.mark("sweep_runs")

        entropy = self.modulator.analyze_entropy(path)
        if entropy > 0.5:
            self.diagnostics.mark("entropy_slope_drops")
            self.modulator.mark_shell_failure()

        cost = self._evaluate_path(path)
        if cost < self.best_cost:
            self.best_cost = cost
            self.best_path = path
            self.diagnostics.mark("path_improved")

        high_complexity = self.complexity.compute_weights(path)
        patch_zone = self.complexity.get_high_complexity_nodes(threshold=0.7)
        if patch_zone:
            mid = self.midpoint.detect(path)
            patched = self.patcher.patch_subpath(path, max(1, mid - 3), min(len(path), mid + 4))
            self.diagnostics.mark("patch_suggestions")
            patched_cost = self._evaluate_path(patched)
            if patched_cost < self.best_cost:
                self.best_cost = patched_cost
                self.best_path = patched
                self.diagnostics.mark("path_improved")

        if self.modulator.dynamic_unlock_trigger:
            reentry_path = self.reentry.generate_fallback_path(path[0])
            re_cost = self._evaluate_path(reentry_path)
            if re_cost < self.best_cost:
                self.best_cost = re_cost
                self.best_path = reentry_path
                self.diagnostics.mark("spiral_collapses")

        if self.loop_counter >= self.max_loops:
            self.diagnostics.stop_timer()
            return True

        return False

    def get_diagnostics(self):
        return self.diagnostics.get_report()

    def get_best_path(self):
        return self.best_path

    def get_best_cost(self):
        return self.best_cost
