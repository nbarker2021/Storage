# mdhg_hash.py
# Multi-Dimensional Hamiltonian Golden Ratio Hash Table

from collections import defaultdict, deque, Counter
import math, time, random
from typing import Any, Dict, List, Tuple

class MDHGHashTable:
    def __init__(self, capacity=1024, dimensions=3):
        self.PHI = (1 + 5 ** 0.5) / 2
        self.capacity = capacity
        self.dimensions = dimensions
        self.size = 0
        self.buildings = self._init_buildings()
        self.location_map = {}
        self.stats = {
            'puts': 0, 'gets': 0, 'hits': 0, 'misses': 0, 'collisions': 0
        }

    def _init_buildings(self):
        count = max(1, int(math.log(self.capacity, self.PHI)))
        return {f"B{i}": {'velocity': [None] * (self.capacity // count)} for i in range(count)}

    def put(self, key: Any, value: Any):
        self.stats['puts'] += 1
        b_id = self._hash_to_building(key)
        b = self.buildings[b_id]
        idx = self._hash_to_velocity_index(key, b_id)
        if b['velocity'][idx] is None:
            b['velocity'][idx] = (key, value)
            self.location_map[key] = (b_id, idx)
            self.size += 1

    def get(self, key: Any) -> Any:
        self.stats['gets'] += 1
        loc = self.location_map.get(key)
        if loc:
            b_id, idx = loc
            entry = self.buildings[b_id]['velocity'][idx]
            if entry and entry[0] == key:
                self.stats['hits'] += 1
                return entry[1]
        self.stats['misses'] += 1
        return None

    def remove(self, key: Any) -> bool:
        loc = self.location_map.get(key)
        if loc:
            b_id, idx = loc
            if self.buildings[b_id]['velocity'][idx][0] == key:
                self.buildings[b_id]['velocity'][idx] = None
                del self.location_map[key]
                self.size -= 1
                return True
        return False

    def _hash_to_building(self, key) -> str:
        return f"B{hash(key) % len(self.buildings)}"

    def _hash_to_velocity_index(self, key, b_id) -> int:
        return abs(hash(str(key))) % len(self.buildings[b_id]['velocity'])

    def get_stats(self) -> Dict:
        return self.stats
