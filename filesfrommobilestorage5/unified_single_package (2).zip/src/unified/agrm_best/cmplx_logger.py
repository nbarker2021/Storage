import datetime
import os

LOG_DIR = "results/logs"
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "cmplx_log.txt")

def log(message, agent="System", phase="General"):
    timestamp = datetime.datetime.utcnow().isoformat()
    entry = f"[{timestamp}] [{agent}] [{phase}] {message}\n"
    print(entry.strip())
    with open(LOG_FILE, "a") as f:
        f.write(entry)
