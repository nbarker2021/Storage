# utils.py
import itertools
import hashlib
import logging

def setup_logging():
    """Sets up logging to a file named 'superpermutation.log'."""
    logging.basicConfig(level=logging.DEBUG, filename='superpermutation.log', filemode='w', format='%(asctime)s - %(levelname)s - %(message)s')

def compute_checksum(data: str) -> str:
    """Computes the SHA-256 checksum of a given string.  This is useful for verifying data integrity."""
    return hashlib.sha256(data.encode('utf-8')).hexdigest()

def generate_permutations(n: int):
    """Generates all possible permutations of the numbers from 1 to n (inclusive).  Returns a list of tuples, where each tuple is a permutation."""
    return list(itertools.permutations(range(1, n + 1)))

def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a given tuple is a valid permutation of numbers from 1 to n.  A valid permutation contains each number from 1 to n exactly once."""
    return len(perm) == n and set(perm) == set(range(1, n + 1))

def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the length of the maximum suffix of s1 that is also a prefix of s2.  This is used to determine how much two sequences overlap."""
    max_len = min(len(s1), len(s2))
    for i in range(max_len, 0, -1):
        if s1[-i:] == s2[:i]:
            return i
    return 0

def normalize_sequence(seq: str) -> str:
    """Normalizes a sequence by rotating it so that it starts with the smallest character.  This ensures that equivalent sequences (rotations of each other) are treated as the same."""
    min_char = min(seq)
    min_indices = [i for i, c in enumerate(seq) if c == min_char]
    rotations = [seq[i:] + seq[:i] for i in min_indices]
    return min(rotations)

def kmer_to_int(kmer):
    """Converts a k-mer (represented as a tuple of digits) to its integer representation.  This is done for efficiency, as integer comparisons are faster than tuple comparisons."""
    int_kmer = 0
    for i, digit in enumerate(kmer):
        int_kmer = int_kmer * 10 + digit
    return int_kmer

def int_to_kmer(int_kmer, k):
    """Converts an integer representation of a k-mer back to a k-mer tuple."""
    kmer = ()
    for _ in range(k):
        digit = int_kmer % 10
        kmer = (digit,) + kmer
        int_kmer //= 10
    return kmer

def hash_permutation(perm):
    """Hashes a permutation.  Handles both integer and tuple representations."""
    if isinstance(perm, tuple):
        return hash(perm)
    elif isinstance(perm, int):
        return perm
    else:
        raise TypeError("Permutation must be int or tuple")

def unhash_permutation(perm_hash, n):
    """Unhashes a permutation.  Handles integer to tuple conversion."""
    if isinstance(perm_hash, int):
        return int_to_kmer(perm_hash, n)
    else:
        raise TypeError("Permutation hash must be int")


# graph_utils.py
import networkx as nx
import logging

def build_de_bruijn_graph(kmers):
    """Builds a De Bruijn graph from a list of k-mers.  The De Bruijn graph is a directed graph where nodes represent (k-1)-mers and edges represent k-mers."""
    graph = nx.DiGraph()
    for kmer in kmers:
        graph.add_edge(kmer[:-1], kmer[1:])  # Add an edge for each k-mer
    logging.debug(f"De Bruijn graph: {graph.number_of_nodes()} nodes, {graph.number_of_edges()} edges.")
    return graph

def find_eulerian_path(graph: nx.DiGraph):
    """Finds an Eulerian path in a given graph.  An Eulerian path is a path that visits every edge exactly once."""
    try:
        path = list(nx.eulerian_path(graph))
        return [u for u, v in path] + [path[-1][1]]  # Extract the nodes from the path
    except nx.NetworkXError:
        logging.error("No Eulerian path found.")
        return []
        
        #This chunk contains the core utility functions (utils.py) and the graph-related functions (graph_utils.py).  The utility functions handle common tasks like logging, checksum calculation, permutation generation, overlap calculation, and k-mer conversion. The graph_utils.py file provides functions for building a De Bruijn graph and finding an Eulerian path within it.  These are fundamental tools used in superpermutation generation.