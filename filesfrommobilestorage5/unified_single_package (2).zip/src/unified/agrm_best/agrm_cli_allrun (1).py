
import argparse
import os
import subprocess

from agrm_profiler_diagnostics import AGRMProfiler
from agrm_runtime_controller import AGRMRuntimeController
from tsp_node_loader import select_tsp_dataset, TSPLIB_DATASETS
from agrm_results_export import export_results_to_csv, export_results_to_json, plot_comparison_graph

greedy_baseline_dict = {
    'pcb442': 18000, 'pr2392': 140000, 'rl5915': 360000,
    'rl11849': 700000, 'usa13509': 820000, 'brd14051': 860000,
    'd15112': 920000, 'pla33810': 2000000, 'pla85900': 5000000
}

optimal_baseline_dict = {
    'pcb442': 50778, 'pr2392': 378032, 'rl5915': 565530,
    'rl11849': 923288, 'usa13509': 19982859, 'brd14051': 469385,
    'd15112': 736468, 'pla33810': 660489, 'pla85900': 14238241
}

def run_agrm(loader, config, dataset_name):
    print(f"\n[RUNNING AGRM TEST] Dataset: {dataset_name}")
    profiler = AGRMProfiler()
    profiler.start_timer()

    runtime = AGRMRuntimeController(loader.get_nodes())

    while True:
        profiler.mark('cycles')
        if runtime.run_cycle():
            break

    profiler.stop_timer()
    print("\n--- AGRM Summary ---")
    profiler.print_report()
    return profiler.report()

def run_all_tests():
    all_results = {}
    for name in TSPLIB_DATASETS.keys():
        loader, config, _ = select_tsp_dataset(name)
        report = run_agrm(loader, config, dataset_name=name)
        all_results[name] = report
    print("\n[ALL AGRM TESTS COMPLETE]")
    return all_results

def main():
    parser = argparse.ArgumentParser(description="AGRM Full Benchmark Runner")
    parser.add_argument('--run_all', action='store_true', help='Run all benchmark tests')
    parser.add_argument('--export', action='store_true', help='Export results to CSV and JSON')
    parser.add_argument('--compare', action='store_true', help='Plot AGRM vs Greedy vs Optimal graph')
    args = parser.parse_args()

    if args.run_all:
        results = run_all_tests()
        if args.export:
            export_results_to_csv(results)
            export_results_to_json(results)
        if args.compare:
            plot_comparison_graph(results, greedy_baseline_dict, optimal_baseline_dict)
    else:
        print("[ERROR] Use --run_all to execute full benchmark suite")

if __name__ == '__main__':
    main()
