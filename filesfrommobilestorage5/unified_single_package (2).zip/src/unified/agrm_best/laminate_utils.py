laminate_utils.py

# laminate_utils.py
import networkx as nx
from utils import is_valid_permutation, hash_permutation, unhash_permutation

def create_laminate(sequence, n, k):
    """Creates a laminate graph from a sequence."""
    graph = nx.DiGraph()
    seq_list = [int(x) for x in sequence]
    for i in range(len(seq_list) - n + 1):
        perm = tuple(seq_list[i:i + n])
        if is_valid_permutation(perm, n):
            if i >= k:
                kmer1 = "".join(str(x) for x in seq_list[i - k:i])
                kmer2 = "".join(str(x) for x in seq_list[i - k + 1:i + 1])
                if len(kmer1) == k and len(kmer2) == k:
                    graph.add_edge(kmer1, kmer2)
    return graph

def is_compatible(permutation, laminate_graph, n, k):
    """Checks if a permutation is compatible with a laminate graph."""
    perm_str = "".join(str(x) for x in permutation)
    for i in range(len(perm_str) - k + 1):
        kmer1 = perm_str[i:i + k - 1]
        kmer2 = perm_str[i + 1:i + k]
        if len(kmer1) == k - 1 and len(kmer2) == k - 1:
            if not laminate_graph.has_edge(kmer1, kmer2):
                return False
    return True

def create_anti_laminate(anti_prodigals, n, k):
    """Creates an anti-laminate graph from a set of anti-prodigals.

    Args:
        anti_prodigals (set): A set of anti-prodigal k-mer strings.
        n (int): The value of n.
        k (int): The k-mer length used for the anti-laminate.

    Returns:
        networkx.DiGraph: The anti-laminate graph.
    """

    anti_laminate = nx.DiGraph()

    # Create a complete graph with all possible (n-1)-mers as nodes and edges
    for perm in generate_permutations(n):
        perm_str = "".join(map(str, perm))
        for i in range(len(perm_str) - (k - 1) + 1):
            kmer1 = perm_str[i:i + k - 1]
            kmer2 = perm_str[i + 1:i + k]
            if len(kmer1) == k-1 and len(kmer2) == k-1:
                anti_laminate.add_edge(kmer1, kmer2)


    # Remove edges that correspond to anti-prodigal k-mers
    for anti_prodigal in anti_prodigals:
        if len(anti_prodigal) == k:  # Ensure the anti-prodigal is a k-mer
            prefix = anti_prodigal[:-1]
            suffix = anti_prodigal[1:]
            if anti_laminate.has_edge(prefix, suffix):
                anti_laminate.remove_edge(prefix, suffix)

    return anti_laminate