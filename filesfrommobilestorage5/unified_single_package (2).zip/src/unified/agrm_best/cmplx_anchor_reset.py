
from typing import Dict, Tuple, List
import math

class AGRMAnchorReselector:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def find_new_anchor(self, path: List[int], max_offset: float = 0.3) -> int:
        print("[AnchorReset] Evaluating drift and re-centering candidate anchor...")
        max_dist = max(
            math.hypot(coord[0] - self.center[0], coord[1] - self.center[1])
            for coord in self.nodes.values()
        )
        threshold = max_offset * max_dist

        for nid in path:
            dist = math.hypot(
                self.nodes[nid][0] - self.center[0],
                self.nodes[nid][1] - self.center[1]
            )
            if dist <= threshold:
                print(f"[AnchorReset] Anchor reassigned to node {nid} (within {threshold:.2f})")
                return nid

        fallback = path[len(path) // 2]
        print(f"[AnchorReset] Fallback anchor: node {fallback}")
        return fallback
