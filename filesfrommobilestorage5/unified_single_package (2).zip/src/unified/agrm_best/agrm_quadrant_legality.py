
from typing import Dict, Tuple

class AGRMQuadrantLegality:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.center = self._compute_center()
        self.node_quadrants = {nid: self._quadrant(coord) for nid, coord in nodes.items()}

    def _compute_center(self) -> Tuple[float, float]:
        xs, ys = zip(*self.nodes.values())
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    def _quadrant(self, coord: Tuple[float, float]) -> int:
        dx, dy = coord[0] - self.center[0], coord[1] - self.center[1]
        if dx >= 0 and dy >= 0:
            return 0
        elif dx < 0 and dy >= 0:
            return 1
        elif dx < 0 and dy < 0:
            return 2
        else:
            return 3

    def is_crossing_illegal(self, a: int, b: int, max_jump: int = 2) -> bool:
        qa = self.node_quadrants.get(a)
        qb = self.node_quadrants.get(b)
        if qa is None or qb is None:
            return False
        delta = abs(qa - qb)
        delta = min(delta, 4 - delta)  # wrap around
        return delta > max_jump
