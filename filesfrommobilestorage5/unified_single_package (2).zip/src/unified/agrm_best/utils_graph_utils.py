# utils.py
import itertools
import hashlib
import logging

def setup_logging():
    """Sets up logging to a file."""
    logging.basicConfig(level=logging.DEBUG, filename='superpermutation.log', filemode='w', format='%(asctime)s - %(levelname)s - %(message)s')

def compute_checksum(data: str) -> str:
    """Computes the SHA-256 checksum of a string."""
    return hashlib.sha256(data.encode('utf-8')).hexdigest()

def generate_permutations(n: int):
    """Generates all permutations of numbers from 1 to n."""
    return list(itertools.permutations(range(1, n + 1)))

def is_valid_permutation(perm: tuple, n: int) -> bool:
    """Checks if a tuple is a valid permutation."""
    return len(perm) == n and set(perm) == set(range(1, n + 1))

def calculate_overlap(s1: str, s2: str) -> int:
    """Calculates the maximum overlap between two strings."""
    max_len = min(len(s1), len(s2))
    for i in range(max_len, 0, -1):
        if s1[-i:] == s2[:i]:
            return i
    return 0

def normalize_sequence(seq: str) -> str:
    """Normalizes a sequence by rotating it."""
    min_char = min(seq)
    min_indices = [i for i, c in enumerate(seq) if c == min_char]
    rotations = [seq[i:] + seq[:i] for i in min_indices]
    return min(rotations)

def kmer_to_int(kmer):
    """Converts a k-mer tuple to an integer."""
    int_kmer = 0
    for i, digit in enumerate(kmer):
        int_kmer = int_kmer * 10 + digit
    return int_kmer

def int_to_kmer(int_kmer, k):
    """Converts an integer to a k-mer tuple."""
    kmer = ()
    for _ in range(k):
        digit = int_kmer % 10
        kmer = (digit,) + kmer
        int_kmer //= 10
    return kmer

def hash_permutation(perm):
    """Hashes a permutation (tuple or int)."""
    if isinstance(perm, tuple):
        return hash(perm)
    elif isinstance(perm, int):
        return perm
    else:
        raise TypeError("Permutation must be int or tuple")

def unhash_permutation(perm_hash, n):
    """Unhashes a permutation (int to tuple)."""
    if isinstance(perm_hash, int):
        return int_to_kmer(perm_hash, n)
    else:
        raise TypeError("Permutation hash must be int")


# graph_utils.py
import networkx as nx
import logging

def build_de_bruijn_graph(kmers):
    """Builds a De Bruijn graph."""
    graph = nx.DiGraph()
    for kmer in kmers:
        graph.add_edge(kmer[:-1], kmer[1:])
    logging.debug(f"De Bruijn graph: {graph.number_of_nodes()} nodes, {graph.number_of_edges()} edges.")
    return graph

def find_eulerian_path(graph: nx.DiGraph):
    """Finds an Eulerian path in the graph."""
    try:
        path = list(nx.eulerian_path(graph))
        return [u for u, v in path] + [path[-1][1]]
    except nx.NetworkXError:
        logging.error("No Eulerian path found.")
        return []