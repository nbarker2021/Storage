import os
import pandas as pd
from systems.top_layer_controller import register_agents
from core.cmplx_runtime_controller import AGRMRuntimeController
from core.cmplx_logger import log

def infer_config_from_filename(filename):
    name = filename.lower()
    if "75k" in name:
        return {"max_cycles": 150, "merge_stall": 2, "entropy": 0.4}
    elif "50k" in name:
        return {"max_cycles": 120, "merge_stall": 3, "entropy": 0.45}
    elif "25k" in name:
        return {"max_cycles": 100, "merge_stall": 4, "entropy": 0.48}
    else:
        return {"max_cycles": 80, "merge_stall": 5, "entropy": 0.5}

def run_one_test(tsp_file):
    config = infer_config_from_filename(tsp_file)
    controller = register_agents()

    df = pd.read_csv(tsp_file)
    nodes = {int(row['id']): (row['x'], row['y']) for _, row in df.iterrows()}

    log(f"Running selective CMPLX test on {tsp_file} with config: {config}", agent="CLI", phase="SingleRun")
    runtime = AGRMRuntimeController(nodes)
    runtime.apply_learning_plan({
        "builder": {"max_merge_stall": config["merge_stall"]},
        "modulator": {"entropy_collapse_threshold": config["entropy"]},
        "controller": {"max_cycles": config["max_cycles"]}
    })

    for _ in range(config["max_cycles"]):
        if runtime.run_cycle():
            break

if __name__ == "__main__":
    test_file = "datasets/tsp_75k_test.csv"
    run_one_test(test_file)