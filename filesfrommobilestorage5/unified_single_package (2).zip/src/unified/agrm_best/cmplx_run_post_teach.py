import os
import yaml
import pandas as pd
from core.cmplx_logger import log
from core.runtime_controller import AGRMRuntimeController
from core.config_loader import load_config
from core.audit_output import save_audit_output
from plans.learning_plan_manager import LearningPlanManager
from agents.register_agents import register_agents

def run_cmplx_cli(dataset_path, plan_mode="generate", save_audit=True, recovery_depth=0):
    if recovery_depth > 2:
        log("Maximum recovery depth exceeded. Aborting self-triggered run.", agent="CLI", phase="RecursionGuard")
        return

    df = pd.read_csv(dataset_path)
    nodes = {int(row['id']): (row['x'], row['y']) for _, row in df.iterrows()}
    config = load_config(dataset_path)
    runtime_settings = config.get("runtime_settings", {})

    agent_manager = register_agents(runtime_settings)
    runtime = AGRMRuntimeController(nodes)
    runtime.inject_agent_manager(agent_manager)

    if plan_mode == "generate":
        planner = LearningPlanManager()
        audit_path = os.path.join("results", "audit_result.json")
        plan = planner.generate_plan(audit_path, dataset_path)

    elif plan_mode.endswith(".yaml"):
        with open(plan_mode, 'r') as f:
            plan = yaml.safe_load(f)

    else:
        with open(os.path.join("presets", f"{plan_mode}.yaml"), 'r') as f:
            plan = yaml.safe_load(f)

    if "agents" in plan:
        agent_manager.replace_from_strategy(plan["agents"])

    agent_manager.get_agent("builder").configure(plan.get("builder", {}))
    runtime.set_max_cycles(plan.get("controller", {}).get("max_cycles", runtime_settings["limits"]["max_cycles"]))

    runtime.state["plan_used"] = plan
    runtime.state["dataset"] = dataset_path
    runtime.state["_recovery_depth"] = recovery_depth
    runtime.state["runtime_config"] = runtime_settings

    while not runtime.is_terminated():
        runtime.run_cycle()

    if save_audit:
        save_audit_output(runtime.get_state(), output_path="results/audit_result.json")

    # 🧠 Post-cycle teaching only now
    teacher = agent_manager.get_agent("teacher")
    if teacher:
        teacher.step(runtime.get_state())
