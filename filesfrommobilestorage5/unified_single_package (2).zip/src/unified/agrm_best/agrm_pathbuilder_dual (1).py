
import random
from typing import List, Tuple, Dict
from agrm_modulation_and_legalgraph import AGRMLegalGraph

class AGRMPathBuilderDual:
    def __init__(self, nodes: Dict[int, Tuple[float, float]]):
        self.nodes = nodes
        self.legal_graph = AGRMLegalGraph(nodes)
        self.last_path: List[int] = []

    def build_path(self, forward: bool = True) -> List[int]:
        print(f"[BuilderDual] Generating {'forward' if forward else 'reverse'} path...")
        all_nodes = list(self.nodes.keys())
        start = all_nodes[0] if forward else all_nodes[-1]
        visited = {start}
        path = [start]

        current = start
        while len(path) < len(all_nodes):
            options = list(self.legal_graph.neighbors(current) - visited)
            if not options:
                break
            next_node = min(
                options,
                key=lambda n: self._distance(self.nodes[current], self.nodes[n])
            )
            path.append(next_node)
            visited.add(next_node)
            current = next_node

        self.last_path = path
        return path

    def _distance(self, a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return ((a[0] - b[0])**2 + (a[1] - b[1])**2) ** 0.5

    def get_last_path(self) -> List[int]:
        return self.last_path

    
def invalidate_legality(self, a: int, b: int, feedback_bus=None):
    self.legal_graph.invalidate_edge(a, b)
    if feedback_bus:
        feedback_bus.broadcast("builder_illegal_transition", {"from": a, "to": b})
        feedback_bus.log_failure(b)

        self.legal_graph.invalidate_edge(a, b)
