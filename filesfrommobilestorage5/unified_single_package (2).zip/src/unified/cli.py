
import argparse, json
from unified.snap.registry import default as R
from unified.snap.core import run_pipeline
from unified.integration.agrm_adapter import AGRMBuilder
from unified.integration.mdhg_adapter import MDHGIndexAdapter
from unified.integration.e8_adapter import NoopLattice
from unified.e8.jobs.queue import sweep_promotion
from unified.e8.persistence import db as e8db

# Register default tools
R.register("builder:agrm", lambda **kw: AGRMBuilder())
    from unified.integration.agrm_v5_adapter import AGRMBuilderV5
    R.register("builder:agrm_v5", lambda **kw: AGRMBuilderV5())
    from unified.integration.agrm_v4_adapter import AGRMBuilderV4
    R.register("builder:agrm_v4", lambda **kw: AGRMBuilderV4())
    from unified.integration.agrm_v3_adapter import AGRMBuilderV3
    R.register("builder:agrm_v3", lambda **kw: AGRMBuilderV3())
    from unified.integration.agrm_best_adapter import AGRMBuilderBest
    R.register("builder:agrm_best", lambda **kw: AGRMBuilderBest())
    from unified.integration.agrm_v2_adapter import AGRMBuilderV2
    R.register("builder:agrm_v2", lambda **kw: AGRMBuilderV2())
    from unified.integration.agrm_v1_adapter import AGRMBuilderV1
    R.register("builder:agrm_v1", lambda **kw: AGRMBuilderV1())
    from unified.agrm_ref.builder import AGRMRefBuilder
    R.register("builder:agrm_ref", lambda **kw: AGRMRefBuilder())
R.register("index:mdhg", lambda **kw: MDHGIndexAdapter())
R.register("lattice:e8", lambda **kw: NoopLattice())  # placeholder, promotion via jobs.queue

def main():
    p = argparse.ArgumentParser(description="Unified SNAP CLI (agnostic toolchain)")
    p.add_argument("--builder", default="builder:agrm")
    p.add_argument("--index", default="index:mdhg")
    p.add_argument("--lattice", default="none", help="'none' or a registry key (e.g., lattice:e8)")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--instance", type=str, default="{}", help="JSON dict with problem params")
    p.add_argument("--raw-agrm", action="store_true", help="Run original AGRM __main__ instead")
    ns = p.parse_args()

    if ns.raw_agrm:
        import unified.agrm.__main__ as mainmod
        return mainmod.cli()

    builder = R.build(ns.builder)
    index = R.build(ns.index)
    lattice = None if ns.lattice == "none" else R.build(ns.lattice)
    instance = json.loads(ns.instance)

    report = run_pipeline(builder=builder, index=index, lattice=lattice,
                          instance=instance, seed=ns.seed, goldens=None)
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
