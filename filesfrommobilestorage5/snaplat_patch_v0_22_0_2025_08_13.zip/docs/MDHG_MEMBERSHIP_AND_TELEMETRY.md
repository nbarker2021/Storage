
# MDHG Membership & Telemetry (v0.22.0)

## Membership in snapshots
Each room now includes a compressed `members.ranges` encoding of its indices. On reload, the hierarchy restores:
- index→room map (enabling heat application across runs),
- room sizes/heat/tags,
- existing elevators.

## Ephemeral events (persist=False)
When `cfg['mdhg']['persist'] == False` and a `repo` is provided:
- The controller writes an ephemeral MDHG snapshot (`family=mdhg_ephemeral`) and still emits enriched elevator candidates referencing that id.

## Telemetry
`summary['telemetry']` exposes:
- `candidates_emitted`: number of elevator candidates written,
- `candidates_blocked`: reserved,
- `policy_blocks`: count of room splits blocked by policy.
