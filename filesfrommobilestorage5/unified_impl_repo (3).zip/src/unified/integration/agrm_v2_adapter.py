
from __future__ import annotations
from typing import Any, Dict, Optional, List
import time
try:
    from unified.agrm_v2 import runner as _runner
except Exception:
    _runner = None
try:
    from unified.agrm_v2 import snapshots as _snaps
except Exception:
    _snaps = None

def _collect_snapshots() -> List[Dict[str, Any]]:
    snaps = []
    if _snaps and hasattr(_snaps, "list_snapshots"):
        try:
            snaps = list(_snaps.list_snapshots())
        except Exception:
            snaps = []
    return snaps

class AGRMBuilderV2:
    def build(self, instance: Dict[str, Any], *, seed: Optional[int]=None) -> Dict[str, Any]:
        params = instance.get('params', {})
        res = None
        if _runner:
            # Try common entry points
            for fn in ("run_once","main","run_beam"):
                if hasattr(_runner, fn):
                    try:
                        res = getattr(_runner, fn)(params, seed=seed) if fn=="run_once" else getattr(_runner, fn)()
                        break
                    except TypeError:
                        try:
                            res = getattr(_runner, fn)(params)
                            break
                        except Exception:
                            pass
                    except Exception:
                        pass
        if res is None:
            res = {{"ok": False, "note": "Runner entry not found or failed"}}
        snaps_raw = _collect_snapshots()
        now = time.time()
        norm_snaps = []
        for i, s in enumerate(snaps_raw):
            payload = {{k: s.get(k) for k in ("route","steps","score","metrics") if k in s}}
            sid = s.get("id") or f"v2-snap-{{seed or 0}}-{{i}}"
            snap = {{
                "id": sid,
                "seed": seed,
                "ts": s.get("ts", now),
                "params": params,
                "payload": payload or {{}}
            }}
            snap["hash"] = str(hash(str(snap["id"]) + str(snap["payload"])))
            norm_snaps.append(snap)
        return {{"result": res, "snapshots": norm_snaps}}
