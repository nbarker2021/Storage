
# Viewer24 Controller v2 + Dihedral CA Overlay (pure stdlib)

Dihedrally connected cellular automaton overlay spanning 24 screens (6x4). Global
grid ensures seam continuity; each tile uses a distinct Julia parameter derived
from its Niemeier label, giving unique but edge-aligned dynamics. Colors follow
an approximate electromagnetic spectrum mapping, with angle banding.

Run:
  python viewer_api.py
  # open http://127.0.0.1:8989

Controls: Init CA, Play/Pause, Alpha (overlay opacity). Paste points to set the
geometry layer's world->screen affine; all canvases stay edge-aligned.
