
from typing import Tuple
def lane_color(channel: int) -> Tuple[float,float,float]:
    if channel == 3: return (1.0,0.95,0.9)
    if channel == 6: return (0.9,1.0,0.95)
    if channel == 9: return (0.9,0.95,1.0)
    return (1.0,1.0,1.0)
