
from typing import Dict, List, Tuple
import math

DGraph = Dict[int, Dict[int, float]]  # u -> {v: w}

def floyd_warshall(G: DGraph):
    nodes = sorted(set(G.keys()) | {v for u in G for v in G[u]})
    idx = {u:i for i,u in enumerate(nodes)}
    n = len(nodes)
    INF = 1e18
    D = [[INF]*n for _ in range(n)]
    nxt = [[-1]*n for _ in range(n)]
    for u in nodes:
        i = idx[u]; D[i][i] = 0.0; nxt[i][i] = i
        for v,w in G.get(u, {}).items():
            j = idx[v]; 
            if w < D[i][j]: 
                D[i][j] = w; nxt[i][j] = j
    for k in range(n):
        for i in range(n):
            Dik = D[i][k]
            if Dik == INF: continue
            for j in range(n):
                alt = Dik + D[k][j]
                if alt < D[i][j]:
                    D[i][j] = alt; nxt[i][j] = nxt[i][k]
    return nodes, idx, D, nxt

def reconstruct_path(u: int, v: int, nodes: List[int], idx, nxt) -> List[int]:
    i, j = idx[u], idx[v]
    if nxt[i][j] == -1: return []
    path = [u]
    while u != v:
        i = idx[u]; j = idx[v]
        u = nodes[nxt[i][j]]
        path.append(u)
    return path

def eulerize_directed_approx(G: DGraph) -> DGraph:
    nodes = sorted(set(G.keys()) | {v for u in G for v in G[u]})
    H: DGraph = {u: dict(G.get(u, {})) for u in nodes}
    indeg = {u: 0 for u in nodes}
    outdeg = {u: 0 for u in nodes}
    for u in nodes:
        for v in H.get(u, {}):
            outdeg[u] += 1; indeg[v] += 1
    surplus = [u for u in nodes if outdeg[u] > indeg[u]]  # needs inbound
    deficit = [u for u in nodes if indeg[u] > outdeg[u]]  # needs outbound
    if not surplus and not deficit:
        return H

    nodes_list, idx, D, nxt = floyd_warshall(H)

    si, di = 0, 0
    while si < len(surplus) and di < len(deficit):
        u = surplus[si]; v = deficit[di]  # add path v -> u
        p = reconstruct_path(v, u, nodes_list, idx, nxt)
        if not p or len(p) < 2:
            di += 1
            continue
        for a,b in zip(p[:-1], p[1:]):
            w = D[idx[a]][idx[b]]
            H.setdefault(a, {})[b] = H.get(a, {}).get(b, 0.0) + w
            outdeg[a] += 1; indeg[b] += 1
        if outdeg[u] <= indeg[u]: si += 1
        if indeg[v] <= outdeg[v]: di += 1
    return H

def euler_tour_directed(H: DGraph, start: int) -> List[int]:
    G = {u: list(vs.keys()) for u,vs in H.items()}
    stack = [start]; path = []
    while stack:
        v = stack[-1]
        if G.get(v):
            u = G[v].pop()
            stack.append(u)
        else:
            path.append(stack.pop())
    path.reverse()
    return path
